/***************************************************
 *   DL_MESO       Version 2.7                     *
 *   Authors   :   R. S. Qin, M. A. Seaton         *
 *   Amended   :   L. Grinberg                     *
 *   Copyright :   UKRI STFC Daresbury Laboratory  *
 *             :   09/12/2018                      *
 ***************************************************/


int fGetMomentEquilibriumF(double *meq, double *p, double rho)
{

  // calculate equilibrium moments of compressible fluid for MRT collision schemes:
  // not suitable for incompressible fluid
  const double c1 = -7.0/3.0;
  const double c2 = -2.0/3.0;
  double rrho = fReciprocal(rho);

  if(lbsy.nq == 9) {
    // D2Q9 (Lallemand and Luo, 2000)
    meq[0] = rho;                                                                              // density
    meq[1] = -2.0 * rho + 3.0 * (p[0] * p[0] + p[1] * p[1]) * rrho;                            // energy
    meq[2] = lbmrtw[0] * rho + lbmrtw[1] * (p[0] * p[0] + p[1] * p[1]) * rrho;                 // energy-squared
    meq[3] = p[0];                                                                             // x-momentum
    meq[4] = -p[0];                                                                            // x-energy flux
    meq[5] = p[1];                                                                             // y-momentum
    meq[6] = -p[1];                                                                            // y-energy flux
    meq[7] = (p[0] * p[0] - p[1] * p[1]) * rrho;                                               // diagonal (xx) stress tensor
    meq[8] = p[0] * p[1] * rrho;                                                               // off-diagonal (xy) stress tensor
  }
  else if(lbsy.nq == 15) {
    // D3Q15 (d'Humieres et al., 2002)
    meq[0]  = rho;                                                                             // density
    meq[1]  = -rho + (p[0] * p[0] + p[1] * p[1] + p[2] * p[2]) * rrho;                         // energy
    meq[2]  = lbmrtw[0] * rho + lbmrtw[1] * (p[0] * p[0] + p[1] * p[1] + p[2] * p[2]) * rrho;  // energy-squared
    meq[3]  = p[0];                                                                            // x-momentum
    meq[4]  = c1 * p[0];                                                                       // x-energy flux
    meq[5]  = p[1];                                                                            // y-momentum
    meq[6]  = c1 * p[1];                                                                       // y-energy flux
    meq[7]  = p[2];                                                                            // z-momentum
    meq[8]  = c1 * p[2];                                                                       // z-energy flux
    meq[9]  = (2.0 * p[0] * p[0] - p[1] * p[1] - p[2] * p[2]) * rrho;                          // diagonal (xx) stress tensor (3p_xx)
    meq[10] = (p[1] * p[1] - p[2] * p[2]) * rrho;                                              // diagonal (yy/zz) stress tensor (p_yy - p_zz)
    meq[11] = p[0] * p[1] * rrho;                                                              // off-diagonal (xy) stress tensor
    meq[12] = p[1] * p[2] * rrho;                                                              // off-diagonal (yz) stress tensor
    meq[13] = p[0] * p[2] * rrho;                                                              // off-diagonal (zx) stress tensor
    meq[14] = 0.0;                                                                             // antisymmetric (xyz) third-order moment
  }
  else if(lbsy.nq == 19) {
    // D3Q19 (d'Humieres et al., 2002)
    meq[0]  = rho;                                                                             // density
    meq[1]  = -11.0 * rho + 19.0 * (p[0] * p[0] + p[1] * p[1] + p[2] * p[2]) * rrho;           // energy
    meq[2]  = lbmrtw[0] * rho + lbmrtw[1] * (p[0] * p[0] + p[1] * p[1] + p[2] * p[2]) * rrho;  // energy-squared
    meq[3]  = p[0];                                                                            // x-momentum
    meq[4]  = c2 * p[0];                                                                       // x-energy flux
    meq[5]  = p[1];                                                                            // y-momentum
    meq[6]  = c2 * p[1];                                                                       // y-energy flux
    meq[7]  = p[2];                                                                            // z-momentum
    meq[8]  = c2 * p[2];                                                                       // z-energy flux
    meq[9]  = (2.0 * p[0] * p[0] - p[1] * p[1] - p[2] * p[2]) * rrho;                          // diagonal (xx) stress tensor (3p_xx)
    meq[10] = lbmrtw[2] * (2.0 * p[0] * p[0] - p[1] * p[1] - p[2] * p[2]) * rrho;              // diagonal (xx) fourth-order moment (3 pi_xx)
    meq[11] = (p[1] * p[1] - p[2] * p[2]) * rrho;                                              // diagonal (yy/zz) stress tensor (p_yy - p_zz)
    meq[12] = lbmrtw[2] * (p[1] * p[1] - p[2] * p[2]) * rrho;                                  // diagonal (yy/zz) fourth-order moment (pi_yy - pi_zz)
    meq[13] = p[0] * p[1] * rrho;                                                              // off-diagonal (xy) stress tensor
    meq[14] = p[1] * p[2] * rrho;                                                              // off-diagonal (yz) stress tensor
    meq[15] = p[0] * p[2] * rrho;                                                              // off-diagonal (zx) stress tensor
    meq[16] = 0.0;                                                                             // symmetric (x) third-order moment
    meq[17] = 0.0;                                                                             // symmetric (y) third-order moment
    meq[18] = 0.0;                                                                             // symmetric (z) third-order moment
  }
  else if(lbsy.nq == 27) {
    // D3Q27 (Suga et al., 2015)
    meq[0]  = rho;                                                                             // density
    meq[1]  = p[0];                                                                            // x-momentum
    meq[2]  = p[1];                                                                            // y-momentum
    meq[3]  = p[2];                                                                            // z-momentum
    meq[4]  = -rho + (p[0] * p[0] + p[1] * p[1] + p[2] * p[2]) * rrho;                         // energy
    meq[5]  = (2.0 * p[0] * p[0] - p[1] * p[1] - p[2] * p[2]) * rrho;                          // diagonal (xx) stress tensor (3p_xx)
    meq[6]  = (p[1] * p[1] - p[2] * p[2]) * rrho;                                              // diagonal (yy/zz) stress tensor (p_yy - p_zz)
    meq[7]  = p[0] * p[1] * rrho;                                                              // off-diagonal (xy) stress tensor
    meq[8]  = p[1] * p[2] * rrho;                                                              // off-diagonal (yz) stress tensor
    meq[9]  = p[0] * p[2] * rrho;                                                              // off-diagonal (zx) stress tensor
    meq[10] = -2.0 * p[0];                                                                     // x-energy flux
    meq[11] = -2.0 * p[1];                                                                     // y-energy flux
    meq[12] = -2.0 * p[2];                                                                     // z-energy flux
    meq[13] = p[0];                                                                            // square of x-energy flux
    meq[14] = p[1];                                                                            // square of y-energy flux
    meq[15] = p[2];                                                                            // square of z-energy flux
    meq[16] = rho - 2.0 * (p[0] * p[0] + p[1] * p[1] + p[2] * p[2]) * rrho;                    // energy-squared
    meq[17] = -rho + (p[0] * p[0] + p[1] * p[1] + p[2] * p[2]) * rrho;                         // energy-cubed
    meq[18] = -(2.0 * p[0] * p[0] - p[1] * p[1] - p[2] * p[2]) * rrho;                         // diagonal (xx) fourth-order moment (3 pi_xx)
    meq[19] = -(p[1] * p[1] - p[2] * p[2]) * rrho;                                             // diagonal (yy/zz) fourth-order moment (pi_yy - pi_zz)
    meq[20] = -p[0] * p[1] * rrho;                                                             // off-diagonal (xy) fourth-order moment
    meq[21] = -p[1] * p[2] * rrho;                                                             // off-diagonal (yz) fourth-order moment
    meq[22] = -p[0] * p[2] * rrho;                                                             // off-diagonal (zx) fourth-order moment
    meq[23] = 0.0;                                                                             // symmetric (x) third-order moment
    meq[24] = 0.0;                                                                             // symmetric (y) third-order moment
    meq[25] = 0.0;                                                                             // symmetric (z) third-order moment
    meq[26] = 0.0;                                                                             // anti-symmetric (xyz) third-order moment
  }
  else if(lbdm.rank ==0) {
    cout << "the multiple-relaxation-time scheme for D" << lbsy.nd << "Q" << lbsy.nq << " model has not been defined" << endl;
    if(lbsy.nd == 2)
      cout << "the D2Q9 model can be used" << endl;
    else
      cout << "the D3Q15, D3Q19 or D3Q27 models can be used" << endl;
    exit(1);
  }  
  return 0;
}


int fGetMomentEquilibriumFIncom(double *meq, double *p, double rho, double rho0)
{

  // calculate equilibrium moments of incompressible fluid for MRT collision schemes
  const double c1 = -7.0/3.0;
  const double c2 = -2.0/3.0;
  double rrho = fReciprocal(rho0);
    
  if(lbsy.nq == 9) {
    // D2Q9 (Lallemand and Luo, 2000)
    meq[0] = rho;                                                                              // density
    meq[1] = -2.0 * rho + 3.0 * (p[0] * p[0] + p[1] * p[1]) * rrho;                            // energy
    meq[2] = lbmrtw[0] * rho + lbmrtw[1] * (p[0] * p[0] + p[1] * p[1]) * rrho;                 // energy-squared
    meq[3] = p[0];                                                                             // x-momentum
    meq[4] = -p[0];                                                                            // x-energy flux
    meq[5] = p[1];                                                                             // y-momentum
    meq[6] = -p[1];                                                                            // y-energy flux
    meq[7] = (p[0] * p[0] - p[1] * p[1]) * rrho;                                               // diagonal (xx) stress tensor
    meq[8] = p[0] * p[1] * rrho;                                                               // off-diagonal (xy) stress tensor
  }
  else if(lbsy.nq == 15) {
    // D3Q15 (d'Humieres et al., 2002)
    meq[0]  = rho;                                                                             // density
    meq[1]  = -rho + (p[0] * p[0] + p[1] * p[1] + p[2] * p[2]) * rrho;                         // energy
    meq[2]  = lbmrtw[0] * rho + lbmrtw[1] * (p[0] * p[0] + p[1] * p[1] + p[2] * p[2]) * rrho;  // energy-squared
    meq[3]  = p[0];                                                                            // x-momentum
    meq[4]  = c1 * p[0];                                                                       // x-energy flux
    meq[5]  = p[1];                                                                            // y-momentum
    meq[6]  = c1 * p[1];                                                                       // y-energy flux
    meq[7]  = p[2];                                                                            // z-momentum
    meq[8]  = c1 * p[2];                                                                       // z-energy flux
    meq[9]  = (2.0 * p[0] * p[0] - p[1] * p[1] - p[2] * p[2]) * rrho;                          // diagonal (xx) stress tensor (3p_xx)
    meq[10] = (p[1] * p[1] - p[2] * p[2]) * rrho;                                              // diagonal (yy/zz) stress tensor (p_yy - p_zz)
    meq[11] = p[0] * p[1] * rrho;                                                              // off-diagonal (xy) stress tensor
    meq[12] = p[1] * p[2] * rrho;                                                              // off-diagonal (yz) stress tensor
    meq[13] = p[0] * p[2] * rrho;                                                              // off-diagonal (zx) stress tensor
    meq[14] = 0.0;                                                                             // antisymmetric (xyz) third-order moment
  }
  else if(lbsy.nq == 19) {
    // D3Q19 (d'Humieres et al., 2002)
    meq[0]  = rho;                                                                             // density
    meq[1]  = -11.0 * rho + 19.0 * (p[0] * p[0] + p[1] * p[1] + p[2] * p[2]) * rrho;           // energy
    meq[2]  = lbmrtw[0] * rho + lbmrtw[1] * (p[0] * p[0] + p[1] * p[1] + p[2] * p[2]) * rrho;  // energy-squared
    meq[3]  = p[0];                                                                            // x-momentum
    meq[4]  = c2 * p[0];                                                                       // x-energy flux
    meq[5]  = p[1];                                                                            // y-momentum
    meq[6]  = c2 * p[1];                                                                       // y-energy flux
    meq[7]  = p[2];                                                                            // z-momentum
    meq[8]  = c2 * p[2];                                                                       // z-energy flux
    meq[9]  = (2.0 * p[0] * p[0] - p[1] * p[1] - p[2] * p[2]) * rrho;                          // diagonal (xx) stress tensor (3p_xx)
    meq[10] = lbmrtw[2] * (2.0 * p[0] * p[0] - p[1] * p[1] - p[2] * p[2]) * rrho;              // diagonal (xx) fourth-order moment (3 pi_xx)
    meq[11] = (p[1] * p[1] - p[2] * p[2]) * rrho;                                              // diagonal (yy/zz) stress tensor (p_yy - p_zz)
    meq[12] = lbmrtw[2] * (p[1] * p[1] - p[2] * p[2]) * rrho;                                  // diagonal (yy/zz) fourth-order moment (pi_yy - pi_zz)
    meq[13] = p[0] * p[1] * rrho;                                                              // off-diagonal (xy) stress tensor
    meq[14] = p[1] * p[2] * rrho;                                                              // off-diagonal (yz) stress tensor
    meq[15] = p[0] * p[2] * rrho;                                                              // off-diagonal (zx) stress tensor
    meq[16] = 0.0;                                                                             // symmetric (x) third-order moment
    meq[17] = 0.0;                                                                             // symmetric (y) third-order moment
    meq[18] = 0.0;                                                                             // symmetric (z) third-order moment
  }
  else if(lbsy.nq == 27) {
    // D3Q27 (Suga et al., 2015)
    meq[0]  = rho;                                                                             // density
    meq[1]  = p[0];                                                                            // x-momentum
    meq[2]  = p[1];                                                                            // y-momentum
    meq[3]  = p[2];                                                                            // z-momentum
    meq[4]  = -rho + (p[0] * p[0] + p[1] * p[1] + p[2] * p[2]) * rrho;                         // energy
    meq[5]  = (2.0 * p[0] * p[0] - p[1] * p[1] - p[2] * p[2]) * rrho;                          // diagonal (xx) stress tensor (3p_xx)
    meq[6]  = (p[1] * p[1] - p[2] * p[2]) * rrho;                                              // diagonal (yy/zz) stress tensor (p_yy - p_zz)
    meq[7]  = p[0] * p[1] * rrho;                                                              // off-diagonal (xy) stress tensor
    meq[8]  = p[1] * p[2] * rrho;                                                              // off-diagonal (yz) stress tensor
    meq[9]  = p[0] * p[2] * rrho;                                                              // off-diagonal (zx) stress tensor
    meq[10] = -2.0 * p[0];                                                                     // x-energy flux
    meq[11] = -2.0 * p[1];                                                                     // y-energy flux
    meq[12] = -2.0 * p[2];                                                                     // z-energy flux
    meq[13] = p[0];                                                                            // square of x-energy flux
    meq[14] = p[1];                                                                            // square of y-energy flux
    meq[15] = p[2];                                                                            // square of z-energy flux
    meq[16] = rho - 2.0 * (p[0] * p[0] + p[1] * p[1] + p[2] * p[2]) * rrho;                    // energy-squared
    meq[17] = -rho + (p[0] * p[0] + p[1] * p[1] + p[2] * p[2]) * rrho;                         // energy-cubed
    meq[18] = -(2.0 * p[0] * p[0] - p[1] * p[1] - p[2] * p[2]) * rrho;                         // diagonal (xx) fourth-order moment (3 pi_xx)
    meq[19] = -(p[1] * p[1] - p[2] * p[2]) * rrho;                                             // diagonal (yy/zz) fourth-order moment (pi_yy - pi_zz)
    meq[20] = -p[0] * p[1] * rrho;                                                             // off-diagonal (xy) fourth-order moment
    meq[21] = -p[1] * p[2] * rrho;                                                             // off-diagonal (yz) fourth-order moment
    meq[22] = -p[0] * p[2] * rrho;                                                             // off-diagonal (zx) fourth-order moment
    meq[23] = 0.0;                                                                             // symmetric (x) third-order moment
    meq[24] = 0.0;                                                                             // symmetric (y) third-order moment
    meq[25] = 0.0;                                                                             // symmetric (z) third-order moment
    meq[26] = 0.0;                                                                             // anti-symmetric (xyz) third-order moment
  }
  else if(lbdm.rank ==0) {
    cout << "the multiple-relaxation-time scheme for D" << lbsy.nd << "Q" << lbsy.nq << " model has not been defined" << endl;
    if(lbsy.nd == 2)
      cout << "the D2Q9 model can be used" << endl;
    else
      cout << "the D3Q15, D3Q19 or D3Q27 models can be used" << endl;
    exit(1);
  }  
  return 0;
}


int fGetMomentEquilibriumFSwiftOneFluid(double *meq, double *p, double rho, double pb, double lambda, double *grad)
{

  // calculate equilibrium moments of one fluid with Swift free-energy interactions for MRT collision schemes
  // (note: no Swift free-energy scheme currently exists for D3Q27)

  const double c1 = -7.0/3.0;
  const double c2 = -2.0/3.0;
  double drdx = grad[0];
  double drdy = grad[1];
  double drdz = grad[2];
  double nabr = grad[3];
  double rrho = fReciprocal(rho);
    
  if(lbsy.nq == 9) {
    // D2Q9 (Lallemand and Luo, 2000)
    meq[0] = rho;                                                                              // density
    meq[1] = -4.0*rho + 3.0*(p[0]*p[0]+p[1]*p[1])*rrho + 6.0*(pb-lbkappa*rho*nabr)
           + 15.0*lambda*(p[0]*drdx+p[1]*drdy)*rrho;                                           // energy
    meq[2] = 4.0*rho - 3.0*(p[0]*p[0]+p[1]*p[1])*rrho - 9.0*(pb-lbkappa*rho*nabr)
           - 1.5*lbkappa*(drdx*drdx+drdy*drdy) - 16.5*lambda*(p[0]*drdx+p[1]*drdy)*rrho;       // energy-squared
    meq[3] = p[0];                                                                             // x-momentum
    meq[4] = -p[0];                                                                            // x-energy flux
    meq[5] = p[1];                                                                             // y-momentum
    meq[6] = -p[1];                                                                            // y-energy flux
    meq[7] = (p[0]*p[0]-p[1]*p[1])*rrho + lbkappa*(drdx*drdx-drdy*drdy)
           + 2.0*lambda*(p[0]*drdx-p[1]*drdy)*rrho;                                            // diagonal (xx) stress tensor
    meq[8] = p[0]*p[1]*rrho + lbkappa*drdx*drdy + lambda*(p[0]*drdy+p[1]*drdx)*rrho;           // off-diagonal (xy) stress tensor
  }
  else if(lbsy.nq == 15) {
    // D3Q15 (d'Humieres et al., 2002)
    meq[0]  = rho;                                                                             // density
    meq[1]  = -2.0*rho + (p[0]*p[0]+p[1]*p[1]+p[2]*p[2])*rrho + 3.0*(pb-lbkappa*rho*nabr)
            - 0.5*lbkappa*(drdx*drdx+drdy*drdy+drdz*drdz)
            + 5.0*lambda*(p[0]*drdx+p[1]*drdy+p[2]*drdz)*rrho;                                 // energy
    meq[2]  = 16.0*rho - 5.0*(p[0]*p[0]+p[1]*p[1]+p[2]*p[2])*rrho - 45.0*(pb-lbkappa*rho*nabr)
            + 2.5*lbkappa*(drdx*drdx+drdy*drdy+drdz*drdz)
            - 85.0*lambda*(p[0]*drdx+p[1]*drdy+p[2]*drdz)*rrho;                                // energy-squared
    meq[3]  = p[0];                                                                            // x-momentum
    meq[4]  = c1*p[0];                                                                         // x-energy flux
    meq[5]  = p[1];                                                                            // y-momentum
    meq[6]  = c1*p[1];                                                                         // y-energy flux
    meq[7]  = p[2];                                                                            // z-momentum
    meq[8]  = c1*p[2];                                                                         // z-energy flux
    meq[9]  = (2.0*p[0]*p[0]-p[1]*p[1]-p[2]*p[2])*rrho
            + lbkappa*(2.0*drdx*drdx-drdy*drdy-drdz*drdz)
            + 2.0*lambda*(2.0*p[0]*drdx-p[1]*drdy-p[2]*drdz)*rrho;                             // diagonal (xx) stress tensor (3p_xx)
    meq[10] = (p[1]*p[1]-p[2]*p[2])*rrho + lbkappa*(drdy*drdy-drdz*drdz)
            + 2.0*lambda*(p[1]*drdy-p[2]*drdz)*rrho;                                           // diagonal (yy/zz) stress tensor (p_yy - p_zz)
    meq[11] = p[0]*p[1]*rrho + lbkappa*drdx*drdy + lambda*(p[0]*drdy+p[1]*drdx)*rrho;          // off-diagonal (xy) stress tensor
    meq[12] = p[1]*p[2]*rrho + lbkappa*drdy*drdz + lambda*(p[1]*drdz+p[2]*drdy)*rrho;          // off-diagonal (yz) stress tensor
    meq[13] = p[0]*p[2]*rrho + lbkappa*drdx*drdz + lambda*(p[0]*drdz+p[2]*drdx)*rrho;          // off-diagonal (zx) stress tensor
    meq[14] = 0.0;                                                                             // antisymmetric (xyz) third-order moment
  }
  else if(lbsy.nq == 19) {
    // D3Q19 (d'Humieres et al., 2002)
    meq[0]  = rho;                                                                             // density
    meq[1]  = -30.0*rho + 19.0*(p[0]*p[0]+p[1]*p[1]+p[2]*p[2])*rrho
            + 57.0*(pb-lbkappa*rho*nabr) - 9.5*lbkappa*(drdx*drdx+drdy*drdy+drdz*drdz)
            + 152.0*lambda*(p[0]*drdx+p[1]*drdy+p[2]*drdz)*rrho;                               // energy
    meq[2]  = 12.0*rho - 5.5*(p[0]*p[0]+p[1]*p[1]+p[2]*p[2])*rrho - 27.0*(pb-lbkappa*rho*nabr)
            + 8.0*lbkappa*(drdx*drdx+drdy*drdy+drdz*drdz)
            - 54.5*lambda*(p[0]*drdx+p[1]*drdy+p[2]*drdz)*rrho;                                // energy-squared
    meq[3]  = p[0];                                                                            // x-momentum
    meq[4]  = c2*p[0];                                                                         // x-energy flux
    meq[5]  = p[1];                                                                            // y-momentum
    meq[6]  = c2*p[1];                                                                         // y-energy flux
    meq[7]  = p[2];                                                                            // z-momentum
    meq[8]  = c2*p[2];                                                                         // z-energy flux
    meq[9]  = (2.0*p[0]*p[0]-p[1]*p[1]-p[2]*p[2])*rrho
            + lbkappa*(2.0*drdx*drdx-drdy*drdy-drdz*drdz)
            + 2.0*lambda*(2.0*p[0]*drdx-p[1]*drdy-p[2]*drdz)*rrho;                             // diagonal (xx) stress tensor (3p_xx)
    meq[10] = -0.5*(2.0*p[0]*p[0]-p[1]*p[1]-p[2]*p[2])*rrho
            - 3.5*lbkappa*(2.0*drdx*drdx-drdy*drdy-drdz*drdz)
            - lambda*(2.0*p[0]*drdx-p[1]*drdy-p[2]*drdz)*rrho;                                 // diagonal (xx) fourth-order moment (3 pi_xx)
    meq[11] = (p[1]*p[1]-p[2]*p[2])*rrho + lbkappa*(drdy*drdy-drdz*drdz)
            + 2.0*lambda*(p[1]*drdy-p[2]*drdz)*rrho;                                           // diagonal (yy/zz) stress tensor (p_yy - p_zz)
    meq[12] = -0.5*(p[1]*p[1]-p[2]*p[2])*rrho - 3.5*lbkappa*(drdy*drdy-drdz*drdz)
            - lambda*(p[1]*drdy-p[2]*drdz)*rrho;                                               // diagonal (yy/zz) fourth-order moment (pi_yy - pi_zz)
    meq[13] = p[0]*p[1]*rrho + lbkappa*drdx*drdy + lambda*(p[0]*drdy+p[1]*drdx)*rrho;          // off-diagonal (xy) stress tensor
    meq[14] = p[1]*p[2]*rrho + lbkappa*drdy*drdz + lambda*(p[1]*drdz+p[2]*drdy)*rrho;          // off-diagonal (yz) stress tensor
    meq[15] = p[0]*p[2]*rrho + lbkappa*drdx*drdz + lambda*(p[0]*drdz+p[2]*drdx)*rrho;          // off-diagonal (zx) stress tensor
    meq[16] = 0.0;                                                                             // symmetric (x) third-order moment
    meq[17] = 0.0;                                                                             // symmetric (y) third-order moment
    meq[18] = 0.0;                                                                             // symmetric (z) third-order moment
  }
  else if(lbdm.rank ==0) {
    cout << "the multiple-relaxation-time scheme for D" << lbsy.nd << "Q" << lbsy.nq << " model has not been defined" << endl;
    if(lbsy.nd == 2)
      cout << "the D2Q9 model can be used" << endl;
    else
      cout << "the D3Q15 or D3Q19 models can be used" << endl;
    exit(1);
  }  
  return 0;
}

int fGetMomentEquilibriumFSwiftTwoFluid(double *meq, double *p, double rho, double phi, double pb, double mu, double lambda, double *grad)
{

  // calculate equilibrium moments of one fluid with Swift free-energy interactions for MRT collision schemes
  // (note: no Swift free-energy scheme currently exists for D3Q27)

  const double c1 = -7.0/3.0;
  const double c2 = -2.0/3.0;
  double drdx = (lbfeeos>0)?grad[0]:0.0;
  double drdy = (lbfeeos>0)?grad[1]:0.0;
  double drdz = (lbfeeos>0)?grad[2]:0.0;
  double nabr = (lbfeeos>0)?grad[3]:0.0;
  double dpdx = grad[4];
  double dpdy = grad[5];
  double dpdz = grad[6];
  double nabp = grad[7];
  double modv, uv;
  double v[3];
  double rrho = fReciprocal(rho);

  if(lbsy.nq == 9) {
    // D2Q9 (Lallemand and Luo, 2000)
    meq[0] = rho;                                                                              // density
    meq[1] = -4.0*rho + 3.0*(p[0]*p[0]+p[1]*p[1])*rrho + 6.0*(pb-lbkappa*(rho*nabr+phi*nabp))
           + 15.0*lambda*(p[0]*drdx+p[1]*drdy)*rrho;                                           // energy
    meq[2] = 4.0*rho - 3.0*(p[0]*p[0]+p[1]*p[1])*rrho - 9.0*(pb-lbkappa*(rho*nabr+phi*nabp))
           - 1.5*lbkappa*(drdx*drdx+drdy*drdy+dpdx*dpdx+dpdy*dpdy)
           - 16.5*lambda*(p[0]*drdx+p[1]*drdy)*rrho;                                           // energy-squared
    meq[3] = p[0];                                                                             // x-momentum
    meq[4] = -p[0];                                                                            // x-energy flux
    meq[5] = p[1];                                                                             // y-momentum
    meq[6] = -p[1];                                                                            // y-energy flux
    meq[7] = (p[0]*p[0]-p[1]*p[1])*rrho + lbkappa*(drdx*drdx+dpdx*dpdx-drdy*drdy-dpdy*dpdy)
           + 2.0*lambda*(p[0]*drdx-p[1]*drdy)*rrho;                                            // diagonal (xx) stress tensor
    meq[8] = p[0]*p[1]*rrho + lbkappa*(drdx*drdy+dpdx*dpdy)
           + lambda*(p[0]*drdy+p[1]*drdx)*rrho;                                                // off-diagonal (xy) stress tensor
  }
  else if(lbsy.nq == 15) {
    // D3Q15 (d'Humieres et al., 2002)
    meq[0]  = rho;                                                                             // density
    meq[1]  = -2.0*rho + (p[0]*p[0]+p[1]*p[1]+p[2]*p[2])*rrho
            + 3.0*(pb-lbkappa*(rho*nabr+phi*nabp))
            - 0.5*lbkappa*(drdx*drdx+drdy*drdy+drdz*drdz+dpdx*dpdx+dpdy*dpdy+dpdz*dpdz)
            + 5.0*lambda*(p[0]*drdx+p[1]*drdy+p[2]*drdz)*rrho;                                 // energy
    meq[2]  = 16.0*rho - 5.0*(p[0]*p[0]+p[1]*p[1]+p[2]*p[2])*rrho
            - 45.0*(pb-lbkappa*(rho*nabr+phi*nabp))
            + 2.5*lbkappa*(drdx*drdx+drdy*drdy+drdz*drdz+dpdx*dpdx+dpdy*dpdy+dpdz*dpdz)
            - 85.0*lambda*(p[0]*drdx+p[1]*drdy+p[2]*drdz)*rrho;                                // energy-squared
    meq[3]  = p[0];                                                                            // x-momentum
    meq[4]  = c1*p[0];                                                                         // x-energy flux
    meq[5]  = p[1];                                                                            // y-momentum
    meq[6]  = c1*p[1];                                                                         // y-energy flux
    meq[7]  = p[2];                                                                            // z-momentum
    meq[8]  = c1*p[2];                                                                         // z-energy flux
    meq[9]  = (2.0*p[0]*p[0]-p[1]*p[1]-p[2]*p[2])*rrho
            + lbkappa*(2.0*(drdx*drdx+dpdx*dpdx)-drdy*drdy-dpdy*dpdy-drdz*drdz-dpdz*dpdz)
            + 2.0*lambda*(2.0*p[0]*drdx-p[1]*drdy-p[2]*drdz)*rrho;                             // diagonal (xx) stress tensor (3p_xx)
    meq[10] = (p[1]*p[1]-p[2]*p[2])/rho + lbkappa*(drdy*drdy+dpdy*dpdy-drdz*drdz-dpdz*dpdz)
            + 2.0*lambda*(p[1]*drdy-p[2]*drdz)*rrho;                                           // diagonal (yy/zz) stress tensor (p_yy - p_zz)
    meq[11] = p[0]*p[1]/rho + lbkappa*(drdx*drdy+dpdx*dpdy)
            + lambda*(p[0]*drdy+p[1]*drdx)*rrho;                                               // off-diagonal (xy) stress tensor
    meq[12] = p[1]*p[2]/rho + lbkappa*(drdy*drdz+dpdy*dpdz)
            + lambda*(p[1]*drdz+p[2]*drdy)*rrho;                                               // off-diagonal (yz) stress tensor
    meq[13] = p[0]*p[2]/rho + lbkappa*(drdx*drdz+dpdx*dpdz)
            + lambda*(p[0]*drdz+p[2]*drdx)*rrho;                                               // off-diagonal (zx) stress tensor
    meq[14] = 0.0;                                                                             // antisymmetric (xyz) third-order moment
  }
  else if(lbsy.nq == 19) {
    // D3Q19 (d'Humieres et al., 2002)
    meq[0]  = rho;                                                                             // density
    meq[1]  = -30.0*rho + 19.0*(p[0]*p[0]+p[1]*p[1]+p[2]*p[2])*rrho
            + 57.0*(pb-lbkappa*(rho*nabr+phi*nabp))
            - 9.5*lbkappa*(drdx*drdx+drdy*drdy+drdz*drdz+dpdx*dpdx+dpdy*dpdy+dpdz*dpdz)
            + 152.0*lambda*(p[0]*drdx+p[1]*drdy+p[2]*drdz)*rrho;                               // energy
    meq[2]  = 12.0*rho - 5.5*(p[0]*p[0]+p[1]*p[1]+p[2]*p[2])*rrho
            - 27.0*(pb-lbkappa*(rho*nabr+phi*nabp))
            + 8.0*lbkappa*(drdx*drdx+drdy*drdy+drdz*drdz+dpdx*dpdx+dpdy*dpdy+dpdz*dpdz)
            - 54.5*lambda*(p[0]*drdx+p[1]*drdy+p[2]*drdz)*rrho;                                // energy-squared
    meq[3]  = p[0];                                                                            // x-momentum
    meq[4]  = c2*p[0];                                                                         // x-energy flux
    meq[5]  = p[1];                                                                            // y-momentum
    meq[6]  = c2*p[1];                                                                         // y-energy flux
    meq[7]  = p[2];                                                                            // z-momentum
    meq[8]  = c2*p[2];                                                                         // z-energy flux
    meq[9]  = (2.0*p[0]*p[0]-p[1]*p[1]-p[2]*p[2])*rrho
            + lbkappa*(2.0*(drdx*drdx+dpdx*dpdx)-drdy*drdy-dpdy*dpdy-drdz*drdz-dpdz*dpdz)
            + 2.0*lambda*(2.0*p[0]*drdx-p[1]*drdy-p[2]*drdz)*rrho;                             // diagonal (xx) stress tensor (3p_xx)
    meq[10] = -0.5*(2.0*p[0]*p[0]-p[1]*p[1]-p[2]*p[2])*rrho
            - 3.5*lbkappa*(2.0*(drdx*drdx+dpdx*dpdx)-drdy*drdy-dpdy*dpdy-drdz*drdz-dpdz*dpdz)
            - lambda*(2.0*p[0]*drdx-p[1]*drdy-p[2]*drdz)*rrho;                                 // diagonal (xx) fourth-order moment (3 pi_xx)
    meq[11] = (p[1]*p[1]-p[2]*p[2])*rrho + lbkappa*(drdy*drdy+dpdy*dpdy-drdz*drdz-dpdz*dpdz)
            + 2.0*lambda*(p[1]*drdy-p[2]*drdz)*rrho;                                           // diagonal (yy/zz) stress tensor (p_yy - p_zz)
    meq[12] = -0.5*(p[1]*p[1]-p[2]*p[2])*rrho
            - 3.5*lbkappa*(drdy*drdy+dpdy*dpdy-drdz*drdz-dpdz*dpdz)
            - lambda*(p[1]*drdy-p[2]*drdz)*rrho;                                               // diagonal (yy/zz) fourth-order moment (pi_yy - pi_zz)
    meq[13] = p[0]*p[1]/rho + lbkappa*(drdx*drdy+dpdx*dpdy)
            + lambda*(p[0]*drdy+p[1]*drdx)*rrho;                                               // off-diagonal (xy) stress tensor
    meq[14] = p[1]*p[2]/rho + lbkappa*(drdy*drdz+dpdy*dpdz)
            + lambda*(p[1]*drdz+p[2]*drdy)*rrho;                                               // off-diagonal (yz) stress tensor
    meq[15] = p[0]*p[2]/rho + lbkappa*(drdx*drdz+dpdx*dpdz)
            + lambda*(p[0]*drdz+p[2]*drdx)*rrho;                                               // off-diagonal (zx) stress tensor
    meq[16] = 0.0;                                                                             // symmetric (x) third-order moment
    meq[17] = 0.0;                                                                             // symmetric (y) third-order moment
    meq[18] = 0.0;                                                                             // symmetric (z) third-order moment
  }
  else if(lbdm.rank ==0) {
    cout << "the multiple-relaxation-time scheme for D" << lbsy.nd << "Q" << lbsy.nq << " model has not been defined" << endl;
    if(lbsy.nd == 2)
      cout << "the D2Q9 model can be used" << endl;
    else
      cout << "the D3Q15 or D3Q19 models can be used" << endl;
    exit(1);
  }
  v[0] = p[0]*rrho; v[1] = p[1]*rrho; v[2] = p[2]*rrho;
  modv = v[0]*v[0] + v[1]*v[1] + v[2]*v[2];
  for(int i=0; i<lbsy.nq; i++) {
    uv = lbvx[i] * v[0] + lbvy[i] * v[1] + lbvz[i] * v[2];
    meq[lbsy.nq+i] = lbfemob * mu * lbwpt[i] + lbw0[i] * phi + lbw[i] * phi * (uv + 1.5 * uv * uv - 0.5 * modv);
  }
  return 0;
}


int fGetMomentForceGuo(double *source, double *v, double *force)
{

  // calculate forcing terms in terms of moments for MRT collision schemes
  // (Premnath and Abraham, 2007)

  const double c1 = -7.0/3.0;
  const double c2 = -2.0/3.0;
    
  if(lbsy.nq == 9) {
    // D2Q9
    source[0] = 0.0;
    source[1] = 6.0 * (v[0] * force[0] + v[1] * force[1]);
    source[2] = -6.0 * (v[0] * force[0] + v[1] * force[1]);
    source[3] = force[0];
    source[4] = -force[0];
    source[5] = force[1];
    source[6] = -force[1];
    source[7] = 2.0 * (v[0] * force[0] - v[1] * force[1]);
    source[8] = v[0] * force[1] + v[1] * force[0];
  }
  else if(lbsy.nq == 15) {
    // D3Q15
    source[0]  = 0.0;
    source[1]  = 2.0 * (v[0] * force[0] + v[1] * force[1] + v[2] * force[2]);
    source[2]  = -10.0 * (v[0] * force[0] + v[1] * force[1] + v[2] * force[2]);
    source[3]  = force[0];
    source[4]  = c1 * force[0];
    source[5]  = force[1];
    source[6]  = c1 * force[1];
    source[7]  = force[2];
    source[8]  = c1 * force[2];
    source[9]  = 2.0 * (2.0 * v[0] * force[0] - v[1] * force[1] - v[2] * force[2]);
    source[10] = 2.0 * (v[1] * force[1] - v[2] * force[2]);
    source[11] = v[0] * force[1] + v[1] * force[0];
    source[12] = v[1] * force[2] + v[2] * force[1];
    source[13] = v[0] * force[2] + v[2] * force[0];
    source[14] = 0.0;
  }
  else if(lbsy.nq == 19) {
    // D3Q19
    source[0]  = 0.0;
    source[1]  = 38.0 * (v[0] * force[0] + v[1] * force[1] + v[2] * force[2]);
    source[2]  = -11.0 * (v[0] * force[0] + v[1] * force[1] + v[2] * force[2]);
    source[3]  = force[0];
    source[4]  = c2 * force[0];
    source[5]  = force[1];
    source[6]  = c2 * force[1];
    source[7]  = force[2];
    source[8]  = c2 * force[2];
    source[9]  = 2.0 * (2.0 * v[0] * force[0] - v[1] * force[1] - v[2] * force[2]);
    source[10] = -(2.0 * v[0] * force[0] - v[1] * force[1] - v[2] * force[2]);
    source[11] = 2.0 * (v[1] * force[1] - v[2] * force[2]);
    source[12] = -(v[1] * force[1] - v[2] * force[2]);
    source[13] = v[0] * force[1] + v[1] * force[0];
    source[14] = v[1] * force[2] + v[2] * force[1];
    source[15] = v[0] * force[2] + v[2] * force[0];
    source[16] = 0.0;
    source[17] = 0.0;
    source[18] = 0.0;
  }
  else if(lbsy.nq == 27) {
    source[0]  = 0.0;
    source[1]  = force[0];
    source[2]  = force[1];
    source[3]  = force[2];
    source[4]  = 2.0 * (v[0] * force[0] + v[1] * force[1] + v[2] * force[2]);
    source[5]  = 2.0 * (2.0 * v[0] * force[0] - v[1] * force[1] - v[2] * force[2]);
    source[6]  = 2.0 * (v[1] * force[1] - v[2] * force[2]);
    source[7]  = v[1] * force[0] + v[0] * force[1];
    source[8]  = v[2] * force[1] + v[1] * force[2];
    source[9]  = v[0] * force[2] + v[2] * force[0];
    source[10] = -2.0 * force[0];
    source[11] = -2.0 * force[1];
    source[12] = -2.0 * force[2];
    source[13] = force[0];
    source[14] = force[1];
    source[15] = force[2];
    source[16] = -4.0 * (v[0] * force[0] + v[1] * force[1] + v[2] * force[2]);
    source[17] = 6.0 * (v[0] * force[0] + v[1] * force[1] + v[2] * force[2]);
    source[18] = -2.0 * (2.0 * v[0] * force[0] - v[1] * force[1] - v[2] * force[2]);
    source[19] = -2.0 * (v[1] * force[1] - v[2] * force[2]);
    source[20] = -(v[1] * force[0] + v[0] * force[1]);
    source[21] = -(v[2] * force[1] + v[1] * force[2]);
    source[22] = -(v[0] * force[2] + v[2] * force[0]);
    source[23] = 0.0;
    source[24] = 0.0;
    source[25] = 0.0;
    source[26] = 0.0;
  }
  else if(lbdm.rank ==0) {
    cout << "the multiple-relaxation-time scheme for D" << lbsy.nd << "Q" << lbsy.nq << " model has not been defined" << endl;
    if(lbsy.nd == 2)
      cout << "the D2Q9 model can be used" << endl;
    else
      cout << "the D3Q15 or D3Q19 models can be used" << endl;
    exit(1);
  }  
  return 0;
}


int fGetMomentForceHe(double *source, double *v, double *force)
{

  // calculate forcing terms in terms of moments for MRT collision schemes
  // (Premnath and Abraham, 2007)

  const double c2 = -2.0/3.0;

  double v0v0 = v[0] * v[0];
  double v1v1 = v[1] * v[1];
  double v2v2 = v[2] * v[2];
  double v0v1 = v[0] * v[1];
  double v0v2 = v[0] * v[2];
  double v1v2 = v[1] * v[2];
    
  if(lbsy.nq == 9) {
    // D2Q9
    source[0] = 0.0;
    source[1] = 6.0 * (v[0] * force[0] + v[1] * force[1]);
    source[2] = -6.0 * (v[0] * force[0] + v[1] * force[1]);
    source[3] = force[0];
    source[4] = -force[0] * (1.0 - 3.0 * v1v1) + 6.0 * v0v1 * force[1];
    source[5] = force[1];
    source[6] = -force[1] * (1.0 - 3.0 * v0v0) + 6.0 * v0v1 * force[0];
    source[7] = 2.0 * (v[0] * force[0] - v[1] * force[1]);
    source[8] = v[0] * force[1] + v[1] * force[0];
  }
  else if(lbsy.nq == 15) {
    // D3Q15
    source[0]  = 0.0;
    source[1]  = 2.0 * (v[0] * force[0] + v[1] * force[1] + v[2] * force[2]);
    source[2]  = -10.0 * (v[0] * force[0] + v[1] * force[1] + v[2] * force[2]);
    source[3]  = force[0];
    source[4]  = force[0] * (c2 + 5.0 * (v1v1 + v2v2)) + 10.0 * (v0v1 * force[1] + v0v2 * force[2]);
    source[5]  = force[1];
    source[6]  = force[1] * (c2 + 5.0 * (v0v0 + v2v2)) + 10.0 * (v0v1 * force[0] + v1v2 * force[2]);
    source[7]  = force[2];
    source[8]  = force[2] * (c2 + 5.0 * (v0v0 + v1v1)) + 10.0 * (v0v2 * force[0] + v1v2 * force[1]);
    source[9]  = 2.0 * (2.0 * v[0] * force[0] - v[1] * force[1] - v[2] * force[2]);
    source[10] = 2.0 * (v[1] * force[1] - v[2] * force[2]);
    source[11] = v[0] * force[1] + v[1] * force[0];
    source[12] = v[1] * force[2] + v[2] * force[1];
    source[13] = v[0] * force[2] + v[2] * force[0];
    source[14] = 3.0 * (v1v2 * force[0] + v0v2 * force[1] + v0v1 * force[2]);
  }
  else if(lbsy.nq == 19) {
    // D3Q19
    source[0]  = 0.0;
    source[1]  = 38.0 * (v[0] * force[0] + v[1] * force[1] + v[2] * force[2]);
    source[2]  = -11.0 * (v[0] * force[0] + v[1] * force[1] + v[2] * force[2]);
    source[3]  = force[0];
    source[4]  = force[0] * (c2 + 2.5 * (v1v1 + v2v2)) + 5.0 * (v0v1 * force[1] + v0v2 * force[2]);
    source[5]  = force[1];
    source[6]  = force[1] * (c2 + 2.5 * (v0v0 + v2v2)) + 5.0 * (v0v1 * force[0] + v1v2 * force[2]);
    source[7]  = force[2];
    source[8]  = force[2] * (c2 + 2.5 * (v0v0 + v1v1)) + 5.0 * (v0v2 * force[0] + v1v2 * force[1]);
    source[9]  = 2.0 * (2.0 * v[0] * force[0] - v[1] * force[1] - v[2] * force[2]);
    source[10] = -(2.0 * v[0] * force[0] - v[1] * force[1] - v[2] * force[2]);
    source[11] = 2.0 * (v[1] * force[1] - v[2] * force[2]);
    source[12] = -(v[1] * force[1] - v[2] * force[2]);
    source[13] = v[0] * force[1] + v[1] * force[0];
    source[14] = v[1] * force[2] + v[2] * force[1];
    source[15] = v[0] * force[2] + v[2] * force[0];
    source[16] = 1.5 * (v1v1 - v2v2) * force[0] + 3.0 * (v0v1 * force[1] - v0v2 * force[2]);
    source[17] = 1.5 * (v2v2 - v0v0) * force[1] + 3.0 * (v1v2 * force[2] - v0v1 * force[0]);
    source[18] = 1.5 * (v0v0 - v1v1) * force[2] + 3.0 * (v0v2 * force[0] - v1v2 * force[1]);
  }
  else if(lbsy.nq == 27) {
    source[0]  = 0.0;
    source[1]  = force[0];
    source[2]  = force[1];
    source[3]  = force[2];
    source[4]  = 2.0 * (v[0] * force[0] + v[1] * force[1] + v[2] * force[2]);
    source[5]  = 2.0 * (2.0 * v[0] * force[0] - v[1] * force[1] - v[2] * force[2]);
    source[6]  = 2.0 * (v[1] * force[1] - v[2] * force[2]);
    source[7]  = v[1] * force[0] + v[0] * force[1];
    source[8]  = v[2] * force[1] + v[1] * force[2];
    source[9]  = v[0] * force[2] + v[2] * force[0];
    source[10] = force[0] * (-2.0 + 3.0 * (v1v1 + v2v2)) + 6.0 * (v0v1 * force[1] + v0v2 * force[2]);
    source[11] = force[1] * (-2.0 + 3.0 * (v0v0 + v2v2)) + 6.0 * (v0v1 * force[0] + v1v2 * force[2]);
    source[12] = force[2] * (-2.0 + 3.0 * (v0v0 + v1v1)) + 6.0 * (v0v2 * force[0] + v1v2 * force[1]);
    source[13] = force[0] * (1.0 - 3.0 * (v1v1 + v2v2)) - 6.0 * (v0v1 * force[1] + v0v2 * force[2]);
    source[14] = force[1] * (1.0 - 3.0 * (v0v0 + v2v2)) - 6.0 * (v0v1 * force[0] + v1v2 * force[2]);
    source[15] = force[2] * (1.0 - 3.0 * (v0v0 + v1v1)) - 6.0 * (v0v2 * force[0] + v1v2 * force[1]);
    source[16] = -4.0 * (v[0] * force[0] + v[1] * force[1] + v[2] * force[2]);
    source[17] = 6.0 * (v[0] * force[0] + v[1] * force[1] + v[2] * force[2]);
    source[18] = -2.0 * (2.0 * v[0] * force[0] - v[1] * force[1] - v[2] * force[2]);
    source[19] = -2.0 * (v[1] * force[1] - v[2] * force[2]);
    source[20] = -(v[1] * force[0] + v[0] * force[1]);
    source[21] = -(v[2] * force[1] + v[1] * force[2]);
    source[22] = -(v[0] * force[2] + v[2] * force[0]);
    source[23] = (v1v1 - v2v2) * force[0] + 2.0 * (v0v1 * force[1] - v0v2 * force[2]);
    source[24] = (v2v2 - v0v0) * force[1] + 2.0 * (v1v2 * force[2] - v0v1 * force[0]);
    source[25] = (v0v0 - v1v1) * force[2] + 2.0 * (v0v2 * force[0] - v1v2 * force[1]);
    source[26] = v1v2 * force[0] + v0v2 * force[1] + v0v1 * force[2];
  }
  else if(lbdm.rank ==0) {
    cout << "the multiple-relaxation-time scheme for D" << lbsy.nd << "Q" << lbsy.nq << " model has not been defined" << endl;
    if(lbsy.nd == 2)
      cout << "the D2Q9 model can be used" << endl;
    else
      cout << "the D3Q15 or D3Q19 models can be used" << endl;
    exit(1);
  }
  return 0;
}


int fGetMRTCollide(double *collide, double omegashear, double omegabulk)
{

  // calculate collision parameters for MRT collision schemes:
  // tuneable parameters (lbmrts) can be modified by user if required

  if(lbsy.nq == 9) {
    // D2Q9
    collide[0] = 1.0;         // fixed parameter for conserved moment (density)
    collide[1] = omegabulk;
    collide[2] = lbmrts[0];
    collide[3] = 1.0;         // fixed parameter for conserved moment (x-momentum)
    collide[4] = lbmrts[1];
    collide[5] = 1.0;         // fixed parameter for conserved moment (y-momentum)
    collide[6] = lbmrts[1];
    collide[7] = omegashear;
    collide[8] = omegashear;
  }
  else if(lbsy.nq == 15) {
    // D3Q15
    collide[0]  = 1.0;        // fixed parameter for conserved moment (density)
    collide[1]  = omegabulk;
    collide[2]  = lbmrts[0];
    collide[3]  = 1.0;        // fixed parameter for conserved moment (x-momentum)
    collide[4]  = lbmrts[1];
    collide[5]  = 1.0;        // fixed parameter for conserved moment (y-momentum)
    collide[6]  = lbmrts[1];
    collide[7]  = 1.0;        // fixed parameter for conserved moment (z-momentum)
    collide[8]  = lbmrts[1];
    collide[9]  = omegashear;
    collide[10] = omegashear;
    collide[11] = omegashear;
    collide[12] = omegashear;
    collide[13] = omegashear;
    collide[14] = lbmrts[2];
  }
  else if(lbsy.nq == 19) {
    // D3Q19
    collide[0]  = 1.0;        // fixed parameter for conserved moment (density)
    collide[1]  = omegabulk;
    collide[2]  = lbmrts[0];
    collide[3]  = 1.0;        // fixed parameter for conserved moment (x-momentum)
    collide[4]  = lbmrts[1];
    collide[5]  = 1.0;        // fixed parameter for conserved moment (y-momentum)
    collide[6]  = lbmrts[1];
    collide[7]  = 1.0;        // fixed parameter for conserved moment (z-momentum)
    collide[8]  = lbmrts[1];
    collide[9]  = omegashear;
    collide[10] = lbmrts[0];
    collide[11] = omegashear;
    collide[12] = lbmrts[0];
    collide[13] = omegashear;
    collide[14] = omegashear;
    collide[15] = omegashear;
    collide[16] = lbmrts[2];
    collide[17] = lbmrts[2];
    collide[18] = lbmrts[2];
  }
  else if(lbsy.nq == 27) {
    // D3Q27
    collide[0]  = 1.0;        // fixed parameter for conserved moment (density)
    collide[1]  = 1.0;        // fixed parameter for conserved moment (x-momentum)
    collide[2]  = 1.0;        // fixed parameter for conserved moment (y-momentum)
    collide[3]  = 1.0;        // fixed parameter for conserved moment (z-momentum)
    collide[4]  = omegabulk;
    collide[5]  = omegashear;
    collide[6]  = omegashear;
    collide[7]  = omegashear;
    collide[8]  = omegashear;
    collide[9]  = omegashear;
    collide[10] = lbmrts[0];
    collide[11] = lbmrts[0];
    collide[12] = lbmrts[0];
    collide[13] = lbmrts[1];
    collide[14] = lbmrts[1];
    collide[15] = lbmrts[1];
    collide[16] = lbmrts[2];
    collide[17] = lbmrts[3];
    collide[18] = lbmrts[4];
    collide[19] = lbmrts[4];
    collide[20] = lbmrts[5];
    collide[21] = lbmrts[5];
    collide[22] = lbmrts[5];
    collide[23] = lbmrts[6];
    collide[24] = lbmrts[6];
    collide[25] = lbmrts[6];
    collide[26] = lbmrts[7];
}
  else if(lbdm.rank ==0) {
    cout << "the multiple-relaxation-time scheme for D" << lbsy.nd << "Q" << lbsy.nq << " model has not been defined" << endl;
    if(lbsy.nd == 2)
      cout << "the D2Q9 model can be used" << endl;
    else
      cout << "the D3Q15, D3Q19 or D3Q27 models can be used" << endl;
    exit(1);
  }  
  return 0;
}

// Standard fluid collisions

int fSiteFluidCollisionMRT(double* startpos, double *sitespeed, double *omega, double *omegabulk, double *rho, double* bodyforce)
{
  
  // calculate fluid collisions at grid point: uses MRT schemes

  double speed[3], meq[lbsy.nq];
  double moment[lbsy.nq], collide[lbsy.nq];
  double relax;
  double *pt2 = &startpos[0];
  double *pt3 = &bodyforce[0];
  int qdim = lbsy.nf+lbsy.nc+lbsy.nt;

  for(int k=0; k<lbsy.nf; k++) {
    relax = fReciprocal(omega[k]);
    speed[0] = rho[k] * sitespeed[0] + pt3[3*k]   * relax;
    speed[1] = rho[k] * sitespeed[1] + pt3[3*k+1] * relax;
    speed[2] = rho[k] * sitespeed[2] + pt3[3*k+2] * relax;
    fGetMomentEquilibriumF(&meq[0], speed, rho[k]);
    fGetMRTCollide(collide, omega[k], omegabulk[k]);
    for(int i=0; i<lbsy.nq; i++) {
      moment[i] = 0.0;
      for(int j=0; j<lbsy.nq; j++) {
        moment[i] += pt2[j*qdim+k] * lbtr[i*lbsy.nq+j];
      }
      moment[i] = collide[i] * (meq[i] - moment[i]);
    }
    for(int i=0; i<lbsy.nq; i++) {
      for(int j=0; j<lbsy.nq; j++) {
        pt2[i*qdim+k] += moment[j] * lbtrinv[i*lbsy.nq+j];
      }
    }
  }

  pt2 = NULL;
  pt3 = NULL;  
  return 0;
}

int fSiteFluidIncomCollisionMRT(double* startpos, double *sitespeed, double *omega, double *omegabulk, double *rho, double* bodyforce)
{
  
  // calculate fluid collisions at grid point: uses MRT schemes for incompressible fluids

  double speed[3], meq[lbsy.nq];
  double moment[lbsy.nq], collide[lbsy.nq];
  double density, relax;
  double *pt2 = &startpos[0];
  double *pt3 = &bodyforce[0];
  int qdim = lbsy.nf+lbsy.nc+lbsy.nt;

  for(int k=0; k<lbsy.nf; k++) {
    density = lbincp[k];
    relax = fReciprocal(omega[k]);
    speed[0] = density * sitespeed[0] + pt3[3*k]   * relax;
    speed[1] = density * sitespeed[1] + pt3[3*k+1] * relax;
    speed[2] = density * sitespeed[2] + pt3[3*k+2] * relax;
    fGetMomentEquilibriumFIncom(&meq[0], speed, rho[k], density);
    fGetMRTCollide(collide, omega[k], omegabulk[k]);
    for(int i=0; i<lbsy.nq; i++) {
      moment[i] = 0;
      for(int j=0; j<lbsy.nq; j++) {
        moment[i] += pt2[j*qdim+k] * lbtr[i*lbsy.nq+j];
      }
      moment[i] = collide[i] * (meq[i] - moment[i]);
    }
    for(int i=0; i<lbsy.nq; i++) {
      for(int j=0; j<lbsy.nq; j++) {
        pt2[i*qdim+k] += moment[j] * lbtrinv[i*lbsy.nq+j];
      }
    }
  }

  pt2 = NULL;
  pt3 = NULL;  
  return 0;
}

int fSiteFluidCollisionMRTEDM(double* startpos, double *sitespeed, double *omega, double *omegabulk, double *rho, double* bodyforce)
{
  
  // calculate fluid collisions at grid point: uses MRT schemes with
  // Exact Difference Method forcing term

  double dv[3], meq[lbsy.nq], moment[lbsy.nq], collide[lbsy.nq];
  double invmass, source;
  double modv,eixux,eiyuy,eizuz,eixdux,eiyduy,eizduz;
  double *pt2 = &startpos[0];
  double *pt3 = &bodyforce[0];
  int qdim = lbsy.nf+lbsy.nc+lbsy.nt;

  for(int k=0; k<lbsy.nf; k++) {
    invmass = fReciprocal(rho[k]);
    dv[0] = pt3[3*k]   * invmass;
    dv[1] = pt3[3*k+1] * invmass;
    dv[2] = pt3[3*k+2] * invmass;
    fGetMomentEquilibriumF(&meq[0], sitespeed, rho[k]);
    fGetMRTCollide(collide, omega[k], omegabulk[k]);
    modv = dv[0]*(2.0*sitespeed[0]+dv[0]) + dv[1]*(2.0*sitespeed[1]+dv[1]) + dv[2]*(2.0*sitespeed[2]+dv[2]);
    for(int i=0; i<lbsy.nq; i++) {
      moment[i] = 0;
      for(int j=0; j<lbsy.nq; j++) {
        moment[i] += pt2[j*qdim+k] * lbtr[i*lbsy.nq+j];
      }
      moment[i] = collide[i] * (meq[i] - moment[i]);
    }
    for(int i=0; i<lbsy.nq; i++) {
      eixux =  lbvx[i]*sitespeed[0];
      eiyuy =  lbvy[i]*sitespeed[1];
      eizuz =  lbvz[i]*sitespeed[2];
      eixdux = lbvx[i]*dv[0];
      eiyduy = lbvy[i]*dv[1];
      eizduz = lbvz[i]*dv[2];
      source = rho[k] * lbw[i] * (3.0 * (eixdux+eiyduy+eizduz) +
                                  4.5 * (eixdux*(eixdux+2.0*(eixux+eiyuy+eizuz+eiyduy+eizduz)) +
                                         eiyduy*(eiyduy+2.0*(eixux+eiyuy+eizuz+eizduz)) +
                                         eizduz*(eizduz+2.0*(eixux+eiyuy+eizuz))) -
                                  1.5 * modv);
      for(int j=0; j<lbsy.nq; j++) {
        pt2[i*qdim+k] += moment[j] * lbtrinv[i*lbsy.nq+j];
      }
      pt2[i*qdim+k] += source;
    }
  }

  pt2 = NULL;
  pt3 = NULL;  
  return 0;
}

int fSiteFluidIncomCollisionMRTEDM(double* startpos, double *sitespeed, double *omega, double *omegabulk, double *rho, double* bodyforce)
{
  
  // calculate fluid collisions at grid point: uses MRT schemes
  // for incompressible fluids with Exact Difference Method forcing term

  double dv[3], meq[lbsy.nq], moment[lbsy.nq], collide[lbsy.nq];
  double density, invmass, source;
  double modv,eixux,eiyuy,eizuz,eixdux,eiyduy,eizduz;
  double *pt2 = &startpos[0];
  double *pt3 = &bodyforce[0];
  int qdim = lbsy.nf+lbsy.nc+lbsy.nt;

  for(int k=0; k<lbsy.nf; k++) {
    density = lbincp[k];
    invmass = fReciprocal(density);
    dv[0] = pt3[3*k]   * invmass;
    dv[1] = pt3[3*k+1] * invmass;
    dv[2] = pt3[3*k+2] * invmass;
    fGetMomentEquilibriumFIncom(&meq[0], sitespeed, rho[k], density);
    fGetMRTCollide(collide, omega[k], omegabulk[k]);
    modv = dv[0]*(2.0*sitespeed[0]+dv[0]) + dv[1]*(2.0*sitespeed[1]+dv[1]) + dv[2]*(2.0*sitespeed[2]+dv[2]);
    for(int i=0; i<lbsy.nq; i++) {
      moment[i] = 0;
      for(int j=0; j<lbsy.nq; j++) {
        moment[i] += pt2[j*qdim+k] * lbtr[i*lbsy.nq+j];
      }
      moment[i] = collide[i] * (meq[i] - moment[i]);
    }
    for(int i=0; i<lbsy.nq; i++) {
      eixux =  lbvx[i]*sitespeed[0];
      eiyuy =  lbvy[i]*sitespeed[1];
      eizuz =  lbvz[i]*sitespeed[2];
      eixdux = lbvx[i]*dv[0];
      eiyduy = lbvy[i]*dv[1];
      eizduz = lbvz[i]*dv[2];
      source = density * lbw[i] * (3.0 * (eixdux+eiyduy+eizduz) +
                                   4.5 * (eixdux*(eixdux+2.0*(eixux+eiyuy+eizuz+eiyduy+eizduz)) +
                                          eiyduy*(eiyduy+2.0*(eixux+eiyuy+eizuz+eizduz)) +
                                          eizduz*(eizduz+2.0*(eixux+eiyuy+eizuz))) -
                                   1.5 * modv);
      for(int j=0; j<lbsy.nq; j++) {
        pt2[i*qdim+k] += moment[j] * lbtrinv[i*lbsy.nq+j];
      }
      pt2[i*qdim+k] += source;
    }
  }

  pt2 = NULL;
  pt3 = NULL;  
  return 0;
}

int fSiteFluidCollisionMRTGuo(double* startpos, double *sitespeed, double *omega, double *omegabulk, double *rho, double* bodyforce)
{
  
  // calculate collisions at grid point: uses MRT schemes with Guo-like source terms
  // for fluids only (BGK collisions used for solutes and heat transfers)

  double speed[3], force[3], meq[lbsy.nq];
  double moment[lbsy.nq], collide[lbsy.nq], source[lbsy.nq];
  double invmass;
  double *pt2 = &startpos[0];
  double *pt3 = &bodyforce[0];
  int qdim = lbsy.nf+lbsy.nc+lbsy.nt;

  for(int k=0; k<lbsy.nf; k++) {
    invmass = fReciprocal(rho[k]);
    force[0] = pt3[3*k];
    force[1] = pt3[3*k+1];
    force[2] = pt3[3*k+2];
    speed[0] = rho[k] * sitespeed[0] + 0.5 * force[0];
    speed[1] = rho[k] * sitespeed[1] + 0.5 * force[1];
    speed[2] = rho[k] * sitespeed[2] + 0.5 * force[2];
    fGetMomentEquilibriumF(&meq[0], speed, rho[k]);
    speed[0] *= invmass;
    speed[1] *= invmass;
    speed[2] *= invmass;
    fGetMomentForceGuo(source, speed, force);
    fGetMRTCollide(collide, omega[k], omegabulk[k]);
    for(int i=0; i<lbsy.nq; i++) {
      moment[i] = 0;
      for(int j=0; j<lbsy.nq; j++) {
        moment[i] += pt2[j*qdim+k] * lbtr[i*lbsy.nq+j];
      }
      moment[i] = collide[i] * (meq[i] - moment[i]) + (1.0 - 0.5 * collide[i]) * source[i];
    }
    for(int i=0; i<lbsy.nq; i++) {
      for(int j=0; j<lbsy.nq; j++) {
        pt2[i*qdim+k] += moment[j] * lbtrinv[i*lbsy.nq+j];
      }
    }
  }

  pt2 = NULL;
  pt3 = NULL;  
  return 0;
}

int fSiteFluidIncomCollisionMRTGuo(double* startpos, double *sitespeed, double *omega, double *omegabulk, double *rho, double* bodyforce)
{
  
  // calculate collisions at grid point: uses MRT schemes with Guo-like source terms
  // for incompressible fluids only (BGK collisions used for solutes and heat transfers)

  double speed[3], force[3], meq[lbsy.nq];
  double moment[lbsy.nq], collide[lbsy.nq], source[lbsy.nq];
  double density, invdensity;
  double *pt2 = &startpos[0];
  double *pt3 = &bodyforce[0];
  int qdim = lbsy.nf+lbsy.nc+lbsy.nt;

  for(int k=0; k<lbsy.nf; k++) {
    density = lbincp[k];
    invdensity = fReciprocal(density);
    force[0] = pt3[3*k];
    force[1] = pt3[3*k+1];
    force[2] = pt3[3*k+2];
    speed[0] = density * sitespeed[0] + 0.5 * force[0];
    speed[1] = density * sitespeed[1] + 0.5 * force[1];
    speed[2] = density * sitespeed[2] + 0.5 * force[2];
    fGetMomentEquilibriumFIncom(&meq[0], speed, rho[k], density);
    speed[0] *= invdensity;
    speed[1] *= invdensity;
    speed[2] *= invdensity;
    fGetMomentForceGuo(source, speed, force);
    fGetMRTCollide(collide, omega[k], omegabulk[k]);
    for(int i=0; i<lbsy.nq; i++) {
      moment[i] = 0;
      for(int j=0; j<lbsy.nq; j++) {
        moment[i] += pt2[j*qdim+k] * lbtr[i*lbsy.nq+j];
      }
      moment[i] = collide[i] * (meq[i] - moment[i]) + (1.0 - 0.5 * collide[i]) * source[i];
    }
    for(int i=0; i<lbsy.nq; i++) {
      for(int j=0; j<lbsy.nq; j++) {
        pt2[i*qdim+k] += moment[j] * lbtrinv[i*lbsy.nq+j];
      }
    }
  }

  pt2 = NULL;
  pt3 = NULL;  
  return 0;
}

int fSiteFluidCollisionMRTHe(double* startpos, double *sitespeed, double *omega, double *omegabulk, double *rho, double* bodyforce)
{
  
  // calculate collisions at grid point: uses MRT schemes with He-like source terms
  // for fluids only (BGK collisions used for solutes and heat transfers)

  double speed[3], force[3], meq[lbsy.nq];
  double moment[lbsy.nq], collide[lbsy.nq], source[lbsy.nq];
  double invmass;
  double *pt2 = &startpos[0];
  double *pt3 = &bodyforce[0];
  int qdim = lbsy.nf+lbsy.nc+lbsy.nt;

  for(int k=0; k<lbsy.nf; k++) {
    invmass = fReciprocal(rho[k]);
    force[0] = pt3[3*k];
    force[1] = pt3[3*k+1];
    force[2] = pt3[3*k+2];
    speed[0] = rho[k] * sitespeed[0] + 0.5 * force[0];
    speed[1] = rho[k] * sitespeed[1] + 0.5 * force[1];
    speed[2] = rho[k] * sitespeed[2] + 0.5 * force[2];
    fGetMomentEquilibriumF(&meq[0], speed, rho[k]);
    speed[0] *= invmass;
    speed[1] *= invmass;
    speed[2] *= invmass;
    fGetMomentForceHe(source, speed, force);
    fGetMRTCollide(collide, omega[k], omegabulk[k]);
    for(int i=0; i<lbsy.nq; i++) {
      moment[i] = 0;
      for(int j=0; j<lbsy.nq; j++) {
        moment[i] += pt2[j*qdim+k] * lbtr[i*lbsy.nq+j];
      }
      moment[i] = collide[i] * (meq[i] - moment[i]) + (1.0 - 0.5 * collide[i]) * source[i];
    }
    for(int i=0; i<lbsy.nq; i++) {
      for(int j=0; j<lbsy.nq; j++) {
        pt2[i*qdim+k] += moment[j] * lbtrinv[i*lbsy.nq+j];
      }
    }
  }

  pt2 = NULL;
  pt3 = NULL;
  return 0;
}

int fSiteFluidIncomCollisionMRTHe(double* startpos, double *sitespeed, double *omega, double *omegabulk, double *rho, double* bodyforce)
{
  
  // calculate collisions at grid point: uses MRT schemes with He-like source terms
  // for incompressible fluids only (BGK collisions used for solutes and heat transfers)

  double speed[3], force[3], meq[lbsy.nq];
  double moment[lbsy.nq], collide[lbsy.nq], source[lbsy.nq];
  double density, invdensity;
  double *pt2 = &startpos[0];
  double *pt3 = &bodyforce[0];
  int qdim = lbsy.nf+lbsy.nc+lbsy.nt;

  for(int k=0; k<lbsy.nf; k++) {
    density = lbincp[k];
    invdensity = fReciprocal(density);
    force[0] = pt3[3*k];
    force[1] = pt3[3*k+1];
    force[2] = pt3[3*k+2];
    speed[0] = density * sitespeed[0] + 0.5 * force[0];
    speed[1] = density * sitespeed[1] + 0.5 * force[1];
    speed[2] = density * sitespeed[2] + 0.5 * force[2];
    fGetMomentEquilibriumFIncom(&meq[0], speed, rho[k], density);
    speed[0] *= invdensity;
    speed[1] *= invdensity;
    speed[2] *= invdensity;
    fGetMomentForceHe(source, speed, force);
    fGetMRTCollide(collide, omega[k], omegabulk[k]);
    for(int i=0; i<lbsy.nq; i++) {
      moment[i] = 0;
      for(int j=0; j<lbsy.nq; j++) {
        moment[i] += pt2[j*qdim+k] * lbtr[i*lbsy.nq+j];
      }
      moment[i] = collide[i] * (meq[i] - moment[i]) + (1.0 - 0.5 * collide[i]) * source[i];
    }
    for(int i=0; i<lbsy.nq; i++) {
      for(int j=0; j<lbsy.nq; j++) {
        pt2[i*qdim+k] += moment[j] * lbtrinv[i*lbsy.nq+j];
      }
    }
  }

  pt2 = NULL;
  pt3 = NULL;
  return 0;
}

// Achromatic fluid collisions with pre-calculated interfacial forces and phase segregation

int fSiteFluidCollisionMRTLishchuk(double* startpos, double *sitespeed, double *omega, double *omegabulk, double *rho, double* bodyforce, double* phaseindex)
{

  // MRT collision of achromatic fluid and D'Ortona segregation
  // calculate fluid collisions at grid point: using MRT schemes

  double speed[3], meq[lbsy.nq];
  double allmass, invallmass, omegat, omegabulkt, relax, nx, ny, nz, segcomp, segpiece, collpiece;
  double seg[lbsy.nf*lbsy.nq], lbfac[lbsy.nq], moment[lbsy.nq], collide[lbsy.nq];
  double *pt2 = &startpos[0];
  double *pt3 = &bodyforce[0];
  double *pt4 = &phaseindex[0];
  int numpair = lbsy.nf*(lbsy.nf-1)/2;
  int qdim = lbsy.nf+lbsy.nc+lbsy.nt;

  // collision of achromatic fluid

  allmass = 0.0;
  omegat = 0.0;
  omegabulkt = 0.0;

  for(int j=0; j<lbsy.nf; j++) {
    allmass += rho[j];
    omegat += omega[j] * rho[j];
    omegabulkt += omegabulk[j] * rho[j];
  }

  invallmass = fReciprocal(allmass);
  omegat *= invallmass;
  omegabulkt *= invallmass;

  for(int i=0; i<lbsy.nq; i++) {
    lbfac[i] = 0.0;
    for(int j=0; j<lbsy.nf; i++) {
      lbfac[i] += pt2[i*qdim+j];
      seg[i*lbsy.nf+j] = 0.0;
    }
  }

  // calculate segregation terms

  for(int k=0; k<numpair; k++) {
    int i = lbspair[2*k  ];
    int j = lbspair[2*k+1];
    nx = pt4[3*k  ];
    ny = pt4[3*k+1];
    nz = pt4[3*k+2];
    segpiece = lbseg[lbsy.nf*j+i] * rho[i] * rho[j] * invallmass * invallmass;
    for(int m=0; m<lbsy.nq; m++) {
      segcomp = segpiece * (lbvwx[m]*nx + lbvwy[m]*ny + lbvwz[m]*nz);
      seg[m*lbsy.nf+i] += segcomp;
      seg[m*lbsy.nf+j] -= segcomp;
    }
  }

  // collide and segregate fluids

  relax = fReciprocal(omegat);
  speed[0] = allmass * sitespeed[0] + pt3[0] * relax;
  speed[1] = allmass * sitespeed[1] + pt3[1] * relax;
  speed[2] = allmass * sitespeed[2] + pt3[2] * relax;

  fGetMomentEquilibriumF(&meq[0], speed, allmass);
  fGetMRTCollide(collide, omegat, omegabulkt);
  for(int i=0; i<lbsy.nq; i++) {
    moment[i] = 0.0;
    for(int j=0; j<lbsy.nq; j++) {
      moment[i] += lbfac[j] * lbtr[i*lbsy.nq+j];
    }
    moment[i] = collide[i] * (meq[i] - moment[i]);
  }
  for(int m=0; m<lbsy.nq; m++) {
    collpiece = lbfac[m];
    for(int j=0; j<lbsy.nq; j++) {
      collpiece += moment[j] * lbtrinv[m*lbsy.nq+j];
    }
    for(int i=0; i<lbsy.nf; i++) {
      pt2[m*qdim+i] = rho[i] * collpiece * invallmass + seg[m*lbsy.nf+i];
    }
  }

  pt2 = NULL;
  pt3 = NULL;  
  pt4 = NULL;  
  return 0;
}

int fSiteFluidIncomCollisionMRTLishchuk(double* startpos, double *sitespeed, double *omega, double *omegabulk, double *rho, double* bodyforce, double* phaseindex)
{

  // MRT collision of achromatic fluid and D'Ortona segregation
  // calculate collisions at grid point: using MRT schemes for incompressible fluids

  double speed[3], meq[lbsy.nq];
  double density, allmass, invallmass, omegat, omegabulkt, relax, nx, ny, nz, segcomp, segpiece, collpiece;
  double seg[lbsy.nf*lbsy.nq], lbfac[lbsy.nq], moment[lbsy.nq], collide[lbsy.nq];
  double *pt2 = &startpos[0];
  double *pt3 = &bodyforce[0];
  double *pt4 = &phaseindex[0];
  int numpair = lbsy.nf*(lbsy.nf-1)/2;
  int qdim = lbsy.nf+lbsy.nc+lbsy.nt;

  // collision of achromatic fluid

  allmass = 0.0;
  omegat = 0.0;
  omegabulkt = 0.0;
  density = 0.0;

  for(int j=0; j<lbsy.nf; j++) {
    allmass += rho[j];
    omegat += omega[j] * rho[j];
    omegabulkt += omegabulk[j] * rho[j];
    density += lbincp[j] * rho[j];
  }

  invallmass = fReciprocal(allmass);
  omegat *= invallmass;
  omegabulkt *= invallmass;
  density *= invallmass;
    
  for(int i=0; i<lbsy.nq; i++) {
    lbfac[i] = 0.0;
    for(int j=0; j<lbsy.nf; j++) {
      lbfac[i] += pt2[i*qdim+j];
      seg[i*lbsy.nf+j] = 0.0;
    }
  }

  // calculate segregation terms

  for(int k=0; k<numpair; k++) {
    int i = lbspair[2*k  ];
    int j = lbspair[2*k+1];
    nx = pt4[3*k  ];
    ny = pt4[3*k+1];
    nz = pt4[3*k+2];
    segpiece = lbseg[lbsy.nf*j+i] * rho[i] * rho[j] * invallmass * invallmass;
    for(int m=0; m<lbsy.nq; m++) {
      segcomp = segpiece * (lbvwx[m]*nx + lbvwy[m]*ny + lbvwz[m]*nz);
      seg[m*lbsy.nf+i] += segcomp;
      seg[m*lbsy.nf+j] -= segcomp;
    }
  }

  // collide and segregate fluids

  relax = fReciprocal(omegat);
  speed[0] = density * sitespeed[0] + pt3[0] * relax;
  speed[1] = density * sitespeed[1] + pt3[1] * relax;
  speed[2] = density * sitespeed[2] + pt3[2] * relax;

  fGetMomentEquilibriumFIncom(&meq[0], speed, allmass, density);
  fGetMRTCollide(collide, omegat, omegabulkt);
  for(int i=0; i<lbsy.nq; i++) {
    moment[i] = 0.0;
    for(int j=0; j<lbsy.nq; j++) {
      moment[i] += lbfac[j] * lbtr[i*lbsy.nq+j];
    }
    moment[i] = collide[i] * (lbfeq[i] - moment[i]);
  }
  for(int m=0; m<lbsy.nq; m++) {
    collpiece = lbfac[m];
    for(int j=0; j<lbsy.nq; j++) {
      collpiece += moment[j] * lbtrinv[m*lbsy.nq+j];
    }
    for(int i=0; i<lbsy.nf; i++) {
      pt2[m*qdim+i] = rho[i] * collpiece * invallmass + seg[m*lbsy.nf+i];
    }
  }

  pt2 = NULL;
  pt3 = NULL;  
  pt4 = NULL;  
  return 0;
}

int fSiteFluidCollisionMRTEDMLishchuk(double* startpos, double *sitespeed, double *omega, double *omegabulk, double *rho, double* bodyforce, double* phaseindex)
{

  // MRT collision of achromatic fluid and D'Ortona segregation
  // calculate fluid collisions at grid point: using MRT schemes
  // with Exact Difference Method forcing term

  double dv[3], meq[lbsy.nq];
  double allmass, invallmass, omegat, omegabulkt, nx, ny, nz, segcomp, segpiece, collpiece, source;
  double modv,eixux,eiyuy,eizuz,eixdux,eiyduy,eizduz;
  double seg[lbsy.nf*lbsy.nq], lbfac[lbsy.nq], moment[lbsy.nq], collide[lbsy.nq];
  double *pt2 = &startpos[0];
  double *pt3 = &bodyforce[0];
  double *pt4 = &phaseindex[0];
  int numpair = lbsy.nf*(lbsy.nf-1)/2;
  int qdim = lbsy.nf+lbsy.nc+lbsy.nt;

  // collision of achromatic fluid

  allmass = 0.0;
  omegat = 0.0;
  omegabulkt = 0.0;

  for(int j=0; j<lbsy.nf; j++) {
    allmass += rho[j];
    omegat += omega[j] * rho[j];
    omegabulkt += omegabulk[j] * rho[j];
  }
    
  invallmass = fReciprocal(allmass);
  omegat *= invallmass;
  omegabulkt *= invallmass;
    
  for(int i=0; i<lbsy.nq; i++) {
    lbfac[i] = 0.0;
    for(int j=0; j<lbsy.nf; j++) {
      lbfac[i] += pt2[i*qdim+j];
      seg[i*lbsy.nf+j] = 0.0;
    }
  }

  // calculate segregation terms

  for(int k=0; k<numpair; k++) {
    int i = lbspair[2*k  ];
    int j = lbspair[2*k+1];
    nx = pt4[3*k  ];
    ny = pt4[3*k+1];
    nz = pt4[3*k+2];
    segpiece = lbseg[lbsy.nf*j+i] * rho[i] * rho[j] * invallmass * invallmass;
    for(int m=0; m<lbsy.nq; m++) {
      segcomp = segpiece * (lbvwx[m]*nx + lbvwy[m]*ny + lbvwz[m]*nz);
      seg[m*lbsy.nf+i] += segcomp;
      seg[m*lbsy.nf+j] -= segcomp;
    }
  }

  // collide and segregate fluids
    
  dv[0] = pt3[0] * invallmass;
  dv[1] = pt3[1] * invallmass;
  dv[2] = pt3[2] * invallmass;

  fGetMomentEquilibriumF(&meq[0], sitespeed, allmass);
  fGetMRTCollide(collide, omegat, omegabulkt);
  modv = dv[0]*(2.0*sitespeed[0]+dv[0]) + dv[1]*(2.0*sitespeed[1]+dv[1]) + dv[2]*(2.0*sitespeed[2]+dv[2]);
  for(int i=0; i<lbsy.nq; i++) {
    moment[i] = 0.0;
    for(int j=0; j<lbsy.nq; j++) {
      moment[i] += lbfac[j] * lbtr[i*lbsy.nq+j];
    }
    moment[i] = collide[i] * (meq[i] - moment[i]);
  }
  for(int m=0; m<lbsy.nq; m++) {
    eixux =  lbvx[m]*sitespeed[0];
    eiyuy =  lbvy[m]*sitespeed[1];
    eizuz =  lbvz[m]*sitespeed[2];
    eixdux = lbvx[m]*dv[0];
    eiyduy = lbvy[m]*dv[1];
    eizduz = lbvz[m]*dv[2];
    source = allmass * lbw[m] * (3.0 * (eixdux+eiyduy+eizduz) +
                                 4.5 * (eixdux*(eixdux+2.0*(eixux+eiyuy+eizuz+eiyduy+eizduz)) +
                                        eiyduy*(eiyduy+2.0*(eixux+eiyuy+eizuz+eizduz)) +
                                        eizduz*(eizduz+2.0*(eixux+eiyuy+eizuz))) -
                                 1.5 * modv);
    collpiece = lbfac[m] + source;
    for(int j=0; j<lbsy.nq; j++) {
      collpiece += moment[j] * lbtrinv[m*lbsy.nq+j];
    }
    for(int i=0; i<lbsy.nf; i++) {
      pt2[m*qdim+i] = rho[i] * collpiece * invallmass + seg[m*lbsy.nf+i];
    }
  }

  pt2 = NULL;
  pt3 = NULL;  
  pt4 = NULL;  
  return 0;
}

int fSiteFluidIncomCollisionMRTEDMLishchuk(double* startpos, double *sitespeed, double *omega, double *omegabulk, double *rho, double* bodyforce, double* phaseindex)
{

  // MRT collision of achromatic fluid and D'Ortona segregation
  // calculate collisions at grid point: using MRT schemes
  // for incompressible fluids with Exact Difference Method forcing term

  double dv[3], meq[lbsy.nq];
  double density, allmass, invallmass, invmass, omegat, omegabulkt, nx, ny, nz, segcomp, segpiece, collpiece, source;
  double modv,eixux,eiyuy,eizuz,eixdux,eiyduy,eizduz;
  double seg[lbsy.nf*lbsy.nq], lbfac[lbsy.nq], moment[lbsy.nq], collide[lbsy.nq];
  double *pt2 = &startpos[0];
  double *pt3 = &bodyforce[0];
  double *pt4 = &phaseindex[0];
  int numpair = lbsy.nf*(lbsy.nf-1)/2;
  int qdim = lbsy.nf+lbsy.nc+lbsy.nt;

  // collision of achromatic fluid

  allmass = 0.0;
  omegat = 0.0;
  omegabulkt = 0.0;
  density = 0.0;

  for(int j=0; j<lbsy.nf; j++) {
    allmass += rho[j];
    omegat += omega[j] * rho[j];
    omegabulkt += omegabulk[j] * rho[j];
    density += lbincp[j] * rho[j];
  }
    
  invallmass = fReciprocal(allmass);
  omegat *= invallmass;
  omegabulkt *= invallmass;
  density *= invallmass;
    
  for(int i=0; i<lbsy.nq; i++) {
    lbfac[i] = 0.0;
    for(int j=0; j<lbsy.nf; j++) {
      lbfac[i] += pt2[i*qdim+j];
      seg[i*lbsy.nf+j] = 0.0;
    }
  }

  // calculate segregation terms

  for(int k=0; k<numpair; k++) {
    int i = lbspair[2*k  ];
    int j = lbspair[2*k+1];
    nx = pt4[3*k  ];
    ny = pt4[3*k+1];
    nz = pt4[3*k+2];
    segpiece = lbseg[lbsy.nf*j+i] * rho[i] * rho[j] * invallmass * invallmass;
    for(int m=0; m<lbsy.nq; m++) {
      segcomp = segpiece * (lbvwx[m]*nx + lbvwy[m]*ny + lbvwz[m]*nz);
      seg[m*lbsy.nf+i] += segcomp;
      seg[m*lbsy.nf+j] -= segcomp;
    }
  }

  // collide and segregate fluids
    
  invmass = fReciprocal(density);
  dv[0] = pt3[0] * invmass;
  dv[1] = pt3[1] * invmass;
  dv[2] = pt3[2] * invmass;

  fGetMomentEquilibriumFIncom(&meq[0], sitespeed, allmass, density);
  fGetMRTCollide(collide, omegat, omegabulkt);
  modv = dv[0]*(2.0*sitespeed[0]+dv[0]) + dv[1]*(2.0*sitespeed[1]+dv[1]) + dv[2]*(2.0*sitespeed[2]+dv[2]);
  for(int i=0; i<lbsy.nq; i++) {
    moment[i] = 0.0;
    for(int j=0; j<lbsy.nq; j++) {
      moment[i] += lbfac[j] * lbtr[i*lbsy.nq+j];
    }
    moment[i] = collide[i] * (lbfeq[i] - moment[i]);
  }
  for(int m=0; m<lbsy.nq; m++) {
    eixux =  lbvx[m]*sitespeed[0];
    eiyuy =  lbvy[m]*sitespeed[1];
    eizuz =  lbvz[m]*sitespeed[2];
    eixdux = lbvx[m]*dv[0];
    eiyduy = lbvy[m]*dv[1];
    eizduz = lbvz[m]*dv[2];
    source = density * lbw[m] * (3.0 * (eixdux+eiyduy+eizduz) +
                                 4.5 * (eixdux*(eixdux+2.0*(eixux+eiyuy+eizuz+eiyduy+eizduz)) +
                                        eiyduy*(eiyduy+2.0*(eixux+eiyuy+eizuz+eizduz)) +
                                        eizduz*(eizduz+2.0*(eixux+eiyuy+eizuz))) -
                                 1.5 * modv);
    collpiece = lbfac[m] + source;
    for(int j=0; j<lbsy.nq; j++) {
      collpiece += moment[j] * lbtrinv[m*lbsy.nq+j];
    }
    for(int i=0; i<lbsy.nf; i++) {
      pt2[m*qdim+i] = rho[i] * collpiece * invallmass + seg[m*lbsy.nf+i];
    }
  }

  pt2 = NULL;
  pt3 = NULL;  
  pt4 = NULL;  
  return 0;
}

int fSiteFluidCollisionMRTGuoLishchuk(double* startpos, double *sitespeed, double *omega, double *omegabulk, double *rho, double* bodyforce, double* phaseindex)
{

  // MRT collision of achromatic fluid and D'Ortona segregation
  // calculate collisions at grid point: using MRT schemes with 
  // Guo-like source terms for fluids only (BGK collisions used
  // for solutes and heat transfers)

  double speed[3], force[3], meq[lbsy.nq];
  double allmass, invallmass, omegat, omegabulkt, nx, ny, nz, segcomp, segpiece, collpiece;
  double seg[lbsy.nf*lbsy.nq], lbfac[lbsy.nq], moment[lbsy.nq], collide[lbsy.nq], source[lbsy.nq];
  double *pt2 = &startpos[0];
  double *pt3 = &bodyforce[0];
  double *pt4 = &phaseindex[0];
  int numpair = lbsy.nf*(lbsy.nf-1)/2;
  int qdim = lbsy.nf+lbsy.nc+lbsy.nt;

  // collision of achromatic fluid

  allmass = 0.0;
  omegat = 0.0;
  omegabulkt = 0.0;

  for(int j=0; j<lbsy.nf; j++) {
    allmass += rho[j];
    omegat += omega[j] * rho[j];
    omegabulkt += omegabulk[j] * rho[j];
  }
    
  invallmass = fReciprocal(allmass);
  omegat *= invallmass;
  omegabulkt *= invallmass;
    
  for(int i=0; i<lbsy.nq; i++) {
    lbfac[i] = 0.0;
    for(int j=0; j<lbsy.nf; j++) {
      lbfac[i] += pt2[i*qdim+j];
      seg[i*lbsy.nf+j] = 0.0;
    }
  }

  // calculate segregation terms

  for(int k=0; k<numpair; k++) {
    int i = lbspair[2*k  ];
    int j = lbspair[2*k+1];
    nx = pt4[3*k  ];
    ny = pt4[3*k+1];
    nz = pt4[3*k+2];
    segpiece = lbseg[lbsy.nf*j+i] * rho[i] * rho[j] * invallmass * invallmass;
    for(int m=0; m<lbsy.nq; m++) {
      segcomp = segpiece * (lbvwx[m]*nx + lbvwy[m]*ny + lbvwz[m]*nz);
      seg[m*lbsy.nf+i] += segcomp;
      seg[m*lbsy.nf+j] -= segcomp;
    }
  }

  // collide and segregate fluids
    
  force[0] = pt3[0];
  force[1] = pt3[1];
  force[2] = pt3[2];
  speed[0] = allmass * sitespeed[0] + 0.5 * force[0];
  speed[1] = allmass * sitespeed[1] + 0.5 * force[1];
  speed[2] = allmass * sitespeed[2] + 0.5 * force[2];

  fGetMomentEquilibriumF(&meq[0], speed, allmass);
  speed[0] *= invallmass;
  speed[1] *= invallmass;
  speed[2] *= invallmass;
  fGetMomentForceGuo(source, speed, force);
  fGetMRTCollide(collide, omegat, omegabulkt);
  for(int i=0; i<lbsy.nq; i++) {
    moment[i] = 0.0;
    for(int j=0; j<lbsy.nq; j++) {
      moment[i] += lbfac[j] * lbtr[i*lbsy.nq+j];
    }
    moment[i] = collide[i] * (meq[i] - moment[i]) + (1.0 - 0.5 * collide[i]) * source[i];
  }
  for(int m=0; m<lbsy.nq; m++) {
    collpiece = lbfac[m];
    for(int j=0; j<lbsy.nq; j++) {
      collpiece += moment[j] * lbtrinv[m*lbsy.nq+j];
    }
    for(int i=0; i<lbsy.nf; i++) {
      pt2[m*qdim+i] = rho[i] * collpiece * invallmass + seg[m*lbsy.nf+i];
    }
  }

  pt2 = NULL;
  pt3 = NULL;  
  pt4 = NULL;  
  return 0;
}

int fSiteFluidIncomCollisionMRTGuoLishchuk(double* startpos, double *sitespeed, double *omega, double *omegabulk, double *rho, double* bodyforce, double* phaseindex)
{

  // MRT collision of achromatic fluid and D'Ortona segregation
  // calculate collisions at grid point: using MRT schemes with 
  // Guo-like source terms for incompressible fluids only
  // (BGK collisions used for solutes and heat transfers)

  double speed[3], force[3], meq[lbsy.nq];
  double allmass, invallmass, density, omegat, omegabulkt, nx, ny, nz, segcomp, segpiece, collpiece;
  double seg[lbsy.nf*lbsy.nq], lbfac[lbsy.nq], moment[lbsy.nq], collide[lbsy.nq], source[lbsy.nq];
  double *pt2 = &startpos[0];
  double *pt3 = &bodyforce[0];
  double *pt4 = &phaseindex[0];
  int numpair = lbsy.nf*(lbsy.nf-1)/2;
  int qdim = lbsy.nf+lbsy.nc+lbsy.nt;

  // collision of achromatic fluid

  allmass = 0.0;
  omegat = 0.0;
  omegabulkt = 0.0;
  density = 0.0;

  for(int j=0; j<lbsy.nf; j++) {
    allmass += rho[j];
    omegat += omega[j] * rho[j];
    omegabulkt += omegabulk[j] * rho[j];
    density += lbincp[j] * rho[j];
  }

  invallmass = fReciprocal(allmass);
  omegat *= invallmass;
  omegabulkt *= invallmass;
  density *= invallmass;
    
  for(int i=0; i<lbsy.nq; i++) {
    lbfac[i] = 0.0;
    for(int j=0; j<lbsy.nf; j++) {
      lbfac[i] += pt2[i*qdim+j];
      seg[i*lbsy.nf+j] = 0.0;
    }
  }

  // calculate segregation terms

  for(int k=0; k<numpair; k++) {
    int i = lbspair[2*k  ];
    int j = lbspair[2*k+1];
    nx = pt4[3*k  ];
    ny = pt4[3*k+1];
    nz = pt4[3*k+2];
    segpiece = lbseg[lbsy.nf*j+i] * rho[i] * rho[j] * invallmass * invallmass;
    for(int m=0; m<lbsy.nq; m++) {
      segcomp = segpiece * (lbvwx[m]*nx + lbvwy[m]*ny + lbvwz[m]*nz);
      seg[m*lbsy.nf+i] += segcomp;
      seg[m*lbsy.nf+j] -= segcomp;
    }
  }

  // collide and segregate fluids
    
  force[0] = pt3[0];
  force[1] = pt3[1];
  force[2] = pt3[2];
  speed[0] = allmass * sitespeed[0] + 0.5 * force[0];
  speed[1] = allmass * sitespeed[1] + 0.5 * force[1];
  speed[2] = allmass * sitespeed[2] + 0.5 * force[2];

  fGetMomentEquilibriumFIncom(&meq[0], speed, allmass, density);
  speed[0] *= invallmass;
  speed[1] *= invallmass;
  speed[2] *= invallmass;
  fGetMomentForceGuo(source, speed, force);
  fGetMRTCollide(collide, omegat, omegabulkt);
  for(int i=0; i<lbsy.nq; i++) {
    moment[i] = 0.0;
    for(int j=0; j<lbsy.nq; j++) {
      moment[i] += lbfac[j] * lbtr[i*lbsy.nq+j];
    }
    moment[i] = collide[i] * (meq[i] - moment[i]) + (1.0 - 0.5 * collide[i]) * source[i];
  }
  for(int m=0; m<lbsy.nq; m++) {
    collpiece = lbfac[m];
    for(int j=0; j<lbsy.nq; j++) {
      collpiece += moment[j] * lbtrinv[m*lbsy.nq+j];
    }
    for(int i=0; i<lbsy.nf; i++) {
      pt2[m*qdim+i] = rho[i] * collpiece * invallmass + seg[m*lbsy.nf+i];
    }
  }

  pt2 = NULL;
  pt3 = NULL;  
  pt4 = NULL;  
  return 0;
}

int fSiteFluidCollisionMRTHeLishchuk(double* startpos, double *sitespeed, double *omega, double *omegabulk, double *rho, double* bodyforce, double* phaseindex)
{

  // MRT collision of achromatic fluid and D'Ortona segregation
  // calculate collisions at grid point: using MRT schemes with
  // He-like source terms for fluids only (BGK collisions used
  // for solutes and heat transfers)

  double speed[3], force[3], meq[lbsy.nq];
  double allmass, invallmass, omegat, omegabulkt, nx, ny, nz, segcomp, segpiece, collpiece;
  double seg[lbsy.nf*lbsy.nq], lbfac[lbsy.nq], moment[lbsy.nq], collide[lbsy.nq], source[lbsy.nq];
  double *pt2 = &startpos[0];
  double *pt3 = &bodyforce[0];
  double *pt4 = &phaseindex[0];
  int numpair = lbsy.nf*(lbsy.nf-1)/2;
  int qdim = lbsy.nf+lbsy.nc+lbsy.nt;

  // collision of achromatic fluid

  allmass = 0.0;
  omegat = 0.0;
  omegabulkt = 0.0;

  for(int j=0; j<lbsy.nf; j++) {
    allmass += rho[j];
    omegat += omega[j] * rho[j];
    omegabulkt += omegabulk[j] * rho[j];
  }
    
  invallmass = fReciprocal(allmass);
  omegat *= invallmass;
  omegabulkt *= invallmass;
    
  for(int i=0; i<lbsy.nq; i++) {
    lbfac[i] = 0.0;
    for(int j=0; j<lbsy.nf; j++) {
      lbfac[i] += pt2[i*qdim+j];
      seg[i*lbsy.nf+j] = 0.0;
    }
  }

  // calculate segregation terms

  for(int k=0; k<numpair; k++) {
    int i = lbspair[2*k  ];
    int j = lbspair[2*k+1];
    nx = pt4[3*k  ];
    ny = pt4[3*k+1];
    nz = pt4[3*k+2];
    segpiece = lbseg[lbsy.nf*j+i] * rho[i] * rho[j] * invallmass * invallmass;
    for(int m=0; m<lbsy.nq; m++) {
      segcomp = segpiece * (lbvwx[m]*nx + lbvwy[m]*ny + lbvwz[m]*nz);
      seg[m*lbsy.nf+i] += segcomp;
      seg[m*lbsy.nf+j] -= segcomp;
    }
  }

  // collide and segregate fluids
    
  force[0] = pt3[0];
  force[1] = pt3[1];
  force[2] = pt3[2];
  speed[0] = allmass * sitespeed[0] + 0.5 * force[0];
  speed[1] = allmass * sitespeed[1] + 0.5 * force[1];
  speed[2] = allmass * sitespeed[2] + 0.5 * force[2];

  fGetMomentEquilibriumF(&meq[0], speed, allmass);
  speed[0] *= invallmass;
  speed[1] *= invallmass;
  speed[2] *= invallmass;
  fGetMomentForceHe(source, speed, force);
  fGetMRTCollide(collide, omegat, omegabulkt);
  for(int i=0; i<lbsy.nq; i++) {
    moment[i] = 0.0;
    for(int j=0; j<lbsy.nq; j++) {
      moment[i] += lbfac[j] * lbtr[i*lbsy.nq+j];
    }
    moment[i] = collide[i] * (meq[i] - moment[i]) + (1.0 - 0.5 * collide[i]) * source[i];
  }
  for(int m=0; m<lbsy.nq; m++) {
    collpiece = lbfac[m];
    for(int j=0; j<lbsy.nq; j++) {
      collpiece += moment[j] * lbtrinv[m*lbsy.nq+j];
    }
    for(int i=0; i<lbsy.nf; i++) {
      pt2[m*qdim+i] = rho[i] * collpiece * invallmass + seg[m*lbsy.nf+i];
    }
  }

  pt2 = NULL;
  pt3 = NULL;
  pt4 = NULL;
  return 0;
}

int fSiteFluidIncomCollisionMRTHeLishchuk(double* startpos, double *sitespeed, double *omega, double *omegabulk, double *rho, double* bodyforce, double* phaseindex)
{

  // MRT collision of achromatic fluid and D'Ortona segregation
  // calculate collisions at grid point: using MRT schemes with
  // He-like source terms for incompressible fluids only
  // (BGK collisions used for solutes and heat transfers)

  double speed[3], force[3], meq[lbsy.nq];
  double allmass, invallmass, density, omegat, omegabulkt, nx, ny, nz, segcomp, segpiece, collpiece;
  double seg[lbsy.nf*lbsy.nq], lbfac[lbsy.nq], moment[lbsy.nq], collide[lbsy.nq], source[lbsy.nq];
  double *pt2 = &startpos[0];
  double *pt3 = &bodyforce[0];
  double *pt4 = &phaseindex[0];
  int numpair = lbsy.nf*(lbsy.nf-1)/2;
  int qdim = lbsy.nf+lbsy.nc+lbsy.nt;

  // collision of achromatic fluid

  allmass = 0.0;
  omegat = 0.0;
  omegabulkt = 0.0;
  density = 0.0;

  for(int j=0; j<lbsy.nf; j++) {
    allmass += rho[j];
    omegat += omega[j] * rho[j];
    omegabulkt += omegabulk[j] * rho[j];
    density += lbincp[j] * rho[j];
  }

  invallmass = fReciprocal(allmass);
  omegat *= invallmass;
  omegabulkt *= invallmass;
  density *= invallmass;
    
  for(int i=0; i<lbsy.nq; i++) {
    lbfac[i] = 0.0;
    for(int j=0; j<lbsy.nf; j++) {
      lbfac[i] += pt2[i*qdim+j];
      seg[i*lbsy.nf+j] = 0.0;
    }
  }

  // calculate segregation terms

  for(int k=0; k<numpair; k++) {
    int i = lbspair[2*k  ];
    int j = lbspair[2*k+1];
    nx = pt4[3*k  ];
    ny = pt4[3*k+1];
    nz = pt4[3*k+2];
    segpiece = lbseg[lbsy.nf*j+i] * rho[i] * rho[j] * invallmass * invallmass;
    for(int m=0; m<lbsy.nq; m++) {
      segcomp = segpiece * (lbvwx[m]*nx + lbvwy[m]*ny + lbvwz[m]*nz);
      seg[m*lbsy.nf+i] += segcomp;
      seg[m*lbsy.nf+j] -= segcomp;
    }
  }

  // collide and segregate fluids
    
  force[0] = pt3[0];
  force[1] = pt3[1];
  force[2] = pt3[2];
  speed[0] = allmass * sitespeed[0] + 0.5 * force[0];
  speed[1] = allmass * sitespeed[1] + 0.5 * force[1];
  speed[2] = allmass * sitespeed[2] + 0.5 * force[2];

  fGetMomentEquilibriumFIncom(&meq[0], speed, allmass, density);
  speed[0] *= invallmass;
  speed[1] *= invallmass;
  speed[2] *= invallmass;
  fGetMomentForceHe(source, speed, force);
  fGetMRTCollide(collide, omegat, omegabulkt);
  for(int i=0; i<lbsy.nq; i++) {
    moment[i] = 0.0;
    for(int j=0; j<lbsy.nq; j++) {
      moment[i] += lbfac[j] * lbtr[i*lbsy.nq+j];
    }
    moment[i] = collide[i] * (meq[i] - moment[i]) + (1.0 - 0.5 * collide[i]) * source[i];
  }
  for(int m=0; m<lbsy.nq; m++) {
    collpiece = lbfac[m];
    for(int j=0; j<lbsy.nq; j++) {
      collpiece += moment[j] * lbtrinv[m*lbsy.nq+j];
    }
    for(int i=0; i<lbsy.nf; i++) {
      pt2[m*qdim+i] = rho[i] * collpiece * invallmass + seg[m*lbsy.nf+i];
    }
  }

  pt2 = NULL;
  pt3 = NULL;
  pt4 = NULL;
  return 0;
}

// Achromatic fluid collisions with local forcing terms and phase segregation

int fSiteFluidCollisionMRTLishchukLocal(double* startpos, double *sitespeed, double *omega, double *omegabulk, double *rho, double* bodyforce, double* phaseindex, int threed)
{

  // MRT collision of achromatic fluid and D'Ortona segregation
  // calculate interfacial forcing terms and fluid collisions at grid point:
  // using MRT schemes

  double speed[3], meq[lbsy.nq];
  double allmass, invallmass, omegat, omegabulkt, ex, ey, ez, nx, ny, nz;
  double forceconst, segcomp, segpiece, collpiece, relax;
  double seg[lbsy.nf*lbsy.nq], lbfac[lbsy.nq], moment[lbsy.nq], collide[lbsy.nq], phaseforce[lbsy.nq];
  double *pt2 = &startpos[0];
  double *pt3 = &bodyforce[0];
  double *pt4 = &phaseindex[0];
  int numpair = lbsy.nf*(lbsy.nf-1)/2;
  int qdim = lbsy.nf+lbsy.nc+lbsy.nt;

  // collision of achromatic fluid

  allmass = 0.0;
  omegat = 0.0;
  omegabulkt = 0.0;

  for(int j=0; j<lbsy.nf; j++) {
    allmass += rho[j];
    omegat += omega[j] * rho[j];
    omegabulkt += omegabulk[j] * rho[j];
  }

  invallmass = fReciprocal(allmass);
  omegat *= invallmass;
  omegabulkt *= invallmass;
    
  for(int i=0; i<lbsy.nq; i++) {
    lbfac[i] = 0.0;
    phaseforce[i] = 0.0;
    for(int j=0; j<lbsy.nf; j++) {
      lbfac[i] += pt2[i*qdim+j];
      seg[i*lbsy.nf+j] = 0.0;
    }
  }

  // calculate local forcing and segregation terms
    
  for(int k=0; k<numpair; k++) {
    int i = lbspair[2*k  ];
    int j = lbspair[2*k+1];
    nx = pt4[3*k  ];
    ny = pt4[3*k+1];
    nz = pt4[3*k+2];
    forceconst = lbseg[lbsy.nf*j+i] * lbg[lbsy.nf*j+i] * rho[i] * rho[j];
    segpiece = lbseg[lbsy.nf*j+i] * rho[i] * rho[j] * invallmass * invallmass;
    for(int m=0; m<lbsy.nq; m++) {
      ex = lbvx[m];
      ey = lbvy[m];
      ez = lbvz[m];
      phaseforce[m] += forceconst * ((nx*nx-1.0)*(ex*ex-lbcssq) + (ny*ny-1.0)*(ey*ey-lbcssq) + 2.0*nx*ny*ex*ey
                     + threed*((nz*nz-1.0)*(ez*ez-lbcssq) + 2.0*nz*ez*(nx*ex+ny*ey)));
      segcomp = segpiece * (lbvwx[m]*nx + lbvwy[m]*ny + lbvwz[m]*nz);
      seg[m*lbsy.nf+i] += segcomp;
      seg[m*lbsy.nf+j] -= segcomp;
    }
  }

  // collide and segregate fluids
    
  relax = fReciprocal(omegat);
  speed[0] = allmass * sitespeed[0] + pt3[0] * relax;
  speed[1] = allmass * sitespeed[1] + pt3[1] * relax;
  speed[2] = allmass * sitespeed[2] + pt3[2] * relax;
  forceconst = omegat * invallmass * invallmass * invallmass * lbrcssq * lbrcssq;

  fGetMomentEquilibriumF(&meq[0], speed, allmass);
  fGetMRTCollide(collide, omegat, omegabulkt);
  for(int i=0; i<lbsy.nq; i++) {
    moment[i] = 0.0;
    for(int j=0; j<lbsy.nq; j++) {
      moment[i] += lbfac[j] * lbtr[i*lbsy.nq+j];
    }
    moment[i] = collide[i] * (meq[i] - moment[i]);
  }
  for(int m=0; m<lbsy.nq; m++) {
    collpiece = lbfac[m] + lbw[m]*forceconst*phaseforce[m];
    for(int j=0; j<lbsy.nq; j++) {
      collpiece += moment[j] * lbtrinv[m*lbsy.nq+j];
    }
    for(int i=0; i<lbsy.nf; i++) {
      pt2[m*qdim+i] = rho[i] * collpiece * invallmass + seg[m*lbsy.nf+i];
    }
  }

  pt2 = NULL;
  pt3 = NULL;  
  pt4 = NULL;  
  return 0;
}

int fSiteFluidIncomCollisionMRTLishchukLocal(double* startpos, double *sitespeed, double *omega, double *omegabulk, double *rho, double* bodyforce, double* phaseindex, int threed)
{

  // MRT collision of achromatic fluid and D'Ortona segregation
  // calculate interfacial forcing terms and collisions at grid point:
  // using MRT schemes for incompressible fluids

  double speed[3], meq[lbsy.nq];
  double density, allmass, invallmass, omegat, omegabulkt, ex, ey, ez, nx, ny, nz;
  double forceconst, relax, segcomp, segpiece, collpiece;
  double seg[lbsy.nf*lbsy.nq], lbfac[lbsy.nq], moment[lbsy.nq], collide[lbsy.nq], phaseforce[lbsy.nq];
  double *pt2 = &startpos[0];
  double *pt3 = &bodyforce[0];
  double *pt4 = &phaseindex[0];
  int numpair = lbsy.nf*(lbsy.nf-1)/2;
  int qdim = lbsy.nf+lbsy.nc+lbsy.nt;

  // collision of achromatic fluid

  allmass = 0.0;
  omegat = 0.0;
  omegabulkt = 0.0;
  density = 0.0;

  for(int j=0; j<lbsy.nf; j++) {
    allmass += rho[j];
    omegat += omega[j] * rho[j];
    omegabulkt += omegabulk[j] * rho[j];
    density += lbincp[j] * rho[j];
  }
    
  invallmass = fReciprocal(allmass);
  omegat *= invallmass;
  omegabulkt *= invallmass;
  density *= invallmass;
    
  for(int i=0; i<lbsy.nq; i++) {
    lbfac[i] = 0.0;
    phaseforce[i] = 0.0;
    for(int j=0; j<lbsy.nf; j++) {
      lbfac[i] += pt2[i*qdim+j];
      seg[i*lbsy.nf+j] = 0.0;
    }
  }

  // calculate local forcing and segregation terms
    
  for(int k=0; k<numpair; k++) {
    int i = lbspair[2*k  ];
    int j = lbspair[2*k+1];
    nx = pt4[3*k  ];
    ny = pt4[3*k+1];
    nz = pt4[3*k+2];
    forceconst = lbseg[lbsy.nf*j+i] * lbg[lbsy.nf*j+i] * rho[i] * rho[j];
    segpiece = lbseg[lbsy.nf*j+i] * rho[i] * rho[j] * invallmass * invallmass;
    for(int m=0; m<lbsy.nq; m++) {
      ex = lbvx[m];
      ey = lbvy[m];
      ez = lbvz[m];
      phaseforce[m] += forceconst * ((nx*nx-1.0)*(ex*ex-lbcssq) + (ny*ny-1.0)*(ey*ey-lbcssq) + 2.0*nx*ny*ex*ey
                     + threed*((nz*nz-1.0)*(ez*ez-lbcssq) + 2.0*nz*ez*(nx*ex+ny*ey)));
      segcomp = segpiece * (lbvwx[m]*nx + lbvwy[m]*ny + lbvwz[m]*nz);
      seg[m*lbsy.nf+i] += segcomp;
      seg[m*lbsy.nf+j] -= segcomp;
    }
  }

  // collide and segregate fluids
    
  relax = fReciprocal(omegat);
  speed[0] = density * sitespeed[0] + pt3[0] * relax;
  speed[1] = density * sitespeed[1] + pt3[1] * relax;
  speed[2] = density * sitespeed[2] + pt3[2] * relax;
  forceconst = omegat * invallmass * invallmass * lbrcssq * lbrcssq * fReciprocal(density);

  fGetMomentEquilibriumFIncom(&meq[0], speed, allmass, density);
  fGetMRTCollide(collide, omegat, omegabulkt);
  for(int i=0; i<lbsy.nq; i++) {
    moment[i] = 0.0;
    for(int j=0; j<lbsy.nq; j++) {
      moment[i] += lbfac[j] * lbtr[i*lbsy.nq+j];
    }
    moment[i] = collide[i] * (lbfeq[i] - moment[i]);
  }
  for(int m=0; m<lbsy.nq; m++) {
    collpiece = lbfac[m] + lbw[m]*forceconst*phaseforce[m];
    for(int j=0; j<lbsy.nq; j++) {
      collpiece += moment[j] * lbtrinv[m*lbsy.nq+j];
    }
    for(int i=0; i<lbsy.nf; i++) {
      pt2[m*qdim+i] = rho[i] * collpiece * invallmass + seg[m*lbsy.nf+i];
    }
  }

  pt2 = NULL;
  pt3 = NULL;  
  pt4 = NULL;  
  return 0;
}

int fSiteFluidCollisionMRTEDMLishchukLocal(double* startpos, double *sitespeed, double *omega, double *omegabulk, double *rho, double* bodyforce, double* phaseindex, int threed)
{

  // MRT collision of achromatic fluid and D'Ortona segregation
  // calculate interfacial forcing terms and fluid collisions at grid point:
  // using MRT schemes with Exact Difference Method forcing term

  double dv[3], meq[lbsy.nq];
  double allmass, invallmass, omegat, omegabulkt, ex, ey, ez, nx, ny, nz;
  double forceconst, segcomp, segpiece, collpiece, source;
  double modv,eixux,eiyuy,eizuz,eixdux,eiyduy,eizduz;
  double seg[lbsy.nf*lbsy.nq], lbfac[lbsy.nq], moment[lbsy.nq], collide[lbsy.nq], phaseforce[lbsy.nq];
  double *pt2 = &startpos[0];
  double *pt3 = &bodyforce[0];
  double *pt4 = &phaseindex[0];
  int numpair = lbsy.nf*(lbsy.nf-1)/2;
  int qdim = lbsy.nf+lbsy.nc+lbsy.nt;

  // collision of achromatic fluid

  allmass = 0.0;
  omegat = 0.0;
  omegabulkt = 0.0;

  for(int j=0; j<lbsy.nf; j++) {
    allmass += rho[j];
    omegat += omega[j] * rho[j];
    omegabulkt += omegabulk[j] * rho[j];
  }

  invallmass = fReciprocal(allmass);
  omegat *= invallmass;
  omegabulkt *= invallmass;
    
  for(int i=0; i<lbsy.nq; i++) {
    lbfac[i] = 0.0;
    phaseforce[i] = 0.0;
    for(int j=0; j<lbsy.nf; j++) {
      lbfac[i] += pt2[i*qdim+j];
      seg[i*lbsy.nf+j] = 0.0;
    }
  }

  // calculate local forcing and segregation terms
    
  for(int k=0; k<numpair; k++) {
    int i = lbspair[2*k  ];
    int j = lbspair[2*k+1];
    nx = pt4[3*k  ];
    ny = pt4[3*k+1];
    nz = pt4[3*k+2];
    forceconst = lbseg[lbsy.nf*j+i] * lbg[lbsy.nf*j+i] * rho[i] * rho[j];
    segpiece = lbseg[lbsy.nf*j+i] * rho[i] * rho[j] * invallmass * invallmass;
    for(int m=0; m<lbsy.nq; m++) {
      ex = lbvx[m];
      ey = lbvy[m];
      ez = lbvz[m];
      phaseforce[m] += forceconst * ((nx*nx-1.0)*(ex*ex-lbcssq) + (ny*ny-1.0)*(ey*ey-lbcssq) + 2.0*nx*ny*ex*ey
                     + threed*((nz*nz-1.0)*(ez*ez-lbcssq) + 2.0*nz*ez*(nx*ex+ny*ey)));
      segcomp = segpiece * (lbvwx[m]*nx + lbvwy[m]*ny + lbvwz[m]*nz);
      seg[m*lbsy.nf+i] += segcomp;
      seg[m*lbsy.nf+j] -= segcomp;
    }
  }
  
  // collide and segregate fluids
    
  dv[0] = pt3[0] * invallmass;
  dv[1] = pt3[1] * invallmass;
  dv[2] = pt3[2] * invallmass;
  forceconst = omegat * invallmass * invallmass * invallmass * lbrcssq * lbrcssq;

  fGetMomentEquilibriumF(&meq[0], sitespeed, allmass);
  fGetMRTCollide(collide, omegat, omegabulkt);
  modv = dv[0]*(2.0*sitespeed[0]+dv[0]) + dv[1]*(2.0*sitespeed[1]+dv[1]) + dv[2]*(2.0*sitespeed[2]+dv[2]);
  for(int i=0; i<lbsy.nq; i++) {
    moment[i] = 0.0;
    for(int j=0; j<lbsy.nq; j++) {
      moment[i] += lbfac[j] * lbtr[i*lbsy.nq+j];
    }
    moment[i] = collide[i] * (meq[i] - moment[i]);
  }
  for(int m=0; m<lbsy.nq; m++) {
    eixux =  lbvx[m]*sitespeed[0];
    eiyuy =  lbvy[m]*sitespeed[1];
    eizuz =  lbvz[m]*sitespeed[2];
    eixdux = lbvx[m]*dv[0];
    eiyduy = lbvy[m]*dv[1];
    eizduz = lbvz[m]*dv[2];
    source = allmass * lbw[m] * (3.0 * (eixdux+eiyduy+eizduz) +
                                 4.5 * (eixdux*(eixdux+2.0*(eixux+eiyuy+eizuz+eiyduy+eizduz)) +
                                        eiyduy*(eiyduy+2.0*(eixux+eiyuy+eizuz+eizduz)) +
                                        eizduz*(eizduz+2.0*(eixux+eiyuy+eizuz))) -
                                 1.5 * modv);
    collpiece = lbfac[m] + source + lbw[m]*forceconst*phaseforce[m];
    for(int j=0; j<lbsy.nq; j++) {
      collpiece += moment[j] * lbtrinv[m*lbsy.nq+j];
    }
    for(int i=0; i<lbsy.nf; i++) {
      pt2[m*qdim+i] = rho[i] * collpiece * invallmass + seg[m*lbsy.nf+i];
    }
  }

  pt2 = NULL;
  pt3 = NULL;  
  pt4 = NULL;  
  return 0;
}

int fSiteFluidIncomCollisionMRTEDMLishchukLocal(double* startpos, double *sitespeed, double *omega, double *omegabulk, double *rho, double* bodyforce, double* phaseindex, int threed)
{

  // MRT collision of achromatic fluid and D'Ortona segregation
  // calculate interfacial forcing terms and collisions at grid point:
  // using MRT schemes for incompressible fluids with
  // Exact Difference Method forcing term

  double dv[3], meq[lbsy.nq];
  double density, allmass, invallmass, invmass, omegat, omegabulkt, ex, ey, ez, nx, ny, nz;
  double forceconst, segcomp, segpiece, collpiece, source;
  double modv,eixux,eiyuy,eizuz,eixdux,eiyduy,eizduz;
  double seg[lbsy.nf*lbsy.nq], lbfac[lbsy.nq], moment[lbsy.nq], collide[lbsy.nq], phaseforce[lbsy.nq];
  double *pt2 = &startpos[0];
  double *pt3 = &bodyforce[0];
  double *pt4 = &phaseindex[0];
  int numpair = lbsy.nf*(lbsy.nf-1)/2;
  int qdim = lbsy.nf+lbsy.nc+lbsy.nt;

  // collision of achromatic fluid

  allmass = 0.0;
  omegat = 0.0;
  omegabulkt = 0.0;
  density = 0.0;

  for(int j=0; j<lbsy.nf; j++) {
    allmass += rho[j];
    omegat += omega[j] * rho[j];
    omegabulkt += omegabulk[j] * rho[j];
    density += lbincp[j] * rho[j];
  }
    
  invallmass = fReciprocal(allmass);
  omegat *= invallmass;
  omegabulkt *= invallmass;
  density *= invallmass;
    
  for(int i=0; i<lbsy.nq; i++) {
    lbfac[i] = 0.0;
    phaseforce[i] = 0.0;
    for(int j=0; j<lbsy.nf; j++) {
      lbfac[i] += pt2[i*qdim+j];
      seg[i*lbsy.nf+j] = 0.0;
    }
  }

  // calculate local forcing and segregation terms
    
  for(int k=0; k<numpair; k++) {
    int i = lbspair[2*k  ];
    int j = lbspair[2*k+1];
    nx = pt4[3*k  ];
    ny = pt4[3*k+1];
    nz = pt4[3*k+2];
    forceconst = lbseg[lbsy.nf*j+i] * lbg[lbsy.nf*j+i] * rho[i] * rho[j];
    segpiece = lbseg[lbsy.nf*j+i] * rho[i] * rho[j] * invallmass * invallmass;
    for(int m=0; m<lbsy.nq; m++) {
      ex = lbvx[m];
      ey = lbvy[m];
      ez = lbvz[m];
      phaseforce[m] += forceconst * ((nx*nx-1.0)*(ex*ex-lbcssq) + (ny*ny-1.0)*(ey*ey-lbcssq) + 2.0*nx*ny*ex*ey
                     + threed*((nz*nz-1.0)*(ez*ez-lbcssq) + 2.0*nz*ez*(nx*ex+ny*ey)));
      segcomp = segpiece * (lbvwx[m]*nx + lbvwy[m]*ny + lbvwz[m]*nz);
      seg[m*lbsy.nf+i] += segcomp;
      seg[m*lbsy.nf+j] -= segcomp;
    }
  }

  // collide and segregate fluids
    
  invmass = fReciprocal(density);
  dv[0] = pt3[0] * invmass;
  dv[1] = pt3[1] * invmass;
  dv[2] = pt3[2] * invmass;
  forceconst = omegat * invallmass * invallmass * lbrcssq * lbrcssq * invmass;

  fGetMomentEquilibriumFIncom(&meq[0], sitespeed, allmass, density);
  fGetMRTCollide(collide, omegat, omegabulkt);
  modv = dv[0]*(2.0*sitespeed[0]+dv[0]) + dv[1]*(2.0*sitespeed[1]+dv[1]) + dv[2]*(2.0*sitespeed[2]+dv[2]);
  for(int i=0; i<lbsy.nq; i++) {
    moment[i] = 0.0;
    for(int j=0; j<lbsy.nq; j++) {
      moment[i] += lbfac[j] * lbtr[i*lbsy.nq+j];
    }
    moment[i] = collide[i] * (lbfeq[i] - moment[i]);
  }
  for(int m=0; m<lbsy.nq; m++) {
    eixux =  lbvx[m]*sitespeed[0];
    eiyuy =  lbvy[m]*sitespeed[1];
    eizuz =  lbvz[m]*sitespeed[2];
    eixdux = lbvx[m]*dv[0];
    eiyduy = lbvy[m]*dv[1];
    eizduz = lbvz[m]*dv[2];
    source = density * lbw[m] * (3.0 * (eixdux+eiyduy+eizduz) +
                                 4.5 * (eixdux*(eixdux+2.0*(eixux+eiyuy+eizuz+eiyduy+eizduz)) +
                                        eiyduy*(eiyduy+2.0*(eixux+eiyuy+eizuz+eizduz)) +
                                        eizduz*(eizduz+2.0*(eixux+eiyuy+eizuz))) -
                                 1.5 * modv);
    collpiece = lbfac[m] + source + lbw[m]*forceconst*phaseforce[m];
    for(int j=0; j<lbsy.nq; j++) {
      collpiece += moment[j] * lbtrinv[m*lbsy.nq+j];
    }
    for(int i=0; i<lbsy.nf; i++) {
      pt2[m*qdim+i] = rho[i] * collpiece * invallmass + seg[m*lbsy.nf+i];
    }
  }

  pt2 = NULL;
  pt3 = NULL;  
  pt4 = NULL;  
  return 0;
}

int fSiteFluidCollisionMRTGuoLishchukLocal(double* startpos, double *sitespeed, double *omega, double *omegabulk, double *rho, double* bodyforce, double* phaseindex, int threed)
{

  // MRT collision of achromatic fluid and D'Ortona segregation
  // calculate interfacial forcing terms and collisions at grid point:
  // using MRT schemes with Guo-like source terms for fluids only
  // (BGK collisions used for solutes and heat transfers)

  double speed[3], force[3], meq[lbsy.nq];
  double allmass, invallmass, omegat, omegabulkt, ex, ey, ez, nx, ny, nz;
  double forceconst, segcomp, segpiece, collpiece;
  double seg[lbsy.nf*lbsy.nq], lbfac[lbsy.nq], moment[lbsy.nq], collide[lbsy.nq], source[lbsy.nq], phaseforce[lbsy.nq];
  double *pt2 = &startpos[0];
  double *pt3 = &bodyforce[0];
  double *pt4 = &phaseindex[0];
  int numpair = lbsy.nf*(lbsy.nf-1)/2;
  int qdim = lbsy.nf+lbsy.nc+lbsy.nt;

  // collision of achromatic fluid

  allmass = 0.0;
  omegat = 0.0;
  omegabulkt = 0.0;

  for(int j=0; j<lbsy.nf; j++) {
    allmass += rho[j];
    omegat += omega[j] * rho[j];
    omegabulkt += omegabulk[j] * rho[j];
  }

  invallmass = fReciprocal(allmass);
  omegat *= invallmass;
  omegabulkt *= invallmass;
    
  for(int i=0; i<lbsy.nq; i++) {
    lbfac[i] = 0.0;
    phaseforce[i] = 0.0;
    for(int j=0; j<lbsy.nf; j++) {
      lbfac[i] += pt2[i*qdim+j];
      seg[i*lbsy.nf+j] = 0.0;
    }
  }

  // calculate local forcing and segregation terms
    
  for(int k=0; k<numpair; k++) {
    int i = lbspair[2*k  ];
    int j = lbspair[2*k+1];
    nx = pt4[3*k  ];
    ny = pt4[3*k+1];
    nz = pt4[3*k+2];
    forceconst = lbseg[lbsy.nf*j+i] * lbg[lbsy.nf*j+i] * rho[i] * rho[j];
    segpiece = lbseg[lbsy.nf*j+i] * rho[i] * rho[j] * invallmass * invallmass;
    for(int m=0; m<lbsy.nq; m++) {
      ex = lbvx[m];
      ey = lbvy[m];
      ez = lbvz[m];
      phaseforce[m] += forceconst * ((nx*nx-1.0)*(ex*ex-lbcssq) + (ny*ny-1.0)*(ey*ey-lbcssq) + 2.0*nx*ny*ex*ey
                     + threed*((nz*nz-1.0)*(ez*ez-lbcssq) + 2.0*nz*ez*(nx*ex+ny*ey)));
      segcomp = segpiece * (lbvwx[m]*nx + lbvwy[m]*ny + lbvwz[m]*nz);
      seg[m*lbsy.nf+i] += segcomp;
      seg[m*lbsy.nf+j] -= segcomp;
    }
  }

  // collide and segregate fluids
    
  force[0] = pt3[0];
  force[1] = pt3[1];
  force[2] = pt3[2];
  speed[0] = allmass * sitespeed[0] + 0.5 * force[0];
  speed[1] = allmass * sitespeed[1] + 0.5 * force[1];
  speed[2] = allmass * sitespeed[2] + 0.5 * force[2];

  fGetMomentEquilibriumF(&meq[0], speed, allmass);
  speed[0] *= invallmass;
  speed[1] *= invallmass;
  speed[2] *= invallmass;
  forceconst = omegat * invallmass * invallmass * invallmass * lbrcssq * lbrcssq;

  fGetMomentForceGuo(source, speed, force);
  fGetMRTCollide(collide, omegat, omegabulkt);
  for(int i=0; i<lbsy.nq; i++) {
    moment[i] = 0.0;
    for(int j=0; j<lbsy.nq; j++) {
      moment[i] += lbfac[j] * lbtr[i*lbsy.nq+j];
    }
    moment[i] = collide[i] * (meq[i] - moment[i]) + (1.0 - 0.5 * collide[i]) * source[i];
  }
  for(int m=0; m<lbsy.nq; m++) {
    collpiece = lbfac[m] + lbw[m]*forceconst*phaseforce[m];
    for(int j=0; j<lbsy.nq; j++) {
      collpiece += moment[j] * lbtrinv[m*lbsy.nq+j];
    }
    for(int i=0; i<lbsy.nf; i++) {
      pt2[m*qdim+i] = rho[i] * collpiece * invallmass + seg[m*lbsy.nf+i];
    }
  }

  pt2 = NULL;
  pt3 = NULL;  
  pt4 = NULL;  
  return 0;
}

int fSiteFluidIncomCollisionMRTGuoLishchukLocal(double* startpos, double *sitespeed, double *omega, double *omegabulk, double *rho, double* bodyforce, double* phaseindex, int threed)
{

  // MRT collision of achromatic fluid and D'Ortona segregation
  // calculate interfacial forcing terms and collisions at grid point:
  // using MRT schemes with Guo-like source terms for incompressible fluids only
  // (BGK collisions used for solutes and heat transfers)

  double speed[3], force[3], meq[lbsy.nq];
  double allmass, invallmass, density, invdensity, omegat, omegabulkt, ex, ey, ez, nx, ny, nz;
  double forceconst, segcomp, segpiece, collpiece;
  double seg[lbsy.nf*lbsy.nq], lbfac[lbsy.nq], moment[lbsy.nq], collide[lbsy.nq], source[lbsy.nq], phaseforce[lbsy.nq];
  double *pt2 = &startpos[0];
  double *pt3 = &bodyforce[0];
  double *pt4 = &phaseindex[0];
  int numpair = lbsy.nf*(lbsy.nf-1)/2;
  int qdim = lbsy.nf+lbsy.nc+lbsy.nt;

  // collision of achromatic fluid

  fGetAllMassSite(rho, pt2);
  allmass = 0.0;
  omegat = 0.0;
  omegabulkt = 0.0;
  density = 0.0;

  for(int j=0; j<lbsy.nf; j++) {
    allmass += rho[j];
    omegat += omega[j] * rho[j];
    omegabulkt += omegabulk[j] * rho[j];
    density += lbincp[j] * rho[j];
  }
    
  invallmass = fReciprocal(allmass);
  omegat *= invallmass;
  omegabulkt *= invallmass;
  density *= invallmass;
    
  for(int i=0; i<lbsy.nq; i++) {
    lbfac[i] = 0.0;
    phaseforce[i] = 0.0;
    for(int j=0; j<lbsy.nf; j++) {
      lbfac[i] += pt2[i*qdim+j];
      seg[i*lbsy.nf+j] = 0.0;
    }
  }

  // calculate local forcing and segregation terms
    
  for(int k=0; k<numpair; k++) {
    int i = lbspair[2*k  ];
    int j = lbspair[2*k+1];
    nx = pt4[3*k  ];
    ny = pt4[3*k+1];
    nz = pt4[3*k+2];
    forceconst = lbseg[lbsy.nf*j+i] * lbg[lbsy.nf*j+i] * rho[i] * rho[j];
    segpiece = lbseg[lbsy.nf*j+i] * rho[i] * rho[j] * invallmass * invallmass;
    for(int m=0; m<lbsy.nq; m++) {
      ex = lbvx[m];
      ey = lbvy[m];
      ez = lbvz[m];
      phaseforce[m] += forceconst * ((nx*nx-1.0)*(ex*ex-lbcssq) + (ny*ny-1.0)*(ey*ey-lbcssq) + 2.0*nx*ny*ex*ey
                     + threed*((nz*nz-1.0)*(ez*ez-lbcssq) + 2.0*nz*ez*(nx*ex+ny*ey)));
      segcomp = segpiece * (lbvwx[m]*nx + lbvwy[m]*ny + lbvwz[m]*nz);
      seg[m*lbsy.nf+i] += segcomp;
      seg[m*lbsy.nf+j] -= segcomp;
    }
  }

  // collide and segregate fluids
    
  force[0] = pt3[0];
  force[1] = pt3[1];
  force[2] = pt3[2];
  speed[0] = density * sitespeed[0] + 0.5 * force[0];
  speed[1] = density * sitespeed[1] + 0.5 * force[1];
  speed[2] = density * sitespeed[2] + 0.5 * force[2];

  fGetMomentEquilibriumFIncom(&meq[0], speed, allmass, density);
  invdensity = fReciprocal(density);
  speed[0] *= invdensity;
  speed[1] *= invdensity;
  speed[2] *= invdensity;
  forceconst = omegat * invallmass * invallmass * lbrcssq * lbrcssq * invdensity;

  fGetMomentForceGuo(source, speed, force);
  fGetMRTCollide(collide, omegat, omegabulkt);
  for(int i=0; i<lbsy.nq; i++) {
    moment[i] = 0.0;
    for(int j=0; j<lbsy.nq; j++) {
      moment[i] += lbfac[j] * lbtr[i*lbsy.nq+j];
    }
    moment[i] = collide[i] * (meq[i] - moment[i]) + (1.0 - 0.5 * collide[i]) * source[i];
  }
  for(int m=0; m<lbsy.nq; m++) {
    collpiece = lbfac[m] + lbw[m]*forceconst*phaseforce[m];
    for(int j=0; j<lbsy.nq; j++) {
      collpiece += moment[j] * lbtrinv[m*lbsy.nq+j];
    }
    for(int i=0; i<lbsy.nf; i++) {
      pt2[m*qdim+i] = rho[i] * collpiece * invallmass + seg[m*lbsy.nf+i];
    }
  }

  pt2 = NULL;
  pt3 = NULL;  
  pt4 = NULL;  
  return 0;
}

int fSiteFluidCollisionMRTHeLishchukLocal(double* startpos, double *sitespeed, double *omega, double *omegabulk, double *rho, double* bodyforce, double* phaseindex, int threed)
{

  // MRT collision of achromatic fluid and D'Ortona segregation
  // calculate interfacial forcing terms and collisions at grid point:
  // using MRT schemes with He-like source terms for fluids only
  // (BGK collisions used for solutes and heat transfers)

  double speed[3], force[3], meq[lbsy.nq];
  double allmass, invallmass, omegat, omegabulkt, ex, ey, ez, nx, ny, nz;
  double forceconst, segcomp, segpiece, collpiece;
  double seg[lbsy.nf*lbsy.nq], lbfac[lbsy.nq], moment[lbsy.nq], collide[lbsy.nq], source[lbsy.nq], phaseforce[lbsy.nq];
  double *pt2 = &startpos[0];
  double *pt3 = &bodyforce[0];
  double *pt4 = &phaseindex[0];
  int numpair = lbsy.nf*(lbsy.nf-1)/2;
  int qdim = lbsy.nf+lbsy.nc+lbsy.nt;

  // collision of achromatic fluid

  allmass = 0.0;
  omegat = 0.0;
  omegabulkt = 0.0;

  for(int j=0; j<lbsy.nf; j++) {
    allmass += rho[j];
    omegat += omega[j] * rho[j];
    omegabulkt += omegabulk[j] * rho[j];
  }

  invallmass = fReciprocal(allmass);
  omegat *= invallmass;
  omegabulkt *= invallmass;
    
  for(int i=0; i<lbsy.nq; i++) {
    lbfac[i] = 0.0;
    phaseforce[i] = 0.0;
    for(int j=0; j<lbsy.nf; j++) {
      lbfac[i] += pt2[i*qdim+j];
      seg[i*lbsy.nf+j] = 0.0;
    }
  }

  // calculate local forcing and segregation terms
    
  for(int k=0; k<numpair; k++) {
    int i = lbspair[2*k  ];
    int j = lbspair[2*k+1];
    nx = pt4[3*k  ];
    ny = pt4[3*k+1];
    nz = pt4[3*k+2];
    forceconst = lbseg[lbsy.nf*j+i] * lbg[lbsy.nf*j+i] * rho[i] * rho[j];
    segpiece = lbseg[lbsy.nf*j+i] * rho[i] * rho[j] * invallmass * invallmass;
    for(int m=0; m<lbsy.nq; m++) {
      ex = lbvx[m];
      ey = lbvy[m];
      ez = lbvz[m];
      phaseforce[m] += forceconst * ((nx*nx-1.0)*(ex*ex-lbcssq) + (ny*ny-1.0)*(ey*ey-lbcssq) + 2.0*nx*ny*ex*ey
                     + threed*((nz*nz-1.0)*(ez*ez-lbcssq) + 2.0*nz*ez*(nx*ex+ny*ey)));
      segcomp = segpiece * (lbvwx[m]*nx + lbvwy[m]*ny + lbvwz[m]*nz);
      seg[m*lbsy.nf+i] += segcomp;
      seg[m*lbsy.nf+j] -= segcomp;
    }
  }

  // collide and segregate fluids
    
  force[0] = pt3[0];
  force[1] = pt3[1];
  force[2] = pt3[2];
  speed[0] = allmass * sitespeed[0] + 0.5 * force[0];
  speed[1] = allmass * sitespeed[1] + 0.5 * force[1];
  speed[2] = allmass * sitespeed[2] + 0.5 * force[2];

  fGetMomentEquilibriumF(&meq[0], speed, allmass);
  speed[0] *= invallmass;
  speed[1] *= invallmass;
  speed[2] *= invallmass;
  forceconst = omegat * invallmass * invallmass * invallmass * lbrcssq * lbrcssq;

  fGetMomentForceHe(source, speed, force);
  fGetMRTCollide(collide, omegat, omegabulkt);
  for(int i=0; i<lbsy.nq; i++) {
    moment[i] = 0.0;
    for(int j=0; j<lbsy.nq; j++) {
      moment[i] += lbfac[j] * lbtr[i*lbsy.nq+j];
    }
    moment[i] = collide[i] * (meq[i] - moment[i]) + (1.0 - 0.5 * collide[i]) * source[i];
  }
  for(int m=0; m<lbsy.nq; m++) {
    collpiece = lbfac[m] + lbw[m]*forceconst*phaseforce[m];
    for(int j=0; j<lbsy.nq; j++) {
      collpiece += moment[j] * lbtrinv[m*lbsy.nq+j];
    }
    for(int i=0; i<lbsy.nf; i++) {
      pt2[m*qdim+i] = rho[i] * collpiece * invallmass + seg[m*lbsy.nf+i];
    }
  }

  pt2 = NULL;
  pt3 = NULL;
  pt4 = NULL;
  return 0;
}

int fSiteFluidIncomCollisionMRTHeLishchukLocal(double* startpos, double *sitespeed, double *omega, double *omegabulk, double *rho, double* bodyforce, double* phaseindex, int threed)
{

  // MRT collision of achromatic fluid and D'Ortona segregation
  // calculate interfacial forcing terms and collisions at grid point:
  // using MRT schemes with He-like source terms for incompressible fluids only
  // (BGK collisions used for solutes and heat transfers)

  double speed[3], force[3], meq[lbsy.nq];
  double allmass, invallmass, density, invdensity, omegat, omegabulkt, ex, ey, ez, nx, ny, nz;
  double forceconst, segcomp, segpiece, collpiece;
  double seg[lbsy.nf*lbsy.nq], lbfac[lbsy.nq], moment[lbsy.nq], collide[lbsy.nq], source[lbsy.nq], phaseforce[lbsy.nq];
  double *pt2 = &startpos[0];
  double *pt3 = &bodyforce[0];
  double *pt4 = &phaseindex[0];
  int numpair = lbsy.nf*(lbsy.nf-1)/2;
  int qdim = lbsy.nf+lbsy.nc+lbsy.nt;

  // collision of achromatic fluid

  fGetAllMassSite(rho, pt2);
  allmass = 0.0;
  omegat = 0.0;
  omegabulkt = 0.0;
  density = 0.0;

  for(int j=0; j<lbsy.nf; j++) {
    allmass += rho[j];
    omegat += omega[j] * rho[j];
    omegabulkt += omegabulk[j] * rho[j];
    density += lbincp[j] * rho[j];
  }
    
  invallmass = fReciprocal(allmass);
  omegat *= invallmass;
  omegabulkt *= invallmass;
  density *= invallmass;
    
  for(int i=0; i<lbsy.nq; i++) {
    lbfac[i] = 0.0;
    phaseforce[i] = 0.0;
    for(int j=0; j<lbsy.nf; j++) {
      lbfac[i] += pt2[i*qdim+j];
      seg[i*lbsy.nf+j] = 0.0;
    }
  }

  // calculate local forcing and segregation terms
    
  for(int k=0; k<numpair; k++) {
    int i = lbspair[2*k  ];
    int j = lbspair[2*k+1];
    nx = pt4[3*k  ];
    ny = pt4[3*k+1];
    nz = pt4[3*k+2];
    forceconst = lbseg[lbsy.nf*j+i] * lbg[lbsy.nf*j+i] * rho[i] * rho[j];
    segpiece = lbseg[lbsy.nf*j+i] * rho[i] * rho[j] * invallmass * invallmass;
    for(int m=0; m<lbsy.nq; m++) {
      ex = lbvx[m];
      ey = lbvy[m];
      ez = lbvz[m];
      phaseforce[m] += forceconst * ((nx*nx-1.0)*(ex*ex-lbcssq) + (ny*ny-1.0)*(ey*ey-lbcssq) + 2.0*nx*ny*ex*ey
                     + threed*((nz*nz-1.0)*(ez*ez-lbcssq) + 2.0*nz*ez*(nx*ex+ny*ey)));
      segcomp = segpiece * (lbvwx[m]*nx + lbvwy[m]*ny + lbvwz[m]*nz);
      seg[m*lbsy.nf+i] += segcomp;
      seg[m*lbsy.nf+j] -= segcomp;
    }
  }

  // collide and segregate fluids
    
  force[0] = pt3[0];
  force[1] = pt3[1];
  force[2] = pt3[2];
  speed[0] = density * sitespeed[0] + 0.5 * force[0];
  speed[1] = density * sitespeed[1] + 0.5 * force[1];
  speed[2] = density * sitespeed[2] + 0.5 * force[2];

  fGetMomentEquilibriumFIncom(&meq[0], speed, allmass, density);
  invdensity = fReciprocal(density);
  speed[0] *= invdensity;
  speed[1] *= invdensity;
  speed[2] *= invdensity;
  forceconst = omegat * invallmass * invallmass * lbrcssq * lbrcssq * invdensity;

  fGetMomentForceHe(source, speed, force);
  fGetMRTCollide(collide, omegat, omegabulkt);
  for(int i=0; i<lbsy.nq; i++) {
    moment[i] = 0.0;
    for(int j=0; j<lbsy.nq; j++) {
      moment[i] += lbfac[j] * lbtr[i*lbsy.nq+j];
    }
    moment[i] = collide[i] * (meq[i] - moment[i]) + (1.0 - 0.5 * collide[i]) * source[i];
  }
  for(int m=0; m<lbsy.nq; m++) {
    collpiece = lbfac[m] + lbw[m]*forceconst*phaseforce[m];
    for(int j=0; j<lbsy.nq; j++) {
      collpiece += moment[j] * lbtrinv[m*lbsy.nq+j];
    }
    for(int i=0; i<lbsy.nf; i++) {
      pt2[m*qdim+i] = rho[i] * collpiece * invallmass + seg[m*lbsy.nf+i];
    }
  }

  pt2 = NULL;
  pt3 = NULL;
  pt4 = NULL;
  return 0;
}

// Swift free-energy collisions

int fSiteFluidCollisionMRTSwiftOneFluid(double* startpos, double *sitespeed, double *omega, double *omegabulk, double *rho, double* gradient, double* bodyforce, double T)
{
  
  // calculate fluid collisions at grid point: uses MRT schemes
  // and Swift free-energy interactions for one fluid

  double speed[3], meq[lbsy.nq];
  double moment[lbsy.nq], collide[lbsy.nq];
  double relax, pb, lambda;
  double *pt2 = &startpos[0];
  double *pt3 = &gradient[0];
  double *pt4 = &bodyforce[0];
  int qdim = lbsy.nf+lbsy.nc+lbsy.nt;

  pb = fGetBulkPressureSwift(rho[0], 0.0, T);
  lambda = fGetLambdaSwift(rho[0], omega[0], T);
    
  relax = fReciprocal(omega[0]);
  speed[0] = rho[0] * sitespeed[0] + pt4[0] * relax;
  speed[1] = rho[0] * sitespeed[1] + pt4[1] * relax;
  speed[2] = rho[0] * sitespeed[2] + pt4[2] * relax;
  fGetMomentEquilibriumFSwiftOneFluid(&meq[0], speed, rho[0], pb, lambda, pt3);
  fGetMRTCollide(collide, omega[0], omegabulk[0]);
  for(int i=0; i<lbsy.nq; i++) {
    moment[i] = 0.0;
    for(int j=0; j<lbsy.nq; j++) {
      moment[i] += pt2[j*qdim] * lbtr[i*lbsy.nq+j];
    }
    moment[i] = collide[i] * (meq[i] - moment[i]);
  }
  for(int i=0; i<lbsy.nq; i++) {
    for(int j=0; j<lbsy.nq; j++) {
      pt2[i*qdim] += moment[j] * lbtrinv[i*lbsy.nq+j];
    }
  }

  pt2 = NULL;
  pt3 = NULL;
  pt4 = NULL;
  return 0;
}

int fSiteFluidCollisionMRTSwiftTwoFluid(double* startpos, double *sitespeed, double *omega, double *omegabulk, double *rho, double* gradient, double* bodyforce, double T)
{
  
  // calculate fluid collisions at grid point: uses MRT schemes
  // and Swift free-energy interactions for two fluids (MRT for
  // density distribution, BGK for concentration distribution)

  double speed[3], meq[2*lbsy.nq];
  double moment[lbsy.nq], collide[lbsy.nq];
  double omegat, omegabulkt, relax, relaxphi, pb, mu, lambda;
  double *pt2 = &startpos[0];
  double *pt3 = &gradient[0];
  double *pt4 = &bodyforce[0];
  int qdim = lbsy.nf+lbsy.nc+lbsy.nt;

  omegat = 2.0*omega[0]*omega[1]/(2.0*omega[0]+(1.0+rho[1])*(omega[1]-omega[0]));
  omegabulkt = 2.0*omegabulk[0]*omegabulk[1]/(2.0*omegabulk[0]+(1.0+rho[1])*(omegabulk[1]-omegabulk[0]));
  pb = fGetBulkPressureSwift(rho[0], rho[1], T);
  lambda = fGetLambdaSwift(rho[0], omegat, T);
  mu = fGetPotentialSwift(rho[1], pt3[7]);

  relax = fReciprocal(omegat);
  relaxphi = 1.0 - lbtmob;
  speed[0] = rho[0] * sitespeed[0] + pt4[0] * relax;
  speed[1] = rho[0] * sitespeed[1] + pt4[1] * relax;
  speed[2] = rho[0] * sitespeed[2] + pt4[2] * relax;
  fGetMomentEquilibriumFSwiftTwoFluid(&meq[0], speed, rho[0], rho[1], pb, mu, lambda, pt3);
  fGetMRTCollide(collide, omegat, omegabulkt);
  for(int i=0; i<lbsy.nq; i++) {
    moment[i] = 0.0;
    for(int j=0; j<lbsy.nq; j++) {
      moment[i] += pt2[j*qdim] * lbtr[i*lbsy.nq+j];
    }
    moment[i] = collide[i] * (meq[i] - moment[i]);
  }
  for(int i=0; i<lbsy.nq; i++) {
    for(int j=0; j<lbsy.nq; j++) {
      pt2[i*qdim] += moment[j] * lbtrinv[i*lbsy.nq+j];
    }
    pt2[i*qdim+1] = relaxphi * pt2[i*qdim+1] + meq[lbsy.nq+i]*lbtmob;
  }

  pt2 = NULL;
  pt3 = NULL;
  pt4 = NULL;
  return 0;
}

int fSiteFluidCollisionMRTEDMSwiftOneFluid(double* startpos, double *sitespeed, double *omega, double *omegabulk, double *rho, double* gradient, double* bodyforce, double T)
{
  
  // calculate fluid collisions at grid point: uses MRT schemes with
  // Exact Difference Method forcing term and Swift free-energy
  // interactions for one fluid

  double dv[3], meq[lbsy.nq], moment[lbsy.nq], collide[lbsy.nq];
  double invmass, source;
  double modv,eixux,eiyuy,eizuz,eixdux,eiyduy,eizduz;
  double pb, lambda;
  double *pt2 = &startpos[0];
  double *pt3 = &gradient[0];
  double *pt4 = &bodyforce[0];
  int qdim = lbsy.nf+lbsy.nc+lbsy.nt;

  pb = fGetBulkPressureSwift(rho[0], 0.0, T);
  lambda = fGetLambdaSwift(rho[0], omega[0], T);

  invmass = fReciprocal(rho[0]);
  dv[0] = pt4[0] * invmass;
  dv[1] = pt4[1] * invmass;
  dv[2] = pt4[2] * invmass;
  fGetMomentEquilibriumFSwiftOneFluid(&meq[0], sitespeed, rho[0], pb, lambda, pt3);
  fGetMRTCollide(collide, omega[0], omegabulk[0]);
  modv = dv[0]*(2.0*sitespeed[0]+dv[0]) + dv[1]*(2.0*sitespeed[1]+dv[1]) + dv[2]*(2.0*sitespeed[2]+dv[2]);
  for(int i=0; i<lbsy.nq; i++) {
    moment[i] = 0;
    for(int j=0; j<lbsy.nq; j++) {
      moment[i] += pt2[j*qdim] * lbtr[i*lbsy.nq+j];
    }
    moment[i] = collide[i] * (meq[i] - moment[i]);
  }
  for(int i=0; i<lbsy.nq; i++) {
    eixux =  lbvx[i]*sitespeed[0];
    eiyuy =  lbvy[i]*sitespeed[1];
    eizuz =  lbvz[i]*sitespeed[2];
    eixdux = lbvx[i]*dv[0];
    eiyduy = lbvy[i]*dv[1];
    eizduz = lbvz[i]*dv[2];
    source = rho[0] * lbw[i] * (3.0 * (eixdux+eiyduy+eizduz) +
                                4.5 * (eixdux*(eixdux+2.0*(eixux+eiyuy+eizuz+eiyduy+eizduz)) +
                                       eiyduy*(eiyduy+2.0*(eixux+eiyuy+eizuz+eizduz)) +
                                       eizduz*(eizduz+2.0*(eixux+eiyuy+eizuz))) -
                                1.5 * modv);
    for(int j=0; j<lbsy.nq; j++) {
      pt2[i*qdim] += moment[j] * lbtrinv[i*lbsy.nq+j];
    }
    pt2[i*qdim] += source;
  }

  pt2 = NULL;
  pt3 = NULL;
  pt4 = NULL;
  return 0;
}

int fSiteFluidCollisionMRTEDMSwiftTwoFluid(double* startpos, double *sitespeed, double *omega, double *omegabulk, double *rho, double* gradient, double* bodyforce, double T)
{
  
  // calculate fluid collisions at grid point: uses MRT schemes with
  // Exact Difference Method forcing term and Swift free-energy
  // interactions for two fluids (MRT for density distribution,
  // BGK for concentration distribution)

  double dv[3], meq[lbsy.nq], moment[2*lbsy.nq], collide[lbsy.nq];
  double invmass, source;
  double modv,eixux,eiyuy,eizuz,eixdux,eiyduy,eizduz;
  double omegat, omegabulkt, relaxphi, pb, mu, lambda;
  double *pt2 = &startpos[0];
  double *pt3 = &gradient[0];
  double *pt4 = &bodyforce[0];
  int qdim = lbsy.nf+lbsy.nc+lbsy.nt;

  omegat = 2.0*omega[0]*omega[1]/(2.0*omega[0]+(1.0+rho[1])*(omega[1]-omega[0]));
  omegabulkt = 2.0*omegabulk[0]*omegabulk[1]/(2.0*omegabulk[0]+(1.0+rho[1])*(omegabulk[1]-omegabulk[0]));
  pb = fGetBulkPressureSwift(rho[0], rho[1], T);
  lambda = fGetLambdaSwift(rho[0], omegat, T);
  mu = fGetPotentialSwift(rho[1], pt3[7]);

  invmass = fReciprocal(rho[0]);
  dv[0] = pt4[0] * invmass;
  dv[1] = pt4[1] * invmass;
  dv[2] = pt4[2] * invmass;
  relaxphi = 1.0 - lbtmob;
  fGetMomentEquilibriumFSwiftTwoFluid(&meq[0], sitespeed, rho[0], rho[1], pb, mu, lambda, pt3);
  fGetMRTCollide(collide, omegat, omegabulkt);
  modv = dv[0]*(2.0*sitespeed[0]+dv[0]) + dv[1]*(2.0*sitespeed[1]+dv[1]) + dv[2]*(2.0*sitespeed[2]+dv[2]);
  for(int i=0; i<lbsy.nq; i++) {
    moment[i] = 0.0;
    for(int j=0; j<lbsy.nq; j++) {
      moment[i] += pt2[j*qdim] * lbtr[i*lbsy.nq+j];
    }
    moment[i] = collide[i] * (meq[i] - moment[i]);
  }
  for(int i=0; i<lbsy.nq; i++) {
    eixux =  lbvx[i]*sitespeed[0];
    eiyuy =  lbvy[i]*sitespeed[1];
    eizuz =  lbvz[i]*sitespeed[2];
    eixdux = lbvx[i]*dv[0];
    eiyduy = lbvy[i]*dv[1];
    eizduz = lbvz[i]*dv[2];
    source = rho[0] * lbw[i] * (3.0 * (eixdux+eiyduy+eizduz) +
                                4.5 * (eixdux*(eixdux+2.0*(eixux+eiyuy+eizuz+eiyduy+eizduz)) +
                                       eiyduy*(eiyduy+2.0*(eixux+eiyuy+eizuz+eizduz)) +
                                       eizduz*(eizduz+2.0*(eixux+eiyuy+eizuz))) -
                                1.5 * modv);
    for(int j=0; j<lbsy.nq; j++) {
      pt2[i*qdim] += moment[j] * lbtrinv[i*lbsy.nq+j];
    }
    pt2[i*qdim  ] += source;
    pt2[i*qdim+1] = relaxphi * pt2[i*qdim+1] + meq[lbsy.nq+i]*lbtmob;
  }

  pt2 = NULL;
  pt3 = NULL;
  pt4 = NULL;
  return 0;
}

int fSiteFluidCollisionMRTGuoSwiftOneFluid(double* startpos, double *sitespeed, double *omega, double *omegabulk, double *rho, double* gradient, double* bodyforce, double T)
{
  
  // calculate collisions at grid point: uses MRT schemes with Guo-like source terms
  // and Swift free-energy interactions for one fluid

  double speed[3], force[3], meq[lbsy.nq];
  double moment[lbsy.nq], collide[lbsy.nq], source[lbsy.nq];
  double invmass, pb, lambda;
  double *pt2 = &startpos[0];
  double *pt3 = &gradient[0];
  double *pt4 = &bodyforce[0];
  int qdim = lbsy.nf+lbsy.nc+lbsy.nt;

  pb = fGetBulkPressureSwift(rho[0], 0.0, T);
  lambda = fGetLambdaSwift(rho[0], omega[0], T);

  invmass = fReciprocal(rho[0]);
  force[0] = pt4[0];
  force[1] = pt4[1];
  force[2] = pt4[2];
  speed[0] = rho[0] * sitespeed[0] + 0.5 * force[0];
  speed[1] = rho[0] * sitespeed[1] + 0.5 * force[1];
  speed[2] = rho[0] * sitespeed[2] + 0.5 * force[2];
  fGetMomentEquilibriumFSwiftOneFluid(&meq[0], speed, rho[0], pb, lambda, pt3);
  speed[0] *= invmass;
  speed[1] *= invmass;
  speed[2] *= invmass;
  fGetMomentForceGuo(source, speed, force);
  fGetMRTCollide(collide, omega[0], omegabulk[0]);
  for(int i=0; i<lbsy.nq; i++) {
    moment[i] = 0.0;
    for(int j=0; j<lbsy.nq; j++) {
      moment[i] += pt2[j*qdim] * lbtr[i*lbsy.nq+j];
    }
    moment[i] = collide[i] * (meq[i] - moment[i]) + (1.0 - 0.5 * collide[i]) * source[i];
  }
  for(int i=0; i<lbsy.nq; i++) {
    for(int j=0; j<lbsy.nq; j++) {
      pt2[i*qdim] += moment[j] * lbtrinv[i*lbsy.nq+j];
    }
  }

  pt2 = NULL;
  pt3 = NULL;
  pt4 = NULL;
  return 0;
}

int fSiteFluidCollisionMRTGuoSwiftTwoFluid(double* startpos, double *sitespeed, double *omega, double *omegabulk, double *rho, double* gradient, double* bodyforce, double T)
{
  
  // calculate collisions at grid point: uses MRT schemes with Guo-like source terms
  // and Swift free-energy interactions for two fluids (MRT for density distribution,
  // BGK for concentration distribution)

  double speed[3], force[3], meq[lbsy.nq];
  double moment[lbsy.nq], collide[lbsy.nq], source[lbsy.nq];
  double invmass, omegat, omegabulkt, relaxphi, pb, mu, lambda;
  double *pt2 = &startpos[0];
  double *pt3 = &gradient[0];
  double *pt4 = &bodyforce[0];
  int qdim = lbsy.nf+lbsy.nc+lbsy.nt;

  omegat = 2.0*omega[0]*omega[1]/(2.0*omega[0]+(1.0+rho[1])*(omega[1]-omega[0]));
  omegabulkt = 2.0*omegabulk[0]*omegabulk[1]/(2.0*omegabulk[0]+(1.0+rho[1])*(omegabulk[1]-omegabulk[0]));
  pb = fGetBulkPressureSwift(rho[0], rho[1], T);
  lambda = fGetLambdaSwift(rho[0], omegat, T);
  mu = fGetPotentialSwift(rho[1], pt3[7]);

  invmass = fReciprocal(rho[0]);
  force[0] = pt4[0];
  force[1] = pt4[1];
  force[2] = pt4[2];
  speed[0] = rho[0] * sitespeed[0] + 0.5 * force[0];
  speed[1] = rho[0] * sitespeed[1] + 0.5 * force[1];
  speed[2] = rho[0] * sitespeed[2] + 0.5 * force[2];
  fGetMomentEquilibriumFSwiftTwoFluid(&meq[0], speed, rho[0], rho[1], pb, mu, lambda, pt3);
  speed[0] *= invmass;
  speed[1] *= invmass;
  speed[2] *= invmass;
  fGetMomentForceGuo(source, speed, force);
  fGetMRTCollide(collide, omegat, omegabulkt);
  relaxphi = 1.0 - lbtmob;
  for(int i=0; i<lbsy.nq; i++) {
    moment[i] = 0.0;
    for(int j=0; j<lbsy.nq; j++) {
      moment[i] += pt2[j*qdim] * lbtr[i*lbsy.nq+j];
    }
    moment[i] = collide[i] * (meq[i] - moment[i]) + (1.0 - 0.5 * collide[i]) * source[i];
  }
  for(int i=0; i<lbsy.nq; i++) {
    for(int j=0; j<lbsy.nq; j++) {
      pt2[i*qdim] += moment[j] * lbtrinv[i*lbsy.nq+j];
    }
    pt2[i*qdim+1] = relaxphi * pt2[i*qdim+1] + meq[lbsy.nq+i]*lbtmob;
  }

  pt2 = NULL;
  pt3 = NULL;
  pt4 = NULL;
  return 0;
}

int fSiteFluidCollisionMRTHeSwiftOneFluid(double* startpos, double *sitespeed, double *omega, double *omegabulk, double *rho, double* gradient, double* bodyforce, double T)
{
  
  // calculate collisions at grid point: uses MRT schemes with He-like source terms
  // and Swift free-energy interactions for one fluid

  double speed[3], force[3], meq[lbsy.nq];
  double moment[lbsy.nq], collide[lbsy.nq], source[lbsy.nq];
  double invmass, pb, lambda;
  double *pt2 = &startpos[0];
  double *pt3 = &gradient[0];
  double *pt4 = &bodyforce[0];
  int qdim = lbsy.nf+lbsy.nc+lbsy.nt;

  pb = fGetBulkPressureSwift(rho[0], 0.0, T);
  lambda = fGetLambdaSwift(rho[0], omega[0], T);

  invmass = fReciprocal(rho[0]);
  force[0] = pt4[0];
  force[1] = pt4[1];
  force[2] = pt4[2];
  speed[0] = rho[0] * sitespeed[0] + 0.5 * force[0];
  speed[1] = rho[0] * sitespeed[1] + 0.5 * force[1];
  speed[2] = rho[0] * sitespeed[2] + 0.5 * force[2];
  fGetMomentEquilibriumFSwiftOneFluid(&meq[0], speed, rho[0], pb, lambda, pt3);
  speed[0] *= invmass;
  speed[1] *= invmass;
  speed[2] *= invmass;
  fGetMomentForceHe(source, speed, force);
  fGetMRTCollide(collide, omega[0], omegabulk[0]);
  for(int i=0; i<lbsy.nq; i++) {
    moment[i] = 0.0;
    for(int j=0; j<lbsy.nq; j++) {
      moment[i] += pt2[j*qdim] * lbtr[i*lbsy.nq+j];
    }
    moment[i] = collide[i] * (meq[i] - moment[i]) + (1.0 - 0.5 * collide[i]) * source[i];
  }
  for(int i=0; i<lbsy.nq; i++) {
    for(int j=0; j<lbsy.nq; j++) {
      pt2[i*qdim] += moment[j] * lbtrinv[i*lbsy.nq+j];
    }
  }

  pt2 = NULL;
  pt3 = NULL;
  pt4 = NULL;
  return 0;
}

int fSiteFluidCollisionMRTHeSwiftTwoFluid(double* startpos, double *sitespeed, double *omega, double *omegabulk, double *rho, double* gradient, double* bodyforce, double T)
{
  
  // calculate collisions at grid point: uses MRT schemes with He-like source terms
  // and Swift free-energy interactions for two fluids (MRT for density distribution,
  // BGK for concentration distribution)

  double speed[3], force[3], meq[lbsy.nq];
  double moment[lbsy.nq], collide[lbsy.nq], source[lbsy.nq];
  double invmass, omegat, omegabulkt, relaxphi, pb, mu, lambda;
  double *pt2 = &startpos[0];
  double *pt3 = &gradient[0];
  double *pt4 = &bodyforce[0];
  int qdim = lbsy.nf+lbsy.nc+lbsy.nt;

  omegat = 2.0*omega[0]*omega[1]/(2.0*omega[0]+(1.0+rho[1])*(omega[1]-omega[0]));
  omegabulkt = 2.0*omegabulk[0]*omegabulk[1]/(2.0*omegabulk[0]+(1.0+rho[1])*(omegabulk[1]-omegabulk[0]));
  pb = fGetBulkPressureSwift(rho[0], rho[1], T);
  lambda = fGetLambdaSwift(rho[0], omegat, T);
  mu = fGetPotentialSwift(rho[1], pt3[7]);

  invmass = fReciprocal(rho[0]);
  force[0] = pt4[0];
  force[1] = pt4[1];
  force[2] = pt4[2];
  speed[0] = rho[0] * sitespeed[0] + 0.5 * force[0];
  speed[1] = rho[0] * sitespeed[1] + 0.5 * force[1];
  speed[2] = rho[0] * sitespeed[2] + 0.5 * force[2];
  fGetMomentEquilibriumFSwiftTwoFluid(&meq[0], speed, rho[0], rho[1], pb, mu, lambda, pt3);
  speed[0] *= invmass;
  speed[1] *= invmass;
  speed[2] *= invmass;
  fGetMomentForceHe(source, speed, force);
  fGetMRTCollide(collide, omegat, omegabulkt);
  relaxphi = 1.0 - lbtmob;
  for(int i=0; i<lbsy.nq; i++) {
    moment[i] = 0.0;
    for(int j=0; j<lbsy.nq; j++) {
      moment[i] += pt2[j*qdim] * lbtr[i*lbsy.nq+j];
    }
    moment[i] = collide[i] * (meq[i] - moment[i]) + (1.0 - 0.5 * collide[i]) * source[i];
  }
  for(int i=0; i<lbsy.nq; i++) {
    for(int j=0; j<lbsy.nq; j++) {
      pt2[i*qdim] += moment[j] * lbtrinv[i*lbsy.nq+j];
    }
    pt2[i*qdim+1] = relaxphi * pt2[i*qdim+1] + meq[lbsy.nq+i]*lbtmob;
  }

  pt2 = NULL;
  pt3 = NULL;
  pt4 = NULL;
  return 0;
}

// Collision loops over all grid points

int fCollisionMRT()
{
  long Tmax = lbdm.touter;
  double freq = (lbbdforcetyp==1)*sin(lboscilfreq*(lbcurstep-lbequstep));

  if(!incompress) {

    #pragma omp parallel
    {
      double interforce_t[3*lbsy.nf], sitespeed_t[3], rho_t[lbsy.nf];
      double *interforce = &interforce_t[0];
      double *sitespeed = &sitespeed_t[0];
      double *rho = &rho_t[0];
                                     
      #pragma omp for
      for(long il=0; il<Tmax; il++) {
        if(lbphi[il] != 11) {
          fGetSpeedAllMassSite(sitespeed, rho, &lbf[il*lbsitelength]);
          for(int ll=0; ll<3*lbsy.nf; ll++)
	        interforce[ll] = lbinterforce[il*3*lbsy.nf+ll] + lbheatforce[il*3*lbsy.nf+ll] + postequil*(lbbdforce[ll]+lboscilforce[ll]*freq);
          if(lbphi[il] != 12 && lbphi[il] != 13)
            fSiteFluidCollisionMRT(&lbf[il * lbsitelength], sitespeed, &lbomega[il*lbsy.nf], lbtfbulk, rho, interforce);
          fSiteSoluteCollisionBGK(&lbf[il*lbsitelength + lbsy.nf], sitespeed);
          fSiteThermalCollisionBGK(&lbf[il*lbsitelength + (lbsy.nf+lbsy.nc)], sitespeed);
        }
      }
    }
  }
  else {

    #pragma omp parallel
    {
      double interforce_t[3*lbsy.nf], sitespeed_t[3], rho_t[lbsy.nf];
      double *interforce = &interforce_t[0];
      double *sitespeed = &sitespeed_t[0];
      double *rho = &rho_t[0];
        
      #pragma omp for
      for(long il=0; il<Tmax; il++) {
        if(lbphi[il] != 11) {
          fGetSpeedIncomAllMassSite(sitespeed, rho, &lbf[il*lbsitelength]);
          for(int ll=0; ll<3*lbsy.nf; ll++)
	        interforce[ll] = lbinterforce[il*3*lbsy.nf+ll] + lbheatforce[il*3*lbsy.nf+ll] + postequil*(lbbdforce[ll]+lboscilforce[ll]*freq);
          if(lbphi[il] != 12 && lbphi[il] != 13)
            fSiteFluidIncomCollisionMRT(&lbf[il * lbsitelength], sitespeed, &lbomega[il*lbsy.nf], lbtfbulk, rho, interforce);
          fSiteSoluteCollisionBGK(&lbf[il*lbsitelength + lbsy.nf], sitespeed);
          fSiteThermalCollisionBGK(&lbf[il*lbsitelength + (lbsy.nf+lbsy.nc)], sitespeed);
        }
      }
    }
  }
  return 0;
}

int fCollisionMRTEDM()
{
  long Tmax = lbdm.touter;
  double freq = (lbbdforcetyp==1)*sin(lboscilfreq*(lbcurstep-lbequstep));

  if(!incompress) {

    #pragma omp parallel
    {
      double interforce_t[3*lbsy.nf], sitespeed_t[3], rho_t[lbsy.nf];
      double *interforce = &interforce_t[0];
      double *sitespeed = &sitespeed_t[0];
      double *rho = &rho_t[0];
        
      #pragma omp for
      for(long il=0; il<Tmax; il++) {
        if(lbphi[il] != 11) {
          fGetSpeedAllMassSite(sitespeed, rho, &lbf[il*lbsitelength]);
          for(int ll=0; ll<3*lbsy.nf; ll++)
	        interforce[ll] = lbinterforce[il*3*lbsy.nf+ll] + lbheatforce[il*3*lbsy.nf+ll] + postequil*(lbbdforce[ll]+lboscilforce[ll]*freq);
          if(lbphi[il] != 12 && lbphi[il] != 13)
            fSiteFluidCollisionMRTEDM(&lbf[il * lbsitelength], sitespeed, &lbomega[il*lbsy.nf], lbtfbulk, rho, interforce);
          fSiteSoluteCollisionBGK(&lbf[il*lbsitelength + lbsy.nf], sitespeed);
          fSiteThermalCollisionBGK(&lbf[il*lbsitelength + (lbsy.nf+lbsy.nc)], sitespeed);
        }
      }
    }
  }
  else {

    #pragma omp parallel
    {
      double interforce_t[3*lbsy.nf], sitespeed_t[3], rho_t[lbsy.nf];
      double *interforce = &interforce_t[0];
      double *sitespeed = &sitespeed_t[0];
      double *rho = &rho_t[0];
        
      #pragma omp for
      for(long il=0; il<Tmax; il++) {
        if(lbphi[il] != 11) {
          fGetSpeedIncomAllMassSite(sitespeed, rho, &lbf[il*lbsitelength]);
          for(int ll=0; ll<3*lbsy.nf; ll++)
	        interforce[ll] = lbinterforce[il*3*lbsy.nf+ll] + lbheatforce[il*3*lbsy.nf+ll] + postequil*(lbbdforce[ll]+lboscilforce[ll]*freq);
          if(lbphi[il] != 12 && lbphi[il] != 13)
            fSiteFluidIncomCollisionMRTEDM(&lbf[il * lbsitelength], sitespeed, &lbomega[il*lbsy.nf], lbtfbulk, rho, interforce);
          fSiteSoluteCollisionBGK(&lbf[il*lbsitelength + lbsy.nf], sitespeed);
          fSiteThermalCollisionBGK(&lbf[il*lbsitelength + (lbsy.nf+lbsy.nc)], sitespeed);
        }
      }
    }
                                     
  }
  return 0;
}

int fCollisionMRTGuo()
{
  long Tmax = lbdm.touter;
  double freq = (lbbdforcetyp==1)*sin(lboscilfreq*(lbcurstep-lbequstep));

  if(!incompress) {

    #pragma omp parallel
    {
      double interforce_t[3*lbsy.nf], sitespeed_t[3], rho_t[lbsy.nf];
      double *interforce = &interforce_t[0];
      double *sitespeed = &sitespeed_t[0];
      double *rho = &rho_t[0];
        
      #pragma omp for
      for(long il=0; il<Tmax; il++) {
        if(lbphi[il] != 11) {
          fGetSpeedAllMassSite(sitespeed, rho, &lbf[il*lbsitelength]);
          for(int ll=0; ll<3*lbsy.nf; ll++)
	        interforce[ll] = lbinterforce[il*3*lbsy.nf+ll] + lbheatforce[il*3*lbsy.nf+ll] + postequil*(lbbdforce[ll]+lboscilforce[ll]*freq);
          if(lbphi[il] != 12 && lbphi[il] != 13)
            fSiteFluidCollisionMRTGuo(&lbf[il * lbsitelength], sitespeed, &lbomega[il*lbsy.nf], lbtfbulk, rho, interforce);
          fSiteSoluteCollisionBGK(&lbf[il*lbsitelength + lbsy.nf], sitespeed);
          fSiteThermalCollisionBGK(&lbf[il*lbsitelength + (lbsy.nf+lbsy.nc)], sitespeed);
        }
      }
    }
  }
  else {

    #pragma omp parallel
    {
      double interforce_t[3*lbsy.nf], sitespeed_t[3], rho_t[lbsy.nf];
      double *interforce = &interforce_t[0];
      double *sitespeed = &sitespeed_t[0];
      double *rho = &rho_t[0];
        
      #pragma omp for
      for(long il=0; il<Tmax; il++) {
        if(lbphi[il] != 11) {
          fGetSpeedIncomAllMassSite(sitespeed, rho, &lbf[il*lbsitelength]);
          for(int ll=0; ll<3*lbsy.nf; ll++)
	        interforce[ll] = lbinterforce[il*3*lbsy.nf+ll] + lbheatforce[il*3*lbsy.nf+ll] + postequil*(lbbdforce[ll]+lboscilforce[ll]*freq);
          if(lbphi[il] != 12 && lbphi[il] != 13)
            fSiteFluidIncomCollisionMRTGuo(&lbf[il * lbsitelength], sitespeed, &lbomega[il*lbsy.nf], lbtfbulk, rho, interforce);
          fSiteSoluteCollisionBGK(&lbf[il*lbsitelength + lbsy.nf], sitespeed);
          fSiteThermalCollisionBGK(&lbf[il*lbsitelength + (lbsy.nf+lbsy.nc)], sitespeed);
        }
      }
    }
                                     
  }
  return 0;
}

int fCollisionMRTHe()
{
  long Tmax = lbdm.touter;
  double freq = (lbbdforcetyp==1)*sin(lboscilfreq*(lbcurstep-lbequstep));

  if(!incompress) {

    #pragma omp parallel
    {
      double interforce_t[3*lbsy.nf], sitespeed_t[3], rho_t[lbsy.nf];
      double *interforce = &interforce_t[0];
      double *sitespeed = &sitespeed_t[0];
      double *rho = &rho_t[0];
        
      #pragma omp for
      for(long il=0; il<Tmax; il++) {
        if(lbphi[il] != 11) {
          fGetSpeedAllMassSite(sitespeed, rho, &lbf[il*lbsitelength]);
          for(int ll=0; ll<3*lbsy.nf; ll++)
	        interforce[ll] = lbinterforce[il*3*lbsy.nf+ll] + lbheatforce[il*3*lbsy.nf+ll] + postequil*(lbbdforce[ll]+lboscilforce[ll]*freq);
          if(lbphi[il] != 12 && lbphi[il] != 13)
            fSiteFluidCollisionMRTHe(&lbf[il * lbsitelength], sitespeed, &lbomega[il*lbsy.nf], lbtfbulk, rho, interforce);
          fSiteSoluteCollisionBGK(&lbf[il*lbsitelength + lbsy.nf], sitespeed);
          fSiteThermalCollisionBGK(&lbf[il*lbsitelength + (lbsy.nf+lbsy.nc)], sitespeed);
        }
      }
    }
  }
  else {

    #pragma omp parallel
    {
      double interforce_t[3*lbsy.nf], sitespeed_t[3], rho_t[lbsy.nf];
      double *interforce = &interforce_t[0];
      double *sitespeed = &sitespeed_t[0];
      double *rho = &rho_t[0];
        
      #pragma omp for
      for(long il=0; il<Tmax; il++) {
        if(lbphi[il] != 11) {
          fGetSpeedIncomAllMassSite(sitespeed, rho, &lbf[il*lbsitelength]);
          for(int ll=0; ll<3*lbsy.nf; ll++)
	        interforce[ll] = lbinterforce[il*3*lbsy.nf+ll] + lbheatforce[il*3*lbsy.nf+ll] + postequil*(lbbdforce[ll]+lboscilforce[ll]*freq);
          if(lbphi[il] != 12 && lbphi[il] != 13)
            fSiteFluidIncomCollisionMRTHe(&lbf[il * lbsitelength], sitespeed, &lbomega[il*lbsy.nf], lbtfbulk, rho, interforce);
          fSiteSoluteCollisionBGK(&lbf[il*lbsitelength + lbsy.nf], sitespeed);
          fSiteThermalCollisionBGK(&lbf[il*lbsitelength + (lbsy.nf+lbsy.nc)], sitespeed);
        }
      }
    }
      
  }
  return 0;
}

int fCollisionMRTShanChen()
{
  long Tmax = lbdm.touter;
  double freq = (lbbdforcetyp==1)*sin(lboscilfreq*(lbcurstep-lbequstep));

  if(!incompress) {

    #pragma omp parallel
    {
      double interforce_t[3*lbsy.nf], sitespeed_t[3], rho_t[lbsy.nf];
      double *interforce = &interforce_t[0];
      double *sitespeed = &sitespeed_t[0];
      double *rho = &rho_t[0];
        
      #pragma omp for
      for(long il=0; il<Tmax; il++) {
        if(lbphi[il] != 11) {
          fGetSpeedShanChenAllMassSite(sitespeed, rho, &lbf[il*lbsitelength], &lbomega[il*lbsy.nf]);
          for(int ll=0; ll<3*lbsy.nf; ll++)
	        interforce[ll] = lbinterforce[il*3*lbsy.nf+ll] + lbheatforce[il*3*lbsy.nf+ll] + postequil*(lbbdforce[ll]+lboscilforce[ll]*freq);
          if(lbphi[il] != 12 && lbphi[il] != 13)
            fSiteFluidCollisionMRT(&lbf[il * lbsitelength], sitespeed, &lbomega[il*lbsy.nf], lbtfbulk, rho, interforce);
          fSiteSoluteCollisionBGK(&lbf[il*lbsitelength + lbsy.nf], sitespeed);
          fSiteThermalCollisionBGK(&lbf[il*lbsitelength + (lbsy.nf+lbsy.nc)], sitespeed);
        }
      }
    }
  }
  else {

    #pragma omp parallel
    {
      double interforce_t[3*lbsy.nf], sitespeed_t[3], rho_t[lbsy.nf];
      double *interforce = &interforce_t[0];
      double *sitespeed = &sitespeed_t[0];
      double *rho = &rho_t[0];
        
      #pragma omp for
      for(long il=0; il<Tmax; il++) {
        if(lbphi[il] != 11) {
          fGetSpeedShanChenIncomAllMassSite(sitespeed, rho, &lbf[il*lbsitelength], &lbomega[il*lbsy.nf]);
          for(int ll=0; ll<3*lbsy.nf; ll++)
	        interforce[ll] = lbinterforce[il*3*lbsy.nf+ll] + lbheatforce[il*3*lbsy.nf+ll] + postequil*(lbbdforce[ll]+lboscilforce[ll]*freq);
          if(lbphi[il] != 12 && lbphi[il] != 13)
            fSiteFluidIncomCollisionMRT(&lbf[il * lbsitelength], sitespeed, &lbomega[il*lbsy.nf], lbtfbulk, rho, interforce);
          fSiteSoluteCollisionBGK(&lbf[il*lbsitelength + lbsy.nf], sitespeed);
          fSiteThermalCollisionBGK(&lbf[il*lbsitelength + (lbsy.nf+lbsy.nc)], sitespeed);
        }
      }
    }
  }
  return 0;
}

int fCollisionMRTEDMShanChen()
{
  long Tmax = lbdm.touter;
  double freq = (lbbdforcetyp==1)*sin(lboscilfreq*(lbcurstep-lbequstep));

  if(!incompress) {

    #pragma omp parallel
    {
      double interforce_t[3*lbsy.nf], sitespeed_t[3], rho_t[lbsy.nf];
      double *interforce = &interforce_t[0];
      double *sitespeed = &sitespeed_t[0];
      double *rho = &rho_t[0];
        
      #pragma omp for
      for(long il=0; il<Tmax; il++) {
        if(lbphi[il] != 11) {
          fGetSpeedShanChenAllMassSite(sitespeed, rho, &lbf[il*lbsitelength], &lbomega[il*lbsy.nf]);
          for(int ll=0; ll<3*lbsy.nf; ll++)
	        interforce[ll] = lbinterforce[il*3*lbsy.nf+ll] + lbheatforce[il*3*lbsy.nf+ll] + postequil*(lbbdforce[ll]+lboscilforce[ll]*freq);
          if(lbphi[il] != 12 && lbphi[il] != 13)
            fSiteFluidCollisionMRTEDM(&lbf[il * lbsitelength], sitespeed, &lbomega[il*lbsy.nf], lbtfbulk, rho, interforce);
          fSiteSoluteCollisionBGK(&lbf[il*lbsitelength + lbsy.nf], sitespeed);
          fSiteThermalCollisionBGK(&lbf[il*lbsitelength + (lbsy.nf+lbsy.nc)], sitespeed);
        }
      }
    }
  }
  else {

    #pragma omp parallel
    {
      double interforce_t[3*lbsy.nf], sitespeed_t[3], rho_t[lbsy.nf];
      double *interforce = &interforce_t[0];
      double *sitespeed = &sitespeed_t[0];
      double *rho = &rho_t[0];
        
      #pragma omp for
      for(long il=0; il<Tmax; il++) {
        if(lbphi[il] != 11) {
          fGetSpeedShanChenIncomAllMassSite(sitespeed, rho, &lbf[il*lbsitelength], &lbomega[il*lbsy.nf]);
          for(int ll=0; ll<3*lbsy.nf; ll++)
	        interforce[ll] = lbinterforce[il*3*lbsy.nf+ll] + lbheatforce[il*3*lbsy.nf+ll] + postequil*(lbbdforce[ll]+lboscilforce[ll]*freq);
          if(lbphi[il] != 12 && lbphi[il] != 13)
            fSiteFluidIncomCollisionMRTEDM(&lbf[il * lbsitelength], sitespeed, &lbomega[il*lbsy.nf], lbtfbulk, rho, interforce);
          fSiteSoluteCollisionBGK(&lbf[il*lbsitelength + lbsy.nf], sitespeed);
          fSiteThermalCollisionBGK(&lbf[il*lbsitelength + (lbsy.nf+lbsy.nc)], sitespeed);
        }
      }
    }
                                     
  }
  return 0;
}

int fCollisionMRTGuoShanChen()
{
  long Tmax = lbdm.touter;
  double freq = (lbbdforcetyp==1)*sin(lboscilfreq*(lbcurstep-lbequstep));

  if(!incompress) {

    #pragma omp parallel
    {
      double interforce_t[3*lbsy.nf], sitespeed_t[3], rho_t[lbsy.nf];
      double *interforce = &interforce_t[0];
      double *sitespeed = &sitespeed_t[0];
      double *rho = &rho_t[0];
        
      #pragma omp for
      for(long il=0; il<Tmax; il++) {
        if(lbphi[il] != 11) {
          fGetSpeedShanChenAllMassSite(sitespeed, rho, &lbf[il*lbsitelength], &lbomega[il*lbsy.nf]);
          for(int ll=0; ll<3*lbsy.nf; ll++)
	        interforce[ll] = lbinterforce[il*3*lbsy.nf+ll] + lbheatforce[il*3*lbsy.nf+ll] + postequil*(lbbdforce[ll]+lboscilforce[ll]*freq);
          if(lbphi[il] != 12 && lbphi[il] != 13)
            fSiteFluidCollisionMRTGuo(&lbf[il * lbsitelength], sitespeed, &lbomega[il*lbsy.nf], lbtfbulk, rho, interforce);
          fSiteSoluteCollisionBGK(&lbf[il*lbsitelength + lbsy.nf], sitespeed);
          fSiteThermalCollisionBGK(&lbf[il*lbsitelength + (lbsy.nf+lbsy.nc)], sitespeed);
        }
      }
    }
  }
  else {

    #pragma omp parallel
    {
      double interforce_t[3*lbsy.nf], sitespeed_t[3], rho_t[lbsy.nf];
      double *interforce = &interforce_t[0];
      double *sitespeed = &sitespeed_t[0];
      double *rho = &rho_t[0];
        
      #pragma omp for
      for(long il=0; il<Tmax; il++) {
        if(lbphi[il] != 11) {
          fGetSpeedShanChenIncomAllMassSite(sitespeed, rho, &lbf[il*lbsitelength], &lbomega[il*lbsy.nf]);
          for(int ll=0; ll<3*lbsy.nf; ll++)
	        interforce[ll] = lbinterforce[il*3*lbsy.nf+ll] + lbheatforce[il*3*lbsy.nf+ll] + postequil*(lbbdforce[ll]+lboscilforce[ll]*freq);
          if(lbphi[il] != 12 && lbphi[il] != 13)
            fSiteFluidIncomCollisionMRTGuo(&lbf[il * lbsitelength], sitespeed, &lbomega[il*lbsy.nf], lbtfbulk, rho, interforce);
          fSiteSoluteCollisionBGK(&lbf[il*lbsitelength + lbsy.nf], sitespeed);
          fSiteThermalCollisionBGK(&lbf[il*lbsitelength + (lbsy.nf+lbsy.nc)], sitespeed);
        }
      }
    }
                                     
  }
  return 0;
}

int fCollisionMRTHeShanChen()
{
  long Tmax = lbdm.touter;
  double freq = (lbbdforcetyp==1)*sin(lboscilfreq*(lbcurstep-lbequstep));

  if(!incompress) {

    #pragma omp parallel
    {
      double interforce_t[3*lbsy.nf], sitespeed_t[3], rho_t[lbsy.nf];
      double *interforce = &interforce_t[0];
      double *sitespeed = &sitespeed_t[0];
      double *rho = &rho_t[0];
        
      #pragma omp for
      for(long il=0; il<Tmax; il++) {
        if(lbphi[il] != 11) {
          fGetSpeedShanChenAllMassSite(sitespeed, rho, &lbf[il*lbsitelength], &lbomega[il*lbsy.nf]);
          for(int ll=0; ll<3*lbsy.nf; ll++)
	        interforce[ll] = lbinterforce[il*3*lbsy.nf+ll] + lbheatforce[il*3*lbsy.nf+ll] + postequil*(lbbdforce[ll]+lboscilforce[ll]*freq);
          if(lbphi[il] != 12 && lbphi[il] != 13)
            fSiteFluidCollisionMRTHe(&lbf[il * lbsitelength], sitespeed, &lbomega[il*lbsy.nf], lbtfbulk, rho, interforce);
          fSiteSoluteCollisionBGK(&lbf[il*lbsitelength + lbsy.nf], sitespeed);
          fSiteThermalCollisionBGK(&lbf[il*lbsitelength + (lbsy.nf+lbsy.nc)], sitespeed);
        }
      }
    }
  }
  else {

    #pragma omp parallel
    {
      double interforce_t[3*lbsy.nf], sitespeed_t[3], rho_t[lbsy.nf];
      double *interforce = &interforce_t[0];
      double *sitespeed = &sitespeed_t[0];
      double *rho = &rho_t[0];
        
      #pragma omp for
      for(long il=0; il<Tmax; il++) {
        if(lbphi[il] != 11) {
          fGetSpeedShanChenIncomAllMassSite(sitespeed, rho, &lbf[il*lbsitelength], &lbomega[il*lbsy.nf]);
          for(int ll=0; ll<3*lbsy.nf; ll++)
	        interforce[ll] = lbinterforce[il*3*lbsy.nf+ll] + lbheatforce[il*3*lbsy.nf+ll] + postequil*(lbbdforce[ll]+lboscilforce[ll]*freq);
          if(lbphi[il] != 12 && lbphi[il] != 13)
            fSiteFluidIncomCollisionMRTHe(&lbf[il * lbsitelength], sitespeed, &lbomega[il*lbsy.nf], lbtfbulk, rho, interforce);
          fSiteSoluteCollisionBGK(&lbf[il*lbsitelength + lbsy.nf], sitespeed);
          fSiteThermalCollisionBGK(&lbf[il*lbsitelength + (lbsy.nf+lbsy.nc)], sitespeed);
        }
      }
    }
      
  }
  return 0;
}

int fCollisionMRTLishchuk()
{
  int numpair = 3 * lbsy.nf * (lbsy.nf-1) / 2;
  long Tmax = lbdm.touter;
  double freq = (lbbdforcetyp==1)*sin(lboscilfreq*(lbcurstep-lbequstep));
    
  if(!incompress) {

    #pragma omp parallel
    {
      double interforce_t[3*lbsy.nf], sitespeed_t[3], rho_t[lbsy.nf];
      double *interforce = &interforce_t[0];
      double *sitespeed = &sitespeed_t[0];
      double *rho = &rho_t[0];

      #pragma omp for
      for(long il=0; il<Tmax; il++) {
        if(lbphi[il] != 11) {
          fGetSpeedAllMassSite(sitespeed, rho, &lbf[il*lbsitelength]);
          double invallmass = 0.0;
          for(int ll=0; ll<lbsy.nf; ll++)
            invallmass += rho[ll];
          invallmass = fReciprocal(invallmass);
          interforce[0] = lbinterforce[3*il  ]; interforce[1] = lbinterforce[3*il+1]; interforce[2] = lbinterforce[3*il+2];
          for(int ll=0; ll<lbsy.nf; ll++) {
            double frac = rho[ll] * invallmass;
	        interforce[0] += frac*(lbheatforce[il*3*lbsy.nf+3*ll  ]+postequil*(lbbdforce[3*ll  ]+lboscilforce[3*ll  ]*freq));
            interforce[1] += frac*(lbheatforce[il*3*lbsy.nf+3*ll+1]+postequil*(lbbdforce[3*ll+1]+lboscilforce[3*ll+1]*freq));
	        interforce[2] += frac*(lbheatforce[il*3*lbsy.nf+3*ll+2]+postequil*(lbbdforce[3*ll+2]+lboscilforce[3*ll+2]*freq));
          }
          if(lbphi[il] != 12 && lbphi[il] != 13)
            fSiteFluidCollisionMRTLishchuk(&lbf[il*lbsitelength], sitespeed, &lbomega[il*lbsy.nf], lbtfbulk, rho, interforce, &lbft[il*numpair]);
          fSiteSoluteCollisionBGK(&lbf[il*lbsitelength + lbsy.nf], sitespeed);
          fSiteThermalCollisionBGK(&lbf[il*lbsitelength + (lbsy.nf+lbsy.nc)], sitespeed);
        }
      }
    }
  }
  else {
      
    #pragma omp parallel
    {
      double interforce_t[3*lbsy.nf], sitespeed_t[3], rho_t[lbsy.nf];
      double *interforce = &interforce_t[0];
      double *sitespeed = &sitespeed_t[0];
      double *rho = &rho_t[0];

      #pragma omp for
      for(long il=0; il<Tmax; il++) {
        fGetSpeedIncomSite(sitespeed, &lbf[il*lbsitelength]);
        if(lbphi[il] != 11) {
          double invallmass = 0.0;
          for(int ll=0; ll<lbsy.nf; ll++)
            invallmass += rho[ll];
          invallmass = fReciprocal(invallmass);
          interforce[0] = lbinterforce[3*il  ]; interforce[1] = lbinterforce[3*il+1]; interforce[2] = lbinterforce[3*il+2];
          for(int ll=0; ll<lbsy.nf; ll++) {
            double frac = rho[ll] * invallmass;
	        interforce[0] += frac*(lbheatforce[il*3*lbsy.nf+3*ll  ]+postequil*(lbbdforce[3*ll  ]+lboscilforce[3*ll  ]*freq));
            interforce[1] += frac*(lbheatforce[il*3*lbsy.nf+3*ll+1]+postequil*(lbbdforce[3*ll+1]+lboscilforce[3*ll+1]*freq));
	        interforce[2] += frac*(lbheatforce[il*3*lbsy.nf+3*ll+2]+postequil*(lbbdforce[3*ll+2]+lboscilforce[3*ll+2]*freq));
          }
          if(lbphi[il] != 12 && lbphi[il] != 13)
            fSiteFluidIncomCollisionMRTLishchuk(&lbf[il*lbsitelength], sitespeed, &lbomega[il*lbsy.nf], lbtfbulk, rho, interforce, &lbft[il*numpair]);
          fSiteSoluteCollisionBGK(&lbf[il*lbsitelength + lbsy.nf], sitespeed);
          fSiteThermalCollisionBGK(&lbf[il*lbsitelength + (lbsy.nf+lbsy.nc)], sitespeed);
        }
      }
    }
  }
  return 0;
}

int fCollisionMRTEDMLishchuk()
{
  int numpair = 3 * lbsy.nf * (lbsy.nf-1) / 2;
  long Tmax = lbdm.touter;
  double freq = (lbbdforcetyp==1)*sin(lboscilfreq*(lbcurstep-lbequstep));
    
  if(!incompress) {

    #pragma omp parallel
    {
      double interforce_t[3*lbsy.nf], sitespeed_t[3], rho_t[lbsy.nf];
      double *interforce = &interforce_t[0];
      double *sitespeed = &sitespeed_t[0];
      double *rho = &rho_t[0];

      #pragma omp for
      for(long il=0; il<Tmax; il++) {
        if(lbphi[il] != 11) {
          fGetSpeedAllMassSite(sitespeed, rho, &lbf[il*lbsitelength]);
          double invallmass = 0.0;
          for(int ll=0; ll<lbsy.nf; ll++)
            invallmass += rho[ll];
          invallmass = fReciprocal(invallmass);
          interforce[0] = lbinterforce[3*il  ]; interforce[1] = lbinterforce[3*il+1]; interforce[2] = lbinterforce[3*il+2];
          for(int ll=0; ll<lbsy.nf; ll++) {
            double frac = rho[ll] * invallmass;
	        interforce[0] += frac*(lbheatforce[il*3*lbsy.nf+3*ll  ]+postequil*(lbbdforce[3*ll  ]+lboscilforce[3*ll  ]*freq));
            interforce[1] += frac*(lbheatforce[il*3*lbsy.nf+3*ll+1]+postequil*(lbbdforce[3*ll+1]+lboscilforce[3*ll+1]*freq));
	        interforce[2] += frac*(lbheatforce[il*3*lbsy.nf+3*ll+2]+postequil*(lbbdforce[3*ll+2]+lboscilforce[3*ll+2]*freq));
          }
          if(lbphi[il] != 12 && lbphi[il] != 13)
            fSiteFluidCollisionMRTEDMLishchuk(&lbf[il*lbsitelength], sitespeed, &lbomega[il*lbsy.nf], lbtfbulk, rho, interforce, &lbft[il*numpair]);
          fSiteSoluteCollisionBGK(&lbf[il*lbsitelength + lbsy.nf], sitespeed);
          fSiteThermalCollisionBGK(&lbf[il*lbsitelength + (lbsy.nf+lbsy.nc)], sitespeed);
        }
      }
    }
  }
  else {

    #pragma omp parallel
    {
      double interforce_t[3*lbsy.nf], sitespeed_t[3], rho_t[lbsy.nf];
      double *interforce = &interforce_t[0];
      double *sitespeed = &sitespeed_t[0];
      double *rho = &rho_t[0];

      #pragma omp for
      for(long il=0; il<Tmax; il++) {
        if(lbphi[il] != 11) {
          fGetSpeedIncomAllMassSite(sitespeed, rho, &lbf[il*lbsitelength]);
          double invallmass = 0.0;
          for(int ll=0; ll<lbsy.nf; ll++)
            invallmass += rho[ll];
          invallmass = fReciprocal(invallmass);
          interforce[0] = lbinterforce[3*il  ]; interforce[1] = lbinterforce[3*il+1]; interforce[2] = lbinterforce[3*il+2];
          for(int ll=0; ll<lbsy.nf; ll++) {
            double frac = rho[ll] * invallmass;
	        interforce[0] += frac*(lbheatforce[il*3*lbsy.nf+3*ll  ]+postequil*(lbbdforce[3*ll  ]+lboscilforce[3*ll  ]*freq));
            interforce[1] += frac*(lbheatforce[il*3*lbsy.nf+3*ll+1]+postequil*(lbbdforce[3*ll+1]+lboscilforce[3*ll+1]*freq));
	        interforce[2] += frac*(lbheatforce[il*3*lbsy.nf+3*ll+2]+postequil*(lbbdforce[3*ll+2]+lboscilforce[3*ll+2]*freq));
          }
          if(lbphi[il] != 12 && lbphi[il] != 13)
            fSiteFluidIncomCollisionMRTEDMLishchuk(&lbf[il*lbsitelength], sitespeed, &lbomega[il*lbsy.nf], lbtfbulk, rho, interforce, &lbft[il*numpair]);
          fSiteSoluteCollisionBGK(&lbf[il*lbsitelength + lbsy.nf], sitespeed);
          fSiteThermalCollisionBGK(&lbf[il*lbsitelength + (lbsy.nf+lbsy.nc)], sitespeed);
        }
      }
    }
  }
  return 0;
}


int fCollisionMRTGuoLishchuk()
{
  int numpair = 3 * lbsy.nf * (lbsy.nf-1) / 2;
  long Tmax = lbdm.touter;
  double freq = (lbbdforcetyp==1)*sin(lboscilfreq*(lbcurstep-lbequstep));
    
  if(!incompress) {

    #pragma omp parallel
    {
      double interforce_t[3*lbsy.nf], sitespeed_t[3], rho_t[lbsy.nf];
      double *interforce = &interforce_t[0];
      double *sitespeed = &sitespeed_t[0];
      double *rho = &rho_t[0];

      #pragma omp for
      for(long il=0; il<Tmax; il++) {
        if(lbphi[il] != 11) {
          fGetSpeedAllMassSite(sitespeed, rho, &lbf[il*lbsitelength]);
          double invallmass = 0.0;
          for(int ll=0; ll<lbsy.nf; ll++)
            invallmass += rho[ll];
          invallmass = fReciprocal(invallmass);
          interforce[0] = lbinterforce[3*il  ]; interforce[1] = lbinterforce[3*il+1]; interforce[2] = lbinterforce[3*il+2];
          for(int ll=0; ll<lbsy.nf; ll++) {
            double frac = rho[ll] * invallmass;
	        interforce[0] += frac*(lbheatforce[il*3*lbsy.nf+3*ll  ]+postequil*(lbbdforce[3*ll  ]+lboscilforce[3*ll  ]*freq));
            interforce[1] += frac*(lbheatforce[il*3*lbsy.nf+3*ll+1]+postequil*(lbbdforce[3*ll+1]+lboscilforce[3*ll+1]*freq));
	        interforce[2] += frac*(lbheatforce[il*3*lbsy.nf+3*ll+2]+postequil*(lbbdforce[3*ll+2]+lboscilforce[3*ll+2]*freq));
          }
          if(lbphi[il] != 12 && lbphi[il] != 13)
            fSiteFluidCollisionMRTGuoLishchuk(&lbf[il*lbsitelength], sitespeed, &lbomega[il*lbsy.nf], lbtfbulk, rho, interforce, &lbft[il*numpair]);
          fSiteSoluteCollisionBGK(&lbf[il*lbsitelength + lbsy.nf], sitespeed);
          fSiteThermalCollisionBGK(&lbf[il*lbsitelength + (lbsy.nf+lbsy.nc)], sitespeed);
        }
      }
    }
  }
  else {

    #pragma omp parallel
    {
      double interforce_t[3*lbsy.nf], sitespeed_t[3], rho_t[lbsy.nf];
      double *interforce = &interforce_t[0];
      double *sitespeed = &sitespeed_t[0];
      double *rho = &rho_t[0];

      #pragma omp for
      for(long il=0; il<Tmax; il++) {
        if(lbphi[il] != 11) {
          fGetSpeedIncomAllMassSite(sitespeed, rho, &lbf[il*lbsitelength]);
          double invallmass = 0.0;
          for(int ll=0; ll<lbsy.nf; ll++)
            invallmass += rho[ll];
          invallmass = fReciprocal(invallmass);
          interforce[0] = lbinterforce[3*il  ]; interforce[1] = lbinterforce[3*il+1]; interforce[2] = lbinterforce[3*il+2];
          for(int ll=0; ll<lbsy.nf; ll++) {
            double frac = rho[ll] * invallmass;
	        interforce[0] += frac*(lbheatforce[il*3*lbsy.nf+3*ll  ]+postequil*(lbbdforce[3*ll  ]+lboscilforce[3*ll  ]*freq));
            interforce[1] += frac*(lbheatforce[il*3*lbsy.nf+3*ll+1]+postequil*(lbbdforce[3*ll+1]+lboscilforce[3*ll+1]*freq));
	        interforce[2] += frac*(lbheatforce[il*3*lbsy.nf+3*ll+2]+postequil*(lbbdforce[3*ll+2]+lboscilforce[3*ll+2]*freq));
          }
          if(lbphi[il] != 12 && lbphi[il] != 13)
            fSiteFluidIncomCollisionMRTGuoLishchuk(&lbf[il*lbsitelength], sitespeed, &lbomega[il*lbsy.nf], lbtfbulk, rho, interforce, &lbft[il*numpair]);
          fSiteSoluteCollisionBGK(&lbf[il*lbsitelength + lbsy.nf], sitespeed);
          fSiteThermalCollisionBGK(&lbf[il*lbsitelength + (lbsy.nf+lbsy.nc)], sitespeed);
        }
      }
    }
  }
  return 0;
}


int fCollisionMRTHeLishchuk()
{
  int numpair = 3 * lbsy.nf * (lbsy.nf-1) / 2;
  long Tmax = lbdm.touter;
  double freq = (lbbdforcetyp==1)*sin(lboscilfreq*(lbcurstep-lbequstep));
    
  if(!incompress) {

    #pragma omp parallel
    {
      double interforce_t[3*lbsy.nf], sitespeed_t[3], rho_t[lbsy.nf];
      double *interforce = &interforce_t[0];
      double *sitespeed = &sitespeed_t[0];
      double *rho = &rho_t[0];

      #pragma omp for
      for(long il=0; il<Tmax; il++) {
        if(lbphi[il] != 11) {
          fGetSpeedAllMassSite(sitespeed, rho, &lbf[il*lbsitelength]);
          double invallmass = 0.0;
          for(int ll=0; ll<lbsy.nf; ll++)
            invallmass += rho[ll];
          invallmass = fReciprocal(invallmass);
          interforce[0] = lbinterforce[3*il  ]; interforce[1] = lbinterforce[3*il+1]; interforce[2] = lbinterforce[3*il+2];
          for(int ll=0; ll<lbsy.nf; ll++) {
            double frac = rho[ll] * invallmass;
	        interforce[0] += frac*(lbheatforce[il*3*lbsy.nf+3*ll  ]+postequil*(lbbdforce[3*ll  ]+lboscilforce[3*ll  ]*freq));
            interforce[1] += frac*(lbheatforce[il*3*lbsy.nf+3*ll+1]+postequil*(lbbdforce[3*ll+1]+lboscilforce[3*ll+1]*freq));
	        interforce[2] += frac*(lbheatforce[il*3*lbsy.nf+3*ll+2]+postequil*(lbbdforce[3*ll+2]+lboscilforce[3*ll+2]*freq));
          }
          if(lbphi[il] != 12 && lbphi[il] != 13)
            fSiteFluidCollisionMRTHeLishchuk(&lbf[il*lbsitelength], sitespeed, &lbomega[il*lbsy.nf], lbtfbulk, rho, interforce, &lbft[il*numpair]);
          fSiteSoluteCollisionBGK(&lbf[il*lbsitelength + lbsy.nf], sitespeed);
          fSiteThermalCollisionBGK(&lbf[il*lbsitelength + (lbsy.nf+lbsy.nc)], sitespeed);
        }
      }
    }
  }
  else {

    #pragma omp parallel
    {
      double interforce_t[3*lbsy.nf], sitespeed_t[3], rho_t[lbsy.nf];
      double *interforce = &interforce_t[0];
      double *sitespeed = &sitespeed_t[0];
      double *rho = &rho_t[0];

      #pragma omp for
      for(long il=0; il<Tmax; il++) {
        if(lbphi[il] != 11) {
          fGetSpeedIncomAllMassSite(sitespeed, rho, &lbf[il*lbsitelength]);
          double invallmass = 0.0;
          for(int ll=0; ll<lbsy.nf; ll++)
            invallmass += rho[ll];
          invallmass = fReciprocal(invallmass);
          interforce[0] = lbinterforce[3*il  ]; interforce[1] = lbinterforce[3*il+1]; interforce[2] = lbinterforce[3*il+2];
          for(int ll=0; ll<lbsy.nf; ll++) {
            double frac = rho[ll] * invallmass;
	        interforce[0] += frac*(lbheatforce[il*3*lbsy.nf+3*ll  ]+postequil*(lbbdforce[3*ll  ]+lboscilforce[3*ll  ]*freq));
            interforce[1] += frac*(lbheatforce[il*3*lbsy.nf+3*ll+1]+postequil*(lbbdforce[3*ll+1]+lboscilforce[3*ll+1]*freq));
	        interforce[2] += frac*(lbheatforce[il*3*lbsy.nf+3*ll+2]+postequil*(lbbdforce[3*ll+2]+lboscilforce[3*ll+2]*freq));
          }
          if(lbphi[il] != 12 && lbphi[il] != 13)
            fSiteFluidIncomCollisionMRTHeLishchuk(&lbf[il*lbsitelength], sitespeed, &lbomega[il*lbsy.nf], lbtfbulk, rho, interforce, &lbft[il*numpair]);
          fSiteSoluteCollisionBGK(&lbf[il*lbsitelength + lbsy.nf], sitespeed);
          fSiteThermalCollisionBGK(&lbf[il*lbsitelength + (lbsy.nf+lbsy.nc)], sitespeed);
        }
      }
    }
  }
  return 0;
}


int fCollisionMRTLishchukLocal()
{
  int numpair = 3 * lbsy.nf * (lbsy.nf-1) / 2;
  int threed = (lbsy.nd>2);
  long Tmax = lbdm.touter;
  double freq = (lbbdforcetyp==1)*sin(lboscilfreq*(lbcurstep-lbequstep));

  if(!incompress) {
      
    #pragma omp parallel
    {
      double interforce_t[3*lbsy.nf], sitespeed_t[3], rho_t[lbsy.nf];
      double *interforce = &interforce_t[0];
      double *sitespeed = &sitespeed_t[0];
      double *rho = &rho_t[0];

      #pragma omp for
      for(long il=0; il<Tmax; il++) {
        if(lbphi[il] != 11) {
          fGetSpeedAllMassSite(sitespeed, rho, &lbf[il*lbsitelength]);
          double invallmass = 0.0;
          for(int ll=0; ll<lbsy.nf; ll++)
            invallmass += rho[ll];
          invallmass = fReciprocal(invallmass);
          interforce[0] = lbinterforce[3*il  ]; interforce[1] = lbinterforce[3*il+1]; interforce[2] = lbinterforce[3*il+2];
          for(int ll=0; ll<lbsy.nf; ll++) {
            double frac = rho[ll] * invallmass;
	        interforce[0] += frac*(lbheatforce[il*3*lbsy.nf+3*ll  ]+postequil*(lbbdforce[3*ll  ]+lboscilforce[3*ll  ]*freq));
            interforce[1] += frac*(lbheatforce[il*3*lbsy.nf+3*ll+1]+postequil*(lbbdforce[3*ll+1]+lboscilforce[3*ll+1]*freq));
	        interforce[2] += frac*(lbheatforce[il*3*lbsy.nf+3*ll+2]+postequil*(lbbdforce[3*ll+2]+lboscilforce[3*ll+2]*freq));
          }
          if(lbphi[il] != 12 && lbphi[il] != 13)
	        fSiteFluidCollisionMRTLishchukLocal(&lbf[il*lbsitelength], sitespeed, &lbomega[il*lbsy.nf], lbtfbulk, rho, interforce, &lbft[il*numpair], threed);
          fSiteSoluteCollisionBGK(&lbf[il*lbsitelength + lbsy.nf], sitespeed);
          fSiteThermalCollisionBGK(&lbf[il*lbsitelength + (lbsy.nf+lbsy.nc)], sitespeed);
        }
      }
    }
  }
  else {
      
    #pragma omp parallel
    {
      double interforce_t[3*lbsy.nf], sitespeed_t[3], rho_t[lbsy.nf];
      double *interforce = &interforce_t[0];
      double *sitespeed = &sitespeed_t[0];
      double *rho = &rho_t[0];

      #pragma omp for
      for(long il=0; il<Tmax; il++) {
        if(lbphi[il] != 11) {
          fGetSpeedIncomAllMassSite(sitespeed, rho, &lbf[il*lbsitelength]);
          double invallmass = 0.0;
          for(int ll=0; ll<lbsy.nf; ll++)
            invallmass += rho[ll];
          invallmass = fReciprocal(invallmass);
          interforce[0] = lbinterforce[3*il  ]; interforce[1] = lbinterforce[3*il+1]; interforce[2] = lbinterforce[3*il+2];
          for(int ll=0; ll<lbsy.nf; ll++) {
            double frac = rho[ll] * invallmass;
	        interforce[0] += frac*(lbheatforce[il*3*lbsy.nf+3*ll  ]+postequil*(lbbdforce[3*ll  ]+lboscilforce[3*ll  ]*freq));
            interforce[1] += frac*(lbheatforce[il*3*lbsy.nf+3*ll+1]+postequil*(lbbdforce[3*ll+1]+lboscilforce[3*ll+1]*freq));
	        interforce[2] += frac*(lbheatforce[il*3*lbsy.nf+3*ll+2]+postequil*(lbbdforce[3*ll+2]+lboscilforce[3*ll+2]*freq));
          }
          if(lbphi[il] != 12 && lbphi[il] != 13)
            fSiteFluidIncomCollisionMRTLishchukLocal(&lbf[il*lbsitelength], sitespeed, &lbomega[il*lbsy.nf], lbtfbulk, rho, interforce, &lbft[il*numpair], threed);
          fSiteSoluteCollisionBGK(&lbf[il*lbsitelength + lbsy.nf], sitespeed);
          fSiteThermalCollisionBGK(&lbf[il*lbsitelength + (lbsy.nf+lbsy.nc)], sitespeed);
        }
      }
    }
  }
  return 0;
}

int fCollisionMRTEDMLishchukLocal()
{
  int numpair = 3 * lbsy.nf * (lbsy.nf-1) / 2;
  int threed = (lbsy.nd>2);
  long Tmax = lbdm.touter;
  double freq = (lbbdforcetyp==1)*sin(lboscilfreq*(lbcurstep-lbequstep));

  if(!incompress) {

    #pragma omp parallel
    {
      double interforce_t[3*lbsy.nf], sitespeed_t[3], rho_t[lbsy.nf];
      double *interforce = &interforce_t[0];
      double *sitespeed = &sitespeed_t[0];
      double *rho = &rho_t[0];

      #pragma omp for
      for(long il=0; il<Tmax; il++) {
        if(lbphi[il] != 11) {
          fGetSpeedAllMassSite(sitespeed, rho, &lbf[il*lbsitelength]);
          double invallmass = 0.0;
          for(int ll=0; ll<lbsy.nf; ll++)
            invallmass += rho[ll];
          invallmass = fReciprocal(invallmass);
          interforce[0] = lbinterforce[3*il  ]; interforce[1] = lbinterforce[3*il+1]; interforce[2] = lbinterforce[3*il+2];
          for(int ll=0; ll<lbsy.nf; ll++) {
            double frac = rho[ll] * invallmass;
	        interforce[0] += frac*(lbheatforce[il*3*lbsy.nf+3*ll  ]+postequil*(lbbdforce[3*ll  ]+lboscilforce[3*ll  ]*freq));
            interforce[1] += frac*(lbheatforce[il*3*lbsy.nf+3*ll+1]+postequil*(lbbdforce[3*ll+1]+lboscilforce[3*ll+1]*freq));
	        interforce[2] += frac*(lbheatforce[il*3*lbsy.nf+3*ll+2]+postequil*(lbbdforce[3*ll+2]+lboscilforce[3*ll+2]*freq));
          }
          if(lbphi[il] != 12 && lbphi[il] != 13)
            fSiteFluidCollisionMRTEDMLishchukLocal(&lbf[il*lbsitelength], sitespeed, &lbomega[il*lbsy.nf], lbtfbulk, rho, interforce, &lbft[il*numpair], threed);
          fSiteSoluteCollisionBGK(&lbf[il*lbsitelength + lbsy.nf], sitespeed);
          fSiteThermalCollisionBGK(&lbf[il*lbsitelength + (lbsy.nf+lbsy.nc)], sitespeed);
        }
      }
    }
  }
  else {

    #pragma omp parallel
    {
      double interforce_t[3*lbsy.nf], sitespeed_t[3], rho_t[lbsy.nf];
      double *interforce = &interforce_t[0];
      double *sitespeed = &sitespeed_t[0];
      double *rho = &rho_t[0];

      #pragma omp for
      for(long il=0; il<Tmax; il++) {
        if(lbphi[il] != 11) {
          fGetSpeedIncomAllMassSite(sitespeed, rho, &lbf[il*lbsitelength]);
          double invallmass = 0.0;
          for(int ll=0; ll<lbsy.nf; ll++)
            invallmass += rho[ll];
          invallmass = fReciprocal(invallmass);
          interforce[0] = lbinterforce[3*il  ]; interforce[1] = lbinterforce[3*il+1]; interforce[2] = lbinterforce[3*il+2];
          for(int ll=0; ll<lbsy.nf; ll++) {
            double frac = rho[ll] * invallmass;
	        interforce[0] += frac*(lbheatforce[il*3*lbsy.nf+3*ll  ]+postequil*(lbbdforce[3*ll  ]+lboscilforce[3*ll  ]*freq));
            interforce[1] += frac*(lbheatforce[il*3*lbsy.nf+3*ll+1]+postequil*(lbbdforce[3*ll+1]+lboscilforce[3*ll+1]*freq));
	        interforce[2] += frac*(lbheatforce[il*3*lbsy.nf+3*ll+2]+postequil*(lbbdforce[3*ll+2]+lboscilforce[3*ll+2]*freq));
          }
          if(lbphi[il] != 12 && lbphi[il] != 13)
            fSiteFluidIncomCollisionMRTEDMLishchukLocal(&lbf[il*lbsitelength], sitespeed, &lbomega[il*lbsy.nf], lbtfbulk, rho, interforce, &lbft[il*numpair], threed);
          fSiteSoluteCollisionBGK(&lbf[il*lbsitelength + lbsy.nf], sitespeed);
          fSiteThermalCollisionBGK(&lbf[il*lbsitelength + (lbsy.nf+lbsy.nc)], sitespeed);
        }
      }
    }
  }
  return 0;
}

int fCollisionMRTGuoLishchukLocal()
{
  int numpair = 3 * lbsy.nf * (lbsy.nf-1) / 2;
  int threed = (lbsy.nd>2);
  long Tmax = lbdm.touter;
  double freq = (lbbdforcetyp==1)*sin(lboscilfreq*(lbcurstep-lbequstep));

  if(!incompress) {

    #pragma omp parallel
    {
      double interforce_t[3*lbsy.nf], sitespeed_t[3], rho_t[lbsy.nf];
      double *interforce = &interforce_t[0];
      double *sitespeed = &sitespeed_t[0];
      double *rho = &rho_t[0];

      #pragma omp for
      for(long il=0; il<Tmax; il++) {
        if(lbphi[il] != 11) {
          fGetSpeedAllMassSite(sitespeed, rho, &lbf[il*lbsitelength]);
          double invallmass = 0.0;
          for(int ll=0; ll<lbsy.nf; ll++)
            invallmass += rho[ll];
          invallmass = fReciprocal(invallmass);
          interforce[0] = lbinterforce[3*il  ]; interforce[1] = lbinterforce[3*il+1]; interforce[2] = lbinterforce[3*il+2];
          for(int ll=0; ll<lbsy.nf; ll++) {
            double frac = rho[ll] * invallmass;
	        interforce[0] += frac*(lbheatforce[il*3*lbsy.nf+3*ll  ]+postequil*(lbbdforce[3*ll  ]+lboscilforce[3*ll  ]*freq));
            interforce[1] += frac*(lbheatforce[il*3*lbsy.nf+3*ll+1]+postequil*(lbbdforce[3*ll+1]+lboscilforce[3*ll+1]*freq));
	        interforce[2] += frac*(lbheatforce[il*3*lbsy.nf+3*ll+2]+postequil*(lbbdforce[3*ll+2]+lboscilforce[3*ll+2]*freq));
          }
          if(lbphi[il] != 12 && lbphi[il] != 13)
            fSiteFluidCollisionMRTGuoLishchukLocal(&lbf[il*lbsitelength], sitespeed, &lbomega[il*lbsy.nf], lbtfbulk, rho, interforce, &lbft[il*numpair], threed);
          fSiteSoluteCollisionBGK(&lbf[il*lbsitelength + lbsy.nf], sitespeed);
          fSiteThermalCollisionBGK(&lbf[il*lbsitelength + (lbsy.nf+lbsy.nc)], sitespeed);
        }
      }
    }
  }
  else {

    #pragma omp parallel
    {
      double interforce_t[3*lbsy.nf], sitespeed_t[3], rho_t[lbsy.nf];
      double *interforce = &interforce_t[0];
      double *sitespeed = &sitespeed_t[0];
      double *rho = &rho_t[0];

      #pragma omp for
      for(long il=0; il<Tmax; il++) {
        if(lbphi[il] != 11) {
          fGetSpeedIncomAllMassSite(sitespeed, rho, &lbf[il*lbsitelength]);
          double invallmass = 0.0;
          for(int ll=0; ll<lbsy.nf; ll++)
            invallmass += rho[ll];
          invallmass = fReciprocal(invallmass);
          interforce[0] = lbinterforce[3*il  ]; interforce[1] = lbinterforce[3*il+1]; interforce[2] = lbinterforce[3*il+2];
          for(int ll=0; ll<lbsy.nf; ll++) {
            double frac = rho[ll] * invallmass;
	        interforce[0] += frac*(lbheatforce[il*3*lbsy.nf+3*ll  ]+postequil*(lbbdforce[3*ll  ]+lboscilforce[3*ll  ]*freq));
            interforce[1] += frac*(lbheatforce[il*3*lbsy.nf+3*ll+1]+postequil*(lbbdforce[3*ll+1]+lboscilforce[3*ll+1]*freq));
	        interforce[2] += frac*(lbheatforce[il*3*lbsy.nf+3*ll+2]+postequil*(lbbdforce[3*ll+2]+lboscilforce[3*ll+2]*freq));
          }
          if(lbphi[il] != 12 && lbphi[il] != 13)
            fSiteFluidIncomCollisionMRTGuoLishchukLocal(&lbf[il*lbsitelength], sitespeed, &lbomega[il*lbsy.nf], lbtfbulk, rho, interforce, &lbft[il*numpair], threed);
          fSiteSoluteCollisionBGK(&lbf[il*lbsitelength + lbsy.nf], sitespeed);
          fSiteThermalCollisionBGK(&lbf[il*lbsitelength + (lbsy.nf+lbsy.nc)], sitespeed);
        }
      }
    }
  }
  return 0;
}

int fCollisionMRTHeLishchukLocal()
{
  int numpair = 3 * lbsy.nf * (lbsy.nf-1) / 2;
  int threed = (lbsy.nd>2);
  long Tmax = lbdm.touter;
  double freq = (lbbdforcetyp==1)*sin(lboscilfreq*(lbcurstep-lbequstep));

  if(!incompress) {

    #pragma omp parallel
    {
      double interforce_t[3*lbsy.nf], sitespeed_t[3], rho_t[lbsy.nf];
      double *interforce = &interforce_t[0];
      double *sitespeed = &sitespeed_t[0];
      double *rho = &rho_t[0];

      #pragma omp for
      for(long il=0; il<Tmax; il++) {
        if(lbphi[il] != 11) {
          fGetSpeedAllMassSite(sitespeed, rho, &lbf[il*lbsitelength]);
          double invallmass = 0.0;
          for(int ll=0; ll<lbsy.nf; ll++)
            invallmass += rho[ll];
          invallmass = fReciprocal(invallmass);
          interforce[0] = lbinterforce[3*il  ]; interforce[1] = lbinterforce[3*il+1]; interforce[2] = lbinterforce[3*il+2];
          for(int ll=0; ll<lbsy.nf; ll++) {
            double frac = rho[ll] * invallmass;
	        interforce[0] += frac*(lbheatforce[il*3*lbsy.nf+3*ll  ]+postequil*(lbbdforce[3*ll  ]+lboscilforce[3*ll  ]*freq));
            interforce[1] += frac*(lbheatforce[il*3*lbsy.nf+3*ll+1]+postequil*(lbbdforce[3*ll+1]+lboscilforce[3*ll+1]*freq));
	        interforce[2] += frac*(lbheatforce[il*3*lbsy.nf+3*ll+2]+postequil*(lbbdforce[3*ll+2]+lboscilforce[3*ll+2]*freq));
          }
          if(lbphi[il] != 12 && lbphi[il] != 13)
            fSiteFluidCollisionMRTHeLishchukLocal(&lbf[il*lbsitelength], sitespeed, &lbomega[il*lbsy.nf], lbtfbulk, rho, interforce, &lbft[il*numpair], threed);
          fSiteSoluteCollisionBGK(&lbf[il*lbsitelength + lbsy.nf], sitespeed);
          fSiteThermalCollisionBGK(&lbf[il*lbsitelength + (lbsy.nf+lbsy.nc)], sitespeed);
        }
      }
    }
  }
  else {

    #pragma omp parallel
    {
      double interforce_t[3*lbsy.nf], sitespeed_t[3], rho_t[lbsy.nf];
      double *interforce = &interforce_t[0];
      double *sitespeed = &sitespeed_t[0];
      double *rho = &rho_t[0];

      #pragma omp for
      for(long il=0; il<Tmax; il++) {
        if(lbphi[il] != 11) {
          fGetSpeedIncomAllMassSite(sitespeed, rho, &lbf[il*lbsitelength]);
          double invallmass = 0.0;
          for(int ll=0; ll<lbsy.nf; ll++)
            invallmass += rho[ll];
          invallmass = fReciprocal(invallmass);
          interforce[0] = lbinterforce[3*il  ]; interforce[1] = lbinterforce[3*il+1]; interforce[2] = lbinterforce[3*il+2];
          for(int ll=0; ll<lbsy.nf; ll++) {
            double frac = rho[ll] * invallmass;
	        interforce[0] += frac*(lbheatforce[il*3*lbsy.nf+3*ll  ]+postequil*(lbbdforce[3*ll  ]+lboscilforce[3*ll  ]*freq));
            interforce[1] += frac*(lbheatforce[il*3*lbsy.nf+3*ll+1]+postequil*(lbbdforce[3*ll+1]+lboscilforce[3*ll+1]*freq));
	        interforce[2] += frac*(lbheatforce[il*3*lbsy.nf+3*ll+2]+postequil*(lbbdforce[3*ll+2]+lboscilforce[3*ll+2]*freq));
          }
          if(lbphi[il] != 12 && lbphi[il] != 13)
            fSiteFluidIncomCollisionMRTHeLishchukLocal(&lbf[il*lbsitelength], sitespeed, &lbomega[il*lbsy.nf], lbtfbulk, rho, interforce, &lbft[il*numpair], threed);
          fSiteSoluteCollisionBGK(&lbf[il*lbsitelength + lbsy.nf], sitespeed);
          fSiteThermalCollisionBGK(&lbf[il*lbsitelength + (lbsy.nf+lbsy.nc)], sitespeed);
        }
      }
    }
  }
  return 0;
}

int fCollisionMRTSwift()
{
  long Tmax = lbdm.touter;
  double freq = (lbbdforcetyp==1)*sin(lboscilfreq*(lbcurstep-lbequstep));

  if(lbsy.nf>1) {

   #pragma omp parallel
   {
      double interforce_t[3*lbsy.nf], sitespeed_t[3], rho_t[lbsy.nf];
      double *interforce = &interforce_t[0];
      double *sitespeed = &sitespeed_t[0];
      double *rho = &rho_t[0];

      #pragma omp for
      for(long il=0; il<Tmax; il++) {
        fGetOneSpeedSite(sitespeed, &lbf[il*lbsitelength]);
        double T = (lbsy.nt>0)?fGetTemperatureSite(il):lbsyst;
        if(lbneigh[il]>0 && lbphi[il]==0) {
          sitespeed[0] = 0.0; sitespeed[1] = 0.0; sitespeed[2] = 0.0;
        }
        if(lbphi[il] != 11) {
          fGetAllMassSite(rho, &lbf[il*lbsitelength]);
          double frac = 0.5*(1.0+rho[1]);
          for(int ll=0; ll<3; ll++)
            interforce [ll] = frac*(lbinterforce[il*3*lbsy.nf+ll]+lbheatforce[il*3*lbsy.nf+ll]+postequil*(lbbdforce[ll]+lboscilforce[ll]*freq))
                            + (1.0-frac)*(lbinterforce[il*3*lbsy.nf+3+ll]+lbheatforce[il*3*lbsy.nf+3+ll]+postequil*(lbbdforce[3+ll]+lboscilforce[3+ll]*freq));
          if(lbphi[il] != 12 && lbphi[il] != 13)
            fSiteFluidCollisionMRTSwiftTwoFluid(&lbf[il*lbsitelength], sitespeed, &lbomega[il*lbsy.nf], lbtfbulk, rho, &lbft[8*il], interforce, T);
          fSiteSoluteCollisionBGK(&lbf[il*lbsitelength + lbsy.nf], sitespeed);
          fSiteThermalCollisionBGK(&lbf[il*lbsitelength + lbsy.nf+lbsy.nc], sitespeed);
        }
      }
    }
  }
  else {
      
   #pragma omp parallel
   {
      double interforce_t[3*lbsy.nf], sitespeed_t[3], rho_t[lbsy.nf];
      double *interforce = &interforce_t[0];
      double *sitespeed = &sitespeed_t[0];
      double *rho = &rho_t[0];

      #pragma omp for
      for(long il=0; il<Tmax; il++) {
        fGetOneSpeedSite(sitespeed, &lbf[il*lbsitelength]);
        double T = (lbsy.nt>0)?fGetTemperatureSite(il):lbsyst;
        if(lbneigh[il]>0 && lbphi[il]==0) {
          sitespeed[0] = 0.0; sitespeed[1] = 0.0; sitespeed[2] = 0.0;
        }
        if(lbphi[il] != 11) {
          fGetAllMassSite(rho, &lbf[il*lbsitelength]);
          for(int ll=0; ll<3; ll++)
            interforce [ll] = lbinterforce[il*3*lbsy.nf+ll]+lbheatforce[il*3*lbsy.nf+ll]+postequil*(lbbdforce[ll]+lboscilforce[ll]*freq);
          if(lbphi[il] != 12 && lbphi[il] != 13)
            fSiteFluidCollisionMRTSwiftOneFluid(&lbf[il*lbsitelength], sitespeed, &lbomega[il*lbsy.nf], lbtfbulk, rho, &lbft[4*il], interforce, T);
          fSiteSoluteCollisionBGK(&lbf[il*lbsitelength + lbsy.nf], sitespeed);
          fSiteThermalCollisionBGK(&lbf[il*lbsitelength + lbsy.nf+lbsy.nc], sitespeed);
        }
      }
    }
  }
  return 0;
}

int fCollisionMRTEDMSwift()
{
  long Tmax = lbdm.touter;
  double freq = (lbbdforcetyp==1)*sin(lboscilfreq*(lbcurstep-lbequstep));

  if(lbsy.nf>1) {

   #pragma omp parallel
   {
      double interforce_t[3*lbsy.nf], sitespeed_t[3], rho_t[lbsy.nf];
      double *interforce = &interforce_t[0];
      double *sitespeed = &sitespeed_t[0];
      double *rho = &rho_t[0];

      #pragma omp for
      for(long il=0; il<Tmax; il++) {
        fGetOneSpeedSite(sitespeed, &lbf[il*lbsitelength]);
        double T = (lbsy.nt>0)?fGetTemperatureSite(il):lbsyst;
        if(lbneigh[il]>0 && lbphi[il]==0) {
          sitespeed[0] = 0.0; sitespeed[1] = 0.0; sitespeed[2] = 0.0;
        }
        if(lbphi[il] != 11) {
          fGetAllMassSite(rho, &lbf[il*lbsitelength]);
          double frac = 0.5*(1.0+rho[1]);
          for(int ll=0; ll<3; ll++)
            interforce [ll] = frac*(lbinterforce[il*3*lbsy.nf+ll]+lbheatforce[il*3*lbsy.nf+ll]+postequil*(lbbdforce[ll]+lboscilforce[ll]*freq))
                            + (1.0-frac)*(lbinterforce[il*3*lbsy.nf+3+ll]+lbheatforce[il*3*lbsy.nf+3+ll]+postequil*(lbbdforce[3+ll]+lboscilforce[3+ll]*freq));
          if(lbphi[il] != 12 && lbphi[il] != 13)
            fSiteFluidCollisionMRTEDMSwiftTwoFluid(&lbf[il*lbsitelength], sitespeed, &lbomega[il*lbsy.nf], lbtfbulk, rho, &lbft[8*il], interforce, T);
          fSiteSoluteCollisionBGK(&lbf[il*lbsitelength + lbsy.nf], sitespeed);
          fSiteThermalCollisionBGK(&lbf[il*lbsitelength + lbsy.nf+lbsy.nc], sitespeed);
        }
      }
    }
  }
  else {
      
   #pragma omp parallel
   {
      double interforce_t[3*lbsy.nf], sitespeed_t[3], rho_t[lbsy.nf];
      double *interforce = &interforce_t[0];
      double *sitespeed = &sitespeed_t[0];
      double *rho = &rho_t[0];

      #pragma omp for
      for(long il=0; il<Tmax; il++) {
        fGetOneSpeedSite(sitespeed, &lbf[il*lbsitelength]);
        double T = (lbsy.nt>0)?fGetTemperatureSite(il):lbsyst;
        if(lbneigh[il]>0 && lbphi[il]==0) {
          sitespeed[0] = 0.0; sitespeed[1] = 0.0; sitespeed[2] = 0.0;
        }
        if(lbphi[il] != 11) {
          fGetAllMassSite(rho, &lbf[il*lbsitelength]);
          for(int ll=0; ll<3; ll++)
            interforce [ll] = lbinterforce[il*3*lbsy.nf+ll]+lbheatforce[il*3*lbsy.nf+ll]+postequil*(lbbdforce[ll]+lboscilforce[ll]*freq);
          if(lbphi[il] != 12 && lbphi[il] != 13)
            fSiteFluidCollisionMRTEDMSwiftOneFluid(&lbf[il*lbsitelength], sitespeed, &lbomega[il*lbsy.nf], lbtfbulk, rho, &lbft[4*il], interforce, T);
          fSiteSoluteCollisionBGK(&lbf[il*lbsitelength + lbsy.nf], sitespeed);
          fSiteThermalCollisionBGK(&lbf[il*lbsitelength + lbsy.nf+lbsy.nc], sitespeed);
        }
      }
    }
  }
  return 0;
}

int fCollisionMRTGuoSwift()
{
  long Tmax = lbdm.touter;
  double freq = (lbbdforcetyp==1)*sin(lboscilfreq*(lbcurstep-lbequstep));

  if(lbsy.nf>1) {

   #pragma omp parallel
   {
      double interforce_t[3*lbsy.nf], sitespeed_t[3], rho_t[lbsy.nf];
      double *interforce = &interforce_t[0];
      double *sitespeed = &sitespeed_t[0];
      double *rho = &rho_t[0];

      #pragma omp for
      for(long il=0; il<Tmax; il++) {
        fGetOneSpeedSite(sitespeed, &lbf[il*lbsitelength]);
        double T = (lbsy.nt>0)?fGetTemperatureSite(il):lbsyst;
        if(lbneigh[il]>0 && lbphi[il]==0) {
          sitespeed[0] = 0.0; sitespeed[1] = 0.0; sitespeed[2] = 0.0;
        }
        if(lbphi[il] != 11) {
          fGetAllMassSite(rho, &lbf[il*lbsitelength]);
          double frac = 0.5*(1.0+rho[1]);
          for(int ll=0; ll<3; ll++)
            interforce [ll] = frac*(lbinterforce[il*3*lbsy.nf+ll]+lbheatforce[il*3*lbsy.nf+ll]+postequil*(lbbdforce[ll]+lboscilforce[ll]*freq))
                            + (1.0-frac)*(lbinterforce[il*3*lbsy.nf+3+ll]+lbheatforce[il*3*lbsy.nf+3+ll]+postequil*(lbbdforce[3+ll]+lboscilforce[3+ll]*freq));
          if(lbphi[il] != 12 && lbphi[il] != 13)
            fSiteFluidCollisionMRTGuoSwiftTwoFluid(&lbf[il*lbsitelength], sitespeed, &lbomega[il*lbsy.nf], lbtfbulk, rho, &lbft[8*il], interforce, T);
          fSiteSoluteCollisionBGK(&lbf[il*lbsitelength + lbsy.nf], sitespeed);
          fSiteThermalCollisionBGK(&lbf[il*lbsitelength + lbsy.nf+lbsy.nc], sitespeed);
        }
      }
    }
  }
  else {
      
   #pragma omp parallel
   {
      double interforce_t[3*lbsy.nf], sitespeed_t[3], rho_t[lbsy.nf];
      double *interforce = &interforce_t[0];
      double *sitespeed = &sitespeed_t[0];
      double *rho = &rho_t[0];

      #pragma omp for
      for(long il=0; il<Tmax; il++) {
        fGetOneSpeedSite(sitespeed, &lbf[il*lbsitelength]);
        double T = (lbsy.nt>0)?fGetTemperatureSite(il):lbsyst;
        if(lbneigh[il]>0 && lbphi[il]==0) {
          sitespeed[0] = 0.0; sitespeed[1] = 0.0; sitespeed[2] = 0.0;
        }
        if(lbphi[il] != 11) {
          fGetAllMassSite(rho, &lbf[il*lbsitelength]);
          for(int ll=0; ll<3; ll++)
            interforce [ll] = lbinterforce[il*3*lbsy.nf+ll]+lbheatforce[il*3*lbsy.nf+ll]+postequil*(lbbdforce[ll]+lboscilforce[ll]*freq);
          if(lbphi[il] != 12 && lbphi[il] != 13)
            fSiteFluidCollisionMRTGuoSwiftOneFluid(&lbf[il*lbsitelength], sitespeed, &lbomega[il*lbsy.nf], lbtfbulk, rho, &lbft[4*il], interforce, T);
          fSiteSoluteCollisionBGK(&lbf[il*lbsitelength + lbsy.nf], sitespeed);
          fSiteThermalCollisionBGK(&lbf[il*lbsitelength + lbsy.nf+lbsy.nc], sitespeed);
        }
      }
    }
  }
  return 0;
}

int fCollisionMRTHeSwift()
{
  long Tmax = lbdm.touter;
  double freq = (lbbdforcetyp==1)*sin(lboscilfreq*(lbcurstep-lbequstep));

  if(lbsy.nf>1) {

   #pragma omp parallel
   {
      double interforce_t[3*lbsy.nf], sitespeed_t[3], rho_t[lbsy.nf];
      double *interforce = &interforce_t[0];
      double *sitespeed = &sitespeed_t[0];
      double *rho = &rho_t[0];

      #pragma omp for
      for(long il=0; il<Tmax; il++) {
        fGetOneSpeedSite(sitespeed, &lbf[il*lbsitelength]);
        double T = (lbsy.nt>0)?fGetTemperatureSite(il):lbsyst;
        if(lbneigh[il]>0 && lbphi[il]==0) {
          sitespeed[0] = 0.0; sitespeed[1] = 0.0; sitespeed[2] = 0.0;
        }
        if(lbphi[il] != 11) {
          fGetAllMassSite(rho, &lbf[il*lbsitelength]);
          double frac = 0.5*(1.0+rho[1]);
          for(int ll=0; ll<3; ll++)
            interforce [ll] = frac*(lbinterforce[il*3*lbsy.nf+ll]+lbheatforce[il*3*lbsy.nf+ll]+postequil*(lbbdforce[ll]+lboscilforce[ll]*freq))
                            + (1.0-frac)*(lbinterforce[il*3*lbsy.nf+3+ll]+lbheatforce[il*3*lbsy.nf+3+ll]+postequil*(lbbdforce[3+ll]+lboscilforce[3+ll]*freq));
          if(lbphi[il] != 12 && lbphi[il] != 13)
            fSiteFluidCollisionMRTHeSwiftTwoFluid(&lbf[il*lbsitelength], sitespeed, &lbomega[il*lbsy.nf], lbtfbulk, rho, &lbft[8*il], interforce, T);
          fSiteSoluteCollisionBGK(&lbf[il*lbsitelength + lbsy.nf], sitespeed);
          fSiteThermalCollisionBGK(&lbf[il*lbsitelength + lbsy.nf+lbsy.nc], sitespeed);
        }
      }
    }
  }
  else {
      
   #pragma omp parallel
   {
      double interforce_t[3*lbsy.nf], sitespeed_t[3], rho_t[lbsy.nf];
      double *interforce = &interforce_t[0];
      double *sitespeed = &sitespeed_t[0];
      double *rho = &rho_t[0];

      #pragma omp for
      for(long il=0; il<Tmax; il++) {
        fGetOneSpeedSite(sitespeed, &lbf[il*lbsitelength]);
        double T = (lbsy.nt>0)?fGetTemperatureSite(il):lbsyst;
        if(lbneigh[il]>0 && lbphi[il]==0) {
          sitespeed[0] = 0.0; sitespeed[1] = 0.0; sitespeed[2] = 0.0;
        }
        if(lbphi[il] != 11) {
          fGetAllMassSite(rho, &lbf[il*lbsitelength]);
          for(int ll=0; ll<3; ll++)
            interforce [ll] = lbinterforce[il*3*lbsy.nf+ll]+lbheatforce[il*3*lbsy.nf+ll]+postequil*(lbbdforce[ll]+lboscilforce[ll]*freq);
          if(lbphi[il] != 12 && lbphi[il] != 13)
            fSiteFluidCollisionMRTHeSwiftOneFluid(&lbf[il*lbsitelength], sitespeed, &lbomega[il*lbsy.nf], lbtfbulk, rho, &lbft[4*il], interforce, T);
          fSiteSoluteCollisionBGK(&lbf[il*lbsitelength + lbsy.nf], sitespeed);
          fSiteThermalCollisionBGK(&lbf[il*lbsitelength + lbsy.nf+lbsy.nc], sitespeed);
        }
      }
    }
  }
  return 0;
}



