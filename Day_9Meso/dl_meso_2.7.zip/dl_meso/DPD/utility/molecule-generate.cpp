#include <iomanip>
#include <iostream>
#include <fstream>
#include <cstdlib>
#include <cstdio>
#include <string>
#include <cstring>
#include <cmath>
#include <ctime>
#include <sstream>
#include <vector>

using namespace std;

double duni();
double sgn(double);
string readstring (string, int);
double readdble(string, int);
long int readint(string, int);
bool fexists(const char *);
long int neighbourbond(long int);
long int neighbourangle(long int);
long int neighbourdihedral(long int);

const double PI=3.141592653589793;
double c,cd,cm;
long int** bndtbl=NULL;
long int** angtbl=NULL;
long int** dhdtbl=NULL;
long int** dest=NULL;

bool newx=true;
double uni[102];
long int numbond,numchains;

int main(int argc, char* argv[])
  //-----------------------------------------------------------------
  //
  //    daresbury laboratory ccp5 program to generate molecule chains
  //    for dissipative particle dynamics calculations in dl_meso_dpd 
  //
  //    copyright ukri stfc daresbury laboratory
  //    authors - w. smith & m. a. seaton december 2018
  //
  //-----------------------------------------------------------------
{
  double* xxx=NULL;
  double* yyy=NULL;
  double* zzz=NULL;
  long int* bead=NULL;
  long int* startbead=NULL;
  long int* chain=NULL;
  long int* species=NULL;
  long int* bdtyp=NULL;
  long int* agtyp=NULL;
  long int* dhtyp=NULL;
  double* abond=NULL;
  double* bbond=NULL;
  double* cbond=NULL;
  double* aang=NULL;
  double* bang=NULL;
  double* cang=NULL;
  double* adhd=NULL;
  double* bdhd=NULL;
  double* cdhd=NULL;

  char line[200];
  char** atmnam=NULL;
  char molnam[9];

  string record, word, name;

  long int beadtotal,defspec,i,imol,j,k,l,m,n,numang,numdhd,numlinks,nummol,numspecies,count;
  long int nbondtype,nangtype,ndhdtype,bdtype,agtype,dhtype,numbranch,idest,popmol;
  double cubesize,dx,dy,dz,halfcube,bondlength,x,x0,y,y0,z,z0,azimuth,elevation;
  bool incube,fieldexist,specread,isomer,separate;
  char namespecies[40];

//  FILE *F;

  // check for command line arguments
  separate=false;
  numspecies = 0;
  for(i=1; i<argc; i++) {
    word = argv[i];
    if(word.compare(0,2,"-p")==0 || word.compare(0,2,"-P")==0) {
      separate=true;
    }
    else if(word.compare(0,2,"-s")==0 || word.compare(0,2,"-S")==0) {
      numspecies = atoi(argv[i+1]);
      i += 2;
      atmnam = new char*[numspecies];
      for (j=0; j<numspecies; j++)
        atmnam[j] = new char[9];
      for(j=0; j<numspecies; j++) {
        strcpy(atmnam[j], argv[i+j]);
        l = strlen(atmnam[j]);
        for(k=l; k<8; k++) {
          atmnam[j][k]=' ';
        }
        atmnam[j][8] = '\0';
      }
    }
    else if(word.compare(0,2,"-h")==0 || word.compare(0,2,"-H")==0) {
      cout << "DL_MESO molecule generate utility, creates molecule configuration" << endl;
      cout << "data with bond connectivities and interactions, and writes to either" << endl;
      cout << "a (new or pre-existing) FIELD file or a separate file (molecule)" << endl;
      cout << "Usage: " << argv[0] << " [OPTIONS]" << endl << endl;
      cout << "Options:" << endl << endl;
      cout << "-h" << endl;
      cout << "       display this help and exit" << endl << endl;
      cout << "-p" << endl;
      cout << "       place molecule data into separate file (molecule)" << endl << endl;
      cout << "-s [n] [SPEC1] [SPEC2] ... [SPECn]" << endl;
      cout << "       supply names of [n] bead species ([SPEC1], [SPEC2] ... [SPECn])" << endl << endl;
      exit(0);
    }
  }

  /* obtain input information to generate chains - number of chains,
     chain lengths, starting beads for branches, bond length and 
     size of cube (later also obtain species types for particles)   */

  // try to read FIELD file for species information - ask for user input if not available

  if(numspecies==0) {
    fieldexist = fexists("FIELD");
    if(fieldexist) {
      ifstream inpfile;
      inpfile.open("FIELD");
      specread = false;
      while(inpfile.good()!=0 && !specread)
        {
          inpfile.getline(line,200);
          word = line;
          record = readstring(word, 0);
          if((record.compare(0,4,"SPEC")==0 || record.compare(0,4,"spec")==0) && !specread)
            {
              numspecies = readint(word, 1);
              atmnam = new char*[numspecies];
              for (j=0; j<numspecies; j++) {
                atmnam[j] = new char[9];
                inpfile.getline(line,200);
                name = readstring(line, 0);
                copy(name.begin(), name.end(), atmnam[j]);
                if(name.size()<9)
                  atmnam[j][name.size()] = '\0';
                else
                  atmnam[j][8] = '\0';
              }
              specread = true;
            }
        }
      inpfile.close();
    }
  }

  if(numspecies==0) {
      cout << "Number of species: ";
      while(1)
        {
          cin >> numspecies;
          if (numspecies<1) {
            cout << "Number of species must be greater than 0!"<<endl;
          }
          else {
            break;
          }
        } 
      atmnam = new char*[numspecies];
      for (j=0; j<numspecies; j++)
        atmnam[j] = new char[9];

      for(i=0; i<numspecies; i++)
        {
          cout << "Name of species "<<(i+1)<<" (max. length of 8 characters): ";
          cin >> namespecies;
          k = strlen(namespecies);
          strcpy(atmnam[i], namespecies);
          for(j=k; j<8; j++) {
            atmnam[i][j]=' ';
          }
          atmnam[i][8] = '\0';
        }

      if(!separate) {
        ofstream newfield;
        newfield.open("FIELD");

        newfield << "FIELD file created by molecule-generate" << endl << endl;
 
        newfield << "SPECIES " << numspecies << showpoint << endl;
        for(i=0; i<numspecies; i++) {
          newfield << atmnam[i] << " 1.0 0.0 0.0" << endl;
        }
        newfield << endl;
     
        newfield.close();
      }
  }

  cout << "Number of molecules to design: ";
  while(1)
    {
      cin >> nummol;
      if (nummol<1) {
        cout << "Number of molecules must be greater than zero!"<<endl;
      }
      else {
        break;
      }
    }

  // initialise random number generator

  duni();

  // ask user input for bond, angle and dihedral types

  nbondtype=0;
  nangtype=0;
  ndhdtype=0;

  cout << endl << "Number of bond types: ";
  while(1) {
    cin >> nbondtype;
    if(nbondtype<1) {
      cout << "At least one bond type must be specified!" << endl;
    } 
    else {
      break;
    }
  }
  bdtyp = new long int[nbondtype];
  abond = new double[nbondtype];
  bbond = new double[nbondtype];
  cbond = new double[nbondtype];

  cout << "Available bond potentials: 1 = harmonic" << endl;
  cout << "                           2 = FENE" << endl;
  cout << "                           3 = WLC" << endl;
  cout << "                           4 = Morse" << endl;
  for(i=0; i<nbondtype; i++)
    {
      cout << "Bond type "<<(i+1)<<endl;
      cout << "Potential (1-4): ";
      bdtype = 0;
      while(1) {
        cin >> bdtype;
        if(bdtype<1 || bdtype>4) {
          cout << "Potential must be between 1 and 4!" << endl;
        }
        else {
          break;
        }
      }
      bdtyp[i] = bdtype;
      switch (bdtype) {
        case 1 :
          cout << "Spring force constant = ";
          cin >> abond[i];
          cout << "Equilibrium bond length = ";
          cin >> bbond[i];
          cbond[i]=0.0;
          break;
        case 2 :
          cout << "Spring force constant = ";
          cin >> abond[i];
          cout << "Equilibrium bond length = ";
          cin >> bbond[i];
          cout << "Maximum bond length = ";
          cin >> cbond[i];
          break;
        case 3 :
          cout << "Persistence length = ";
          cin >> abond[i];
          cout << "Maximum bond length = ";
          cin >> bbond[i];
          cbond[i]=0.0;
          break;
        case 4 :
          cout << "Potential well depth = ";
          cin >> abond[i];
          cout << "Equilibrium bond length = ";
          cin >> bbond[i];
          cout << "Potential width = ";
          cin >> cbond[i];
          break;
      }     
    }  

  cout << endl << "Number of bond angle types: ";
  cin >> nangtype;

  if(nangtype>0) {
    agtyp = new long int[nangtype];
    aang = new double[nangtype];
    bang = new double[nangtype];
    cang = new double[nangtype];

    cout << "Available bond angle potentials: 1 = harmonic" << endl;
    cout << "                                 2 = harmonic cosine" << endl;
    cout << "                                 3 = cosine" << endl;
    for(i=0; i<nangtype; i++)
      {
        cout << "Bond angle type "<<(i+1)<<endl;
        cout << "Potential (1-3): ";
        agtype = 0;
        while(1) {
          cin >> agtype;
          if(agtype<1 || agtype>3) {
            cout << "Potential must be between 1 and 3!" << endl;
          }
          else {
            break;
          }
        }
        agtyp[i] = agtype;
        switch (agtype) {
          case 1 :
            cout << "Angle force constant = ";
            cin >> aang[i];
            cout << "Equilibrium bond angle (degrees) = ";
            cin >> bang[i];
            cang[i]=0.0;
            break;
          case 2 :
            cout << "Angle force constant = ";
            cin >> aang[i];
            cout << "Equilibrium bond angle (degrees) = ";
            cin >> bang[i];
            cang[i]=0.0;
            break;
          case 3 :
            cout << "Angle force constant = ";
            cin >> aang[i];
            cout << "Angle at minimum potential (degrees) = ";
            cin >> bang[i];
            cout << "Multiplicity = ";
            cin >> cang[i];
            break;
        }     
      }  

  }

  cout << endl << "Number of bond dihedral types: ";
  cin >> ndhdtype;

  if(ndhdtype>0) {
    dhtyp = new long int[ndhdtype];
    adhd = new double[ndhdtype];
    bdhd = new double[ndhdtype];
    cdhd = new double[ndhdtype];

    cout << "Available bond dihedral potentials: 1 = cosine torsion" << endl;
    cout << "                                    2 = harmonic" << endl;
    cout << "                                    3 = harmonic cosine" << endl;
    for(i=0; i<ndhdtype; i++)
      {
        cout << "Bond dihedral type "<<(i+1)<<endl;
        cout << "Potential (1-3): ";
        dhtype = 0;
        while(1) {
          cin >> dhtype;
          if(dhtype<1 || dhtype>3) {
            cout << "Potential must be between 1 and 3!" << endl;
          }
          else {
            break;
          }
        }
        dhtyp[i] = dhtype;
        switch (dhtype) {
          case 1 :
            cout << "Dihedral force constant = ";
            cin >> adhd[i];
            cout << "Dihedral at minimum potential (degrees) = ";
            cin >> bdhd[i];
            cout << "Multiplicity = ";
            cin >> cdhd[i];
            break;
          case 2 :
            cout << "Dihedral force constant = ";
            cin >> adhd[i];
            cout << "Equilibrium bond dihedral (degrees) = ";
            cin >> bdhd[i];
            cdhd[i]=0.0;
            break;
          case 3 :
            cout << "Dihedral force constant = ";
            cin >> adhd[i];
            cout << "Equilibrium bond dihedral (degrees) = ";
            cin >> bdhd[i];
            cdhd[i]=0.0;
            break;
        }     
      }  

  }

  ofstream appendfield;
  if(separate)
    appendfield.open("molecule");
  else
    appendfield.open("FIELD", ios::app);
    
  appendfield << "MOLECULES " << nummol << endl;

  for(imol=0; imol<nummol; imol++)
    {
      cout << endl<<"Designing molecule "<<(imol+1)<<endl<<endl;
      cout << "Name of molecule (max. length of 8 characters): ";
      cin >> namespecies;
      k = strlen(namespecies);
      strcpy(molnam, namespecies);
      for(j=k; j<8; j++) {
        molnam[j]=' ';
      }
      molnam[8] = '\0';
      cout << "Molecule population in system : ";
      cin >> popmol;

      cout << "Permit molecular isomers (T or F) : ";
      while(1) {
        cin >> name;
        if(name.compare(0,1,"T")==0 || name.compare(0,1,"t")==0) {
          isomer=true;
          break;
        }
        if(name.compare(0,1,"F")==0 || name.compare(0,1,"f")==0) {
          isomer=false;
          break;
        }      
      }

      cout << "Size of cube for molecule (include 1 unit for buffer): ";
      cin >> cubesize;
      halfcube=0.5*(cubesize-1.0);

      cout << "Size of bond lengths: ";
      cin >> bondlength;

      cout << "Number of chains: ";
      cin >> numchains;

      bead=new long int[numchains+1];
      startbead=new long int[numchains];
      dest=new long int*[2*numchains];
      for(i=0; i<2*numchains; i++) {
        dest[i] = new long int[3];
        dest[i][0] = 0;
        dest[i][1] = 0;
        dest[i][2] = 0;
      }
      beadtotal=0;
      numlinks=0;
      numbond=0;
      numang=0;
      numdhd=0;

      cout << "Number of beads in chain 1: ";
      cin >> j;
      beadtotal=j;
      bead[0]=0;
      bead[1]=beadtotal;
      startbead[0]=0;
      numlinks=j-1;
      if (numchains>1) {
        cout << "Chain 1 is the primary chain." << endl;
        for(i=1;i<numchains;i++)
          {
            cout << "Number of beads in chain " << (i+1) << ": ";
            cin >> j;
            beadtotal+=j;
            numlinks+=j;
            bead[i+1]=beadtotal;
            cout << "Chain " << (i+1) << " is a branch.\n";
            cout << "Starting bead for branch (1 to " << (beadtotal-j) << "): ";
            cin >> k;
            startbead[i]=k;
          }
        }

      xxx = new double[beadtotal];
      yyy = new double[beadtotal];
      zzz = new double[beadtotal];
      chain = new long int[beadtotal];
      species = new long int[beadtotal];
      bndtbl = new long int*[beadtotal];
      angtbl = new long int*[beadtotal];
      dhdtbl = new long int*[beadtotal];
      for(i=0;i<beadtotal;i++)
      {
        chain[i]=0;
        species[i]=0;
        bndtbl[i] = new long int[3];
        angtbl[i] = new long int[4];
        dhdtbl[i] = new long int[5];
      }

  /* identify bead species                                          */

      if (numspecies>1) {
        for (i=0; i<numspecies; i++)
          cout<<"Species number "<<(i+1)<<": "<<atmnam[i]<<endl;
        cout << "Default bead species number for molecule: "<<endl;
        while(1) {
          cin >> defspec;
          if(defspec<1 || defspec>numspecies) {
            cout << "Default bead species number must be between 1 and "<< numspecies << "!" << endl;
          }
          else {
            break;
          }
        }
        defspec--;
        for (i=0;i<beadtotal;i++)
        {
          species[i]=defspec;
        }
        for (i=0; i<numspecies; i++) {
          if (i!=defspec) {
            cout << "Enter bead numbers for species "<<(i+1)<<" ("<<atmnam[i]<<")"<<endl;
            cout << "Valid bead numbers: 1 to "<<beadtotal<<" (enter 0 to finish)"<<endl;
            while(1)
              {
                cin >> j;
                if (j>0 && j<=beadtotal) {
                  species[j-1] = i;
                }
                else if (j==0) {
                  break;
                }
                else {
                  cout << "Invalid bead number!" <<endl;
                }
              }
          }
        }
      }

  // determine default bond type

     if (nbondtype>1) {
       for(i=0; i<nbondtype; i++) {
         bdtype = bdtyp[i];
         switch (bdtype) {
           case 1 :
             cout << "Bond type " << (i+1) << ": harmonic, k = " << abond[i]<<", r_0 = " <<bbond[i]<<endl;
             break;
           case 2 :
             cout << "Bond type " << (i+1) << ": FENE, k = " << abond[i]<<", r_0 = " <<bbond[i]<<", r_max = "<<cbond[i]<<endl;
             break;
           case 3 :
             cout << "Bond type " << (i+1) << ": WLC, A_p = " << abond[i]<<", r_max = " <<bbond[i]<<endl;
             break;
           case 4 :
             cout << "Bond type " << (i+1) << ": Morse, D_e = " << abond[i]<<", r_0 = " <<bbond[i]<<", beta = "<<cbond[i]<<endl;
             break;
         }
       }
       cout << "Default bond type (between 1 and " << nbondtype <<"): ";
       while(1) {
         cin >> j;
         if (j>0 && j<=nbondtype) {
           bdtype = j;
           break;
         }
         else {
           cout << "Invalid bond type!" <<endl;
         }
       }
     } 
     else {
       bdtype = 1;
     }

  // construct bond table

     count=1;
     for (i=0; i<beadtotal; i++)
     {
       if (i!=bead[count]-1) {
         numbond++;
         bndtbl[numbond-1][0] = i+1;
         bndtbl[numbond-1][1] = i+2;
         bndtbl[numbond-1][2] = bdtype;
       }
       else {
         count++;
       }
       if (numchains>1) {
         for (j=1; j<numchains; j++)
         {
           if (i==startbead[j]-1) {
             numbond++;
             bndtbl[numbond-1][0] = i+1;
             bndtbl[numbond-1][1] = bead[j]+1;
             bndtbl[numbond-1][2] = bdtype;
           }
         }
       }
     }

  // determine any non-default bonds

     if (nbondtype>1) {

       while (1) {
         cout << "Enter bead index number for non-default bonds or 0 to finish: ";
         cin >> j;
         if(j==0) {
           break;
         }
         else {
           numbranch = neighbourbond(j);
           if(numbranch==0) {
             cout << "Chosen bead is not a valid index bead!"<<endl;
           }
           else {
             if (numbranch==1) {
               idest = dest[0][0];
               l = bndtbl[idest][1]; 
             }
             else {
               cout << "Index bead attached to:";
               for (k=0; k<numbranch; k++) {
                 m = dest[k][0];
                 cout << " " << bndtbl[m][1];
               }
               cout << endl;
               cout << "Destination bead index: ";
               while (1) {
                 cin >> l;
                 idest = -1;
                 for(k=0; k<numbranch; k++) {
                   m = dest[k][0];
                   if(l==bndtbl[m][1]) {
                     idest = m;
                   }
                 }
                 if(m>=0) {
                   break;
                 }
                 else {
                   cout << "Not a valid destination bead!" << endl;
                 }
               }
             }
             cout << "Bond connecting beads "<<j<<" and "<<l<<endl;
             cout << "Enter bond type (1 to "<<nbondtype<<"): ";
             while (1) {
               cin >> n;
               if (n>0 && n<=nbondtype) {
                 bndtbl[idest][2] = n;
                 break;
               }
               else {
                 cout << "Invalid bond type!" << endl;
               }
             }
           }
         }           
       }

     }
          
  // determine any bond angles

     if (numbond>2 && nangtype>0) {

       for(i=0; i<nangtype; i++) {
         agtype = agtyp[i];
         switch (agtype) {
           case 1 :
             cout << "Angle type " << (i+1) << ": harmonic, k = " << aang[i]<<", theta_0 = " <<bang[i]<<endl;
             break;
           case 2 :
             cout << "Angle type " << (i+1) << ": harmonic cosine, k = " << aang[i]<<", theta_0 = " <<bang[i]<<endl;
             break;
           case 3 :
             cout << "Angle type " << (i+1) << ": cosine, A = " << aang[i]<<", delta = " <<bang[i]<<", m = "<<cang[i]<<endl;
             break;
         }
       }

       while (1) {
         cout << "Enter bead index number for bond angles or 0 to finish: ";
         cin >> j;
         if(j==0) {
           break;
         }
         else {
           numbranch = neighbourangle(j);           
           if(numbranch==0) {
             cout << "Chosen bead is not a valid index bead!"<<endl;
           }
           else {
             if (numbranch==1) {
               idest = 0;
             }
             else {
               cout << "Possible bond triples:"<<endl;
               for (k=0; k<numbranch; k++) {
                 cout << (k+1)<< ": " << dest[k][0]<<" "<<j<<" "<<dest[k][1]<<endl;
               }
               cout << "Select bond triple (1 to "<<numbranch<<"): ";
               while (1) {
                 cin >> idest;
                 if(idest>0 || idest<=numbranch) {
                   idest--;
                   break;
                 }
                 else {
                   cout << "Not a valid triple!" << endl;
                 }
               }
             }
             cout << "Bond triple: " << dest[idest][0] << " " << j << " " << dest[idest][1] << endl;
             if(nangtype>1) {
               cout << "Enter angle type (1 to "<<nangtype<<"): ";
               while (1) {
                 cin >> n;
                 if (n<1 || n>nangtype) {
                   cout << "Invalid angle type!" << endl;
                 }
                 else {
                   break;
                 }
               }
             }
             else {
               n = 1;
             }
             numang++;
             angtbl[numang-1][0] = dest[idest][0];
             angtbl[numang-1][1] = j;
             angtbl[numang-1][2] = dest[idest][1];
             angtbl[numang-1][3] = n;
           }
         }           
       }
     }
          
  // determine any bond dihedrals

     if (numbond>3 && ndhdtype>0) {

       for(i=0; i<ndhdtype; i++) {
         dhtype = dhtyp[i];
         switch (dhtype) {
           case 1 :
             cout << "Dihedral type " << (i+1) << ": cosine torsion, A = " << adhd[i]<<", delta = " <<bdhd[i]<<", m = "<<cdhd[i]<<endl;
             break;
           case 2 :
             cout << "Dihedral type " << (i+1) << ": harmonic, k = " << adhd[i]<<", phi_0 = " <<bdhd[i]<<endl;
             break;
           case 3 :
             cout << "Dihedral type " << (i+1) << ": harmonic cosine, k = " << adhd[i]<<", phi_0 = " <<bdhd[i]<<endl;
             break;
         }
       }
       while (1) {
         cout << "Enter bead index number for bond dihedrals or 0 to finish: ";
         cin >> j;
         if(j==0) {
           break;
         }
         else {
           numbranch = neighbourdihedral(j);           
           if(numbranch==0) {
             cout << "Chosen bead is not a valid index bead!"<<endl;
           }
           else {
             if (numbranch==1) {
               idest = 0;
             }
             else {
               cout << "Possible bond quadruples:"<<endl;
               for (k=0; k<numbranch; k++) {
                 cout << (k+1) << ": " << dest[k][0]<<" "<<j<<" "<<dest[k][1]<<" "<<dest[k][2]<<endl;
               }
               cout << "Select bond quadruple (1 to "<<numbranch<<"): ";
               while (1) {
                 cin >> idest;
                 if(idest>0 || idest<=numbranch) {
                   idest--;
                   break;
                 }
                 else {
                   cout << "Not a valid quadruple!" << endl;
                 }
               }
             }
             cout << "Bond quadruple: " << dest[idest][0] << " " << j << " " << dest[idest][1] << " " << dest[idest][2] << endl;
             if(ndhdtype>1) {
               cout << "Enter dihedral type (1 to "<<ndhdtype<<"): ";
               while (1) {
                 cin >> n;
                 if (n<1 || n>ndhdtype) {
                   cout << "Invalid dihedral type!" << endl;
                 }
                 else {
                   break;
                 }
               }
             }
             else {
               n = 1;
             }
             numdhd++;
             dhdtbl[numdhd-1][0] = dest[idest][0];
             dhdtbl[numdhd-1][1] = j;
             dhdtbl[numdhd-1][2] = dest[idest][1];
             dhdtbl[numdhd-1][3] = dest[idest][2];
             dhdtbl[numdhd-1][4] = n;
           }
         }           
       }
     }
          
  /* construct chains with random flight procedure                    */

  // place first bead at random position in cube

      x=0.5*(cubesize*duni()-halfcube);
      y=0.5*(cubesize*duni()-halfcube);
      z=0.5*(cubesize*duni()-halfcube);
      x0=x;
      y0=y;
      z0=z;
      xxx[0]=x;
      yyy[0]=y;
      zzz[0]=z;
      chain[0]=0;
      count=1;

      for(i=0;i<numchains;i++)
        {
  // if branch, find position of starting bead
          if(startbead[i]!=0) {
            k=startbead[i];
            x=xxx[k-1];
            y=yyy[k-1];
            z=zzz[k-1];
            }
  // determine random elevation and azimuth (bearing) to next bead
          while(count<bead[i+1])
            {
              incube = false;
              while (!incube)
                {
  // calculate position of next bead - reject and recalculate if outside cube
                  elevation=PI*duni();
                  azimuth=2.0*PI*duni();
                  dx=bondlength*cos(azimuth)*sin(elevation);
                  dy=bondlength*sin(azimuth)*sin(elevation);
                  dz=bondlength*cos(elevation);
                  if(fabs(x+dx)<halfcube && fabs(y+dy)<halfcube && fabs(z+dz)<halfcube) {
                    incube = true;
                    }
                }
              x=x+dx;
              y=y+dy;
              z=z+dz;
              xxx[count]=x;
              yyy[count]=y;
              zzz[count]=z;
              x0 += x;
              y0 += y;
              z0 += z;
              chain[count]=i;
              count++;
            }
        }

  // recentre molecule to its centre of mass

     x0 /= beadtotal;
     y0 /= beadtotal;
     z0 /= beadtotal;

     for(i=0; i<beadtotal; i++) {
       xxx[i] -= x0;
       yyy[i] -= y0;
       zzz[i] -= z0;
     }

  // append information to end of either preexisting FIELD file or separate molecule file

      appendfield << molnam << endl;

      appendfield << "nummols " << popmol << endl;
      appendfield << "beads " << beadtotal << endl;
      for(i=0; i<beadtotal; i++) {
        appendfield << atmnam[species[i]] << " " << xxx[i] << " " << yyy[i] << " " << zzz[i] << endl;
      }
      appendfield << "bonds " << numbond << showpoint << endl;
      for(i=0; i<numbond; i++) {
        l = bndtbl[i][2]-1;
        bdtype = bdtyp[l];
        switch(bdtype) {
          case 1 :
            appendfield << "harm  " << bndtbl[i][0] << " " << bndtbl[i][1] << " " << abond[l] << " " << bbond[l] << endl;
            break;
          case 2 :
            appendfield << "fene  " << bndtbl[i][0] << " " << bndtbl[i][1] << " " << abond[l] << " " << bbond[l] 
                                                                              << " " << cbond[l] << endl;
            break;
          case 3 :
            appendfield << "wlc   " << bndtbl[i][0] << " " << bndtbl[i][1] << " " << abond[l] << " " << bbond[l] << endl;
            break;
          case 4 :
            appendfield << "mors  " << bndtbl[i][0] << " " << bndtbl[i][1] << " " << abond[l] << " " << bbond[l]
                                                                              << " " << cbond[l] << endl;
            break;
        }
      }
      if(numang>0) {
        appendfield << "angles " << numang << endl;
        for(i=0; i<numang; i++) {
          l = angtbl[i][3]-1;
          agtype = agtyp[l];
          switch(agtype) {
            case 1 :
              appendfield << "harm  " << angtbl[i][0] << " " << angtbl[i][1] << " " << angtbl[i][2] << " " 
                                                            << aang[l] << " " << bang[l] << endl;
              break;
            case 2 :
              appendfield << "hcos  " << angtbl[i][0] << " " << angtbl[i][1] << " " << angtbl[i][2] << " " 
                                                            << aang[l] << " " << bang[l] << endl;
              break;
            case 3 :
              appendfield << "cos   " << angtbl[i][0] << " " << angtbl[i][1] << " " << angtbl[i][2] << " " 
                                                            << aang[l] << " " << bang[l] << " " << cang[l] << endl;
              break;
          }
        }
      }

      if(numdhd>0) {
        appendfield << "dihedrals " << numdhd << endl;
        for(i=0; i<numdhd; i++) {
          l = dhdtbl[i][4]-1;
          dhtype = dhtyp[l];
          switch(dhtype) {
            case 1 :
              appendfield << "cos   " << dhdtbl[i][0] << " " << dhdtbl[i][1] << " " << dhdtbl[i][2] << " " << dhdtbl[i][3] << " " 
                                                            << adhd[l] << " " << bdhd[l] << " " << cdhd[l] << endl;
              break;
            case 2 :
              appendfield << "harm  " << dhdtbl[i][0] << " " << dhdtbl[i][1] << " " << dhdtbl[i][2] << " " << dhdtbl[i][3] << " " 
                                                            << adhd[l] << " " << bdhd[l] << endl;
              break;
            case 3 :
              appendfield << "hcos  " << dhdtbl[i][0] << " " << dhdtbl[i][1] << " " << dhdtbl[i][2] << " " << dhdtbl[i][3] << " " 
                                                            << adhd[l] << " " << bdhd[l] << endl;
              break;
          }
        }
      }

      if(!isomer) {
        appendfield << "no isomer" << endl;
      }
      appendfield << "finish" << endl;

      delete [] xxx;
      delete [] yyy;
      delete [] zzz;
      delete [] chain;
      delete [] species;
      delete [] bead;
      delete [] startbead;
      for(i=0; i<beadtotal; i++) {
        delete [] bndtbl[i];
        delete [] angtbl[i];
        delete [] dhdtbl[i];
      }
      delete [] bndtbl;
      delete [] angtbl;
      delete [] dhdtbl;
      for(i=0; i<2*numchains; i++)
        delete [] dest[i];
       delete [] dest;
  }

  appendfield.close();

  delete [] abond;
  delete [] bbond;
  delete [] cbond;
  delete [] aang;
  delete [] bang;
  delete [] cang;
  delete [] adhd;
  delete [] bdhd;
  delete [] cdhd;
  delete [] bdtyp;
  delete [] agtyp;
  delete [] dhtyp;  

  return(0);
}

double duni()
{
  
  //-----------------------------------------------------------------
  //
  //    dl_poly random number generator based on the universal
  //    random number generator of marsaglia, zaman and tsang
  //    (stats and prob. lett. 8 (1990) 35-39.) it must be
  //    called once to initialise parameters uni,c,cd,cm
  //
  //    copyright daresbury laboratory 1992
  //    author -  w.smith         july 1992
  //
  //    wl
  //    2006/11/17 17:26:59
  //    1.2
  //    Exp
  //
  //-----------------------------------------------------------------
  
  long int i,ii,ir,j,jj,jr,k,l,m,me;
  
  double duni=0.0,s,t;
  
  if(newx)
    {
      me=time(0);
 //     me=0;
      //    initial values of i,j,k must be in range 1 to 178 (not all 1)
      //    initial value of l must be in range 0 to 168.
      
      i=((me+12)%178)+1;
      j=((me+34)%178)+1;
      k=((me+56)%178)+1;
      l=((me+78)%168)+1;
      ir=97;
      jr=33;
      newx=false;
      
      for(ii=0;ii<97;ii++)
	{
	  s=0.0;
	  t=0.5;
	  for(jj=0;jj<24;jj++)
	    {

	      m=(((i*j)%179)*k)%179;
	      i=j;
	      j=k;
	      k=m;
	      l=(53*l+1)%169;
	      if(((l*m)%64)>=32)s=s+t;
	      t=0.5*t;
	      
	    }
	  uni[ii]=s;
	}
      c =  362436.0/16777216.0;
      cd= 7654321.0/16777216.0;
      cm=16777213.0/16777216.0;
      uni[97]=cd;
      uni[98]=cm;
      uni[99]=c;
      uni[100]=double(ir);
      uni[101]=double(jr);
    }
  else
    {
      
      //    calculate random number
      
      cd=uni[97];
      cm=uni[98];
      c=uni[99];
      ir=long(uni[100]+0.5);
      jr=long(uni[101]+0.5);
      duni=uni[ir-1]-uni[jr-1];
      if(duni<0.0)duni=duni+1.0;
      uni[ir-1]=duni;
      ir=ir-1;
      if(ir==0)ir=97;
      jr=jr-1;
      if(jr==0)jr=97;
      c=c-cd;
      if(c<0.0)c=c+cm;
      duni=duni-c;
      if(duni<0.0)duni=duni+1.0;
      uni[97]=cd;
      uni[98]=cm;
      uni[99]=c;
      uni[100]=double(ir);
      uni[101]=double(jr);
    }
  
  return duni;
}

double sgn(double a)
{
  if (a>0)
    return 1.;
  else if (a<0)
    return -1.;
  else
    return 0.;
}

string readstring(string strin, int ii)
{
    string buf;
    vector<string> tokens;
    stringstream ss(strin);

    while (ss >> buf)
        tokens.push_back(buf);

    if(ii>=tokens.size()) {
      buf = string();
    }
    else {
      buf = tokens.at(ii);
    }

    return(buf);
}

double readdble(string strin, int ii)
{
    string buf;
    double num;
    vector<string> tokens;
    stringstream ss(strin);

    while (ss >> buf)
        tokens.push_back(buf);

    if(ii>=tokens.size()) {
      num = 0.0;
    }
    else {
      buf = tokens.at(ii);     
      stringstream(buf) >> num;
    }

    return(num);
}

long int readint(string strin, int ii)
{
    string buf;
    long int num;
    vector<string> tokens;
    stringstream ss(strin);

    while (ss >> buf)
        tokens.push_back(buf);

    if(ii>=tokens.size()) {
      num = 0;
    }
    else {
      buf = tokens.at(ii);     
      stringstream(buf) >> num;
    }

    return(num);
}

bool fexists(const char *filename)
{
  ifstream ifile(filename);
  return (bool)ifile;
}

long int neighbourbond(long int index)
{
  long int numneigh;

  for(long int i=0; i<2*numchains; i++)
    dest[i][0] = 0;

  numneigh=0;
  for(long int i=0; i<numbond; i++) {
    if(bndtbl[i][0]==index) {
      numneigh++;
      dest[numneigh-1][0] = i;
     }
  }

  return numneigh;
}

long int neighbourangle(long int index)
{
  long int numang;

  for(long int i=0; i<2*numchains; i++) {
    dest[i][0] = 0;
    dest[i][1] = 0;
  }

  numang=0;
  for(long int i=0; i<numbond; i++) {
    if(bndtbl[i][1]==index) {
      for(long int j=0; j<numbond; j++) {
        if(bndtbl[j][0]==index) {
          numang++;
          dest[numang-1][0] = bndtbl[i][0];
          dest[numang-1][1] = bndtbl[j][1];
         }
       }
     }
  }

  return numang;
}

long int neighbourdihedral(long int index)
{
  long int numdhd;

  for(long int i=0; i<2*numchains; i++) {
    dest[i][0] = 0;
    dest[i][1] = 0;
    dest[i][2] = 0;
  }

  numdhd=0;
  for(long int i=0; i<numbond; i++) {
    if(bndtbl[i][1]==index) {
      for(long int j=0; j<numbond; j++) {
        if(bndtbl[j][0]==index) {
          for(long int k=0; k<numbond; k++) {
            if(bndtbl[k][0]==bndtbl[j][1]) {
              numdhd++;
              dest[numdhd-1][0] = bndtbl[i][0];
              dest[numdhd-1][1] = bndtbl[j][1];
              dest[numdhd-1][2] = bndtbl[k][1];
            }
           }
         }
       }
     }
  }

  return numdhd;
}

