/*
  DL_MESO_LBE
  Authors      :   R.S. Qin, M. A. Seaton
  Contributors :   J. Meng
  Copyright    :   UKRI STFC Daresbury Laboratory
               :   05/11/2004, rev. 04/07/2024
  
*/


// system information

struct sSystem
{
  int nd;
  int nq;
  int nf;
  int nc;
  int nt;
  int pf;
  int nx;
  int ny;
  int nz;
};


// domain information

struct sDomain
{
  int rank;
  int size;
  int bwid;
  int owidx;
  int owidy;
  int owidz;
  int xcor;
  int ycor;
  int zcor;
  int xdim;
  int ydim;
  int zdim;
  int xs;
  int xe;
  int ys;
  int ye;
  int zs;
  int ze;
  int xinner;
  int yinner;
  int zinner;
  int xouter;
  int youter;
  int zouter;
  int touter;
};

// neighbour information

// structure objects

sSystem lbsy;
sDomain lbdm;

// parameters

double  lbiniv[3];
double  lbtopv[3];
double  lbbotv[3];
double  lbfrov[3];
double  lbbacv[3];
double  lblefv[3];
double  lbrigv[3];
double  lbtopvoscil[3];
double  lbbotvoscil[3];
double  lbfrovoscil[3];
double  lbbacvoscil[3];
double  lblefvoscil[3];
double  lbrigvoscil[3];

double lbtopvfq;
double lbbotvfq;
double lbfrovfq;
double lbbacvfq;
double lblefvfq;
double lbrigvfq;

int lbtopvbc;
int lbbotvbc;
int lbfrovbc;
int lbbacvbc;
int lblefvbc;
int lbrigvbc;

double* lbincp;
double* lbinip;
double* lbtopp;
double* lbbotp;
double* lbfrop;
double* lbbacp;
double* lblefp;
double* lbrigp;

double* lbinic;
double* lbtopc;
double* lbbotc;
double* lbfroc;
double* lbbacc;
double* lblefc;
double* lbrigc;

double  lbsyst;
double  lbinit;
double  lbtopt;
double  lbbott;
double  lbfrot;
double  lbbact;
double  lbleft;
double  lbrigt;

double  lbsysdt;
double  lbtopdt;
double  lbbotdt;
double  lbfrodt;
double  lbbacdt;
double  lblefdt;
double  lbrigdt;


double  lbxsize;
int     lbtotstep;
int     lbequstep;
int     lbsave;
int     lbdump;
int     lbcurstep;
int     lbsteer;
int     lbmpiio;
int     lbrestart;

// double lbsmw;
// double lbsmv;
// int    *lbanifold;
// double *lbanitens; 
// double *lbemradius;
// int    *lbemnumber;

double  lbcalctime;
double  lbnoise;
double  lbtrtmagic;
double  lbgasconst;
double *lbtf;
double *lbtfbulk;
double *lbtfclb3;
double *lbtfclb4;
double *lbtc;
double *lbtt;
double  lbtmob;
int    *lbscpot;
int    *lbwet;
double  lbfewet[4];
int     lbfeeos;
int     lbfepot;
int     lbgradord;
int     lbbctyp;
int     lbsbctyp;
int     lbtbctyp;
double  lbkappa;
double  lbfemob;
double *lbg;
double *lbgwall;
double *lbseg;
double *lbpsi0;
double *lbcritt;
double *lbcritp;
double *lbeosa;
double *lbeosb;
double *lbacentric;
double *lbscquad;
double *lbbdforce;
double *lboscilforce;
double *lbbousforce;
double *lbheatforce;
double *lbinterforce;
double  lboscilfreq;
int     lbbdforcetyp;
double *lbomega;
int    *lbrheo;
double *lbrheoa;
double *lbrheob;
double *lbrheoc;
double *lbrheod;
double *lbrheopower;

double *lbf;
double *lbft;
double *lbfeq;
int    *lbphi;
int    *lbneigh;
double *lbboundnorm;

int    *lbvx;
int    *lbvy;
int    *lbvz;
int     lbfevx[19];
int     lbfevy[19];
int     lbfevz[19];
int    *lbopv;
int    *lbspair;
double *lbw;
double *lbvwx;
double *lbvwy;
double *lbvwz;

double *lbwi;
double *lbw0;
double *lbwpt;
double *lbwxx;
double *lbwyy;
double *lbwzz;
double *lbwxy;
double *lbwxz;
double *lbwyz;
double *lbwgam;
double *lbwdel;

double *lbtr;
double *lbtrinv;
double  lbmrts[8];
double  lbmrtw[3];

int    lbsitelength;
double lbdx;
double lbdt;
double lbcs;
double lbcssq;
double lbrcssq;
double lbsoundv;
double lbreynolds;
double lbkinetic;
int    lbyz;
// double lbxst;
// double lbtcoe;
double lbbousth;
double lbboustl;
double lbevaplim;

unsigned long *lbouter;
int lboutersize;

// calculation parameters

int    bigend;
double timetotal;
int    qVersion;
int    collide;
int    interact;
int    incompress;
int    nonnewtonian;
int    outformat;
int    postequil;

// boundary condition types

typedef enum {
    PST = 21,
    PSD = 22,
    PSL = 23,
    PSR = 24,
    PSF = 25,
    PSB = 26,
    CCTRB = 27,
    CCTLB = 28,
    CCDLB = 29,
    CCDRB = 30,
    CCTRF = 31,
    CCTLF = 32,
    CCDLF = 33,
    CCDRF = 34,
    CETR = 43,
    CETL = 44,
    CEDL = 45,
    CEDR = 46,
    CETF = 47,
    CELF = 48,
    CEDF = 49,
    CERF = 50,
    CETB = 51,
    CELB = 52,
    CEDB = 53,
    CERB = 54
} BoundaryType;

static const string dlmversion="2.7";
static const int dlmrevision=11;
static const string dlmdate="July 2024";
static const string dlmyear="2024";

/*
  DL_MESO_LBE
  Authors      :   R.S. Qin, M. A. Seaton
  Contributors :   J. Meng
  Copyright    :   UKRI STFC Daresbury Laboratory
               :   05/11/2004, rev. 04/07/2024

*/  
//	    DL_MESO_LBE functions
//	    camel
//          p-package
//          f-function 
//          s-structure
//          c-class

