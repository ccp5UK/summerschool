int fGetNumberOrdered(int &iox, int &ioy, int &ioz);
int fGetNumberOrdered(int &iox, int &ioy);
int fGetNumberOrderFixed(int &iox, int &ioy, int &ioz,
			 int ix, int iy, int iz);
int fGetNumberOrderFixed(int &iox, int &ioy, int ix, int iy);
int fBestGrouping(int totalgrid, int totalgroup, 
		  int& indigrid, int& critigroup);
int fCppMod(int a, int b);
long fCppMod(long a, long b);
int fPrintLine();
int fPrintDoubleLine();
double fRandom();
int fBigEndian();
void fByteSwap(void *data, int len, int count);
double fCheckTimeSerial();
string fReadString(string line, int i);

