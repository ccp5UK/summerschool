int fsNoInteract();
int fsShanChen();
int fsShanChenQuadratic();
int fsLishchuk();
int fsLishchukSpencer();
int fsLishchukSpencerTensor();
int fsLishchukLocal();
int fsSwift();
