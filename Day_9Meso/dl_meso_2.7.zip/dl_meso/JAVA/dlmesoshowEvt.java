import javax.swing.*;
import java.util.*;
import java.lang.*;
import java.io.*;
import java.awt.*;
import java.awt.event.*;
import java.awt.geom.*;
import java.awt.image.*;
/*
 *     DL_MESO_GUI
 *     author: R. S. Qin, M. A. Seaton
 *     copyright: UKRI STFC Daresbury Laboratory and CCP5
 *     2005, 2018
 */
class dlmesoshowEvt implements ActionListener {
    
    dlmesoshowboard gui;
    public dlmesoshowEvt(dlmesoshowboard in) {
	gui =in;
    }
    public void actionPerformed(ActionEvent event) {
	String cmd =event.getActionCommand();
	if(cmd == "exit")
	    gui.dispose();
    }
}
