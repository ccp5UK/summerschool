/***************************************************
 *   DL_MESO       Version 2.7                     *
 *   Authors   :   R. S. Qin, M. A. Seaton         *
 *   Amended   :   L. Grinberg                     *
 *   Copyright :   UKRI STFC Daresbury Laboratory  *
 *             :   09/12/2018                      *
 ***************************************************/

// No mesoscopic interactions

int fsNoInteract()
{
  int (*fCollision)() = &fCollisionBGK;
  int cont;
  // select subroutine for collisions
  switch (collide) {
    case 0:
    // option 0: BGK with standard forcing
      fCollision = &fCollisionBGK;
      break;
    case 1:
    // option 1: BGK with EDM forcing
      fCollision = &fCollisionBGKEDM;
      break;
    case 2:
    // option 2: BGK with Guo forcing
      fCollision = &fCollisionBGKGuo;
      break;
    case 3:
    // option 3: BGK with He forcing
      fCollision = &fCollisionBGKHe;
      break;
    case 4:
    // option 4: TRT with standard forcing
      fCollision = &fCollisionTRT;
      break;
    case 5:
    // option 5: TRT with EDM forcing
      fCollision = &fCollisionTRTEDM;
      break;
    case 6:
    // option 6: TRT with Guo forcing
      fCollision = &fCollisionTRTGuo;
      break;
    case 7:
    // option 7: TRT with He forcing
      fCollision = &fCollisionTRTHe;
      break;
    case 8:
    // option 8: MRT with standard forcing
      fCollision = &fCollisionMRT;
      break;
    case 9:
    // option 9: MRT with EDM forcing
      fCollision = &fCollisionMRTEDM;
      break;
    case 10:
    // option 10: MRT with Guo-like forcing
      fCollision = &fCollisionMRTGuo;
      break;
    case 11:
    // option 11: MRT with He forcing
      fCollision = &fCollisionMRTHe;
      break;
    case 12:
    // option 12: CLBE with standard forcing
      fCollision = &fCollisionCLBE;
      break;
    case 13:
    // option 13: CLBE with EDM forcing
      fCollision = &fCollisionCLBEEDM;
      break;
    case 14:
    // option 14: CLBE with Guo-like forcing
      fCollision = &fCollisionCLBEGuo;
      break;
    case 15:
    // option 15: CLBE with He forcing
      fCollision = &fCollisionCLBEHe;
      break;
  }
  do {
    if(lbcurstep==lbtotstep || (lbdump>0 && lbcurstep%lbdump == 0))
      fWriteRestart();
    if(lbcurstep%lbsave == 0 || lbcurstep==lbequstep) {
      if(lbequstep>0 && lbcurstep==lbequstep) {
        fPrintEndEquilibration();
        postequil = 1;
        fReadSpaceParameter();
        fNeighbourBoundary();
      }
      if(lbcurstep>=lbequstep)
        fOutput();
      cout << left << setw(12) << lbcurstep << " ";
      fPrintDomainMass();
      double timeelapsed = fCheckTimeSerial();
      cout << left << setw(12) << timeelapsed << " ";
      fPrintDomainMomentum();
    }
    if(lbsy.nt==1) {
      fInteractionForceZero();
      fConvectionForceBoussinesq(lbbousth, lbboustl);
    }
    switch (nonnewtonian) {
      case 1:
        fGetSystemOmegaSimple();
        break;
      case 2:
        fGetSystemOmega();
        break;
    }
    fCollision();
    fPostCollBoundary();
    fPropagationSwap();
    fPostPropBoundary();
    lbcurstep++;
    double timecheck = fCheckTimeSerial();
    cont = !((lbcalctime>0.0 && timecheck>lbcalctime) || lbcurstep>lbtotstep);
  }
  while(cont);
  return 0;
}

// Shan-Chen pseudopotential interactions

int fsShanChen()
{
  int (*fCollision)() = &fCollisionBGKShanChen;
  int cont;
  // select subroutine for collisions
  switch (collide) {
    case 0:
    // option 0: BGK with standard forcing
      fCollision = &fCollisionBGKShanChen;
      break;
    case 1:
    // option 1: BGK with EDM forcing
      fCollision = &fCollisionBGKEDMShanChen;
      break;
    case 2:
    // option 2: BGK with Guo forcing
      fCollision = &fCollisionBGKGuoShanChen;
      break;
    case 3:
    // option 3: BGK with He forcing
      fCollision = &fCollisionBGKHeShanChen;
      break;
    case 4:
    // option 4: TRT with standard forcing
      fCollision = &fCollisionTRTShanChen;
      break;
    case 5:
    // option 5: TRT with EDM forcing
      fCollision = &fCollisionTRTEDMShanChen;
      break;
    case 6:
    // option 6: TRT with Guo forcing
      fCollision = &fCollisionTRTGuoShanChen;
      break;
    case 7:
    // option 7: TRT with He forcing
      fCollision = &fCollisionTRTHeShanChen;
      break;
    case 8:
    // option 8: MRT with standard forcing
      fCollision = &fCollisionMRTShanChen;
      break;
    case 9:
    // option 9: MRT with EDM forcing
      fCollision = &fCollisionMRTEDMShanChen;
      break;
    case 10:
    // option 10: MRT with Guo-like forcing
      fCollision = &fCollisionMRTGuoShanChen;
      break;
    case 11:
    // option 11: MRT with He forcing
      fCollision = &fCollisionMRTHeShanChen;
      break;
    case 12:
    // option 12: CLBE with standard forcing
      fCollision = &fCollisionCLBEShanChen;
      break;
    case 13:
    // option 13: CLBE with EDM forcing
      fCollision = &fCollisionCLBEEDMShanChen;
      break;
    case 14:
    // option 14: CLBE with Guo-like forcing
      fCollision = &fCollisionCLBEGuoShanChen;
      break;
    case 15:
    // option 15: CLBE with He forcing
      fCollision = &fCollisionCLBEHeShanChen;
      break;
  }
  do {
    if(lbcurstep==lbtotstep || (lbdump>0 && lbcurstep%lbdump == 0))
      fWriteRestart();
    if(lbcurstep%lbsave == 0 || lbcurstep==lbequstep) {
      if(lbequstep>0 && lbcurstep==lbequstep) {
        fPrintEndEquilibration();
        postequil = 1;
        fReadSpaceParameter();
        fNeighbourBoundary();
      }
      if(lbcurstep>=lbequstep)
        fOutput();
      cout << left << setw(12) << lbcurstep << " ";
      fPrintDomainMass();
      double timeelapsed = fCheckTimeSerial();
      cout << left << setw(12) << timeelapsed << " ";
      fPrintDomainMomentum();
    }
    fInteractionForceZero();
    fConvectionForceBoussinesq(lbbousth, lbboustl);
    fCalcPotential_ShanChen();
    fsInteractionForceShanChen();
    switch (nonnewtonian) {
      case 1:
        fGetSystemOmegaSimple();
        break;
      case 2:
        fGetSystemOmega();
        break;
    }
    fCollision();
    fPostCollBoundary();
    fPropagationSwap();
    fPostPropBoundary();
    lbcurstep++;
    double timecheck = fCheckTimeSerial();
    cont = !((lbcalctime>0.0 && timecheck>lbcalctime) || lbcurstep>lbtotstep);
  }
  while(cont);
  return 0;
}

// Shan/Chen pseudopotential interactions with quadratic pseudopotential term

int fsShanChenQuadratic()
{
  int (*fCollision)() = &fCollisionBGKShanChen;
  int cont;
  // select subroutine for collisions
  switch (collide) {
    case 0:
    // option 0: BGK with standard forcing
      fCollision = &fCollisionBGKShanChen;
      break;
    case 1:
    // option 1: BGK with EDM forcing
      fCollision = &fCollisionBGKEDMShanChen;
      break;
    case 2:
    // option 2: BGK with Guo forcing
      fCollision = &fCollisionBGKGuoShanChen;
      break;
    case 3:
    // option 3: BGK with He forcing
      fCollision = &fCollisionBGKHeShanChen;
      break;
    case 4:
    // option 4: TRT with standard forcing
      fCollision = &fCollisionTRTShanChen;
      break;
    case 5:
    // option 5: TRT with EDM forcing
      fCollision = &fCollisionTRTEDMShanChen;
      break;
    case 6:
    // option 6: TRT with Guo forcing
      fCollision = &fCollisionTRTGuoShanChen;
      break;
    case 7:
    // option 7: TRT with He forcing
      fCollision = &fCollisionTRTHeShanChen;
      break;
    case 8:
    // option 8: MRT with standard forcing
      fCollision = &fCollisionMRTShanChen;
      break;
    case 9:
    // option 9: MRT with EDM forcing
      fCollision = &fCollisionMRTEDMShanChen;
      break;
    case 10:
    // option 10: MRT with Guo-like forcing
      fCollision = &fCollisionMRTGuoShanChen;
      break;
    case 11:
    // option 11: MRT with He forcing
      fCollision = &fCollisionMRTHeShanChen;
      break;
    case 12:
    // option 12: CLBE with standard forcing
      fCollision = &fCollisionCLBEShanChen;
      break;
    case 13:
    // option 13: CLBE with EDM forcing
      fCollision = &fCollisionCLBEEDMShanChen;
      break;
    case 14:
    // option 14: CLBE with Guo-like forcing
      fCollision = &fCollisionCLBEGuoShanChen;
      break;
    case 15:
    // option 15: CLBE with He forcing
      fCollision = &fCollisionCLBEHeShanChen;
      break;
  }
  do {
    if(lbcurstep==lbtotstep || (lbdump>0 && lbcurstep%lbdump == 0))
      fWriteRestart();
    if(lbcurstep%lbsave == 0 || lbcurstep==lbequstep) {
      if(lbequstep>0 && lbcurstep==lbequstep) {
        fPrintEndEquilibration();
        postequil = 1;
        fReadSpaceParameter();
        fNeighbourBoundary();
      }
      if(lbcurstep>=lbequstep)
        fOutput();
      cout << left << setw(12) << lbcurstep << " ";
      fPrintDomainMass();
      double timeelapsed = fCheckTimeSerial();
      cout << left << setw(12) << timeelapsed << " ";
      fPrintDomainMomentum();
    }
    fInteractionForceZero();
    fConvectionForceBoussinesq(lbbousth, lbboustl);
    fCalcPotential_ShanChen();
    fsInteractionForceShanChenQuadratic();
    switch (nonnewtonian) {
      case 1:
        fGetSystemOmegaSimple();
        break;
      case 2:
        fGetSystemOmega();
        break;
    }
    fCollision();
    fPostCollBoundary();
    fPropagationSwap();
    fPostPropBoundary();
    lbcurstep++;
    double timecheck = fCheckTimeSerial();
    cont = !((lbcalctime>0.0 && timecheck>lbcalctime) || lbcurstep>lbtotstep);
  }
  while(cont);
  return 0;
}

// Lishchuk continuum-based interactions (with interfacial normals calculated non-locally)

int fsLishchuk()
{
  int (*fCollision)() = &fCollisionBGKLishchuk;
  int cont;
  // select subroutine for collisions
  switch (collide) {
    case 0:
    // option 0: BGK with standard forcing
      fCollision = &fCollisionBGKLishchuk;
      break;
    case 1:
    // option 1: BGK with EDM forcing
      fCollision = &fCollisionBGKEDMLishchuk;
      break;
    case 2:
    // option 2: BGK with Guo forcing
      fCollision = &fCollisionBGKGuoLishchuk;
      break;
    case 3:
    // option 3: BGK with He forcing
      fCollision = &fCollisionBGKHeLishchuk;
      break;
    case 4:
    // option 4: TRT with standard forcing
      fCollision = &fCollisionTRTLishchuk;
      break;
    case 5:
    // option 5: TRT with EDM forcing
      fCollision = &fCollisionTRTEDMLishchuk;
      break;
    case 6:
    // option 6: TRT with Guo forcing
      fCollision = &fCollisionTRTGuoLishchuk;
      break;
    case 7:
    // option 7: TRT with He forcing
      fCollision = &fCollisionTRTHeLishchuk;
      break;
    case 8:
    // option 8: MRT with standard forcing
      fCollision = &fCollisionMRTLishchuk;
      break;
    case 9:
    // option 9: MRT with EDM forcing
      fCollision = &fCollisionMRTEDMLishchuk;
      break;
    case 10:
    // option 10: MRT with Guo-like forcing
      fCollision = &fCollisionMRTGuoLishchuk;
      break;
    case 11:
    // option 11: MRT with He forcing
      fCollision = &fCollisionMRTHeLishchuk;
      break;
    case 12:
    // option 12: CLBE with standard forcing
      fCollision = &fCollisionCLBELishchuk;
      break;
    case 13:
    // option 13: CLBE with EDM forcing
      fCollision = &fCollisionCLBEEDMLishchuk;
      break;
    case 14:
    // option 14: CLBE with Guo-like forcing
      fCollision = &fCollisionCLBEGuoLishchuk;
      break;
    case 15:
    // option 15: CLBE with He forcing
      fCollision = &fCollisionCLBEHeLishchuk;
      break;
  }
  do {
    if(lbcurstep==lbtotstep || (lbdump>0 && lbcurstep%lbdump == 0))
      fWriteRestart();
    if(lbcurstep%lbsave == 0 || lbcurstep==lbequstep) {
      if(lbequstep>0 && lbcurstep==lbequstep) {
        fPrintEndEquilibration();
        postequil = 1;
        fReadSpaceParameter();
        fNeighbourBoundary();
      }
      if(lbcurstep>=lbequstep)
        fOutput();
      cout << left << setw(12) << lbcurstep << " ";
      fPrintDomainMass();
      double timeelapsed = fCheckTimeSerial();
      cout << left << setw(12) << timeelapsed << " ";
      fPrintDomainMomentum();
    }
    fInteractionForceZero();
    fConvectionForceBoussinesq(lbbousth, lbboustl);
    fsCalcPhaseIndex_Lishchuk();
    fsInteractionForceLishchuk();
    switch (nonnewtonian) {
      case 1:
        fGetSystemOmegaSimple();
        break;
      case 2:
        fGetSystemOmega();
        break;
    }
    fCollision();
    fPostCollBoundary();
    fPropagationSwap();
    fPostPropBoundary();
    lbcurstep++;
    double timecheck = fCheckTimeSerial();
    cont = !((lbcalctime>0.0 && timecheck>lbcalctime) || lbcurstep>lbtotstep);
  }
  while(cont);
  return 0;
}

// Lishchuk-Spencer continuum-based interactions (with interfacial normals calculated non-locally)

int fsLishchukSpencer()
{
  int (*fCollision)() = &fCollisionBGKLishchuk;
  int cont;
  // select subroutine for collisions
  switch (collide) {
    case 0:
    // option 0: BGK with standard forcing
      fCollision = &fCollisionBGKLishchuk;
      break;
    case 1:
    // option 1: BGK with EDM forcing
      fCollision = &fCollisionBGKEDMLishchuk;
      break;
    case 2:
    // option 2: BGK with Guo forcing
      fCollision = &fCollisionBGKGuoLishchuk;
      break;
    case 3:
    // option 3: BGK with He forcing
      fCollision = &fCollisionBGKHeLishchuk;
      break;
    case 4:
    // option 4: TRT with standard forcing
      fCollision = &fCollisionTRTLishchuk;
      break;
    case 5:
    // option 5: TRT with EDM forcing
      fCollision = &fCollisionTRTEDMLishchuk;
      break;
    case 6:
    // option 6: TRT with Guo forcing
      fCollision = &fCollisionTRTGuoLishchuk;
      break;
    case 7:
    // option 7: TRT with He forcing
      fCollision = &fCollisionTRTHeLishchuk;
      break;
    case 8:
    // option 8: MRT with standard forcing
      fCollision = &fCollisionMRTLishchuk;
      break;
    case 9:
    // option 9: MRT with EDM forcing
      fCollision = &fCollisionMRTEDMLishchuk;
      break;
    case 10:
    // option 10: MRT with Guo-like forcing
      fCollision = &fCollisionMRTGuoLishchuk;
      break;
    case 11:
    // option 11: MRT with He forcing
      fCollision = &fCollisionMRTHeLishchuk;
      break;
    case 12:
    // option 12: CLBE with standard forcing
      fCollision = &fCollisionCLBELishchuk;
      break;
    case 13:
    // option 13: CLBE with EDM forcing
      fCollision = &fCollisionCLBEEDMLishchuk;
      break;
    case 14:
    // option 14: CLBE with Guo-like forcing
      fCollision = &fCollisionCLBEGuoLishchuk;
      break;
    case 15:
    // option 15: CLBE with He forcing
      fCollision = &fCollisionCLBEHeLishchuk;
      break;
  }
  do {
    if(lbcurstep==lbtotstep || (lbdump>0 && lbcurstep%lbdump == 0))
      fWriteRestart();
    if(lbcurstep%lbsave == 0 || lbcurstep==lbequstep) {
      if(lbequstep>0 && lbcurstep==lbequstep) {
        fPrintEndEquilibration();
        postequil = 1;
        fReadSpaceParameter();
        fNeighbourBoundary();
      }
      if(lbcurstep>=lbequstep)
        fOutput();
      cout << left << setw(12) << lbcurstep << " ";
      fPrintDomainMass();
      double timeelapsed = fCheckTimeSerial();
      cout << left << setw(12) << timeelapsed << " ";
      fPrintDomainMomentum();
    }
    fInteractionForceZero();
    fConvectionForceBoussinesq(lbbousth, lbboustl);
    fsCalcPhaseIndex_Lishchuk();
    fsInteractionForceLishchukSpencer();
    switch (nonnewtonian) {
      case 1:
        fGetSystemOmegaSimple();
        break;
      case 2:
        fGetSystemOmega();
        break;
    }
    fCollision();
    fPostCollBoundary();
    fPropagationSwap();
    fPostPropBoundary();
    lbcurstep++;
    double timecheck = fCheckTimeSerial();
    cont = !((lbcalctime>0.0 && timecheck>lbcalctime) || lbcurstep>lbtotstep);
  }
  while(cont);
  return 0;
}

// Lishchuk-Spencer-tensor continuum-based interactions (with interfacial normals calculated non-locally)

int fsLishchukSpencerTensor()
{
  int (*fCollision)() = &fCollisionBGKLishchukLocal;
  int cont;
  // select subroutine for collisions
  switch (collide) {
    case 0:
    // option 0: BGK with standard forcing
      fCollision = &fCollisionBGKLishchukLocal;
      break;
    case 1:
    // option 1: BGK with EDM forcing
      fCollision = &fCollisionBGKEDMLishchukLocal;
      break;
    case 2:
    // option 2: BGK with Guo forcing
      fCollision = &fCollisionBGKGuoLishchukLocal;
      break;
    case 3:
    // option 3: BGK with He forcing
      fCollision = &fCollisionBGKHeLishchukLocal;
      break;
    case 4:
    // option 4: TRT with standard forcing
      fCollision = &fCollisionTRTLishchukLocal;
      break;
    case 5:
    // option 5: TRT with EDM forcing
      fCollision = &fCollisionTRTEDMLishchukLocal;
      break;
    case 6:
    // option 6: TRT with Guo forcing
      fCollision = &fCollisionTRTGuoLishchukLocal;
      break;
    case 7:
    // option 7: TRT with He forcing
      fCollision = &fCollisionTRTHeLishchukLocal;
      break;
    case 8:
    // option 8: MRT with standard forcing
      fCollision = &fCollisionMRTLishchukLocal;
      break;
    case 9:
    // option 9: MRT with EDM forcing
      fCollision = &fCollisionMRTEDMLishchukLocal;
      break;
    case 10:
    // option 10: MRT with Guo-like forcing
      fCollision = &fCollisionMRTGuoLishchukLocal;
      break;
    case 11:
    // option 11: MRT with He forcing
      fCollision = &fCollisionMRTHeLishchukLocal;
      break;
    case 12:
    // option 12: CLBE with standard forcing
      fCollision = &fCollisionCLBELishchukLocal;
      break;
    case 13:
    // option 13: CLBE with EDM forcing
      fCollision = &fCollisionCLBEEDMLishchukLocal;
      break;
    case 14:
    // option 14: CLBE with Guo-like forcing
      fCollision = &fCollisionCLBEGuoLishchukLocal;
      break;
    case 15:
    // option 15: CLBE with He forcing
      fCollision = &fCollisionCLBEHeLishchukLocal;
      break;
  }
  do {
    if(lbcurstep==lbtotstep || (lbdump>0 && lbcurstep%lbdump == 0))
      fWriteRestart();
    if(lbcurstep%lbsave == 0 || lbcurstep==lbequstep) {
      if(lbequstep>0 && lbcurstep==lbequstep) {
        fPrintEndEquilibration();
        postequil = 1;
        fReadSpaceParameter();
        fNeighbourBoundary();
      }
      if(lbcurstep>=lbequstep)
        fOutput();
      cout << left << setw(12) << lbcurstep << " ";
      fPrintDomainMass();
      double timeelapsed = fCheckTimeSerial();
      cout << left << setw(12) << timeelapsed << " ";
      fPrintDomainMomentum();
    }
    fInteractionForceZero();
    fConvectionForceBoussinesq(lbbousth, lbboustl);
    fsCalcPhaseIndex_Lishchuk();
    fWallInteractionForceLishchukLocal();
    switch (nonnewtonian) {
      case 1:
        fGetSystemOmegaSimple();
        break;
      case 2:
        fGetSystemOmega();
        break;
    }
    fCollision();
    fPostCollBoundary();
    fPropagationSwap();
    fPostPropBoundary();
    lbcurstep++;
    double timecheck = fCheckTimeSerial();
    cont = !((lbcalctime>0.0 && timecheck>lbcalctime) || lbcurstep>lbtotstep);
  }
  while(cont);
  return 0;
}

// Lishchuk continuum-based interactions (with interfacial normals calculated locally)

int fsLishchukLocal()
{
  int (*fCollision)() = &fCollisionBGKLishchukLocal;
  int cont;
  // select subroutine for collisions
  switch (collide) {
    case 0:
    // option 0: BGK with standard forcing
      fCollision = &fCollisionBGKLishchukLocal;
      break;
    case 1:
    // option 1: BGK with EDM forcing
      fCollision = &fCollisionBGKEDMLishchukLocal;
      break;
    case 2:
    // option 2: BGK with Guo forcing
      fCollision = &fCollisionBGKGuoLishchukLocal;
      break;
    case 3:
    // option 3: BGK with He forcing
      fCollision = &fCollisionBGKHeLishchukLocal;
      break;
    case 4:
    // option 4: TRT with standard forcing
      fCollision = &fCollisionTRTLishchukLocal;
      break;
    case 5:
    // option 5: TRT with EDM forcing
      fCollision = &fCollisionTRTEDMLishchukLocal;
      break;
    case 6:
    // option 6: TRT with Guo forcing
      fCollision = &fCollisionTRTGuoLishchukLocal;
      break;
    case 7:
    // option 7: TRT with He forcing
      fCollision = &fCollisionTRTHeLishchukLocal;
      break;
    case 8:
    // option 8: MRT with standard forcing
      fCollision = &fCollisionMRTLishchukLocal;
      break;
    case 9:
    // option 9: MRT with EDM forcing
      fCollision = &fCollisionMRTEDMLishchukLocal;
      break;
    case 10:
    // option 10: MRT with Guo-like forcing
      fCollision = &fCollisionMRTGuoLishchukLocal;
      break;
    case 11:
    // option 11: MRT with He forcing
      fCollision = &fCollisionMRTHeLishchukLocal;
      break;
    case 12:
    // option 12: CLBE with standard forcing
      fCollision = &fCollisionCLBELishchukLocal;
      break;
    case 13:
    // option 13: CLBE with EDM forcing
      fCollision = &fCollisionCLBEEDMLishchukLocal;
      break;
    case 14:
    // option 14: CLBE with Guo-like forcing
      fCollision = &fCollisionCLBEGuoLishchukLocal;
      break;
    case 15:
    // option 15: CLBE with He forcing
      fCollision = &fCollisionCLBEHeLishchukLocal;
      break;
  }
  do {
    if(lbcurstep==lbtotstep || (lbdump>0 && lbcurstep%lbdump == 0))
      fWriteRestart();
    if(lbcurstep%lbsave == 0 || lbcurstep==lbequstep) {
      if(lbequstep>0 && lbcurstep==lbequstep) {
        fPrintEndEquilibration();
        postequil = 1;
        fReadSpaceParameter();
        fNeighbourBoundary();
      }
      if(lbcurstep>=lbequstep)
        fOutput();
      cout << left << setw(12) << lbcurstep << " ";
      fPrintDomainMass();
      double timeelapsed = fCheckTimeSerial();
      cout << left << setw(12) << timeelapsed << " ";
      fPrintDomainMomentum();
    }
    fInteractionForceZero();
    fConvectionForceBoussinesq(lbbousth, lbboustl);
    fCalcPhaseIndex_LishchukLocal();
    fWallInteractionForceLishchukLocal();
    switch (nonnewtonian) {
      case 1:
        fGetSystemOmegaSimple();
        break;
      case 2:
        fGetSystemOmega();
        break;
    }
    fCollision();
    fPostCollBoundary();
    fPropagationSwap();
    fPostPropBoundary();
    lbcurstep++;
    double timecheck = fCheckTimeSerial();
    cont = !((lbcalctime>0.0 && timecheck>lbcalctime) || lbcurstep>lbtotstep);
  }
  while(cont);
  return 0;
}

// Swift free-energy interactions

int fsSwift()
{
  int (*fCollision)() = &fCollisionBGKSwift;
  int cont;
 // select subroutine for collisions
  switch (collide) {
    case 0:
    // option 0: BGK with standard forcing
      fCollision = &fCollisionBGKSwift;
      break;
    case 1:
    // option 1: BGK with EDM forcing
      fCollision = &fCollisionBGKEDMSwift;
      break;
    case 2:
    // option 2: BGK with Guo forcing
      fCollision = &fCollisionBGKGuoSwift;
      break;
    case 3:
    // option 3: BGK with He forcing
      fCollision = &fCollisionBGKHeSwift;
      break;
    case 4:
    // option 4: TRT with standard forcing
      fCollision = &fCollisionTRTSwift;
      break;
    case 5:
    // option 5: TRT with EDM forcing
      fCollision = &fCollisionTRTEDMSwift;
      break;
    case 6:
    // option 6: TRT with Guo forcing
      fCollision = &fCollisionTRTGuoSwift;
      break;
    case 7:
    // option 7: TRT with He forcing
      fCollision = &fCollisionTRTHeSwift;
      break;
    case 8:
    // option 8: MRT with standard forcing
      fCollision = &fCollisionMRTSwift;
      break;
    case 9:
    // option 9: MRT with EDM forcing
      fCollision = &fCollisionMRTEDMSwift;
      break;
    case 10:
    // option 10: MRT with Guo-like forcing
      fCollision = &fCollisionMRTGuoSwift;
      break;
    case 11:
    // option 11: MRT with He forcing
      fCollision = &fCollisionMRTHeSwift;
      break;
    case 12:
    // option 12: CLBE with standard forcing - not available
      break;
    case 13:
    // option 13: CLBE with EDM forcing - not available
      break;
    case 14:
    // option 14: CLBE with Guo-like forcing - not available
      break;
    case 15:
    // option 15: CLBE with He forcing - not available
      break;
  }
  do {
    if(lbcurstep==lbtotstep || (lbdump>0 && lbcurstep%lbdump == 0))
      fWriteRestart();
    if(lbcurstep%lbsave == 0 || lbcurstep==lbequstep) {
      if(lbequstep>0 && lbcurstep==lbequstep) {
        fPrintEndEquilibration();
        postequil = 1;
        fReadSpaceParameter();
        fNeighbourBoundary();
      }
      if(lbcurstep>=lbequstep)
        fOutput();
      cout << left << setw(12) << lbcurstep << " ";
      fPrintDomainMass();
      double timeelapsed = fCheckTimeSerial();
      cout << left << setw(12) << timeelapsed << " ";
      fPrintDomainMomentum();
    }
    fInteractionForceZero();
    fConvectionForceBoussinesq(lbbousth, lbboustl);
    fsCalcGradient_Swift();
    switch (nonnewtonian) {
      case 1:
        fGetSystemOmegaSimple();
        break;
      case 2:
        fGetSystemOmega();
        break;
    }
    fCollision();
    fPostCollBoundary();
    fPropagationSwap();
    fPostPropBoundary();
    lbcurstep++;
    double timecheck = fCheckTimeSerial();
    cont = !((lbcalctime>0.0 && timecheck>lbcalctime) || lbcurstep>lbtotstep);
  }
  while(cont);
  return 0;
}


