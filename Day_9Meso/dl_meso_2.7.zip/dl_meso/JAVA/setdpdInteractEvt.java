import javax.swing.*;
import java.util.*;
import java.lang.*;
import java.io.*;
import java.awt.*;
import java.awt.event.*;
import java.awt.geom.*;
import java.awt.image.*;
/*
 *     DL_MESO_GUI
 *     author: R. S. Qin, M. A. Seaton
 *     copyright: UKRI STFC Daresbury Laboratory and CCP5
 *     2005, 2018
 */
class setdpdInteractEvt implements ItemListener, ActionListener {

    static setdpdInteract sg;
    setSpecies spg; 
    setInteraction ig;
    setExternal eg;
    FileWriter ot;
    String rcmd;
    String str;
    String filename = "FIELD";
    String editor = "dlmesoEditor";
    dpdsysdim dim = new dpdsysdim();
    int xint,ii,jj,kk;
    int srftype=dim.srftyp;
    boolean frozen=dim.frzwalls;
    double xdouble;
    static int nspe, npot, ktyp, externtype, frzspe;
    static double bdfx, bdfy, bdfz, frzdens, frzthick;
    static String[] spenam = new String[10];
    static double spemass[] = new double[10];
    static double spechge[] = new double[10];
    static int spenum[] = new int[10];
    static int spefrz[] = new int[10];
    static double srfaa[] = new double[10];
    static double srfdist[] = new double[10];
    static int srfktype[] = new int[10];
    static double aa[] = new double[10*(10+1)/2];
    static double bb[] = new double[10*(10+1)/2];
    static double cc[] = new double[10*(10+1)/2];
    static double dd[] = new double[10*(10+1)/2];
    static double ee[] = new double[10*(10+1)/2];
    static double gamma[] = new double[10*(10+1)/2];
    static double distance[] = new double[10*(10+1)/2];
    static int ktype[] = new int[10*(10+1)/2];
    private static String OS = System.getProperty("os.name").toLowerCase();

    public setdpdInteractEvt(setdpdInteract setinteractions) {
	    sg=setinteractions;
        nspe = 1;
        npot = 1;
        for (int i=0; i<10; i++) {
          spenam[i] = "SPEC"+(i+1);
        }
        java.util.Arrays.fill(spenum, 0);
        java.util.Arrays.fill(spemass, 1.0);
        java.util.Arrays.fill(spechge, 1.0);
        java.util.Arrays.fill(spefrz, 0);
        java.util.Arrays.fill(aa, 25.0);
        java.util.Arrays.fill(bb, 0.0);
        java.util.Arrays.fill(cc, 0.0);
        java.util.Arrays.fill(dd, 0.0);
        java.util.Arrays.fill(ee, 0.0);
        java.util.Arrays.fill(gamma, 4.5);
        java.util.Arrays.fill(distance, 1.0);
        java.util.Arrays.fill(ktype, 2);
        java.util.Arrays.fill(srfaa, 25.0);
        java.util.Arrays.fill(srfdist, 1.0);
        java.util.Arrays.fill(srfktype, 0);
        kk=0;
        ktyp=2;
    }

    public setdpdInteractEvt(setSpecies speini) {
        spg=speini;
    }

    public setdpdInteractEvt(setInteraction interactdpd) {
        ig=interactdpd;
    }

    public setdpdInteractEvt(setExternal externdpd) {
        eg=externdpd;
    }


    public void actionPerformed(ActionEvent event) {
        String cmd =event.getActionCommand();
        if (cmd == "set species") {
            nspe = (Integer)sg.species.getValue();
            npot = nspe * (nspe+1) / 2;
            setspecies(nspe, spenam, spemass, spechge, spenum, spefrz);
        }
        else if (cmd == "set interactions") {
            setinteract(nspe, spenam, ktype[0], aa[0], bb[0], cc[0], dd[0], ee[0], gamma[0], distance[0], srftype, srfktype[0], srfaa[0], srfdist[0], frozen, frzspe, frzdens, frzthick);
        }
        
        else if (cmd == "SAVE SP") {
            savespecies();
        }
        else if (cmd == "CLOSE SP") {
            spg.dispose();
        }

        else if (cmd == "SET I") {
             ii = ig.speci.getSelectedIndex();
             jj = ig.specj.getSelectedIndex();
             if (ii>jj) {
                 kk = ii;
                 ii = jj;
                 jj = kk;
             }
             kk = jj * (jj + 1) / 2 + ii;
             xdouble=Double.parseDouble(ig.aa.getText());
             aa[kk]=xdouble;
             xdouble=Double.parseDouble(ig.bb.getText());
             bb[kk]=xdouble;
             xdouble=Double.parseDouble(ig.cc.getText());
             cc[kk]=xdouble;
             xdouble=Double.parseDouble(ig.dd.getText());
             dd[kk]=xdouble;
             xdouble=Double.parseDouble(ig.ee.getText());
             ee[kk]=xdouble;
             xdouble=Double.parseDouble(ig.dist.getText());
             distance[kk]=xdouble;
             xdouble=Double.parseDouble(ig.gamma.getText());
             gamma[kk]=xdouble;
             ktype[kk]=ktyp;
             kk = ig.specsrf.getSelectedIndex();
             xdouble=Double.parseDouble(ig.srfaa.getText());
             srfaa[kk] = xdouble;
             xdouble=Double.parseDouble(ig.srfdist.getText());
             srfdist[kk] = xdouble;
             srfktype[kk] = ig.intersrf.getSelectedIndex();
             frzspe = ig.wallspec.getSelectedIndex();
             xdouble=Double.parseDouble(ig.walldens.getText());
             frzdens = xdouble;
             xdouble=Double.parseDouble(ig.wallthick.getText());
             frzthick = xdouble;
        }
        else if (cmd == "CLOSE I") {
            ig.dispose();
        }

        else if (cmd == "SAVE E") {
            saveexternal();
        }
        else if (cmd == "CANCEL E") {
            eg.dispose();
        }

        else if (cmd == "create molecules"){
            try {
                if(isMac()) {
                    String executionPath = System.getProperty("user.dir");
                    rcmd = "tell application \"Terminal\" to do script \"cd "+executionPath+";./molecule.exe;exit\"";
                    String[] rcmdargs = { "osascript", "-e", rcmd };
                    Process p2 = Runtime.getRuntime().exec(rcmdargs);
                    BufferedReader ou2 = new BufferedReader
                    (new InputStreamReader(p2.getInputStream()));
                    String line2;
                    while ((line2 = ou2.readLine()) != null)
                        System.out.println(line2);
                }
                else if(isWindows()) {
                    rcmd = "molecule.exe -p";
                    if(nspe>0) {
                      rcmd = rcmd+" -s "+nspe;
                      for(int i=0; i<nspe; i++)
                        rcmd = rcmd+" "+spenam[i];
                    }
                    String[] rcmdargs = { "cmd.exe", "/c", rcmd };
                    Process p2 = Runtime.getRuntime().exec(rcmdargs);
                    BufferedReader ou2 = new BufferedReader
                    (new InputStreamReader(p2.getInputStream()));
                    String line2;
                    while ((line2 = ou2.readLine()) != null)
                        System.out.println(line2);
                }
                else {
                    rcmd = "./molecule.exe -p";
                    if(nspe>0) {
                      rcmd = rcmd+" -s "+nspe;
                      for(int i=0; i<nspe; i++)
                        rcmd = rcmd+" "+spenam[i];
                    }
                    String[] rcmdargs = { "xterm", "-e", rcmd };
                    Process p2 = Runtime.getRuntime().exec(rcmdargs);
                    BufferedReader ou2 = new BufferedReader
                    (new InputStreamReader(p2.getInputStream()));
                    String line2;
                    while ((line2 = ou2.readLine()) != null)
                        System.out.println(line2);
                }
            } catch (IOException e1) {
                System.out.println(e1);
            }
        }
        else if(cmd == "set parameters") {
             externtype = sg.external.getSelectedIndex();
             setexternal(externtype,bdfx,bdfy,bdfz);
        }
        else if(cmd == "edit FIELD file") {
             if(editor=="dlmesoEditor") {
                 dledit(filename);
             }
             else if(editor=="other") {
                 str = sg.otheredit.getText() + " " + filename;
                 try {
                     Process p2 = Runtime.getRuntime().exec(str);
                     BufferedReader ou2 = new BufferedReader
                     (new InputStreamReader(p2.getErrorStream()));
                     String line2;
                     while ((line2 = ou2.readLine()) != null)
                         System.err.println(line2);
                } catch (IOException e1) {
                    ierr(" "+sg.otheredit.getText()+": not found");
                }
            }
            else {
                str = editor + " " + filename;
                try {
                    Process p2 = Runtime.getRuntime().exec(str);
                    BufferedReader ou2 = new BufferedReader
                    (new InputStreamReader(p2.getErrorStream()));
                    String line2;
                    while ((line2 = ou2.readLine()) != null)
                        System.err.println(line2);
                } catch (IOException e1) {
                    ierr(" "+editor+": not found");
                }
            }
        }
        else if(cmd == "OPEN") {
            String input,input1;
            String[] words,words1;
            int i,j,k,speci,specj,npottemp;
            externtype = 0;
            File it = new File(filename);
            if(!it.exists()) {
                ierr(" cannot find "+filename+" file ");
            }
            try {
                BufferedReader in = new BufferedReader(new FileReader(filename));
                while((input = in.readLine()) != null) {
                    words = input.split("\\s+");
                    k = words.length;
                    if(words[0].toLowerCase().startsWith("finish"))
                      break;
                    else if(words[0].toLowerCase().startsWith("species")) {
                        nspe = Integer.parseInt(words[1]);
                        npot = nspe*(nspe+1)/2;
                        if(nspe<1) {
                          ierr(" cannot find any species in "+filename+" file ");
                          break;
                        }
                        else if(nspe>10) {
                          ierr(" cannot read more than 10 bead species ");
                          nspe = 10; // restrict reading to up to 10 bead species
                        }
                        sg.species.setValue(Integer.valueOf(nspe));
                        for(i=0; i<nspe; i++) {
                            input = in.readLine();
                            words = input.split("\\s+");
                            k = words.length;
                            spenam[i] = words[0];
                            spemass[i] = Double.parseDouble(words[1]);
                            spechge[i] = Double.parseDouble(words[2]);
                            if(k>3)
                                spenum[i] = Integer.parseInt(words[3]);
                            if(k>4) {
                                if (Integer.parseInt(words[4])>0)
                                    spefrz[i] = 1;
                                else
                                    spefrz[i] = 0;
                            }
                        }
                    }
                    else if(words[0].toLowerCase().startsWith("interact")) {
                        npottemp = Integer.parseInt(words[1]);
                        for(i=0; i<npottemp; i++) {
                            input = in.readLine();
                            words = input.split("\\s+");
                            k = words.length;
                            speci = -1;
                            specj = -1;
                            for(j=0; j<nspe; j++) {
                                if(Objects.equals(words[0], spenam[j])) speci = j;
                                if(Objects.equals(words[1], spenam[j])) specj = j;
                            }
                            if(speci>=0 && speci<nspe && specj>=0 && specj<nspe) {
                                if(speci>specj)
                                  j = speci * (speci + 1) / 2 + specj;
                                else
                                  j = specj * (specj + 1) / 2 + speci;
                                if(words[2].toLowerCase().startsWith("lj")) {
                                    ktype[j] = 0;
                                    aa[j] = Double.parseDouble(words[3]);
                                    bb[j] = 0.0;
                                    cc[j] = 0.0;
                                    dd[j] = 0.0;
                                    ee[j] = 0.0;
                                    distance[j] = Double.parseDouble(words[4]);
                                    gamma[j] = Double.parseDouble(words[5]);
                                }
                                else if(words[2].toLowerCase().startsWith("wca")) {
                                    ktype[j] = 1;
                                    aa[j] = Double.parseDouble(words[3]);
                                    bb[j] = 0.0;
                                    cc[j] = 0.0;
                                    dd[j] = 0.0;
                                    ee[j] = 0.0;
                                    distance[j] = Double.parseDouble(words[4]);
                                    gamma[j] = Double.parseDouble(words[5]);
                                }
                                else if(words[2].toLowerCase().startsWith("dpd")) {
                                    ktype[j] = 2;
                                    aa[j] = Double.parseDouble(words[3]);
                                    bb[j] = 0.0;
                                    cc[j] = 0.0;
                                    dd[j] = 0.0;
                                    ee[j] = 0.0;
                                    distance[j] = Double.parseDouble(words[4]);
                                    gamma[j] = Double.parseDouble(words[5]);
                                }
                                else if(words[2].toLowerCase().startsWith("mdpd")) {
                                    ktype[j] = 3;
                                    aa[j] = Double.parseDouble(words[3]);
                                    bb[j] = Double.parseDouble(words[4]);
                                    cc[j] = Double.parseDouble(words[5]);
                                    dd[j] = Double.parseDouble(words[6]);
                                    ee[j] = Double.parseDouble(words[7]);
                                    distance[j] = Double.parseDouble(words[8]);
                                    gamma[j] = Double.parseDouble(words[9]);
                                }
                            }
                        }
                    }
                    else if(words[0].toLowerCase().startsWith("frozen")) {
                        input = in.readLine();
                        words = input.split("\\s+");
                        k = words.length;
                        frzspe = -1;
                        for(j=0; j<nspe; j++) {
                                if(Objects.equals(words[0], spenam[j])) frzspe = j;
                        }
                        if(frzspe<0) {
                            ierr(" cannot identify species for frozen bead walls ");
                        }
                        frzdens = Double.parseDouble(words[1]);
                        frzthick = Double.parseDouble(words[2]);
                    }
                    else if(words[0].toLowerCase().startsWith("surf")) {
                        npottemp = Integer.parseInt(words[1]);
                        for(i=0; i<npottemp; i++) {
                            input = in.readLine();
                            words = input.split("\\s+");
                            k = words.length;
                            speci = -1;
                            for(j=0; j<nspe; j++) {
                                if(Objects.equals(words[0], spenam[j])) speci = j;
                            }
                            if(speci>=0 && speci<nspe) {
                                if(words[1].toLowerCase().startsWith("dpd")) {
                                    srfktype[speci] = 0;
                                    srfaa[speci] = Double.parseDouble(words[2]);
                                    srfdist[speci] = Double.parseDouble(words[3]);
                                }
                                else if(words[1].toLowerCase().startsWith("wca")) {
                                    srfktype[speci] = 1;
                                    srfaa[speci] = Double.parseDouble(words[2]);
                                    srfdist[speci] = Double.parseDouble(words[3]);
                                }
                            }
                        }
                    }
                    else if(words[0].toLowerCase().startsWith("extern")) {
                        input = in.readLine();
                        words = input.split("\\s+");
                        k = words.length;
                        if(words[0].toLowerCase().startsWith("grav"))
                          externtype = 1;
                        else if(words[0].toLowerCase().startsWith("shea"))
                          externtype = 2;
                        else if(words[0].toLowerCase().startsWith("elec"))
                          externtype = 3;
                        bdfx = Double.parseDouble(words[1]);
                        bdfy = Double.parseDouble(words[2]);
                        bdfz = Double.parseDouble(words[3]);
                    }
                }
                sg.setinteract.setEnabled(true);
                sg.exterforce.setEnabled(true);
                sg.external.setEnabled(true);
                sg.external.setSelectedIndex(externtype);
                sg.savefield.setEnabled(true);
            } catch (IOException e) {
                ierr(" error when reading "+filename+" ");
                System.out.println("Exception: "+e.getMessage());
            }
        }
        else if(cmd == "SAVE") {
             try {
                ot = new FileWriter(filename, false);
                ot.write(setdpdSysEvt.name+"\n\n");
                ot.write("SPECIES "+nspe+"\n");
                for(int i=0; i<nspe; i++) {
                    ot.write(spenam[i]+" "+spemass[i]+" "+spechge[i]+" "+spenum[i]+" "+spefrz[i]+"\n");
                }
                ot.write("\n");
                if(srftype>1) {
                    ot.write("SURFACES "+nspe+"\n");
                    for(int i=0; i<nspe; i++) {
                        switch (srfktype[i]) {
                            case 0: ot.write(spenam[i]+" dpd  "+srfaa[i]+" "+srfdist[i]+"\n"); break;
                            case 1: ot.write(spenam[i]+" wca  "+srfaa[i]+" "+srfdist[i]+"\n"); break;
                        }
                    }
                    ot.write("\n");
                }
                ot.write("INTERACTIONS "+npot+"\n");
                for(int i=0; i<nspe; i++) {
                    for(int j=i; j<nspe; j++) {
                        kk = j * (j + 1) / 2 + i;
                        switch (ktype[kk]) {
                            case 0: ot.write(spenam[i]+" "+spenam[j]+" lj   "+aa[kk]+" "+distance[kk]+" "+gamma[kk]+"\n"); break;
                            case 1: ot.write(spenam[i]+" "+spenam[j]+" wca  "+aa[kk]+" "+distance[kk]+" "+gamma[kk]+"\n"); break;
                            case 2: ot.write(spenam[i]+" "+spenam[j]+" dpd  "+aa[kk]+" "+distance[kk]+" "+gamma[kk]+"\n"); break;
                            case 3: ot.write(spenam[i]+" "+spenam[j]+" mdpd "+aa[kk]+" "+bb[kk]+" "+cc[kk]+" "+dd[kk]+" "+ee[kk]
                                     +" "+distance[kk]+" "+gamma[kk]+"\n"); break;
                        }
                    }
                }
                ot.write("\n");
                if(setdpdSysEvt.frzx || setdpdSysEvt.frzy || setdpdSysEvt.frzx) {
                    ot.write("FROZEN\n");
                    ot.write(spenam[frzspe]+" "+frzdens+" "+frzthick+"\n\n");
                }
                switch (externtype) {
                  case 0: break;
                  case 1: ot.write("EXTERNAL\n");
                          ot.write("grav "+bdfx+" "+bdfy+" "+bdfz+"\n\n");
                          break;
                  case 2: ot.write("EXTERNAL\n");
                          ot.write("shear "+bdfx+" "+bdfy+" "+bdfz+"\n\n");
                          break;
                  case 3: ot.write("EXTERNAL\n");
                          ot.write("elec "+bdfx+" "+bdfy+" "+bdfz+"\n\n");
                          break;
                }
            } catch (IOException e) {
                ierr(" cannot write to FIELD file ");
            }
            try(BufferedReader br = new BufferedReader(new FileReader("molecule"))) {
                for(String line; (line = br.readLine()) != null; ) {
                    ot.write(line+"\n");
                }
                ot.write("\n");
            }
            catch (FileNotFoundException e)
            {
                // not a problem: no molecules needed!
            }
            catch (IOException e)
            {
                ierr(" error when inserting molecule data from molecule file ");
            }
            try {
                 ot.write("close\n");
             } catch (IOException e) {
                 ierr(" cannot write to FIELD file ");
             }
             try {
                 ot.close();
             } catch (IOException e) {
                 ierr(" error when closing FIELD file ");
             }
             sg.setspecies.setEnabled(false);
             sg.setinteract.setEnabled(false);
             sg.createmolecule.setEnabled(false);
             sg.openfield.setEnabled(false);
             sg.savefield.setEnabled(false);
             sg.external.setEnabled(false);
             sg.compiled.setEnabled(false);
             sg.exterforce.setEnabled(false);
             sg.exterparam.setEnabled(false);
             sg.textedit.setEnabled(true);
             sg.editor.setEnabled(true);
             sg.editfile.setEnabled(true);
             sg.otheredit.setEnabled(true);
        }

    }

    public void itemStateChanged(ItemEvent event) {
	Object item=event.getItem();
	String answer=item.toString();

        if(answer == "DPD") {
            ktyp = 2;
            ig.blabel.setEnabled(false);
            ig.clabel.setEnabled(false);
            ig.dlabel.setEnabled(false);
            ig.elabel.setEnabled(false);
            ig.bb.setEnabled(false);
            ig.bb.setEditable(false);
            ig.cc.setEnabled(false);
            ig.cc.setEditable(false);
            ig.dd.setEnabled(false);
            ig.dd.setEditable(false);
            ig.ee.setEnabled(false);
            ig.ee.setEditable(false);
        }
        else if(answer == "many-body DPD") {
            ktyp = 3;
            ig.blabel.setEnabled(true);
            ig.clabel.setEnabled(true);
            ig.dlabel.setEnabled(true);
            ig.elabel.setEnabled(true);
            ig.bb.setEnabled(true);
            ig.bb.setEditable(true);
            ig.cc.setEnabled(true);
            ig.cc.setEditable(true);
            ig.dd.setEnabled(true);
            ig.dd.setEditable(true);
            ig.ee.setEnabled(true);
            ig.ee.setEditable(true);
        }
        else if(answer == "Lennard-Jones") {
            ktyp = 0;
            ig.blabel.setEnabled(false);
            ig.clabel.setEnabled(false);
            ig.dlabel.setEnabled(false);
            ig.elabel.setEnabled(false);
            ig.bb.setEnabled(false);
            ig.bb.setEditable(false);
            ig.cc.setEnabled(false);
            ig.cc.setEditable(false);
            ig.dd.setEnabled(false);
            ig.dd.setEditable(false);
            ig.ee.setEnabled(false);
            ig.ee.setEditable(false);
        }
        else if(answer == "WCA") {
            ktyp = 1;
            ig.blabel.setEnabled(false);
            ig.clabel.setEnabled(false);
            ig.dlabel.setEnabled(false);
            ig.elabel.setEnabled(false);
            ig.bb.setEnabled(false);
            ig.bb.setEditable(false);
            ig.cc.setEnabled(false);
            ig.cc.setEditable(false);
            ig.dd.setEnabled(false);
            ig.dd.setEditable(false);
            ig.ee.setEnabled(false);
            ig.ee.setEditable(false);
        }

        else if(answer == "none") {
            sg.exterparam.setEnabled(false);
        }

        else if(answer == "gravity") {
            sg.exterparam.setEnabled(true);
        }

        else if(answer == "linear shear") {
            sg.exterparam.setEnabled(true);
        }

        else if(answer == "electric field") {
            sg.exterparam.setEnabled(true);
        }
        
        else if(answer == "emacs") {
            editor = "emacs";
        }

        else if(answer == "notepad") {
            editor = "notepad";
        }

        else if(answer == "vi") {
            editor = "vi";
        }

        else if(answer == "dlmesoEditor") {
            editor = "dlmesoEditor";
        }

        else if(answer == "other ...") {
            editor = "other";
        }

        else if(event.getSource()==ig.specsrf) {
             ii = ig.specsrf.getSelectedIndex();
             str = Double.toString(srfaa[ii]);
             ig.srfaa.setText(str);
             str = Double.toString(srfdist[ii]);
             ig.srfdist.setText(str);
             ig.intersrf.setSelectedIndex(srfktype[ii]);
        }

        else if(event.getSource()==ig.speci || event.getSource()==ig.specj) {
             ii = ig.speci.getSelectedIndex();
             jj = ig.specj.getSelectedIndex();
             if (ii>jj) {
                 kk = ii;
                 ii = jj;
                 jj = kk;
             }
             kk = jj * (jj + 1) / 2 + ii;
             str = Double.toString(aa[kk]);
             ig.aa.setText(str);
             str = Double.toString(bb[kk]);
             ig.bb.setText(str);
             str = Double.toString(cc[kk]);
             ig.cc.setText(str);
             str = Double.toString(dd[kk]);
             ig.dd.setText(str);
             str = Double.toString(ee[kk]);
             ig.ee.setText(str);
             str = Double.toString(distance[kk]);
             ig.dist.setText(str);
             str = Double.toString(gamma[kk]);
             ig.gamma.setText(str);
             switch (ktype[kk]) {
                 case 0: ig.inter.setSelectedIndex(2); break;
                 case 1: ig.inter.setSelectedIndex(3); break;
                 case 2: ig.inter.setSelectedIndex(0); break;
                 case 3: ig.inter.setSelectedIndex(1); break;
             }
        }

    }

    void setspecies(int totspe, String[] names, double[] masses, double[] charges, int[] numbers, int[] frozen) {
      setSpecies spg= new setSpecies(totspe,names,masses,charges,numbers,frozen);
    }

    void  savespecies() {
        int i, j, k;
        String str;
        try {
           for(i=0; i<nspe; i++) {
             str = spg.specname[i].getText();
             if (str.isEmpty())
                 throw new NumberFormatException ("Enter species name");
             str = str.toUpperCase() + "        ";
             spenam[i] = str.substring(0, 8);
             xint = Integer.parseInt(spg.specpop[i].getText());
             spenum[i] = xint;
             xdouble=Double.parseDouble(spg.specmass[i].getText());
             spemass[i] = xdouble;
             xdouble=Double.parseDouble(spg.speccharge[i].getText());
             spechge[i] = xdouble;
             if(spg.specfroz[i].isSelected())
                 spefrz[i] = 1;
             else
                 spefrz[i] = 0;
             
            }
            spg.dispose();
            } catch (NumberFormatException enfl) {
                ierr(" species parameter: format error or no value ");
            }
        }

    void setinteract(int totspe, String[] names, int ktyp, double aa, double bb, double cc, double dd, double ee, double gamm, double dist, int sftyp, int srfktyp, double srfaa, double srfdist, boolean froz, int wallspe, double wallrho, double wallthick) {
        setInteraction ig= new setInteraction(totspe, names, ktyp, aa, bb, cc, dd, ee, gamm, dist, sftyp, srfktyp, srfaa, srfdist, froz, wallspe, wallrho, wallthick);
    }

    void setexternal(int exttype, double ex, double ey, double ez) {
      setExternal eg= new setExternal(exttype,ex,ey,ez);
    }

    void  saveexternal() {
	  try {
        bdfx=Double.parseDouble(eg.aex.getText());
        bdfy=Double.parseDouble(eg.bex.getText());
        bdfz=Double.parseDouble(eg.cex.getText());
 	    eg.dispose();
	  } catch (NumberFormatException enfl) {
	    ierr(" species parameter: format error or no value ");
      }
    }

    void dledit(String str) {
	dlmesoeditor dlm = new dlmesoeditor(str);
    }

    void ierr(String errinfo) {
      msgPanel fcer=new msgPanel(errinfo);	
    }

    public static boolean isWindows() {
        return (OS.indexOf("win") >= 0);
    }
    
    public static boolean isMac() {
        return (OS.indexOf("mac") >= 0);
    }
    
    public static boolean isUnix() {
        return (OS.indexOf("nix") >= 0 || OS.indexOf("nux") >= 0 || OS.indexOf("aix") >= 0 || OS.indexOf("sunos") >= 0 );
    }

}
