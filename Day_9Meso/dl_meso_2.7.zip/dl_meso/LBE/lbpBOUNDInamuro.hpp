int fD2Q9VCEInamuro(double v0, double v1, double *force, double *f0, double *f1, double *f2,
                    double *f3, double *f4, double *f5, double *f6, double *f7, double *f8);
int fD2Q9VCCInamuro(double *p, double v0, double v1, double *force, long tpos, double *f0, double *f1, double *f2,
                    double *f3, double *f4, double *f5, double *f6, double *f7, double *f8);
int fD2Q9VCECLBEInamuro(double v0, double v1, double *force, double *f0, double *f1, double *f2,
                        double *f3, double *f4, double *f5, double *f6, double *f7, double *f8);
int fD2Q9VCCCLBEInamuro(double *p, double v0, double v1, double *force, long tpos, double *f0, double *f1, double *f2,
                        double *f3, double *f4, double *f5, double *f6, double *f7, double *f8);
int fD2Q9VCESwiftInamuro(double v0, double v1, double *force, double *f0, double *f1, double *f2,
                         double *f3, double *f4, double *f5, double *f6, double *f7, double *f8,
                         double drdx, double drdy, double dpdx, double dpdy, double nabr, double nabp, double *omega, double T);
int fD2Q9VCCSwiftInamuro(double *p, double v0, double v1, double *force, long tpos, double *f0, double *f1, double *f2,
                         double *f3, double *f4, double *f5, double *f6, double *f7, double *f8,
                         double drdx, double drdy, double dpdx, double dpdy, double nabr, double nabp, double *omega, double T);
int fD2Q9VFInamuro(long tpos, long tpos1, int prop, double *uwall, double dx, double dy, double T);
int fD2Q9PCEInamuro(double *p, double *force, double *f0, double *f1, double *f2, double *f3,
                    double *f4, double *f5, double *f6, double *f7, double *f8, double &vel);
int fD2Q9PCECLBEInamuro(double *p, double *force, double *f0, double *f1, double *f2, double *f3,
                        double *f4, double *f5, double *f6, double *f7, double *f8, double &vel);
int fD2Q9PCESwiftInamuro(double *p, double *force, double *f0, double *f1, double *f2, double *f3,
                         double *f4, double *f5, double *f6, double *f7, double *f8,
                         double drdx, double drdy, double dpdx, double dpdy, double nabr, double napr,
                         double *omega, double T, double &vel);
int fD2Q9PFInamuro(long tpos, int prop, double *p0, double *uwall, double T);
int fD2Q9CCEInamuro(double *p, double v0, double v1, double *f0, double *f1, double *f2,
                    double *f3, double *f4, double *f5, double *f6, double *f7, double *f8);
int fD2Q9CCCInamuro(double *p, double v0, double v1, double *f0, double *f1, double *f2,
                    double *f3, double *f4, double *f5, double *f6, double *f7, double *f8);
int fD2Q9PCInamuro(long tpos, int prop, double *p0, double *uwall);
int fD2Q9TCEInamuro(double p, double v0, double v1, double *f0, double *f1, double *f2,
                    double *f3, double *f4, double *f5, double *f6, double *f7, double *f8);
int fD2Q9TCCInamuro(double p, double v0, double v1, double *f0, double *f1, double *f2,
                    double *f3, double *f4, double *f5, double *f6, double *f7, double *f8);
int fD2Q9PTInamuro(long tpos, int prop, double p0, double *uwall);

int fD3Q15VPSInamuro(double v0, double v1, double v2, double *force, double *f0, double *f1, double *f2,
                     double *f3, double *f4, double *f5, double *f6, double *f7, double *f8,
                     double *f9, double *f10, double *f11, double *f12, double *f13, double *f14);
int fD3Q15VCEInamuro(double *p, double v0, double v1, double v2, double *force, double *f0, double *f1, double *f2,
                     double *f3, double *f4, double *f5, double *f6, double *f7, double *f8,
                     double *f9, double *f10, double *f11, double *f12, double *f13, double *f14);
int fD3Q15VCCInamuro(double *p, double v0, double v1, double v2, double *force, double *f0, double *f1, double *f2,
                     double *f3, double *f4, double *f5, double *f6, double *f7, double *f8,
                     double *f9, double *f10, double *f11, double *f12, double *f13, double *f14);
int fD3Q15VPSSwiftInamuro(double v0, double v1, double v2, double *force, double *f0, double *f1, double *f2,
                          double *f3, double *f4, double *f5, double *f6, double *f7, double *f8,
                          double *f9, double *f10, double *f11, double *f12, double *f13, double *f14,
                          double drdx, double drdy, double drdz, double dpdx, double dpdy, double dpdz,
                          double nabr, double nabp, double *omega, double T);
int fD3Q15VCESwiftInamuro(double *p, double v0, double v1, double v2, double *force, double *f0, double *f1, double *f2,
                          double *f3, double *f4, double *f5, double *f6, double *f7, double *f8,
                          double *f9, double *f10, double *f11, double *f12, double *f13, double *f14,
                          double drdx, double drdy, double drdz, double dpdx, double dpdy, double dpdz,
                          double nabr, double nabp, double *omega, double T);
int fD3Q15VCCSwiftInamuro(double *p, double v0, double v1, double v2, double *force, double *f0, double *f1, double *f2,
                          double *f3, double *f4, double *f5, double *f6, double *f7, double *f8,
                          double *f9, double *f10, double *f11, double *f12, double *f13, double *f14,
                          double drdx, double drdy, double drdz, double dpdx, double dpdy, double dpdz,
                          double nabr, double nabp, double *omega, double T);
int fD3Q15VFInamuro(long tpos, long rpos, int prop, double *uwall, double dx, double dy, double dz, double T);
int fD3Q15PPSInamuro(double *p, double *force, double *f0, double *f1,
                     double *f2, double *f3, double *f4, double *f5,
                     double *f6, double *f7, double *f8, double *f9,
                     double *f10, double *f11, double *f12, double *f13,
                     double *f14, double &vel);
int fD3Q15PPSSwiftInamuro(double *p, double *force, double *f0, double *f1,
                          double *f2, double *f3, double *f4, double *f5,
                          double *f6, double *f7, double *f8, double *f9,
                          double *f10, double *f11, double *f12, double *f13,
                          double *f14, double drdx, double drdy, double drdz,
                          double dpdx, double dpdy, double dpdz, double nabr,
                          double nabp, double *omega, double T, double &vel);
int fD3Q15PFInamuro(long tpos, int prop, double *p0, double *uwall, double T);
int fD3Q15CPSInamuro(double *p, double v0, double v1, double v2, double *f0, double *f1,
                     double *f2, double *f3, double *f4, double *f5, double *f6,
                     double *f7, double *f8, double *f9, double *f10, double *f11,
                     double *f12, double *f13, double *f14);
int fD3Q15CCEInamuro(double *p, double v0, double v1, double v2, double *f0, double *f1,
                     double *f2, double *f3, double *f4, double *f5, double *f6,
                     double *f7, double *f8, double *f9, double *f10, double *f11,
                     double *f12, double *f13, double *f14);
int fD3Q15CCCInamuro(double *p, double v0, double v1, double v2, double *f0, double *f1,
                     double *f2, double *f3, double *f4, double *f5, double *f6,
                     double *f7, double *f8, double *f9, double *f10, double *f11,
                     double *f12, double *f13, double *f14);
int fD3Q15PCInamuro(long tpos, int prop, double *p0, double *uwall);
int fD3Q15TPSInamuro(double p, double v0, double v1, double v2, double *f0, double *f1,
                     double *f2, double *f3, double *f4, double *f5, double *f6,
                     double *f7, double *f8, double *f9, double *f10, double *f11,
                     double *f12, double *f13, double *f14);
int fD3Q15TCEInamuro(double p, double v0, double v1, double v2, double *f0, double *f1,
                     double *f2, double *f3, double *f4, double *f5, double *f6,
                     double *f7, double *f8, double *f9, double *f10, double *f11,
                     double *f12, double *f13, double *f14);
int fD3Q15TCCInamuro(double p, double v0, double v1, double v2, double *f0, double *f1,
                     double *f2, double *f3, double *f4, double *f5, double *f6,
                     double *f7, double *f8, double *f9, double *f10, double *f11,
                     double *f12, double *f13, double *f14);
int fD3Q15PTInamuro(long tpos, int prop, double p0, double *uwall);

int fD3Q19VPSInamuro(double v0, double v1, double v2, double *force, double *f0, double *f1, double *f2,
                     double *f3, double *f4, double *f5, double *f6, double *f7, double *f8,
                     double *f9, double *f10, double *f11, double *f12, double *f13, double *f14,
                     double *f15, double *f16, double *f17, double *f18);
int fD3Q19VCEInamuro(double *p, double v0, double v1, double v2, double *force, double *f0, double *f1, double *f2,
                     double *f3, double *f4, double *f5, double *f6, double *f7, double *f8,
                     double *f9, double *f10, double *f11, double *f12, double *f13, double *f14,
                     double *f15, double *f16, double *f17, double *f18);
int fD3Q19VCCInamuro(double *p, double v0, double v1, double v2, double *force, double *f0, double *f1, double *f2,
                     double *f3, double *f4, double *f5, double *f6, double *f7, double *f8,
                     double *f9, double *f10, double *f11, double *f12, double *f13, double *f14,
                     double *f15, double *f16, double *f17, double *f18);
int fD3Q19VPSCLBEInamuro(double v0, double v1, double v2, double *force, double *f0, double *f1, double *f2,
                         double *f3, double *f4, double *f5, double *f6, double *f7, double *f8,
                         double *f9, double *f10, double *f11, double *f12, double *f13, double *f14,
                         double *f15, double *f16, double *f17, double *f18);
int fD3Q19VCECLBEInamuro(double *p, double v0, double v1, double v2, double *force, double *f0, double *f1, double *f2,
                         double *f3, double *f4, double *f5, double *f6, double *f7, double *f8,
                         double *f9, double *f10, double *f11, double *f12, double *f13, double *f14,
                         double *f15, double *f16, double *f17, double *f18);
int fD3Q19VCCCLBEInamuro(double *p, double v0, double v1, double v2, double *force, double *f0, double *f1, double *f2,
                         double *f3, double *f4, double *f5, double *f6, double *f7, double *f8,
                         double *f9, double *f10, double *f11, double *f12, double *f13, double *f14,
                         double *f15, double *f16, double *f17, double *f18);
int fD3Q19VPSSwiftInamuro(double v0, double v1, double v2, double *force, double *f0, double *f1, double *f2,
                          double *f3, double *f4, double *f5, double *f6, double *f7, double *f8,
                          double *f9, double *f10, double *f11, double *f12, double *f13, double *f14,
                          double *f15, double *f16, double *f17, double *f18,
                          double drdx, double drdy, double drdz, double dpdx, double dpdy, double dpdz,
                          double nabr, double nabp, double *omega, double T);
int fD3Q19VCESwiftInamuro(double *p, double v0, double v1, double v2, double *force, double *f0, double *f1, double *f2,
                          double *f3, double *f4, double *f5, double *f6, double *f7, double *f8,
                          double *f9, double *f10, double *f11, double *f12, double *f13, double *f14,
                          double *f15, double *f16, double *f17, double *f18,
                          double drdx, double drdy, double drdz, double dpdx, double dpdy, double dpdz,
                          double nabr, double nabp, double *omega, double T);
int fD3Q19VCCSwiftInamuro(double *p, double v0, double v1, double v2, double *force, double *f0, double *f1, double *f2,
                          double *f3, double *f4, double *f5, double *f6, double *f7, double *f8,
                          double *f9, double *f10, double *f11, double *f12, double *f13, double *f14,
                          double *f15, double *f16, double *f17, double *f18,
                          double drdx, double drdy, double drdz, double dpdx, double dpdy, double dpdz,
                          double nabr, double nabp, double *omega, double T);
int fD3Q19VFInamuro(long tpos, long rpos, int prop, double *uwall, double dx, double dy, double dz, double T);
int fD3Q19PPSInamuro(double *p, double *force, double *f0, double *f1,
                     double *f2, double *f3, double *f4, double *f5,
                     double *f6, double *f7, double *f8, double *f9,
                     double *f10, double *f11, double *f12, double *f13,
                     double *f14, double *f15, double *f16, double *f17,
                     double *f18, double &vel);
int fD3Q19PPSCLBEInamuro(double *p, double *force, double *f0, double *f1,
                         double *f2, double *f3, double *f4, double *f5,
                         double *f6, double *f7, double *f8, double *f9,
                         double *f10, double *f11, double *f12, double *f13,
                         double *f14, double *f15, double *f16, double *f17,
                         double *f18, double &vel);
int fD3Q19PPSSwiftInamuro(double *p, double *force, double *f0, double *f1,
                          double *f2, double *f3, double *f4, double *f5,
                          double *f6, double *f7, double *f8, double *f9,
                          double *f10, double *f11, double *f12, double *f13,
                          double *f14, double *f15, double *f16, double *f17,
                          double *f18, double drdx, double drdy, double drdz,
                          double dpdx, double dpdy, double dpdz, double nabr,
                          double nabp, double *omega, double T, double &vel);
int fD3Q19PFInamuro(long tpos, int prop, double *p0, double *uwall, double T);
int fD3Q19CPSInamuro(double *p, double v0, double v1, double v2, double *f0, double *f1,
                     double *f2, double *f3, double *f4, double *f5, double *f6,
                     double *f7, double *f8, double *f9, double *f10, double *f11,
                     double *f12, double *f13, double *f14, double *f15, double *f16,
                     double *f17, double *f18);
int fD3Q19CCEInamuro(double *p, double v0, double v1, double v2, double *f0, double *f1,
                     double *f2, double *f3, double *f4, double *f5, double *f6,
                     double *f7, double *f8, double *f9, double *f10, double *f11,
                     double *f12, double *f13, double *f14, double *f15, double *f16,
                     double *f17, double *f18);
int fD3Q19CCCInamuro(double *p, double v0, double v1, double v2, double *f0, double *f1,
                     double *f2, double *f3, double *f4, double *f5, double *f6,
                     double *f7, double *f8, double *f9, double *f10, double *f11,
                     double *f12, double *f13, double *f14, double *f15, double *f16,
                     double *f17, double *f18);
int fD3Q19PCInamuro(long tpos, int prop, double *p0, double *uwall);
int fD3Q19TPSInamuro(double p, double v0, double v1, double v2, double *f0, double *f1,
                     double *f2, double *f3, double *f4, double *f5, double *f6,
                     double *f7, double *f8, double *f9, double *f10, double *f11,
                     double *f12, double *f13, double *f14, double *f15, double *f16,
                     double *f17, double *f18);
int fD3Q19TCEInamuro(double p, double v0, double v1, double v2, double *f0, double *f1,
                     double *f2, double *f3, double *f4, double *f5, double *f6,
                     double *f7, double *f8, double *f9, double *f10, double *f11,
                     double *f12, double *f13, double *f14, double *f15, double *f16,
                     double *f17, double *f18);
int fD3Q19TCCInamuro(double p, double v0, double v1, double v2, double *f0, double *f1,
                     double *f2, double *f3, double *f4, double *f5, double *f6,
                     double *f7, double *f8, double *f9, double *f10, double *f11,
                     double *f12, double *f13, double *f14, double *f15, double *f16,
                     double *f17, double *f18);
int fD3Q19PTInamuro(long tpos, int prop, double p0, double *uwall);

int fD3Q27VPSInamuro(double v0, double v1, double v2, double *force, double *f0, double *f1, double *f2,
                     double *f3, double *f4, double *f5, double *f6, double *f7, double *f8,
                     double *f9, double *f10, double *f11, double *f12, double *f13, double *f14,
                     double *f15, double *f16, double *f17, double *f18, double *f19, double *f20,
                     double *f21, double *f22, double *f23, double *f24, double *f25, double *f26);
int fD3Q27VCEInamuro(double *p, double v0, double v1, double v2, double *force, double *f0, double *f1, double *f2,
                     double *f3, double *f4, double *f5, double *f6, double *f7, double *f8,
                     double *f9, double *f10, double *f11, double *f12, double *f13, double *f14,
                     double *f15, double *f16, double *f17, double *f18, double *f19, double *f20,
                     double *f21, double *f22, double *f23, double *f24, double *f25, double *f26);
int fD3Q27VCCInamuro(double *p, double v0, double v1, double v2, double *force, double *f0, double *f1, double *f2,
                     double *f3, double *f4, double *f5, double *f6, double *f7, double *f8,
                     double *f9, double *f10, double *f11, double *f12, double *f13, double *f14,
                     double *f15, double *f16, double *f17, double *f18, double *f19, double *f20,
                     double *f21, double *f22, double *f23, double *f24, double *f25, double *f26);
int fD3Q27VPSCLBEInamuro(double v0, double v1, double v2, double *force, double *f0, double *f1, double *f2,
                         double *f3, double *f4, double *f5, double *f6, double *f7, double *f8,
                         double *f9, double *f10, double *f11, double *f12, double *f13, double *f14,
                         double *f15, double *f16, double *f17, double *f18, double *f19, double *f20,
                         double *f21, double *f22, double *f23, double *f24, double *f25, double *f26);
int fD3Q27VCECLBEInamuro(double *p, double v0, double v1, double v2, double *force, double *f0, double *f1, double *f2,
                         double *f3, double *f4, double *f5, double *f6, double *f7, double *f8,
                         double *f9, double *f10, double *f11, double *f12, double *f13, double *f14,
                         double *f15, double *f16, double *f17, double *f18, double *f19, double *f20,
                         double *f21, double *f22, double *f23, double *f24, double *f25, double *f26);
int fD3Q27VCCCLBEInamuro(double *p, double v0, double v1, double v2, double *force, double *f0, double *f1, double *f2,
                         double *f3, double *f4, double *f5, double *f6, double *f7, double *f8,
                         double *f9, double *f10, double *f11, double *f12, double *f13, double *f14,
                         double *f15, double *f16, double *f17, double *f18, double *f19, double *f20,
                         double *f21, double *f22, double *f23, double *f24, double *f25, double *f26);
int fD3Q27VFInamuro(long tpos, long rpos, int prop, double *uwall);
int fD3Q27PPSInamuro(double *p, double *force, double *f0, double *f1,
                     double *f2, double *f3, double *f4, double *f5,
                     double *f6, double *f7, double *f8, double *f9,
                     double *f10, double *f11, double *f12, double *f13,
                     double *f14, double *f15, double *f16, double *f17,
                     double *f18, double *f19, double *f20, double *f21,
                     double *f22, double *f23, double *f24, double *f25,
                     double *f26, double &vel);
int fD3Q27PPSCLBEInamuro(double *p, double *force, double *f0, double *f1,
                         double *f2, double *f3, double *f4, double *f5,
                         double *f6, double *f7, double *f8, double *f9,
                         double *f10, double *f11, double *f12, double *f13,
                         double *f14, double *f15, double *f16, double *f17,
                         double *f18, double *f19, double *f20, double *f21,
                         double *f22, double *f23, double *f24, double *f25,
                         double *f26, double &vel);
int fD3Q27PFInamuro(long tpos, int prop, double *p0, double *uwall);
int fD3Q27CPSInamuro(double *p, double v0, double v1, double v2, double *f0, double *f1,
                     double *f2, double *f3, double *f4, double *f5, double *f6,
                     double *f7, double *f8, double *f9, double *f10, double *f11,
                     double *f12, double *f13, double *f14, double *f15, double *f16,
                     double *f17, double *f18, double *f19, double *f20, double *f21,
                     double *f22, double *f23, double *f24, double *f25, double *f26);
int fD3Q27CCEInamuro(double *p, double v0, double v1, double v2, double *f0, double *f1,
                     double *f2, double *f3, double *f4, double *f5, double *f6,
                     double *f7, double *f8, double *f9, double *f10, double *f11,
                     double *f12, double *f13, double *f14, double *f15, double *f16,
                     double *f17, double *f18, double *f19, double *f20, double *f21,
                     double *f22, double *f23, double *f24, double *f25, double *f26);
int fD3Q27CCCInamuro(double *p, double v0, double v1, double v2, double *f0, double *f1,
                     double *f2, double *f3, double *f4, double *f5, double *f6,
                     double *f7, double *f8, double *f9, double *f10, double *f11,
                     double *f12, double *f13, double *f14, double *f15, double *f16,
                     double *f17, double *f18, double *f19, double *f20, double *f21,
                     double *f22, double *f23, double *f24, double *f25, double *f26);
int fD3Q27PCInamuro(long tpos, int prop, double *p0, double *uwall);
int fD3Q27TPSInamuro(double p, double v0, double v1, double v2, double *f0, double *f1,
                     double *f2, double *f3, double *f4, double *f5, double *f6,
                     double *f7, double *f8, double *f9, double *f10, double *f11,
                     double *f12, double *f13, double *f14, double *f15, double *f16,
                     double *f17, double *f18, double *f19, double *f20, double *f21,
                     double *f22, double *f23, double *f24, double *f25, double *f26);
int fD3Q27TCEInamuro(double p, double v0, double v1, double v2, double *f0, double *f1,
                     double *f2, double *f3, double *f4, double *f5, double *f6,
                     double *f7, double *f8, double *f9, double *f10, double *f11,
                     double *f12, double *f13, double *f14, double *f15, double *f16,
                     double *f17, double *f18, double *f19, double *f20, double *f21,
                     double *f22, double *f23, double *f24, double *f25, double *f26);
int fD3Q27TCCInamuro(double p, double v0, double v1, double v2, double *f0, double *f1,
                     double *f2, double *f3, double *f4, double *f5, double *f6,
                     double *f7, double *f8, double *f9, double *f10, double *f11,
                     double *f12, double *f13, double *f14, double *f15, double *f16,
                     double *f17, double *f18, double *f19, double *f20, double *f21,
                     double *f22, double *f23, double *f24, double *f25, double *f26);
int fD3Q27PTInamuro(long tpos, int prop, double p0, double *uwall);

