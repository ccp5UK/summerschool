/***************************************************
 *   DL_MESO       Version 2.7                     *
 *   Authors   :   R. S. Qin, M. A. Seaton         *
 *   Copyright :   UKRI STFC Daresbury Laboratory  *
 *             :   09/12/2018                      *
 ***************************************************/

int fDefineSystem(const char* filename = "lbin.sys")
{
  
  // read calculation parameters from system data file (default: lbin.sys)

  int numb=0;
  int ansi=0;
  string line,issue,value;
  ifstream myfile;

  myfile.open(filename, ios::in);

  if(!myfile)
    {
      cout << "error opening system file" << endl;
      exit(1);
    }

  lbrestart = 0;
  incompress = 0;
  collide = 0;
  interact = 0;
  outformat = 0;

  while (!myfile.eof())
    {

      getline(myfile,line);
      issue = fReadString(line, 0);
      value = fReadString(line, 1);

      if(issue.compare(0,15,"space_dimension")==0) { 
	    lbsy.nd = fStringToNumber <int> (value); numb++; }

      else if(issue.compare(0,14,"discrete_speed")==0) { 
	    lbsy.nq = fStringToNumber <int> (value); numb++; }

      else if(issue.compare(0,15,"number_of_fluid")==0) { 
	    lbsy.nf = fStringToNumber <int> (value); numb++; }

      else if(issue.compare(0,16,"number_of_solute")==0) {
	    lbsy.nc = fStringToNumber <int> (value); numb++; }

      else if(issue.compare(0,18,"temperature_scalar")==0) {
	    lbsy.nt = fStringToNumber <int> (value); numb++; }

      else if(issue.compare(0,11,"phase_field")==0) {
	    lbsy.pf = fStringToNumber <int> (value); numb++; }

      else if(issue.compare(0,13,"grid_number_x")==0) {
	    lbsy.nx = fStringToNumber <int> (value); numb++; }

      else if(issue.compare(0,13,"grid_number_y")==0) {
	    lbsy.ny = fStringToNumber <int> (value); numb++; }

      else if(issue.compare(0,13,"grid_number_z")==0) {
	    lbsy.nz = fStringToNumber <int> (value); numb++; }

      else if(issue.compare(0,21,"domain_boundary_width")==0) { 
	    lbdm.bwid = fStringToNumber <int> (value); numb++; }

      else if(issue.compare(0,21,"incompressible_fluids")==0) { 
	    incompress = fStringToNumber <int> (value); }

      else if(issue.compare(0,18,"restart_simulation")==0) {
	    lbrestart = fStringToNumber <int> (value); }

      else if(issue.compare(0,14,"collision_type")==0) { 
        if(value.compare("BGK")==0) {
          collide = 0;
        }
        else if(value.compare("BGKEDM")==0) {
          collide = 1;
        }
        else if(value.compare("BGKGuo")==0) {
          collide = 2;
        }
        else if(value.compare("BGKHe")==0) {
          collide = 3;
        }
        else if(value.compare("TRT")==0) {
          collide = 4;
        }
        else if(value.compare("TRTEDM")==0) {
          collide = 5;
        }
        else if(value.compare("TRTGuo")==0) {
          collide = 6;
        }
        else if(value.compare("TRTHe")==0) {
          collide = 7;
        }
        else if(value.compare("MRT")==0) {
          collide = 8;
        }
        else if(value.compare("MRTEDM")==0) {
          collide = 9;
        }
        else if(value.compare("MRTGuo")==0) {
          collide = 10;
        }
        else if(value.compare("MRTHe")==0) {
          collide = 11;
        }
        else if(value.compare("CLBE")==0) {
          collide = 12;
        }
        else if(value.compare("CLBEEDM")==0) {
          collide = 13;
        }
        else if(value.compare("CLBEGuo")==0) {
          collide = 14;
        }
        else if(value.compare("CLBEHe")==0) {
          collide = 15;
        }
        else {
          collide = fStringToNumber <int> (value);
        }
      }

      else if(issue.compare(0,16,"interaction_type")==0) { 
        if(value.compare("ShanChen")==0) {
          interact = 1;
        }
        else if(value.compare("ShanChenWetting")==0) {
          interact = 1;
        }
        else if(value.compare("ShanChenQuadratic")==0) {
          interact = 2;
        }
        else if(value.compare("Lishchuk")==0) {
          interact = 10;
        }
        else if(value.compare("LishchukSpencer")==0) {
          interact = 11;
        }
        else if(value.compare("LishchukSpencerTensor")==0) {
          interact = 12;
        }
        else if(value.compare("LishchukLocal")==0) {
          interact = 13;
        }
        else if(value.compare("Swift")==0) {
          interact = 20;
        }
        else {
          interact = fStringToNumber <int> (value);
        }
      }

      else if(issue.compare(0,13,"output_format")==0) {
	    if(value.compare("VTK")==0) {
          outformat = 0;
        }
        else if(value.compare("LegacyVTK")==0) {
          outformat = 1;
        }
        else if(value.compare("Plot3D")==0) {
          outformat = 2;
        }
        else {
          outformat = fStringToNumber <int> (value);
        }
      }

      else if(issue.compare(0,13,"output_type")==0) {
	    if(value.compare("Binary")==0) {
          ansi = 0;
        }
        else if(value.compare("Text")==0 || value.compare("ANSI")==0) {
          ansi = 1;
        }
        else {
          ansi = fStringToNumber <int> (value);
        }
      }
    }

  if(numb < 10) {
    cout << "error: insufficient system information" << endl;
    exit(1); }
  else if(numb>10) {
    cout << "warning: system information may be duplicated - last values used in calculations" << endl; }
  
  if((lbsy.nd == 2) && (lbsy.nz != 1)) {
    lbsy.nz = 1;
    cout << "warning: lbsy.nz is reset to 1" << endl; }

  if(interact==20 && incompress>0) {
    incompress = 0;
    cout << "warning: no incompressible scheme available for Swift free-energy interactions" << endl; }

  if(collide>11 && lbsy.nd==3 && (lbsy.nq!=19 && lbsy.nq!=27)) {
    cout << "error: cascaded LBE schemes only available for D2Q9, D3Q19 and D3Q27 lattices" << endl;
    exit(1); }
    
  if(interact==20 && collide>11) {
    cout << "error: cascaded LBE scheme not available for Swift free-energy interactions" << endl;
    exit(1); }
    
  if(collide>11 && incompress>0) {
    incompress = 0;
    cout << "warning: no incompressible scheme available for cascaded LBE" << endl; }

  outformat += 3*ansi;
    
  lbsitelength = (lbsy.nf + lbsy.nc + lbsy.nt) * lbsy.nq + lbsy.pf;

  myfile.close();
  
  return 0;
  
}


int fInputParameters(const char* filename="lbin.sys")
{
  
  // reads system parameters from system data file (default: lbin.sys)
  
  string line,issue,value,str1,str2;
  stringstream sstm;
  ifstream myfile;
  int eos, pot, bound, wet, rheo;
  
  myfile.open(filename, ios::in);
  
  if(!myfile)
    {
      cout << "error: cannot open system file" << endl;
      exit(1);
    }

  // default values for equilibration steps, evaporation limit,
  // gradient order, gas constant, boundary/force oscillations
  // and restart file writing

  lbequstep = 0;
  lbevaplim = 1e-8;
  lbgradord = 1;
  lbbctyp = 0;
  lbsbctyp = 0;
  lbtbctyp = 0;
  lbgasconst = 1.0;
  lbtopvfq = lbbotvfq = lbfrovfq = lbbacvfq = lblefvfq = lbrigvfq = 0.0;
  lbtopvbc = lbbotvbc = lbfrovbc = lbbacvbc = lblefvbc = lbrigvbc = 0;
  lboscilfreq = 0.0;
  lbbdforcetyp = 0;
  lbdump = 10000;
  lbcalctime = 0.0;

  // default values for I/O subgrid aggregation
    
  lbIOGroup.subgrid[0] = 0;
  lbIOGroup.subgrid[1] = 0;
  lbIOGroup.subgrid[2] = 0;

  // set MRT collision parameters to default values if not otherwise specified

  switch (lbsy.nq) {
    case 9:
      lbmrts[0] = 1.14;  // s2   - tuneable collision parameter
      lbmrts[1] = 1.92;  // s4   - tuneable collision parameter
      lbmrts[2] = lbmrts[3] = lbmrts[4] = lbmrts[5] = lbmrts[6] = lbmrts[7] = 0.0;
      break;
    case 15:
      lbmrts[0] = 1.2;   // s2   - tuneable collision parameter
      lbmrts[1] = 1.6;   // s4   - tuneable collision parameter
      lbmrts[2] = 1.2;   // s14  - tuneable collision parameter
      lbmrts[3] = lbmrts[4] = lbmrts[5] = lbmrts[6] = lbmrts[7] = 0.0;
      break;
    case 19:
      lbmrts[0] = 1.4;   // s2   - tuneable collision parameter
      lbmrts[1] = 1.2;   // s4   - tuneable collision parameter
      lbmrts[2] = 1.98;  // s16  - tuneable collision parameter
      lbmrts[3] = lbmrts[4] = lbmrts[5] = lbmrts[6] = lbmrts[7] = 0.0;
      break;
    case 27:
      lbmrts[0] = 1.5;   // s10  - tuneable collision parameter
      lbmrts[1] = 1.83;  // s13  - tuneable collision parameter
      lbmrts[2] = 1.4;   // s16  - tuneable collision parameter
      lbmrts[3] = 1.61;  // s17  - tuneable collision parameter
      lbmrts[4] = 1.98;  // s18  - tuneable collision parameter
      lbmrts[5] = 1.98;  // s20  - tuneable collision parameter
      lbmrts[6] = 1.74;  // s23  - tuneable collision parameter
      lbmrts[7] = 1.74;  // s26  - tuneable collision parameter
      break;
  }
    
  while (!myfile.eof())
    {
      getline(myfile,line);
      issue = fReadString(line, 0);
      value = fReadString(line, 1);
      eos = -1;
      // get equation of state type based on word given in 'value'
      if(value.compare("IdealLattice")==0)
        eos = 0;
      else if(value.compare("ShanChen1993")==0)
        eos = 1;
      else if(value.compare("ShanChen1994")==0)
        eos = 2;
      else if(value.compare("Qian1995")==0)
        eos = 3;
      else if(value.compare("Rho")==0)
        eos = 4;
      else if(value.compare("Ideal")==0)
        eos = 5;
      else if(value.compare("vanderWaals")==0 || value.compare("vdW")==0)
        eos = 6;
      else if(value.compare("CarnahanStarlingvanderWaals")==0 || value.compare("CSvdW")==0)
        eos = 7;
      else if(value.compare("RedlichKwong")==0 || value.compare("RK")==0)
        eos = 8;
      else if(value.compare("SoaveRedlichKwong")==0 || value.compare("SRK")==0)
        eos = 10;
      else if(value.compare("PengRobinson")==0 || value.compare("PR")==0)
        eos = 12;
      else if(value.compare("CarnahanStarlingRedlichKwong")==0 || value.compare("CSRK")==0)
        eos = 14;

      // get (free-energy) chemical potential type based on word given in 'value'
      pot = -1;
      if(value.compare("None")==0)
        pot = 0;
      else if(value.compare("Quartic")==0)
        pot = 1;
    
      // get boundary condition type based on word given in 'value'
      bound = -1;
      if(value.compare("ZouHe")==0)
        bound = 0;
      else if(value.compare("Inamuro")==0)
        bound = 1;
      else if(value.compare("Regularised")==0 || value.compare("Regularized")==0)
        bound = 2;
      else if(value.compare("SimpleZouHe")==0)
        bound = 10;
      else if(value.compare("Kinetic")==0)
        bound = 11;

      // get boundary wetting type based on word given in 'value':
      // note reuse of numbers for Shan/Chen and Swift free-energy
      // interaction types

      wet = -1;
      if(value.compare("Density")==0)
        wet = 0;
      else if(value.compare("Potential")==0)
        wet = 1;
      else if(value.compare("ScreenedPotential")==0)
        wet = 2;
      else if(value.compare("None")==0)
        wet = 0;
      else if(value.compare("Quadratic")==0)
        wet = 1;

      // get rheological model type based on word given in 'value'
        
      rheo = -1;
      if(value.compare("Simple")==0)
        rheo = 0;
      else if(value.compare("Newtonian")==0)
        rheo = 1;
      else if(value.compare("PowerLaw")==0 || value.compare("Power")==0)
        rheo = 2;
      else if(value.compare("Bingham")==0)
        rheo = 3;
      else if(value.compare("HerschelBulkley")==0 || value.compare("Herschel")==0)
        rheo = 4;
      else if(value.compare("Casson")==0)
        rheo = 5;
      else if(value.compare("CarreauYasuda")==0 || value.compare("Carreau")==0)
        rheo = 6;

      // assign parameters for properties that depend
      // strongly on interaction type
    
      switch(interact) {
        case 1:
        case 2:
	      if(issue.compare("potential_type")==0 || issue.compare("equation_of_state")==0) {
            if(eos>-1) {
              for(int i=0; i<lbsy.nf; i++) {
                lbscpot[i] = eos;
              }
            }
            else {
              for(int i=0; i<lbsy.nf; i++) {
                lbscpot[i] = fStringToNumber <int> (value);
              }
            }
	      }
          else if(issue.compare(0,14,"wetting_type")==0) {
            if(wet>-1) {
              for(int i=0; i<lbsy.nf; i++) {
                lbwet[i] = wet;
              }
            }
            else {
              for(int i=0; i<lbsy.nf; i++) {
                lbwet[i] = fStringToNumber <int> (value);
              }
            }
          }
          break;
        case 20:
	      if(issue.compare("equation_of_state")==0) {
            if(eos>-1)
              lbfeeos = eos;
            else
              lbfeeos = fStringToNumber <int> (value);
	      }
          else if(issue.compare(0,14,"wetting_type")==0) {
            if(wet>-1)
              for(int i=0; i<lbsy.nf; i++) {
                lbwet[i] = wet;
              }
            else
              for(int i=0; i<lbsy.nf; i++) {
                lbwet[i] = fStringToNumber <int> (value);
              }
          }
	      else if(issue.compare("potential_type")==0) {
            if(pot>-1)
              lbfepot = pot;
            else
              lbfepot = fStringToNumber <int> (value);
	      }
          break;
      }
    
      if(issue.compare(0,10,"total_step")==0)
 	    lbtotstep = fStringToNumber <int> (value);
      else if(issue.compare(0,18,"equilibration_step")==0)
        lbequstep = fStringToNumber <int> (value);
      else if(issue.compare(0,9,"save_span")==0)
	    lbsave = fStringToNumber <int> (value);
      else if(issue.compare(0,9,"dump_span")==0)
        lbdump = fStringToNumber <int> (value);
      else if(issue.compare(0,16,"calculation_time")==0)
        lbcalctime = fStringToNumber <double> (value);
      else if(issue.compare(0,15,"noise_intensity")==0)
	    lbnoise = fStringToNumber <double> (value);
      else if(issue.compare(0,11,"sound_speed")==0)
	    lbsoundv = fStringToNumber <double> (value);
      else if(issue.compare(0,17,"kinetic_viscosity")==0)
	    lbkinetic = fStringToNumber <double> (value);
      else if(issue.compare(0,17,"evaporation_limit")==0)
	    lbevaplim = fStringToNumber <double> (value);
      else if(issue.compare(0,16,"trt_magic_number")==0)
        lbtrtmagic = fStringToNumber <double> (value);
      else if(issue.compare(0,12,"gas_constant")==0)
        lbgasconst = fStringToNumber <double> (value);
      else if(issue.compare(0,14,"gradient_order")==0)
        lbgradord = fStringToNumber <int> (value);
      
      else if(issue.compare(0,18,"temperature_system")==0)
	    lbsyst = fStringToNumber <double> (value);
      else if(issue.compare(0,15,"temperature_ini")==0)
	    lbinit = fStringToNumber <double> (value);
      else if(issue.compare(0,15,"temperature_top")==0)
	    lbtopt = fStringToNumber <double> (value);
      else if(issue.compare(0,18,"temperature_bottom")==0)
	    lbbott = fStringToNumber <double> (value);
      else if(issue.compare(0,17,"temperature_front")==0)
	    lbfrot = fStringToNumber <double> (value);
      else if(issue.compare(0,16,"temperature_back")==0)
	    lbbact = fStringToNumber <double> (value);
      else if(issue.compare(0,16,"temperature_left")==0)
	    lbleft = fStringToNumber <double> (value);
      else if(issue.compare(0,17,"temperature_right")==0)
	    lbrigt = fStringToNumber <double> (value);
      else if(issue.compare(0,27,"temperature_boussinesq_high")==0)
	    lbbousth = fStringToNumber <double> (value);
      else if(issue.compare(0,26,"temperature_boussinesq_low")==0)
	    lbboustl = fStringToNumber <double> (value);
      
      else if(issue.compare(0,16,"heating_rate_sys")==0)
	    lbsysdt = fStringToNumber <double> (value);
      else if(issue.compare(0,16,"heating_rate_top")==0)
	    lbtopdt = fStringToNumber <double> (value);
      else if(issue.compare(0,19,"heating_rate_bottom")==0)
	    lbbotdt = fStringToNumber <double> (value);
      else if(issue.compare(0,18,"heating_rate_front")==0)
	    lbfrodt = fStringToNumber <double> (value);
      else if(issue.compare(0,17,"heating_rate_back")==0)
	    lbbacdt = fStringToNumber <double> (value);
      else if(issue.compare(0,17,"heating_rate_left")==0)
	    lblefdt = fStringToNumber <double> (value);
      else if(issue.compare(0,18,"heating_rate_right")==0)
	    lbrigdt = fStringToNumber <double> (value);

      else if(issue.compare(0,14,"relax_mobility")==0)
        lbtmob = 1.0 / fStringToNumber <double> (value);
      else if(issue.compare(0,19,"relax_freq_mobility")==0)
        lbtmob = fStringToNumber <double> (value);
      else if(issue.compare(0,18,"mobility_parameter")==0)
        lbfemob = fStringToNumber <double> (value);
      else if(issue.compare(0,25,"surface_tension_parameter")==0)
        lbkappa = fStringToNumber <double> (value);
      else if(interact==20 && issue.compare(0,15,"eos_parameter_a")==0)
        lbeosa[0] = fStringToNumber <double> (value);
      else if(interact==20 && issue.compare(0,15,"eos_parameter_b")==0)
        lbeosb[0] = fStringToNumber <double> (value);
      else if(interact==20 && lbsy.nf>1 && issue.compare(0,21,"potential_parameter_a")==0)
        lbeosa[1] = fStringToNumber <double> (value);
      else if(interact==20 && lbsy.nf>1 && issue.compare(0,21,"potential_parameter_b")==0)
        lbeosb[1] = fStringToNumber <double> (value);
        
      else if(issue.compare(0,16,"oscillating_freq")==0)
        lboscilfreq = fStringToNumber <double> (value);
      else if(issue.compare(0,18,"oscillating_period")==0)
        lboscilfreq = 1.0 / fStringToNumber <double> (value);
      else if(issue.compare(0,20,"oscillating_freq_top")==0)
        lbtopvfq = fStringToNumber <double> (value);
      else if(issue.compare(0,22,"oscillating_period_top")==0)
        lbtopvfq = 1.0 / fStringToNumber <double> (value);
      else if(issue.compare(0,20,"oscillating_freq_bot")==0)
        lbbotvfq = fStringToNumber <double> (value);
      else if(issue.compare(0,22,"oscillating_period_bot")==0)
        lbbotvfq = 1.0 / fStringToNumber <double> (value);
      else if(issue.compare(0,20,"oscillating_freq_fro")==0)
        lbfrovfq = fStringToNumber <double> (value);
      else if(issue.compare(0,22,"oscillating_period_fro")==0)
        lbfrovfq = 1.0 / fStringToNumber <double> (value);
      else if(issue.compare(0,20,"oscillating_freq_bac")==0)
        lbbacvfq = fStringToNumber <double> (value);
      else if(issue.compare(0,22,"oscillating_period_bac")==0)
        lbbacvfq = 1.0 / fStringToNumber <double> (value);
      else if(issue.compare(0,20,"oscillating_freq_lef")==0)
        lblefvfq = fStringToNumber <double> (value);
      else if(issue.compare(0,22,"oscillating_period_lef")==0)
        lblefvfq = 1.0 / fStringToNumber <double> (value);
      else if(issue.compare(0,20,"oscillating_freq_rig")==0)
        lbrigvfq = fStringToNumber <double> (value);
      else if(issue.compare(0,22,"oscillating_period_rig")==0)
        lbrigvfq = 1.0 / fStringToNumber <double> (value);
        
      else if(issue.compare(0,16,"output_combine_x")==0)
        lbIOGroup.subgrid[0] = fStringToNumber <bool> (value);
      else if(issue.compare(0,16,"output_combine_y")==0)
        lbIOGroup.subgrid[1] = fStringToNumber <bool> (value);
      else if(issue.compare(0,16,"output_combine_z")==0)
        lbIOGroup.subgrid[2] = fStringToNumber <bool> (value);
        
      else if(issue.compare(0,11,"segregation")==0) {
        for(int i=0; i<lbsy.nf*lbsy.nf; i++) {
	      lbseg[i]=fStringToNumber <double> (value);
        }
      }

      else if(issue.compare(0,14,"quadratic_weight")==0) {
        for(int i=0; i<lbsy.nf; i++) {
	      lbscquad[i*lbsy.nf+i]=fStringToNumber <double> (value);
        }
      }
      else if(issue.compare(0,14,"boundary_type")==0) {
        if(bound>-1)
          lbbctyp = bound;
        else
          lbbctyp = fStringToNumber <int> (value);
      }
      else if(issue.compare(0,21,"solute_boundary_type")==0) {
        if(bound>-1 && bound<2)
          lbsbctyp = bound;
        else
          lbsbctyp = fStringToNumber <int> (value);
      }
      else if(issue.compare(0,22,"thermal_boundary_type")==0) {
        if(bound>-1 && bound<2)
          lbtbctyp = bound;
        else
          lbtbctyp = fStringToNumber <int> (value);
      }

      else {
        for(int i=0; i<7; i++) {
          sstm.str(string());
          sstm << "mrt_relax_" << i;
          str1 = sstm.str();
          sstm.str(string());
          sstm << "mrt_relax_freq_" << i;
          str2 = sstm.str();
          if(issue.compare(str1)==0)
            lbmrts[i] = 1.0 / fStringToNumber <double> (value);
          else if(issue.compare(str2)==0)
            lbmrts[i] = fStringToNumber <double> (value);
        }
        for(int i=0; i<2; i++) {
          sstm.str(string());
          sstm << "wetting_parameter_rho_" << i;
          str1 = sstm.str();
          if(issue.compare(str1)==0) {
            lbfewet[i] = fStringToNumber <double> (value); goto Found; }
            
          sstm.str(string());
          sstm << "wetting_parameter_phi_" << i;
          str1 = sstm.str();
          if(issue.compare(str1)==0) {
            lbfewet[2+i] = fStringToNumber <double> (value); goto Found; }
            
        }

        for(int i=0; i<3; i++) {
          sstm.str(string());
          sstm << "speed_ini_" << i;
	      str1 = sstm.str();
	      if(issue.compare(str1)==0) {
	        lbiniv[i] = fStringToNumber <double> (value); goto Found;}
	  
          sstm.str(string());
          sstm << "speed_top_" << i;
	      str1 = sstm.str();
	      if(issue.compare(str1)==0) {
	        lbtopv[i] = fStringToNumber <double> (value);  goto Found;}
	  
          sstm.str(string());
          sstm << "speed_oscil_top_" << i;
	      str1 = sstm.str();
	      if(issue.compare(str1)==0) {
	        lbtopvoscil[i] = fStringToNumber <double> (value);  goto Found;}
	  
          sstm.str(string());
          sstm << "speed_bot_" << i;
	      str1 = sstm.str();
	      if(issue.compare(str1)==0) {
	        lbbotv[i] = fStringToNumber <double> (value); goto Found;}
	  
          sstm.str(string());
          sstm << "speed_oscil_bot_" << i;
	      str1 = sstm.str();
	      if(issue.compare(str1)==0) {
	        lbbotvoscil[i] = fStringToNumber <double> (value); goto Found;}
	  
          sstm.str(string());
          sstm << "speed_fro_" << i;
	      str1 = sstm.str();
	      if(issue.compare(str1)==0) {
	        lbfrov[i] = fStringToNumber <double> (value); goto Found;}
	  
          sstm.str(string());
          sstm << "speed_oscil_fro_" << i;
	      str1 = sstm.str();
	      if(issue.compare(str1)==0) {
	        lbfrovoscil[i] = fStringToNumber <double> (value); goto Found;}
	  
          sstm.str(string());
          sstm << "speed_bac_" << i;
	      str1 = sstm.str();
	      if(issue.compare(str1)==0) {
	        lbbacv[i] = fStringToNumber <double> (value); goto Found;}
	  
          sstm.str(string());
          sstm << "speed_oscil_bac_" << i;
	      str1 = sstm.str();
	      if(issue.compare(str1)==0) {
	        lbbacvoscil[i] = fStringToNumber <double> (value); goto Found;}
	  
          sstm.str(string());
          sstm << "speed_lef_" << i;
	      str1 = sstm.str();
    	  if(issue.compare(str1)==0) {
	        lblefv[i] = fStringToNumber <double> (value); goto Found;}
	  
          sstm.str(string());
          sstm << "speed_oscil_lef_" << i;
	      str1 = sstm.str();
    	  if(issue.compare(str1)==0) {
	        lblefvoscil[i] = fStringToNumber <double> (value); goto Found;}
	  
          sstm.str(string());
          sstm << "speed_rig_" << i;
	      str1 = sstm.str();
	      if(issue.compare(str1)==0) {
	        lbrigv[i] = fStringToNumber <double> (value); goto Found;}
	  
          sstm.str(string());
          sstm << "speed_oscil_rig_" << i;
	      str1 = sstm.str();
	      if(issue.compare(str1)==0) {
	        lbrigvoscil[i] = fStringToNumber <double> (value); goto Found;}
        
	    }
          
	    for(int i=0; i<lbsy.nf; i++) {

/*
          sstm.str(string());
          sstm << "embryo_radius_" << i;
	      str1 = sstm.str();
	      if(issue.compare(str1)==0) {
	        lbemradius[i] = fStringToNumber <double> (value);  goto Found;}
	  
          sstm.str(string());
          sstm << "embryo_number_" << i;
	      str1 = sstm.str();
	      if(issue.compare(str1)==0) {
	        lbemnumber[i] = fStringToNumber <int> (value); goto Found;}
*/

          sstm.str(string());
          sstm << "density_inc_" << i;
	      str1 = sstm.str();
	      if(issue.compare(str1)==0) {
	        lbincp[i] = fStringToNumber <double> (value);  goto Found;}
	  
          sstm.str(string());
          sstm << "density_ini_" << i;
	      str1 = sstm.str();
	      if(issue.compare(str1)==0) {
	        lbinip[i] = fStringToNumber <double> (value);
            if(!incompress && lbincp[i]==0.0)
              lbincp[i] = fStringToNumber <double> (value);
            goto Found;}
	  
          sstm.str(string());
          sstm << "density_top_" << i;
	      str1 = sstm.str();
	      if(issue.compare(str1)==0) {
	        lbtopp[i] = fStringToNumber <double> (value);  goto Found;}
	  
          sstm.str(string());
          sstm << "density_bot_" << i;
	      str1 = sstm.str();
	      if(issue.compare(str1)==0) {
	        lbbotp[i] = fStringToNumber <double> (value);  goto Found;}
	  
          sstm.str(string());
          sstm << "density_fro_" << i;
  	      str1 = sstm.str();
	      if(issue.compare(str1)==0) {
	        lbfrop[i] = fStringToNumber <double> (value);  goto Found;}
	  
          sstm.str(string());
          sstm << "density_bac_" << i;
	      str1 = sstm.str();
	      if(issue.compare(str1)==0) {
	        lbbacp[i] = fStringToNumber <double> (value);  goto Found;}
	  
          sstm.str(string());
          sstm << "density_lef_" << i;
	      str1 = sstm.str();
	      if(issue.compare(str1)==0) {
	        lblefp[i] = fStringToNumber <double> (value);  goto Found;}
	  
          sstm.str(string());
          sstm << "density_rig_" << i;
	      str1 = sstm.str();
	      if(issue.compare(str1)==0) {
	        lbrigp[i] = fStringToNumber <double> (value);  goto Found;}
	  
          sstm.str(string());
          sstm << "rheology_fluid_" << i;
	      str1 = sstm.str();
	      if(issue.compare(str1)==0) {
            if(rheo>-1)
	          lbrheo[i] = rheo;
            else
              lbrheo[i] = fStringToNumber <int> (value);
            goto Found;
          }

          sstm.str(string());
          sstm << "relaxation_fluid_" << i;
	      str1 = sstm.str();
	      if(issue.compare(str1)==0) {
	        lbtf[i] = 1.0 / fStringToNumber <double> (value);  goto Found;}
	  
          sstm.str(string());
          sstm << "relax_freq_fluid_" << i;
	      str1 = sstm.str();
	      if(issue.compare(str1)==0) {
	        lbtf[i] = fStringToNumber <double> (value);  goto Found;}

          sstm.str(string());
          sstm << "bulk_relaxation_fluid_" << i;
	      str1 = sstm.str();
	      if(issue.compare(str1)==0) {
	        lbtfbulk[i] = 1.0 / fStringToNumber <double> (value);  goto Found;}
	  
          sstm.str(string());
          sstm << "bulk_relax_freq_fluid_" << i;
	      str1 = sstm.str();
	      if(issue.compare(str1)==0) {
	        lbtfbulk[i] = fStringToNumber <double> (value);  goto Found;}
	  
          sstm.str(string());
          sstm << "clbe3_relaxation_fluid_" << i;
	      str1 = sstm.str();
	      if(issue.compare(str1)==0) {
	        lbtfclb3[i] = 1.0 / fStringToNumber <double> (value);  goto Found;}
	  
          sstm.str(string());
          sstm << "clbe3_relax_freq_fluid_" << i;
	      str1 = sstm.str();
	      if(issue.compare(str1)==0) {
	        lbtfclb3[i] = fStringToNumber <double> (value);  goto Found;}

          sstm.str(string());
          sstm << "clbe4_relaxation_fluid_" << i;
	      str1 = sstm.str();
	      if(issue.compare(str1)==0) {
	        lbtfclb4[i] = 1.0 / fStringToNumber <double> (value);  goto Found;}
	  
          sstm.str(string());
          sstm << "clbe4_relax_freq_fluid_" << i;
	      str1 = sstm.str();
	      if(issue.compare(str1)==0) {
	        lbtfclb4[i] = fStringToNumber <double> (value);  goto Found;}

          sstm.str(string());
          sstm << "rheology_parameter_a_" << i;
	      str1 = sstm.str();
	      if(issue.compare(str1)==0) {
            lbrheoa[i] = fStringToNumber <double> (value);  goto Found;}

          sstm.str(string());
          sstm << "rheology_parameter_b_" << i;
	      str1 = sstm.str();
	      if(issue.compare(str1)==0) {
            lbrheob[i] = fStringToNumber <double> (value);  goto Found;}

          sstm.str(string());
          sstm << "rheology_parameter_c_" << i;
	      str1 = sstm.str();
	      if(issue.compare(str1)==0) {
            lbrheoc[i] = fStringToNumber <double> (value);  goto Found;}

          sstm.str(string());
          sstm << "rheology_parameter_d_" << i;
	      str1 = sstm.str();
	      if(issue.compare(str1)==0) {
            lbrheod[i] = fStringToNumber <double> (value);  goto Found;}

          sstm.str(string());
          sstm << "rheology_power_" << i;
	      str1 = sstm.str();
	      if(issue.compare(str1)==0) {
            lbrheopower[i] = fStringToNumber <double> (value);  goto Found;}

          sstm.str(string());
          sstm << "shanchen_psi0_" << i;
	      str1 = sstm.str();
	      if(issue.compare(str1)==0) {
	        lbpsi0[i] = fStringToNumber <double> (value);  goto Found;}
	  
          sstm.str(string());
          sstm << "critical_temperature_" << i;
	      str1 = sstm.str();
	      if(issue.compare(str1)==0) {
	        lbcritt[i] = fStringToNumber <double> (value);  goto Found;}
	  
          sstm.str(string());
          sstm << "critical_pressure_" << i;
	      str1 = sstm.str();
	      if(issue.compare(str1)==0) {
	        lbcritp[i] = fStringToNumber <double> (value);  goto Found;}
	  
          sstm.str(string());
          sstm << "eos_parameter_a_" << i;
	      str1 = sstm.str();
	      if(issue.compare(str1)==0) {
	        lbeosa[i] = fStringToNumber <double> (value);  goto Found;}
	  
          sstm.str(string());
          sstm << "eos_parameter_b_" << i;
	      str1 = sstm.str();
	      if(issue.compare(str1)==0) {
	        lbeosb[i] = fStringToNumber <double> (value);  goto Found;}
	  
          sstm.str(string());
          sstm << "acentric_factor_" << i;
	      str1 = sstm.str();
	      if(issue.compare(str1)==0) {
	        lbacentric[i] = fStringToNumber <double> (value);  goto Found;}
	  
          sstm.str(string());
          sstm << "potential_type_" << i;
	      str1 = sstm.str();
	      if((interact==1 || interact==2) && issue.compare(str1)==0) {
            if(eos>-1)
              lbscpot[i] = eos;
            else
	          lbscpot[i] = fStringToNumber <double> (value);
            goto Found;}
	  
          sstm.str(string());
          sstm << "wetting_type_" << i;
	      str1 = sstm.str();
	      if(issue.compare(str1)==0) {
            if(wet>-1) {
              lbwet[i] = wet;
            }
            else {
	          lbwet[i] = fStringToNumber <double> (value);
            }
            goto Found;}
	  
	      for(int j=0; j<lbsy.nf; j++) {
            sstm.str(string());
            sstm << "interaction_" << (i*lbsy.nf+j);
	        str1 = sstm.str();
	        if(issue.compare(str1)==0) {
	          lbg[i*lbsy.nf+j]=fStringToNumber <double> (value);  goto Found;}

            sstm.str(string());
            sstm << "interaction_" << i << "_" << j;
	        str1 = sstm.str();
	        if(issue.compare(str1)==0) {
	          lbg[i*lbsy.nf+j]=fStringToNumber <double> (value);
	          lbg[j*lbsy.nf+i]=fStringToNumber <double> (value);  goto Found;}

            sstm.str(string());
            sstm << "segregation_" << (i*lbsy.nf+j);
	        str1 = sstm.str();
	        if(issue.compare(str1)==0) {
	          lbseg[i*lbsy.nf+j]=fStringToNumber <double> (value);  goto Found;}

            sstm.str(string());
            sstm << "segregation_" << i << "_" << j;
	        str1 = sstm.str();
	        if(issue.compare(str1)==0) {
	          lbseg[i*lbsy.nf+j]=fStringToNumber <double> (value);
	          lbseg[j*lbsy.nf+i]=fStringToNumber <double> (value);  goto Found;}

            sstm.str(string());
            sstm << "quadratic_weight_" << (i*lbsy.nf+j);
	        str1 = sstm.str();
	        if(issue.compare(str1)==0) {
	          lbscquad[i*lbsy.nf+j]=fStringToNumber <double> (value);  goto Found;}

            sstm.str(string());
            sstm << "quadratic_weight_" << i << "_" << j;
	        str1 = sstm.str();
	        if(issue.compare(str1)==0) {
	          lbscquad[i*lbsy.nf+j]=fStringToNumber <double> (value);
	          lbscquad[j*lbsy.nf+i]=fStringToNumber <double> (value);  goto Found;}

          }

          sstm.str(string());
          sstm << "wall_interaction_" << i;
	      str1 = sstm.str();
	      if(issue.compare(str1)==0) {
	        lbgwall[i] = fStringToNumber <double> (value);  goto Found;}


          for(int j=0; j<3; j++) {
            sstm.str(string());
            sstm << "body_force_" << (i*3+j);
	        str1 = sstm.str();
	        if(issue.compare(str1)==0) {
	          lbbdforce[i*3+j] = fStringToNumber <double> (value);  goto Found;}

            sstm.str(string());
            sstm << "oscillating_force_" << (i*3+j);
	        str1 = sstm.str();
	        if(issue.compare(str1)==0) {
	          lboscilforce[i*3+j] = fStringToNumber <double> (value);  goto Found;}

            sstm.str(string());
            sstm << "boussinesq_force_" << (i*3+j);
	        str1 = sstm.str();
	        if(issue.compare(str1)==0) {
	          lbbousforce[i*3+j] = fStringToNumber <double> (value);  goto Found;}
	      }

          sstm.str(string());
          sstm << "body_force_x_" << i;
	      str1 = sstm.str();
	      if(issue.compare(str1)==0) {
	        lbbdforce[i*3] = fStringToNumber <double> (value);  goto Found;}
          sstm.str(string());
          sstm << "body_force_y_" << i;
	      str1 = sstm.str();
	      if(issue.compare(str1)==0) {
	        lbbdforce[i*3+1] = fStringToNumber <double> (value);  goto Found;}
          sstm.str(string());
          sstm << "body_force_z_" << i;
	      str1 = sstm.str();
	      if(issue.compare(str1)==0) {
	        lbbdforce[i*3+2] = fStringToNumber <double> (value);  goto Found;}
          sstm.str(string());
          sstm << "oscillating_force_x_" << i;
	      str1 = sstm.str();
	      if(issue.compare(str1)==0) {
	        lboscilforce[i*3] = fStringToNumber <double> (value);  goto Found;}
          sstm.str(string());
          sstm << "oscillating_force_y_" << i;
	      str1 = sstm.str();
	      if(issue.compare(str1)==0) {
	        lboscilforce[i*3+1] = fStringToNumber <double> (value);  goto Found;}
          sstm.str(string());
          sstm << "oscillating_force_z_" << i;
	      str1 = sstm.str();
	      if(issue.compare(str1)==0) {
	        lboscilforce[i*3+2] = fStringToNumber <double> (value);  goto Found;}
          sstm.str(string());
          sstm << "boussinesq_force_x_" << i;
	      str1 = sstm.str();
	      if(issue.compare(str1)==0) {
	        lbbousforce[i*3] = fStringToNumber <double> (value);  goto Found;}
          sstm.str(string());
          sstm << "boussinesq_force_y_" << i;
	      str1 = sstm.str();
	      if(issue.compare(str1)==0) {
	        lbbousforce[i*3+1] = fStringToNumber <double> (value);  goto Found;}
          sstm.str(string());
          sstm << "boussinesq_force_z_" << i;
	      str1 = sstm.str();
	      if(issue.compare(str1)==0) {
	        lbbousforce[i*3+2] = fStringToNumber <double> (value);  goto Found;}
	  
	    }

  	    for(int j=0; j<lbsy.nc; j++) {
          sstm.str(string());
          sstm << "relax_solute_" << j;
	      str1 = sstm.str();
	      if(issue.compare(str1)==0) {
	        lbtc[j]= 1.0 / fStringToNumber <double> (value);  goto Found;}
          sstm.str(string());
          sstm << "relax_freq_solute_" << j;
	      str1 = sstm.str();
	      if(issue.compare(str1)==0) {
	        lbtc[j]= fStringToNumber <double> (value);  goto Found;}
	    }
	  
	    for(int j=0; j<lbsy.nt; j++) {
	      if(issue.compare(0,13,"relax_thermal")==0) {
	        lbtt[j]= 1.0 / fStringToNumber <double> (value); goto Found;}
	      if(issue.compare(0,18,"relax_freq_thermal")==0) {
	        lbtt[j]= fStringToNumber <double> (value); goto Found;}
	    }

/*
	    for(int i=0; i<(lbsy.nf * (lbsy.nf-1))/2; i++) {
          sstm.str(string());
          sstm << "interface_fold_" << i;
	      str1 = sstm.str();
	      if(issue.compare(str1)==0) {
	        lbanifold[i] = fStringToNumber <int> (value);  goto Found;}
	  
          sstm.str(string());
          sstm << "anisotropy_intensity_" << i;
	      str1 = sstm.str();
	      if(issue.compare(str1)==0) {
	        lbanitens[i] = fStringToNumber <double> (value);  goto Found;}
	    }
*/	
	
	    for(int i=0; i<lbsy.nc; i++) {
          sstm.str(string());
          sstm << "solute_ini_" << i;
	      str1 = sstm.str();
	      if(issue.compare(str1)==0) {
	        lbinic[i] = fStringToNumber <double> (value); goto Found;}
	  
          sstm.str(string());
          sstm << "solute_top_" << i;
  	      str1 = sstm.str();
	      if(issue.compare(str1)==0) {
	        lbtopc[i] = fStringToNumber <double> (value); goto Found;}
	  
          sstm.str(string());
          sstm << "solute_bot_" << i;
	      str1 = sstm.str();
	      if(issue.compare(str1)==0) {
	        lbbotc[i] = fStringToNumber <double> (value); goto Found;}
	  
          sstm.str(string());
          sstm << "solute_fro_" << i;
	      str1 = sstm.str();
	      if(issue.compare(str1)==0) {
	        lbfroc[i] = fStringToNumber <double> (value); goto Found;}
	  
          sstm.str(string());
          sstm << "solute_bac_" << i;
	      str1 = sstm.str();
	      if(issue.compare(str1)==0) {
	        lbbacc[i] = fStringToNumber <double> (value); goto Found;}
	  
          sstm.str(string());
          sstm << "solute_lef_" << i;
	      str1 = sstm.str();
	      if(issue.compare(str1)==0) {
	        lblefc[i] = fStringToNumber <double> (value); goto Found;}
	  
          sstm.str(string());
          sstm << "solute_rig_" << i;
	      str1 = sstm.str();
	      if(issue.compare(str1)==0) {
	        lbrigc[i] = fStringToNumber <double> (value); goto Found;}
	    }
      }
    Found: ;
    }

  myfile.close();
  
  lbdt = lbkinetic / (lbsoundv * lbsoundv * (1.0/lbtf[0] -0.5));
  if(lbdt <= 0) {
    cout << "The given relaxation time is not suitable for LBE calculation!" << endl;
    cout << "error: program terminated" << endl;
    exit(1);
  }
  lbdx = lbsoundv * lbdt / lbcs;

  postequil = (lbequstep==0);
  
  if(lbgradord<1)
    lbgradord=1;
  else if(lbgradord>2)
    lbgradord=2;

  // fill array with local values of relaxation times,
  // initialized with values given in file (for non-Newtonian rheologies)

  for(long il=0; il<lbdm.touter; il++) {
    for(int i=0; i<lbsy.nf; i++) {
      lbomega[il*lbsy.nf+i] = lbtf[i];
    }
  }
    
  // prepare for use of non-Newtonian rheologies
    
  nonnewtonian = 0;
  for(int i=0; i<lbsy.nf; i++) {
    switch (lbrheo[i]) {
      case 0: // Simple fluid (constant kinematic viscosity)
        if(lbrheoa[i]==0.0)
          lbrheoa[i] = lbtf[i];
        break;
      case 1: // (Density-dependent) Newtonian fluid
        if(lbrheoa[i]==0.0) {
          lbrheoa[i] = lbcssq*(fReciprocal(lbtf[i])-0.5);
          lbrheoa[i] *= (!incompress)?lbinip[i]:lbincp[i];
          nonnewtonian = 1;
        }
        break;
      case 2: // Power law fluid: if power = 1, revert to Newtonian
        if(lbrheoa[i]==0.0) {
          lbrheoa[i] = lbcssq*(fReciprocal(lbtf[i])-0.5);
          lbrheoa[i] *= (!incompress)?lbinip[i]:lbincp[i];
        }
        if(lbrheopower[i]!=1.0) {
          nonnewtonian = 2;
          lbrheopower[i] -= 1.0;
        }
        else {
          lbrheo[i] = 1;
          if(nonnewtonian==0)
            nonnewtonian = 1;
        }
        break;
      case 3: // Bingham plastic: if yield stress = 0, revert to Newtonian
        if(lbrheoa[i]==0.0) {
          lbrheoa[i] = lbcssq*(fReciprocal(lbtf[i])-0.5);
          lbrheoa[i] *= (!incompress)?lbinip[i]:lbincp[i];
        }
        if(lbrheob[i]>0.0)
          nonnewtonian = 2;
        else {
          lbrheo[i] = 1;
          if(nonnewtonian==0)
            nonnewtonian = 1;
        }
        break;
      case 4: // Herschel-Bulkley plastic: if yield stress = 0, revert to power law fluid
              //                           if power = 1, revert to Bingham plastic
              //                           if yield stress = 0 and power = 1, revert to Newtonian
        if(lbrheoa[i]==0.0) {
          lbrheoa[i] = lbcssq*(fReciprocal(lbtf[i])-0.5);
          lbrheoa[i] *= (!incompress)?lbinip[i]:lbincp[i];
        }
        if(lbrheob[i]>0.0) {
          nonnewtonian = 2;
          if(lbrheopower[i]==1.0)
            lbrheo[i] = 3;
        }
        else {
          if(lbrheopower[i]!=1.0) {
            lbrheo[i] = 2;
            lbrheopower[i] -= 1.0;
            nonnewtonian = 2;
          }
          else {
            lbrheo[i] = 1;
            if(nonnewtonian==0)
              nonnewtonian = 1;
          }
        }
        break;
      case 5: // Casson model: if yield stress = 0, revert to Newtonian
        if(lbrheoa[i]==0.0) {
          lbrheoa[i] = lbcssq*(fReciprocal(lbtf[i])-0.5);
          lbrheoa[i] *= (!incompress)?lbinip[i]:lbincp[i];
        }
        if(lbrheob[i]>0.0) {
          nonnewtonian = 2;
          // prepare multiplier with square-root of viscosity-yield stress product
          lbrheod[i] = 2.0*sqrt(lbrheoa[i]*lbrheob[i]);
        }
        else {
          lbrheo[i] = 1;
          if(nonnewtonian==0)
            nonnewtonian = 1;
        }
        break;
      case 6: // Carreau-Yasuda model: if zero-shear viscosity = 0, lambda = 0,
              //                       inner power = 0 or outer power = 1, revert to Newtonian
        if(lbrheoa[i]==0.0) {
          lbrheoa[i] = lbcssq*(fReciprocal(lbtf[i])-0.5);
          lbrheoa[i] *= (!incompress)?lbinip[i]:lbincp[i];
        }
        if(lbrheob[i]>0.0 && lbrheoc[i]!=0.0 && lbrheod[i]!=0.0 && lbrheopower[i]!=1.0) {
          nonnewtonian = 2;
          // prepare difference in viscosities and outside index
          lbrheob[i] = lbrheob[i] - lbrheoa[i];
          lbrheopower[i] = (lbrheopower[i]-1.0)*fReciprocal(lbrheod[i]);
        }
        else {
          lbrheo[i] = 1;
          lbrheoa[i] = lbrheoa[i]+lbrheob[i];
          if(nonnewtonian==0)
            nonnewtonian = 1;
        }
    }
  }
    
  // determine types of forcing and velocity boundary conditions
  // based on available parameters
    
  if(lboscilfreq>0.0) {
    lbbdforcetyp = 1;
    lboscilfreq *= 6.283185307179586;
  }
    
  if(lbtopvfq>0.0) {
    lbtopvbc = 1;
    lbtopvfq *= 6.283185307179586;
  }
  
  if(lbbotvfq>0.0) {
    lbbotvbc = 1;
    lbbotvfq *= 6.283185307179586;
  }
    
  if(lbfrovfq>0.0) {
    lbfrovbc = 1;
    lbfrovfq *= 6.283185307179586;
  }
    
  if(lbbacvfq>0.0) {
    lbbacvbc = 1;
    lbbacvfq *= 6.283185307179586;
  }
    
  if(lblefvfq>0.0) {
    lblefvbc = 1;
    lblefvfq *= 6.283185307179586;
  }
    
  if(lbrigvfq>0.0) {
    lbrigvbc = 1;
    lbrigvfq *= 6.283185307179586;
  }
    
  // determine if EOS-based Shan-Chen pseudopotentials use constant or
  // variable temperatures and reset interaction parameters

  if(interact>0 && interact<10) {
    for(int i=0; i<lbsy.nf; i++) {
      if(lbscpot[i]>4) {
        lbscpot[i] += (lbsy.nt>0 && lbscpot[i]>7)?1:0;
        if(lbsy.nt==0 && lbsyst<=0.0) {
          cout << "The given pseudopotential for fluid species "<<i<<" requires a specified temperature!" << endl;
          cout << "error: program terminated" << endl;
          exit(1);
        }
        lbg[i*lbsy.nf+i] = 1.0;
        int pottyp = lbscpot[i];
        switch (pottyp) {
          case 6:
            // van der Waals
            if(lbcritt[i]==0.0)
              lbcritt[i] = 8.0 * lbeosa[i] * fReciprocal(27.0 * lbgasconst * lbeosb[i]);
            if(lbcritp[i]==0.0)
              lbcritp[i] = lbeosa[i] * fReciprocal(27.0 * lbeosb[i] * lbeosb[i]);
            if(lbeosa[i]==0.0)
              lbeosa[i] = 27.0 * lbgasconst * lbgasconst * lbcritt[i] * lbcritt[i] * fReciprocal(64.0*lbcritp[i]);
            if(lbeosb[i]==0.0)
              lbeosb[i] = lbgasconst * lbcritt[i] * fReciprocal(8.0*lbcritp[i]);
            break;
          case 7:
            // Carnahan-Starling-van der Waals
            if(lbcritt[i]==0.0)
              lbcritt[i] = 0.37731481253489 * lbeosa[i] * fReciprocal(lbgasconst * lbeosb[i]);
            if(lbcritp[i]==0.0)
              lbcritp[i] = 0.07066901441631 * lbeosa[i] * fReciprocal(lbeosb[i] * lbeosb[i]);
            if(lbeosa[i]==0.0)
              lbeosa[i] = 0.49638805772941 * lbgasconst * lbgasconst * lbcritt[i] * lbcritt[i] * fReciprocal(lbcritp[i]);
            if(lbeosb[i]==0.0)
              lbeosb[i] = 0.18729456694673 * lbgasconst * lbcritt[i] * fReciprocal(lbcritp[i]);
            break;
          case 8:
          case 9:
            // Redlich-Kwong
            if(lbcritt[i]==0.0)
              lbcritt[i] = pow(0.20267685653536*lbeosa[i]*fReciprocal(lbgasconst*lbeosb[i]), 2.0/3.0);
            if(lbcritp[i]==0.0)
              lbcritp[i] = 0.01755999378002*lbeosa[i]*fReciprocal(sqrt(lbcritt[i])*lbeosb[i]*lbeosb[i]);
            if(lbeosa[i]==0.0)
              lbeosa[i] = 0.42748023354034 * lbgasconst * lbgasconst * lbcritt[i] * lbcritt[i] * sqrt(lbcritt[i]) * fReciprocal(lbcritp[i]);
            if(lbeosb[i]==0.0)
              lbeosb[i] = 0.08664034996496 * lbgasconst * lbcritt[i] * fReciprocal(lbcritp[i]);
            break;
          case 10:
          case 11:
            // Soave-Redlich-Kwong
            if(lbcritt[i]==0.0)
              lbcritt[i] = 0.20267685653536 * lbeosa[i] * fReciprocal(lbgasconst*lbeosb[i]);
            if(lbcritp[i]==0.0)
              lbcritp[i] = 0.01755999378002 * lbeosa[i] * fReciprocal(lbeosb[i]*lbeosb[i]);
            if(lbeosa[i]==0.0)
              lbeosa[i] = 0.42748023354034 * lbgasconst * lbgasconst * lbcritt[i] * lbcritt[i] * fReciprocal(lbcritp[i]);
            if(lbeosb[i]==0.0)
              lbeosb[i] = 0.08664034996496 * lbgasconst * lbcritt[i] * fReciprocal(lbcritp[i]);
            if(lbcritt[i]==0.0)
              lbcritt[i] = 0.20267685653536 * lbeosa[i] * fReciprocal(lbgasconst*lbeosb[i]);
            break;
          case 12:
          case 13:
            // Peng-Robinson
            if(lbcritt[i]==0.0)
              lbcritt[i] = 0.17014442007035 * lbeosa[i] * fReciprocal(lbgasconst*lbeosb[i]);
            if(lbcritp[i]==0.0)
              lbcritp[i] = 0.01323656787813 * lbeosa[i] * fReciprocal(lbeosb[i]*lbeosb[i]);
            if(lbeosa[i]==0.0)
              lbeosa[i] = 0.45723552892138 * lbgasconst * lbgasconst * lbcritt[i] * lbcritt[i] * fReciprocal(lbcritp[i]);
            if(lbeosb[i]==0.0)
              lbeosb[i] = 0.07779607390389 * lbgasconst * lbcritt[i] * fReciprocal(lbcritp[i]);
            if(lbcritt[i]==0.0)
              lbcritt[i] = 0.17014442007035 * lbeosa[i] * fReciprocal(lbgasconst*lbeosb[i]);
            break;
          case 14:
          case 15:
            // Carnahan-Starling-Redlich-Kwong
            if(lbcritt[i]==0.0)
              lbcritt[i] = pow(0.2273290998908*lbeosa[i]*fReciprocal(lbgasconst*lbeosb[i]), 2.0/3.0);
            if(lbcritp[i]==0.0)
              lbcritp[i] = 0.02382998820259*lbeosa[i]*fReciprocal(sqrt(lbcritt[i])*lbeosb[i]*lbeosb[i]);
            if(lbeosa[i]==0.0)
              lbeosa[i] = 0.46111979136946 * lbgasconst * lbgasconst * lbcritt[i] * lbcritt[i] * sqrt(lbcritt[i]) * fReciprocal(lbcritp[i]);
            if(lbeosb[i]==0.0)
              lbeosb[i] = 0.10482594711385 * lbgasconst * lbcritt[i] * fReciprocal(lbcritp[i]);
            break;
        }
      }
    }
  }

  // determine if EOS for Swift free-energy interactions use constant or
  // variable temperatures and reset interaction parameters

  if(interact==20) {
    if(lbsy.nf>2) {
      cout << "Swift free-energy interactions cannot model more than 2 fluids!" << endl;
      cout << "error: program terminated" << endl;
      exit(1);
    }
    lbfeeos += (lbsy.nt>0 && lbfeeos>7)?1:0;
    if(lbfeeos>4 && lbsy.nt==0 && lbsyst<=0.0) {
      cout << "The given equation of state requires a specified temperature!" << endl;
      cout << "error: program terminated" << endl;
      exit(1);
    }
    switch (lbfeeos) {
      case 1:
        // Shan-Chen model (1993)
        if(lbeosa[0]==0.0)
          lbeosa[0] = lbg[0];
        break;
      case 2:
        // Shan-Chen model (1994)
        if(lbeosa[0]==0.0)
          lbeosa[0] = lbg[0];
        if(lbeosb[0]==0.0)
          lbeosb[0] = lbpsi0[0];
        break;
      case 3:
        // Qian model (1995)
        if(lbeosa[0]==0.0)
          lbeosa[0] = lbg[0];
        break;
      case 4:
        // Quadratic equation of state (psi = rho)
        if(lbeosa[0]==0.0)
          lbeosa[0] = lbg[0];
        break;
      case 6:
        // van der Waals
        if(lbcritt[0]==0.0)
          lbcritt[0] = 8.0 * lbeosa[0] * fReciprocal(27.0 * lbgasconst * lbeosb[0]);
        if(lbcritp[0]==0.0)
          lbcritp[0] = lbeosa[0] * fReciprocal(27.0 * lbeosb[0] * lbeosb[0]);
        if(lbeosa[0]==0.0)
          lbeosa[0] = 27.0 * lbgasconst * lbgasconst * lbcritt[0] * lbcritt[0] * fReciprocal(64.0*lbcritp[0]);
        if(lbeosb[0]==0.0)
          lbeosb[0] = lbgasconst * lbcritt[0] * fReciprocal(8.0*lbcritp[0]);
        break;
      case 7:
        // Carnahan-Starling-van der Waals
        if(lbcritt[0]==0.0)
          lbcritt[0] = 0.37731481253489 * lbeosa[0] * fReciprocal(lbgasconst * lbeosb[0]);
        if(lbcritp[0]==0.0)
          lbcritp[0] = 0.07066901441631 * lbeosa[0] * fReciprocal(lbeosb[0] * lbeosb[0]);
        if(lbeosa[0]==0.0)
          lbeosa[0] = 0.49638805772941 * lbgasconst * lbgasconst * lbcritt[0] * lbcritt[0] * fReciprocal(lbcritp[0]);
        if(lbeosb[0]==0.0)
          lbeosb[0] = 0.18729456694673 * lbgasconst * lbcritt[0] * fReciprocal(lbcritp[0]);
        break;
      case 8:
      case 9:
        // Redlich-Kwong
        if(lbcritt[0]==0.0)
          lbcritt[0] = pow(0.20267685653536*lbeosa[0]*fReciprocal(lbgasconst*lbeosb[0]), 2.0/3.0);
        if(lbcritp[0]==0.0)
          lbcritp[0] = 0.01755999378002*lbeosa[0]*fReciprocal(sqrt(lbcritt[0])*lbeosb[0]*lbeosb[0]);
        if(lbeosa[0]==0.0)
          lbeosa[0] = 0.42748023354034 * lbgasconst * lbgasconst * lbcritt[0] * lbcritt[0] * sqrt(lbcritt[0]) * fReciprocal(lbcritp[0]);
        if(lbeosb[0]==0.0)
          lbeosb[0] = 0.08664034996496 * lbgasconst * lbcritt[0] * fReciprocal(lbcritp[0]);
        break;
      case 10:
      case 11:
        // Soave-Redlich-Kwong
        if(lbcritt[0]==0.0)
          lbcritt[0] = 0.20267685653536 * lbeosa[0] * fReciprocal(lbgasconst*lbeosb[0]);
        if(lbcritp[0]==0.0)
          lbcritp[0] = 0.01755999378002 * lbeosa[0] * fReciprocal(lbeosb[0]*lbeosb[0]);
        if(lbeosa[0]==0.0)
          lbeosa[0] = 0.42748023354034 * lbgasconst * lbgasconst * lbcritt[0] * lbcritt[0] * fReciprocal(lbcritp[0]);
        if(lbeosb[0]==0.0)
          lbeosb[0] = 0.08664034996496 * lbgasconst * lbcritt[0] * fReciprocal(lbcritp[0]);
        if(lbcritt[0]==0.0)
          lbcritt[0] = 0.20267685653536 * lbeosa[0] * fReciprocal(lbgasconst*lbeosb[0]);
        break;
      case 12:
      case 13:
        // Peng-Robinson
        if(lbcritt[0]==0.0)
          lbcritt[0] = 0.17014442007035 * lbeosa[0] * fReciprocal(lbgasconst*lbeosb[0]);
        if(lbcritp[0]==0.0)
          lbcritp[0] = 0.01323656787813 * lbeosa[0] * fReciprocal(lbeosb[0]*lbeosb[0]);
        if(lbeosa[0]==0.0)
          lbeosa[0] = 0.45723552892138 * lbgasconst * lbgasconst * lbcritt[0] * lbcritt[0] * fReciprocal(lbcritp[0]);
        if(lbeosb[0]==0.0)
          lbeosb[0] = 0.07779607390389 * lbgasconst * lbcritt[0] * fReciprocal(lbcritp[0]);
        if(lbcritt[0]==0.0)
          lbcritt[0] = 0.17014442007035 * lbeosa[0] * fReciprocal(lbgasconst*lbeosb[0]);
        break;
      case 14:
      case 15:
        // Carnahan-Starling-Redlich-Kwong
        if(lbcritt[0]==0.0)
          lbcritt[0] = pow(0.2273290998908*lbeosa[0]*fReciprocal(lbgasconst*lbeosb[0]), 2.0/3.0);
        if(lbcritp[0]==0.0)
          lbcritp[0] = 0.02382998820259*lbeosa[0]*fReciprocal(sqrt(lbcritt[0])*lbeosb[0]*lbeosb[0]);
        if(lbeosa[0]==0.0)
          lbeosa[0] = 0.46111979136946 * lbgasconst * lbgasconst * lbcritt[0] * lbcritt[0] * sqrt(lbcritt[0]) * fReciprocal(lbcritp[0]);
        if(lbeosb[0]==0.0)
          lbeosb[0] = 0.10482594711385 * lbgasconst * lbcritt[0] * fReciprocal(lbcritp[0]);
        break;
    }
  }

  // override negative I/O data aggregation choices if
  // only one core in a particular dimension

  if(lbdm.xdim==1 && lbIOGroup.subgrid[0]==0)
    lbIOGroup.subgrid[0] = 1;
  if(lbdm.ydim==1 && lbIOGroup.subgrid[1]==0)
    lbIOGroup.subgrid[1] = 1;
  if(lbdm.zdim==1 && lbIOGroup.subgrid[2]==0)
    lbIOGroup.subgrid[2] = 1;

  // apply MPI-I/O if all two/three dimensions are
  // chosen for data aggregation (and using more than
  // one processor)
    
  lbmpiio=0;
  if(lbdm.size>1 && lbsy.nd==3 && lbIOGroup.subgrid[0]==1 && lbIOGroup.subgrid[1]==1 && lbIOGroup.subgrid[2]==1) {
    lbmpiio=1;
    lbIOGroup.subgrid[2]=0;
  }
  else if(lbdm.size>1 && lbsy.nd==2 && lbIOGroup.subgrid[0]==1 && lbIOGroup.subgrid[1]==1) {
    lbmpiio=1;
    lbIOGroup.subgrid[1]=lbIOGroup.subgrid[2]=0;
  }
  return 0;
}

int fReadSpace2D(const char* filename="lbin.spa")
{

  // read 2D space parameters from data file (default: lbin.spa)
   
  int xpos, ypos, zpos, value;
  unsigned long rpos;

  ifstream myfile;
  myfile.open(filename, ios::in);
  if(!myfile)
    {
      cout << "error: cannot open input file" << endl;
      exit(1);
    }
  while (!myfile.eof())
    {
      myfile >> xpos >> ypos >> zpos >> value;
      if(!(postequil) && value>110 && value<890)
        value = 0;
      if((xpos >= lbdm.xs) && (xpos < lbdm.xe) && 
	 (ypos >= lbdm.ys) && (ypos < lbdm.ye) &&
	 (zpos == 0))
	{
	  rpos = (xpos - lbdm.xs + lbdm.bwid) * lbdm.youter 
	    + ypos - lbdm.ys + lbdm.bwid; 
	  lbphi[rpos] = value;
	}
    }
  myfile.close();
  return 0;
}


int fReadSpace3D(const char* filename="lbin.spa")
{
  
  // read 3D space parameters from data file (default: lbin.spa)
  
  int xpos, ypos, zpos, value;
  unsigned long rpos;
  
  ifstream myfile;
  myfile.open(filename, ios::in);
  if(!myfile)
    {
      cout << "error: cannot open input file" << endl;
      exit(1);
    }
  while (!myfile.eof())
    {
      myfile >> xpos >> ypos >> zpos >> value;
      if(!(postequil) && value>110 && value<890)
        value = 0;
      if((xpos >= lbdm.xs) && (xpos <lbdm.xe) && 
	 (ypos >= lbdm.ys) && (ypos <lbdm.ye) &&
	 (zpos >= lbdm.zs) && (zpos <lbdm.ze))
	{
	  rpos = ((xpos - lbdm.xs + lbdm.bwid) * lbdm.youter 
		  + (ypos - lbdm.ys + lbdm.bwid)) * lbdm.zouter
	    + zpos - lbdm.zs + lbdm.bwid; 
	  lbphi[rpos] = value;
	}
    }
  myfile.close();
  return 0;
}


int fReadSpaceParameter(const char* filename="lbin.spa")
{

  if(lbsy.nd == 2)
    fReadSpace2D(filename);
  else
    fReadSpace3D(filename);
  return 0;
}


int fReadInitialState2D(const char* filename="lbin.init")
{
  
  // read initial velocities, densities, concentrations, temperature
  // from data file to replace default values (default file: lbin.init)

  int xpos, ypos, zpos;
  unsigned long rpos;
  double vel[3];
  double dens[lbsy.nf];
  double conc[lbsy.nc];
  double delta[4*lbsy.nf];
  double temp, T, rho, phi, omega, pb, lambda, mu;
  double * pt2;
  int qdim=lbsy.nf+lbsy.nc+lbsy.nt;

  for(int i=0; i<4*lbsy.nf; i++)
    delta[i] = 0.0;
    
  ifstream myfile;
  myfile.open(filename, ios::in);
  if(myfile)
    {
    while (!myfile.eof())
      {
        myfile >> xpos >> ypos >> zpos;
        myfile >> vel[0] >> vel[1] >> vel[2];
        for (int m=0; m<lbsy.nf; m++) {
          myfile >> dens[m];
        }
        if (lbsy.nc>0) {
          for (int m=0; m<lbsy.nc; m++) {
            myfile >> conc[m];
          }
        }
        if (lbsy.nt==1) {
          myfile >> temp;
        }
  //  replace populations for points inside domain

        if((xpos >= lbdm.xs) && (xpos <lbdm.xe) && 
           (ypos >= lbdm.ys) && (ypos <lbdm.ye) &&
           (zpos == 0))
  	      {
	        rpos = (xpos - lbdm.xs + lbdm.bwid) * lbdm.youter
		         + (ypos - lbdm.ys + lbdm.bwid);
	        pt2 = &lbf[lbsitelength*rpos];
            T = (lbsy.nt>0)?temp:lbsyst;
            if(interact==20 && lbsy.nf>1) {
              rho = dens[0]+dens[1];
              phi = (dens[0]-dens[1])*fReciprocal(rho);
              omega = 2.0*lbtf[0]*lbtf[1]/(2.0*lbtf[0]+(1.0+phi)*(lbtf[1]-lbtf[0]));
              pb = fGetBulkPressureSwift(rho, phi, T);
              lambda = fGetLambdaSwift(rho, omega, T);
              mu = fGetPotentialSwift(phi, 0.0);
              fGetEquilibriumFSwiftTwoFluid(lbfeq, vel, rho, phi, pb, mu, lambda, delta);
              for (int n=0; n<lbsy.nq; n++) {
                pt2[n*qdim  ] = lbfeq[2*n  ];
                pt2[n*qdim+1] = lbfeq[2*n+1];
              }
            }
            else if(interact==20 && lbsy.nf==1) {
              pb = fGetBulkPressureSwift(dens[0], 0.0, T);
              lambda = fGetLambdaSwift(dens[0], lbtf[0], T);
              fGetEquilibriumFSwiftOneFluid(lbfeq, vel, dens[0], pb, lambda, delta);
              for (int n=0; n<lbsy.nq; n++) {
                pt2[n*qdim] = lbfeq[n];
              }
            }
            else if(!incompress) {
              for (int m=0; m<lbsy.nf; m++) {
                fGetEquilibriumF(lbfeq, vel, dens[m]);
                for (int n=0; n<lbsy.nq; n++) {
                  pt2[n*qdim+m] = lbfeq[n];
                }
              }
            }
            else {
              for (int m=0; m<lbsy.nf; m++) {
                fGetEquilibriumFIncom(lbfeq, vel, dens[m], lbinip[m]);
                for (int n=0; n<lbsy.nq; n++) {
                  pt2[n*qdim+m] = lbfeq[n];
                }
              }
            }
            for (int m=0; m<lbsy.nc; m++) {
              fGetEquilibriumC(lbfeq, vel, conc[m]);
              for (int n=0; n<lbsy.nq; n++) {
                pt2[n*qdim+lbsy.nf+m] = lbfeq[n];
              }
            }
            if (lbsy.nt==1) {
              fGetEquilibriumT(lbfeq, vel, temp);
              for (int n=0; n<lbsy.nq; n++) {
                pt2[n*qdim+lbsy.nf+lbsy.nc] = lbfeq[n];
              }
            }
     	  }

      }
    }
  myfile.close();
  pt2=NULL;

  return 0;
}


int fReadInitialState3D(const char* filename="lbin.init")
{
  
  // read initial velocities, densities, concentrations, temperature
  // from data file to replace default values (default file: lbin.init)

  int xpos, ypos, zpos;
  unsigned long rpos;
  double vel[3];
  double dens[lbsy.nf];
  double conc[lbsy.nc];
  double delta[4*lbsy.nf];
  double temp, T, rho, phi, omega, pb, lambda, mu;
  double * pt2;
  int qdim=lbsy.nf+lbsy.nc+lbsy.nt;

  for(int i=0; i<4*lbsy.nf; i++)
    delta[i] = 0.0;

  ifstream myfile;
  myfile.open(filename, ios::in);
  if(myfile)
    {
    while (!myfile.eof())
      {
        myfile >> xpos >> ypos >> zpos;
        myfile >> vel[0] >> vel[1] >> vel[2];
        for (int m=0; m<lbsy.nf; m++) {
          myfile >> dens[m];
        }
        if (lbsy.nc>0) {
          for (int m=0; m<lbsy.nc; m++) {
            myfile >> conc[m];
          }
        }
        if (lbsy.nt==1) {
          myfile >> temp;
        }
  //  replace populations for points inside domain

        if((xpos >= lbdm.xs) && (xpos <lbdm.xe) && 
	       (ypos >= lbdm.ys) && (ypos <lbdm.ye) &&
  	       (zpos >= lbdm.zs) && (zpos <lbdm.ze))
  	      {
	        rpos = ((xpos - lbdm.xs + lbdm.bwid) * lbdm.youter
		         + (ypos - lbdm.ys + lbdm.bwid)) * lbdm.zouter
	             + zpos - lbdm.zs + lbdm.bwid;
            pt2 = &lbf[lbsitelength*rpos];
            T = (lbsy.nt>0)?temp:lbsyst;
            if(interact==20 && lbsy.nf>1) {
              rho = dens[0]+dens[1];
              phi = (dens[0]-dens[1])*fReciprocal(rho);
              omega = 2.0*lbtf[0]*lbtf[1]/(2.0*lbtf[0]+(1.0+phi)*(lbtf[1]-lbtf[0]));
              pb = fGetBulkPressureSwift(rho, phi, T);
              lambda = fGetLambdaSwift(rho, omega, T);
              mu = fGetPotentialSwift(phi, 0.0);
              fGetEquilibriumFSwiftTwoFluid(lbfeq, vel, rho, phi, pb, mu, lambda, delta);
              for (int n=0; n<lbsy.nq; n++) {
                pt2[n*qdim  ] = lbfeq[2*n  ];
                pt2[n*qdim+1] = lbfeq[2*n+1];
              }
            }
            else if(interact==20 && lbsy.nf==1) {
              pb = fGetBulkPressureSwift(dens[0], 0.0, T);
              lambda = fGetLambdaSwift(dens[0], lbtf[0], T);
              fGetEquilibriumFSwiftOneFluid(lbfeq, vel, dens[0], pb, lambda, delta);
              for (int n=0; n<lbsy.nq; n++) {
                pt2[n*qdim] = lbfeq[n];
              }
            }
            else if(!incompress) {
              for (int m=0; m<lbsy.nf; m++) {
                fGetEquilibriumF(lbfeq, vel, dens[m]);
                for (int n=0; n<lbsy.nq; n++) {
                  pt2[n*qdim+m] = lbfeq[n];
                }
              }
            }
            else {
              for (int m=0; m<lbsy.nf; m++) {
                fGetEquilibriumFIncom(lbfeq, vel, dens[m], lbinip[m]);
                for (int n=0; n<lbsy.nq; n++) {
                  pt2[n*qdim+m] = lbfeq[n];
                }
              }
            }
            for (int m=0; m<lbsy.nc; m++) {
              fGetEquilibriumC(lbfeq, vel, conc[m]);
              for (int n=0; n<lbsy.nq; n++) {
                pt2[n*qdim+lbsy.nf+m] = lbfeq[n];
              }
            }
            if (lbsy.nt==1) {
              fGetEquilibriumT(lbfeq, vel, temp);
              for (int n=0; n<lbsy.nq; n++) {
                pt2[n*qdim+lbsy.nf+lbsy.nc] = lbfeq[n];
              }
            }
  	      }

      }
    }
  myfile.close();
  pt2=NULL;

  return 0;
}

int fReadInitialState(const char* filename="lbin.init")
{

  if(lbsy.nd == 2)
    fReadInitialState2D(filename);
  else
    fReadInitialState3D(filename);
  return 0;
}


int fSetoffSteer()
{
  // create notsteer file to prevent DL_MESO_LBE creating new system and space
  // files

  ofstream file("notsteer");
  file << "delete this file before steering\n";
  file.close();
  
  return 0;
}


int fCheckSteer()
{

  // check for existence of notsteer file: if not found, read system and space 
  // files
  
  ifstream file("notsteer");
  if(!file){
    fInputParameters("lbin.sys");
    fReadSpaceParameter("lbin.spa");	
  }
  fSetoffSteer();
  
  return 0;
}


int fPrintSystemInfo()
{

  // print system information

  string buff, bufc, buft, bufcoll, bufforc, bufmeso, bufwet;
//  char buff[30], bufc[20], buft[30], bufcoll[20], bufforc[20], bufmeso[20], bufwet[20];
  int coll=collide/4;
  int forc=collide%4;

  if(!incompress)
    buff.assign((lbsy.nf>1)?"compressible phases":"compressible phase");
  else
    buff.assign((lbsy.nf>1)?"incompressible phases":"incompressible phase");

  bufc.assign((lbsy.nc>1)?"solutes":"solute");
  buft.assign((lbsy.nt==1)?"temperature scalar":"no temperature scalar");
  switch (coll) {
    case 0:
      bufcoll.assign("BGK");
      break;
    case 1:
      bufcoll.assign("TRT");
      break;
    case 2:
      bufcoll.assign("MRT");
      break;
    case 3:
      bufcoll.assign("CLBE");
      break;
  }
  switch (forc) {
    case 0:
      bufforc.assign("standard");
      break;
    case 1:
      bufforc.assign("EDM");
      break;
    case 2:
      bufforc.assign("Guo");
      break;
    case 3:
      bufforc.assign("He");
      break;
  }
  switch (interact) {
    case 0:
      bufmeso.assign("no");
      bufwet.assign(" ");
      break;
    case 1:
      bufmeso.assign("Shan-Chen");
      bufwet.assign(" ");
      break;
    case 2:
      bufmeso.assign("Shan-Chen");
      bufwet.assign("with quadratic terms");
      break;
    case 10:
      bufmeso.assign("Lishchuk");
      bufwet.assign(" ");
      break;
    case 11:
      bufmeso.assign("Lishchuk-Spencer");
      bufwet.assign(" ");
      break;
    case 12:
      bufmeso.assign("Lishchuk-Spencer");
      bufwet.assign("using force tensors");
      break;
    case 13:
      bufmeso.assign("Lishchuk");
      bufwet.assign("determined locally");
      break;
    case 20:
      bufmeso.assign("Swift free-energy");
      bufwet.assign(" ");
      break;

  }
  if(lbdm.rank == 0) {
    fPrintDoubleLine();
    cout << lbsy.nd << "-dimensional system with grid size: nx=" << lbsy.nx << ", ny=" << lbsy.ny;
    if(lbsy.nd == 3)
      cout << ", nz=" << lbsy.nz; 
    cout << endl;
    cout << "boundary width = " << lbdm.bwid << endl;
    cout << "system includes " << lbsy.nf << " " << buff << ", " << lbsy.nc 
         << " " << bufc << " and " << buft << endl;
    cout << "D" << lbsy.nd << "Q" << lbsy.nq << " lattice Boltzmann model is defined using " 
         << bufcoll << " collisions" << endl;
    cout << "with " << bufforc << " forcing and " << bufmeso << " interactions " << bufwet << endl;
    fPrintLine();
  }
  return 0;
}

int fPrintParameters()
{
  int coll=collide/4;
  int k, reporttemp;
  double Tr, alpha;

  // print parameters for system (fluids, solutes, thermal fields)

  if(lbdm.rank == 0) {
    reporttemp = 0;
    for(int i=0; i<lbsy.nf; i++) {
      switch (lbrheo[i]) {
        case 0:
          cout << "fluid " << left << setw(3) << i << ":               simple Newtonian fluid" << endl;
          cout << "                         relaxation time            = " << setw(13) << 1.0/lbtf[i] << endl;
          break;
        case 1:
          cout << "fluid " << left << setw(3) << i << ":               Newtonian fluid" << endl;
          cout << "                         initial relaxation time    = " << setw(13) << 1.0/lbtf[i] << endl;
          cout << "                         dynamic viscosity          = " << setw(13) << lbrheoa[i] << endl;
          break;
        case 2:
          cout << "fluid " << left << setw(3) << i << ":               power law fluid" << endl;
          cout << "                         initial relaxation time    = " << setw(13) << 1.0/lbtf[i] << endl;
          cout << "                         consistency viscosity      = " << setw(13) << lbrheoa[i] << endl;
          cout << "                         power index                = " << setw(13) << lbrheopower[i]+1.0 << endl;
          break;
        case 3:
          cout << "fluid " << left << setw(3) << i << ":               Bingham plastic fluid" << endl;
          cout << "                         initial relaxation time    = " << setw(13) << 1.0/lbtf[i] << endl;
          cout << "                         plastic viscosity          = " << setw(13) << lbrheoa[i] << endl;
          cout << "                         yield stress               = " << setw(13) << lbrheob[i] << endl;
          cout << "                         stress growth exponent     = " << setw(13) << lbrheoc[i] << endl;
          break;
        case 4:
          cout << "fluid " << left << setw(3) << i << ":               Herschel-Bulkley fluid" << endl;
          cout << "                         initial relaxation time    = " << setw(13) << 1.0/lbtf[i] << endl;
          cout << "                         plastic consistency visc.  = " << setw(13) << lbrheoa[i] << endl;
          cout << "                         yield stress               = " << setw(13) << lbrheob[i] << endl;
          cout << "                         stress growth exponent     = " << setw(13) << lbrheoc[i] << endl;
          cout << "                         power index                = " << setw(13) << lbrheopower[i]+1.0 << endl;
          break;
        case 5:
          cout << "fluid " << left << setw(3) << i << ":               Casson fluid" << endl;
          cout << "                         initial relaxation time    = " << setw(13) << 1.0/lbtf[i] << endl;
          cout << "                         consistency viscosity      = " << setw(13) << lbrheoa[i] << endl;
          cout << "                         yield stress               = " << setw(13) << lbrheob[i] << endl;
          cout << "                         stress growth exponent     = " << setw(13) << lbrheoc[i] << endl;
          break;
        case 6:
          cout << "fluid " << left << setw(3) << i << ":               Carreau-Yasuda fluid" << endl;
          cout << "                         initial relaxation time    = " << setw(13) << 1.0/lbtf[i] << endl;
          cout << "                         infinite yield viscosity   = " << setw(13) << lbrheoa[i] << endl;
          cout << "                         zero yield viscosity       = " << setw(13) << lbrheob[i]+lbrheoa[i] << endl;
          cout << "                         yield relaxation time      = " << setw(13) << lbrheoc[i] << endl;
          cout << "                         inner power index          = " << setw(13) << lbrheod[i] << endl;
          cout << "                         outer power index          = " << setw(13) << lbrheod[i]*lbrheopower[i]+1.0 << endl;
          break;
      }
      if(coll==2 || coll==3)
        cout << "                         bulk relaxation time       = " << 1.0/lbtfbulk[i] << endl;
      if(coll==3) {
        cout << "                         3rd moment relaxation time = " << 1.0/lbtfclb3[i] << endl;
        cout << "                         4th moment relaxation time = " << 1.0/lbtfclb4[i] << endl;
      }
      if(interact==1 || interact==2) {
        cout << "                         pseudopotential form       : ";
        switch (lbscpot[i]) {
          case 0:
            cout << "ideal lattice gas" << endl;
            break;
          case 1:
            cout << "Shan-Chen (1993)" << endl;
            cout << "                         constant density (rho0)    = " << lbincp[i] << endl;
            break;
          case 2:
            cout << "Shan-Chen (1994)" << endl;
            cout << "                         maximum potential (psi0)   = " << lbpsi0[i] << endl;
            cout << "                         constant density (rho0)    = " << lbincp[i] << endl;
            break;
          case 3:
            cout << "Qian (1995)" << endl;
            cout << "                         constant density (rho0)    = " << lbincp[i] << endl;
            break;
          case 4:
            cout << "density (quadratic equation of state)" << endl;
            break;
          case 5:
            cout << "ideal gas" << endl;
            reporttemp = 1;
            break;
          case 6:
            cout << "van der Waals" << endl;
            cout << "                         parameter a                = " << lbeosa[i] << endl;
            cout << "                         parameter b                = " << lbeosb[i] << endl;
            cout << "                         critical temperature (Tc)  = " << lbcritt[i] << endl;
            cout << "                         critical pressure (Pc)     = " << lbcritp[i] << endl;
            reporttemp = 1;
            break;
          case 7:
            cout << "Carnahan-Starling-van der Waals" << endl;
            cout << "                         parameter a                = " << lbeosa[i] << endl;
            cout << "                         parameter b                = " << lbeosb[i] << endl;
            cout << "                         critical temperature (Tc)  = " << lbcritt[i] << endl;
            cout << "                         critical pressure (Pc)     = " << lbcritp[i] << endl;
            reporttemp = 1;
            break;
          case 8:
          case 9:
            cout << "Redlich-Kwong" << endl;
            cout << "                         parameter a                = " << lbeosa[i] << endl;
            cout << "                         parameter b                = " << lbeosb[i] << endl;
            cout << "                         critical temperature (Tc)  = " << lbcritt[i] << endl;
            cout << "                         critical pressure (Pc)     = " << lbcritp[i] << endl;
            reporttemp = 1;
            break;
          case 10:
          case 11:
            cout << "Soave-Redlich-Kwong" << endl;
            cout << "                         parameter a                = " << lbeosa[i] << endl;
            cout << "                         parameter b                = " << lbeosb[i] << endl;
            cout << "                         acentric factor (omega)    = " << lbacentric[i] << endl;
            cout << "                         critical temperature (Tc)  = " << lbcritt[i] << endl;
            cout << "                         critical pressure (Pc)     = " << lbcritp[i] << endl;
            reporttemp = 1;
            break;
          case 12:
          case 13:
            cout << "Peng-Robinson" << endl;
            cout << "                         parameter a                = " << lbeosa[i] << endl;
            cout << "                         parameter b                = " << lbeosb[i] << endl;
            cout << "                         acentric factor (omega)    = " << lbacentric[i] << endl;
            cout << "                         critical temperature (Tc)  = " << lbcritt[i] << endl;
            cout << "                         critical pressure (Pc)     = " << lbcritp[i] << endl;
            reporttemp = 1;
            break;
          case 14:
          case 15:
            cout << "Carnahan-Starling-Redlich-Kwong" << endl;
            cout << "                         parameter a                = " << lbeosa[i] << endl;
            cout << "                         parameter b                = " << lbeosb[i] << endl;
            cout << "                         critical temperature (Tc)  = " << lbcritt[i] << endl;
            cout << "                         critical pressure (Pc)     = " << lbcritp[i] << endl;
            reporttemp = 1;
            break;
        }
        cout << endl;
      }
    }
    if(interact==20 && lbfeeos>4)
      reporttemp = 1;
    switch (coll) {
      case 1:
        cout << "                         TRT magic number           = " << lbtrtmagic << endl;
        break;
      case 2:
        cout << "                         MRT tuneable parameter 1   = " << lbmrts[0] << endl;
        cout << "                         MRT tuneable parameter 2   = " << lbmrts[1] << endl;
        if(lbsy.nq==15 || lbsy.nq==19 || lbsy.nq==27)
          cout << "                         MRT tuneable parameter 3   = " << lbmrts[2] << endl;
        if(lbsy.nq==27) {
          cout << "                         MRT tuneable parameter 4   = " << lbmrts[3] << endl;
          cout << "                         MRT tuneable parameter 5   = " << lbmrts[4] << endl;
          cout << "                         MRT tuneable parameter 6   = " << lbmrts[5] << endl;
          cout << "                         MRT tuneable parameter 7   = " << lbmrts[6] << endl;
          cout << "                         MRT tuneable parameter 8   = " << lbmrts[7] << endl;
            
        }
        break;
    }
    if(lbsy.nt==0 && reporttemp>0)
      cout << "                         system temperature         = " << lbsyst << endl;
    cout << endl;
    for(int i=0; i<lbsy.nc; i++) {
      cout << "solute " << left << setw(3) << i << "               relaxation time            = " << 1.0/lbtc[i] << endl;
      cout << endl;
    }
    if(lbsy.nt>0) {
      cout << "thermal                  relaxation time            = " << 1.0/lbtt[0] << endl;
      cout << endl;
    }
    switch (interact) {
      case 1:
        cout << "interaction parameters:  fluid i  fluid j           g_ij" << endl;
        for(int i=0; i<lbsy.nf; i++) {
          for(int j=i; j<lbsy.nf; j++) {
            k = i*lbsy.nf+j;
            cout << "                             " << right << setw(3) << i << "      " << setw(3) << j << "  " << setw(13) << lbg[k] << endl;
          }
        }
        cout << endl;
        cout << "wall interaction parameters:      fluid i           g_wi" << endl;
        for(int i=0; i<lbsy.nf; i++) {
          cout << "                                      " << right << setw(3) << i << "  " << setw(13) << lbgwall[i] << endl;
        }
        if(lbsy.nt==0 && reporttemp>0)
          cout << "                        system temperature         = " << lbsyst << endl;
        break;
      case 2:
        cout << "interaction parameters:  fluid i  fluid j           g_ij        beta_ij" << endl;
        reporttemp = 0;
        for(int i=0; i<lbsy.nf; i++) {
          for(int j=i; j<lbsy.nf; j++) {
            k = i*lbsy.nf+j;
            cout << "                             " << right << setw(3) << i << "      " << setw(3) << j << "  " << setw(13) << lbg[k] << "  " << setw(13) << lbscquad[k] << endl;
          }
        }
        cout << endl;
        cout << "wall interaction parameters:      fluid i           g_wi" << endl;
        for(int i=0; i<lbsy.nf; i++) {
          cout << "                                      " << right << setw(3) << i << "  " << setw(13) << lbgwall[i] << endl;
        }
        if(lbsy.nt==0 && reporttemp>0)
          cout << "                        system temperature         = " << lbsyst << endl;
        break;
      case 10:
      case 11:
      case 12:
      case 13:
        cout << "interaction parameters:  fluid i  fluid j           g_ij        beta_ij" << endl;
        for(int i=0; i<lbsy.nf-1; i++) {
          for(int j=i+1; j<lbsy.nf; j++) {
            k = i*lbsy.nf+j;
            cout << "                             " << right << setw(3) << i << "      " << setw(3) << j << "  " << setw(13) << lbg[k] << "  " << setw(13) << lbseg[k] << endl;
          }
        }
        cout << endl;
        cout << "wall interaction parameters:      fluid i           g_wi" << endl;
        for(int i=1; i<lbsy.nf; i++) {
          cout << "                                      " << right << setw(3) << i << "  " << setw(13) << lbgwall[i] << endl;
        }
        break;
      case 20:
        cout << "fluid equation of state: ";
        switch (lbfeeos) {
          case 0:
            cout << "ideal lattice gas" << endl;
            break;
          case 1:
            cout << "Shan-Chen (1993)" << endl;
            cout << "                         interaction strength (g)   = " << lbeosa[0] << endl;
            cout << "                         constant density (rho0)    = " << lbincp[0] << endl;
            break;
          case 2:
            cout << "Shan-Chen (1994)" << endl;
            cout << "                         interaction strength (g)   = " << lbeosa[0] << endl;
            cout << "                         maximum potential (psi0)   = " << lbeosb[0] << endl;
            cout << "                         constant density (rho0)    = " << lbincp[0] << endl;
            break;
          case 3:
            cout << "Qian (1995)" << endl;
            cout << "                         interaction strength (g)   = " << lbeosa[0] << endl;
            cout << "                         constant density (rho0)    = " << lbincp[0] << endl;
            break;
          case 4:
            cout << "quadratic" << endl;
            cout << "                         interaction strength (g)   = " << lbeosa[0] << endl;
            break;
          case 5:
            cout << "ideal gas" << endl;
            break;
          case 6:
            cout << "van der Waals" << endl;
            cout << "                         parameter a                = " << lbeosa[0] << endl;
            cout << "                         parameter b                = " << lbeosb[0] << endl;
            cout << "                         critical temperature (Tc)  = " << lbcritt[0] << endl;
            cout << "                         critical pressure (Pc)     = " << lbcritp[0] << endl;
            break;
          case 7:
            cout << "Carnahan-Starling-van der Waals" << endl;
            cout << "                         parameter a                = " << lbeosa[0] << endl;
            cout << "                         parameter b                = " << lbeosb[0] << endl;
            cout << "                         critical temperature (Tc)  = " << lbcritt[0] << endl;
            cout << "                         critical pressure (Pc)     = " << lbcritp[0] << endl;
            break;
          case 8:
          case 9:
            cout << "Redlich-Kwong" << endl;
            cout << "                         parameter a                = " << lbeosa[0] << endl;
            cout << "                         parameter b                = " << lbeosb[0] << endl;
            cout << "                         critical temperature (Tc)  = " << lbcritt[0] << endl;
            cout << "                         critical pressure (Pc)     = " << lbcritp[0] << endl;
            break;
          case 10:
          case 11:
            cout << "Soave-Redlich-Kwong" << endl;
            cout << "                         parameter a                = " << lbeosa[0] << endl;
            cout << "                         parameter b                = " << lbeosb[0] << endl;
            cout << "                         acentric factor (omega)    = " << lbacentric[0] << endl;
            cout << "                         critical temperature (Tc)  = " << lbcritt[0] << endl;
            cout << "                         critical pressure (Pc)     = " << lbcritp[0] << endl;
            break;
          case 12:
          case 13:
            cout << "Peng-Robinson" << endl;
            cout << "                         parameter a                = " << lbeosa[0] << endl;
            cout << "                         parameter b                = " << lbeosb[0] << endl;
            cout << "                         acentric factor (omega)    = " << lbacentric[0] << endl;
            cout << "                         critical temperature (Tc)  = " << lbcritt[0] << endl;
            cout << "                         critical pressure (Pc)     = " << lbcritp[0] << endl;
            break;
          case 14:
          case 15:
            cout << "Carnahan-Starling-Redlich-Kwong" << endl;
            cout << "                         parameter a                = " << lbeosa[0] << endl;
            cout << "                         parameter b                = " << lbeosb[0] << endl;
            cout << "                         critical temperature (Tc)  = " << lbcritt[0] << endl;
            cout << "                         critical pressure (Pc)     = " << lbcritp[0] << endl;
            break;
        }
        if(lbsy.nf>1) {
          cout << "concentration potential: ";
          switch (lbfepot) {
            case 0:
              cout << "none" << endl;
              break;
            case 1:
              cout << "quadratic" << endl;
              cout << "                         parameter a                = " << lbeosa[1] << endl;
              cout << "                         parameter b                = " << lbeosb[1] << endl;
              break;
          }
          cout << "                         mobility relaxation time   = " << 1.0/lbtmob << endl;
          cout << "                         mobility parameter         = " << lbfemob << endl;
        }
        cout << "                         surface tension parameter  = " << lbkappa << endl;
    }
    fPrintLine();
  }

  // adjust parameters for equations of state at constant system temperature

  if(interact==1 || interact==2) {
    for (int i=0; i<lbsy.nf; i++) {
      switch (lbscpot[i]) {
        case 8:
        case 14:
          lbeosa[i] *= fReciprocal(sqrt(lbsyst));
          break;
        case 10:
          Tr = lbsyst * fReciprocal(lbcritt[i]);
          alpha = (1.0 + (0.480 + lbacentric[i] * (1.574 - 0.176 * lbacentric[i])) * (1.0 - sqrt(Tr)));
          lbeosa[i] *= alpha * alpha;
          break;
        case 12:
          Tr = lbsyst * fReciprocal(lbcritt[i]);
          alpha = (1.0 + (0.37464 + lbacentric[i] * (1.54226 - 0.26992 * lbacentric[i])) * (1.0 - sqrt(Tr)));
          lbeosa[i] *= alpha * alpha;
          break;
      }
    }
  }
  else if(interact==20) {
    switch (lbfeeos) {
      case 8:
      case 14:
        lbeosa[0] *= fReciprocal(sqrt(lbsyst));
        break;
      case 10:
        Tr = lbsyst * fReciprocal(lbcritt[0]);
        alpha = (1.0 + (0.480 + lbacentric[0] * (1.574 - 0.176 * lbacentric[0])) * (1.0 - sqrt(Tr)));
        lbeosa[0] *= alpha * alpha;
        break;
      case 12:
        Tr = lbsyst * fReciprocal(lbcritt[0]);
        alpha = (1.0 + (0.37464 + lbacentric[0] * (1.54226 - 0.26992 * lbacentric[0])) * (1.0 - sqrt(Tr)));
        lbeosa[0] *= alpha * alpha;
        break;
    }
  }
  return 0;
}



int fPrintEndEquilibration()
{
  if(lbdm.rank == 0) {
    fPrintDoubleLine();
    cout << "EQUILIBRATION PERIOD NOW COMPLETE" << endl;
    fPrintDoubleLine();   
  }
  return 0;
}


int fPrintEarlyTermination()
{
  if(lbdm.rank == 0) {
    fPrintDoubleLine();
    cout << "SIMULATION TERMINATED AFTER " << lbcurstep << " TIMESTEPS" << endl;
    fPrintDoubleLine();
  }
  return 0;
}


int fPrintDomainMass()
{

  // display masses of individual and all fluids in domain

  if(interact==20) {
    cout<<"MASS: "<<"total = "<<fGetOneMassDomain(0);
    for(int i=0; i<lbsy.nf; i++)
      cout<<", fluid "<<i<<" = "<<fGetOneMassSwiftDomain(i);
    cout<<endl;
  }
  else {
    cout<<"MASS: "<<"total = "<<fGetTotMassDomain();
    for(int i=0; i<lbsy.nf; i++)
      cout<<", fluid "<<i<<" = "<<fGetOneMassDomain(i);
    cout<<endl;
  }
  return 0;
}


int fPrintDomainMomentum()
{

  // display total fluid momentum in domain

  double mome[3];
    
  if(interact==20)
    fGetTotMomentSwiftDomain(mome);
  else
    fGetTotMomentDomain(mome);
    
  cout<<"MOMENTUM: "<<"x: "<<mome[0]<<", y: "<<mome[1];
  if(lbsy.nd == 3)
    cout<<", z: "<<mome[2];
  cout<<endl;
  return 0;  
}

int fsCreateIOGroups()
{
    // create I/O group to combine output: serial version of
    // fCreateIOGroups in lbpMPI.cpp, gives values for lbIOGroup
    // structure to allow I/O writing to work with one process
    
    lbIOGroup.rank = 0;
    lbIOGroup.cartCoords[0] = 0;
    lbIOGroup.cartCoords[1] = 0;
    lbIOGroup.cartCoords[2] = 0;
    lbIOGroup.size = 1;
    lbIOGroup.rootRank = 0;
    lbIOGroup.groupId = 0;
    lbIOGroup.cartStart[0] = 0;
    lbIOGroup.cartStart[1] = 0;
    lbIOGroup.cartStart[2] = 0;
    lbIOGroup.cartEnd[0] = lbdm.xouter;
    lbIOGroup.cartEnd[1] = lbdm.youter;
    lbIOGroup.cartEnd[2] = lbdm.zouter;
    lbIOGroup.gridStartGlobal[0] = 0;
    lbIOGroup.gridStartGlobal[1] = 0;
    lbIOGroup.gridStartGlobal[2] = 0;
    lbIOGroup.gridEndGlobal[0] = lbdm.xouter;
    lbIOGroup.gridEndGlobal[1] = lbdm.youter;
    lbIOGroup.gridEndGlobal[2] = lbdm.zouter;
    return 0;
}


int fOutput(const char* filename="lbout")
{

  // output all properties at current timestep according to required format

  switch (outformat) {
    case 0:
      // XML-based VTK in big-endian binary
      fOutputVTK(filename);
      break;
    case 1:
      // Legacy VTK in big-endian binary
      fOutputLegacyVTK(filename);
      break;
    case 2:
      // Plot3D in binary
      fOutputQ(filename);
      break;
    case 3:
      // XML-based VTK in ANSI/text
      fsOutputVTK(filename);
      break;
    case 4:
      // Legacy VTK in ANSI/text
      fsOutputLegacyVTK(filename);
      break;
    case 5:
      // Plot3D in ANSI/text
      fsOutputQ(filename);
      break;
  }
  qVersion++;
  return 0;
}

