/*
 *     DL_MESO_GUI
 *     author: R. S. Qin, M. A. Seaton
 *     copyright: UKRI STFC Daresbury Laboratory and CCP5
 *     2005, 2018
 */
class lbesysdim {
    static int lbnx = 0;
    static int lbny = 0;
    static int lbnz = 0;
    static int lbd = 0;
    static int lbf = 0;
    static int lbc = 0;
    static int lbt = 0;
    static int bctyp = 0;
    static int sbctyp = 0;
    static int tbctyp = 0;
    static int gradord = 1;
    static double densf[] = new double[6*6];
    static double vel[] = new double[6*3];
    static double velos[] = new double[6*3];
    static double velospf[] = new double[6];
    static int pf[] = new int[6];
    static double conc[] = new double[6*6];
    static double temp[] = new double[6];
    static double tempdt[] = new double[6];
    public void lbedimension() {}
}
