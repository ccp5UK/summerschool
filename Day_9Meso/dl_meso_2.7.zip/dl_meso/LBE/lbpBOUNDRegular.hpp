int fD2Q9VCERegular(double v0, double v1, double *force, double *f0, double *f1, double *f2,
                    double *f3, double *f4, double *f5, double *f6, double *f7, double *f8);
int fD2Q9VCCRegular(double *p, double v0, double v1, double *force, double *f0, double *f1, double *f2,
                    double *f3, double *f4, double *f5, double *f6, double *f7, double *f8);
int fD2Q9VCECLBERegular(double v0, double v1, double *force, double *f0, double *f1, double *f2,
                        double *f3, double *f4, double *f5, double *f6, double *f7, double *f8);
int fD2Q9VCCCLBERegular(double *p, double v0, double v1, double *force, double *f0, double *f1, double *f2,
                        double *f3, double *f4, double *f5, double *f6, double *f7, double *f8);
int fD2Q9VCESwiftRegular(double v0, double v1, double *force, double *f0, double *f1, double *f2,
                         double *f3, double *f4, double *f5, double *f6, double *f7, double *f8,
                         double drdx, double drdy, double dpdx, double dpdy, double nabr, double nabp,
                         double *omega, double T);
int fD2Q9VCCSwiftRegular(double *p, double v0, double v1, double *force, double *f0, double *f1, double *f2,
                         double *f3, double *f4, double *f5, double *f6, double *f7, double *f8,
                         double drdx, double drdy, double dpdx, double dpdy, double nabr, double nabp,
                         double *omega, double T);
int fD2Q9VFRegular(long tpos, long tpos1, int prop, double *uwall, double dx, double dy, double T);
int fD2Q9PCERegular(double *p, double *force, double *f0, double *f1, double *f2, double *f3,
                    double *f4, double *f5, double *f6, double *f7, double *f8, double &vel);
int fD2Q9PCESwiftRegular(double *p, double *force, double *f0, double *f1, double *f2, double *f3,
                         double *f4, double *f5, double *f6, double *f7, double *f8,
                         double drdx, double drdy, double dpdx, double dpdy, double nabr, double napr,
                         double *omega, double T, double &vel);
int fD2Q9PFRegular(long tpos, int prop, double *p0, double *uwall, double T);

int fD3Q15VPSRegular(double v0, double v1, double v2, double *force, double *f0, double *f1, double *f2,
                     double *f3, double *f4, double *f5, double *f6, double *f7, double *f8,
                     double *f9, double *f10, double *f11, double *f12, double *f13, double *f14);
int fD3Q15VCERegular(double *p, double v0, double v1, double v2, double *force, double *f0, double *f1, double *f2,
                     double *f3, double *f4, double *f5, double *f6, double *f7, double *f8,
                     double *f9, double *f10, double *f11, double *f12, double *f13, double *f14);
int fD3Q15VCCRegular(double *p, double v0, double v1, double v2, double *force, double *f0, double *f1, double *f2,
                     double *f3, double *f4, double *f5, double *f6, double *f7, double *f8,
                     double *f9, double *f10, double *f11, double *f12, double *f13, double *f14);
int fD3Q15VPSSwiftRegular(double v0, double v1, double v2, double *force, double *f0, double *f1, double *f2,
                          double *f3, double *f4, double *f5, double *f6, double *f7, double *f8,
                          double *f9, double *f10, double *f11, double *f12, double *f13, double *f14,
                          double drdx, double drdy, double drdz, double dpdx, double dpdy, double dpdz,
                          double nabr, double nabp, double *omega, double T);
int fD3Q15VCESwiftRegular(double *p, double v0, double v1, double v2, double *force, double *f0, double *f1, double *f2,
                          double *f3, double *f4, double *f5, double *f6, double *f7, double *f8,
                          double *f9, double *f10, double *f11, double *f12, double *f13, double *f14,
                          double drdx, double drdy, double drdz, double dpdx, double dpdy, double dpdz,
                          double nabr, double nabp, double *omega, double T);
int fD3Q15VCCSwiftRegular(double *p, double v0, double v1, double v2, double *force, double *f0, double *f1, double *f2,
                          double *f3, double *f4, double *f5, double *f6, double *f7, double *f8,
                          double *f9, double *f10, double *f11, double *f12, double *f13, double *f14,
                          double drdx, double drdy, double drdz, double dpdx, double dpdy, double dpdz,
                          double nabr, double nabp, double *omega, double T);
int fD3Q15VFRegular(long tpos, long rpos, int prop, double *uwall, double dx, double dy, double dz, double T);
int fD3Q15PPSRegular(double *p, double *force, double *f0, double *f1,
                     double *f2, double *f3, double *f4, double *f5,
                     double *f6, double *f7, double *f8, double *f9,
                     double *f10, double *f11, double *f12, double *f13,
                     double *f14, double &vel);
int fD3Q15PPSSwiftRegular(double *p, double *force, double *f0, double *f1,
                          double *f2, double *f3, double *f4, double *f5,
                          double *f6, double *f7, double *f8, double *f9,
                          double *f10, double *f11, double *f12, double *f13,
                          double *f14, double drdx, double drdy, double drdz,
                          double dpdx, double dpdy, double dpdz, double nabr,
                          double nabp, double *omega, double T, double &vel);
int fD3Q15PFRegular(long tpos, int prop, double *p0, double *uwall, double T);

int fD3Q19VPSRegular(double v0, double v1, double v2, double *force, double *f0, double *f1, double *f2,
                     double *f3, double *f4, double *f5, double *f6, double *f7, double *f8,
                     double *f9, double *f10, double *f11, double *f12, double *f13, double *f14,
                     double *f15, double *f16, double *f17, double *f18);
int fD3Q19VCERegular(double *p, double v0, double v1, double v2, double *force, double *f0, double *f1, double *f2,
                     double *f3, double *f4, double *f5, double *f6, double *f7, double *f8,
                     double *f9, double *f10, double *f11, double *f12, double *f13, double *f14,
                     double *f15, double *f16, double *f17, double *f18);
int fD3Q19VCCRegular(double *p, double v0, double v1, double v2, double *force, double *f0, double *f1, double *f2,
                     double *f3, double *f4, double *f5, double *f6, double *f7, double *f8,
                     double *f9, double *f10, double *f11, double *f12, double *f13, double *f14,
                     double *f15, double *f16, double *f17, double *f18);
int fD3Q19VPSCLBERegular(double v0, double v1, double v2, double *force, double *f0, double *f1, double *f2,
                         double *f3, double *f4, double *f5, double *f6, double *f7, double *f8,
                         double *f9, double *f10, double *f11, double *f12, double *f13, double *f14,
                         double *f15, double *f16, double *f17, double *f18);
int fD3Q19VCECLBERegular(double *p, double v0, double v1, double v2, double *force, double *f0, double *f1, double *f2,
                         double *f3, double *f4, double *f5, double *f6, double *f7, double *f8,
                         double *f9, double *f10, double *f11, double *f12, double *f13, double *f14,
                         double *f15, double *f16, double *f17, double *f18);
int fD3Q19VCCCLBERegular(double *p, double v0, double v1, double v2, double *force, double *f0, double *f1, double *f2,
                         double *f3, double *f4, double *f5, double *f6, double *f7, double *f8,
                         double *f9, double *f10, double *f11, double *f12, double *f13, double *f14,
                         double *f15, double *f16, double *f17, double *f18);
int fD3Q19VPSSwiftRegular(double v0, double v1, double v2, double *force, double *f0, double *f1, double *f2,
                          double *f3, double *f4, double *f5, double *f6, double *f7, double *f8,
                          double *f9, double *f10, double *f11, double *f12, double *f13, double *f14,
                          double *f15, double *f16, double *f17, double *f18,
                          double drdx, double drdy, double drdz, double dpdx, double dpdy, double dpdz,
                          double nabr, double nabp, double *omega, double T);
int fD3Q19VCESwiftRegular(double *p, double v0, double v1, double v2, double *force, double *f0, double *f1, double *f2,
                          double *f3, double *f4, double *f5, double *f6, double *f7, double *f8,
                          double *f9, double *f10, double *f11, double *f12, double *f13, double *f14,
                          double *f15, double *f16, double *f17, double *f18,
                          double drdx, double drdy, double drdz, double dpdx, double dpdy, double dpdz,
                          double nabr, double nabp, double *omega, double T);
int fD3Q19VCCSwiftRegular(double *p, double v0, double v1, double v2, double *force, double *f0, double *f1, double *f2,
                          double *f3, double *f4, double *f5, double *f6, double *f7, double *f8,
                          double *f9, double *f10, double *f11, double *f12, double *f13, double *f14,
                          double *f15, double *f16, double *f17, double *f18,
                          double drdx, double drdy, double drdz, double dpdx, double dpdy, double dpdz,
                          double nabr, double nabp, double *omega, double T);
int fD3Q19VFRegular(long tpos, long rpos, int prop, double *uwall, double dx, double dy, double dz, double T);
int fD3Q19PPSRegular(double *p, double *force, double *f0, double *f1,
                     double *f2, double *f3, double *f4, double *f5,
                     double *f6, double *f7, double *f8, double *f9,
                     double *f10, double *f11, double *f12, double *f13,
                     double *f14, double *f15, double *f16, double *f17,
                     double *f18, double &vel);
int fD3Q19PPSSwiftRegular(double *p, double *force, double *f0, double *f1,
                          double *f2, double *f3, double *f4, double *f5,
                          double *f6, double *f7, double *f8, double *f9,
                          double *f10, double *f11, double *f12, double *f13,
                          double *f14, double *f15, double *f16, double *f17,
                          double *f18, double drdx, double drdy, double drdz,
                          double dpdx, double dpdy, double dpdz, double nabr,
                          double nabp, double *omega, double T, double &vel);
int fD3Q19PFRegular(long tpos, int prop, double *p0, double *uwall, double T);

int fD3Q27VPSRegular(double v0, double v1, double v2, double *force, double *f0, double *f1, double *f2,
                     double *f3, double *f4, double *f5, double *f6, double *f7, double *f8,
                     double *f9, double *f10, double *f11, double *f12, double *f13, double *f14,
                     double *f15, double *f16, double *f17, double *f18, double *f19, double *f20,
                     double *f21, double *f22, double *f23, double *f24, double *f25, double *f26);
int fD3Q27VCERegular(double *p, double v0, double v1, double v2, double *force, double *f0, double *f1, double *f2,
                     double *f3, double *f4, double *f5, double *f6, double *f7, double *f8,
                     double *f9, double *f10, double *f11, double *f12, double *f13, double *f14,
                     double *f15, double *f16, double *f17, double *f18, double *f19, double *f20,
                     double *f21, double *f22, double *f23, double *f24, double *f25, double *f26);
int fD3Q27VCCRegular(double *p, double v0, double v1, double v2, double *force, double *f0, double *f1, double *f2,
                     double *f3, double *f4, double *f5, double *f6, double *f7, double *f8,
                     double *f9, double *f10, double *f11, double *f12, double *f13, double *f14,
                     double *f15, double *f16, double *f17, double *f18, double *f19, double *f20,
                     double *f21, double *f22, double *f23, double *f24, double *f25, double *f26);
int fD3Q27VPSCLBERegular(double v0, double v1, double v2, double *force, double *f0, double *f1, double *f2,
                         double *f3, double *f4, double *f5, double *f6, double *f7, double *f8,
                         double *f9, double *f10, double *f11, double *f12, double *f13, double *f14,
                         double *f15, double *f16, double *f17, double *f18, double *f19, double *f20,
                         double *f21, double *f22, double *f23, double *f24, double *f25, double *f26);
int fD3Q27VCECLBERegular(double *p, double v0, double v1, double v2, double *force, double *f0, double *f1, double *f2,
                         double *f3, double *f4, double *f5, double *f6, double *f7, double *f8,
                         double *f9, double *f10, double *f11, double *f12, double *f13, double *f14,
                         double *f15, double *f16, double *f17, double *f18, double *f19, double *f20,
                         double *f21, double *f22, double *f23, double *f24, double *f25, double *f26);
int fD3Q27VCCCLBERegular(double *p, double v0, double v1, double v2, double *force, double *f0, double *f1, double *f2,
                         double *f3, double *f4, double *f5, double *f6, double *f7, double *f8,
                         double *f9, double *f10, double *f11, double *f12, double *f13, double *f14,
                         double *f15, double *f16, double *f17, double *f18, double *f19, double *f20,
                         double *f21, double *f22, double *f23, double *f24, double *f25, double *f26);
int fD3Q27VFRegular(long tpos, long rpos, int prop, double *uwall);
int fD3Q27PPSRegular(double *p, double *force, double *f0, double *f1,
                     double *f2, double *f3, double *f4, double *f5,
                     double *f6, double *f7, double *f8, double *f9,
                     double *f10, double *f11, double *f12, double *f13,
                     double *f14, double *f15, double *f16, double *f17,
                     double *f18, double *f19, double *f20, double *f21,
                     double *f22, double *f23, double *f24, double *f25,
                     double *f26, double &vel);
int fD3Q27PFRegular(long tpos, int prop, double *p0, double *uwall);
