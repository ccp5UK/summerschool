import javax.swing.*;
import java.util.*;
import java.lang.*;
import java.io.*;
import java.awt.*;
import java.awt.event.*;
import java.awt.geom.*;
import java.awt.image.*;
/*
 *     DL_MESO_GUI
 *     author: R. S. Qin, M. A. Seaton
 *     copyright: UKRI STFC Daresbury Laboratory and CCP5
 *     2005, 2018
 */
class setBound extends JFrame {
    
    setlbeSpaEvt boundlbe=new setlbeSpaEvt(this);

    JLabel boundlabel = new JLabel("BOUNDARY CONDITIONS", JLabel.LEFT);
    JComboBox<String> bound = new JComboBox<String>();
    
    JLabel xlabel = new JLabel("x", JLabel.CENTER);
    JLabel ylabel = new JLabel("y", JLabel.CENTER);
    JLabel zlabel = new JLabel("z", JLabel.CENTER);
    
    JLabel constvlabel = new JLabel("constant velocity:", JLabel.RIGHT);
    JTextField cvx = new JTextField("0.0", 7);
    JTextField cvy = new JTextField("0.0", 7);
    JTextField cvz = new JTextField("0.0", 7);
    
    JLabel oscilvlabel = new JLabel("oscillating velocity:", JLabel.RIGHT);
    JTextField ovx = new JTextField("0.0", 7);
    JTextField ovy = new JTextField("0.0", 7);
    JTextField ovz = new JTextField("0.0", 7);
    
    JComboBox<String> oscilfreqper = new JComboBox<String>();
    JTextField ofp = new JTextField("1.0", 7);
    
    JLabel denslabel = new JLabel("constant density:", JLabel.RIGHT);
    JTextField dens0 = new JTextField("1.0", 7);
    JTextField dens1 = new JTextField("1.0", 7);
    JTextField dens2 = new JTextField("1.0", 7);
    JTextField dens3 = new JTextField("1.0", 7);
    JTextField dens4 = new JTextField("1.0", 7);
    JTextField dens5 = new JTextField("1.0", 7);

    JLabel conclabel = new JLabel("constant solute concentration:", JLabel.RIGHT);
    JTextField conc0 = new JTextField("0.0", 7);
    JTextField conc1 = new JTextField("0.0", 7);
    JTextField conc2 = new JTextField("0.0", 7);
    JTextField conc3 = new JTextField("0.0", 7);
    JTextField conc4 = new JTextField("0.0", 7);
    JTextField conc5 = new JTextField("0.0", 7);

    JLabel templabel = new JLabel("constant temperature:", JLabel.RIGHT);
    JTextField temper = new JTextField("0.0", 7);
    
    JLabel heatlabel = new JLabel("rate of temperature change:", JLabel.RIGHT);
    JTextField heat = new JTextField("0.0", 7);
    
    JButton set = new JButton("SET BC");
    JButton close = new JButton("CLOSE BC");
    Font font=new Font("Dialog", Font.BOLD, 13);
    
    public setBound(int bc, int[] bcsel, int dim, int totf, int totc, int tott, double[] vel, double[] velos, double[] velospf, int[] pf, double[] dens, double[] conc, double[] temp, double[] tempdt) {

        super("LBE boundary conditions");

        int width;
        int boundnum;
        int [] boundwhich = new int [6];
        
        width = 4;
        if(totf>3)
          width = totf+1;
        if(totc>3 && totc>totf)
          width = totc+1;
            
        setBounds(160, 10, 220+81*width, 692);
        JPanel pane=new JPanel(new GridBagLayout());

        boundlabel.setFont(font);
        addItem(pane, boundlabel, 0, 0, width, 1, GridBagConstraints.WEST);
        
        boundnum = -1;
        for(int i=0; i<6; i++)
          boundwhich[i] = -1;
        
        if(bcsel[0]>3) {
          bound.addItem("TOP");
          boundnum++;
          boundwhich[0] = boundnum;
        }
        if(bcsel[1]>3) {
          bound.addItem("BOTTOM");
          boundnum++;
          boundwhich[1] = boundnum;
        }
        if(bcsel[2]>3) {
          bound.addItem("LEFT");
          boundnum++;
          boundwhich[2] = boundnum;
        }
        if(bcsel[3]>3) {
          bound.addItem("RIGHT");
          boundnum++;
          boundwhich[3] = boundnum;
        }
        if(dim>2 && bcsel[4]>3) {
          bound.addItem("FRONT");
          boundnum++;
          boundwhich[4] = boundnum;
        }
        if(dim>2 && bcsel[5]>3) {
          bound.addItem("BACK");
          boundnum++;
          boundwhich[5] = boundnum;
        }

        bound.setSelectedIndex(boundwhich[bc]);
        bound.addItemListener(boundlbe);
        addItem(pane, bound, 0, 1, width, 1, GridBagConstraints.WEST);
        
        addItem(pane, xlabel, 1, 2, 1, 1, GridBagConstraints.CENTER);
        addItem(pane, ylabel, 2, 2, 1, 1, GridBagConstraints.CENTER);
        addItem(pane, zlabel, 3, 2, 1, 1, GridBagConstraints.CENTER);
        if(dim==2)
          zlabel.setEnabled(false);
        
        constvlabel.setFont(font);
        addItem(pane, constvlabel, 0, 3, 1, 1, GridBagConstraints.EAST);
        
        cvx.setText(Double.toString(vel[3*bc]));
        cvy.setText(Double.toString(vel[3*bc+1]));
        cvz.setText(Double.toString(vel[3*bc+2]));
        addItem(pane, cvx, 1, 3, 1, 1, GridBagConstraints.CENTER);
        addItem(pane, cvy, 2, 3, 1, 1, GridBagConstraints.CENTER);
        addItem(pane, cvz, 3, 3, 1, 1, GridBagConstraints.CENTER);
        if(dim==2) {
          cvz.setEnabled(false);
          cvz.setEditable(false);
        }
        if(bcsel[bc]>7) {
          constvlabel.setEnabled(false);
          cvx.setEnabled(false);
          cvx.setEditable(false);
          cvy.setEnabled(false);
          cvy.setEditable(false);
          cvz.setEnabled(false);
          cvz.setEditable(false);
        }
        
        oscilvlabel.setFont(font);
        addItem(pane, oscilvlabel, 0, 4, 1, 1, GridBagConstraints.EAST);
        
        ovx.setText(Double.toString(velos[3*bc]));
        ovy.setText(Double.toString(velos[3*bc+1]));
        ovz.setText(Double.toString(velos[3*bc+2]));
        addItem(pane, ovx, 1, 4, 1, 1, GridBagConstraints.CENTER);
        addItem(pane, ovy, 2, 4, 1, 1, GridBagConstraints.CENTER);
        addItem(pane, ovz, 3, 4, 1, 1, GridBagConstraints.CENTER);
        if(dim==2) {
          ovz.setEnabled(false);
          ovz.setEditable(false);
        }
        if(bcsel[bc]>7) {
          oscilvlabel.setEnabled(false);
          ovx.setEnabled(false);
          ovx.setEditable(false);
          ovy.setEnabled(false);
          ovy.setEditable(false);
          ovz.setEnabled(false);
          ovz.setEditable(false);
        }
        
        oscilfreqper.addItem("oscillating frequency");
        oscilfreqper.addItem("oscillating period");
        oscilfreqper.setSelectedIndex(pf[bc]);
        addItem(pane, oscilfreqper, 0, 5, 1, 1, GridBagConstraints.EAST);
        ofp.setText(Double.toString(velospf[bc]));
        addItem(pane, ofp, 1, 5, 1, 1, GridBagConstraints.CENTER);
        if(bcsel[bc]>7) {
          oscilfreqper.setEnabled(false);
          ofp.setEnabled(false);
          ofp.setEditable(false);
        }
        
        for(int i=0; i<totf; i++) {
            addItem(pane, new JLabel("fluid "+i), i+1, 6, 1, 1, GridBagConstraints.CENTER);
        }

        denslabel.setFont(font);
        addItem(pane, denslabel, 0, 7, 1, 1, GridBagConstraints.EAST);
        dens0.setText(Double.toString(dens[bc]));
        dens1.setText(Double.toString(dens[6+bc]));
        dens2.setText(Double.toString(dens[12+bc]));
        dens3.setText(Double.toString(dens[18+bc]));
        dens4.setText(Double.toString(dens[24+bc]));
        dens5.setText(Double.toString(dens[30+bc]));
        addItem(pane, dens0, 1, 7, 1, 1, GridBagConstraints.CENTER);
        if(totf>1)
            addItem(pane, dens1, 2, 7, 1, 1, GridBagConstraints.CENTER);
        if(totf>2)
            addItem(pane, dens2, 3, 7, 1, 1, GridBagConstraints.CENTER);
        if(totf>3)
            addItem(pane, dens3, 4, 7, 1, 1, GridBagConstraints.CENTER);
        if(totf>4)
            addItem(pane, dens4, 5, 7, 1, 1, GridBagConstraints.CENTER);
        if(totf>5)
            addItem(pane, dens5, 6, 7, 1, 1, GridBagConstraints.CENTER);

        if(bcsel[bc]<8) {
          denslabel.setEnabled(false);
          dens0.setEnabled(false);
          dens0.setEditable(false);
          dens1.setEnabled(false);
          dens1.setEditable(false);
          dens2.setEnabled(false);
          dens2.setEditable(false);
          dens3.setEnabled(false);
          dens3.setEditable(false);
          dens4.setEnabled(false);
          dens4.setEditable(false);
          dens5.setEnabled(false);
          dens5.setEditable(false);
        }

        conc0.setText(Double.toString(conc[bc]));
        conc1.setText(Double.toString(conc[6+bc]));
        conc2.setText(Double.toString(conc[12+bc]));
        conc3.setText(Double.toString(conc[18+bc]));
        conc4.setText(Double.toString(conc[24+bc]));
        conc5.setText(Double.toString(conc[30+bc]));
        if(totc>0) {
          for(int i=0; i<totc; i++)
            addItem(pane, new JLabel("solute "+i), i+1, 8, 1, 1, GridBagConstraints.CENTER);
          conclabel.setFont(font);
          addItem(pane, conclabel, 0, 9, 1, 1, GridBagConstraints.EAST);
          addItem(pane, conc0, 1, 9, 1, 1, GridBagConstraints.CENTER);
          if(totc>1)
              addItem(pane, conc1, 2, 9, 1, 1, GridBagConstraints.CENTER);
          if(totc>2)
              addItem(pane, conc2, 3, 9, 1, 1, GridBagConstraints.CENTER);
          if(totc>3)
              addItem(pane, conc3, 4, 9, 1, 1, GridBagConstraints.CENTER);
          if(totc>4)
              addItem(pane, conc4, 5, 9, 1, 1, GridBagConstraints.CENTER);
          if(totc>5)
              addItem(pane, conc5, 6, 9, 1, 1, GridBagConstraints.CENTER);
        }
        if(bcsel[bc]==6 || bcsel[bc]==7 || bcsel[bc]==10 || bcsel[bc]==11) {
          conclabel.setEnabled(false);
          conc0.setEnabled(false);
          conc0.setEditable(false);
          conc1.setEnabled(false);
          conc1.setEditable(false);
          conc2.setEnabled(false);
          conc2.setEditable(false);
          conc3.setEnabled(false);
          conc3.setEditable(false);
          conc4.setEnabled(false);
          conc4.setEditable(false);
          conc5.setEnabled(false);
          conc5.setEditable(false);
        }
        
        temper.setText(Double.toString(temp[bc]));
        heat.setText(Double.toString(tempdt[bc]));
        if(tott>0) {
            templabel.setFont(font);
            heatlabel.setFont(font);
            addItem(pane, templabel, 0, (totc>0)?10:8, 1, 1, GridBagConstraints.EAST);
            addItem(pane, heatlabel, 0, (totc>0)?11:9, 1, 1, GridBagConstraints.EAST);
            addItem(pane, temper, 1, (totc>0)?10:8, 1, 1, GridBagConstraints.CENTER);
            addItem(pane, heat, 1, (totc>0)?11:9, 1, 1, GridBagConstraints.CENTER);
        }
        if(bcsel[bc]%2==1) {
          templabel.setEnabled(false);
          heatlabel.setEnabled(false);
          temper.setEnabled(false);
          temper.setEditable(false);
          heat.setEnabled(false);
          heat.setEditable(false);
        }

        Box buttonBox = Box.createHorizontalBox();
        set.setFont(font);
        set.addActionListener(boundlbe);
        buttonBox.add(set);
        close.setFont(font);
        close.addActionListener(boundlbe);
        buttonBox.add(close);
        addItem(pane, buttonBox, 0, 12, width, 1, GridBagConstraints.WEST);

        this.add(pane);
        this.pack();
        setVisible(true);
    }

    private void addItem(JPanel p, JComponent c, int x, int y, int width, int height, int align)
    {
        GridBagConstraints gc = new GridBagConstraints();
        gc.gridx = x;
        gc.gridy = y;
        gc.gridwidth = width;
        gc.gridheight = height;
        gc.weightx = 100.0;
        gc.weighty = 100.0;
        gc.insets = new Insets(5, 5, 5, 5);
        gc.anchor = align;
        gc.fill = GridBagConstraints.NONE;
        p.add(c, gc);
    }

}
