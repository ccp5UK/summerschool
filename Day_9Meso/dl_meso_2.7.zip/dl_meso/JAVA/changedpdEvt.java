import javax.swing.*;
import java.util.*;
import java.lang.*;
import java.io.*;
import java.awt.*;
import java.awt.event.*;
import java.awt.geom.*;
import java.awt.image.*;
/*
 *     DL_MESO_GUI
 *     author: R. S. Qin, M. A. Seaton
 *     copyright: UKRI STFC Daresbury Laboratory and CCP5
 *     2005, 2018
 */
class changedpdEvt implements ItemListener, ActionListener {
    changedpdcode gui;
    static String str0, str1, str2, str3="source-file"; 
    static Boolean altfile = false, altedit = false;
    private static String OS = System.getProperty("os.name").toLowerCase();
    public changedpdEvt(changedpdcode in){
        gui = in;
    }
    public void actionPerformed(ActionEvent event) {
        String cmd =event.getActionCommand();
        if (cmd == "EDIT"){
            if(isWindows())
                str0 = "..\\DPD\\";
            else if(isMac() || isUnix())
                str0 = "../DPD/";
            if(altfile) {
               str2 = gui.openalt.getText();
            }
            if(str1 == "dlmesoEditor")
                dledit(str0+str2);
            else {
                if(altedit)
                    str1 = gui.editalt.getText();
                str3 = str1+" "+str0+str2;
                try {
                    Process p2 = Runtime.getRuntime().exec(str3);
                    BufferedReader ou2 = new BufferedReader
                    (new InputStreamReader(p2.getErrorStream()));
                    String line2;
                    while ((line2 = ou2.readLine()) != null)
                        System.err.println(line2);
                } catch (IOException e1) {
                    ierr(" "+str1+": not found");
                }
            }
        }
    }

    public void itemStateChanged(ItemEvent event) {
        Object item=event.getItem();
        String answer=item.toString();
        if(answer == "emacs") {
            str1="emacs";
            altedit = false;
        }
        else if(answer == "notepad") {
            str1="notepad";
            altedit = false;
        }
        else if(answer == "vi") {
            str1="vi";
            altedit = false;
        }
        else if(answer == "dlmesoEditor") {
            str1="dlmesoEditor";
            altedit = false;
        }
        else if(event.getSource() == gui.edit && answer == "other ...")
            altedit = true;
        else if(answer == "main file") {
            str2 = "dlmesodpd.f90";
            altfile = false;
        } 
        else if(answer == "main file (OpenMP)") {
            str2 = "dlmesodpd_omp.f90";
            altfile = false;
        } 
        else if(answer == "constants") {
            str2 = "constants.f90";
            altfile = false;
        }
        else if(answer == "global variables") {
            str2 = "variables.f90";
            altfile = false;
        } 
        else if(answer == "configuration module") {
            str2 = "config_module.f90";
            altfile = false;
        } 
        else if(answer == "start module") {
            str2 = "start_module.f90";
            altfile = false;
        } 
        else if(answer == "force calculation module") {
            str2 = "field_module.f90";
            altfile = false;
        } 
        else if(answer == "force calculation module (OpenMP)") {
            str2 = "field_module_omp.f90";
            altfile = false;
        }
        else if(answer == "bond interaction module") {
            str2 = "bond_module.f90";
            altfile = false;
        } 
        else if(answer == "bond interaction module (OpenMP)") {
            str2 = "bond_module_omp.f90";
            altfile = false;
        }
        else if(answer == "many-body DPD module") {
            str2 = "manybody_module.f90";
            altfile = false;
        } 
        else if(answer == "many-body DPD module (OpenMP)") {
            str2 = "manybody_module_omp.f90";
            altfile = false;
        }
        else if(answer == "ewald module") {
            str2 = "ewald_module.f90";
            altfile = false;
        }
        else if(answer == "ewald module (OpenMP)") {
            str2 = "ewald_module_omp.f90";
            altfile = false;
        }
        else if(answer == "SPME module") {
            str2 = "spme_module.f90";
            altfile = false;
        }
        else if(answer == "SPME module (OpenMP)") {
            str2 = "spme_module_omp.f90";
            altfile = false;
        }
        else if(answer == "surfaces module") {
            str2 = "surface_module.f90";
            altfile = false;
        } 
        else if(answer == "statistics module") {
            str2 = "statistics_module.f90";
            altfile = false;
        } 
        else if(event.getSource() == gui.open && answer == "other ...")
            altfile = true;
    }
    void dledit(String str) {
        dlmesoeditor dlm = new dlmesoeditor(str);
    }
    void ierr(String errinfo) {
        msgPanel fcer=new msgPanel(errinfo);
    }
    public static boolean isWindows() {
        return (OS.indexOf("win") >= 0);
    }
    
    public static boolean isMac() {
        return (OS.indexOf("mac") >= 0);
    }
    
    public static boolean isUnix() {
        return (OS.indexOf("nix") >= 0 || OS.indexOf("nux") >= 0 || OS.indexOf("aix") >= 0 || OS.indexOf("sunos") >= 0 );
    }
    
}
