/***************************************************
 *   DL_MESO       Version 2.7                     *
 *   Authors   :   R. S. Qin, M. A. Seaton         *
 *   Amended   :   L. Grinberg                     *
 *   Copyright :   UKRI STFC Daresbury Laboratory  *
 *             :   09/12/2018                      *
 ***************************************************/

// Standard fluid collisions

int fSiteFluidCollisionBGK(double* startpos, double *sitespeed, double *omega, double *rho, double* bodyforce)
{
  
  // calculate fluid collisions at grid point: uses BGK single relaxation time

  double speed[3], feq[lbsy.nq];
  double invmassrelax, relax;
  double *pt2 = &startpos[0];
  double *pt3 = &bodyforce[0];
  int qdim = lbsy.nf+lbsy.nc+lbsy.nt;
    
  for(int j=0; j<lbsy.nf; j++) {
    relax = 1.0 - omega[j];
    invmassrelax = fReciprocal(rho[j]*omega[j]);
    speed[0] = sitespeed[0] + pt3[3*j]   * invmassrelax;
    speed[1] = sitespeed[1] + pt3[3*j+1] * invmassrelax;
    speed[2] = sitespeed[2] + pt3[3*j+2] * invmassrelax;
    fGetEquilibriumF(&feq[0], speed, rho[j]);
    for(int i=0; i<lbsy.nq; i++){
      pt2[i*qdim+j] = relax * pt2[i*qdim+j] + feq[i]*omega[j];
    }
  }

  pt2 = NULL;
  pt3 = NULL;  
  return 0;
}

int fSiteFluidIncomCollisionBGK(double* startpos, double *sitespeed, double *omega, double *rho, double* bodyforce)
{
  
  // calculate fluid collisions at grid point: uses BGK single relaxation time
  // with incompressible fluids

  double speed[3], feq[lbsy.nq];
  double density, invmassrelax, relax;
  double *pt2 = &startpos[0];
  double *pt3 = &bodyforce[0];
  int qdim = lbsy.nf+lbsy.nc+lbsy.nt;

  for(int j=0; j<lbsy.nf; j++) {
    density = lbincp[j];
    relax = 1.0 - omega[j];
    invmassrelax = fReciprocal(density*omega[j]);
    speed[0] = sitespeed[0] + pt3[3*j]   * invmassrelax;
    speed[1] = sitespeed[1] + pt3[3*j+1] * invmassrelax;
    speed[2] = sitespeed[2] + pt3[3*j+2] * invmassrelax;
    fGetEquilibriumFIncom(&feq[0], speed, rho[j], density);
    for(int i=0; i<lbsy.nq; i++){
      pt2[i*qdim+j] = relax * pt2[i*qdim+j] + feq[i]*omega[j];
    }
  }

  pt2 = NULL;
  pt3 = NULL;  
  return 0;
}

int fSiteFluidCollisionBGKEDM(double* startpos, double *sitespeed, double *omega, double *rho, double* bodyforce)
{
  
  // calculate fluid collisions at grid point: uses BGK single relaxation time with
  // Exact Difference Method forcing term

  double dv[3], feq[lbsy.nq];
  double invmass, relax, source;
  double modv,eixux,eiyuy,eizuz,eixdux,eiyduy,eizduz;
  double *pt2 = &startpos[0];
  double *pt3 = &bodyforce[0];
  int qdim = lbsy.nf+lbsy.nc+lbsy.nt;

  for(int j=0; j<lbsy.nf; j++) {
    invmass = fReciprocal(rho[j]);
    dv[0] = pt3[3*j]   * invmass;
    dv[1] = pt3[3*j+1] * invmass;
    dv[2] = pt3[3*j+2] * invmass;
    fGetEquilibriumF(&feq[0], sitespeed, rho[j]);
    relax = 1.0 - omega[j];
    modv = dv[0]*(2.0*sitespeed[0]+dv[0]) + dv[1]*(2.0*sitespeed[1]+dv[1]) + dv[2]*(2.0*sitespeed[2]+dv[2]);
    for(int i=0; i<lbsy.nq; i++){
      eixux =  lbvx[i]*sitespeed[0];
      eiyuy =  lbvy[i]*sitespeed[1];
      eizuz =  lbvz[i]*sitespeed[2];
      eixdux = lbvx[i]*dv[0];
      eiyduy = lbvy[i]*dv[1];
      eizduz = lbvz[i]*dv[2];
      source = rho[j] * lbw[i] * (3.0 * (eixdux+eiyduy+eizduz) +
                                  4.5 * (eixdux*(eixdux+2.0*(eixux+eiyuy+eizuz+eiyduy+eizduz)) +
                                         eiyduy*(eiyduy+2.0*(eixux+eiyuy+eizuz+eizduz)) +
                                         eizduz*(eizduz+2.0*(eixux+eiyuy+eizuz))) -
                                  1.5 * modv);
      pt2[i*qdim+j] = relax * pt2[i*qdim+j] + source + feq[i]*omega[j];
    }
  }

  pt2 = NULL;
  pt3 = NULL;  
  return 0;
}

int fSiteFluidIncomCollisionBGKEDM(double* startpos, double *sitespeed, double *omega, double *rho, double* bodyforce)
{
  
  // calculate fluid collisions at grid point: uses BGK single relaxation time
  // with incompressible fluids and Exact Difference Method forcing term

  double dv[3], feq[lbsy.nq];
  double density, invmass, relax, source;
  double modv,eixux,eiyuy,eizuz,eixdux,eiyduy,eizduz;
  double *pt2 = &startpos[0];
  double *pt3 = &bodyforce[0];
  int qdim = lbsy.nf+lbsy.nc+lbsy.nt;

  for(int j=0; j<lbsy.nf; j++) {
    density = lbincp[j];
    invmass = fReciprocal(density);
    relax = 1.0 - omega[j];
    dv[0] = pt3[3*j]   * invmass;
    dv[1] = pt3[3*j+1] * invmass;
    dv[2] = pt3[3*j+2] * invmass;
    fGetEquilibriumFIncom(&feq[0], sitespeed, rho[j], density);
    modv = dv[0]*(2.0*sitespeed[0]+dv[0]) + dv[1]*(2.0*sitespeed[1]+dv[1]) + dv[2]*(2.0*sitespeed[2]+dv[2]);
    for(int i=0; i<lbsy.nq; i++){
      eixux =  lbvx[i]*sitespeed[0];
      eiyuy =  lbvy[i]*sitespeed[1];
      eizuz =  lbvz[i]*sitespeed[2];
      eixdux = lbvx[i]*dv[0];
      eiyduy = lbvy[i]*dv[1];
      eizduz = lbvz[i]*dv[2];
      source = density * lbw[i] * (3.0 * (eixdux+eiyduy+eizduz) +
                                   4.5 * (eixdux*(eixdux+2.0*(eixux+eiyuy+eizuz+eiyduy+eizduz)) +
                                          eiyduy*(eiyduy+2.0*(eixux+eiyuy+eizuz+eizduz)) +
                                          eizduz*(eizduz+2.0*(eixux+eiyuy+eizuz))) -
                                   1.5 * modv);
      pt2[i*qdim+j] = relax * pt2[i*qdim+j] + source + feq[i]*omega[j];
    }
  }

  pt2 = NULL;
  pt3 = NULL;  
  return 0;
}

int fSiteFluidCollisionBGKGuo(double* startpos, double *sitespeed, double *omega, double *rho, double* bodyforce)
{
  
  // calculate fluid collisions at grid point: uses BGK single relaxation time with
  // Guo forcing term

  double speed[3], force[3], feq[lbsy.nq];
  double udot, source, invmass, relax, halfrelax, ex, ey, ez;
  double *pt2 = &startpos[0];
  double *pt3 = &bodyforce[0];
  int qdim = lbsy.nf+lbsy.nc+lbsy.nt;

  for(int j=0; j<lbsy.nf; j++) {
    invmass = fReciprocal(rho[j]);
    force[0] = pt3[3*j];
    force[1] = pt3[3*j+1];
    force[2] = pt3[3*j+2];
    speed[0] = sitespeed[0] + 0.5 * force[0] * invmass;
    speed[1] = sitespeed[1] + 0.5 * force[1] * invmass;
    speed[2] = sitespeed[2] + 0.5 * force[2] * invmass;
    fGetEquilibriumF(&feq[0], speed, rho[j]);
    relax = 1.0 - omega[j];
    halfrelax = 1.0 - 0.5*omega[j];
    for(int i=0; i<lbsy.nq; i++){
      ex = lbvx[i];
      ey = lbvy[i];
      ez = lbvz[i];
      udot = ex * speed[0] + ey * speed[1] + ez * speed[2];
      source = (3.0*(ex-speed[0]) + 9.0*udot*ex) * force[0]
             + (3.0*(ey-speed[1]) + 9.0*udot*ey) * force[1]
             + (3.0*(ez-speed[2]) + 9.0*udot*ez) * force[2];
      pt2[i*qdim+j] = relax * pt2[i*qdim+j] + halfrelax * lbw[i] * source + feq[i]*omega[j];
    }
  }

  pt2 = NULL;
  pt3 = NULL;  
  return 0;
}

int fSiteFluidIncomCollisionBGKGuo(double* startpos, double *sitespeed, double *omega, double *rho, double* bodyforce)
{
  
  // calculate fluid collisions at grid point: uses BGK single relaxation time with
  // Guo forcing term for incompressible fluids

  double speed[3], force[3], feq[lbsy.nq];
  double density, udot, source, invmass, relax, halfrelax, ex, ey, ez;
  double *pt2 = &startpos[0];
  double *pt3 = &bodyforce[0];
  int qdim = lbsy.nf+lbsy.nc+lbsy.nt;

  for(int j=0; j<lbsy.nf; j++) {
    density = lbincp[j];
    invmass = fReciprocal(density);
    force[0] = pt3[3*j];
    force[1] = pt3[3*j+1];
    force[2] = pt3[3*j+2];
    speed[0] = sitespeed[0] + 0.5 * force[0] * invmass;
    speed[1] = sitespeed[1] + 0.5 * force[1] * invmass;
    speed[2] = sitespeed[2] + 0.5 * force[2] * invmass;
    fGetEquilibriumFIncom(&feq[0], speed, rho[j], density);
    relax = 1.0 - omega[j];
    halfrelax = 1.0 - 0.5*omega[j];
    for(int i=0; i<lbsy.nq; i++){
      ex = lbvx[i];
      ey = lbvy[i];
      ez = lbvz[i];
      udot = ex * speed[0] + ey * speed[1] + ez * speed[2];
      source = (3.0*(ex-speed[0]) + 9.0*udot*ex) * force[0]
             + (3.0*(ey-speed[1]) + 9.0*udot*ey) * force[1]
             + (3.0*(ez-speed[2]) + 9.0*udot*ez) * force[2];
      pt2[i*qdim+j] = relax * pt2[i*qdim+j] + halfrelax * lbw[i] * source + feq[i]*omega[j];
    }
  }

  pt2 = NULL;
  pt3 = NULL;  
  return 0;
}

int fSiteFluidCollisionBGKHe(double* startpos, double *sitespeed, double *omega, double *rho, double* bodyforce)
{
  
  // calculate fluid collisions at grid point: uses BGK single relaxation time with
  // He forcing term

  double speed[3], force[3], feq[lbsy.nq];
  double udot, fdot, modv, modf, source, invmass, relax, halfrelax, ex, ey, ez;
  double *pt2 = &startpos[0];
  double *pt3 = &bodyforce[0];
  int qdim = lbsy.nf+lbsy.nc+lbsy.nt;

  for(int j=0; j<lbsy.nf; j++) {
    invmass = fReciprocal(rho[j]);
    force[0] = pt3[3*j];
    force[1] = pt3[3*j+1];
    force[2] = pt3[3*j+2];
    speed[0] = sitespeed[0] + 0.5 * force[0] * invmass;
    speed[1] = sitespeed[1] + 0.5 * force[1] * invmass;
    speed[2] = sitespeed[2] + 0.5 * force[2] * invmass;
    modv = speed[0] * speed[0] + speed[1] * speed[1] + speed[2] * speed[2];
    modf = speed[0] * force[0] + speed[1] * force[1] + speed[2] * force[2];
    fGetEquilibriumF(&feq[0], speed, rho[j]);
    relax = 1.0 - omega[j];
    halfrelax = 1.0 - 0.5*omega[j];
    for(int i=0; i<lbsy.nq; i++){
      ex = lbvx[i];
      ey = lbvy[i];
      ez = lbvz[i];
      udot = ex * speed[0] + ey * speed[1] + ez * speed[2];
      fdot = ex * force[0] + ey * force[1] + ez * force[2];
      source = 3.0*(fdot-modf)*(1.0+3.0*udot) + 4.5*fdot*(3.0*udot*udot-modv);
      pt2[i*qdim+j] = relax * pt2[i*qdim+j] + halfrelax * lbw[i] * source + feq[i]*omega[j];
    }
  }

  pt2 = NULL;
  pt3 = NULL;
  return 0;
}

int fSiteFluidIncomCollisionBGKHe(double* startpos, double *sitespeed, double *omega, double *rho, double* bodyforce)
{
  
  // calculate fluid collisions at grid point: uses BGK single relaxation time with
  // He forcing term for incompressible fluids

  double speed[3], force[3], feq[lbsy.nq];
  double density, udot, fdot, modv, modf, source, invmass, relax, halfrelax, ex, ey, ez;
  double *pt2 = &startpos[0];
  double *pt3 = &bodyforce[0];
  int qdim = lbsy.nf+lbsy.nc+lbsy.nt;

  for(int j=0; j<lbsy.nf; j++) {
    density = lbincp[j];
    invmass = fReciprocal(density);
    force[0] = pt3[3*j];
    force[1] = pt3[3*j+1];
    force[2] = pt3[3*j+2];
    speed[0] = sitespeed[0] + 0.5 * force[0] * invmass;
    speed[1] = sitespeed[1] + 0.5 * force[1] * invmass;
    speed[2] = sitespeed[2] + 0.5 * force[2] * invmass;
    modv = speed[0] * speed[0] + speed[1] * speed[1] + speed[2] * speed[2];
    modf = speed[0] * force[0] + speed[1] * force[1] + speed[2] * force[2];
    fGetEquilibriumFIncom(&feq[0], speed, rho[j], density);
    relax = 1.0 - omega[j];
    halfrelax = 1.0 - 0.5*omega[j];
    for(int i=0; i<lbsy.nq; i++){
      ex = lbvx[i];
      ey = lbvy[i];
      ez = lbvz[i];
      udot = ex * speed[0] + ey * speed[1] + ez * speed[2];
      fdot = ex * force[0] + ey * force[1] + ez * force[2];
      source = 3.0*(fdot-modf)*(1.0+3.0*udot) + 4.5*fdot*(3.0*udot*udot-modv);
      pt2[i*qdim+j] = relax * pt2[i*qdim+j] + halfrelax * lbw[i] * source + feq[i]*omega[j];
    }
  }

  pt2 = NULL;
  pt3 = NULL;
  return 0;
}

// Achromatic fluid collisions with pre-calculated interfacial forces and phase segregation

int fSiteFluidCollisionBGKLishchuk(double* startpos, double *sitespeed, double *omega, double *rho, double* bodyforce, double* phaseindex)
{

  // BGK collision of achromatic fluid and D'Ortona segregration 
  // calculate collisions at grid point: uses BGK single relaxation time

  double speed[3], feq[lbsy.nq];
  double allmass, invallmass, omegatot, nx, ny, nz, segpiece, segcomp, collpiece, invmassrelax, relax;
  double seg[lbsy.nf*lbsy.nq], lbfac[lbsy.nq];
  double *pt2 = &startpos[0];
  double *pt3 = &bodyforce[0];
  double *pt4 = &phaseindex[0];
  int numpair = lbsy.nf*(lbsy.nf-1)/2;
  int qdim = lbsy.nf+lbsy.nc+lbsy.nt;

  // collision of achromatic fluid

  allmass = 0.0;
  omegatot = 0.0;

  for(int j=0; j<lbsy.nf; j++) {
    allmass += rho[j];
    omegatot += omega[j] * rho[j];
  }

  invallmass = fReciprocal(allmass);
  omegatot *= invallmass;
      
  for(int i=0; i<lbsy.nq; i++) {
    lbfac[i] = 0.0;
    for(int j=0; j<lbsy.nf; j++) {
      lbfac[i] += pt2[i*qdim+j];
      seg[i*lbsy.nf+j] = 0.0;
    }
  }

  // calculate segregation terms

  for(int k=0; k<numpair; k++) {
    int i = lbspair[2*k  ];
    int j = lbspair[2*k+1];
    nx = pt4[3*k  ];
    ny = pt4[3*k+1];
    nz = pt4[3*k+2];
    segpiece = lbseg[lbsy.nf*j+i] * rho[i] * rho[j] * invallmass * invallmass;
    for(int m=0; m<lbsy.nq; m++) {
      segcomp = segpiece * (lbvwx[m]*nx + lbvwy[m]*ny + lbvwz[m]*nz);
      seg[m*lbsy.nf+i] += segcomp;
      seg[m*lbsy.nf+j] -= segcomp;
    }
  }

  // collide and segregate fluids
    
  invmassrelax = invallmass * fReciprocal(omegatot);
  relax = 1.0 - omegatot;
  speed[0] = sitespeed[0] + pt3[0] * invmassrelax;
  speed[1] = sitespeed[1] + pt3[1] * invmassrelax;
  speed[2] = sitespeed[2] + pt3[2] * invmassrelax;
  fGetEquilibriumF(&feq[0], speed, allmass);
  for(int m=0; m<lbsy.nq; m++){
    collpiece = relax * lbfac[m] + feq[m]*omegatot;
    for(int i=0; i<lbsy.nf; i++) {
      pt2[m*qdim+i] = rho[i] * collpiece * invallmass + seg[m*lbsy.nf+i];
    }
  }

  pt2 = NULL;
  pt3 = NULL;  
  pt4 = NULL;  
  return 0;
}

int fSiteFluidIncomCollisionBGKLishchuk(double* startpos, double *sitespeed, double *omega, double *rho, double* bodyforce, double* phaseindex)
{

  // BGK collision of achromatic fluid and D'Ortona segregration 
  // calculate collisions at grid point: uses BGK single relaxation time with incompressible fluids

  double speed[3], feq[lbsy.nq];
  double allmass, invallmass, invmassrelax, relax, density, omegatot, nx, ny, nz, segcomp, segpiece, collpiece;
  double seg[lbsy.nf*lbsy.nq], lbfac[lbsy.nq];
  double *pt2 = &startpos[0];
  double *pt3 = &bodyforce[0];
  double *pt4 = &phaseindex[0];
  int numpair = lbsy.nf*(lbsy.nf-1)/2;
  int qdim = lbsy.nf+lbsy.nc+lbsy.nt;

  // collision of achromatic fluid

  allmass = 0.0;
  omegatot = 0.0;
  density = 0.0;

  for(int j=0; j<lbsy.nf; j++) {
    allmass += rho[j];
    omegatot += omega[j] * rho[j];
    density += lbincp[j] * rho[j];
  }

  invallmass = fReciprocal(allmass);
  omegatot *= invallmass;
  density *= invallmass;

  for(int i=0; i<lbsy.nq; i++) {
    lbfac[i] = 0.0;
    for(int j=0; j<lbsy.nf; j++) {
      lbfac[i] += pt2[i*qdim+j];
      seg[i*lbsy.nf+j] = 0.0;
    }
  }

  // calculate segregation terms

  for(int k=0; k<numpair; k++) {
    int i = lbspair[2*k  ];
    int j = lbspair[2*k+1];
    nx = pt4[3*k  ];
    ny = pt4[3*k+1];
    nz = pt4[3*k+2];
    segpiece = lbseg[lbsy.nf*j+i] * rho[i] * rho[j] * invallmass * invallmass;
    for(int m=0; m<lbsy.nq; m++) {
      segcomp = segpiece * (lbvwx[m]*nx + lbvwy[m]*ny + lbvwz[m]*nz);
      seg[m*lbsy.nf+i] += segcomp;
      seg[m*lbsy.nf+j] -= segcomp;
    }
  }

  // collide and segregate fluids
    
  invmassrelax = fReciprocal(omegatot*density);
  relax = 1.0 - omegatot;
  speed[0] = sitespeed[0] + pt3[0] * invmassrelax;
  speed[1] = sitespeed[1] + pt3[1] * invmassrelax;
  speed[2] = sitespeed[2] + pt3[2] * invmassrelax;
  fGetEquilibriumFIncom(&feq[0], speed, allmass, density);
  for(int m=0; m<lbsy.nq; m++){
    collpiece = relax * lbfac[m] + feq[m]*omegatot;
    for(int i=0; i<lbsy.nf; i++) {
      pt2[m*qdim+i] = rho[i] * collpiece * invallmass + seg[m*lbsy.nf+i];
    }
  }

  pt2 = NULL;
  pt3 = NULL;  
  pt4 = NULL;  
  return 0;
}

int fSiteFluidCollisionBGKEDMLishchuk(double* startpos, double *sitespeed, double *omega, double *rho, double* bodyforce, double* phaseindex)
{

  // BGK collision of achromatic fluid and D'Ortona segregration 
  // calculate collisions at grid point: uses BGK single relaxation time with
  // Exact Difference Method forcing term

  double dv[3], feq[lbsy.nq];
  double allmass, invallmass, omegatot, nx, ny, nz, segpiece, collpiece, segcomp, relax, source;
  double modv,eixux,eiyuy,eizuz,eixdux,eiyduy,eizduz;
  double seg[lbsy.nf*lbsy.nq], lbfac[lbsy.nq];
  double *pt2 = &startpos[0];
  double *pt3 = &bodyforce[0];
  double *pt4 = &phaseindex[0];
  int numpair = lbsy.nf*(lbsy.nf-1)/2;
  int qdim = lbsy.nf+lbsy.nc+lbsy.nt;

  // collision of achromatic fluid

  allmass = 0.0;
  omegatot = 0.0;

  for(int j=0; j<lbsy.nf; j++) {
    allmass += rho[j];
    omegatot += omega[j] * rho[j];
  }

  invallmass = fReciprocal(allmass);
  omegatot *= invallmass;
      
  for(int i=0; i<lbsy.nq; i++) {
    lbfac[i] = 0.0;
    for(int j=0; j<lbsy.nf; j++) {
      lbfac[i] += pt2[i*qdim+j];
      seg[i*lbsy.nf+j] = 0.0;
    }
  }

  // calculate segregation terms

  for(int k=0; k<numpair; k++) {
    int i = lbspair[2*k  ];
    int j = lbspair[2*k+1];
    nx = pt4[3*k  ];
    ny = pt4[3*k+1];
    nz = pt4[3*k+2];
    segpiece = lbseg[lbsy.nf*j+i] * rho[i] * rho[j] * invallmass * invallmass;
    for(int m=0; m<lbsy.nq; m++) {
      segcomp = segpiece * (lbvwx[m]*nx + lbvwy[m]*ny + lbvwz[m]*nz);
      seg[m*lbsy.nf+i] += segcomp;
      seg[m*lbsy.nf+j] -= segcomp;
    }
  }

  // collide and segregate fluids
    
  relax = 1.0 - omegatot;
  dv[0] = pt3[0] * invallmass;
  dv[1] = pt3[1] * invallmass;
  dv[2] = pt3[2] * invallmass;
  fGetEquilibriumF(&feq[0], sitespeed, allmass);
  modv = dv[0]*(2.0*sitespeed[0]+dv[0]) + dv[1]*(2.0*sitespeed[1]+dv[1]) + dv[2]*(2.0*sitespeed[2]+dv[2]);
  for(int m=0; m<lbsy.nq; m++){
    eixux =  lbvx[m]*sitespeed[0];
    eiyuy =  lbvy[m]*sitespeed[1];
    eizuz =  lbvz[m]*sitespeed[2];
    eixdux = lbvx[m]*dv[0];
    eiyduy = lbvy[m]*dv[1];
    eizduz = lbvz[m]*dv[2];
    source = allmass * lbw[m] * (3.0 * (eixdux+eiyduy+eizduz) +
                                 4.5 * (eixdux*(eixdux+2.0*(eixux+eiyuy+eizuz+eiyduy+eizduz)) +
                                        eiyduy*(eiyduy+2.0*(eixux+eiyuy+eizuz+eizduz)) +
                                        eizduz*(eizduz+2.0*(eixux+eiyuy+eizuz))) -
                                 1.5 * modv);
    collpiece = relax * lbfac[m] + source + feq[m]*omegatot;
    for(int i=0; i<lbsy.nf; i++) {
      pt2[m*qdim+i] = rho[i] * collpiece * invallmass + seg[m*lbsy.nf+i];
    }
  }

  pt2 = NULL;
  pt3 = NULL;  
  pt4 = NULL;  
  return 0;
}

int fSiteFluidIncomCollisionBGKEDMLishchuk(double* startpos, double *sitespeed, double *omega, double *rho, double* bodyforce, double* phaseindex)
{

  // BGK collision of achromatic fluid and D'Ortona segregration 
  // calculate collisions at grid point: uses BGK single relaxation time
  // with incompressible fluids and Exact Difference Method forcing term

  double dv[3], feq[lbsy.nq];
  double allmass, invallmass, invmass, relax, density, omegatot, nx, ny, nz, segcomp, segpiece, collpiece, source;
  double modv,eixux,eiyuy,eizuz,eixdux,eiyduy,eizduz;
  double seg[lbsy.nf*lbsy.nq], lbfac[lbsy.nq];
  double *pt2 = &startpos[0];
  double *pt3 = &bodyforce[0];
  double *pt4 = &phaseindex[0];
  int numpair = lbsy.nf*(lbsy.nf-1)/2;
  int qdim = lbsy.nf+lbsy.nc+lbsy.nt;

  // collision of achromatic fluid

  allmass = 0.0;
  omegatot = 0.0;
  density = 0.0;

  for(int j=0; j<lbsy.nf; j++) {
    allmass += rho[j];
    omegatot += omega[j] * rho[j];
    density += lbincp[j] * rho[j];
  }

  invallmass = fReciprocal(allmass);
  omegatot *= invallmass;
  density *= invallmass;

  for(int i=0; i<lbsy.nq; i++) {
    lbfac[i] = 0.0;
    for(int j=0; j<lbsy.nf; j++) {
      lbfac[i] += pt2[i*qdim+j];
      seg[i*lbsy.nf+j] = 0.0;
    }
  }

  // calculate segregation terms

  for(int k=0; k<numpair; k++) {
    int i = lbspair[2*k  ];
    int j = lbspair[2*k+1];
    nx = pt4[3*k  ];
    ny = pt4[3*k+1];
    nz = pt4[3*k+2];
    segpiece = lbseg[lbsy.nf*j+i] * rho[i] * rho[j] * invallmass * invallmass;
    for(int m=0; m<lbsy.nq; m++) {
      segcomp = segpiece * (lbvwx[m]*nx + lbvwy[m]*ny + lbvwz[m]*nz);
      seg[m*lbsy.nf+i] += segcomp;
      seg[m*lbsy.nf+j] -= segcomp;
    }
  }

  // collide and segregate fluids
    
  invmass = fReciprocal(density);
  relax = 1.0 - omegatot;
  dv[0] = pt3[0] * invmass;
  dv[1] = pt3[1] * invmass;
  dv[2] = pt3[2] * invmass;
  fGetEquilibriumFIncom(&feq[0], sitespeed, allmass, density);
  modv = dv[0]*(2.0*sitespeed[0]+dv[0]) + dv[1]*(2.0*sitespeed[1]+dv[1]) + dv[2]*(2.0*sitespeed[2]+dv[2]);
  for(int m=0; m<lbsy.nq; m++){
    eixux =  lbvx[m]*sitespeed[0];
    eiyuy =  lbvy[m]*sitespeed[1];
    eizuz =  lbvz[m]*sitespeed[2];
    eixdux = lbvx[m]*dv[0];
    eiyduy = lbvy[m]*dv[1];
    eizduz = lbvz[m]*dv[2];
    source = density * lbw[m] * (3.0 * (eixdux+eiyduy+eizduz) +
                                 4.5 * (eixdux*(eixdux+2.0*(eixux+eiyuy+eizuz+eiyduy+eizduz)) +
                                        eiyduy*(eiyduy+2.0*(eixux+eiyuy+eizuz+eizduz)) +
                                        eizduz*(eizduz+2.0*(eixux+eiyuy+eizuz))) -
                                 1.5 * modv);
    collpiece = relax * lbfac[m] + source + feq[m]*omegatot;
    for(int i=0; i<lbsy.nf; i++) {
      pt2[m*qdim+i] = rho[i] * collpiece * invallmass + seg[m*lbsy.nf+i];
    }
  }

  pt2 = NULL;
  pt3 = NULL;  
  pt4 = NULL;  
  return 0;
}

int fSiteFluidCollisionBGKGuoLishchuk(double* startpos, double *sitespeed, double *omega, double *rho, double* bodyforce, double* phaseindex)
{

  // BGK collision of achromatic fluid and D'Ortona segregration 
  // calculate collisions at grid point: uses BGK single relaxation time with Guo forcing term

  double speed[3], force[3], feq[lbsy.nq];
  double udot, source, allmass, invallmass, omegatot, nx, ny, nz;
  double ex, ey, ez, segcomp, segpiece, collpiece, relax, halfrelax;
  double seg[lbsy.nf*lbsy.nq], lbfac[lbsy.nq];
  double *pt2 = &startpos[0];
  double *pt3 = &bodyforce[0];
  double *pt4 = &phaseindex[0];
  int numpair = lbsy.nf*(lbsy.nf-1)/2;
  int qdim = lbsy.nf+lbsy.nc+lbsy.nt;

  // collision of achromatic fluid

  allmass = 0.0;
  omegatot = 0.0;

  for(int j=0; j<lbsy.nf; j++) {
    allmass += rho[j];
    omegatot += omega[j] * rho[j];
  }

  invallmass = fReciprocal(allmass);
  omegatot *= invallmass;
      
  for(int i=0; i<lbsy.nq; i++) {
    lbfac[i] = 0.0;
    for(int j=0; j<lbsy.nf; j++) {
      lbfac[i] += pt2[i*qdim+j];
      seg[i*lbsy.nf+j] = 0.0;
    }
  }

  // calculate segregation terms

  for(int k=0; k<numpair; k++) {
    int i = lbspair[2*k  ];
    int j = lbspair[2*k+1];
    nx = pt4[3*k  ];
    ny = pt4[3*k+1];
    nz = pt4[3*k+2];
    segpiece = lbseg[lbsy.nf*j+i] * rho[i] * rho[j] * invallmass * invallmass;
    for(int m=0; m<lbsy.nq; m++) {
      segcomp = segpiece * (lbvwx[m]*nx + lbvwy[m]*ny + lbvwz[m]*nz);
      seg[m*lbsy.nf+i] += segcomp;
      seg[m*lbsy.nf+j] -= segcomp;
    }
  }

  // collide and segregate fluids
    
  force[0] = pt3[0];
  force[1] = pt3[1];
  force[2] = pt3[2];
  speed[0] = sitespeed[0] + 0.5 * force[0] * invallmass;
  speed[1] = sitespeed[1] + 0.5 * force[1] * invallmass;
  speed[2] = sitespeed[2] + 0.5 * force[2] * invallmass;
  fGetEquilibriumF(&feq[0], speed, allmass);
  relax = 1.0 - omegatot;
  halfrelax = 1.0 - 0.5*omegatot;
  for(int m=0; m<lbsy.nq; m++){
    ex = lbvx[m];
    ey = lbvy[m];
    ez = lbvz[m];
    udot = ex * speed[0] + ey * speed[1] + ez * speed[2];
    source = (3.0*(ex-speed[0]) + 9.0*udot*ex) * force[0]
           + (3.0*(ey-speed[1]) + 9.0*udot*ey) * force[1]
           + (3.0*(ez-speed[2]) + 9.0*udot*ez) * force[2];
    collpiece = relax * lbfac[m] + halfrelax * lbw[m] * source + feq[m]*omegatot;
    for(int i=0; i<lbsy.nf; i++) {
      pt2[m*qdim+i] = rho[i] * collpiece * invallmass + seg[m*lbsy.nf+i];
    }
  }

  pt2 = NULL;
  pt3 = NULL;  
  pt4 = NULL;  
  return 0;
}

int fSiteFluidIncomCollisionBGKGuoLishchuk(double* startpos, double *sitespeed, double *omega, double *rho, double* bodyforce, double* phaseindex)
{

  // BGK collision of achromatic fluid and D'Ortona segregration 
  // calculate collisions at grid point: uses BGK single relaxation time
  // with Guo forcing term for incompressible fluids

  double speed[3], force[3], feq[lbsy.nq];
  double udot, source, allmass, invallmass, density, invdensity, omegatot, nx, ny, nz;
  double ex, ey, ez, segcomp, segpiece, collpiece, relax, halfrelax;
  double seg[lbsy.nf*lbsy.nq], lbfac[lbsy.nq];
  double *pt2 = &startpos[0];
  double *pt3 = &bodyforce[0];
  double *pt4 = &phaseindex[0];
  int numpair = lbsy.nf*(lbsy.nf-1)/2;
  int qdim = lbsy.nf+lbsy.nc+lbsy.nt;

  // collision of achromatic fluid

  allmass = 0.0;
  omegatot = 0.0;
  density = 0.0;

  for(int j=0; j<lbsy.nf; j++) {
    allmass += rho[j];
    omegatot += omega[j] * rho[j];
    density += lbincp[j] * rho[j];
  }

  invallmass = fReciprocal(allmass);
  omegatot *= invallmass;
  density += invallmass;

  for(int i=0; i<lbsy.nq; i++) {
    lbfac[i] = 0.0;
    for(int j=0; j<lbsy.nf; j++) {
      lbfac[i] += pt2[i*qdim+j];
      seg[i*lbsy.nf+j] = 0.0;
    }
  }

  // calculate segregation terms

  for(int k=0; k<numpair; k++) {
    int i = lbspair[2*k  ];
    int j = lbspair[2*k+1];
    nx = pt4[3*k  ];
    ny = pt4[3*k+1];
    nz = pt4[3*k+2];
    segpiece = lbseg[lbsy.nf*j+i] * rho[i] * rho[j] * invallmass * invallmass;
    for(int m=0; m<lbsy.nq; m++) {
      segcomp = segpiece * (lbvwx[m]*nx + lbvwy[m]*ny + lbvwz[m]*nz);
      seg[m*lbsy.nf+i] += segcomp;
      seg[m*lbsy.nf+j] -= segcomp;
    }
  }

  // collide and segregate fluids
    
  invdensity = fReciprocal(density);
  force[0] = pt3[0];
  force[1] = pt3[1];
  force[2] = pt3[2];
  speed[0] = sitespeed[0] + 0.5 * force[0] * invdensity;
  speed[1] = sitespeed[1] + 0.5 * force[1] * invdensity;
  speed[2] = sitespeed[2] + 0.5 * force[2] * invdensity;
  fGetEquilibriumFIncom(&feq[0], speed, allmass, density);
  relax = 1.0 - omegatot;
  halfrelax = 1.0 - 0.5*omegatot;
  for(int m=0; m<lbsy.nq; m++){
    ex = lbvx[m];
    ey = lbvy[m];
    ez = lbvz[m];
    udot = ex * speed[0] + ey * speed[1] + ez * speed[2];
    source = (3.0*(ex-speed[0]) + 9.0*udot*ex) * force[0]
           + (3.0*(ey-speed[1]) + 9.0*udot*ey) * force[1]
           + (3.0*(ez-speed[2]) + 9.0*udot*ez) * force[2];
    collpiece = relax * lbfac[m] + halfrelax * lbw[m] * source + lbfeq[m]*omegatot;
    for(int i=0; i<lbsy.nf; i++) {
      pt2[m*qdim+i] = rho[i] * collpiece * invallmass + seg[m*lbsy.nf+i];
    }
  }

  pt2 = NULL;
  pt3 = NULL;  
  pt4 = NULL;  
  return 0;
}

int fSiteFluidCollisionBGKHeLishchuk(double* startpos, double *sitespeed, double *omega, double *rho, double* bodyforce, double* phaseindex)
{

  // BGK collision of achromatic fluid and D'Ortona segregration
  // calculate collisions at grid point: uses BGK single relaxation time with He forcing term

  double speed[3], force[3], feq[lbsy.nq];
  double udot, fdot, modv, modf, source, allmass, invallmass, omegatot, nx, ny, nz;
  double ex, ey, ez, segcomp, segpiece, collpiece, relax, halfrelax;
  double seg[lbsy.nf*lbsy.nq], lbfac[lbsy.nq];
  double *pt2 = &startpos[0];
  double *pt3 = &bodyforce[0];
  double *pt4 = &phaseindex[0];
  int numpair = lbsy.nf*(lbsy.nf-1)/2;
  int qdim = lbsy.nf+lbsy.nc+lbsy.nt;

  // collision of achromatic fluid

  allmass = 0.0;
  omegatot = 0.0;

  for(int j=0; j<lbsy.nf; j++) {
    allmass += rho[j];
    omegatot += omega[j] * rho[j];
  }

  invallmass = fReciprocal(allmass);
  omegatot *= invallmass;
    
  for(int i=0; i<lbsy.nq; i++) {
    lbfac[i] = 0.0;
    for(int j=0; j<lbsy.nf; j++) {
      lbfac[i] += pt2[i*qdim+j];
      seg[i*lbsy.nf+j] = 0.0;
    }
  }

  // calculate segregation terms

  for(int k=0; k<numpair; k++) {
    int i = lbspair[2*k  ];
    int j = lbspair[2*k+1];
    nx = pt4[3*k  ];
    ny = pt4[3*k+1];
    nz = pt4[3*k+2];
    segpiece = lbseg[lbsy.nf*j+i] * rho[i] * rho[j] * invallmass * invallmass;
    for(int m=0; m<lbsy.nq; m++) {
      segcomp = segpiece * (lbvwx[m]*nx + lbvwy[m]*ny + lbvwz[m]*nz);
      seg[m*lbsy.nf+i] += segcomp;
      seg[m*lbsy.nf+j] -= segcomp;
    }
  }

  // collide and segregate fluids
    
  force[0] = pt3[0];
  force[1] = pt3[1];
  force[2] = pt3[2];
  speed[0] = sitespeed[0] + 0.5 * force[0] * invallmass;
  speed[1] = sitespeed[1] + 0.5 * force[1] * invallmass;
  speed[2] = sitespeed[2] + 0.5 * force[2] * invallmass;
  modv = speed[0] * speed[0] + speed[1] * speed[1] + speed[2] * speed[2];
  modf = speed[0] * force[0] + speed[1] * force[1] + speed[2] * force[2];
  fGetEquilibriumF(&feq[0], speed, allmass);
  relax = 1.0 - omegatot;
  halfrelax = 1.0 - 0.5*omegatot;
  for(int m=0; m<lbsy.nq; m++){
    ex = lbvx[m];
    ey = lbvy[m];
    ez = lbvz[m];
    udot = ex * speed[0] + ey * speed[1] + ez * speed[2];
    fdot = ex * force[0] + ey * force[1] + ez * force[2];
    source = 3.0*(fdot-modf)*(1.0+3.0*udot) + 4.5*fdot*(3.0*udot*udot-modv);
    collpiece = relax * lbfac[m] + halfrelax * lbw[m] * source + feq[m]*omegatot;
    for(int i=0; i<lbsy.nf; i++) {
      pt2[m*qdim+i] = rho[i] * collpiece * invallmass + seg[m*lbsy.nf+i];
    }
  }

  pt2 = NULL;
  pt3 = NULL;
  pt4 = NULL;
  return 0;
}

int fSiteFluidIncomCollisionBGKHeLishchuk(double* startpos, double *sitespeed, double *omega, double *rho, double* bodyforce, double* phaseindex)
{

  // BGK collision of achromatic fluid and D'Ortona segregration
  // calculate collisions at grid point: uses BGK single relaxation time
  // with He forcing term for incompressible fluids

  double speed[3], force[3], feq[lbsy.nq];
  double udot, fdot, modv, modf, source, allmass, invallmass, density, invdensity, omegatot, nx, ny, nz;
  double ex, ey, ez, segcomp, segpiece, collpiece, relax, halfrelax;
  double seg[lbsy.nf*lbsy.nq], lbfac[lbsy.nq];
  double *pt2 = &startpos[0];
  double *pt3 = &bodyforce[0];
  double *pt4 = &phaseindex[0];
  int numpair = lbsy.nf*(lbsy.nf-1)/2;
  int qdim = lbsy.nf+lbsy.nc+lbsy.nt;

  // collision of achromatic fluid

  allmass = 0.0;
  omegatot = 0.0;
  density = 0.0;

  for(int j=0; j<lbsy.nf; j++) {
    allmass += rho[j];
    omegatot += omega[j] * rho[j];
    density += lbincp[j] * rho[j];
  }

  invallmass = fReciprocal(allmass);
  omegatot *= invallmass;
  density += invallmass;

  for(int i=0; i<lbsy.nq; i++) {
    lbfac[i] = 0.0;
    for(int j=0; j<lbsy.nf; j++) {
      lbfac[i] += pt2[i*qdim+j];
      seg[i*lbsy.nf+j] = 0.0;
    }
  }

  // calculate segregation terms

  for(int k=0; k<numpair; k++) {
    int i = lbspair[2*k  ];
    int j = lbspair[2*k+1];
    nx = pt4[3*k  ];
    ny = pt4[3*k+1];
    nz = pt4[3*k+2];
    segpiece = lbseg[lbsy.nf*j+i] * rho[i] * rho[j] * invallmass * invallmass;
    for(int m=0; m<lbsy.nq; m++) {
      segcomp = segpiece * (lbvwx[m]*nx + lbvwy[m]*ny + lbvwz[m]*nz);
      seg[m*lbsy.nf+i] += segcomp;
      seg[m*lbsy.nf+j] -= segcomp;
    }
  }

  // collide and segregate fluids
    
  invdensity = fReciprocal(density);
  force[0] = pt3[0];
  force[1] = pt3[1];
  force[2] = pt3[2];
  speed[0] = sitespeed[0] + 0.5 * force[0] * invdensity;
  speed[1] = sitespeed[1] + 0.5 * force[1] * invdensity;
  speed[2] = sitespeed[2] + 0.5 * force[2] * invdensity;
  modv = speed[0] * speed[0] + speed[1] * speed[1] + speed[2] * speed[2];
  modf = speed[0] * force[0] + speed[1] * force[1] + speed[2] * force[2];
  fGetEquilibriumFIncom(&feq[0], speed, allmass, density);
  relax = 1.0 - omegatot;
  halfrelax = 1.0 - 0.5*omegatot;
  for(int m=0; m<lbsy.nq; m++){
    ex = lbvx[m];
    ey = lbvy[m];
    ez = lbvz[m];
    udot = ex * speed[0] + ey * speed[1] + ez * speed[2];
    fdot = ex * force[0] + ey * force[1] + ez * force[2];
    source = 3.0*(fdot-modf)*(1.0+3.0*udot) + 4.5*fdot*(3.0*udot*udot-modv);
    collpiece = relax * lbfac[m] + halfrelax * lbw[m] * source + lbfeq[m]*omegatot;
    for(int i=0; i<lbsy.nf; i++) {
      pt2[m*qdim+i] = rho[i] * collpiece * invallmass + seg[m*lbsy.nf+i];
    }
  }

  pt2 = NULL;
  pt3 = NULL;
  pt4 = NULL;
  return 0;
}

// Achromatic fluid collisions with local forcing terms and phase segregation

int fSiteFluidCollisionBGKLishchukLocal(double* startpos, double *sitespeed, double *omega, double *rho, double* bodyforce, double* phaseindex, int threed)
{

  // BGK collision of achromatic fluid and D'Ortona segregration 
  // calculate interfacial forcing terms and collisions at grid point:
  // uses BGK single relaxation time

  double speed[3], feq[lbsy.nq];
  double allmass, invallmass, omegatot, ex, ey, ez, nx, ny, nz;
  double forceconst, segpiece, collpiece, segcomp, invmassrelax, relax;
  double seg[lbsy.nf*lbsy.nq], lbfac[lbsy.nq], phaseforce[lbsy.nq];
  double *pt2 = &startpos[0];
  double *pt3 = &bodyforce[0];
  double *pt4 = &phaseindex[0];
  int numpair = lbsy.nf*(lbsy.nf-1)/2;
  int qdim = lbsy.nf+lbsy.nc+lbsy.nt;

  // collision of achromatic fluid

  allmass = 0.0;
  omegatot = 0.0;

  for(int j=0; j<lbsy.nf; j++) {
    allmass += rho[j];
    omegatot += omega[j] * rho[j];
  }

  invallmass = fReciprocal(allmass);
  omegatot *= invallmass;
      
  for(int i=0; i<lbsy.nq; i++) {
    lbfac[i] = 0.0;
    phaseforce[i] = 0.0;
    for(int j=0; j<lbsy.nf; j++) {
      lbfac[i] += pt2[i*qdim+j];
      seg[i*lbsy.nf+j] = 0.0;
    }
  }

  // calculate local forcing and segregation terms

  for(int k=0; k<numpair; k++) {
    int i = lbspair[2*k  ];
    int j = lbspair[2*k+1];
    nx = pt4[3*k  ];
    ny = pt4[3*k+1];
    nz = pt4[3*k+2];
    forceconst = lbseg[lbsy.nf*j+i] * lbg[lbsy.nf*j+i] * rho[i] * rho[j];
    segpiece = lbseg[lbsy.nf*j+i] * rho[i] * rho[j] * invallmass * invallmass;
    for(int m=0; m<lbsy.nq; m++) {
      ex = lbvx[m];
      ey = lbvy[m];
      ez = lbvz[m];
      phaseforce[m] += forceconst * ((nx*nx-1.0)*(ex*ex-lbcssq) + (ny*ny-1.0)*(ey*ey-lbcssq) + 2.0*nx*ny*ex*ey
                     + threed*((nz*nz-1.0)*(ez*ez-lbcssq) + 2.0*nz*ez*(nx*ex+ny*ey)));
      segcomp = segpiece * (lbvwx[m]*nx + lbvwy[m]*ny + lbvwz[m]*nz);
      seg[m*lbsy.nf+i] += segcomp;
      seg[m*lbsy.nf+j] -= segcomp;
    }
  }

  // collide and segregate fluids
    
  invmassrelax = invallmass * fReciprocal(omegatot);
  relax = 1.0 - omegatot;
  forceconst = omegatot * invallmass * invallmass * invallmass * lbrcssq * lbrcssq;
  speed[0] = sitespeed[0] + pt3[0] * invmassrelax;
  speed[1] = sitespeed[1] + pt3[1] * invmassrelax;
  speed[2] = sitespeed[2] + pt3[2] * invmassrelax;
  fGetEquilibriumF(&feq[0], speed, allmass);
  for(int m=0; m<lbsy.nq; m++){
    collpiece = relax * lbfac[m] + feq[m]*omegatot + lbw[m]*forceconst*phaseforce[m];
    for(int i=0; i<lbsy.nf; i++) {
      pt2[m*qdim+i] = rho[i] * collpiece * invallmass + seg[m*lbsy.nf+i];
    }
  }

  pt2 = NULL;
  pt3 = NULL;  
  pt4 = NULL;  
  return 0;
}

int fSiteFluidIncomCollisionBGKLishchukLocal(double* startpos, double *sitespeed, double *omega, double *rho, double* bodyforce, double* phaseindex, int threed)
{

  // BGK collision of achromatic fluid and D'Ortona segregration 
  // calculate interfacial forcing terms and collisions at grid point:
  // uses BGK single relaxation time with incompressible fluids

  double speed[3], feq[lbsy.nq];
  double allmass, invallmass, invmassrelax, relax, density, omegatot;
  double forceconst, ex, ey, ez, nx, ny, nz, segcomp, segpiece, collpiece;
  double seg[lbsy.nf*lbsy.nq], lbfac[lbsy.nq], phaseforce[lbsy.nq];
  double *pt2 = &startpos[0];
  double *pt3 = &bodyforce[0];
  double *pt4 = &phaseindex[0];
  int numpair = lbsy.nf*(lbsy.nf-1)/2;
  int qdim = lbsy.nf+lbsy.nc+lbsy.nt;

  // collision of achromatic fluid

  allmass = 0.0;
  omegatot = 0.0;
  density = 0.0;

  for(int j=0; j<lbsy.nf; j++) {
    allmass += rho[j];
    omegatot += omega[j] * rho[j];
    density += lbincp[j] * rho[j];
  }

  invallmass = fReciprocal(allmass);
  omegatot *= invallmass;
  density *= invallmass;

  for(int i=0; i<lbsy.nq; i++) {
    lbfac[i] = 0.0;
    phaseforce[i] = 0.0;
    for(int j=0; j<lbsy.nf; j++) {
      lbfac[i] += pt2[i*qdim+j];
      seg[i*lbsy.nf+j] = 0.0;
    }
  }

  // calculate local forcing and segregation terms

  for(int k=0; k<numpair; k++) {
    int i = lbspair[2*k  ];
    int j = lbspair[2*k+1];
    nx = pt4[3*k  ];
    ny = pt4[3*k+1];
    nz = pt4[3*k+2];
    forceconst = lbseg[lbsy.nf*j+i] * lbg[lbsy.nf*j+i] * rho[i] * rho[j];
    segpiece = lbseg[lbsy.nf*j+i] * rho[i] * rho[j] * invallmass * invallmass;
    for(int m=0; m<lbsy.nq; m++) {
      ex = lbvx[m];
      ey = lbvy[m];
      ez = lbvz[m];
      phaseforce[m] += forceconst * ((nx*nx-1.0)*(ex*ex-lbcssq) + (ny*ny-1.0)*(ey*ey-lbcssq) + 2.0*nx*ny*ex*ey
                     + threed*((nz*nz-1.0)*(ez*ez-lbcssq) + 2.0*nz*ez*(nx*ex+ny*ey)));
      segcomp = segpiece * (lbvwx[m]*nx + lbvwy[m]*ny + lbvwz[m]*nz);
      seg[m*lbsy.nf+i] += segcomp;
      seg[m*lbsy.nf+j] -= segcomp;
    }
  }

  // collide and segregate fluids
    
  invmassrelax = fReciprocal(omegatot*density);
  relax = 1.0 - omegatot;
  forceconst = omegatot * invallmass * invallmass * lbrcssq * lbrcssq * fReciprocal(density);
  speed[0] = sitespeed[0] + pt3[0] * invmassrelax;
  speed[1] = sitespeed[1] + pt3[1] * invmassrelax;
  speed[2] = sitespeed[2] + pt3[2] * invmassrelax;
  fGetEquilibriumFIncom(&feq[0], speed, allmass, density);
  for(int m=0; m<lbsy.nq; m++){
    collpiece = relax * lbfac[m] + feq[m]*omegatot + lbw[m]*forceconst*phaseforce[m];
    for(int i=0; i<lbsy.nf; i++) {
      pt2[m*qdim+i] = rho[i] * collpiece * invallmass + seg[m*lbsy.nf+i];
    }
  }

  pt2 = NULL;
  pt3 = NULL;  
  pt4 = NULL;  
  return 0;
}

int fSiteFluidCollisionBGKEDMLishchukLocal(double* startpos, double *sitespeed, double *omega, double *rho, double* bodyforce, double* phaseindex, int threed)
{

  // BGK collision of achromatic fluid and D'Ortona segregration 
  // calculate interfacial forcing terms and collisions at grid point:
  // uses BGK single relaxation time with Exact Difference Method forcing term

  double dv[3], feq[lbsy.nq];
  double allmass, invallmass, omegatot, forceconst, ex, ey, ez, nx, ny, nz, segpiece, collpiece, segcomp, relax, source;
  double modv,eixux,eiyuy,eizuz,eixdux,eiyduy,eizduz;
  double seg[lbsy.nf*lbsy.nq], lbfac[lbsy.nq], phaseforce[lbsy.nq];
  double *pt2 = &startpos[0];
  double *pt3 = &bodyforce[0];
  double *pt4 = &phaseindex[0];
  int numpair = lbsy.nf*(lbsy.nf-1)/2;
  int qdim = lbsy.nf+lbsy.nc+lbsy.nt;

  // collision of achromatic fluid

  allmass = 0.0;
  omegatot = 0.0;

  for(int j=0; j<lbsy.nf; j++) {
    allmass += rho[j];
    omegatot += omega[j] * rho[j];
  }

  invallmass = fReciprocal(allmass);
  omegatot *= invallmass;
      
  for(int i=0; i<lbsy.nq; i++) {
    lbfac[i] = 0.0;
    phaseforce[i] = 0.0;
    for(int j=0; j<lbsy.nf; j++) {
      lbfac[i] += pt2[i*qdim+j];
      seg[i*lbsy.nf+j] = 0.0;
    }
  }

  // calculate local forcing and segregation terms

  for(int k=0; k<numpair; k++) {
    int i = lbspair[2*k  ];
    int j = lbspair[2*k+1];
    nx = pt4[3*k  ];
    ny = pt4[3*k+1];
    nz = pt4[3*k+2];
    forceconst = lbseg[lbsy.nf*j+i] * lbg[lbsy.nf*j+i] * rho[i] * rho[j];
    segpiece = lbseg[lbsy.nf*j+i] * rho[i] * rho[j] * invallmass * invallmass;
    for(int m=0; m<lbsy.nq; m++) {
      ex = lbvx[m];
      ey = lbvy[m];
      ez = lbvz[m];
      phaseforce[m] += forceconst * ((nx*nx-1.0)*(ex*ex-lbcssq) + (ny*ny-1.0)*(ey*ey-lbcssq) + 2.0*nx*ny*ex*ey
                     + threed*((nz*nz-1.0)*(ez*ez-lbcssq) + 2.0*nz*ez*(nx*ex+ny*ey)));
      segcomp = segpiece * (lbvwx[m]*nx + lbvwy[m]*ny + lbvwz[m]*nz);
      seg[m*lbsy.nf+i] += segcomp;
      seg[m*lbsy.nf+j] -= segcomp;
    }
  }

  // collide and segregate fluids

  relax = 1.0 - omegatot;
  dv[0] = pt3[0] * invallmass;
  dv[1] = pt3[1] * invallmass;
  dv[2] = pt3[2] * invallmass;
  forceconst = omegatot * invallmass * invallmass * invallmass * lbrcssq * lbrcssq;
  fGetEquilibriumF(&feq[0], sitespeed, allmass);
  modv = dv[0]*(2.0*sitespeed[0]+dv[0]) + dv[1]*(2.0*sitespeed[1]+dv[1]) + dv[2]*(2.0*sitespeed[2]+dv[2]);
  for(int m=0; m<lbsy.nq; m++){
    eixux =  lbvx[m]*sitespeed[0];
    eiyuy =  lbvy[m]*sitespeed[1];
    eizuz =  lbvz[m]*sitespeed[2];
    eixdux = lbvx[m]*dv[0];
    eiyduy = lbvy[m]*dv[1];
    eizduz = lbvz[m]*dv[2];
    source = allmass * lbw[m] * (3.0 * (eixdux+eiyduy+eizduz) +
                                 4.5 * (eixdux*(eixdux+2.0*(eixux+eiyuy+eizuz+eiyduy+eizduz)) +
                                        eiyduy*(eiyduy+2.0*(eixux+eiyuy+eizuz+eizduz)) +
                                        eizduz*(eizduz+2.0*(eixux+eiyuy+eizuz))) -
                                 1.5 * modv);
    collpiece = relax * lbfac[m] + source + feq[m]*omegatot + lbw[m]*forceconst*phaseforce[m];
    for(int i=0; i<lbsy.nf; i++) {
      pt2[m*qdim+i] = rho[i] * collpiece * invallmass + seg[m*lbsy.nf+i];
    }
  }

  pt2 = NULL;
  pt3 = NULL;  
  pt4 = NULL;  
  return 0;
}

int fSiteFluidIncomCollisionBGKEDMLishchukLocal(double* startpos, double *sitespeed, double *omega, double *rho, double* bodyforce, double* phaseindex, int threed)
{

  // BGK collision of achromatic fluid and D'Ortona segregration 
  // calculate interfacial forcing terms and collisions at grid point:
  // uses BGK single relaxation time with incompressible fluids and
  // Exact Difference Method forcing term

  double dv[3], feq[lbsy.nq];
  double allmass, invallmass, invmass, relax, density, omegatot, source;
  double forceconst, ex, ey, ez, nx, ny, nz, segcomp, segpiece, collpiece;
  double modv,eixux,eiyuy,eizuz,eixdux,eiyduy,eizduz;
  double seg[lbsy.nf*lbsy.nq], lbfac[lbsy.nq], phaseforce[lbsy.nq];
  double *pt2 = &startpos[0];
  double *pt3 = &bodyforce[0];
  double *pt4 = &phaseindex[0];
  int numpair = lbsy.nf*(lbsy.nf-1)/2;
  int qdim = lbsy.nf+lbsy.nc+lbsy.nt;

  // collision of achromatic fluid

  allmass = 0.0;
  omegatot = 0.0;
  density = 0.0;

  for(int j=0; j<lbsy.nf; j++) {
    allmass += rho[j];
    omegatot += omega[j] * rho[j];
    density += lbincp[j] * rho[j];
  }

  invallmass = fReciprocal(allmass);
  omegatot *= invallmass;
  density *= invallmass;

  for(int i=0; i<lbsy.nq; i++) {
    lbfac[i] = 0.0;
    phaseforce[i] = 0.0;
    for(int j=0; j<lbsy.nf; j++) {
      lbfac[i] += pt2[i*qdim+j];
      seg[i*lbsy.nf+j] = 0.0;
    }
  }

  // calculate local forcing and segregation terms

  for(int k=0; k<numpair; k++) {
    int i = lbspair[2*k  ];
    int j = lbspair[2*k+1];
    nx = pt4[3*k  ];
    ny = pt4[3*k+1];
    nz = pt4[3*k+2];
    forceconst = lbseg[lbsy.nf*j+i] * lbg[lbsy.nf*j+i] * rho[i] * rho[j];
    segpiece = lbseg[lbsy.nf*j+i] * rho[i] * rho[j] * invallmass * invallmass;
    for(int m=0; m<lbsy.nq; m++) {
      ex = lbvx[m];
      ey = lbvy[m];
      ez = lbvz[m];
      phaseforce[m] += forceconst * ((nx*nx-1.0)*(ex*ex-lbcssq) + (ny*ny-1.0)*(ey*ey-lbcssq) + 2.0*nx*ny*ex*ey
                     + threed*((nz*nz-1.0)*(ez*ez-lbcssq) + 2.0*nz*ez*(nx*ex+ny*ey)));
      segcomp = segpiece * (lbvwx[m]*nx + lbvwy[m]*ny + lbvwz[m]*nz);
      seg[m*lbsy.nf+i] += segcomp;
      seg[m*lbsy.nf+j] -= segcomp;
    }
  }

  // collide and segregate fluids
    
  invmass = fReciprocal(density);
  relax = 1.0 - omegatot;
  forceconst = omegatot * invallmass * invallmass * lbrcssq * lbrcssq * invmass;
  dv[0] = pt3[0] * invmass;
  dv[1] = pt3[1] * invmass;
  dv[2] = pt3[2] * invmass;
  fGetEquilibriumFIncom(&feq[0], sitespeed, allmass, density);
  modv = dv[0]*(2.0*sitespeed[0]+dv[0]) + dv[1]*(2.0*sitespeed[1]+dv[1]) + dv[2]*(2.0*sitespeed[2]+dv[2]);
  for(int m=0; m<lbsy.nq; m++){
    eixux =  lbvx[m]*sitespeed[0];
    eiyuy =  lbvy[m]*sitespeed[1];
    eizuz =  lbvz[m]*sitespeed[2];
    eixdux = lbvx[m]*dv[0];
    eiyduy = lbvy[m]*dv[1];
    eizduz = lbvz[m]*dv[2];
    source = density * lbw[m] * (3.0 * (eixdux+eiyduy+eizduz) +
                                 4.5 * (eixdux*(eixdux+2.0*(eixux+eiyuy+eizuz+eiyduy+eizduz)) +
                                        eiyduy*(eiyduy+2.0*(eixux+eiyuy+eizuz+eizduz)) +
                                        eizduz*(eizduz+2.0*(eixux+eiyuy+eizuz))) -
                                 1.5 * modv);
    collpiece = relax * lbfac[m] + source + feq[m]*omegatot + lbw[m]*forceconst*phaseforce[m];
    for(int i=0; i<lbsy.nf; i++) {
      pt2[m*qdim+i] = rho[i] * collpiece * invallmass + seg[m*lbsy.nf+i];
    }
  }

  pt2 = NULL;
  pt3 = NULL;  
  pt4 = NULL;  
  return 0;
}

int fSiteFluidCollisionBGKGuoLishchukLocal(double* startpos, double *sitespeed, double *omega, double *rho, double* bodyforce, double* phaseindex, int threed)
{

  // BGK collision of achromatic fluid and D'Ortona segregration 
  // calculate interfacial forcing terms and collisions at grid point:
  // uses BGK single relaxation time with Guo forcing term

  double speed[3], force[3], feq[lbsy.nq];
  double udot, source, allmass, invallmass, omegatot, nx, ny, nz;
  double forceconst, ex, ey, ez, segcomp, segpiece, collpiece, relax, halfrelax;
  double seg[lbsy.nf*lbsy.nq], lbfac[lbsy.nq], phaseforce[lbsy.nq];
  double *pt2 = &startpos[0];
  double *pt3 = &bodyforce[0];
  double *pt4 = &phaseindex[0];
  int numpair = lbsy.nf*(lbsy.nf-1)/2;
  int qdim = lbsy.nf+lbsy.nc+lbsy.nt;

  // collision of achromatic fluid

  allmass = 0.0;
  omegatot = 0.0;

  for(int j=0; j<lbsy.nf; j++) {
    allmass += rho[j];
    omegatot += omega[j] * rho[j];
  }

  invallmass = fReciprocal(allmass);
  omegatot *= invallmass;
      
  for(int i=0; i<lbsy.nq; i++) {
    lbfac[i] = 0.0;
    phaseforce[i] = 0.0;
    for(int j=0; j<lbsy.nf; j++) {
      lbfac[i] += pt2[i*qdim+j];
      seg[i*lbsy.nf+j] = 0.0;
    }
  }

  // calculate local forcing and segregation terms

  for(int k=0; k<numpair; k++) {
    int i = lbspair[2*k  ];
    int j = lbspair[2*k+1];
    nx = pt4[3*k  ];
    ny = pt4[3*k+1];
    nz = pt4[3*k+2];
    forceconst = lbseg[lbsy.nf*j+i] * lbg[lbsy.nf*j+i] * rho[i] * rho[j];
    segpiece = lbseg[lbsy.nf*j+i] * rho[i] * rho[j] * invallmass * invallmass;
    for(int m=0; m<lbsy.nq; m++) {
      ex = lbvx[m];
      ey = lbvy[m];
      ez = lbvz[m];
      phaseforce[m] += forceconst * ((nx*nx-1.0)*(ex*ex-lbcssq) + (ny*ny-1.0)*(ey*ey-lbcssq) + 2.0*nx*ny*ex*ey
                     + threed*((nz*nz-1.0)*(ez*ez-lbcssq) + 2.0*nz*ez*(nx*ex+ny*ey)));
      segcomp = segpiece * (lbvwx[m]*nx + lbvwy[m]*ny + lbvwz[m]*nz);
      seg[m*lbsy.nf+i] += segcomp;
      seg[m*lbsy.nf+j] -= segcomp;
    }
  }

  // collide and segregate fluids
    
  force[0] = pt3[0];
  force[1] = pt3[1];
  force[2] = pt3[2];
  speed[0] = sitespeed[0] + 0.5 * force[0] * invallmass;
  speed[1] = sitespeed[1] + 0.5 * force[1] * invallmass;
  speed[2] = sitespeed[2] + 0.5 * force[2] * invallmass;
  fGetEquilibriumF(&feq[0], speed, allmass);
  relax = 1.0 - omegatot;
  halfrelax = 1.0 - 0.5*omegatot;
  forceconst = omegatot * invallmass * invallmass * invallmass * lbrcssq * lbrcssq;
  for(int m=0; m<lbsy.nq; m++){
    ex = lbvx[m];
    ey = lbvy[m];
    ez = lbvz[m];
    udot = ex * speed[0] + ey * speed[1] + ez * speed[2];
    source = (3.0*(ex-speed[0]) + 9.0*udot*ex) * force[0]
           + (3.0*(ey-speed[1]) + 9.0*udot*ey) * force[1]
           + (3.0*(ez-speed[2]) + 9.0*udot*ez) * force[2];
    collpiece = relax * lbfac[m] + halfrelax * lbw[m] * source + feq[m]*omegatot + lbw[m]*forceconst*phaseforce[m];
    for(int i=0; i<lbsy.nf; i++) {
      pt2[m*qdim+i] = rho[i] * collpiece * invallmass + seg[m*lbsy.nf+i];
    }
  }

  pt2 = NULL;
  pt3 = NULL;  
  pt4 = NULL;  
  return 0;
}

int fSiteFluidIncomCollisionBGKGuoLishchukLocal(double* startpos, double *sitespeed, double *omega, double *rho, double* bodyforce, double* phaseindex, int threed)
{

  // BGK collision of achromatic fluid and D'Ortona segregration 
  // calculate interfacial forcing terms and collisions at grid point:
  // uses BGK single relaxation time with Guo forcing term for incompressible fluids

  double speed[3], force[3], feq[lbsy.nq];
  double udot, source, allmass, invallmass, density, invdensity, omegatot, nx, ny, nz;
  double forceconst, ex, ey, ez, segcomp, segpiece, collpiece, relax, halfrelax;
  double seg[lbsy.nf*lbsy.nq], lbfac[lbsy.nq], phaseforce[lbsy.nq];
  double *pt2 = &startpos[0];
  double *pt3 = &bodyforce[0];
  double *pt4 = &phaseindex[0];
  int numpair = lbsy.nf*(lbsy.nf-1)/2;
  int qdim = lbsy.nf+lbsy.nc+lbsy.nt;

  // collision of achromatic fluid

  allmass = 0.0;
  omegatot = 0.0;
  density = 0.0;

  for(int j=0; j<lbsy.nf; j++) {
    allmass += rho[j];
    omegatot += omega[j] * rho[j];
    density += lbincp[j] * rho[j];
  }

  invallmass = fReciprocal(allmass);
  omegatot *= invallmass;
  density *= invallmass;

  for(int i=0; i<lbsy.nq; i++) {
    lbfac[i] = 0.0;
    phaseforce[i] = 0.0;
    for(int j=0; j<lbsy.nf; j++) {
      lbfac[i] += pt2[i*qdim+j];
      seg[i*lbsy.nf+j] = 0.0;
    }
  }

  // calculate local forcing and segregation terms

  for(int k=0; k<numpair; k++) {
    int i = lbspair[2*k  ];
    int j = lbspair[2*k+1];
    nx = pt4[3*k  ];
    ny = pt4[3*k+1];
    nz = pt4[3*k+2];
    forceconst = lbseg[lbsy.nf*j+i] * lbg[lbsy.nf*j+i] * rho[i] * rho[j];
    segpiece = lbseg[lbsy.nf*j+i] * rho[i] * rho[j] * invallmass * invallmass;
    for(int m=0; m<lbsy.nq; m++) {
      ex = lbvx[m];
      ey = lbvy[m];
      ez = lbvz[m];
      phaseforce[m] += forceconst * ((nx*nx-1.0)*(ex*ex-lbcssq) + (ny*ny-1.0)*(ey*ey-lbcssq) + 2.0*nx*ny*ex*ey
                     + threed*((nz*nz-1.0)*(ez*ez-lbcssq) + 2.0*nz*ez*(nx*ex+ny*ey)));
      segcomp = segpiece * (lbvwx[m]*nx + lbvwy[m]*ny + lbvwz[m]*nz);
      seg[m*lbsy.nf+i] += segcomp;
      seg[m*lbsy.nf+j] -= segcomp;
    }
  }

  // collide and segregate fluids
    
  invdensity = fReciprocal(density);
  force[0] = pt3[0];
  force[1] = pt3[1];
  force[2] = pt3[2];
  speed[0] = sitespeed[0] + 0.5 * force[0] * invdensity;
  speed[1] = sitespeed[1] + 0.5 * force[1] * invdensity;
  speed[2] = sitespeed[2] + 0.5 * force[2] * invdensity;
  fGetEquilibriumFIncom(&feq[0], speed, allmass, density);
  relax = 1.0 - omegatot;
  halfrelax = 1.0 - 0.5*omegatot;
  forceconst = omegatot * invallmass * invallmass * lbrcssq * lbrcssq * invdensity;
  for(int m=0; m<lbsy.nq; m++){
    ex = lbvx[m];
    ey = lbvy[m];
    ez = lbvz[m];
    udot = ex * speed[0] + ey * speed[1] + ez * speed[2];
    source = (3.0*(ex-speed[0]) + 9.0*udot*ex) * force[0]
           + (3.0*(ey-speed[1]) + 9.0*udot*ey) * force[1]
           + (3.0*(ez-speed[2]) + 9.0*udot*ez) * force[2];
    collpiece = relax * lbfac[m] + halfrelax * lbw[m] * source + lbfeq[m]*omegatot + lbw[m]*forceconst*phaseforce[m];
    for(int i=0; i<lbsy.nf; i++) {
      pt2[m*qdim+i] = rho[i] * collpiece * invallmass + seg[m*lbsy.nf+i];
    }
  }

  pt2 = NULL;
  pt3 = NULL;  
  pt4 = NULL;  
  return 0;
}


int fSiteFluidCollisionBGKHeLishchukLocal(double* startpos, double *sitespeed, double *omega, double *rho, double* bodyforce, double* phaseindex, int threed)
{

  // BGK collision of achromatic fluid and D'Ortona segregration
  // calculate interfacial forcing terms and collisions at grid point:
  // uses BGK single relaxation time with He forcing term

  double speed[3], force[3], feq[lbsy.nq];
  double udot, fdot, modv, modf, source, allmass, invallmass, omegatot, nx, ny, nz;
  double forceconst, ex, ey, ez, segcomp, segpiece, collpiece, relax, halfrelax;
  double seg[lbsy.nf*lbsy.nq], lbfac[lbsy.nq], phaseforce[lbsy.nq];
  double *pt2 = &startpos[0];
  double *pt3 = &bodyforce[0];
  double *pt4 = &phaseindex[0];
  int numpair = lbsy.nf*(lbsy.nf-1)/2;
  int qdim = lbsy.nf+lbsy.nc+lbsy.nt;

  // collision of achromatic fluid

  allmass = 0.0;
  omegatot = 0.0;

  for(int j=0; j<lbsy.nf; j++) {
    allmass += rho[j];
    omegatot += omega[j] * rho[j];
  }

  invallmass = fReciprocal(allmass);
  omegatot *= invallmass;
    
  for(int i=0; i<lbsy.nq; i++) {
    lbfac[i] = 0.0;
    phaseforce[i] = 0.0;
    for(int j=0; j<lbsy.nf; j++) {
      lbfac[i] += pt2[i*qdim+j];
      seg[i*lbsy.nf+j] = 0.0;
    }
  }

  // calculate local forcing and segregation terms

  for(int k=0; k<numpair; k++) {
    int i = lbspair[2*k  ];
    int j = lbspair[2*k+1];
    nx = pt4[3*k  ];
    ny = pt4[3*k+1];
    nz = pt4[3*k+2];
    forceconst = lbseg[lbsy.nf*j+i] * lbg[lbsy.nf*j+i] * rho[i] * rho[j];
    segpiece = lbseg[lbsy.nf*j+i] * rho[i] * rho[j] * invallmass * invallmass;
    for(int m=0; m<lbsy.nq; m++) {
      ex = lbvx[m];
      ey = lbvy[m];
      ez = lbvz[m];
      phaseforce[m] += forceconst * ((nx*nx-1.0)*(ex*ex-lbcssq) + (ny*ny-1.0)*(ey*ey-lbcssq) + 2.0*nx*ny*ex*ey
                     + threed*((nz*nz-1.0)*(ez*ez-lbcssq) + 2.0*nz*ez*(nx*ex+ny*ey)));
      segcomp = segpiece * (lbvwx[m]*nx + lbvwy[m]*ny + lbvwz[m]*nz);
      seg[m*lbsy.nf+i] += segcomp;
      seg[m*lbsy.nf+j] -= segcomp;
    }
  }

  // collide and segregate fluids
    
  force[0] = pt3[0];
  force[1] = pt3[1];
  force[2] = pt3[2];
  speed[0] = sitespeed[0] + 0.5 * force[0] * invallmass;
  speed[1] = sitespeed[1] + 0.5 * force[1] * invallmass;
  speed[2] = sitespeed[2] + 0.5 * force[2] * invallmass;
  modv = speed[0] * speed[0] + speed[1] * speed[1] + speed[2] * speed[2];
  modf = speed[0] * force[0] + speed[1] * force[1] + speed[2] * force[2];
  fGetEquilibriumF(&feq[0], speed, allmass);
  relax = 1.0 - omegatot;
  halfrelax = 1.0 - 0.5*omegatot;
  forceconst = omegatot * invallmass * invallmass * invallmass * lbrcssq * lbrcssq;
  for(int m=0; m<lbsy.nq; m++){
    ex = lbvx[m];
    ey = lbvy[m];
    ez = lbvz[m];
    udot = ex * speed[0] + ey * speed[1] + ez * speed[2];
    fdot = ex * force[0] + ey * force[1] + ez * force[2];
    source = 3.0*(fdot-modf)*(1.0+3.0*udot) + 4.5*fdot*(3.0*udot*udot-modv);
    collpiece = relax * lbfac[m] + halfrelax * lbw[m] * source + feq[m]*omegatot + lbw[m]*forceconst*phaseforce[m];
    for(int i=0; i<lbsy.nf; i++) {
      pt2[m*qdim+i] = rho[i] * collpiece * invallmass + seg[m*lbsy.nf+i];
    }
  }

  pt2 = NULL;
  pt3 = NULL;
  pt4 = NULL;
  return 0;
}

int fSiteFluidIncomCollisionBGKHeLishchukLocal(double* startpos, double *sitespeed, double *omega, double *rho, double* bodyforce, double* phaseindex, int threed)
{

  // BGK collision of achromatic fluid and D'Ortona segregration
  // calculate interfacial forcing terms and collisions at grid point:
  // uses BGK single relaxation time with He forcing term for incompressible fluids

  double speed[3], force[3], feq[lbsy.nq];
  double udot, fdot, modv, modf, source, allmass, invallmass, density, invdensity, omegatot, nx, ny, nz;
  double forceconst, ex, ey, ez, segcomp, segpiece, collpiece, relax, halfrelax;
  double seg[lbsy.nf*lbsy.nq], lbfac[lbsy.nq], phaseforce[lbsy.nq];
  double *pt2 = &startpos[0];
  double *pt3 = &bodyforce[0];
  double *pt4 = &phaseindex[0];
  int numpair = lbsy.nf*(lbsy.nf-1)/2;
  int qdim = lbsy.nf+lbsy.nc+lbsy.nt;

  // collision of achromatic fluid

  allmass = 0.0;
  omegatot = 0.0;
  density = 0.0;

  for(int j=0; j<lbsy.nf; j++) {
    allmass += rho[j];
    omegatot += omega[j] * rho[j];
    density += lbincp[j] * rho[j];
  }

  invallmass = fReciprocal(allmass);
  omegatot *= invallmass;
  density *= invallmass;

  for(int i=0; i<lbsy.nq; i++) {
    lbfac[i] = 0.0;
    phaseforce[i] = 0.0;
    for(int j=0; j<lbsy.nf; j++) {
      lbfac[i] += pt2[i*qdim+j];
      seg[i*lbsy.nf+j] = 0.0;
    }
  }

  // calculate local forcing and segregation terms

  for(int k=0; k<numpair; k++) {
    int i = lbspair[2*k  ];
    int j = lbspair[2*k+1];
    nx = pt4[3*k  ];
    ny = pt4[3*k+1];
    nz = pt4[3*k+2];
    forceconst = lbseg[lbsy.nf*j+i] * lbg[lbsy.nf*j+i] * rho[i] * rho[j];
    segpiece = lbseg[lbsy.nf*j+i] * rho[i] * rho[j] * invallmass * invallmass;
    for(int m=0; m<lbsy.nq; m++) {
      ex = lbvx[m];
      ey = lbvy[m];
      ez = lbvz[m];
      phaseforce[m] += forceconst * ((nx*nx-1.0)*(ex*ex-lbcssq) + (ny*ny-1.0)*(ey*ey-lbcssq) + 2.0*nx*ny*ex*ey
                     + threed*((nz*nz-1.0)*(ez*ez-lbcssq) + 2.0*nz*ez*(nx*ex+ny*ey)));
      segcomp = segpiece * (lbvwx[m]*nx + lbvwy[m]*ny + lbvwz[m]*nz);
      seg[m*lbsy.nf+i] += segcomp;
      seg[m*lbsy.nf+j] -= segcomp;
    }
  }

  // collide and segregate fluids
    
  invdensity = fReciprocal(density);
  force[0] = pt3[0];
  force[1] = pt3[1];
  force[2] = pt3[2];
  speed[0] = sitespeed[0] + 0.5 * force[0] * invdensity;
  speed[1] = sitespeed[1] + 0.5 * force[1] * invdensity;
  speed[2] = sitespeed[2] + 0.5 * force[2] * invdensity;
  modv = speed[0] * speed[0] + speed[1] * speed[1] + speed[2] * speed[2];
  modf = speed[0] * force[0] + speed[1] * force[1] + speed[2] * force[2];
  fGetEquilibriumFIncom(&feq[0], speed, allmass, density);
  relax = 1.0 - omegatot;
  halfrelax = 1.0 - 0.5*omegatot;
  forceconst = omegatot * invallmass * invallmass * lbrcssq * lbrcssq * invdensity;
  for(int m=0; m<lbsy.nq; m++){
    ex = lbvx[m];
    ey = lbvy[m];
    ez = lbvz[m];
    udot = ex * speed[0] + ey * speed[1] + ez * speed[2];
    fdot = ex * force[0] + ey * force[1] + ez * force[2];
    source = 3.0*(fdot-modf)*(1.0+3.0*udot) + 4.5*fdot*(3.0*udot*udot-modv);
    collpiece = relax * lbfac[m] + halfrelax * lbw[m] * source + lbfeq[m]*omegatot + lbw[m]*forceconst*phaseforce[m];
    for(int i=0; i<lbsy.nf; i++) {
      pt2[m*qdim+i] = rho[i] * collpiece * invallmass + seg[m*lbsy.nf+i];
    }
  }

  pt2 = NULL;
  pt3 = NULL;
  pt4 = NULL;
  return 0;
}


// Swift free-energy fluid collisions

int fSiteFluidCollisionBGKSwiftOneFluid(double* startpos, double *sitespeed, double *omega, double *rho, double* gradient, double* bodyforce, double T)
{
  
  // calculate fluid collisions at grid point: uses BGK single relaxation time
  // and Swift free-energy interactions for one fluid

  double speed[3], feq[lbsy.nq];
  double invmassrelax, relax, pb, lambda;
  double *pt2 = &startpos[0];
  double *pt3 = &gradient[0];
  double *pt4 = &bodyforce[0];
  int qdim = lbsy.nf+lbsy.nc+lbsy.nt;
    
  pb = fGetBulkPressureSwift(rho[0], 0.0, T);
  lambda = fGetLambdaSwift(rho[0], omega[0], T);
  relax = 1.0 - omega[0];
  invmassrelax = fReciprocal(rho[0]*omega[0]);
  speed[0] = sitespeed[0] + pt4[0] * invmassrelax;
  speed[1] = sitespeed[1] + pt4[1] * invmassrelax;
  speed[2] = sitespeed[2] + pt4[2] * invmassrelax;
  fGetEquilibriumFSwiftOneFluid(feq, speed, rho[0], pb, lambda, pt3);
  for(int i=0; i<lbsy.nq; i++){
    pt2[i*qdim] = relax * pt2[i*qdim] + feq[i]*omega[0];
  }

  pt2 = NULL;
  pt3 = NULL;
  pt4 = NULL;
  return 0;
}

int fSiteFluidCollisionBGKSwiftTwoFluid(double* startpos, double *sitespeed, double *omega, double *rho, double* gradient, double* bodyforce, double T)
{
  
  // calculate fluid collisions at grid point: uses BGK single relaxation time
  // and Swift free-energy interactions for one fluids

  double speed[3], feq[2*lbsy.nq];
  double omegatot, invmassrelax, relax, relaxphi, pb, mu, lambda;
  double *pt2 = &startpos[0];
  double *pt3 = &gradient[0];
  double *pt4 = &bodyforce[0];
  int qdim = lbsy.nf+lbsy.nc+lbsy.nt;
    
  omegatot = 2.0*omega[0]*omega[1]/(2.0*omega[0]+(1.0+rho[1])*(omega[1]-omega[0]));
  pb = fGetBulkPressureSwift(rho[0], rho[1], T);
  lambda = fGetLambdaSwift(rho[0], omegatot, T);
  mu = fGetPotentialSwift(rho[1], pt3[7]);
  relax = 1.0 - omegatot;
  relaxphi = 1.0 - lbtmob;
  invmassrelax = fReciprocal(rho[0]*omegatot);
  speed[0] = sitespeed[0] + pt4[0] * invmassrelax;
  speed[1] = sitespeed[1] + pt4[1] * invmassrelax;
  speed[2] = sitespeed[2] + pt4[2] * invmassrelax;
  fGetEquilibriumFSwiftTwoFluid(feq, speed, rho[0], rho[1], pb, mu, lambda, pt3);
  for(int i=0; i<lbsy.nq; i++){
    pt2[i*qdim  ] = relax    * pt2[i*qdim  ] + feq[2*i  ]*omegatot;
    pt2[i*qdim+1] = relaxphi * pt2[i*qdim+1] + feq[2*i+1]*lbtmob;
  }

  pt2 = NULL;
  pt3 = NULL;
  pt4 = NULL;
  return 0;
}

int fSiteFluidCollisionBGKEDMSwiftOneFluid(double* startpos, double *sitespeed, double *omega, double *rho, double* gradient, double* bodyforce, double T)
{
  
  // calculate fluid collisions at grid point: uses BGK single relaxation time with
  // Exact Difference Method forcing term and Swift free-energy interactions for one fluid

  double dv[3], feq[lbsy.nq];
  double invmass, relax, pb, lambda, source;
  double modv,eixux,eiyuy,eizuz,eixdux,eiyduy,eizduz;
  double *pt2 = &startpos[0];
  double *pt3 = &gradient[0];
  double *pt4 = &bodyforce[0];
  int qdim = lbsy.nf+lbsy.nc+lbsy.nt;

  pb = fGetBulkPressureSwift(rho[0], 0.0, T);
  lambda = fGetLambdaSwift(rho[0], omega[0], T);
  invmass = fReciprocal(rho[0]);
  dv[0] = pt4[0] * invmass;
  dv[1] = pt4[1] * invmass;
  dv[2] = pt4[2] * invmass;
  fGetEquilibriumFSwiftOneFluid(feq, sitespeed, rho[0], pb, lambda, pt3);
  relax = 1.0 - omega[0];
  modv = dv[0]*(2.0*sitespeed[0]+dv[0]) + dv[1]*(2.0*sitespeed[1]+dv[1]) + dv[2]*(2.0*sitespeed[2]+dv[2]);
  for(int i=0; i<lbsy.nq; i++){
    eixux =  lbvx[i]*sitespeed[0];
    eiyuy =  lbvy[i]*sitespeed[1];
    eizuz =  lbvz[i]*sitespeed[2];
    eixdux = lbvx[i]*dv[0];
    eiyduy = lbvy[i]*dv[1];
    eizduz = lbvz[i]*dv[2];
    source = rho[0] * lbw[i] * (3.0 * (eixdux+eiyduy+eizduz) +
                                4.5 * (eixdux*(eixdux+2.0*(eixux+eiyuy+eizuz+eiyduy+eizduz)) +
                                       eiyduy*(eiyduy+2.0*(eixux+eiyuy+eizuz+eizduz)) +
                                       eizduz*(eizduz+2.0*(eixux+eiyuy+eizuz))) -
                                1.5 * modv);
    pt2[i*qdim] = relax * pt2[i*qdim] + source + feq[i]*omega[0];
  }

  pt2 = NULL;
  pt3 = NULL;
  pt4 = NULL;
  return 0;
}

int fSiteFluidCollisionBGKEDMSwiftTwoFluid(double* startpos, double *sitespeed, double *omega, double *rho, double* gradient, double* bodyforce, double T)
{
  
  // calculate fluid collisions at grid point: uses BGK single relaxation time with
  // Exact Difference Method forcing term and Swift free-energy interactions for two fluids

  double dv[3], feq[2*lbsy.nq];
  double omegatot, invmass, relax, relaxphi, pb, mu, lambda, source;
  double modv,eixux,eiyuy,eizuz,eixdux,eiyduy,eizduz;
  double *pt2 = &startpos[0];
  double *pt3 = &gradient[0];
  double *pt4 = &bodyforce[0];
  int qdim = lbsy.nf+lbsy.nc+lbsy.nt;

  omegatot = 2.0*omega[0]*omega[1]/(2.0*omega[0]+(1.0+rho[1])*(omega[1]-omega[0]));
  pb = fGetBulkPressureSwift(rho[0], rho[1], T);
  lambda = fGetLambdaSwift(rho[0], omegatot, T);
  mu = fGetPotentialSwift(rho[1], pt3[7]);
  relax = 1.0 - omegatot;
  relaxphi = 1.0 - lbtmob;
  invmass = fReciprocal(rho[0]);
  dv[0] = pt4[0] * invmass;
  dv[1] = pt4[1] * invmass;
  dv[2] = pt4[2] * invmass;
  fGetEquilibriumFSwiftTwoFluid(feq, sitespeed, rho[0], rho[1], pb, mu, lambda, pt3);
  modv = dv[0]*(2.0*sitespeed[0]+dv[0]) + dv[1]*(2.0*sitespeed[1]+dv[1]) + dv[2]*(2.0*sitespeed[2]+dv[2]);
  for(int i=0; i<lbsy.nq; i++){
    eixux =  lbvx[i]*sitespeed[0];
    eiyuy =  lbvy[i]*sitespeed[1];
    eizuz =  lbvz[i]*sitespeed[2];
    eixdux = lbvx[i]*dv[0];
    eiyduy = lbvy[i]*dv[1];
    eizduz = lbvz[i]*dv[2];
    source = rho[0] * lbw[i] * (3.0 * (eixdux+eiyduy+eizduz) +
                                4.5 * (eixdux*(eixdux+2.0*(eixux+eiyuy+eizuz+eiyduy+eizduz)) +
                                       eiyduy*(eiyduy+2.0*(eixux+eiyuy+eizuz+eizduz)) +
                                       eizduz*(eizduz+2.0*(eixux+eiyuy+eizuz))) -
                                1.5 * modv);
    pt2[i*qdim  ] = relax    * pt2[i*qdim  ] + feq[2*i  ]*omegatot + source;
    pt2[i*qdim+1] = relaxphi * pt2[i*qdim+1] + feq[2*i+1]*lbtmob;
  }

  pt2 = NULL;
  pt3 = NULL;
  pt4 = NULL;
  return 0;
}

int fSiteFluidCollisionBGKGuoSwiftOneFluid(double* startpos, double *sitespeed, double *omega, double *rho, double* gradient, double* bodyforce, double T)
{
  
  // calculate fluid collisions at grid point: uses BGK single relaxation time with
  // Guo forcing term and Swift free-energy interactions for one fluid

  double speed[3], force[3], feq[lbsy.nq];
  double udot, source, invmass, relax, halfrelax, ex, ey, ez, pb, lambda;
  double *pt2 = &startpos[0];
  double *pt3 = &gradient[0];
  double *pt4 = &bodyforce[0];
  int qdim = lbsy.nf+lbsy.nc+lbsy.nt;

  pb = fGetBulkPressureSwift(rho[0], 0.0, T);
  lambda = fGetLambdaSwift(rho[0], omega[0], T);
  invmass = fReciprocal(rho[0]);
  force[0] = pt4[0];
  force[1] = pt4[1];
  force[2] = pt4[2];
  speed[0] = sitespeed[0] + 0.5 * force[0] * invmass;
  speed[1] = sitespeed[1] + 0.5 * force[1] * invmass;
  speed[2] = sitespeed[2] + 0.5 * force[2] * invmass;
  fGetEquilibriumFSwiftOneFluid(feq, speed, rho[0], pb, lambda, pt3);
  relax = 1.0 - omega[0];
  halfrelax = 1.0 - 0.5*omega[0];
  for(int i=0; i<lbsy.nq; i++){
    ex = lbvx[i];
    ey = lbvy[i];
    ez = lbvz[i];
    udot = ex * speed[0] + ey * speed[1] + ez * speed[2];
    source = (3.0*(ex-speed[0]) + 9.0*udot*ex) * force[0]
           + (3.0*(ey-speed[1]) + 9.0*udot*ey) * force[1]
           + (3.0*(ez-speed[2]) + 9.0*udot*ez) * force[2];
    pt2[i*qdim] = relax * pt2[i*qdim] + halfrelax * lbw[i] * source + feq[i]*omega[0];
  }

  pt2 = NULL;
  pt3 = NULL;
  pt4 = NULL;
  return 0;
}

int fSiteFluidCollisionBGKGuoSwiftTwoFluid(double* startpos, double *sitespeed, double *omega, double *rho, double* gradient, double* bodyforce, double T)
{
  
  // calculate fluid collisions at grid point: uses BGK single relaxation time with
  // Guo forcing term and Swift free-energy interactions for two fluids

  double speed[3], force[3], feq[2*lbsy.nq];
  double omegatot, udot, source, invmass, relax, relaxphi, halfrelax, ex, ey, ez, pb, mu, lambda;
  double *pt2 = &startpos[0];
  double *pt3 = &gradient[0];
  double *pt4 = &bodyforce[0];
  int qdim = lbsy.nf+lbsy.nc+lbsy.nt;

  omegatot = 2.0*omega[0]*omega[1]/(2.0*omega[0]+(1.0+rho[1])*(omega[1]-omega[0]));
  pb = fGetBulkPressureSwift(rho[0], rho[1], T);
  lambda = fGetLambdaSwift(rho[0], omegatot, T);
  mu = fGetPotentialSwift(rho[1], pt3[7]);
  invmass = fReciprocal(rho[0]);
  force[0] = pt4[0];
  force[1] = pt4[1];
  force[2] = pt4[2];
  speed[0] = sitespeed[0] + 0.5 * force[0] * invmass;
  speed[1] = sitespeed[1] + 0.5 * force[1] * invmass;
  speed[2] = sitespeed[2] + 0.5 * force[2] * invmass;
  fGetEquilibriumFSwiftTwoFluid(feq, speed, rho[0], rho[1], pb, mu, lambda, pt3);
  relax = 1.0 - omegatot;
  relaxphi = 1.0 - lbtmob;
  halfrelax = 1.0 - 0.5*omegatot;
  for(int i=0; i<lbsy.nq; i++){
    ex = lbvx[i];
    ey = lbvy[i];
    ez = lbvz[i];
    udot = ex * speed[0] + ey * speed[1] + ez * speed[2];
    source = (3.0*(ex-speed[0]) + 9.0*udot*ex) * force[0]
           + (3.0*(ey-speed[1]) + 9.0*udot*ey) * force[1]
           + (3.0*(ez-speed[2]) + 9.0*udot*ez) * force[2];
    pt2[i*qdim  ] = relax    * pt2[i*qdim  ] + feq[2*i]*omegatot + halfrelax * lbw[i] * source;
    pt2[i*qdim+1] = relaxphi * pt2[i*qdim+1] + feq[2*i+1]*lbtmob;
  }

  pt2 = NULL;
  pt3 = NULL;
  pt4 = NULL;
  return 0;
}


int fSiteFluidCollisionBGKHeSwiftOneFluid(double* startpos, double *sitespeed, double *omega, double *rho, double* gradient, double* bodyforce, double T)
{
  
  // calculate fluid collisions at grid point: uses BGK single relaxation time with
  // He forcing term and Swift free-energy interactions for one fluid

  double speed[3], force[3], feq[lbsy.nq];
  double udot, fdot, modv, modf, source, invmass, relax, halfrelax, ex, ey, ez, pb, lambda;
  double *pt2 = &startpos[0];
  double *pt3 = &gradient[0];
  double *pt4 = &bodyforce[0];
  int qdim = lbsy.nf+lbsy.nc+lbsy.nt;

  pb = fGetBulkPressureSwift(rho[0], 0.0, T);
  lambda = fGetLambdaSwift(rho[0], omega[0], T);
  invmass = fReciprocal(rho[0]);
  force[0] = pt4[0];
  force[1] = pt4[1];
  force[2] = pt4[2];
  speed[0] = sitespeed[0] + 0.5 * force[0] * invmass;
  speed[1] = sitespeed[1] + 0.5 * force[1] * invmass;
  speed[2] = sitespeed[2] + 0.5 * force[2] * invmass;
  modv = speed[0] * speed[0] + speed[1] * speed[1] + speed[2] * speed[2];
  modf = speed[0] * force[0] + speed[1] * force[1] + speed[2] * force[2];
  fGetEquilibriumFSwiftOneFluid(feq, speed, rho[0], pb, lambda, pt3);
  relax = 1.0 - omega[0];
  halfrelax = 1.0 - 0.5*omega[0];
  for(int i=0; i<lbsy.nq; i++){
    ex = lbvx[i];
    ey = lbvy[i];
    ez = lbvz[i];
    udot = ex * speed[0] + ey * speed[1] + ez * speed[2];
    fdot = ex * force[0] + ey * force[1] + ez * force[2];
    source = 3.0*(fdot-modf)*(1.0+3.0*udot) + 4.5*fdot*(3.0*udot*udot-modv);
    pt2[i*qdim] = relax * pt2[i*qdim] + halfrelax * lbw[i] * source + feq[i]*omega[0];
  }

  pt2 = NULL;
  pt3 = NULL;
  pt4 = NULL;
  return 0;
}

int fSiteFluidCollisionBGKHeSwiftTwoFluid(double* startpos, double *sitespeed, double *omega, double *rho, double* gradient, double* bodyforce, double T)
{
  
  // calculate fluid collisions at grid point: uses BGK single relaxation time with
  // He forcing term and Swift free-energy interactions for two fluids

  double speed[3], force[3], feq[2*lbsy.nq];
  double omegatot, udot, fdot, modv, modf, source, invmass, relax, relaxphi, halfrelax, ex, ey, ez, pb, mu, lambda;
  double *pt2 = &startpos[0];
  double *pt3 = &gradient[0];
  double *pt4 = &bodyforce[0];
  int qdim = lbsy.nf+lbsy.nc+lbsy.nt;

  omegatot = 2.0*omega[0]*omega[1]/(2.0*omega[0]+(1.0+rho[1])*(omega[1]-omega[0]));
  pb = fGetBulkPressureSwift(rho[0], rho[1], T);
  lambda = fGetLambdaSwift(rho[0], omegatot, T);
  mu = fGetPotentialSwift(rho[1], pt3[7]);
  invmass = fReciprocal(rho[0]);
  force[0] = pt4[0];
  force[1] = pt4[1];
  force[2] = pt4[2];
  speed[0] = sitespeed[0] + 0.5 * force[0] * invmass;
  speed[1] = sitespeed[1] + 0.5 * force[1] * invmass;
  speed[2] = sitespeed[2] + 0.5 * force[2] * invmass;
  modv = speed[0] * speed[0] + speed[1] * speed[1] + speed[2] * speed[2];
  modf = speed[0] * force[0] + speed[1] * force[1] + speed[2] * force[2];
  fGetEquilibriumFSwiftTwoFluid(feq, speed, rho[0], rho[1], pb, mu, lambda, pt3);
  relax = 1.0 - omegatot;
  relaxphi = 1.0 - lbtmob;
  halfrelax = 1.0 - 0.5*omegatot;
  for(int i=0; i<lbsy.nq; i++){
    ex = lbvx[i];
    ey = lbvy[i];
    ez = lbvz[i];
    udot = ex * speed[0] + ey * speed[1] + ez * speed[2];
    fdot = ex * force[0] + ey * force[1] + ez * force[2];
    source = 3.0*(fdot-modf)*(1.0+3.0*udot) + 4.5*fdot*(3.0*udot*udot-modv);
    pt2[i*qdim  ] = relax    * pt2[i*qdim  ] + feq[2*i]*omegatot + halfrelax * lbw[i] * source;
    pt2[i*qdim+1] = relaxphi * pt2[i*qdim+1] + feq[2*i+1]*lbtmob;
  }

  pt2 = NULL;
  pt3 = NULL;
  pt4 = NULL;
  return 0;
}


// Solute collisions

int fSiteSoluteCollisionBGK(double* startpos, double *sitespeed)
{
  
  // calculate solute collisions at grid point: uses BGK single relaxation time

  double relax;
  double feq[lbsy.nq], rho[lbsy.nc];
  double *pt2 = &startpos[0];
  int qdim = lbsy.nf+lbsy.nc+lbsy.nt;

  fGetAllConcSite(rho, pt2);
    
  for(int j=0; j<lbsy.nc; j++) {
    fGetEquilibriumC(&feq[0], sitespeed, rho[j]);
    relax = 1.0 - lbtc[j];
    for(int i=0; i<lbsy.nq; i++) {
      pt2[i*qdim+j] = relax * pt2[i*qdim+j] + feq[i]*lbtc[j];
    }
  }

  pt2 = NULL;
  return 0;
}

// Thermal collisions

int fSiteThermalCollisionBGK(double* startpos, double *sitespeed)
{
  
  // calculate thermal collisions at grid point: uses BGK single relaxation time

  double onemass, relax;
  double feq[lbsy.nq];
  double *pt2 = &startpos[0];
  int qdim = lbsy.nf+lbsy.nc+lbsy.nt;

  if(lbsy.nt == 1) {
    onemass = fGetOneMassSite(pt2);    
    fGetEquilibriumT(&feq[0], sitespeed, onemass);
    relax = 1.0 - lbtt[0];
    for(int i=0; i<lbsy.nq; i++) {
      pt2[i*qdim] = relax * pt2[i*qdim] + feq[i]*lbtt[0];
    }
  }

  pt2 = NULL;
  return 0;
}

// Collision loops over all grid points

int fCollisionBGK()
{
  long Tmax = lbdm.touter;
  double freq = (lbbdforcetyp==1)*sin(lboscilfreq*(lbcurstep-lbequstep));

  if(!incompress) {

   #pragma omp parallel
   {
      double interforce_t[3*lbsy.nf], sitespeed_t[3], rho_t[lbsy.nf];
      double *interforce = &interforce_t[0];
      double *sitespeed = &sitespeed_t[0];
      double *rho = &rho_t[0];

      #pragma omp for
      for(long il=0; il<Tmax; il++) {
        if(lbphi[il] != 11) {
        fGetSpeedAllMassSite(sitespeed, rho, &lbf[il*lbsitelength]);
          for(int ll=0; ll<3*lbsy.nf; ll++)
	        interforce[ll] = lbinterforce[il*3*lbsy.nf+ll] + lbheatforce[il*3*lbsy.nf+ll] + postequil*(lbbdforce[ll]+lboscilforce[ll]*freq);
          if(lbphi[il] != 12 && lbphi[il] != 13)
            fSiteFluidCollisionBGK(&lbf[il*lbsitelength], sitespeed, &lbomega[il*lbsy.nf], rho, interforce);
          fSiteSoluteCollisionBGK(&lbf[il*lbsitelength + lbsy.nf], sitespeed);
          fSiteThermalCollisionBGK(&lbf[il*lbsitelength + lbsy.nf+lbsy.nc], sitespeed);
        }
      }
    }
  }
  else {
      
   #pragma omp parallel
   {
      double interforce_t[3*lbsy.nf], sitespeed_t[3], rho_t[lbsy.nf];
      double *interforce = &interforce_t[0];
      double *sitespeed = &sitespeed_t[0];
      double *rho = &rho_t[0];

      #pragma omp for
      for(long il=0; il<Tmax; il++) {
        if(lbphi[il] != 11) {
          fGetSpeedIncomAllMassSite(sitespeed, rho, &lbf[il*lbsitelength]);
          for(int ll=0; ll<3*lbsy.nf; ll++)
	        interforce[ll] = lbinterforce[il*3*lbsy.nf+ll] + lbheatforce[il*3*lbsy.nf+ll] + postequil*(lbbdforce[ll]+lboscilforce[ll]*freq);
          if(lbphi[il] != 12 && lbphi[il] != 13)
            fSiteFluidIncomCollisionBGK(&lbf[il*lbsitelength], sitespeed, &lbomega[il*lbsy.nf], rho, interforce);
          fSiteSoluteCollisionBGK(&lbf[il*lbsitelength + lbsy.nf], sitespeed);
          fSiteThermalCollisionBGK(&lbf[il*lbsitelength + lbsy.nf+lbsy.nc], sitespeed);
        }
      }
    }
  }
  return 0;
}

int fCollisionBGKEDM()
{
  long Tmax = lbdm.touter;
  double freq = (lbbdforcetyp==1)*sin(lboscilfreq*(lbcurstep-lbequstep));

  if(!incompress) {

    #pragma omp parallel
    {
      double interforce_t[3*lbsy.nf], sitespeed_t[3], rho_t[lbsy.nf];
      double *interforce = &interforce_t[0];
      double *sitespeed = &sitespeed_t[0];
      double *rho = &rho_t[0];
        
      #pragma omp for
      for(long il=0; il<Tmax; il++) {
        if(lbphi[il] != 11) {
          fGetSpeedAllMassSite(sitespeed, rho, &lbf[il*lbsitelength]);
          for(int ll=0; ll<3*lbsy.nf; ll++)
	        interforce[ll] = lbinterforce[il*3*lbsy.nf+ll] + lbheatforce[il*3*lbsy.nf+ll] + postequil*(lbbdforce[ll]+lboscilforce[ll]*freq);
          if(lbphi[il] != 12 && lbphi[il] != 13)
            fSiteFluidCollisionBGKEDM(&lbf[il*lbsitelength], sitespeed, &lbomega[il*lbsy.nf], rho, interforce);
          fSiteSoluteCollisionBGK(&lbf[il*lbsitelength + lbsy.nf], sitespeed);
          fSiteThermalCollisionBGK(&lbf[il*lbsitelength + lbsy.nf+lbsy.nc], sitespeed);
        }
      }
    }
  }
  else {

    #pragma omp parallel
    {
      double interforce_t[3*lbsy.nf], sitespeed_t[3], rho_t[lbsy.nf];
      double *interforce = &interforce_t[0];
      double *sitespeed = &sitespeed_t[0];
      double *rho = &rho_t[0];
        
      #pragma omp for
      for(long il=0; il<Tmax; il++) {
        if(lbphi[il] != 11) {
          fGetSpeedIncomAllMassSite(sitespeed, rho, &lbf[il*lbsitelength]);
          for(int ll=0; ll<3*lbsy.nf; ll++)
	        interforce[ll] = lbinterforce[il*3*lbsy.nf+ll] + lbheatforce[il*3*lbsy.nf+ll] + postequil*(lbbdforce[ll]+lboscilforce[ll]*freq);
          if(lbphi[il] != 12 && lbphi[il] != 13)
            fSiteFluidIncomCollisionBGKEDM(&lbf[il*lbsitelength], sitespeed, &lbomega[il*lbsy.nf], rho, interforce);
          fSiteSoluteCollisionBGK(&lbf[il*lbsitelength + lbsy.nf], sitespeed);
          fSiteThermalCollisionBGK(&lbf[il*lbsitelength + lbsy.nf+lbsy.nc], sitespeed);
        }
      }
    }
  }
  return 0;
}

int fCollisionBGKGuo()
{
  long Tmax = lbdm.touter;
  double freq = (lbbdforcetyp==1)*sin(lboscilfreq*(lbcurstep-lbequstep));

  if(!incompress) {

    #pragma omp parallel
    {
      double interforce_t[3*lbsy.nf], sitespeed_t[3], rho_t[lbsy.nf];
      double *interforce = &interforce_t[0];
      double *sitespeed = &sitespeed_t[0];
      double *rho = &rho_t[0];
        
      #pragma omp for
      for(long il=0; il<Tmax; il++) {
        if(lbphi[il] != 11) {
          fGetSpeedAllMassSite(sitespeed, rho, &lbf[il*lbsitelength]);
          for(int ll=0; ll<3*lbsy.nf; ll++)
	        interforce[ll] = lbinterforce[il*3*lbsy.nf+ll] + lbheatforce[il*3*lbsy.nf+ll] + postequil*(lbbdforce[ll]+lboscilforce[ll]*freq);
          if(lbphi[il] != 12 && lbphi[il] != 13)
            fSiteFluidCollisionBGKGuo(&lbf[il*lbsitelength], sitespeed, &lbomega[il*lbsy.nf], rho, interforce);
          fSiteSoluteCollisionBGK(&lbf[il*lbsitelength + lbsy.nf], sitespeed);
          fSiteThermalCollisionBGK(&lbf[il*lbsitelength + lbsy.nf+lbsy.nc], sitespeed);
        }
      }
    }
  }
  else {

    #pragma omp parallel
    {
      double interforce_t[3*lbsy.nf], sitespeed_t[3], rho_t[lbsy.nf];
      double *interforce = &interforce_t[0];
      double *sitespeed = &sitespeed_t[0];
      double *rho = &rho_t[0];
        
      #pragma omp for
      for(long il=0; il<Tmax; il++) {
        if(lbphi[il] != 11) {
          fGetSpeedIncomAllMassSite(sitespeed, rho, &lbf[il*lbsitelength]);
          for(int ll=0; ll<3*lbsy.nf; ll++)
	        interforce[ll] = lbinterforce[il*3*lbsy.nf+ll] + lbheatforce[il*3*lbsy.nf+ll] + postequil*(lbbdforce[ll]+lboscilforce[ll]*freq);
          if(lbphi[il] != 12 && lbphi[il] != 13)
            fSiteFluidIncomCollisionBGKGuo(&lbf[il*lbsitelength], sitespeed, &lbomega[il*lbsy.nf], rho, interforce);
          fSiteSoluteCollisionBGK(&lbf[il*lbsitelength + lbsy.nf], sitespeed);
          fSiteThermalCollisionBGK(&lbf[il*lbsitelength + lbsy.nf+lbsy.nc], sitespeed);
        }
      }
    }
  }
  return 0;
}


int fCollisionBGKHe()
{
  long Tmax = lbdm.touter;
  double freq = (lbbdforcetyp==1)*sin(lboscilfreq*(lbcurstep-lbequstep));

  if(!incompress) {

    #pragma omp parallel
    {
      double interforce_t[3*lbsy.nf], sitespeed_t[3], rho_t[lbsy.nf];
      double *interforce = &interforce_t[0];
      double *sitespeed = &sitespeed_t[0];
      double *rho = &rho_t[0];
        
      #pragma omp for
      for(long il=0; il<Tmax; il++) {
        if(lbphi[il] != 11) {
          fGetSpeedAllMassSite(sitespeed, rho, &lbf[il*lbsitelength]);
          for(int ll=0; ll<3*lbsy.nf; ll++)
	        interforce[ll] = lbinterforce[il*3*lbsy.nf+ll] + lbheatforce[il*3*lbsy.nf+ll] + postequil*(lbbdforce[ll]+lboscilforce[ll]*freq);
          if(lbphi[il] != 12 && lbphi[il] != 13)
            fSiteFluidCollisionBGKHe(&lbf[il*lbsitelength], sitespeed, &lbomega[il*lbsy.nf], rho, interforce);
          fSiteSoluteCollisionBGK(&lbf[il*lbsitelength + lbsy.nf], sitespeed);
          fSiteThermalCollisionBGK(&lbf[il*lbsitelength + lbsy.nf+lbsy.nc], sitespeed);
        }
      }
    }
  }
  else {

    #pragma omp parallel
    {
      double interforce_t[3*lbsy.nf], sitespeed_t[3], rho_t[lbsy.nf];
      double *interforce = &interforce_t[0];
      double *sitespeed = &sitespeed_t[0];
      double *rho = &rho_t[0];
        
      #pragma omp for
      for(long il=0; il<Tmax; il++) {
        if(lbphi[il] != 11) {
          fGetSpeedIncomAllMassSite(sitespeed, rho, &lbf[il*lbsitelength]);
          for(int ll=0; ll<3*lbsy.nf; ll++)
	        interforce[ll] = lbinterforce[il*3*lbsy.nf+ll] + lbheatforce[il*3*lbsy.nf+ll] + postequil*(lbbdforce[ll]+lboscilforce[ll]*freq);
          if(lbphi[il] != 12 && lbphi[il] != 13)
            fSiteFluidIncomCollisionBGKHe(&lbf[il*lbsitelength], sitespeed, &lbomega[il*lbsy.nf], rho, interforce);
          fSiteSoluteCollisionBGK(&lbf[il*lbsitelength + lbsy.nf], sitespeed);
          fSiteThermalCollisionBGK(&lbf[il*lbsitelength + lbsy.nf+lbsy.nc], sitespeed);
        }
      }
    }
  }
  return 0;
}


int fCollisionBGKShanChen()
{
  long Tmax = lbdm.touter;
  double freq = (lbbdforcetyp==1)*sin(lboscilfreq*(lbcurstep-lbequstep));

  if(!incompress) {

   #pragma omp parallel
   {
      double interforce_t[3*lbsy.nf], sitespeed_t[3], rho_t[lbsy.nf];
      double *interforce = &interforce_t[0];
      double *sitespeed = &sitespeed_t[0];
      double *rho = &rho_t[0];

      #pragma omp for
      for(long il=0; il<Tmax; il++) {
        if(lbphi[il] != 11) {
          fGetSpeedShanChenAllMassSite(sitespeed, rho, &lbf[il*lbsitelength], &lbomega[il*lbsy.nf]);
          for(int ll=0; ll<3*lbsy.nf; ll++)
	        interforce[ll] = lbinterforce[il*3*lbsy.nf+ll] + lbheatforce[il*3*lbsy.nf+ll] + postequil*(lbbdforce[ll]+lboscilforce[ll]*freq);
          if(lbphi[il] != 12 && lbphi[il] != 13)
            fSiteFluidCollisionBGK(&lbf[il*lbsitelength], sitespeed, &lbomega[il*lbsy.nf], rho, interforce);
          fSiteSoluteCollisionBGK(&lbf[il*lbsitelength + lbsy.nf], sitespeed);
          fSiteThermalCollisionBGK(&lbf[il*lbsitelength + lbsy.nf+lbsy.nc], sitespeed);
        }
      }
    }
  }
  else {
      
   #pragma omp parallel
   {
      double interforce_t[3*lbsy.nf], sitespeed_t[3], rho_t[lbsy.nf];
      double *interforce = &interforce_t[0];
      double *sitespeed = &sitespeed_t[0];
      double *rho = &rho_t[0];

      #pragma omp for
      for(long il=0; il<Tmax; il++) {
        if(lbphi[il] != 11) {
          fGetSpeedShanChenIncomAllMassSite(sitespeed, rho, &lbf[il*lbsitelength], &lbomega[il*lbsy.nf]);
          for(int ll=0; ll<3*lbsy.nf; ll++)
	        interforce[ll] = lbinterforce[il*3*lbsy.nf+ll] + lbheatforce[il*3*lbsy.nf+ll] + postequil*(lbbdforce[ll]+lboscilforce[ll]*freq);
          if(lbphi[il] != 12 && lbphi[il] != 13)
            fSiteFluidIncomCollisionBGK(&lbf[il*lbsitelength], sitespeed, &lbomega[il*lbsy.nf], rho, interforce);
          fSiteSoluteCollisionBGK(&lbf[il*lbsitelength + lbsy.nf], sitespeed);
          fSiteThermalCollisionBGK(&lbf[il*lbsitelength + lbsy.nf+lbsy.nc], sitespeed);
        }
      }
    }
  }
  return 0;
}

int fCollisionBGKEDMShanChen()
{
  long Tmax = lbdm.touter;
  double freq = (lbbdforcetyp==1)*sin(lboscilfreq*(lbcurstep-lbequstep));

  if(!incompress) {

    #pragma omp parallel
    {
      double interforce_t[3*lbsy.nf], sitespeed_t[3], rho_t[lbsy.nf];
      double *interforce = &interforce_t[0];
      double *sitespeed = &sitespeed_t[0];
      double *rho = &rho_t[0];
        
      #pragma omp for
      for(long il=0; il<Tmax; il++) {
        if(lbphi[il] != 11) {
          fGetSpeedShanChenAllMassSite(sitespeed, rho, &lbf[il*lbsitelength], &lbomega[il*lbsy.nf]);
          for(int ll=0; ll<3*lbsy.nf; ll++)
	        interforce[ll] = lbinterforce[il*3*lbsy.nf+ll] + lbheatforce[il*3*lbsy.nf+ll] + postequil*(lbbdforce[ll]+lboscilforce[ll]*freq);
          if(lbphi[il] != 12 && lbphi[il] != 13)
            fSiteFluidCollisionBGKEDM(&lbf[il*lbsitelength], sitespeed, &lbomega[il*lbsy.nf], rho, interforce);
          fSiteSoluteCollisionBGK(&lbf[il*lbsitelength + lbsy.nf], sitespeed);
          fSiteThermalCollisionBGK(&lbf[il*lbsitelength + lbsy.nf+lbsy.nc], sitespeed);
        }
      }
    }
  }
  else {

    #pragma omp parallel
    {
      double interforce_t[3*lbsy.nf], sitespeed_t[3], rho_t[lbsy.nf];
      double *interforce = &interforce_t[0];
      double *sitespeed = &sitespeed_t[0];
      double *rho = &rho_t[0];
        
      #pragma omp for
      for(long il=0; il<Tmax; il++) {
        if(lbphi[il] != 11) {
          fGetSpeedShanChenIncomAllMassSite(sitespeed, rho, &lbf[il*lbsitelength], &lbomega[il*lbsy.nf]);
          for(int ll=0; ll<3*lbsy.nf; ll++)
	        interforce[ll] = lbinterforce[il*3*lbsy.nf+ll] + lbheatforce[il*3*lbsy.nf+ll] + postequil*(lbbdforce[ll]+lboscilforce[ll]*freq);
          if(lbphi[il] != 12 && lbphi[il] != 13)
            fSiteFluidIncomCollisionBGKEDM(&lbf[il*lbsitelength], sitespeed, &lbomega[il*lbsy.nf], rho, interforce);
          fSiteSoluteCollisionBGK(&lbf[il*lbsitelength + lbsy.nf], sitespeed);
          fSiteThermalCollisionBGK(&lbf[il*lbsitelength + lbsy.nf+lbsy.nc], sitespeed);
        }
      }
    }
  }
  return 0;
}

int fCollisionBGKGuoShanChen()
{
  long Tmax = lbdm.touter;
  double freq = (lbbdforcetyp==1)*sin(lboscilfreq*(lbcurstep-lbequstep));

  if(!incompress) {

    #pragma omp parallel
    {
      double interforce_t[3*lbsy.nf], sitespeed_t[3], rho_t[lbsy.nf];
      double *interforce = &interforce_t[0];
      double *sitespeed = &sitespeed_t[0];
      double *rho = &rho_t[0];
        
      #pragma omp for
      for(long il=0; il<Tmax; il++) {
        fGetSpeedShanChenAllMassSite(sitespeed, rho, &lbf[il*lbsitelength], &lbomega[il*lbsy.nf]);
        if(lbphi[il] != 11) {
          for(int ll=0; ll<3*lbsy.nf; ll++)
	        interforce[ll] = lbinterforce[il*3*lbsy.nf+ll] + lbheatforce[il*3*lbsy.nf+ll] + postequil*(lbbdforce[ll]+lboscilforce[ll]*freq);
          if(lbphi[il] != 12 && lbphi[il] != 13)
            fSiteFluidCollisionBGKGuo(&lbf[il*lbsitelength], sitespeed, &lbomega[il*lbsy.nf], rho, interforce);
          fSiteSoluteCollisionBGK(&lbf[il*lbsitelength + lbsy.nf], sitespeed);
          fSiteThermalCollisionBGK(&lbf[il*lbsitelength + lbsy.nf+lbsy.nc], sitespeed);
        }
      }
    }
  }
  else {

    #pragma omp parallel
    {
      double interforce_t[3*lbsy.nf], sitespeed_t[3], rho_t[lbsy.nf];
      double *interforce = &interforce_t[0];
      double *sitespeed = &sitespeed_t[0];
      double *rho = &rho_t[0];
        
      #pragma omp for
      for(long il=0; il<Tmax; il++) {
        if(lbphi[il] != 11) {
          fGetSpeedShanChenIncomAllMassSite(sitespeed, rho, &lbf[il*lbsitelength], &lbomega[il*lbsy.nf]);
          for(int ll=0; ll<3*lbsy.nf; ll++)
	        interforce[ll] = lbinterforce[il*3*lbsy.nf+ll] + lbheatforce[il*3*lbsy.nf+ll] + postequil*(lbbdforce[ll]+lboscilforce[ll]*freq);
          if(lbphi[il] != 12 && lbphi[il] != 13)
            fSiteFluidIncomCollisionBGKGuo(&lbf[il*lbsitelength], sitespeed, &lbomega[il*lbsy.nf], rho, interforce);
          fSiteSoluteCollisionBGK(&lbf[il*lbsitelength + lbsy.nf], sitespeed);
          fSiteThermalCollisionBGK(&lbf[il*lbsitelength + lbsy.nf+lbsy.nc], sitespeed);
        }
      }
    }
  }
  return 0;
}

int fCollisionBGKHeShanChen()
{
  long Tmax = lbdm.touter;
  double freq = (lbbdforcetyp==1)*sin(lboscilfreq*(lbcurstep-lbequstep));

  if(!incompress) {

    #pragma omp parallel
    {
      double interforce_t[3*lbsy.nf], sitespeed_t[3], rho_t[lbsy.nf];
      double *interforce = &interforce_t[0];
      double *sitespeed = &sitespeed_t[0];
      double *rho = &rho_t[0];
        
      #pragma omp for
      for(long il=0; il<Tmax; il++) {
        fGetSpeedShanChenAllMassSite(sitespeed, rho, &lbf[il*lbsitelength], &lbomega[il*lbsy.nf]);
        if(lbphi[il] != 11) {
          for(int ll=0; ll<3*lbsy.nf; ll++)
	        interforce[ll] = lbinterforce[il*3*lbsy.nf+ll] + lbheatforce[il*3*lbsy.nf+ll] + postequil*(lbbdforce[ll]+lboscilforce[ll]*freq);
          if(lbphi[il] != 12 && lbphi[il] != 13)
            fSiteFluidCollisionBGKHe(&lbf[il*lbsitelength], sitespeed, &lbomega[il*lbsy.nf], rho, interforce);
          fSiteSoluteCollisionBGK(&lbf[il*lbsitelength + lbsy.nf], sitespeed);
          fSiteThermalCollisionBGK(&lbf[il*lbsitelength + lbsy.nf+lbsy.nc], sitespeed);
        }
      }
    }
  }
  else {

    #pragma omp parallel
    {
      double interforce_t[3*lbsy.nf], sitespeed_t[3], rho_t[lbsy.nf];
      double *interforce = &interforce_t[0];
      double *sitespeed = &sitespeed_t[0];
      double *rho = &rho_t[0];
        
      #pragma omp for
      for(long il=0; il<Tmax; il++) {
        if(lbphi[il] != 11) {
          fGetSpeedShanChenIncomAllMassSite(sitespeed, rho, &lbf[il*lbsitelength], &lbomega[il*lbsy.nf]);
          for(int ll=0; ll<3*lbsy.nf; ll++)
	        interforce[ll] = lbinterforce[il*3*lbsy.nf+ll] + lbheatforce[il*3*lbsy.nf+ll] + postequil*(lbbdforce[ll]+lboscilforce[ll]*freq);
          if(lbphi[il] != 12 && lbphi[il] != 13)
            fSiteFluidIncomCollisionBGKHe(&lbf[il*lbsitelength], sitespeed, &lbomega[il*lbsy.nf], rho, interforce);
          fSiteSoluteCollisionBGK(&lbf[il*lbsitelength + lbsy.nf], sitespeed);
          fSiteThermalCollisionBGK(&lbf[il*lbsitelength + lbsy.nf+lbsy.nc], sitespeed);
        }
      }
    }
  }
  return 0;
}


int fCollisionBGKLishchuk()
{
  int numpair = 3 * lbsy.nf * (lbsy.nf-1) / 2;
  long Tmax = lbdm.touter;
  double freq = (lbbdforcetyp==1)*sin(lboscilfreq*(lbcurstep-lbequstep));

  if(!incompress) {
      
    #pragma omp parallel
    {
      double interforce_t[3], sitespeed_t[3], rho_t[lbsy.nf];
      double *interforce = &interforce_t[0];
      double *sitespeed = &sitespeed_t[0];
      double *rho = &rho_t[0];

      #pragma omp for
      for(long il=0; il<Tmax; il++) {
        if(lbphi[il] != 11) {
          fGetSpeedAllMassSite(sitespeed, rho, &lbf[il*lbsitelength]);
          double invallmass = 0.0;
          for(int ll=0; ll<lbsy.nf; ll++)
            invallmass += rho[ll];
          invallmass = fReciprocal(invallmass);
          interforce[0] = lbinterforce[3*il  ]; interforce[1] = lbinterforce[3*il+1]; interforce[2] = lbinterforce[3*il+2];
          for(int ll=0; ll<lbsy.nf; ll++) {
            double frac = rho[ll] * invallmass;
	        interforce[0] += frac*(lbheatforce[il*3*lbsy.nf+3*ll  ]+postequil*(lbbdforce[3*ll  ]+lboscilforce[3*ll  ]*freq));
            interforce[1] += frac*(lbheatforce[il*3*lbsy.nf+3*ll+1]+postequil*(lbbdforce[3*ll+1]+lboscilforce[3*ll+1]*freq));
	        interforce[2] += frac*(lbheatforce[il*3*lbsy.nf+3*ll+2]+postequil*(lbbdforce[3*ll+2]+lboscilforce[3*ll+2]*freq));
          }
          if(lbphi[il] != 12 && lbphi[il] != 13)
	        fSiteFluidCollisionBGKLishchuk(&lbf[il*lbsitelength], sitespeed, &lbomega[il*lbsy.nf], rho, interforce, &lbft[il*numpair]);
          fSiteSoluteCollisionBGK(&lbf[il*lbsitelength + lbsy.nf], sitespeed);
          fSiteThermalCollisionBGK(&lbf[il*lbsitelength + lbsy.nf+lbsy.nc], sitespeed);
        }
      }
    }
  }
  else {
      
    #pragma omp parallel
    {
      double interforce_t[3], sitespeed_t[3], rho_t[lbsy.nf];
      double *interforce = &interforce_t[0];
      double *sitespeed = &sitespeed_t[0];
      double *rho = &rho_t[0];

      #pragma omp for
      for(long il=0; il<Tmax; il++) {
        if(lbphi[il] != 11) {
          fGetSpeedIncomAllMassSite(sitespeed, rho, &lbf[il*lbsitelength]);
          double invallmass = 0.0;
          for(int ll=0; ll<lbsy.nf; ll++)
            invallmass += rho[ll];
          invallmass = fReciprocal(invallmass);
          interforce[0] = lbinterforce[3*il  ]; interforce[1] = lbinterforce[3*il+1]; interforce[2] = lbinterforce[3*il+2];
          for(int ll=0; ll<lbsy.nf; ll++) {
            double frac = rho[ll] * invallmass;
	        interforce[0] += frac*(lbheatforce[il*3*lbsy.nf+3*ll  ]+postequil*(lbbdforce[3*ll  ]+lboscilforce[3*ll  ]*freq));
            interforce[1] += frac*(lbheatforce[il*3*lbsy.nf+3*ll+1]+postequil*(lbbdforce[3*ll+1]+lboscilforce[3*ll+1]*freq));
	        interforce[2] += frac*(lbheatforce[il*3*lbsy.nf+3*ll+2]+postequil*(lbbdforce[3*ll+2]+lboscilforce[3*ll+2]*freq));
          }
          if(lbphi[il] != 12 && lbphi[il] != 13)
            fSiteFluidIncomCollisionBGKLishchuk(&lbf[il*lbsitelength], sitespeed, &lbomega[il*lbsy.nf], rho, interforce, &lbft[il*numpair]);
          fSiteSoluteCollisionBGK(&lbf[il*lbsitelength + lbsy.nf], sitespeed);
          fSiteThermalCollisionBGK(&lbf[il*lbsitelength + lbsy.nf+lbsy.nc], sitespeed);
        }
      }
    }
  }
  return 0;
}

int fCollisionBGKEDMLishchuk()
{
  int numpair = 3 * lbsy.nf * (lbsy.nf-1) / 2;
  long Tmax = lbdm.touter;
  double freq = (lbbdforcetyp==1)*sin(lboscilfreq*(lbcurstep-lbequstep));

  if(!incompress) {

    #pragma omp parallel
    {
      double interforce_t[3], sitespeed_t[3], rho_t[lbsy.nf];
      double *interforce = &interforce_t[0];
      double *sitespeed = &sitespeed_t[0];
      double *rho = &rho_t[0];

      #pragma omp for
      for(long il=0; il<Tmax; il++) {
        if(lbphi[il] != 11) {
          fGetSpeedAllMassSite(sitespeed, rho, &lbf[il*lbsitelength]);
          double invallmass = 0.0;
          for(int ll=0; ll<lbsy.nf; ll++)
            invallmass += rho[ll];
          invallmass = fReciprocal(invallmass);
          interforce[0] = lbinterforce[3*il  ]; interforce[1] = lbinterforce[3*il+1]; interforce[2] = lbinterforce[3*il+2];
          for(int ll=0; ll<lbsy.nf; ll++) {
            double frac = rho[ll] * invallmass;
	        interforce[0] += frac*(lbheatforce[il*3*lbsy.nf+3*ll  ]+postequil*(lbbdforce[3*ll  ]+lboscilforce[3*ll  ]*freq));
            interforce[1] += frac*(lbheatforce[il*3*lbsy.nf+3*ll+1]+postequil*(lbbdforce[3*ll+1]+lboscilforce[3*ll+1]*freq));
	        interforce[2] += frac*(lbheatforce[il*3*lbsy.nf+3*ll+2]+postequil*(lbbdforce[3*ll+2]+lboscilforce[3*ll+2]*freq));
          }
          if(lbphi[il] != 12 && lbphi[il] != 13)
            fSiteFluidCollisionBGKEDMLishchuk(&lbf[il*lbsitelength], sitespeed, &lbomega[il*lbsy.nf], rho, interforce, &lbft[il*numpair]);
          fSiteSoluteCollisionBGK(&lbf[il*lbsitelength + lbsy.nf], sitespeed);
          fSiteThermalCollisionBGK(&lbf[il*lbsitelength + lbsy.nf+lbsy.nc], sitespeed);
        }
      }
    }
  }
  else {

    #pragma omp parallel
    {
      double interforce_t[3], sitespeed_t[3], rho_t[lbsy.nf];
      double *interforce = &interforce_t[0];
      double *sitespeed = &sitespeed_t[0];
      double *rho = &rho_t[0];

      #pragma omp for
      for(long il=0; il<Tmax; il++) {
        if(lbphi[il] != 11) {
          fGetSpeedIncomAllMassSite(sitespeed, rho, &lbf[il*lbsitelength]);
          double invallmass = 0.0;
          for(int ll=0; ll<lbsy.nf; ll++)
            invallmass += rho[ll];
          invallmass = fReciprocal(invallmass);
          interforce[0] = lbinterforce[3*il  ]; interforce[1] = lbinterforce[3*il+1]; interforce[2] = lbinterforce[3*il+2];
          for(int ll=0; ll<lbsy.nf; ll++) {
            double frac = rho[ll] * invallmass;
	        interforce[0] += frac*(lbheatforce[il*3*lbsy.nf+3*ll  ]+postequil*(lbbdforce[3*ll  ]+lboscilforce[3*ll  ]*freq));
            interforce[1] += frac*(lbheatforce[il*3*lbsy.nf+3*ll+1]+postequil*(lbbdforce[3*ll+1]+lboscilforce[3*ll+1]*freq));
	        interforce[2] += frac*(lbheatforce[il*3*lbsy.nf+3*ll+2]+postequil*(lbbdforce[3*ll+2]+lboscilforce[3*ll+2]*freq));
          }
          if(lbphi[il] != 12 && lbphi[il] != 13)
            fSiteFluidIncomCollisionBGKEDMLishchuk(&lbf[il*lbsitelength], sitespeed, &lbomega[il*lbsy.nf], rho, interforce, &lbft[il*numpair]);
          fSiteSoluteCollisionBGK(&lbf[il*lbsitelength + lbsy.nf], sitespeed);
          fSiteThermalCollisionBGK(&lbf[il*lbsitelength + lbsy.nf+lbsy.nc], sitespeed);
        }
      }
    }
  }
  return 0;
}

int fCollisionBGKGuoLishchuk()
{
  int numpair = 3 * lbsy.nf * (lbsy.nf-1) / 2;
  long Tmax = lbdm.touter;
  double freq = (lbbdforcetyp==1)*sin(lboscilfreq*(lbcurstep-lbequstep));

  if(!incompress) {

    #pragma omp parallel
    {
      double interforce_t[3], sitespeed_t[3], rho_t[lbsy.nf];
      double *interforce = &interforce_t[0];
      double *sitespeed = &sitespeed_t[0];
      double *rho = &rho_t[0];

      #pragma omp for
      for(long il=0; il<Tmax; il++) {
        if(lbphi[il] != 11) {
          fGetSpeedAllMassSite(sitespeed, rho, &lbf[il*lbsitelength]);
          double invallmass = 0.0;
          for(int ll=0; ll<lbsy.nf; ll++)
            invallmass += rho[ll];
          invallmass = fReciprocal(invallmass);
          interforce[0] = lbinterforce[3*il  ]; interforce[1] = lbinterforce[3*il+1]; interforce[2] = lbinterforce[3*il+2];
          for(int ll=0; ll<lbsy.nf; ll++) {
            double frac = rho[ll] * invallmass;
	        interforce[0] += frac*(lbheatforce[il*3*lbsy.nf+3*ll  ]+postequil*(lbbdforce[3*ll  ]+lboscilforce[3*ll  ]*freq));
            interforce[1] += frac*(lbheatforce[il*3*lbsy.nf+3*ll+1]+postequil*(lbbdforce[3*ll+1]+lboscilforce[3*ll+1]*freq));
	        interforce[2] += frac*(lbheatforce[il*3*lbsy.nf+3*ll+2]+postequil*(lbbdforce[3*ll+2]+lboscilforce[3*ll+2]*freq));
          }
          if(lbphi[il] != 12 && lbphi[il] != 13)
            fSiteFluidCollisionBGKGuoLishchuk(&lbf[il*lbsitelength], sitespeed, &lbomega[il*lbsy.nf], rho, interforce, &lbft[il*numpair]);
          fSiteSoluteCollisionBGK(&lbf[il*lbsitelength + lbsy.nf], sitespeed);
          fSiteThermalCollisionBGK(&lbf[il*lbsitelength + lbsy.nf+lbsy.nc], sitespeed);
        }
      }
    }
  }
  else {

    #pragma omp parallel
    {
      double interforce_t[3], sitespeed_t[3], rho_t[lbsy.nf];
      double *interforce = &interforce_t[0];
      double *sitespeed = &sitespeed_t[0];
      double *rho = &rho_t[0];

      #pragma omp for
      for(long il=0; il<Tmax; il++) {
        if(lbphi[il] != 11) {
          fGetSpeedIncomAllMassSite(sitespeed, rho, &lbf[il*lbsitelength]);
          double invallmass = 0.0;
          for(int ll=0; ll<lbsy.nf; ll++)
            invallmass += rho[ll];
          invallmass = fReciprocal(invallmass);
          interforce[0] = lbinterforce[3*il  ]; interforce[1] = lbinterforce[3*il+1]; interforce[2] = lbinterforce[3*il+2];
          for(int ll=0; ll<lbsy.nf; ll++) {
            double frac = rho[ll] * invallmass;
	        interforce[0] += frac*(lbheatforce[il*3*lbsy.nf+3*ll  ]+postequil*(lbbdforce[3*ll  ]+lboscilforce[3*ll  ]*freq));
            interforce[1] += frac*(lbheatforce[il*3*lbsy.nf+3*ll+1]+postequil*(lbbdforce[3*ll+1]+lboscilforce[3*ll+1]*freq));
	        interforce[2] += frac*(lbheatforce[il*3*lbsy.nf+3*ll+2]+postequil*(lbbdforce[3*ll+2]+lboscilforce[3*ll+2]*freq));
          }
          if(lbphi[il] != 12 && lbphi[il] != 13)
            fSiteFluidIncomCollisionBGKGuoLishchuk(&lbf[il*lbsitelength], sitespeed, &lbomega[il*lbsy.nf], rho, interforce, &lbft[il*numpair]);
          fSiteSoluteCollisionBGK(&lbf[il*lbsitelength + lbsy.nf], sitespeed);
          fSiteThermalCollisionBGK(&lbf[il*lbsitelength + lbsy.nf+lbsy.nc], sitespeed);
        }
      }
    }
  }
  return 0;
}


int fCollisionBGKHeLishchuk()
{
  int numpair = 3 * lbsy.nf * (lbsy.nf-1) / 2;
  long Tmax = lbdm.touter;
  double freq = (lbbdforcetyp==1)*sin(lboscilfreq*(lbcurstep-lbequstep));

  if(!incompress) {

    #pragma omp parallel
    {
      double interforce_t[3], sitespeed_t[3], rho_t[lbsy.nf];
      double *interforce = &interforce_t[0];
      double *sitespeed = &sitespeed_t[0];
      double *rho = &rho_t[0];

      #pragma omp for
      for(long il=0; il<Tmax; il++) {
        if(lbphi[il] != 11) {
          fGetSpeedAllMassSite(sitespeed, rho, &lbf[il*lbsitelength]);
          double invallmass = 0.0;
          for(int ll=0; ll<lbsy.nf; ll++)
            invallmass += rho[ll];
          invallmass = fReciprocal(invallmass);
          interforce[0] = lbinterforce[3*il  ]; interforce[1] = lbinterforce[3*il+1]; interforce[2] = lbinterforce[3*il+2];
          for(int ll=0; ll<lbsy.nf; ll++) {
            double frac = rho[ll] * invallmass;
	        interforce[0] += frac*(lbheatforce[il*3*lbsy.nf+3*ll  ]+postequil*(lbbdforce[3*ll  ]+lboscilforce[3*ll  ]*freq));
            interforce[1] += frac*(lbheatforce[il*3*lbsy.nf+3*ll+1]+postequil*(lbbdforce[3*ll+1]+lboscilforce[3*ll+1]*freq));
	        interforce[2] += frac*(lbheatforce[il*3*lbsy.nf+3*ll+2]+postequil*(lbbdforce[3*ll+2]+lboscilforce[3*ll+2]*freq));
          }
          if(lbphi[il] != 12 && lbphi[il] != 13)
            fSiteFluidCollisionBGKHeLishchuk(&lbf[il*lbsitelength], sitespeed, &lbomega[il*lbsy.nf], rho, interforce, &lbft[il*numpair]);
          fSiteSoluteCollisionBGK(&lbf[il*lbsitelength + lbsy.nf], sitespeed);
          fSiteThermalCollisionBGK(&lbf[il*lbsitelength + lbsy.nf+lbsy.nc], sitespeed);
        }
      }
    }
  }
  else {

    #pragma omp parallel
    {
      double interforce_t[3], sitespeed_t[3], rho_t[lbsy.nf];
      double *interforce = &interforce_t[0];
      double *sitespeed = &sitespeed_t[0];
      double *rho = &rho_t[0];

      #pragma omp for
      for(long il=0; il<Tmax; il++) {
        if(lbphi[il] != 11) {
          fGetSpeedIncomAllMassSite(sitespeed, rho, &lbf[il*lbsitelength]);
          double invallmass = 0.0;
          for(int ll=0; ll<lbsy.nf; ll++)
            invallmass += rho[ll];
          invallmass = fReciprocal(invallmass);
          interforce[0] = lbinterforce[3*il  ]; interforce[1] = lbinterforce[3*il+1]; interforce[2] = lbinterforce[3*il+2];
          for(int ll=0; ll<lbsy.nf; ll++) {
            double frac = rho[ll] * invallmass;
	        interforce[0] += frac*(lbheatforce[il*3*lbsy.nf+3*ll  ]+postequil*(lbbdforce[3*ll  ]+lboscilforce[3*ll  ]*freq));
            interforce[1] += frac*(lbheatforce[il*3*lbsy.nf+3*ll+1]+postequil*(lbbdforce[3*ll+1]+lboscilforce[3*ll+1]*freq));
	        interforce[2] += frac*(lbheatforce[il*3*lbsy.nf+3*ll+2]+postequil*(lbbdforce[3*ll+2]+lboscilforce[3*ll+2]*freq));
          }
          if(lbphi[il] != 12 && lbphi[il] != 13)
            fSiteFluidIncomCollisionBGKHeLishchuk(&lbf[il*lbsitelength], sitespeed, &lbomega[il*lbsy.nf], rho, interforce, &lbft[il*numpair]);
          fSiteSoluteCollisionBGK(&lbf[il*lbsitelength + lbsy.nf], sitespeed);
          fSiteThermalCollisionBGK(&lbf[il*lbsitelength + lbsy.nf+lbsy.nc], sitespeed);
        }
      }
    }
  }
  return 0;
}


int fCollisionBGKLishchukLocal()
{
  int numpair = 3 * lbsy.nf * (lbsy.nf-1) / 2;
  int threed = (lbsy.nd>2);
  long Tmax = lbdm.touter;
  double freq = (lbbdforcetyp==1)*sin(lboscilfreq*(lbcurstep-lbequstep));

  if(!incompress) {
      
    #pragma omp parallel
    {
      double interforce_t[3], sitespeed_t[3], rho_t[lbsy.nf];
      double *interforce = &interforce_t[0];
      double *sitespeed = &sitespeed_t[0];
      double *rho = &rho_t[0];

      #pragma omp for
      for(long il=0; il<Tmax; il++) {
        if(lbphi[il] != 11) {
          fGetSpeedAllMassSite(sitespeed, rho, &lbf[il*lbsitelength]);
          double invallmass = 0.0;
          for(int ll=0; ll<lbsy.nf; ll++)
            invallmass += rho[ll];
          invallmass = fReciprocal(invallmass);
          interforce[0] = lbinterforce[3*il  ]; interforce[1] = lbinterforce[3*il+1]; interforce[2] = lbinterforce[3*il+2];
          for(int ll=0; ll<lbsy.nf; ll++) {
            double frac = rho[ll] * invallmass;
	        interforce[0] += frac*(lbheatforce[il*3*lbsy.nf+3*ll  ]+postequil*(lbbdforce[3*ll  ]+lboscilforce[3*ll  ]*freq));
            interforce[1] += frac*(lbheatforce[il*3*lbsy.nf+3*ll+1]+postequil*(lbbdforce[3*ll+1]+lboscilforce[3*ll+1]*freq));
	        interforce[2] += frac*(lbheatforce[il*3*lbsy.nf+3*ll+2]+postequil*(lbbdforce[3*ll+2]+lboscilforce[3*ll+2]*freq));
          }
          if(lbphi[il] != 12 && lbphi[il] != 13)
	        fSiteFluidCollisionBGKLishchukLocal(&lbf[il*lbsitelength], sitespeed, &lbomega[il*lbsy.nf], rho, interforce, &lbft[il*numpair], threed);
          fSiteSoluteCollisionBGK(&lbf[il*lbsitelength + lbsy.nf], sitespeed);
          fSiteThermalCollisionBGK(&lbf[il*lbsitelength + lbsy.nf+lbsy.nc], sitespeed);
        }
      }
    }
  }
  else {
      
    #pragma omp parallel
    {
      double interforce_t[3], sitespeed_t[3], rho_t[lbsy.nf];
      double *interforce = &interforce_t[0];
      double *sitespeed = &sitespeed_t[0];
      double *rho = &rho_t[0];

      #pragma omp for
      for(long il=0; il<Tmax; il++) {
        if(lbphi[il] != 11) {
          fGetSpeedIncomAllMassSite(sitespeed, rho, &lbf[il*lbsitelength]);
          double invallmass = 0.0;
          for(int ll=0; ll<lbsy.nf; ll++)
            invallmass += rho[ll];
          invallmass = fReciprocal(invallmass);
          interforce[0] = lbinterforce[3*il  ]; interforce[1] = lbinterforce[3*il+1]; interforce[2] = lbinterforce[3*il+2];
          for(int ll=0; ll<lbsy.nf; ll++) {
            double frac = rho[ll] * invallmass;
	        interforce[0] += frac*(lbheatforce[il*3*lbsy.nf+3*ll  ]+postequil*(lbbdforce[3*ll  ]+lboscilforce[3*ll  ]*freq));
            interforce[1] += frac*(lbheatforce[il*3*lbsy.nf+3*ll+1]+postequil*(lbbdforce[3*ll+1]+lboscilforce[3*ll+1]*freq));
	        interforce[2] += frac*(lbheatforce[il*3*lbsy.nf+3*ll+2]+postequil*(lbbdforce[3*ll+2]+lboscilforce[3*ll+2]*freq));
          }
          if(lbphi[il] != 12 && lbphi[il] != 13)
            fSiteFluidIncomCollisionBGKLishchukLocal(&lbf[il*lbsitelength], sitespeed, &lbomega[il*lbsy.nf], rho, interforce, &lbft[il*numpair], threed);
          fSiteSoluteCollisionBGK(&lbf[il*lbsitelength + lbsy.nf], sitespeed);
          fSiteThermalCollisionBGK(&lbf[il*lbsitelength + lbsy.nf+lbsy.nc], sitespeed);
        }
      }
    }
  }
  return 0;
}

int fCollisionBGKEDMLishchukLocal()
{
  int numpair = 3 * lbsy.nf * (lbsy.nf-1) / 2;
  int threed = (lbsy.nd>2);
  long Tmax = lbdm.touter;
  double freq = (lbbdforcetyp==1)*sin(lboscilfreq*(lbcurstep-lbequstep));

  if(!incompress) {

    #pragma omp parallel
    {
      double interforce_t[3], sitespeed_t[3], rho_t[lbsy.nf];
      double *interforce = &interforce_t[0];
      double *sitespeed = &sitespeed_t[0];
      double *rho = &rho_t[0];

      #pragma omp for
      for(long il=0; il<Tmax; il++) {
        if(lbphi[il] != 11) {
          fGetSpeedAllMassSite(sitespeed, rho, &lbf[il*lbsitelength]);
          double invallmass = 0.0;
          for(int ll=0; ll<lbsy.nf; ll++)
            invallmass += rho[ll];
          invallmass = fReciprocal(invallmass);
          interforce[0] = lbinterforce[3*il  ]; interforce[1] = lbinterforce[3*il+1]; interforce[2] = lbinterforce[3*il+2];
          for(int ll=0; ll<lbsy.nf; ll++) {
            double frac = rho[ll] * invallmass;
	        interforce[0] += frac*(lbheatforce[il*3*lbsy.nf+3*ll  ]+postequil*(lbbdforce[3*ll  ]+lboscilforce[3*ll  ]*freq));
            interforce[1] += frac*(lbheatforce[il*3*lbsy.nf+3*ll+1]+postequil*(lbbdforce[3*ll+1]+lboscilforce[3*ll+1]*freq));
	        interforce[2] += frac*(lbheatforce[il*3*lbsy.nf+3*ll+2]+postequil*(lbbdforce[3*ll+2]+lboscilforce[3*ll+2]*freq));
          }
          if(lbphi[il] != 12 && lbphi[il] != 13)
            fSiteFluidCollisionBGKEDMLishchukLocal(&lbf[il*lbsitelength], sitespeed, &lbomega[il*lbsy.nf], rho, interforce, &lbft[il*numpair], threed);
          fSiteSoluteCollisionBGK(&lbf[il*lbsitelength + lbsy.nf], sitespeed);
          fSiteThermalCollisionBGK(&lbf[il*lbsitelength + lbsy.nf+lbsy.nc], sitespeed);
        }
      }
    }
  }
  else {

    #pragma omp parallel
    {
      double interforce_t[3], sitespeed_t[3], rho_t[lbsy.nf];
      double *interforce = &interforce_t[0];
      double *sitespeed = &sitespeed_t[0];
      double *rho = &rho_t[0];

      #pragma omp for
      for(long il=0; il<Tmax; il++) {
        if(lbphi[il] != 11) {
          fGetSpeedIncomAllMassSite(sitespeed, rho, &lbf[il*lbsitelength]);
          double invallmass = 0.0;
          for(int ll=0; ll<lbsy.nf; ll++)
            invallmass += rho[ll];
          invallmass = fReciprocal(invallmass);
          interforce[0] = lbinterforce[3*il  ]; interforce[1] = lbinterforce[3*il+1]; interforce[2] = lbinterforce[3*il+2];
          for(int ll=0; ll<lbsy.nf; ll++) {
            double frac = rho[ll] * invallmass;
	        interforce[0] += frac*(lbheatforce[il*3*lbsy.nf+3*ll  ]+postequil*(lbbdforce[3*ll  ]+lboscilforce[3*ll  ]*freq));
            interforce[1] += frac*(lbheatforce[il*3*lbsy.nf+3*ll+1]+postequil*(lbbdforce[3*ll+1]+lboscilforce[3*ll+1]*freq));
	        interforce[2] += frac*(lbheatforce[il*3*lbsy.nf+3*ll+2]+postequil*(lbbdforce[3*ll+2]+lboscilforce[3*ll+2]*freq));
          }
          if(lbphi[il] != 12 && lbphi[il] != 13)
            fSiteFluidIncomCollisionBGKEDMLishchukLocal(&lbf[il*lbsitelength], sitespeed, &lbomega[il*lbsy.nf], rho, interforce, &lbft[il*numpair], threed);
          fSiteSoluteCollisionBGK(&lbf[il*lbsitelength + lbsy.nf], sitespeed);
          fSiteThermalCollisionBGK(&lbf[il*lbsitelength + lbsy.nf+lbsy.nc], sitespeed);
        }
      }
    }
  }
  return 0;
}

int fCollisionBGKGuoLishchukLocal()
{
  int numpair = 3 * lbsy.nf * (lbsy.nf-1) / 2;
  int threed = (lbsy.nd>2);
  long Tmax = lbdm.touter;
  double freq = (lbbdforcetyp==1)*sin(lboscilfreq*(lbcurstep-lbequstep));

  if(!incompress) {

    #pragma omp parallel
    {
      double interforce_t[3], sitespeed_t[3], rho_t[lbsy.nf];
      double *interforce = &interforce_t[0];
      double *sitespeed = &sitespeed_t[0];
      double *rho = &rho_t[0];

      #pragma omp for
      for(long il=0; il<Tmax; il++) {
        if(lbphi[il] != 11) {
          fGetSpeedAllMassSite(sitespeed, rho, &lbf[il*lbsitelength]);
          double invallmass = 0.0;
          for(int ll=0; ll<lbsy.nf; ll++)
            invallmass += rho[ll];
          invallmass = fReciprocal(invallmass);
          interforce[0] = lbinterforce[3*il  ]; interforce[1] = lbinterforce[3*il+1]; interforce[2] = lbinterforce[3*il+2];
          for(int ll=0; ll<lbsy.nf; ll++) {
            double frac = rho[ll] * invallmass;
	        interforce[0] += frac*(lbheatforce[il*3*lbsy.nf+3*ll  ]+postequil*(lbbdforce[3*ll  ]+lboscilforce[3*ll  ]*freq));
            interforce[1] += frac*(lbheatforce[il*3*lbsy.nf+3*ll+1]+postequil*(lbbdforce[3*ll+1]+lboscilforce[3*ll+1]*freq));
	        interforce[2] += frac*(lbheatforce[il*3*lbsy.nf+3*ll+2]+postequil*(lbbdforce[3*ll+2]+lboscilforce[3*ll+2]*freq));
          }
          if(lbphi[il] != 12 && lbphi[il] != 13)
            fSiteFluidCollisionBGKGuoLishchukLocal(&lbf[il*lbsitelength], sitespeed, &lbomega[il*lbsy.nf], rho, interforce, &lbft[il*numpair], threed);
          fSiteSoluteCollisionBGK(&lbf[il*lbsitelength + lbsy.nf], sitespeed);
          fSiteThermalCollisionBGK(&lbf[il*lbsitelength + lbsy.nf+lbsy.nc], sitespeed);
        }
      }
    }
  }
  else {

    #pragma omp parallel
    {
      double interforce_t[3], sitespeed_t[3], rho_t[lbsy.nf];
      double *interforce = &interforce_t[0];
      double *sitespeed = &sitespeed_t[0];
      double *rho = &rho_t[0];

      #pragma omp for
      for(long il=0; il<Tmax; il++) {
        fGetSpeedIncomAllMassSite(sitespeed, rho, &lbf[il*lbsitelength]);
        if(lbphi[il] != 11) {
          double invallmass = 0.0;
          for(int ll=0; ll<lbsy.nf; ll++)
            invallmass += rho[ll];
          invallmass = fReciprocal(invallmass);
          interforce[0] = lbinterforce[3*il  ]; interforce[1] = lbinterforce[3*il+1]; interforce[2] = lbinterforce[3*il+2];
          for(int ll=0; ll<lbsy.nf; ll++) {
            double frac = rho[ll] * invallmass;
	        interforce[0] += frac*(lbheatforce[il*3*lbsy.nf+3*ll  ]+postequil*(lbbdforce[3*ll  ]+lboscilforce[3*ll  ]*freq));
            interforce[1] += frac*(lbheatforce[il*3*lbsy.nf+3*ll+1]+postequil*(lbbdforce[3*ll+1]+lboscilforce[3*ll+1]*freq));
	        interforce[2] += frac*(lbheatforce[il*3*lbsy.nf+3*ll+2]+postequil*(lbbdforce[3*ll+2]+lboscilforce[3*ll+2]*freq));
          }
          if(lbphi[il] != 12 && lbphi[il] != 13)
            fSiteFluidIncomCollisionBGKGuoLishchukLocal(&lbf[il*lbsitelength], sitespeed, &lbomega[il*lbsy.nf], rho, interforce, &lbft[il*numpair], threed);
          fSiteSoluteCollisionBGK(&lbf[il*lbsitelength + lbsy.nf], sitespeed);
          fSiteThermalCollisionBGK(&lbf[il*lbsitelength + lbsy.nf+lbsy.nc], sitespeed);
        }
      }
    }
  }
  return 0;
}


int fCollisionBGKHeLishchukLocal()
{
  int numpair = 3 * lbsy.nf * (lbsy.nf-1) / 2;
  int threed = (lbsy.nd>2);
  long Tmax = lbdm.touter;
  double freq = (lbbdforcetyp==1)*sin(lboscilfreq*(lbcurstep-lbequstep));

  if(!incompress) {

    #pragma omp parallel
    {
      double interforce_t[3], sitespeed_t[3], rho_t[lbsy.nf];
      double *interforce = &interforce_t[0];
      double *sitespeed = &sitespeed_t[0];
      double *rho = &rho_t[0];

      #pragma omp for
      for(long il=0; il<Tmax; il++) {
        if(lbphi[il] != 11) {
          fGetSpeedAllMassSite(sitespeed, rho, &lbf[il*lbsitelength]);
          double invallmass = 0.0;
          for(int ll=0; ll<lbsy.nf; ll++)
            invallmass += rho[ll];
          invallmass = fReciprocal(invallmass);
          interforce[0] = lbinterforce[3*il  ]; interforce[1] = lbinterforce[3*il+1]; interforce[2] = lbinterforce[3*il+2];
          for(int ll=0; ll<lbsy.nf; ll++) {
            double frac = rho[ll] * invallmass;
	        interforce[0] += frac*(lbheatforce[il*3*lbsy.nf+3*ll  ]+postequil*(lbbdforce[3*ll  ]+lboscilforce[3*ll  ]*freq));
            interforce[1] += frac*(lbheatforce[il*3*lbsy.nf+3*ll+1]+postequil*(lbbdforce[3*ll+1]+lboscilforce[3*ll+1]*freq));
	        interforce[2] += frac*(lbheatforce[il*3*lbsy.nf+3*ll+2]+postequil*(lbbdforce[3*ll+2]+lboscilforce[3*ll+2]*freq));
          }
          if(lbphi[il] != 12 && lbphi[il] != 13)
            fSiteFluidCollisionBGKHeLishchukLocal(&lbf[il*lbsitelength], sitespeed, &lbomega[il*lbsy.nf], rho, interforce, &lbft[il*numpair], threed);
          fSiteSoluteCollisionBGK(&lbf[il*lbsitelength + lbsy.nf], sitespeed);
          fSiteThermalCollisionBGK(&lbf[il*lbsitelength + lbsy.nf+lbsy.nc], sitespeed);
        }
      }
    }
  }
  else {

    #pragma omp parallel
    {
      double interforce_t[3], sitespeed_t[3], rho_t[lbsy.nf];
      double *interforce = &interforce_t[0];
      double *sitespeed = &sitespeed_t[0];
      double *rho = &rho_t[0];

      #pragma omp for
      for(long il=0; il<Tmax; il++) {
        fGetSpeedIncomAllMassSite(sitespeed, rho, &lbf[il*lbsitelength]);
        if(lbphi[il] != 11) {
          double invallmass = 0.0;
          for(int ll=0; ll<lbsy.nf; ll++)
            invallmass += rho[ll];
          invallmass = fReciprocal(invallmass);
          interforce[0] = lbinterforce[3*il  ]; interforce[1] = lbinterforce[3*il+1]; interforce[2] = lbinterforce[3*il+2];
          for(int ll=0; ll<lbsy.nf; ll++) {
            double frac = rho[ll] * invallmass;
	        interforce[0] += frac*(lbheatforce[il*3*lbsy.nf+3*ll  ]+postequil*(lbbdforce[3*ll  ]+lboscilforce[3*ll  ]*freq));
            interforce[1] += frac*(lbheatforce[il*3*lbsy.nf+3*ll+1]+postequil*(lbbdforce[3*ll+1]+lboscilforce[3*ll+1]*freq));
	        interforce[2] += frac*(lbheatforce[il*3*lbsy.nf+3*ll+2]+postequil*(lbbdforce[3*ll+2]+lboscilforce[3*ll+2]*freq));
          }
          if(lbphi[il] != 12 && lbphi[il] != 13)
            fSiteFluidIncomCollisionBGKHeLishchukLocal(&lbf[il*lbsitelength], sitespeed, &lbomega[il*lbsy.nf], rho, interforce, &lbft[il*numpair], threed);
          fSiteSoluteCollisionBGK(&lbf[il*lbsitelength + lbsy.nf], sitespeed);
          fSiteThermalCollisionBGK(&lbf[il*lbsitelength + lbsy.nf+lbsy.nc], sitespeed);
        }
      }
    }
  }
  return 0;
}


int fCollisionBGKSwift()
{

  long Tmax = lbdm.touter;
  double freq = (lbbdforcetyp==1)*sin(lboscilfreq*(lbcurstep-lbequstep));

  if(lbsy.nf>1) {

   #pragma omp parallel
   {
      double interforce_t[3], sitespeed_t[3], rho_t[lbsy.nf];
      double *interforce = &interforce_t[0];
      double *sitespeed = &sitespeed_t[0];
      double *rho = &rho_t[0];

      #pragma omp for
      for(long il=0; il<Tmax; il++) {
        fGetOneSpeedSite(sitespeed, &lbf[il*lbsitelength]);
        double T = (lbsy.nt>0)?fGetTemperatureSite(il):lbsyst;
        if(lbneigh[il]>0 && lbphi[il]==0) {
          sitespeed[0] = 0.0; sitespeed[1] = 0.0; sitespeed[2] = 0.0;
        }
        if(lbphi[il] != 11) {
          fGetAllMassSite(rho, &lbf[il*lbsitelength]);
          double frac = 0.5*(1.0+rho[1]);
          for(int ll=0; ll<3; ll++)
            interforce [ll] = frac*(lbinterforce[il*3*lbsy.nf+ll]+lbheatforce[il*3*lbsy.nf+ll]+postequil*(lbbdforce[ll]+lboscilforce[ll]*freq))
                            + (1.0-frac)*(lbinterforce[il*3*lbsy.nf+3+ll]+lbheatforce[il*3*lbsy.nf+3+ll]+postequil*(lbbdforce[3+ll]+lboscilforce[3+ll]*freq));
          if(lbphi[il] != 12 && lbphi[il] != 13)
            fSiteFluidCollisionBGKSwiftTwoFluid(&lbf[il*lbsitelength], sitespeed, &lbomega[il*lbsy.nf], rho, &lbft[8*il], interforce, T);
          fSiteSoluteCollisionBGK(&lbf[il*lbsitelength + lbsy.nf], sitespeed);
          fSiteThermalCollisionBGK(&lbf[il*lbsitelength + lbsy.nf+lbsy.nc], sitespeed);
        }
      }
    }
  }
  else {
      
   #pragma omp parallel
   {
      double interforce_t[3], sitespeed_t[3], rho_t[lbsy.nf];
      double *interforce = &interforce_t[0];
      double *sitespeed = &sitespeed_t[0];
      double *rho = &rho_t[0];

      #pragma omp for
      for(long il=0; il<Tmax; il++) {
        fGetOneSpeedSite(sitespeed, &lbf[il*lbsitelength]);
        double T = (lbsy.nt>0)?fGetTemperatureSite(il):lbsyst;
        if(lbneigh[il]>0 && lbphi[il]==0) {
          sitespeed[0] = 0.0; sitespeed[1] = 0.0; sitespeed[2] = 0.0;
        }
        if(lbphi[il] != 11) {
          fGetAllMassSite(rho, &lbf[il*lbsitelength]);
          for(int ll=0; ll<3; ll++)
            interforce [ll] = lbinterforce[il*3*lbsy.nf+ll]+lbheatforce[il*3*lbsy.nf+ll]+postequil*(lbbdforce[ll]+lboscilforce[ll]*freq);
          if(lbphi[il] != 12 && lbphi[il] != 13)
            fSiteFluidCollisionBGKSwiftOneFluid(&lbf[il*lbsitelength], sitespeed, &lbomega[il*lbsy.nf], rho, &lbft[4*il], interforce, T);
          fSiteSoluteCollisionBGK(&lbf[il*lbsitelength + lbsy.nf], sitespeed);
          fSiteThermalCollisionBGK(&lbf[il*lbsitelength + lbsy.nf+lbsy.nc], sitespeed);
        }
      }
    }
  }
  return 0;
}

int fCollisionBGKEDMSwift()
{
  long Tmax = lbdm.touter;
  double freq = (lbbdforcetyp==1)*sin(lboscilfreq*(lbcurstep-lbequstep));

  if(lbsy.nf>1) {

   #pragma omp parallel
   {
      double interforce_t[3], sitespeed_t[3], rho_t[lbsy.nf];
      double *interforce = &interforce_t[0];
      double *sitespeed = &sitespeed_t[0];
      double *rho = &rho_t[0];

      #pragma omp for
      for(long il=0; il<Tmax; il++) {
        fGetOneSpeedSite(sitespeed, &lbf[il*lbsitelength]);
        double T = (lbsy.nt>0)?fGetTemperatureSite(il):lbsyst;
        if(lbneigh[il]>0 && lbphi[il]==0) {
          sitespeed[0] = 0.0; sitespeed[1] = 0.0; sitespeed[2] = 0.0;
        }
        if(lbphi[il] != 11) {
          fGetAllMassSite(rho, &lbf[il*lbsitelength]);
          double frac = 0.5*(1.0+rho[1]);
          for(int ll=0; ll<3; ll++)
            interforce [ll] = frac*(lbinterforce[il*3*lbsy.nf+ll]+lbheatforce[il*3*lbsy.nf+ll]+postequil*(lbbdforce[ll]+lboscilforce[ll]*freq))
                            + (1.0-frac)*(lbinterforce[il*3*lbsy.nf+3+ll]+lbheatforce[il*3*lbsy.nf+3+ll]+postequil*(lbbdforce[3+ll]+lboscilforce[3+ll]*freq));
          if(lbphi[il] != 12 && lbphi[il] != 13)
            fSiteFluidCollisionBGKEDMSwiftTwoFluid(&lbf[il*lbsitelength], sitespeed, &lbomega[il*lbsy.nf], rho, &lbft[8*il], interforce, T);
          fSiteSoluteCollisionBGK(&lbf[il*lbsitelength + lbsy.nf], sitespeed);
          fSiteThermalCollisionBGK(&lbf[il*lbsitelength + lbsy.nf+lbsy.nc], sitespeed);
        }
      }
    }
  }
  else {
      
   #pragma omp parallel
   {
      double interforce_t[3], sitespeed_t[3], rho_t[lbsy.nf];
      double *interforce = &interforce_t[0];
      double *sitespeed = &sitespeed_t[0];
      double *rho = &rho_t[0];

      #pragma omp for
      for(long il=0; il<Tmax; il++) {
        fGetOneSpeedSite(sitespeed, &lbf[il*lbsitelength]);
        double T = (lbsy.nt>0)?fGetTemperatureSite(il):lbsyst;
        if(lbneigh[il]>0 && lbphi[il]==0) {
          sitespeed[0] = 0.0; sitespeed[1] = 0.0; sitespeed[2] = 0.0;
        }
        if(lbphi[il] != 11) {
          fGetAllMassSite(rho, &lbf[il*lbsitelength]);
          for(int ll=0; ll<3; ll++)
            interforce [ll] = lbinterforce[il*3*lbsy.nf+ll]+lbheatforce[il*3*lbsy.nf+ll]+postequil*(lbbdforce[ll]+lboscilforce[ll]*freq);
          if(lbphi[il] != 12 && lbphi[il] != 13)
            fSiteFluidCollisionBGKEDMSwiftOneFluid(&lbf[il*lbsitelength], sitespeed, &lbomega[il*lbsy.nf], rho, &lbft[4*il], interforce, T);
          fSiteSoluteCollisionBGK(&lbf[il*lbsitelength + lbsy.nf], sitespeed);
          fSiteThermalCollisionBGK(&lbf[il*lbsitelength + lbsy.nf+lbsy.nc], sitespeed);
        }
      }
    }
  }
  return 0;
}

int fCollisionBGKGuoSwift()
{
  long Tmax = lbdm.touter;
  double freq = (lbbdforcetyp==1)*sin(lboscilfreq*(lbcurstep-lbequstep));

  if(lbsy.nf>1) {

   #pragma omp parallel
   {
      double interforce_t[3], sitespeed_t[3], rho_t[lbsy.nf];
      double *interforce = &interforce_t[0];
      double *sitespeed = &sitespeed_t[0];
      double *rho = &rho_t[0];

      #pragma omp for
      for(long il=0; il<Tmax; il++) {
        fGetOneSpeedSite(sitespeed, &lbf[il*lbsitelength]);
        double T = (lbsy.nt>0)?fGetTemperatureSite(il):lbsyst;
        if(lbneigh[il]>0 && lbphi[il]==0) {
          sitespeed[0] = 0.0; sitespeed[1] = 0.0; sitespeed[2] = 0.0;
        }
        if(lbphi[il] != 11) {
          fGetAllMassSite(rho, &lbf[il*lbsitelength]);
          double frac = 0.5*(1.0+rho[1]);
          for(int ll=0; ll<3; ll++)
            interforce [ll] = frac*(lbinterforce[il*3*lbsy.nf+ll]+lbheatforce[il*3*lbsy.nf+ll]+postequil*(lbbdforce[ll]+lboscilforce[ll]*freq))
                            + (1.0-frac)*(lbinterforce[il*3*lbsy.nf+3+ll]+lbheatforce[il*3*lbsy.nf+3+ll]+postequil*(lbbdforce[3+ll]+lboscilforce[3+ll]*freq));
          if(lbphi[il] != 12 && lbphi[il] != 13)
            fSiteFluidCollisionBGKGuoSwiftTwoFluid(&lbf[il*lbsitelength], sitespeed, &lbomega[il*lbsy.nf], rho, &lbft[8*il], interforce, T);
          fSiteSoluteCollisionBGK(&lbf[il*lbsitelength + lbsy.nf], sitespeed);
          fSiteThermalCollisionBGK(&lbf[il*lbsitelength + lbsy.nf+lbsy.nc], sitespeed);
        }
      }
    }
  }
  else {
      
   #pragma omp parallel
   {
      double interforce_t[3], sitespeed_t[3], rho_t[lbsy.nf];
      double *interforce = &interforce_t[0];
      double *sitespeed = &sitespeed_t[0];
      double *rho = &rho_t[0];

      #pragma omp for
      for(long il=0; il<Tmax; il++) {
        fGetOneSpeedSite(sitespeed, &lbf[il*lbsitelength]);
        double T = (lbsy.nt>0)?fGetTemperatureSite(il):lbsyst;
        if(lbneigh[il]>0 && lbphi[il]==0) {
          sitespeed[0] = 0.0; sitespeed[1] = 0.0; sitespeed[2] = 0.0;
        }
        if(lbphi[il] != 11) {
          fGetAllMassSite(rho, &lbf[il*lbsitelength]);
          for(int ll=0; ll<3; ll++)
            interforce [ll] = lbinterforce[il*3*lbsy.nf+ll]+lbheatforce[il*3*lbsy.nf+ll]+postequil*(lbbdforce[ll]+lboscilforce[ll]*freq);
          if(lbphi[il] != 12 && lbphi[il] != 13)
            fSiteFluidCollisionBGKGuoSwiftOneFluid(&lbf[il*lbsitelength], sitespeed, &lbomega[il*lbsy.nf], rho, &lbft[4*il], interforce, T);
          fSiteSoluteCollisionBGK(&lbf[il*lbsitelength + lbsy.nf], sitespeed);
          fSiteThermalCollisionBGK(&lbf[il*lbsitelength + lbsy.nf+lbsy.nc], sitespeed);
        }
      }
    }
  }
  return 0;
}


int fCollisionBGKHeSwift()
{
  long Tmax = lbdm.touter;
  double freq = (lbbdforcetyp==1)*sin(lboscilfreq*(lbcurstep-lbequstep));

  if(lbsy.nf>1) {

   #pragma omp parallel
   {
      double interforce_t[3], sitespeed_t[3], rho_t[lbsy.nf];
      double *interforce = &interforce_t[0];
      double *sitespeed = &sitespeed_t[0];
      double *rho = &rho_t[0];

      #pragma omp for
      for(long il=0; il<Tmax; il++) {
        fGetOneSpeedSite(sitespeed, &lbf[il*lbsitelength]);
        double T = (lbsy.nt>0)?fGetTemperatureSite(il):lbsyst;
        if(lbneigh[il]>0 && lbphi[il]==0) {
          sitespeed[0] = 0.0; sitespeed[1] = 0.0; sitespeed[2] = 0.0;
        }
        if(lbphi[il] != 11) {
          fGetAllMassSite(rho, &lbf[il*lbsitelength]);
          double frac = 0.5*(1.0+rho[1]);
          for(int ll=0; ll<3; ll++)
            interforce [ll] = frac*(lbinterforce[il*3*lbsy.nf+ll]+lbheatforce[il*3*lbsy.nf+ll]+postequil*(lbbdforce[ll]+lboscilforce[ll]*freq))
                            + (1.0-frac)*(lbinterforce[il*3*lbsy.nf+3+ll]+lbheatforce[il*3*lbsy.nf+3+ll]+postequil*(lbbdforce[3+ll]+lboscilforce[3+ll]*freq));
          if(lbphi[il] != 12 && lbphi[il] != 13)
            fSiteFluidCollisionBGKHeSwiftTwoFluid(&lbf[il*lbsitelength], sitespeed, &lbomega[il*lbsy.nf], rho, &lbft[8*il], interforce, T);
          fSiteSoluteCollisionBGK(&lbf[il*lbsitelength + lbsy.nf], sitespeed);
          fSiteThermalCollisionBGK(&lbf[il*lbsitelength + lbsy.nf+lbsy.nc], sitespeed);
        }
      }
    }
  }
  else {
      
   #pragma omp parallel
   {
      double interforce_t[3], sitespeed_t[3], rho_t[lbsy.nf];
      double *interforce = &interforce_t[0];
      double *sitespeed = &sitespeed_t[0];
      double *rho = &rho_t[0];

      #pragma omp for
      for(long il=0; il<Tmax; il++) {
        fGetOneSpeedSite(sitespeed, &lbf[il*lbsitelength]);
        double T = (lbsy.nt>0)?fGetTemperatureSite(il):lbsyst;
        if(lbneigh[il]>0 && lbphi[il]==0) {
          sitespeed[0] = 0.0; sitespeed[1] = 0.0; sitespeed[2] = 0.0;
        }
        if(lbphi[il] != 11) {
          fGetAllMassSite(rho, &lbf[il*lbsitelength]);
          for(int ll=0; ll<3; ll++)
            interforce [ll] = lbinterforce[il*3*lbsy.nf+ll]+lbheatforce[il*3*lbsy.nf+ll]+postequil*(lbbdforce[ll]+lboscilforce[ll]*freq);
          if(lbphi[il] != 12 && lbphi[il] != 13)
            fSiteFluidCollisionBGKHeSwiftOneFluid(&lbf[il*lbsitelength], sitespeed, &lbomega[il*lbsy.nf], rho, &lbft[4*il], interforce, T);
          fSiteSoluteCollisionBGK(&lbf[il*lbsitelength + lbsy.nf], sitespeed);
          fSiteThermalCollisionBGK(&lbf[il*lbsitelength + lbsy.nf+lbsy.nc], sitespeed);
        }
      }
    }
  }
  return 0;
}


