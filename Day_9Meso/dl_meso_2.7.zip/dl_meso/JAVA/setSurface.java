import javax.swing.*;
import java.util.*;
import java.lang.*;
import java.io.*;
import java.awt.*;
import java.awt.event.*;
import java.awt.geom.*;
import java.awt.image.*;
/*
 *     DL_MESO_GUI
 *     author: R. S. Qin, M. A. Seaton
 *     copyright: UKRI STFC Daresbury Laboratory and CCP5
 *     2005, 2018
 */
class setSurface extends JFrame {
    
    setdpdSysEvt surinidpd=new setdpdSysEvt(this);

    JLabel surfacetype = new JLabel("SURFACE TYPE", JLabel.RIGHT);

    JLabel walllabel = new JLabel("wall directions:", JLabel.RIGHT);
    JLabel walloffsetlabel = new JLabel("wall offset:", JLabel.RIGHT);
    JLabel vacuumlabel = new JLabel("vacuum gap (x,y,z):", JLabel.RIGHT);
    JCheckBox xwall = new JCheckBox("x");
    JCheckBox ywall = new JCheckBox("y");
    JCheckBox zwall = new JCheckBox("z");
    JTextField walloffset = new JTextField("0.0", 7);
    JTextField vgapx = new JTextField("0.0", 7);
    JTextField vgapy = new JTextField("0.0", 7);
    JTextField vgapz = new JTextField("0.0", 7);

    JButton save = new JButton("SAVE SF");
    JButton close = new JButton("CANCEL SF");
    Font font=new Font("Dialog", Font.BOLD, 13);
    
    public setSurface(int srft, int sx, int sy, int sz, double walloff, double vgpx, double vgpy, double vgpz) {

        super("DPD surface properties");
        setBounds(160, 10, 400, 220);
        JPanel pane=new JPanel(new GridBagLayout());
        walloffset.setText(Double.toString(walloff));
        vgapx.setText(Double.toString(vgpx));
        vgapy.setText(Double.toString(vgpy));
        vgapz.setText(Double.toString(vgpz));

        switch (srft) {
            case 0:     surfacetype.setText("WALLS OF FROZEN BEADS");
                        vacuumlabel.setFont(font);
                        addItem(pane, vacuumlabel, 0, 1, 1, 1, GridBagConstraints.WEST);
                        addItem(pane, vgapx, 1, 1, 1, 1, GridBagConstraints.WEST);
                        addItem(pane, vgapy, 2, 1, 1, 1, GridBagConstraints.WEST);
                        addItem(pane, vgapz, 3, 1, 1, 1, GridBagConstraints.WEST);
                        break;
            case 1:     surfacetype.setText("LEES-EDWARDS SHEARING PERIODIC BOUNDARIES");
                        walllabel.setFont(font);
                        addItem(pane, walllabel, 0, 1, 1, 1, GridBagConstraints.WEST);
                        Box tickBox = Box.createHorizontalBox();
                        xwall.addActionListener(surinidpd);
                        tickBox.add(xwall);
                        ywall.addActionListener(surinidpd);
                        tickBox.add(ywall);
                        zwall.addActionListener(surinidpd);
                        tickBox.add(zwall);
                        addItem(pane, tickBox, 1, 1, 3, 1, GridBagConstraints.WEST);
                        break;
            case 2:     surfacetype.setText("HARD SURFACES WITH SPECULAR REFLECTION");
                        walllabel.setFont(font);
                        addItem(pane, walllabel, 0, 1, 1, 1, GridBagConstraints.WEST);
                        Box tickBox2 = Box.createHorizontalBox();
                        xwall.addActionListener(surinidpd);
                        tickBox2.add(xwall);
                        ywall.addActionListener(surinidpd);
                        tickBox2.add(ywall);
                        zwall.addActionListener(surinidpd);
                        tickBox2.add(zwall);
                        addItem(pane, tickBox2, 1, 1, 3, 1, GridBagConstraints.WEST);
                        walloffsetlabel.setFont(font);
                        addItem(pane, walloffsetlabel, 0, 2, 1, 1, GridBagConstraints.WEST);
                        addItem(pane, walloffset, 1, 2, 1, 1, GridBagConstraints.WEST);
                        vacuumlabel.setFont(font);
                        addItem(pane, vacuumlabel, 0, 3, 1, 1, GridBagConstraints.WEST);
                        addItem(pane, vgapx, 1, 3, 1, 1, GridBagConstraints.WEST);
                        addItem(pane, vgapy, 2, 3, 1, 1, GridBagConstraints.WEST);
                        addItem(pane, vgapz, 3, 3, 1, 1, GridBagConstraints.WEST);
                        break;
            case 3:     surfacetype.setText("HARD SURFACES WITH BOUNCEBACK REFLECTION");
                        walllabel.setFont(font);
                        addItem(pane, walllabel, 0, 1, 1, 1, GridBagConstraints.WEST);
                        Box tickBox3 = Box.createHorizontalBox();
                        xwall.addActionListener(surinidpd);
                        tickBox3.add(xwall);
                        ywall.addActionListener(surinidpd);
                        tickBox3.add(ywall);
                        zwall.addActionListener(surinidpd);
                        tickBox3.add(zwall);
                        addItem(pane, tickBox3, 1, 1, 3, 1, GridBagConstraints.WEST);
                        walloffsetlabel.setFont(font);
                        addItem(pane, walloffsetlabel, 0, 2, 1, 1, GridBagConstraints.WEST);
                        addItem(pane, walloffset, 1, 2, 1, 1, GridBagConstraints.WEST);
                        vacuumlabel.setFont(font);
                        addItem(pane, vacuumlabel, 0, 3, 1, 1, GridBagConstraints.WEST);
                        addItem(pane, vgapx, 1, 3, 1, 1, GridBagConstraints.WEST);
                        addItem(pane, vgapy, 2, 3, 1, 1, GridBagConstraints.WEST);
                        addItem(pane, vgapz, 3, 3, 1, 1, GridBagConstraints.WEST);
                        break;
        }

        surfacetype.setFont(font);
        addItem(pane, surfacetype, 0, 0, 4, 1, GridBagConstraints.WEST);

        if(sx>0)
          xwall.setSelected(true);
        else
          xwall.setSelected(false);

        if(sy>0)
          ywall.setSelected(true);
        else
          ywall.setSelected(false);

        if(sz>0)
          zwall.setSelected(true);
        else
          zwall.setSelected(false);

        Box buttonBox = Box.createHorizontalBox();
        save.setFont(font);
        save.addActionListener(surinidpd);
        buttonBox.add(save);
        close.setFont(font);
        close.addActionListener(surinidpd);
        buttonBox.add(close);
        addItem(pane, buttonBox, 0, 4, 4, 1, GridBagConstraints.WEST);

        this.add(pane);
        this.pack();
        setVisible(true);
    }

    private void addItem(JPanel p, JComponent c, int x, int y, int width, int height, int align)
    {
        GridBagConstraints gc = new GridBagConstraints();
        gc.gridx = x;
        gc.gridy = y;
        gc.gridwidth = width;
        gc.gridheight = height;
        gc.weightx = 100.0;
        gc.weighty = 100.0;
        gc.insets = new Insets(5, 5, 5, 5);
        gc.anchor = align;
        gc.fill = GridBagConstraints.NONE;
        p.add(c, gc);
    }

}
