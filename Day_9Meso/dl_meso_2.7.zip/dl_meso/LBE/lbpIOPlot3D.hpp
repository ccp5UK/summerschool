int fOutputGrid(const char* filename);
int fsOutputGrid(const char* filename);

int fOutputQ(const char* filename);
int fsOutputQ(const char* filename);

int fOutputQP(const char* filename, int iprop);
int fsOutputQP(const char* filename, int iprop);

int fOutputQCA(const char* filename, int iprop);
int fsOutputQCA(const char* filename, int iprop);

int fOutputQCB(const char* filename, int iprop);
int fsOutputQCB(const char* filename, int iprop);

int fOutputQT(const char* filename);
int fsOutputQT(const char* filename);
