#include <iostream>
#include <fstream>
#include <cstdlib>
#include <ctime>
#include <cstdio>
#include <cmath>
#include <iomanip>
#include <string>
#include <cstring>
#include <sstream>
#include <vector>
#include <sys/time.h>
#include <sys/stat.h>
#ifdef _OPENMP
#include <omp.h>
#else
#define omp_get_num_thread() 1
#define omp_get_thread_num() 0
#endif
#include <mpi.h>
using namespace std;

/*
  DL_MESO_LBE
  Author    :   R.S. Qin, M. A. Seaton
  Copyright :   STFC Daresbury Laboratory
            :   05/11/2004, rev. 09/12/2018

*/

#include "lbe.hpp"


struct sNeighbour
{
  int rank;
  unsigned long int spos;
  unsigned long int rpos;
  unsigned long int bspos;
  unsigned long int brpos;
  unsigned long int fspos;
  unsigned long int frpos;
  unsigned long int ispos;
  unsigned long int irpos;
//  unsigned long int kspos;
//  unsigned long int krpos;
  unsigned long int nspos;
  unsigned long int nrpos;
};
sNeighbour lbnb[6];

typedef struct
{
    int rank;
    int cartCoords[3];
    int size;
    int rootRank;
    int rootSize;
    int groupId;
    int cartStart[3];
    int cartEnd[3];
    int gridStartGlobal[3];
    int gridEndGlobal[3];
    int subgrid[3];
    int *sortpoint;
    MPI_Comm cartCommunicator;
    MPI_Comm ioCommunicator;
}
sIOGroup;

sIOGroup lbIOGroup;
MPI_Comm ioRootCommunicator;
MPI_File output_handle;
MPI_File dump_handle;

// messages to be communicated 
MPI_Datatype lbmsg2x; 
MPI_Datatype lbmsg2y; 
MPI_Datatype lbmsg3x; 
MPI_Datatype lbmsg3y; 
MPI_Datatype lbmsg3z; 
MPI_Datatype lbbmsg2x; 
MPI_Datatype lbbmsg2y; 
MPI_Datatype lbbmsg3x; 
MPI_Datatype lbbmsg3y; 
MPI_Datatype lbbmsg3z;
MPI_Datatype lbfmsg2x; 
MPI_Datatype lbfmsg2y; 
MPI_Datatype lbfmsg3x; 
MPI_Datatype lbfmsg3y; 
MPI_Datatype lbfmsg3z;
MPI_Datatype lbimsg2x; 
MPI_Datatype lbimsg2y; 
MPI_Datatype lbimsg3x; 
MPI_Datatype lbimsg3y; 
MPI_Datatype lbimsg3z;
MPI_Datatype lbkmsg2x;
MPI_Datatype lbkmsg2y;
MPI_Datatype lbkmsg3x;
MPI_Datatype lbkmsg3y;
MPI_Datatype lbkmsg3z;
MPI_Datatype lbnmsg2x;
MPI_Datatype lbnmsg2y;
MPI_Datatype lbnmsg3x;
MPI_Datatype lbnmsg3y;
MPI_Datatype lbnmsg3z;

#ifdef Packbuf
double *recvbuf_0_x, *recvbuf_1_x, *sendbuf_0_x,  *sendbuf_1_x ;
double *recvbuf_0_y, *recvbuf_1_y, *sendbuf_0_y,  *sendbuf_1_y ;
double *recvbuf_0_z, *recvbuf_1_z, *sendbuf_0_z,  *sendbuf_1_z ;
#endif

#include "lbpBASIC.hpp"
#include "lbpGET.hpp"
#include "lbpMPI.hpp"
#include "lbpIOAGGPAR.hpp"
#include "lbpMODEL.hpp"
#include "lbpIO.hpp"
#include "lbpIOPlot3D.hpp"
#include "lbpIOLegacyVTK.hpp"
#include "lbpIOVTK.hpp"
#include "lbpFORCE.hpp"
#include "lbpRHEOLOGY.hpp"
#include "lbpBGK.hpp"
#include "lbpTRT.hpp"
#include "lbpMRT.hpp"
#include "lbpCLBE.hpp"
#include "lbpSUB.hpp"
#include "lbpBOUND.hpp"
#include "lbpBOUNDZouHe.hpp"
#include "lbpBOUNDInamuro.hpp"
#include "lbpBOUNDRegular.hpp"
#include "lbpBOUNDKinetic.hpp"
#include "lbpUSER.hpp"
#include "lbpRUNPAR.hpp"
#include "lbpBASIC.cpp"
#include "lbpGET.cpp"
#include "lbpMPI.cpp"
#include "lbpIOAGGPAR.cpp"
#include "lbpMODEL.cpp"
#include "lbpIO.cpp"
#include "lbpIOPlot3D.cpp"
#include "lbpIOLegacyVTK.cpp"
#include "lbpIOVTK.cpp"
#include "lbpFORCE.cpp"
#include "lbpRHEOLOGY.cpp"
#include "lbpBGK.cpp"
#include "lbpTRT.cpp"
#include "lbpMRT.cpp"
#include "lbpCLBE.cpp"
#include "lbpSUB.cpp"
#include "lbpBOUND.cpp"
#include "lbpBOUNDZouHe.cpp"
#include "lbpBOUNDInamuro.cpp"
#include "lbpBOUNDRegular.cpp"
#include "lbpBOUNDKinetic.cpp"
#include "lbpUSER.cpp"
#include "lbpRUNPAR.cpp"
