import javax.swing.*;
import java.util.*;
import java.lang.*;
import java.io.*;
import java.awt.*;
import java.awt.event.*;
import java.awt.geom.*;
import java.awt.image.*;
/*
 *     DL_MESO_GUI
 *     author: R. S. Qin, W. Smith and M. A. Seaton 2006, 2018
 *     copyright: UKRI STFC Daresbury Laboratory and CCP5
 */
class compiledpdEvt implements ItemListener, ActionListener {
    compiledpd gui;
    static String str0, str1="fortran90 compiler", str2, str3="source-file", str4, str5, str6, str7, str8, str9, filename="Makefile";
    static Boolean altcomp=false,ompcomp=false;
    FileWriter fw;
    static int istate=0;
    private static String OS = System.getProperty("os.name").toLowerCase();
    public compiledpdEvt(compiledpd in){
        gui = in;
    }
    public void actionPerformed(ActionEvent event) {
	String cmd =event.getActionCommand();
        if (cmd == "Create Makefile"){
           makefilemake();
        }
        else if (cmd == "COMPILE"){
            str3 = "make -f "+filename;
	    try {		
            Process p2 = Runtime.getRuntime().exec(str3);
            BufferedReader ou2 = new BufferedReader
		    (new InputStreamReader(p2.getErrorStream()));
            String line2;
            while ((line2 = ou2.readLine()) != null)
                System.err.println(line2);
                gui.lb1.setEnabled(false);
                gui.lb2.setEnabled(false);
                gui.lb3.setEnabled(false);
                gui.lb4.setEnabled(false);
                gui.comflag.setEnabled(false);
                gui.comp.setEnabled(false);
                gui.code.setEnabled(false);
                gui.compilealt.setEnabled(false);
                gui.compilealt.setEditable(false);
                gui.compileflag.setEnabled(false);
                gui.compileflag.setEditable(false);
                gui.fft.setEnabled(false);
                gui.fftalt.setEnabled(false);
                gui.fftalt.setEditable(false);
                gui.making.setEnabled(false);
                gui.compile.setEnabled(false);
                ierr(" dpd.exe created successfully ");
            } catch (IOException e1) {
                ierr(" "+str1+": not found");
            }
        }
    }

    public void itemStateChanged(ItemEvent event) {
        Object item=event.getItem();
        String answer=item.toString();
        if(answer == "gfortran") {
            str1="gfortran";
            altcomp=false;
            gui.ompcompileflag.setText("-fopenmp");
        }
        else if(answer == "ifort") {
            str1="ifort";
            altcomp=false;
            gui.ompcompileflag.setText("-openmp");
        }
        else if(answer == "bgxlf90") {
            str1="bgxlf90";
            altcomp=false;
            gui.ompcompileflag.setText("-qsmp=omp");
        }
        else if(answer == "mpif90") {
            str1="mpif90";
            altcomp=false;
            gui.ompcompileflag.setText("-fopenmp");
        }
        else if(answer == "mpifort") {
            str1="mpifort";
            altcomp=false;
            gui.ompcompileflag.setText("-fopenmp");
        }
        else if(answer == "ftn") {
            str1="ftn";
            altcomp=false;
            gui.ompcompileflag.setText("-openmp");
        }
        else if(answer == "ftn95") {
            str1="ftn95";
            altcomp=false;
            gui.ompcompileflag.setText("-openmp");
        }
        else if(answer == "other ...")
            altcomp = true;
        else if(answer == "serial code") {
            str2 = "_ser.f90";
            str5 = ".f90";
            ompcomp = false;
        }
        else if(answer == "serial code with OpenMP") {
            str2 = "_ser.f90";
            str5 = "_omp.f90";
            ompcomp = true;
        }
        else if(answer == "parallel code") {
            str2 = ".f90";
            str5 = ".f90";
            ompcomp = false;
        }
        else if(answer == "parallel code with OpenMP") {
            str2 = ".f90";
            str5 = "_omp.f90";
            ompcomp = true;
        }
        else if(answer == "DL_MESO default") {
            str7 = "";
            gui.fftcompile.setText("");
            gui.fftlink.setText("");
            gui.fftalt.setEnabled(false);
            gui.fftalt.setEditable(false);
        }
        else if(answer == "ESSL") {
            str7 = " -DESSL";
            gui.fftcompile.setText("-qessl");
            gui.fftlink.setText("");
            gui.fftalt.setEnabled(false);
            gui.fftalt.setEditable(false);
        }
        else if(answer == "FFTW") {
            str7 = " -DFFTW";
            gui.fftcompile.setText("");
            gui.fftlink.setText("-lfftw3");
            gui.fftalt.setEnabled(false);
            gui.fftalt.setEditable(false);
        }
        else if(answer == "other FFT solver") {
            str7 = "";
            gui.fftcompile.setText("");
            gui.fftlink.setText("");
            gui.fftalt.setEnabled(true);
            gui.fftalt.setEditable(true);
        }
    }

    public void makefilemake() {
	try {
            if(istate == 0){
                fw = new FileWriter(filename, false);
                istate =1;
            }
            else
                fw = new FileWriter(filename, true);
        } catch (IOException e) {
            ierr(" cannot create "+filename+" ");
        }
	
	try {
            if (altcomp)
                str1 = gui.compilealt.getText();
            str4 = gui.compileflag.getText();
            if(str4.length()>0)
                str4 = " "+str4;
            if (isWindows ())
                str0 = "..\\DPD\\";
            else if (isMac () || isUnix ())
                str0 = "../DPD/";
            if(ompcomp)
                str6 = " "+gui.ompcompileflag.getText();
            else
                str6 = "";
            if(gui.fftalt.isEditable())
                str7 = " "+gui.fftalt.getText();
            if(gui.fftcompile.equals(""))
                str8 = "";
            else
                str8 = " "+gui.fftcompile.getText();
            if(gui.fftlink.equals(""))
                str9 = "";
            else
                str9 = " "+gui.fftlink.getText();
            fw.write("MF=      Makefile\n\n");
            fw.write("FC=      "+str1+"\n");
            fw.write("FFLAGS=  "+str4+str6+str7+str8+"\n");
            fw.write("LFLAGS=  $(FFLAGS)\n\n");
            fw.write("EXE=     dpd.exe\n\n");
            fw.write("VPATH=   "+str0+"\n\n");
            fw.write("SRC= \\\n");
            fw.write("         constants.f90  \\\n");
            fw.write("         variables.f90  \\\n");
            fw.write("         numeric_container"+str5+"  \\\n");
            fw.write("         comms_module"+str2+"  \\\n");
            fw.write("         error_module.f90  \\\n");
            fw.write("         parse_utils.f90  \\\n");
            fw.write("         bond_module"+str5+"  \\\n");
            fw.write("         surface_module.f90  \\\n");
            fw.write("         domain_module"+str2+"  \\\n");
            fw.write("         read_module.f90  \\\n");
            fw.write("         write_module.f90  \\\n");
            fw.write("         manybody_module"+str5+"  \\\n");
            fw.write("         ewald_module"+str5+"  \\\n");
            fw.write("         spme_module"+str5+"  \\\n");
            fw.write("         start_module.f90  \\\n");
            fw.write("         config_module.f90  \\\n");
            fw.write("         field_module"+str5+"  \\\n");
            fw.write("         integrate_dpd_mdvv.f90  \\\n");
            fw.write("         integrate_dpd_dpdvv.f90  \\\n");
            fw.write("         integrate_dpd_shardlow.f90  \\\n");
            fw.write("         integrate_lowe.f90  \\\n");
            fw.write("         integrate_peters.f90  \\\n");
            fw.write("         integrate_stoyanov.f90  \\\n");
            fw.write("         statistics_module.f90  \\\n");
            fw.write("         run_module.f90  \\\n");
            fw.write("         dlmesodpd"+str5+"\n\n");
            fw.write(".SUFFIXES:\n");
            fw.write(".SUFFIXES: .f90 .o\n\n");
            fw.write("OBJ=\t$(SRC:.f90=.o)\n\n");
            fw.write(".f90.o:\n");
            fw.write("\t$(FC) $(FFLAGS) -c $<\n\n");
            fw.write("all:\t$(EXE)\n\n");
            fw.write("$(EXE):\t$(OBJ)\n");
            fw.write("\t$(FC) $(LFLAGS) -o $@ $(OBJ)"+str9+"\n\n");
            fw.write("$(OBJ):\t$(MF)\n\n");
            fw.write("tar:\n");
            fw.write("\ttar cvf $(EXE).tar $(MF) $(SRC)\n\n");
            fw.write("clean:\n");
            fw.write("\trm -f $(OBJ) $(EXE) *.mod core\n");

//	    System.out.println("\n"+filename+" file completed");
        } catch (IOException e) {
            ierr(" error when saving "+filename+" ");
            System.out.println("Exception: "+e.getMessage());
        }
        try {
            fw.close();
        } catch (IOException e) {
            ierr(" error when closing "+filename+" ");
            System.out.println("Exception: "+e.getMessage());
        }
    }

    void ierr(String errinfo) {
      msgPanel fcer=new msgPanel(errinfo);
    }

    public static boolean isWindows() {
        return (OS.indexOf("win") >= 0);
    }
    
    public static boolean isMac() {
        return (OS.indexOf("mac") >= 0);
    }
    
    public static boolean isUnix() {
        return (OS.indexOf("nix") >= 0 || OS.indexOf("nux") >= 0 || OS.indexOf("aix") >= 0 || OS.indexOf("sunos") >= 0 );
    }
    
}
