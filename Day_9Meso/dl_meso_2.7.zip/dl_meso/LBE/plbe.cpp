#include "plbe.hpp"

int main(int argc, char** argv)
{
  bigend = fBigEndian();
  lbcurstep = 0;
  fStartMPI(argc, argv);
  fDefineSystem("lbin.sys");
  fDefineDomain();
  fStartDLMESO();
  fMemoryAllocation();
  fGetModel();
  fDefineNeighbours();
  fDefineMessage();
  fPrintSystemInfo();
  fAllReady();
  fPrintDomainInfo();
  fAllReady();
  fInputParameters("lbin.sys");
  fPrintParameters();
  fReadSpaceParameter("lbin.spa");
  fCreateIOGroups();
  fNeighbourBoundary();
  fBoundNonBlockCommunication();
  fMarkBoundArea();
  if(lbrestart>0) {
    fReadRestart("lbout.dump");
    if(postequil>0) {
      fReadSpaceParameter();
      fBoundNonBlockCommunication();
      fNeighbourBoundary();
      fMarkBoundArea();
    }
  }
  else {
    fInitializeSystem();
    fReadInitialState("lbin.init");
  }
  fAllReady();
  fOutputInfo();
  if(outformat==2)  // Grid for Plot3D output files
    fOutputGrid();  
  if(interact==1 || interact==2)
    fCalcPotential_ShanChen();
  timetotal=fCheckTimeMPI();
  switch (interact) {
    case 0:
    // no mesoscopic interactions
      fNoInteract();
      break;
    case 1:
    // Shan/Chen pseudopotential interactions
      fShanChen();
      break;
    case 2:
    // Shan/Chen pseudopotential interactions with quadratic pseudopotential term
      fShanChenQuadratic();
      break;
    case 10:
    // Lishchuk continuum-based interactions (with interfacial normals determined non-locally)
      fLishchuk();
      break;
    case 11:
    // Lishchuk-Spencer continuum-based interactions (with interfacial normals determined non-locally)
      fLishchukSpencer();
      break;
    case 12:
    // Lishchuk-Spencer-tensor continuum-based interactions (with interfacial normals determined non-locally)
      fLishchukSpencerTensor();
      break;
    case 13:
    // Lishchuk continuum-based interactions (with interfacial normals determined locally)
      fLishchukLocal();
      break;
    case 20:
    // Swift free-energy interactions
      fSwift();
      break;
  }
  if(lbcurstep<=lbtotstep) {
    fWriteRestart();
    if(lbcurstep==lbtotstep) lbcurstep -= 1;
    fPrintEarlyTermination();
  }
  timetotal=fCheckTimeMPI();
  fFreeMemory();
  fFinishDLMESO();
  fCloseMPI();
  return 0;
}

