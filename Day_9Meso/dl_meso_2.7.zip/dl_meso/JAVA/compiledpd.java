import javax.swing.*;
import java.util.*;
import java.lang.*;
import java.io.*;
import java.awt.*;
import java.awt.event.*;
import java.awt.geom.*;
import java.awt.image.*;
/*
 *     DL_MESO_GUI
 *     author: R. S. Qin, W. Smith and M. A. Seaton 2006, 2018
 *     copyright: UKRI STFC Daresbury Laboratory and CCP5
 */
class compiledpd extends JPanel {
    compiledpdEvt cdpd = new compiledpdEvt(this); 

    Font font=new Font("Dialog", Font.BOLD, 12);
    Color paneltop=new Color(170, 170, 230);

    Color bgcolorc=new Color(200, 200, 190);
    Color focolorc=new Color(30, 20, 30);

    JLabel lb1 = new JLabel("Step 1:");
    JLabel lb2 = new JLabel("Step 2:");
    JLabel lb3 = new JLabel("Step 3:");
    JLabel lb4 = new JLabel("Step 4:");
    JLabel lb5 = new JLabel("Step 5:");
    JLabel comflag = new JLabel("Flags:");
    JLabel ompcomflag = new JLabel("OpenMP flags:");
    JLabel fftcomflag = new JLabel("FFT solver compile flags:");
    JLabel fftlinkflag = new JLabel("FFT solver linker flags:");
    JComboBox<String> comp= new JComboBox<String>();
    JComboBox<String> code= new JComboBox<String>();
    JComboBox<String> fft= new JComboBox<String>();
    JTextField compilealt = new JTextField(10);  
    JTextField compileflag = new JTextField("-O3", 22);
    JTextField ompcompileflag = new JTextField("-openmp", 22);
    JTextField fftalt = new JTextField(10);
    JTextField fftcompile = new JTextField(22);
    JTextField fftlink = new JTextField(22);
    JButton making = new JButton("Create Makefile");
    JButton compile = new JButton("COMPILE");
    public JTextField compilerflags;

    JLabel info1 = new JLabel("The code can also be compiled at a command-line");

    public compiledpd() {
	setSize(620, 530);
        JPanel panel1 = new JPanel();
        panel1.setLayout(new GridBagLayout());

        comp.addItem("Choose Compiler");
        comp.addItem("gfortran");
        comp.addItem("ifort");
        comp.addItem("bgxlf90");
        comp.addItem("mpif90");
        comp.addItem("mpifort");
        comp.addItem("ftn");
        comp.addItem("ftn95");
        comp.addItem("other ...");
        comp.setFont(font);
        comp.addItemListener(cdpd);
        code.addItem("Code");
        code.addItem("parallel code");
        code.addItem("parallel code with OpenMP");
        code.addItem("serial code");
        code.addItem("serial code with OpenMP");
        code.setFont(font);
        code.addItemListener(cdpd);
        fft.addItem("FFT solver");
        fft.addItem("DL_MESO default");
        fft.addItem("ESSL");
        fft.addItem("FFTW");
        fft.addItem("other FFT solver");
        fft.setFont(font);
        fft.addItemListener(cdpd);
        making.setFont(font);
        making.addActionListener(cdpd);
        compile.setFont(font);
        compile.addActionListener(cdpd);

        addItem(panel1, new JLabel(" "), 0, 0, 4, 1, GridBagConstraints.CENTER);

        addItemSpacing(panel1, lb1, 0, 1, 1, 1, GridBagConstraints.EAST, 30, 5);
        addItemSpacing(panel1, comp, 1, 1, 2, 1, GridBagConstraints.WEST, 30, 5);
        addItemSpacing(panel1, compilealt, 3, 1, 1, 1, GridBagConstraints.WEST, 30, 5);
        addItemSpacing(panel1, comflag, 2, 2, 1, 1, GridBagConstraints.EAST, 5, 5);
        addItemSpacing(panel1, compileflag, 3, 2, 1, 1, GridBagConstraints.CENTER, 5, 5);
        addItemSpacing(panel1, ompcomflag, 2, 3, 1, 1, GridBagConstraints.EAST, 5, 30);
        addItemSpacing(panel1, ompcompileflag, 3, 3, 1, 1, GridBagConstraints.CENTER, 5, 30);

        addItemSpacing(panel1, lb2, 0, 4, 1, 1, GridBagConstraints.EAST, 2, 30);
        addItemSpacing(panel1, code, 1, 4, 3, 1, GridBagConstraints.WEST, 2, 30);
        
        addItemSpacing(panel1, lb3, 0, 5, 1, 1, GridBagConstraints.EAST, 30, 5);
        addItemSpacing(panel1, fft, 1, 5, 2, 1, GridBagConstraints.WEST, 30, 5);
        addItemSpacing(panel1, fftalt, 3, 5, 1, 1, GridBagConstraints.WEST, 30, 5);
        addItemSpacing(panel1, fftcomflag, 2, 6, 1, 1, GridBagConstraints.EAST, 5, 5);
        addItemSpacing(panel1, fftcompile, 3, 6, 1, 1, GridBagConstraints.WEST, 5, 5);
        addItemSpacing(panel1, fftlinkflag, 2, 7, 1, 1, GridBagConstraints.EAST, 5, 30);
        addItemSpacing(panel1, fftlink, 3, 7, 1, 1, GridBagConstraints.WEST, 5, 30);
        
        addItem(panel1, lb4, 0, 8, 1, 1, GridBagConstraints.EAST);
        addItem(panel1, making, 1, 8, 3, 1, GridBagConstraints.WEST);

        addItem(panel1, lb5, 0, 9, 1, 1, GridBagConstraints.EAST);
        addItem(panel1, compile, 1, 9, 3, 1, GridBagConstraints.WEST);

        addItem(panel1, info1, 0, 10, 4, 1, GridBagConstraints.CENTER);

        this.add(panel1);
    }

    private void addItem(JPanel p, JComponent c, int x, int y, int width, int height, int align)
    {
        GridBagConstraints gc = new GridBagConstraints();
        gc.gridx = x;
        gc.gridy = y;
        gc.gridwidth = width;
        gc.gridheight = height;
        gc.weightx = 100.0;
        gc.weighty = 100.0;
        gc.insets = new Insets(30, 5, 30, 5);
        gc.anchor = align;
        gc.fill = GridBagConstraints.NONE;
        p.add(c, gc);
    }

    private void addItemSpacing(JPanel p, JComponent c, int x, int y, int width, int height, int align, int inset1, int inset2)
    {
        GridBagConstraints gc = new GridBagConstraints();
        gc.gridx = x;
        gc.gridy = y;
        gc.gridwidth = width;
        gc.gridheight = height;
        gc.weightx = 100.0;
        gc.weighty = 100.0;
        gc.insets = new Insets(inset1, 5, inset2, 5);
        gc.anchor = align;
        gc.fill = GridBagConstraints.VERTICAL;
        p.add(c, gc);
    }


}
