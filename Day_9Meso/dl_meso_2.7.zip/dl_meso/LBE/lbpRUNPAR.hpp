int fNoInteract();
int fShanChen();
int fShanChenQuadratic();
int fLishchuk();
int fLishchukSpencer();
int fLishchukSpencerTensor();
int fLishchukLocal();
int fSwift();
