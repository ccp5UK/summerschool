/***************************************************
 *   DL_MESO       Version 2.7                     *
 *   Authors   :   R. S. Qin, M. A. Seaton         *
 *   Amended   :   L. Grinberg                     *
 *   Copyright :   UKRI STFC Daresbury Laboratory  *
 *             :   09/12/2018                      *
 ***************************************************/

double fTRTOmegaAntisymmetric(double omegasymmetric, double magic)
{
  // calculate TRT antisymmetric relaxation frequency using symmetric
  // relaxation frequency and 'magic number':

  // magic number = (tau^{+} - 0.5)*(tau^{-} - 0.5)

  double topbit = 2.0 * (2.0 - omegasymmetric);
  double bottombit = omegasymmetric * (4.0 * magic - 1.0) + 2.0;
    
  return (topbit/bottombit);
    
}

// Standard fluid collisions

int fSiteFluidCollisionTRT(double* startpos, double *sitespeed, double *omega, double *rho, double* bodyforce)
{
  
  // calculate fluid collisions at grid point: uses two relaxation time scheme

  double speed[3], feq[lbsy.nq], collneg[lbsy.nq];
  double invmassrelax, relax, omeganeg, omegaplus, omegaminus;
  double *pt2 = &startpos[0];
  double *pt3 = &bodyforce[0];
  int qdim = lbsy.nf+lbsy.nc+lbsy.nt;

  for(int j=0; j<lbsy.nf; j++) {
    invmassrelax = fReciprocal(rho[j] * omega[j]);
    omeganeg = fTRTOmegaAntisymmetric(omega[j], lbtrtmagic);
    omegaplus = 0.5 * (omega[j] + omeganeg);
    omegaminus = 0.5 * (omega[j] - omeganeg);
    relax = 1.0 - omegaplus;
    speed[0] = sitespeed[0] + pt3[3*j]   * invmassrelax;
    speed[1] = sitespeed[1] + pt3[3*j+1] * invmassrelax;
    speed[2] = sitespeed[2] + pt3[3*j+2] * invmassrelax;
    fGetEquilibriumF(&feq[0], speed, rho[j]);
    for(int i=0; i<lbsy.nq; i++) {
      collneg[i] = feq[i] - pt2[i*qdim+j];
    }
    for(int i=0; i<lbsy.nq; i++){
      int k = lbopv[i];
      pt2[i*qdim+j] = relax * pt2[i*qdim+j] + feq[i]*omegaplus + collneg[k]*omegaminus;
    }
  }

  pt2 = NULL;
  pt3 = NULL;  
  return 0;
}

int fSiteFluidIncomCollisionTRT(double* startpos, double *sitespeed, double *omega, double *rho, double* bodyforce)
{
  
  // calculate fluid collisions at grid point: uses two relaxation time scheme
  // with incompressible fluids

  double speed[3], feq[lbsy.nq], collneg[lbsy.nq];
  double density, invmassrelax, relax, omeganeg, omegaplus, omegaminus;
  double *pt2 = &startpos[0];
  double *pt3 = &bodyforce[0];
  int qdim = lbsy.nf+lbsy.nc+lbsy.nt;

  for(int j=0; j<lbsy.nf; j++) {
    density = lbincp[j];
    invmassrelax = fReciprocal(density * omega[j]);
    omeganeg = fTRTOmegaAntisymmetric(omega[j], lbtrtmagic);
    omegaplus = 0.5 * (omega[j] + omeganeg);
    omegaminus = 0.5 * (omega[j] - omeganeg);
    relax = 1.0 - omegaplus;
    speed[0] = sitespeed[0] + pt3[3*j]   * invmassrelax;
    speed[1] = sitespeed[1] + pt3[3*j+1] * invmassrelax;
    speed[2] = sitespeed[2] + pt3[3*j+2] * invmassrelax;
    fGetEquilibriumFIncom(&feq[0], speed, rho[j], density);
    for(int i=0; i<lbsy.nq; i++) {
      collneg[i] = feq[i] - pt2[i*qdim+j];
    }
    for(int i=0; i<lbsy.nq; i++){
      int k = lbopv[i];
      pt2[i*qdim+j] = relax * pt2[i*qdim+j] + feq[i]*omegaplus + collneg[k]*omegaminus;
    }
  }

  pt2 = NULL;
  pt3 = NULL;  
  return 0;
}

int fSiteFluidCollisionTRTEDM(double* startpos, double *sitespeed, double *omega, double *rho, double* bodyforce)
{
  
  // calculate fluid collisions at grid point: uses two relaxation time scheme with
  // Exact Difference Method forcing term

  double dv[3], feq[lbsy.nq], collneg[lbsy.nq];
  double invmass, relax, source, omeganeg, omegaplus, omegaminus;
  double modv,eixux,eiyuy,eizuz,eixdux,eiyduy,eizduz;
  double *pt2 = &startpos[0];
  double *pt3 = &bodyforce[0];
  int qdim = lbsy.nf+lbsy.nc+lbsy.nt;

  for(int j=0; j<lbsy.nf; j++) {
    invmass = fReciprocal(rho[j]);
    omeganeg = fTRTOmegaAntisymmetric(omega[j], lbtrtmagic);
    dv[0] = pt3[3*j]   * invmass;
    dv[1] = pt3[3*j+1] * invmass;
    dv[2] = pt3[3*j+2] * invmass;
    fGetEquilibriumF(&feq[0], sitespeed, rho[j]);
    omegaplus = 0.5 * (omega[j] + omeganeg);
    omegaminus = 0.5 * (omega[j] - omeganeg);
    relax = 1.0 - omegaplus;
    modv = dv[0]*(2.0*sitespeed[0]+dv[0]) + dv[1]*(2.0*sitespeed[1]+dv[1]) + dv[2]*(2.0*sitespeed[2]+dv[2]);
    for(int i=0; i<lbsy.nq; i++) {
      collneg[i] = feq[i] - pt2[i*qdim+j];
    }
    for(int i=0; i<lbsy.nq; i++){
      int k = lbopv[i];
      eixux =  lbvx[i]*sitespeed[0];
      eiyuy =  lbvy[i]*sitespeed[1];
      eizuz =  lbvz[i]*sitespeed[2];
      eixdux = lbvx[i]*dv[0];
      eiyduy = lbvy[i]*dv[1];
      eizduz = lbvz[i]*dv[2];
      source = rho[j] * lbw[i] * (3.0 * (eixdux+eiyduy+eizduz) +
                                  4.5 * (eixdux*(eixdux+2.0*(eixux+eiyuy+eizuz+eiyduy+eizduz)) +
                                         eiyduy*(eiyduy+2.0*(eixux+eiyuy+eizuz+eizduz)) +
                                         eizduz*(eizduz+2.0*(eixux+eiyuy+eizuz))) -
                                  1.5 * modv);
      pt2[i*qdim+j] = relax * pt2[i*qdim+j] + source + feq[i]*omegaplus + collneg[k]*omegaminus;
    }
  }

  pt2 = NULL;
  pt3 = NULL;  
  return 0;
}

int fSiteFluidIncomCollisionTRTEDM(double* startpos, double *sitespeed, double *omega, double *rho, double* bodyforce)
{
  
  // calculate fluid collisions at grid point: uses two relaxation time scheme
  // with incompressible fluids and Exact Difference Method forcing term

  double dv[3], feq[lbsy.nq], collneg[lbsy.nq];
  double density, invmass, relax, source, omeganeg, omegaplus, omegaminus;
  double modv,eixux,eiyuy,eizuz,eixdux,eiyduy,eizduz;
  double *pt2 = &startpos[0];
  double *pt3 = &bodyforce[0];
  int qdim = lbsy.nf+lbsy.nc+lbsy.nt;

  for(int j=0; j<lbsy.nf; j++) {
    density = lbincp[j];
    invmass = fReciprocal(density);
    omeganeg = fTRTOmegaAntisymmetric(omega[j], lbtrtmagic);
    omegaplus = 0.5*(omega[j]+omeganeg);
    omegaminus = 0.5*(omega[j]-omeganeg);
    relax = 1.0 - omegaplus;
    dv[0] = pt3[3*j]   * invmass;
    dv[1] = pt3[3*j+1] * invmass;
    dv[2] = pt3[3*j+2] * invmass;
    fGetEquilibriumFIncom(&feq[0], sitespeed, rho[j], density);
    modv = dv[0]*(2.0*sitespeed[0]+dv[0]) + dv[1]*(2.0*sitespeed[1]+dv[1]) + dv[2]*(2.0*sitespeed[2]+dv[2]);
    for(int i=0; i<lbsy.nq; i++) {
      collneg[i] = feq[i] - pt2[i*qdim+j];
    }
    for(int i=0; i<lbsy.nq; i++){
      int k = lbopv[i];
      eixux =  lbvx[i]*sitespeed[0];
      eiyuy =  lbvy[i]*sitespeed[1];
      eizuz =  lbvz[i]*sitespeed[2];
      eixdux = lbvx[i]*dv[0];
      eiyduy = lbvy[i]*dv[1];
      eizduz = lbvz[i]*dv[2];
      source = density * lbw[i] * (3.0 * (eixdux+eiyduy+eizduz) +
                                   4.5 * (eixdux*(eixdux+2.0*(eixux+eiyuy+eizuz+eiyduy+eizduz)) +
                                          eiyduy*(eiyduy+2.0*(eixux+eiyuy+eizuz+eizduz)) +
                                          eizduz*(eizduz+2.0*(eixux+eiyuy+eizuz))) -
                                   1.5 * modv);
      pt2[i*qdim+j] = relax * pt2[i*qdim+j] + source + feq[i]*omegaplus + collneg[k]*omegaminus;
    }
  }

  pt2 = NULL;
  pt3 = NULL;  
  return 0;
}

int fSiteFluidCollisionTRTGuo(double* startpos, double *sitespeed, double *omega, double *rho, double* bodyforce)
{
    
  // calculate fluid collisions at grid point: uses two relaxation time scheme with
  // Guo forcing term
    
  double speed[3], force[3], feq[lbsy.nq], collneg[lbsy.nq], source[lbsy.nq];
  double udot, invmass, relax, halfrelax, ex, ey, ez, omeganeg, omegaplus, omegaminus;
  double *pt2 = &startpos[0];
  double *pt3 = &bodyforce[0];
  int qdim = lbsy.nf+lbsy.nc+lbsy.nt;

  for(int j=0; j<lbsy.nf; j++) {
    invmass = fReciprocal(rho[j]);
    force[0] = pt3[3*j];
    force[1] = pt3[3*j+1];
    force[2] = pt3[3*j+2];
    speed[0] = sitespeed[0] + 0.5 * force[0] * invmass;
    speed[1] = sitespeed[1] + 0.5 * force[1] * invmass;
    speed[2] = sitespeed[2] + 0.5 * force[2] * invmass;
    fGetEquilibriumF(&feq[0], speed, rho[j]);
    omeganeg = fTRTOmegaAntisymmetric(omega[j], lbtrtmagic);
    omegaplus = 0.5*(omega[j]+omeganeg);
    omegaminus = 0.5*(omega[j]-omeganeg);
    relax = 1.0 - omegaplus;
    halfrelax = 1.0 - 0.5*omegaplus;
    for(int i=0; i<lbsy.nq; i++){
      ex = lbvx[i];
      ey = lbvy[i];
      ez = lbvz[i];
      udot = ex * speed[0] + ey * speed[1] + ez * speed[2];
      source[i] = (3.0*(ex-speed[0]) + 9.0*udot*ex) * force[0]
                + (3.0*(ey-speed[1]) + 9.0*udot*ey) * force[1]
                + (3.0*(ez-speed[2]) + 9.0*udot*ez) * force[2];
      collneg[i] = feq[i] - pt2[i*qdim+j];
    }
    for(int i=0; i<lbsy.nq; i++) {
      int k = lbopv[i];
      pt2[i*qdim+j] = relax*pt2[i*qdim+j] + halfrelax*lbw[i]*source[i] + feq[i]*omegaplus
                    + (collneg[k]-0.5*lbw[k]*source[k])*omegaminus;
    }
  }
    
  pt2 = NULL;
  pt3 = NULL;
  return 0;
}

int fSiteFluidIncomCollisionTRTGuo(double* startpos, double *sitespeed, double *omega, double *rho, double* bodyforce)
{
    
  // calculate fluid collisions at grid point: uses two relaxation time scheme with
  // Guo forcing term for incompressible fluids
    
  double speed[3], force[3], feq[lbsy.nq], source[lbsy.nq], collneg[lbsy.nq];
  double density, udot, invmass, relax, halfrelax, ex, ey, ez, omeganeg, omegaplus, omegaminus;
  double *pt2 = &startpos[0];
  double *pt3 = &bodyforce[0];
  int qdim = lbsy.nf+lbsy.nc+lbsy.nt;

  for(int j=0; j<lbsy.nf; j++) {
    density = lbincp[j];
    invmass = fReciprocal(density);
    force[0] = pt3[3*j];
    force[1] = pt3[3*j+1];
    force[2] = pt3[3*j+2];
    speed[0] = sitespeed[0] + 0.5 * force[0] * invmass;
    speed[1] = sitespeed[1] + 0.5 * force[1] * invmass;
    speed[2] = sitespeed[2] + 0.5 * force[2] * invmass;
    fGetEquilibriumFIncom(&feq[0], speed, rho[j], density);
    omeganeg = fTRTOmegaAntisymmetric(omega[j], lbtrtmagic);
    omegaplus = 0.5*(omega[j]+omeganeg);
    omegaminus = 0.5*(omega[j]-omeganeg);
    relax = 1.0 - omegaplus;
    halfrelax = 1.0 - 0.5*omegaplus;
    for(int i=0; i<lbsy.nq; i++){
      ex = lbvx[i];
      ey = lbvy[i];
      ez = lbvz[i];
      udot = ex * speed[0] + ey * speed[1] + ez * speed[2];
      source[i] = (3.0*(ex-speed[0]) + 9.0*udot*ex) * force[0]
                + (3.0*(ey-speed[1]) + 9.0*udot*ey) * force[1]
                + (3.0*(ez-speed[2]) + 9.0*udot*ez) * force[2];
      collneg[i] = feq[i] - pt2[i*qdim+j];
    }
    for(int i=0; i<lbsy.nq; i++) {
      int k = lbopv[i];
      pt2[i*qdim+j] = relax*pt2[i*qdim+j] + halfrelax*lbw[i]*source[i] + feq[i]*omegaplus
                    + (collneg[k]-0.5*lbw[k]*source[k])*omegaminus;
    }
  }
    
  pt2 = NULL;
  pt3 = NULL;
  return 0;
}

int fSiteFluidCollisionTRTHe(double* startpos, double *sitespeed, double *omega, double *rho, double* bodyforce)
{
    
  // calculate fluid collisions at grid point: uses two relaxation time scheme with
  // He forcing term
    
  double speed[3], force[3], feq[lbsy.nq], collneg[lbsy.nq], source[lbsy.nq];
  double udot, fdot, modv, modf, invmass, relax, halfrelax, ex, ey, ez, omeganeg, omegaplus, omegaminus;
  double *pt2 = &startpos[0];
  double *pt3 = &bodyforce[0];
  int qdim = lbsy.nf+lbsy.nc+lbsy.nt;

  for(int j=0; j<lbsy.nf; j++) {
    invmass = fReciprocal(rho[j]);
    force[0] = pt3[3*j];
    force[1] = pt3[3*j+1];
    force[2] = pt3[3*j+2];
    speed[0] = sitespeed[0] + 0.5 * force[0] * invmass;
    speed[1] = sitespeed[1] + 0.5 * force[1] * invmass;
    speed[2] = sitespeed[2] + 0.5 * force[2] * invmass;
    modv = speed[0] * speed[0] + speed[1] * speed[1] + speed[2] * speed[2];
    modf = speed[0] * force[0] + speed[1] * force[1] + speed[2] * force[2];
    fGetEquilibriumF(&feq[0], speed, rho[j]);
    omeganeg = fTRTOmegaAntisymmetric(omega[j], lbtrtmagic);
    omegaplus = 0.5*(omega[j]+omeganeg);
    omegaminus = 0.5*(omega[j]-omeganeg);
    relax = 1.0 - omegaplus;
    halfrelax = 1.0 - 0.5*omegaplus;
    for(int i=0; i<lbsy.nq; i++){
      ex = lbvx[i];
      ey = lbvy[i];
      ez = lbvz[i];
      udot = ex * speed[0] + ey * speed[1] + ez * speed[2];
      fdot = ex * force[0] + ey * force[1] + ez * force[2];
      source[i] = 3.0*(fdot-modf)*(1.0+3.0*udot) + 4.5*fdot*(3.0*udot*udot-modv);
      collneg[i] = feq[i] - pt2[i*qdim+j];
    }
    for(int i=0; i<lbsy.nq; i++) {
      int k = lbopv[i];
      pt2[i*qdim+j] = relax*pt2[i*qdim+j] + halfrelax*lbw[i]*source[i] + feq[i]*omegaplus
                    + (collneg[k]-0.5*lbw[k]*source[k])*omegaminus;
    }
  }
    
  pt2 = NULL;
  pt3 = NULL;
  return 0;
}

int fSiteFluidIncomCollisionTRTHe(double* startpos, double *sitespeed, double *omega, double *rho, double* bodyforce)
{
    
  // calculate fluid collisions at grid point: uses two relaxation time scheme with
  // He forcing term for incompressible fluids
    
  double speed[3], force[3], feq[lbsy.nq], source[lbsy.nq], collneg[lbsy.nq];
  double density, udot, fdot, modv, modf, invmass, relax, halfrelax, ex, ey, ez, omeganeg, omegaplus, omegaminus;
  double *pt2 = &startpos[0];
  double *pt3 = &bodyforce[0];
  int qdim = lbsy.nf+lbsy.nc+lbsy.nt;

  for(int j=0; j<lbsy.nf; j++) {
    density = lbincp[j];
    invmass = fReciprocal(density);
    force[0] = pt3[3*j];
    force[1] = pt3[3*j+1];
    force[2] = pt3[3*j+2];
    speed[0] = sitespeed[0] + 0.5 * force[0] * invmass;
    speed[1] = sitespeed[1] + 0.5 * force[1] * invmass;
    speed[2] = sitespeed[2] + 0.5 * force[2] * invmass;
    modv = speed[0] * speed[0] + speed[1] * speed[1] + speed[2] * speed[2];
    modf = speed[0] * force[0] + speed[1] * force[1] + speed[2] * force[2];
    fGetEquilibriumFIncom(&feq[0], speed, rho[j], density);
    omeganeg = fTRTOmegaAntisymmetric(omega[j], lbtrtmagic);
    omegaplus = 0.5*(omega[j]+omeganeg);
    omegaminus = 0.5*(omega[j]-omeganeg);
    relax = 1.0 - omegaplus;
    halfrelax = 1.0 - 0.5*omegaplus;
    for(int i=0; i<lbsy.nq; i++){
      ex = lbvx[i];
      ey = lbvy[i];
      ez = lbvz[i];
      udot = ex * speed[0] + ey * speed[1] + ez * speed[2];
      fdot = ex * force[0] + ey * force[1] + ez * force[2];
      source[i] = 3.0*(fdot-modf)*(1.0+3.0*udot) + 4.5*fdot*(3.0*udot*udot-modv);
      collneg[i] = feq[i] - pt2[i*qdim+j];
    }
    for(int i=0; i<lbsy.nq; i++) {
      int k = lbopv[i];
      pt2[i*qdim+j] = relax*pt2[i*qdim+j] + halfrelax*lbw[i]*source[i] + feq[i]*omegaplus
                    + (collneg[k]-0.5*lbw[k]*source[k])*omegaminus;
    }
  }
    
  pt2 = NULL;
  pt3 = NULL;
  return 0;
}

// Achromatic fluid collisions with pre-calculated interfacial forces and phase segregation

int fSiteFluidCollisionTRTLishchuk(double* startpos, double *sitespeed, double *omega, double *rho, double* bodyforce, double* phaseindex)
{

  // TRT collision of achromatic fluid and D'Ortona segregration
  // calculate collisions at grid point: uses two relaxation time scheme

  double speed[3], feq[lbsy.nq], collneg[lbsy.nq];
  double allmass, invallmass, omega1, omega2, omegaplus, omegaminus, nx, ny, nz, segpiece, collpiece, segcomp, invmassrelax, relax;
  double seg[lbsy.nf*lbsy.nq], lbfac[lbsy.nq];
  double *pt2 = &startpos[0];
  double *pt3 = &bodyforce[0];
  double *pt4 = &phaseindex[0];
  int numpair = lbsy.nf*(lbsy.nf-1)/2;
  int qdim = lbsy.nf+lbsy.nc+lbsy.nt;

  // collision of achromatic fluid

  allmass = 0.0;
  omega1 = 0.0;

  for(int j=0; j<lbsy.nf; j++) {
    allmass += rho[j];
    omega1 += omega[j] * rho[j];
  }

  invallmass = fReciprocal(allmass);
  omega1 *= invallmass;
      
  for(int i=0; i<lbsy.nq; i++) {
    lbfac[i] = 0.0;
    for(int j=0; j<lbsy.nf; j++) {
      lbfac[i] += pt2[i*qdim+j];
      seg[i*lbsy.nf+j] = 0.0;
    }
  }

  // calculate segregation terms

  for(int k=0; k<numpair; k++) {
    int i = lbspair[2*k  ];
    int j = lbspair[2*k+1];
    nx = pt4[3*k  ];
    ny = pt4[3*k+1];
    nz = pt4[3*k+2];
    segpiece = lbseg[lbsy.nf*j+i] * rho[i] * rho[j] * invallmass * invallmass;
    for(int m=0; m<lbsy.nq; m++) {
      segcomp = segpiece * (lbvwx[m]*nx + lbvwy[m]*ny + lbvwz[m]*nz);
      seg[m*lbsy.nf+i] += segcomp;
      seg[m*lbsy.nf+j] -= segcomp;
    }
  }

  // collide and segregate fluids
    
  omega2 = fTRTOmegaAntisymmetric(omega1, lbtrtmagic);
  invmassrelax = fReciprocal(allmass * omega1);
  omegaplus = 0.5 * (omega1 + omega2);
  omegaminus = 0.5 * (omega1 - omega2);
  relax = 1.0 - omegaplus;
  speed[0] = sitespeed[0] + pt3[0] * invmassrelax;
  speed[1] = sitespeed[1] + pt3[1] * invmassrelax;
  speed[2] = sitespeed[2] + pt3[2] * invmassrelax;
  fGetEquilibriumF(&feq[0], speed, allmass);
  for(int i=0; i<lbsy.nq; i++){
    collneg[i] = feq[i] - lbfac[i];
  }
  for(int m=0; m<lbsy.nq; m++){
    int k = lbopv[m];
    collpiece = relax * lbfac[m] + feq[m]*omegaplus + collneg[k]*omegaminus;
    for(int i=0; i<lbsy.nf; i++) {
      pt2[m*qdim+i] = rho[i] * collpiece * invallmass + seg[m*lbsy.nf+i];
    }
  }

  pt2 = NULL;
  pt3 = NULL;  
  pt4 = NULL;  
  return 0;
}

int fSiteFluidIncomCollisionTRTLishchuk(double* startpos, double *sitespeed, double *omega, double *rho, double* bodyforce, double* phaseindex)
{

  // TRT collision of achromatic fluid and D'Ortona segregration
  // calculate collisions at grid point: uses two relaxation time scheme with incompressible fluids

  double speed[3], feq[lbsy.nq], collneg[lbsy.nq];
  double allmass, invallmass, invmassrelax, relax, density, omega1, omega2;
  double omegaplus, omegaminus, nx, ny, nz, segcomp, segpiece, collpiece;
  double seg[lbsy.nf*lbsy.nq], lbfac[lbsy.nq];
  double *pt2 = &startpos[0];
  double *pt3 = &bodyforce[0];
  double *pt4 = &phaseindex[0];
  int numpair = lbsy.nf*(lbsy.nf-1)/2;
  int qdim = lbsy.nf+lbsy.nc+lbsy.nt;

  // collision of achromatic fluid

  allmass = 0.0;
  omega1 = 0.0;
  density = 0.0;

  for(int j=0; j<lbsy.nf; j++) {
    allmass += rho[j];
    omega1 += omega[j] * rho[j];
    density += lbincp[j] * rho[j];
  }

  invallmass = fReciprocal(allmass);
  omega1 *= invallmass;
  density *= invallmass;

  for(int i=0; i<lbsy.nq; i++) {
    lbfac[i] = 0.0;
    for(int j=0; j<lbsy.nf; j++) {
      lbfac[i] += pt2[i*qdim+j];
      seg[i*lbsy.nf+j] = 0.0;
    }
  }

  // calculate segregation terms

  for(int k=0; k<numpair; k++) {
    int i = lbspair[2*k  ];
    int j = lbspair[2*k+1];
    nx = pt4[3*k  ];
    ny = pt4[3*k+1];
    nz = pt4[3*k+2];
    segpiece = lbseg[lbsy.nf*j+i] * rho[i] * rho[j] * invallmass * invallmass;
    for(int m=0; m<lbsy.nq; m++) {
      segcomp = segpiece * (lbvwx[m]*nx + lbvwy[m]*ny + lbvwz[m]*nz);
      seg[m*lbsy.nf+i] += segcomp;
      seg[m*lbsy.nf+j] -= segcomp;
    }
  }

  // collide and segregate fluids
    
  omega2 = fTRTOmegaAntisymmetric(omega1, lbtrtmagic);
  invmassrelax = fReciprocal(omega1 * density);
  omegaplus = 0.5 * (omega1 + omega2);
  omegaminus = 0.5 * (omega1 - omega2);
  relax = 1.0 - omegaplus;
  speed[0] = sitespeed[0] + pt3[0] * invmassrelax;
  speed[1] = sitespeed[1] + pt3[1] * invmassrelax;
  speed[2] = sitespeed[2] + pt3[2] * invmassrelax;
  fGetEquilibriumFIncom(&feq[0], speed, allmass, density);
  for(int i=0; i<lbsy.nq; i++){
    collneg[i] = feq[i] - lbfac[i];
  }
  for(int m=0; m<lbsy.nq; m++){
    int k = lbopv[m];
    collpiece = relax * lbfac[m] + feq[m]*omegaplus + collneg[k]*omegaminus;
    for(int i=0; i<lbsy.nf; i++) {
      pt2[m*qdim+i] = rho[i] * collpiece * invallmass + seg[m*lbsy.nf+i];
    }
  }

  pt2 = NULL;
  pt3 = NULL;  
  pt4 = NULL;  
  return 0;
}

int fSiteFluidCollisionTRTEDMLishchuk(double* startpos, double *sitespeed, double *omega, double *rho, double* bodyforce, double* phaseindex)
{

  // TRT collision of achromatic fluid and D'Ortona segregration
  // calculate collisions at grid point: uses two relaxation time scheme with
  // Exact Difference Method forcing term

  double dv[3], feq[lbsy.nq], collneg[lbsy.nq];
  double allmass,invallmass, omega1, omega2, omegaplus, omegaminus, nx, ny, nz, segpiece, collpiece, segcomp, relax, source;
  double modv,eixux,eiyuy,eizuz,eixdux,eiyduy,eizduz;
  double seg[lbsy.nf*lbsy.nq], lbfac[lbsy.nq];
  double *pt2 = &startpos[0];
  double *pt3 = &bodyforce[0];
  double *pt4 = &phaseindex[0];
  int numpair = lbsy.nf*(lbsy.nf-1)/2;
  int qdim = lbsy.nf+lbsy.nc+lbsy.nt;

  // collision of achromatic fluid
    
  allmass = 0.0;
  omega1 = 0.0;

  for(int j=0; j<lbsy.nf; j++) {
    allmass += rho[j];
    omega1 += omega[j] * rho[j];
  }

  invallmass = fReciprocal(allmass);
  omega1 *= invallmass;
      
  for(int i=0; i<lbsy.nq; i++) {
    lbfac[i] = 0.0;
    for(int j=0; j<lbsy.nf; j++) {
      lbfac[i] += pt2[i*qdim+j];
      seg[i*lbsy.nf+j] = 0.0;
    }
  }

  // calculate segregation terms

  for(int k=0; k<numpair; k++) {
    int i = lbspair[2*k  ];
    int j = lbspair[2*k+1];
    nx = pt4[3*k  ];
    ny = pt4[3*k+1];
    nz = pt4[3*k+2];
    segpiece = lbseg[lbsy.nf*j+i] * rho[i] * rho[j] * invallmass * invallmass;
    for(int m=0; m<lbsy.nq; m++) {
      segcomp = segpiece * (lbvwx[m]*nx + lbvwy[m]*ny + lbvwz[m]*nz);
      seg[m*lbsy.nf+i] += segcomp;
      seg[m*lbsy.nf+j] -= segcomp;
    }
  }

  // collide and segregate fluids
    
  omega2 = fTRTOmegaAntisymmetric(omega1, lbtrtmagic);
  omegaplus = 0.5 * (omega1 + omega2);
  omegaminus = 0.5 * (omega1 - omega2);
  relax = 1.0 - omegaplus;
  dv[0] = pt3[0] * invallmass;
  dv[1] = pt3[1] * invallmass;
  dv[2] = pt3[2] * invallmass;
  fGetEquilibriumF(&feq[0], sitespeed, allmass);
  modv = dv[0]*(2.0*sitespeed[0]+dv[0]) + dv[1]*(2.0*sitespeed[1]+dv[1]) + dv[2]*(2.0*sitespeed[2]+dv[2]);
  for(int i=0; i<lbsy.nq; i++) {
    collneg[i] = feq[i] - lbfac[i];
  }
  for(int m=0; m<lbsy.nq; m++){
    int k = lbopv[m];
    eixux =  lbvx[m]*sitespeed[0];
    eiyuy =  lbvy[m]*sitespeed[1];
    eizuz =  lbvz[m]*sitespeed[2];
    eixdux = lbvx[m]*dv[0];
    eiyduy = lbvy[m]*dv[1];
    eizduz = lbvz[m]*dv[2];
    source = allmass * lbw[m] * (3.0 * (eixdux+eiyduy+eizduz) +
                                 4.5 * (eixdux*(eixdux+2.0*(eixux+eiyuy+eizuz+eiyduy+eizduz)) +
                                        eiyduy*(eiyduy+2.0*(eixux+eiyuy+eizuz+eizduz)) +
                                        eizduz*(eizduz+2.0*(eixux+eiyuy+eizuz))) -
                                 1.5 * modv);
    collpiece = relax * lbfac[m] + source + feq[m]*omegaplus + collneg[k]*omegaminus;
    for(int i=0; i<lbsy.nf; i++) {
      pt2[m*qdim+i] = rho[i] * collpiece * invallmass + seg[m*lbsy.nf+i];
    }
  }

  pt2 = NULL;
  pt3 = NULL;  
  pt4 = NULL;  
  return 0;
}

int fSiteFluidIncomCollisionTRTEDMLishchuk(double* startpos, double *sitespeed, double *omega, double *rho, double* bodyforce, double* phaseindex)
{

  // TRT collision of achromatic fluid and D'Ortona segregration
  // calculate collisions at grid point: uses two relaxation time scheme
  // with incompressible fluids and Exact Difference Method forcing term

  double dv[3], feq[lbsy.nq], collneg[lbsy.nq];
  double allmass, invallmass, invmass, relax, density, omega1, omega2;
  double omegaplus, omegaminus, nx, ny, nz, segcomp, segpiece, collpiece, source;
  double modv,eixux,eiyuy,eizuz,eixdux,eiyduy,eizduz;
  double seg[lbsy.nf*lbsy.nq], lbfac[lbsy.nq];
  double *pt2 = &startpos[0];
  double *pt3 = &bodyforce[0];
  double *pt4 = &phaseindex[0];
  int numpair = lbsy.nf*(lbsy.nf-1)/2;
  int qdim = lbsy.nf+lbsy.nc+lbsy.nt;

  // collision of achromatic fluid

  allmass = 0.0;
  omega1 = 0.0;
  density = 0.0;

  for(int j=0; j<lbsy.nf; j++) {
    allmass += rho[j];
    omega1 += omega[j] * rho[j];
    density += lbincp[j] * rho[j];
  }

  invallmass = fReciprocal(allmass);
  omega1 *= invallmass;
  density *= invallmass;

  for(int i=0; i<lbsy.nq; i++) {
    lbfac[i] = 0.0;
    for(int j=0; j<lbsy.nf; j++) {
      lbfac[i] += pt2[i*qdim+j];
      seg[i*lbsy.nf+j] = 0.0;
    }
  }

  // calculate segregation terms

  for(int k=0; k<numpair; k++) {
    int i = lbspair[2*k  ];
    int j = lbspair[2*k+1];
    nx = pt4[3*k  ];
    ny = pt4[3*k+1];
    nz = pt4[3*k+2];
    segpiece = lbseg[lbsy.nf*j+i] * rho[i] * rho[j] * invallmass * invallmass;
    for(int m=0; m<lbsy.nq; m++) {
      segcomp = segpiece * (lbvwx[m]*nx + lbvwy[m]*ny + lbvwz[m]*nz);
      seg[m*lbsy.nf+i] += segcomp;
      seg[m*lbsy.nf+j] -= segcomp;
    }
  }

  // collide and segregate fluids
    
  omega2 = fTRTOmegaAntisymmetric(omega1, lbtrtmagic);
  invmass = fReciprocal(density);
  omegaplus = 0.5*(omega1+omega2);
  omegaminus = 0.5*(omega1-omega2);
  relax = 1.0 - omegaplus;
  dv[0] = pt3[0] * invmass;
  dv[1] = pt3[1] * invmass;
  dv[2] = pt3[2] * invmass;
  fGetEquilibriumFIncom(&feq[0], sitespeed, allmass, density);
  modv = dv[0]*(2.0*sitespeed[0]+dv[0]) + dv[1]*(2.0*sitespeed[1]+dv[1]) + dv[2]*(2.0*sitespeed[2]+dv[2]);
  for(int i=0; i<lbsy.nq; i++) {
    collneg[i] = feq[i] - lbfac[i];
  }
  for(int m=0; m<lbsy.nq; m++){
    int k = lbopv[m];
    eixux =  lbvx[m]*sitespeed[0];
    eiyuy =  lbvy[m]*sitespeed[1];
    eizuz =  lbvz[m]*sitespeed[2];
    eixdux = lbvx[m]*dv[0];
    eiyduy = lbvy[m]*dv[1];
    eizduz = lbvz[m]*dv[2];
    source = density * lbw[m] * (3.0 * (eixdux+eiyduy+eizduz) +
                                 4.5 * (eixdux*(eixdux+2.0*(eixux+eiyuy+eizuz+eiyduy+eizduz)) +
                                        eiyduy*(eiyduy+2.0*(eixux+eiyuy+eizuz+eizduz)) +
                                        eizduz*(eizduz+2.0*(eixux+eiyuy+eizuz))) -
                                 1.5 * modv);
    collpiece = relax * lbfac[m] + source + feq[m]*omegaplus + collneg[k]*omegaminus;
    for(int i=0; i<lbsy.nf; i++) {
      pt2[m*qdim+i] = rho[i] * collpiece * invallmass + seg[m*lbsy.nf+i];
    }
  }

  pt2 = NULL;
  pt3 = NULL;  
  pt4 = NULL;  
  return 0;
}

int fSiteFluidCollisionTRTGuoLishchuk(double* startpos, double *sitespeed, double *omega, double *rho, double* bodyforce, double* phaseindex)
{

  // TRT collision of achromatic fluid and D'Ortona segregration
  // calculate collisions at grid point: uses two relaxation time scheme with Guo forcing term

  double speed[3], force[3], feq[lbsy.nq], source[lbsy.nq], collneg[lbsy.nq];
  double udot, allmass, invallmass, omega1, omega2, omegaplus, omegaminus, nx, ny, nz;
  double ex, ey, ez, segcomp, segpiece, collpiece, relax, halfrelax;
  double seg[lbsy.nf*lbsy.nq], lbfac[lbsy.nq];
  double *pt2 = &startpos[0];
  double *pt3 = &bodyforce[0];
  double *pt4 = &phaseindex[0];
  int numpair = lbsy.nf*(lbsy.nf-1)/2;
  int qdim = lbsy.nf+lbsy.nc+lbsy.nt;

  // collision of achromatic fluid

  allmass = 0.0;
  omega1 = 0.0;

  for(int j=0; j<lbsy.nf; j++) {
    allmass += rho[j];
    omega1 += omega[j] * rho[j];
  }

  invallmass = fReciprocal(allmass);
  omega1 *= invallmass;
      
  for(int i=0; i<lbsy.nq; i++) {
    lbfac[i] = 0.0;
    for(int j=0; j<lbsy.nf; j++) {
      lbfac[i] += pt2[i*qdim+j];
      seg[i*lbsy.nf+j] = 0.0;
    }
  }

  // calculate segregation terms

  for(int k=0; k<numpair; k++) {
    int i = lbspair[2*k  ];
    int j = lbspair[2*k+1];
    nx = pt4[3*k  ];
    ny = pt4[3*k+1];
    nz = pt4[3*k+2];
    segpiece = lbseg[lbsy.nf*j+i] * rho[i] * rho[j] * invallmass * invallmass;
    for(int m=0; m<lbsy.nq; m++) {
      segcomp = segpiece * (lbvwx[m]*nx + lbvwy[m]*ny + lbvwz[m]*nz);
      seg[m*lbsy.nf+i] += segcomp;
      seg[m*lbsy.nf+j] -= segcomp;
    }
  }

  // collide and segregate fluids

  force[0] = pt3[0];
  force[1] = pt3[1];
  force[2] = pt3[2];
  speed[0] = sitespeed[0] + 0.5 * force[0] * invallmass;
  speed[1] = sitespeed[1] + 0.5 * force[1] * invallmass;
  speed[2] = sitespeed[2] + 0.5 * force[2] * invallmass;
  fGetEquilibriumF(&feq[0], speed, allmass);
  omega2 = fTRTOmegaAntisymmetric(omega1, lbtrtmagic);
  omegaplus = 0.5*(omega1+omega2);
  omegaminus = 0.5*(omega1-omega2);
  relax = 1.0 - omegaplus;
  halfrelax = 1.0 - 0.5*omegaplus;
  for(int i=0; i<lbsy.nq; i++){
    ex = lbvx[i];
    ey = lbvy[i];
    ez = lbvz[i];
    udot = ex * speed[0] + ey * speed[1] + ez * speed[2];
    source[i] = (3.0*(ex-speed[0]) + 9.0*udot*ex) * force[0]
              + (3.0*(ey-speed[1]) + 9.0*udot*ey) * force[1]
              + (3.0*(ez-speed[2]) + 9.0*udot*ez) * force[2];
    collneg[i] = feq[i] - lbfac[i];
  }
  for(int m=0; m<lbsy.nq; m++) {
    int k = lbopv[m];
    collpiece = relax*lbfac[m] + halfrelax*lbw[m]*source[m] + feq[m]*omegaplus
              + (collneg[k]-0.5*lbw[k]*source[k])*omegaminus;
    for(int i=0; i<lbsy.nf; i++) {
      pt2[m*qdim+i] = rho[i] * collpiece * invallmass + seg[m*lbsy.nf+i];
    }
  }

  pt2 = NULL;
  pt3 = NULL;  
  pt4 = NULL;  
  return 0;
}

int fSiteFluidIncomCollisionTRTGuoLishchuk(double* startpos, double *sitespeed, double *omega, double *rho, double* bodyforce, double* phaseindex)
{

  // TRT collision of achromatic fluid and D'Ortona segregration
  // calculate collisions at grid point: uses two relaxation time scheme
  // with Guo forcing term for incompressible fluids

  double speed[3], force[3], feq[lbsy.nq], source[lbsy.nq], collneg[lbsy.nq];
  double udot, allmass, invallmass, density, invdensity;
  double omega1, omega2, omegaplus, omegaminus, nx, ny, nz;
  double ex, ey, ez, segcomp, segpiece, collpiece, relax, halfrelax;
  double seg[lbsy.nf*lbsy.nq], lbfac[lbsy.nq];
  double *pt2 = &startpos[0];
  double *pt3 = &bodyforce[0];
  double *pt4 = &phaseindex[0];
  int numpair = lbsy.nf*(lbsy.nf-1)/2;
  int qdim = lbsy.nf+lbsy.nc+lbsy.nt;

  // collision of achromatic fluid

  allmass = 0.0;
  omega1 = 0.0;
  density = 0.0;

  for(int j=0; j<lbsy.nf; j++) {
    allmass += rho[j];
    omega1 += omega[j] * rho[j];
    density += lbincp[j] * rho[j];
  }

  invallmass = fReciprocal(allmass);
  omega1 *= invallmass;
  density *= invallmass;

  for(int i=0; i<lbsy.nq; i++) {
    lbfac[i] = 0.0;
    for(int j=0; j<lbsy.nf; j++) {
      lbfac[i] += pt2[i*qdim+j];
      seg[i*lbsy.nf+j] = 0.0;
    }
  }

  // calculate segregation terms

  for(int k=0; k<numpair; k++) {
    int i = lbspair[2*k  ];
    int j = lbspair[2*k+1];
    nx = pt4[3*k  ];
    ny = pt4[3*k+1];
    nz = pt4[3*k+2];
    segpiece = lbseg[lbsy.nf*j+i] * rho[i] * rho[j] * invallmass * invallmass;
    for(int m=0; m<lbsy.nq; m++) {
      segcomp = segpiece * (lbvwx[m]*nx + lbvwy[m]*ny + lbvwz[m]*nz);
      seg[m*lbsy.nf+i] += segcomp;
      seg[m*lbsy.nf+j] -= segcomp;
    }
  }

  // collide and segregate fluids
    
  invdensity = fReciprocal(density);
  force[0] = pt3[0];
  force[1] = pt3[1];
  force[2] = pt3[2];
  speed[0] = sitespeed[0] + 0.5 * force[0] * invdensity;
  speed[1] = sitespeed[1] + 0.5 * force[1] * invdensity;
  speed[2] = sitespeed[2] + 0.5 * force[2] * invdensity;
  fGetEquilibriumFIncom(&feq[0], speed, allmass, density);
  omega2 = fTRTOmegaAntisymmetric(omega1, lbtrtmagic);
  omegaplus = 0.5*(omega1+omega2);
  omegaminus = 0.5*(omega1-omega2);
  relax = 1.0 - omegaplus;
  halfrelax = 1.0 - 0.5*omegaplus;
  for(int i=0; i<lbsy.nq; i++){
    ex = lbvx[i];
    ey = lbvy[i];
    ez = lbvz[i];
    udot = ex * speed[0] + ey * speed[1] + ez * speed[2];
    source[i] = (3.0*(ex-speed[0]) + 9.0*udot*ex) * force[0]
              + (3.0*(ey-speed[1]) + 9.0*udot*ey) * force[1]
              + (3.0*(ez-speed[2]) + 9.0*udot*ez) * force[2];
    collneg[i] = feq[i] - lbfac[i];
  }
  for(int m=0; m<lbsy.nq; m++) {
    int k = lbopv[m];
    collpiece = relax*lbfac[m] + halfrelax*lbw[m]*source[m] + feq[m]*omegaplus
              + (collneg[k]-0.5*lbw[k]*source[k])*omegaminus;
    for(int i=0; i<lbsy.nf; i++) {
      pt2[m*qdim+i] = rho[i] * collpiece * invallmass + seg[m*lbsy.nf+i];
    }
  }

  pt2 = NULL;
  pt3 = NULL;  
  pt4 = NULL;  
  return 0;
}

int fSiteFluidCollisionTRTHeLishchuk(double* startpos, double *sitespeed, double *omega, double *rho, double* bodyforce, double* phaseindex)
{

  // TRT collision of achromatic fluid and D'Ortona segregration
  // calculate collisions at grid point: uses two relaxation time scheme with He forcing term

  double speed[3], force[3], feq[lbsy.nq], source[lbsy.nq], collneg[lbsy.nq];
  double udot, fdot, modv, modf, allmass, invallmass, omega1, omega2, omegaplus, omegaminus, nx, ny, nz;
  double ex, ey, ez, segcomp, segpiece, collpiece, relax, halfrelax;
  double seg[lbsy.nf*lbsy.nq], lbfac[lbsy.nq];
  double *pt2 = &startpos[0];
  double *pt3 = &bodyforce[0];
  double *pt4 = &phaseindex[0];
  int numpair = lbsy.nf*(lbsy.nf-1)/2;
  int qdim = lbsy.nf+lbsy.nc+lbsy.nt;

  // collision of achromatic fluid

  allmass = 0.0;
  omega1 = 0.0;

  for(int j=0; j<lbsy.nf; j++) {
    allmass += rho[j];
    omega1 += omega[j] * rho[j];
  }

  invallmass = fReciprocal(allmass);
  omega1 *= invallmass;
    
  for(int i=0; i<lbsy.nq; i++) {
    lbfac[i] = 0.0;
    for(int j=0; j<lbsy.nf; j++) {
      lbfac[i] += pt2[i*qdim+j];
      seg[i*lbsy.nf+j] = 0.0;
    }
  }

  // calculate segregation terms

  for(int k=0; k<numpair; k++) {
    int i = lbspair[2*k  ];
    int j = lbspair[2*k+1];
    nx = pt4[3*k  ];
    ny = pt4[3*k+1];
    nz = pt4[3*k+2];
    segpiece = lbseg[lbsy.nf*j+i] * rho[i] * rho[j] * invallmass * invallmass;
    for(int m=0; m<lbsy.nq; m++) {
      segcomp = segpiece * (lbvwx[m]*nx + lbvwy[m]*ny + lbvwz[m]*nz);
      seg[m*lbsy.nf+i] += segcomp;
      seg[m*lbsy.nf+j] -= segcomp;
    }
  }

  // collide and segregate fluids

  force[0] = pt3[0];
  force[1] = pt3[1];
  force[2] = pt3[2];
  speed[0] = sitespeed[0] + 0.5 * force[0] * invallmass;
  speed[1] = sitespeed[1] + 0.5 * force[1] * invallmass;
  speed[2] = sitespeed[2] + 0.5 * force[2] * invallmass;
  modv = speed[0] * speed[0] + speed[1] * speed[1] + speed[2] * speed[2];
  modf = speed[0] * force[0] + speed[1] * force[1] + speed[2] * force[2];
  fGetEquilibriumF(&feq[0], speed, allmass);
  omega2 = fTRTOmegaAntisymmetric(omega1, lbtrtmagic);
  omegaplus = 0.5*(omega1+omega2);
  omegaminus = 0.5*(omega1-omega2);
  relax = 1.0 - omegaplus;
  halfrelax = 1.0 - 0.5*omegaplus;
  for(int i=0; i<lbsy.nq; i++){
    ex = lbvx[i];
    ey = lbvy[i];
    ez = lbvz[i];
    udot = ex * speed[0] + ey * speed[1] + ez * speed[2];
    fdot = ex * force[0] + ey * force[1] + ez * force[2];
    source[i] = 3.0*(fdot-modf)*(1.0+3.0*udot) + 4.5*fdot*(3.0*udot*udot-modv);
    collneg[i] = feq[i] - lbfac[i];
  }
  for(int m=0; m<lbsy.nq; m++) {
    int k = lbopv[m];
    collpiece = relax*lbfac[m] + halfrelax*lbw[m]*source[m] + feq[m]*omegaplus
              + (collneg[k]-0.5*lbw[k]*source[k])*omegaminus;
    for(int i=0; i<lbsy.nf; i++) {
      pt2[m*qdim+i] = rho[i] * collpiece * invallmass + seg[m*lbsy.nf+i];
    }
  }

  pt2 = NULL;
  pt3 = NULL;
  pt4 = NULL;
  return 0;
}

int fSiteFluidIncomCollisionTRTHeLishchuk(double* startpos, double *sitespeed, double *omega, double *rho, double* bodyforce, double* phaseindex)
{

  // TRT collision of achromatic fluid and D'Ortona segregration
  // calculate collisions at grid point: uses two relaxation time scheme
  // with He forcing term for incompressible fluids

  double speed[3], force[3], feq[lbsy.nq], source[lbsy.nq], collneg[lbsy.nq];
  double udot, fdot, modv, modf, allmass, invallmass, density, invdensity;
  double omega1, omega2, omegaplus, omegaminus, nx, ny, nz;
  double ex, ey, ez, segcomp, segpiece, collpiece, relax, halfrelax;
  double seg[lbsy.nf*lbsy.nq], lbfac[lbsy.nq];
  double *pt2 = &startpos[0];
  double *pt3 = &bodyforce[0];
  double *pt4 = &phaseindex[0];
  int numpair = lbsy.nf*(lbsy.nf-1)/2;
  int qdim = lbsy.nf+lbsy.nc+lbsy.nt;

  // collision of achromatic fluid

  allmass = 0.0;
  omega1 = 0.0;
  density = 0.0;

  for(int j=0; j<lbsy.nf; j++) {
    allmass += rho[j];
    omega1 += omega[j] * rho[j];
    density += lbincp[j] * rho[j];
  }

  invallmass = fReciprocal(allmass);
  omega1 *= invallmass;
  density *= invallmass;

  for(int i=0; i<lbsy.nq; i++) {
    lbfac[i] = 0.0;
    for(int j=0; j<lbsy.nf; j++) {
      lbfac[i] += pt2[i*qdim+j];
      seg[i*lbsy.nf+j] = 0.0;
    }
  }

  // calculate segregation terms

  for(int k=0; k<numpair; k++) {
    int i = lbspair[2*k  ];
    int j = lbspair[2*k+1];
    nx = pt4[3*k  ];
    ny = pt4[3*k+1];
    nz = pt4[3*k+2];
    segpiece = lbseg[lbsy.nf*j+i] * rho[i] * rho[j] * invallmass * invallmass;
    for(int m=0; m<lbsy.nq; m++) {
      segcomp = segpiece * (lbvwx[m]*nx + lbvwy[m]*ny + lbvwz[m]*nz);
      seg[m*lbsy.nf+i] += segcomp;
      seg[m*lbsy.nf+j] -= segcomp;
    }
  }

  // collide and segregate fluids
    
  invdensity = fReciprocal(density);
  force[0] = pt3[0];
  force[1] = pt3[1];
  force[2] = pt3[2];
  speed[0] = sitespeed[0] + 0.5 * force[0] * invdensity;
  speed[1] = sitespeed[1] + 0.5 * force[1] * invdensity;
  speed[2] = sitespeed[2] + 0.5 * force[2] * invdensity;
  modv = speed[0] * speed[0] + speed[1] * speed[1] + speed[2] * speed[2];
  modf = speed[0] * force[0] + speed[1] * force[1] + speed[2] * force[2];
  fGetEquilibriumFIncom(&feq[0], speed, allmass, density);
  omega2 = fTRTOmegaAntisymmetric(omega1, lbtrtmagic);
  omegaplus = 0.5*(omega1+omega2);
  omegaminus = 0.5*(omega1-omega2);
  relax = 1.0 - omegaplus;
  halfrelax = 1.0 - 0.5*omegaplus;
  for(int i=0; i<lbsy.nq; i++){
    ex = lbvx[i];
    ey = lbvy[i];
    ez = lbvz[i];
    udot = ex * speed[0] + ey * speed[1] + ez * speed[2];
    fdot = ex * force[0] + ey * force[1] + ez * force[2];
    source[i] = 3.0*(fdot-modf)*(1.0+3.0*udot) + 4.5*fdot*(3.0*udot*udot-modv);
    collneg[i] = feq[i] - lbfac[i];
  }
  for(int m=0; m<lbsy.nq; m++) {
    int k = lbopv[m];
    collpiece = relax*lbfac[m] + halfrelax*lbw[m]*source[m] + feq[m]*omegaplus
              + (collneg[k]-0.5*lbw[k]*source[k])*omegaminus;
    for(int i=0; i<lbsy.nf; i++) {
      pt2[m*qdim+i] = rho[i] * collpiece * invallmass + seg[m*lbsy.nf+i];
    }
  }

  pt2 = NULL;
  pt3 = NULL;
  pt4 = NULL;
  return 0;
}

// Achromatic fluid collisions with forcing terms and phase segregation

int fSiteFluidCollisionTRTLishchukLocal(double* startpos, double *sitespeed, double *omega, double *rho, double* bodyforce, double* phaseindex, int threed)
{

  // TRT collision of achromatic fluid and D'Ortona segregration
  // calculate interfacial forcing terms and collisions at grid point:
  // uses two relaxation time scheme

  double speed[3], feq[lbsy.nq], collneg[lbsy.nq];
  double allmass, invallmass, omega1, omega2, omegaplus, omegaminus;
  double ex, ey, ez, nx, ny, nz, forceconst, segpiece, collpiece, segcomp, invmassrelax, relax;
  double seg[lbsy.nf*lbsy.nq], lbfac[lbsy.nq], phaseforce[lbsy.nq];
  double *pt2 = &startpos[0];
  double *pt3 = &bodyforce[0];
  double *pt4 = &phaseindex[0];
  int numpair = lbsy.nf*(lbsy.nf-1)/2;
  int qdim = lbsy.nf+lbsy.nc+lbsy.nt;

  // collision of achromatic fluid

  allmass = 0.0;
  omega1 = 0.0;

  for(int j=0; j<lbsy.nf; j++) {
    allmass += rho[j];
    omega1 += omega[j] * rho[j];
  }

  invallmass = fReciprocal(allmass);
  omega1 *= invallmass;
      
  for(int i=0; i<lbsy.nq; i++) {
    lbfac[i] = 0.0;
    phaseforce[i] = 0.0;
    for(int j=0; j<lbsy.nf; j++) {
      lbfac[i] += pt2[i*qdim+j];
      seg[i*lbsy.nf+j] = 0.0;
    }
  }

  // calculate local forcing and segregation terms
    
  for(int k=0; k<numpair; k++) {
    int i = lbspair[2*k  ];
    int j = lbspair[2*k+1];
    nx = pt4[3*k  ];
    ny = pt4[3*k+1];
    nz = pt4[3*k+2];
    forceconst = lbseg[lbsy.nf*j+i] * lbg[lbsy.nf*j+i] * rho[i] * rho[j];
    segpiece = lbseg[lbsy.nf*j+i] * rho[i] * rho[j] * invallmass * invallmass;
    for(int m=0; m<lbsy.nq; m++) {
      ex = lbvx[m];
      ey = lbvy[m];
      ez = lbvz[m];
      phaseforce[m] += forceconst * ((nx*nx-1.0)*(ex*ex-lbcssq) + (ny*ny-1.0)*(ey*ey-lbcssq) + 2.0*nx*ny*ex*ey
                     + threed*((nz*nz-1.0)*(ez*ez-lbcssq) + 2.0*nz*ez*(nx*ex+ny*ey)));
      segcomp = segpiece * (lbvwx[m]*nx + lbvwy[m]*ny + lbvwz[m]*nz);
      seg[m*lbsy.nf+i] += segcomp;
      seg[m*lbsy.nf+j] -= segcomp;
    }
  }
  
  // collide and segregate fluids
    
  omega2 = fTRTOmegaAntisymmetric(omega1, lbtrtmagic);
  invmassrelax = fReciprocal(allmass * omega1);
  omegaplus = 0.5 * (omega1 + omega2);
  omegaminus = 0.5 * (omega1 - omega2);
  relax = 1.0 - omegaplus;
  forceconst = omega1 * invallmass * invallmass * invallmass * lbrcssq * lbrcssq;

  speed[0] = sitespeed[0] + pt3[0] * invmassrelax;
  speed[1] = sitespeed[1] + pt3[1] * invmassrelax;
  speed[2] = sitespeed[2] + pt3[2] * invmassrelax;
  fGetEquilibriumF(&feq[0], speed, allmass);
  for(int i=0; i<lbsy.nq; i++){
    collneg[i] = feq[i] - lbfac[i];
  }
  for(int m=0; m<lbsy.nq; m++){
    int k = lbopv[m];
    collpiece = relax * lbfac[m] + feq[m]*omegaplus + collneg[k]*omegaminus + lbw[m]*forceconst*phaseforce[m];
    for(int i=0; i<lbsy.nf; i++) {
      pt2[m*qdim+i] = rho[i] * collpiece * invallmass + seg[m*lbsy.nf+i];
    }
  }

  pt2 = NULL;
  pt3 = NULL;  
  pt4 = NULL;  
  return 0;
}

int fSiteFluidIncomCollisionTRTLishchukLocal(double* startpos, double *sitespeed, double *omega, double *rho, double* bodyforce, double* phaseindex, int threed)
{

  // TRT collision of achromatic fluid and D'Ortona segregration
  // calculate interfacial forcing terms and collisions at grid point:
  // uses two relaxation time scheme with incompressible fluids

  double speed[3], feq[lbsy.nq], collneg[lbsy.nq];
  double allmass, invallmass, invmassrelax, relax, density, omega1, omega2;
  double omegaplus, omegaminus, ex, ey, ez, nx, ny, nz, forceconst, segcomp, segpiece, collpiece;
  double seg[lbsy.nf*lbsy.nq], lbfac[lbsy.nq], phaseforce[lbsy.nq];
  double *pt2 = &startpos[0];
  double *pt3 = &bodyforce[0];
  double *pt4 = &phaseindex[0];
  int numpair = lbsy.nf*(lbsy.nf-1)/2;
  int qdim = lbsy.nf+lbsy.nc+lbsy.nt;

  // collision of achromatic fluid

  allmass = 0.0;
  omega1 = 0.0;
  density = 0.0;

  for(int j=0; j<lbsy.nf; j++) {
    allmass += rho[j];
    omega1 += omega[j] * rho[j];
    density += lbincp[j] * rho[j];
  }

  invallmass = fReciprocal(allmass);
  omega1 *= invallmass;
  density *= invallmass;

  for(int i=0; i<lbsy.nq; i++) {
    lbfac[i] = 0.0;
    phaseforce[i] = 0.0;
    for(int j=0; j<lbsy.nf; j++) {
      lbfac[i] += pt2[i*qdim+j];
      seg[i*lbsy.nf+j] = 0.0;
    }
  }

  // calculate local forcing and segregation terms
    
  for(int k=0; k<numpair; k++) {
    int i = lbspair[2*k  ];
    int j = lbspair[2*k+1];
    nx = pt4[3*k  ];
    ny = pt4[3*k+1];
    nz = pt4[3*k+2];
    forceconst = lbseg[lbsy.nf*j+i] * lbg[lbsy.nf*j+i] * rho[i] * rho[j];
    segpiece = lbseg[lbsy.nf*j+i] * rho[i] * rho[j] * invallmass * invallmass;
    for(int m=0; m<lbsy.nq; m++) {
      ex = lbvx[m];
      ey = lbvy[m];
      ez = lbvz[m];
      phaseforce[m] += forceconst * ((nx*nx-1.0)*(ex*ex-lbcssq) + (ny*ny-1.0)*(ey*ey-lbcssq) + 2.0*nx*ny*ex*ey
                     + threed*((nz*nz-1.0)*(ez*ez-lbcssq) + 2.0*nz*ez*(nx*ex+ny*ey)));
      segcomp = segpiece * (lbvwx[m]*nx + lbvwy[m]*ny + lbvwz[m]*nz);
      seg[m*lbsy.nf+i] += segcomp;
      seg[m*lbsy.nf+j] -= segcomp;
    }
  }

  // collide and segregate fluids
    
  omega2 = fTRTOmegaAntisymmetric(omega1, lbtrtmagic);
  invmassrelax = fReciprocal(omega1 * density);
  omegaplus = 0.5 * (omega1 + omega2);
  omegaminus = 0.5 * (omega1 - omega2);
  relax = 1.0 - omegaplus;
  forceconst = omega1 * invallmass * invallmass * lbrcssq * lbrcssq * fReciprocal(density);

  speed[0] = sitespeed[0] + pt3[0] * invmassrelax;
  speed[1] = sitespeed[1] + pt3[1] * invmassrelax;
  speed[2] = sitespeed[2] + pt3[2] * invmassrelax;
  fGetEquilibriumFIncom(&feq[0], speed, allmass, density);
  for(int i=0; i<lbsy.nq; i++){
    collneg[i] = feq[i] - lbfac[i];
  }
  for(int m=0; m<lbsy.nq; m++){
    int k = lbopv[m];
    collpiece = relax * lbfac[m] + feq[m]*omegaplus + collneg[k]*omegaminus + lbw[m]*forceconst*phaseforce[m];
    for(int i=0; i<lbsy.nf; i++) {
      pt2[m*qdim+i] = rho[i] * collpiece * invallmass + seg[m*lbsy.nf+i];
    }
  }

  pt2 = NULL;
  pt3 = NULL;  
  pt4 = NULL;  
  return 0;
}

int fSiteFluidCollisionTRTEDMLishchukLocal(double* startpos, double *sitespeed, double *omega, double *rho, double* bodyforce, double* phaseindex, int threed)
{

  // TRT collision of achromatic fluid and D'Ortona segregration
  // calculate interfacial forcing terms and collisions at grid point:
  // uses two relaxation time scheme with Exact Difference Method forcing term

  double dv[3], feq[lbsy.nq], collneg[lbsy.nq];
  double allmass, invallmass, omega1, omega2, omegaplus, omegaminus, ex, ey, ez, nx, ny, nz;
  double forceconst, segpiece, collpiece, segcomp, relax, source;
  double modv,eixux,eiyuy,eizuz,eixdux,eiyduy,eizduz;
  double seg[lbsy.nf*lbsy.nq], lbfac[lbsy.nq], phaseforce[lbsy.nq];
  double *pt2 = &startpos[0];
  double *pt3 = &bodyforce[0];
  double *pt4 = &phaseindex[0];
  int numpair = lbsy.nf*(lbsy.nf-1)/2;
  int qdim = lbsy.nf+lbsy.nc+lbsy.nt;

  // collision of achromatic fluid

  allmass = 0.0;
  omega1 = 0.0;

  for(int j=0; j<lbsy.nf; j++) {
    allmass += rho[j];
    omega1 += omega[j] * rho[j];
  }

  invallmass = fReciprocal(allmass);
  omega1 *= invallmass;
      
  for(int i=0; i<lbsy.nq; i++) {
    lbfac[i] = 0.0;
    phaseforce[i] = 0.0;
    for(int j=0; j<lbsy.nf; j++) {
      lbfac[i] += pt2[i*qdim+j];
      seg[i*lbsy.nf+j] = 0.0;
    }
  }

  // calculate local forcing and segregation terms
    
  for(int k=0; k<numpair; k++) {
    int i = lbspair[2*k  ];
    int j = lbspair[2*k+1];
    nx = pt4[3*k  ];
    ny = pt4[3*k+1];
    nz = pt4[3*k+2];
    forceconst = lbseg[lbsy.nf*j+i] * lbg[lbsy.nf*j+i] * rho[i] * rho[j];
    segpiece = lbseg[lbsy.nf*j+i] * rho[i] * rho[j] * invallmass * invallmass;
    for(int m=0; m<lbsy.nq; m++) {
      ex = lbvx[m];
      ey = lbvy[m];
      ez = lbvz[m];
      phaseforce[m] += forceconst * ((nx*nx-1.0)*(ex*ex-lbcssq) + (ny*ny-1.0)*(ey*ey-lbcssq) + 2.0*nx*ny*ex*ey
                     + threed*((nz*nz-1.0)*(ez*ez-lbcssq) + 2.0*nz*ez*(nx*ex+ny*ey)));
      segcomp = segpiece * (lbvwx[m]*nx + lbvwy[m]*ny + lbvwz[m]*nz);
      seg[m*lbsy.nf+i] += segcomp;
      seg[m*lbsy.nf+j] -= segcomp;
    }
  }
  
  // collide and segregate fluids
    
  omega2 = fTRTOmegaAntisymmetric(omega1, lbtrtmagic);
  omegaplus = 0.5 * (omega1 + omega2);
  omegaminus = 0.5 * (omega1 - omega2);
  relax = 1.0 - omegaplus;
  dv[0] = pt3[0] * invallmass;
  dv[1] = pt3[1] * invallmass;
  dv[2] = pt3[2] * invallmass;
  forceconst = omega1 * invallmass * invallmass * invallmass * lbrcssq * lbrcssq;

  fGetEquilibriumF(&feq[0], sitespeed, allmass);
  modv = dv[0]*(2.0*sitespeed[0]+dv[0]) + dv[1]*(2.0*sitespeed[1]+dv[1]) + dv[2]*(2.0*sitespeed[2]+dv[2]);
  for(int i=0; i<lbsy.nq; i++) {
    collneg[i] = feq[i] - lbfac[i];
  }
  for(int m=0; m<lbsy.nq; m++){
    int k = lbopv[m];
    eixux =  lbvx[m]*sitespeed[0];
    eiyuy =  lbvy[m]*sitespeed[1];
    eizuz =  lbvz[m]*sitespeed[2];
    eixdux = lbvx[m]*dv[0];
    eiyduy = lbvy[m]*dv[1];
    eizduz = lbvz[m]*dv[2];
    source = allmass * lbw[m] * (3.0 * (eixdux+eiyduy+eizduz) +
                                 4.5 * (eixdux*(eixdux+2.0*(eixux+eiyuy+eizuz+eiyduy+eizduz)) +
                                        eiyduy*(eiyduy+2.0*(eixux+eiyuy+eizuz+eizduz)) +
                                        eizduz*(eizduz+2.0*(eixux+eiyuy+eizuz))) -
                                 1.5 * modv);
    collpiece = relax * lbfac[m] + source + feq[m]*omegaplus + collneg[k]*omegaminus + lbw[m]*forceconst*phaseforce[m];
    for(int i=0; i<lbsy.nf; i++) {
      pt2[m*qdim+i] = rho[i] * collpiece * invallmass + seg[m*lbsy.nf+i];
    }
  }

  pt2 = NULL;
  pt3 = NULL;  
  pt4 = NULL;  
  return 0;
}

int fSiteFluidIncomCollisionTRTEDMLishchukLocal(double* startpos, double *sitespeed, double *omega, double *rho, double* bodyforce, double* phaseindex, int threed)
{

  // TRT collision of achromatic fluid and D'Ortona segregration
  // calculate interfacial forcing terms and collisions at grid point:
  // uses two relaxation time scheme with incompressible fluids and
  // Exact Difference Method forcing term

  double dv[3], feq[lbsy.nq], collneg[lbsy.nq];
  double allmass, invallmass, invmass, relax, density, omega1, omega2;
  double omegaplus, omegaminus, ex, ey, ez, nx, ny, nz, forceconst, segcomp, segpiece, collpiece, source;
  double modv,eixux,eiyuy,eizuz,eixdux,eiyduy,eizduz;
  double seg[lbsy.nf*lbsy.nq], lbfac[lbsy.nq], phaseforce[lbsy.nq];
  double *pt2 = &startpos[0];
  double *pt3 = &bodyforce[0];
  double *pt4 = &phaseindex[0];
  int numpair = lbsy.nf*(lbsy.nf-1)/2;
  int qdim = lbsy.nf+lbsy.nc+lbsy.nt;

  // collision of achromatic fluid

  allmass = 0.0;
  omega1 = 0.0;
  density = 0.0;

  for(int j=0; j<lbsy.nf; j++) {
    allmass += rho[j];
    omega1 += omega[j] * rho[j];
    density += lbincp[j] * rho[j];
  }

  invallmass = fReciprocal(allmass);
  omega1 *= invallmass;
  density *= invallmass;

  for(int i=0; i<lbsy.nq; i++) {
    lbfac[i] = 0.0;
    phaseforce[i] = 0.0;
    for(int j=0; j<lbsy.nf; j++) {
      lbfac[i] += pt2[i*qdim+j];
      seg[i*lbsy.nf+j] = 0.0;
    }
  }

  // calculate local forcing and segregation terms
    
  for(int k=0; k<numpair; k++) {
    int i = lbspair[2*k  ];
    int j = lbspair[2*k+1];
    nx = pt4[3*k  ];
    ny = pt4[3*k+1];
    nz = pt4[3*k+2];
    forceconst = lbseg[lbsy.nf*j+i] * lbg[lbsy.nf*j+i] * rho[i] * rho[j];
    segpiece = lbseg[lbsy.nf*j+i] * rho[i] * rho[j] * invallmass * invallmass;
    for(int m=0; m<lbsy.nq; m++) {
      ex = lbvx[m];
      ey = lbvy[m];
      ez = lbvz[m];
      phaseforce[m] += forceconst * ((nx*nx-1.0)*(ex*ex-lbcssq) + (ny*ny-1.0)*(ey*ey-lbcssq) + 2.0*nx*ny*ex*ey
                     + threed*((nz*nz-1.0)*(ez*ez-lbcssq) + 2.0*nz*ez*(nx*ex+ny*ey)));
      segcomp = segpiece * (lbvwx[m]*nx + lbvwy[m]*ny + lbvwz[m]*nz);
      seg[m*lbsy.nf+i] += segcomp;
      seg[m*lbsy.nf+j] -= segcomp;
    }
  }

  // collide and segregate fluids
    
  omega2 = fTRTOmegaAntisymmetric(omega1, lbtrtmagic);
  invmass = fReciprocal(density);
  omegaplus = 0.5*(omega1+omega2);
  omegaminus = 0.5*(omega1-omega2);
  relax = 1.0 - omegaplus;
  forceconst = omega1 * invallmass * invallmass * lbrcssq * lbrcssq * invmass;

  dv[0] = pt3[0] * invmass;
  dv[1] = pt3[1] * invmass;
  dv[2] = pt3[2] * invmass;
  fGetEquilibriumFIncom(&feq[0], sitespeed, allmass, density);
  modv = dv[0]*(2.0*sitespeed[0]+dv[0]) + dv[1]*(2.0*sitespeed[1]+dv[1]) + dv[2]*(2.0*sitespeed[2]+dv[2]);
  for(int i=0; i<lbsy.nq; i++) {
    collneg[i] = feq[i] - lbfac[i];
  }
  for(int m=0; m<lbsy.nq; m++){
    int k = lbopv[m];
    eixux =  lbvx[m]*sitespeed[0];
    eiyuy =  lbvy[m]*sitespeed[1];
    eizuz =  lbvz[m]*sitespeed[2];
    eixdux = lbvx[m]*dv[0];
    eiyduy = lbvy[m]*dv[1];
    eizduz = lbvz[m]*dv[2];
    source = density * lbw[m] * (3.0 * (eixdux+eiyduy+eizduz) +
                                 4.5 * (eixdux*(eixdux+2.0*(eixux+eiyuy+eizuz+eiyduy+eizduz)) +
                                        eiyduy*(eiyduy+2.0*(eixux+eiyuy+eizuz+eizduz)) +
                                        eizduz*(eizduz+2.0*(eixux+eiyuy+eizuz))) -
                                 1.5 * modv);
    collpiece = relax * lbfac[m] + source + feq[m]*omegaplus + collneg[k]*omegaminus + lbw[m]*forceconst*phaseforce[m];
    for(int i=0; i<lbsy.nf; i++) {
      pt2[m*qdim+i] = rho[i] * collpiece * invallmass + seg[m*lbsy.nf+i];
    }
  }

  pt2 = NULL;
  pt3 = NULL;  
  pt4 = NULL;  
  return 0;
}

int fSiteFluidCollisionTRTGuoLishchukLocal(double* startpos, double *sitespeed, double *omega, double *rho, double* bodyforce, double* phaseindex, int threed)
{

  // TRT collision of achromatic fluid and D'Ortona segregration
  // calculate interfacial forcing terms and collisions at grid point:
  // uses two relaxation time scheme with Guo forcing term

  double speed[3], force[3], feq[lbsy.nq], source[lbsy.nq], collneg[lbsy.nq];
  double udot, allmass, invallmass, omega1, omega2, omegaplus, omegaminus, nx, ny, nz;
  double ex, ey, ez, forceconst, segcomp, segpiece, collpiece, relax, halfrelax;
  double seg[lbsy.nf*lbsy.nq], lbfac[lbsy.nq], phaseforce[lbsy.nq];
  double *pt2 = &startpos[0];
  double *pt3 = &bodyforce[0];
  double *pt4 = &phaseindex[0];
  int numpair = lbsy.nf*(lbsy.nf-1)/2;
  int qdim = lbsy.nf+lbsy.nc+lbsy.nt;

  // collision of achromatic fluid

  allmass = 0.0;
  omega1 = 0.0;

  for(int j=0; j<lbsy.nf; j++) {
    allmass += rho[j];
    omega1 += omega[j] * rho[j];
  }

  invallmass = fReciprocal(allmass);
  omega1 *= invallmass;
      
  for(int i=0; i<lbsy.nq; i++) {
    lbfac[i] = 0.0;
    phaseforce[i] = 0.0;
    for(int j=0; j<lbsy.nf; j++) {
      lbfac[i] += pt2[i*qdim+j];
      seg[i*lbsy.nf+j] = 0.0;
    }
  }

  // calculate local forcing and segregation terms
    
  for(int k=0; k<numpair; k++) {
    int i = lbspair[2*k  ];
    int j = lbspair[2*k+1];
    nx = pt4[3*k  ];
    ny = pt4[3*k+1];
    nz = pt4[3*k+2];
    forceconst = lbseg[lbsy.nf*j+i] * lbg[lbsy.nf*j+i] * rho[i] * rho[j];
    segpiece = lbseg[lbsy.nf*j+i] * rho[i] * rho[j] * invallmass * invallmass;
    for(int m=0; m<lbsy.nq; m++) {
      ex = lbvx[m];
      ey = lbvy[m];
      ez = lbvz[m];
      phaseforce[m] += forceconst * ((nx*nx-1.0)*(ex*ex-lbcssq) + (ny*ny-1.0)*(ey*ey-lbcssq) + 2.0*nx*ny*ex*ey
                     + threed*((nz*nz-1.0)*(ez*ez-lbcssq) + 2.0*nz*ez*(nx*ex+ny*ey)));
      segcomp = segpiece * (lbvwx[m]*nx + lbvwy[m]*ny + lbvwz[m]*nz);
      seg[m*lbsy.nf+i] += segcomp;
      seg[m*lbsy.nf+j] -= segcomp;
    }
  }

  // collide and segregate fluids

  force[0] = pt3[0];
  force[1] = pt3[1];
  force[2] = pt3[2];
  speed[0] = sitespeed[0] + 0.5 * force[0] * invallmass;
  speed[1] = sitespeed[1] + 0.5 * force[1] * invallmass;
  speed[2] = sitespeed[2] + 0.5 * force[2] * invallmass;
  fGetEquilibriumF(&feq[0], speed, allmass);
  omega2 = fTRTOmegaAntisymmetric(omega1, lbtrtmagic);
  omegaplus = 0.5*(omega1+omega2);
  omegaminus = 0.5*(omega1-omega2);
  relax = 1.0 - omegaplus;
  halfrelax = 1.0 - 0.5*omegaplus;
  forceconst = omega1 * invallmass * invallmass * invallmass * lbrcssq * lbrcssq;

  for(int i=0; i<lbsy.nq; i++){
    ex = lbvx[i];
    ey = lbvy[i];
    ez = lbvz[i];
    udot = ex * speed[0] + ey * speed[1] + ez * speed[2];
    source[i] = (3.0*(ex-speed[0]) + 9.0*udot*ex) * force[0]
              + (3.0*(ey-speed[1]) + 9.0*udot*ey) * force[1]
              + (3.0*(ez-speed[2]) + 9.0*udot*ez) * force[2];
    collneg[i] = feq[i] - lbfac[i];
  }
  for(int m=0; m<lbsy.nq; m++) {
    int k = lbopv[m];
    collpiece = relax*lbfac[m] + halfrelax*lbw[m]*source[m] + feq[m]*omegaplus
              + (collneg[k]-0.5*lbw[k]*source[k])*omegaminus + lbw[m]*forceconst*phaseforce[m];
    for(int i=0; i<lbsy.nf; i++) {
      pt2[m*qdim+i] = rho[i] * collpiece * invallmass + seg[m*lbsy.nf+i];
    }
  }

  pt2 = NULL;
  pt3 = NULL;  
  pt4 = NULL;  
  return 0;
}

int fSiteFluidIncomCollisionTRTGuoLishchukLocal(double* startpos, double *sitespeed, double *omega, double *rho, double* bodyforce, double* phaseindex, int threed)
{

  // BGK collision of achromatic fluid and D'Ortona segregration 
  // calculate interfacial forcing terms and collisions at grid point:
  // uses two relaxation time scheme with Guo forcing term for incompressible fluids

  double speed[3], force[3], feq[lbsy.nq], source[lbsy.nq], collneg[lbsy.nq];
  double udot, allmass, invallmass, density, invdensity;
  double omega1, omega2, omegaplus, omegaminus, nx, ny, nz;
  double ex, ey, ez, forceconst, segcomp, segpiece, collpiece, relax, halfrelax;
  double seg[lbsy.nf*lbsy.nq], lbfac[lbsy.nq], phaseforce[lbsy.nq];
  double *pt2 = &startpos[0];
  double *pt3 = &bodyforce[0];
  double *pt4 = &phaseindex[0];
  int numpair = lbsy.nf*(lbsy.nf-1)/2;
  int qdim = lbsy.nf+lbsy.nc+lbsy.nt;

  // collision of achromatic fluid

  allmass = 0.0;
  omega1 = 0.0;
  density = 0.0;

  for(int j=0; j<lbsy.nf; j++) {
    allmass += rho[j];
    omega1 += omega[j] * rho[j];
    density += lbincp[j] * rho[j];
  }

  invallmass = fReciprocal(allmass);
  omega1 *= invallmass;
  density *= invallmass;

  for(int i=0; i<lbsy.nq; i++) {
    lbfac[i] = 0.0;
    phaseforce[i] = 0.0;
    for(int j=0; j<lbsy.nf; j++) {
      lbfac[i] += pt2[i*qdim+j];
      seg[i*lbsy.nf+j] = 0.0;
    }
  }

  // calculate local forcing and segregation terms
    
  for(int k=0; k<numpair; k++) {
    int i = lbspair[2*k  ];
    int j = lbspair[2*k+1];
    nx = pt4[3*k  ];
    ny = pt4[3*k+1];
    nz = pt4[3*k+2];
    forceconst = lbseg[lbsy.nf*j+i] * lbg[lbsy.nf*j+i] * rho[i] * rho[j];
    segpiece = lbseg[lbsy.nf*j+i] * rho[i] * rho[j] * invallmass * invallmass;
    for(int m=0; m<lbsy.nq; m++) {
      ex = lbvx[m];
      ey = lbvy[m];
      ez = lbvz[m];
      phaseforce[m] += forceconst * ((nx*nx-1.0)*(ex*ex-lbcssq) + (ny*ny-1.0)*(ey*ey-lbcssq) + 2.0*nx*ny*ex*ey
                     + threed*((nz*nz-1.0)*(ez*ez-lbcssq) + 2.0*nz*ez*(nx*ex+ny*ey)));
      segcomp = segpiece * (lbvwx[m]*nx + lbvwy[m]*ny + lbvwz[m]*nz);
      seg[m*lbsy.nf+i] += segcomp;
      seg[m*lbsy.nf+j] -= segcomp;
    }
  }

  // collide and segregate fluids

  invdensity = fReciprocal(density);
  force[0] = pt3[0];
  force[1] = pt3[1];
  force[2] = pt3[2];
  speed[0] = sitespeed[0] + 0.5 * force[0] * invdensity;
  speed[1] = sitespeed[1] + 0.5 * force[1] * invdensity;
  speed[2] = sitespeed[2] + 0.5 * force[2] * invdensity;
  fGetEquilibriumFIncom(&feq[0], speed, allmass, density);
  omega2 = fTRTOmegaAntisymmetric(omega1, lbtrtmagic);
  omegaplus = 0.5*(omega1+omega2);
  omegaminus = 0.5*(omega1-omega2);
  relax = 1.0 - omegaplus;
  halfrelax = 1.0 - 0.5*omegaplus;
  forceconst = omega1 * invallmass * invallmass * lbrcssq * lbrcssq * invdensity;

  for(int i=0; i<lbsy.nq; i++){
    ex = lbvx[i];
    ey = lbvy[i];
    ez = lbvz[i];
    udot = ex * speed[0] + ey * speed[1] + ez * speed[2];
    source[i] = (3.0*(ex-speed[0]) + 9.0*udot*ex) * force[0]
              + (3.0*(ey-speed[1]) + 9.0*udot*ey) * force[1]
              + (3.0*(ez-speed[2]) + 9.0*udot*ez) * force[2];
    collneg[i] = feq[i] - lbfac[i];
  }
  for(int m=0; m<lbsy.nq; m++) {
    int k = lbopv[m];
    collpiece = relax*lbfac[m] + halfrelax*lbw[m]*source[m] + feq[m]*omegaplus
              + (collneg[k]-0.5*lbw[k]*source[k])*omegaminus + lbw[m]*forceconst*phaseforce[m];
    for(int i=0; i<lbsy.nf; i++) {
      pt2[m*qdim+i] = rho[i] * collpiece * invallmass + seg[m*lbsy.nf+i];
    }
  }

  pt2 = NULL;
  pt3 = NULL;  
  pt4 = NULL;  
  return 0;
}

int fSiteFluidCollisionTRTHeLishchukLocal(double* startpos, double *sitespeed, double *omega, double *rho, double* bodyforce, double* phaseindex, int threed)
{

  // TRT collision of achromatic fluid and D'Ortona segregration
  // calculate interfacial forcing terms and collisions at grid point:
  // uses two relaxation time scheme with He forcing term

  double speed[3], force[3], feq[lbsy.nq], source[lbsy.nq], collneg[lbsy.nq];
  double udot, fdot, modv, modf, allmass, invallmass, omega1, omega2, omegaplus, omegaminus, nx, ny, nz;
  double ex, ey, ez, forceconst, segcomp, segpiece, collpiece, relax, halfrelax;
  double seg[lbsy.nf*lbsy.nq], lbfac[lbsy.nq], phaseforce[lbsy.nq];
  double *pt2 = &startpos[0];
  double *pt3 = &bodyforce[0];
  double *pt4 = &phaseindex[0];
  int numpair = lbsy.nf*(lbsy.nf-1)/2;
  int qdim = lbsy.nf+lbsy.nc+lbsy.nt;

  // collision of achromatic fluid

  allmass = 0.0;
  omega1 = 0.0;

  for(int j=0; j<lbsy.nf; j++) {
    allmass += rho[j];
    omega1 += omega[j] * rho[j];
  }

  invallmass = fReciprocal(allmass);
  omega1 *= invallmass;
    
  for(int i=0; i<lbsy.nq; i++) {
    lbfac[i] = 0.0;
    phaseforce[i] = 0.0;
    for(int j=0; j<lbsy.nf; j++) {
      lbfac[i] += pt2[i*qdim+j];
      seg[i*lbsy.nf+j] = 0.0;
    }
  }

  // calculate local forcing and segregation terms
    
  for(int k=0; k<numpair; k++) {
    int i = lbspair[2*k  ];
    int j = lbspair[2*k+1];
    nx = pt4[3*k  ];
    ny = pt4[3*k+1];
    nz = pt4[3*k+2];
    forceconst = lbseg[lbsy.nf*j+i] * lbg[lbsy.nf*j+i] * rho[i] * rho[j];
    segpiece = lbseg[lbsy.nf*j+i] * rho[i] * rho[j] * invallmass * invallmass;
    for(int m=0; m<lbsy.nq; m++) {
      ex = lbvx[m];
      ey = lbvy[m];
      ez = lbvz[m];
      phaseforce[m] += forceconst * ((nx*nx-1.0)*(ex*ex-lbcssq) + (ny*ny-1.0)*(ey*ey-lbcssq) + 2.0*nx*ny*ex*ey
                     + threed*((nz*nz-1.0)*(ez*ez-lbcssq) + 2.0*nz*ez*(nx*ex+ny*ey)));
      segcomp = segpiece * (lbvwx[m]*nx + lbvwy[m]*ny + lbvwz[m]*nz);
      seg[m*lbsy.nf+i] += segcomp;
      seg[m*lbsy.nf+j] -= segcomp;
    }
  }

  // collide and segregate fluids

  force[0] = pt3[0];
  force[1] = pt3[1];
  force[2] = pt3[2];
  speed[0] = sitespeed[0] + 0.5 * force[0] * invallmass;
  speed[1] = sitespeed[1] + 0.5 * force[1] * invallmass;
  speed[2] = sitespeed[2] + 0.5 * force[2] * invallmass;
  modv = speed[0] * speed[0] + speed[1] * speed[1] + speed[2] * speed[2];
  modf = speed[0] * force[0] + speed[1] * force[1] + speed[2] * force[2];
  fGetEquilibriumF(&feq[0], speed, allmass);
  omega2 = fTRTOmegaAntisymmetric(omega1, lbtrtmagic);
  omegaplus = 0.5*(omega1+omega2);
  omegaminus = 0.5*(omega1-omega2);
  relax = 1.0 - omegaplus;
  halfrelax = 1.0 - 0.5*omegaplus;
  forceconst = omega1 * invallmass * invallmass * invallmass * lbrcssq * lbrcssq;

  for(int i=0; i<lbsy.nq; i++){
    ex = lbvx[i];
    ey = lbvy[i];
    ez = lbvz[i];
    udot = ex * speed[0] + ey * speed[1] + ez * speed[2];
    fdot = ex * force[0] + ey * force[1] + ez * force[2];
    source[i] = 3.0*(fdot-modf)*(1.0+3.0*udot) + 4.5*fdot*(3.0*udot*udot-modv);
    collneg[i] = feq[i] - lbfac[i];
  }
  for(int m=0; m<lbsy.nq; m++) {
    int k = lbopv[m];
    collpiece = relax*lbfac[m] + halfrelax*lbw[m]*source[m] + feq[m]*omegaplus
              + (collneg[k]-0.5*lbw[k]*source[k])*omegaminus + lbw[m]*forceconst*phaseforce[m];
    for(int i=0; i<lbsy.nf; i++) {
      pt2[m*qdim+i] = rho[i] * collpiece * invallmass + seg[m*lbsy.nf+i];
    }
  }

  pt2 = NULL;
  pt3 = NULL;
  pt4 = NULL;
  return 0;
}

int fSiteFluidIncomCollisionTRTHeLishchukLocal(double* startpos, double *sitespeed, double *omega, double *rho, double* bodyforce, double* phaseindex, int threed)
{

  // BGK collision of achromatic fluid and D'Ortona segregration
  // calculate interfacial forcing terms and collisions at grid point:
  // uses two relaxation time scheme with He forcing term for incompressible fluids

  double speed[3], force[3], feq[lbsy.nq], source[lbsy.nq], collneg[lbsy.nq];
  double udot, fdot, modv, modf, allmass, invallmass, density, invdensity;
  double omega1, omega2, omegaplus, omegaminus, nx, ny, nz;
  double ex, ey, ez, forceconst, segcomp, segpiece, collpiece, relax, halfrelax;
  double seg[lbsy.nf*lbsy.nq], lbfac[lbsy.nq], phaseforce[lbsy.nq];
  double *pt2 = &startpos[0];
  double *pt3 = &bodyforce[0];
  double *pt4 = &phaseindex[0];
  int numpair = lbsy.nf*(lbsy.nf-1)/2;
  int qdim = lbsy.nf+lbsy.nc+lbsy.nt;

  // collision of achromatic fluid

  allmass = 0.0;
  omega1 = 0.0;
  density = 0.0;

  for(int j=0; j<lbsy.nf; j++) {
    allmass += rho[j];
    omega1 += omega[j] * rho[j];
    density += lbincp[j] * rho[j];
  }

  invallmass = fReciprocal(allmass);
  omega1 *= invallmass;
  density *= invallmass;

  for(int i=0; i<lbsy.nq; i++) {
    lbfac[i] = 0.0;
    phaseforce[i] = 0.0;
    for(int j=0; j<lbsy.nf; j++) {
      lbfac[i] += pt2[i*qdim+j];
      seg[i*lbsy.nf+j] = 0.0;
    }
  }

  // calculate local forcing and segregation terms
    
  for(int k=0; k<numpair; k++) {
    int i = lbspair[2*k  ];
    int j = lbspair[2*k+1];
    nx = pt4[3*k  ];
    ny = pt4[3*k+1];
    nz = pt4[3*k+2];
    forceconst = lbseg[lbsy.nf*j+i] * lbg[lbsy.nf*j+i] * rho[i] * rho[j];
    segpiece = lbseg[lbsy.nf*j+i] * rho[i] * rho[j] * invallmass * invallmass;
    for(int m=0; m<lbsy.nq; m++) {
      ex = lbvx[m];
      ey = lbvy[m];
      ez = lbvz[m];
      phaseforce[m] += forceconst * ((nx*nx-1.0)*(ex*ex-lbcssq) + (ny*ny-1.0)*(ey*ey-lbcssq) + 2.0*nx*ny*ex*ey
                     + threed*((nz*nz-1.0)*(ez*ez-lbcssq) + 2.0*nz*ez*(nx*ex+ny*ey)));
      segcomp = segpiece * (lbvwx[m]*nx + lbvwy[m]*ny + lbvwz[m]*nz);
      seg[m*lbsy.nf+i] += segcomp;
      seg[m*lbsy.nf+j] -= segcomp;
    }
  }

  // collide and segregate fluids

  invdensity = fReciprocal(density);
  force[0] = pt3[0];
  force[1] = pt3[1];
  force[2] = pt3[2];
  speed[0] = sitespeed[0] + 0.5 * force[0] * invdensity;
  speed[1] = sitespeed[1] + 0.5 * force[1] * invdensity;
  speed[2] = sitespeed[2] + 0.5 * force[2] * invdensity;
  fGetEquilibriumFIncom(&feq[0], speed, allmass, density);
  modv = speed[0] * speed[0] + speed[1] * speed[1] + speed[2] * speed[2];
  modf = speed[0] * force[0] + speed[1] * force[1] + speed[2] * force[2];
  omega2 = fTRTOmegaAntisymmetric(omega1, lbtrtmagic);
  omegaplus = 0.5*(omega1+omega2);
  omegaminus = 0.5*(omega1-omega2);
  relax = 1.0 - omegaplus;
  halfrelax = 1.0 - 0.5*omegaplus;
  forceconst = omega1 * invallmass * invallmass * lbrcssq * lbrcssq * invdensity;

  for(int i=0; i<lbsy.nq; i++){
    ex = lbvx[i];
    ey = lbvy[i];
    ez = lbvz[i];
    udot = ex * speed[0] + ey * speed[1] + ez * speed[2];
    fdot = ex * force[0] + ey * force[1] + ez * force[2];
    source[i] = 3.0*(fdot-modf)*(1.0+3.0*udot) + 4.5*fdot*(3.0*udot*udot-modv);
    collneg[i] = feq[i] - lbfac[i];
  }
  for(int m=0; m<lbsy.nq; m++) {
    int k = lbopv[m];
    collpiece = relax*lbfac[m] + halfrelax*lbw[m]*source[m] + feq[m]*omegaplus
              + (collneg[k]-0.5*lbw[k]*source[k])*omegaminus + lbw[m]*forceconst*phaseforce[m];
    for(int i=0; i<lbsy.nf; i++) {
      pt2[m*qdim+i] = rho[i] * collpiece * invallmass + seg[m*lbsy.nf+i];
    }
  }

  pt2 = NULL;
  pt3 = NULL;
  pt4 = NULL;
  return 0;
}

// Swift free-energy collisions

int fSiteFluidCollisionTRTSwiftOneFluid(double* startpos, double *sitespeed, double *omega, double *rho, double* gradient, double* bodyforce, double T)
{
  
  // calculate fluid collisions at grid point: uses two relaxation time scheme
  // and Swift free-energy interactions for one fluid

  double speed[3], feq[lbsy.nq], collneg[lbsy.nq];
  double invmassrelax, relax, omeganeg, omegaplus, omegaminus, pb, lambda;
  double *pt2 = &startpos[0];
  double *pt3 = &gradient[0];
  double *pt4 = &bodyforce[0];
  int qdim = lbsy.nf+lbsy.nc+lbsy.nt;

  pb = fGetBulkPressureSwift(rho[0], 0.0, T);
  lambda = fGetLambdaSwift(rho[0], omega[0], T);
    
  invmassrelax = fReciprocal(rho[0]*omega[0]);
  omeganeg = fTRTOmegaAntisymmetric(omega[0], lbtrtmagic);
  omegaplus = 0.5 * (omega[0] + omeganeg);
  omegaminus = 0.5 * (omega[0] - omeganeg);
  relax = 1.0 - omegaplus;
  speed[0] = sitespeed[0] + pt4[0] * invmassrelax;
  speed[1] = sitespeed[1] + pt4[1] * invmassrelax;
  speed[2] = sitespeed[2] + pt4[2] * invmassrelax;
  fGetEquilibriumFSwiftOneFluid(feq, speed, rho[0], pb, lambda, pt3);
  for(int i=0; i<lbsy.nq; i++) {
    collneg[i] = feq[i] - pt2[i*qdim];
  }
  for(int i=0; i<lbsy.nq; i++){
    int k = lbopv[i];
    pt2[i*qdim] = relax * pt2[i*qdim] + feq[i]*omegaplus + collneg[k]*omegaminus;
  }

  pt2 = NULL;
  pt3 = NULL;
  pt4 = NULL;
  return 0;
}

int fSiteFluidCollisionTRTSwiftTwoFluid(double* startpos, double *sitespeed, double *omega, double *rho, double* gradient, double* bodyforce, double T)
{
  
  // calculate fluid collisions at grid point: uses two relaxation time scheme
  // and Swift free-energy interactions for two fluids (TRT for density distribution,
  // BGK for concentration distribution)

  double speed[3], feq[lbsy.nq], collneg[lbsy.nq];
  double invmassrelax, relax, relaxphi, omega1, omega2, omegaplus, omegaminus;
  double pb, mu, lambda;
  double *pt2 = &startpos[0];
  double *pt3 = &gradient[0];
  double *pt4 = &bodyforce[0];
  int qdim = lbsy.nf+lbsy.nc+lbsy.nt;

  omega1 = 2.0*omega[0]*omega[1]/(2.0*omega[0]+(1.0+rho[1])*(omega[1]-omega[0]));
  pb = fGetBulkPressureSwift(rho[0], rho[1], T);
  lambda = fGetLambdaSwift(rho[0], omega1, T);
  mu = fGetPotentialSwift(rho[1], pt3[7]);
    
  omega2 = fTRTOmegaAntisymmetric(omega1, lbtrtmagic);
  omegaplus = 0.5*(omega1+omega2);
  omegaminus = 0.5*(omega1-omega2);
  invmassrelax = fReciprocal(rho[0]*omega1);
  relax = 1.0 - omegaplus;
  relaxphi = 1.0 - lbtmob;
  speed[0] = sitespeed[0] + pt4[0] * invmassrelax;
  speed[1] = sitespeed[1] + pt4[1] * invmassrelax;
  speed[2] = sitespeed[2] + pt4[2] * invmassrelax;
  fGetEquilibriumFSwiftTwoFluid(feq, speed, rho[0], rho[1], pb, mu, lambda, pt3);
  for(int i=0; i<lbsy.nq; i++) {
    collneg[i] = feq[2*i] - pt2[i*qdim];
  }
  for(int i=0; i<lbsy.nq; i++){
    int k = lbopv[i];
    pt2[i*qdim  ] = relax    * pt2[i*qdim  ] + feq[2*i  ]*omegaplus + collneg[k]*omegaminus;
    pt2[i*qdim+1] = relaxphi * pt2[i*qdim+1] + feq[2*i+1]*lbtmob;
  }

  pt2 = NULL;
  pt3 = NULL;
  pt4 = NULL;
  return 0;
}

int fSiteFluidCollisionTRTEDMSwiftOneFluid(double* startpos, double *sitespeed, double *omega, double *rho, double* gradient, double* bodyforce, double T)
{
  
  // calculate fluid collisions at grid point: uses two relaxation time scheme with
  // Exact Difference Method forcing term and Swift free-energy interactions for one fluid

  double dv[3], feq[lbsy.nq], collneg[lbsy.nq];
  double invmass, relax, source, omeganeg, omegaplus, omegaminus, pb, lambda;
  double modv,eixux,eiyuy,eizuz,eixdux,eiyduy,eizduz;
  double *pt2 = &startpos[0];
  double *pt3 = &gradient[0];
  double *pt4 = &bodyforce[0];
  int qdim = lbsy.nf+lbsy.nc+lbsy.nt;

  pb = fGetBulkPressureSwift(rho[0], 0.0, T);
  lambda = fGetLambdaSwift(rho[0], omega[0], T);

  invmass = fReciprocal(rho[0]);
  dv[0] = pt4[0] * invmass;
  dv[1] = pt4[1] * invmass;
  dv[2] = pt4[2] * invmass;
  fGetEquilibriumFSwiftOneFluid(feq, sitespeed, rho[0], pb, lambda, pt3);
  omeganeg = fTRTOmegaAntisymmetric(omega[0], lbtrtmagic);
  omegaplus = 0.5 * (omega[0] + omeganeg);
  omegaminus = 0.5 * (omega[0] - omeganeg);
  relax = 1.0 - omegaplus;
  modv = dv[0]*(2.0*sitespeed[0]+dv[0]) + dv[1]*(2.0*sitespeed[1]+dv[1]) + dv[2]*(2.0*sitespeed[2]+dv[2]);
  for(int i=0; i<lbsy.nq; i++) {
    collneg[i] = feq[i] - pt2[i*qdim];
  }
  for(int i=0; i<lbsy.nq; i++){
    int k = lbopv[i];
    eixux =  lbvx[i]*sitespeed[0];
    eiyuy =  lbvy[i]*sitespeed[1];
    eizuz =  lbvz[i]*sitespeed[2];
    eixdux = lbvx[i]*dv[0];
    eiyduy = lbvy[i]*dv[1];
    eizduz = lbvz[i]*dv[2];
    source = rho[0] * lbw[i] * (3.0 * (eixdux+eiyduy+eizduz) +
                                4.5 * (eixdux*(eixdux+2.0*(eixux+eiyuy+eizuz+eiyduy+eizduz)) +
                                       eiyduy*(eiyduy+2.0*(eixux+eiyuy+eizuz+eizduz)) +
                                       eizduz*(eizduz+2.0*(eixux+eiyuy+eizuz))) -
                                1.5 * modv);
    pt2[i*qdim] = relax * pt2[i*qdim] + source + feq[i]*omegaplus + collneg[k]*omegaminus;
  }

  pt2 = NULL;
  pt3 = NULL;
  pt4 = NULL;
  return 0;
}

int fSiteFluidCollisionTRTEDMSwiftTwoFluid(double* startpos, double *sitespeed, double *omega, double *rho, double* gradient, double* bodyforce, double T)
{
  
  // calculate fluid collisions at grid point: uses two relaxation time scheme with
  // Exact Difference Method forcing term and Swift free-energy interactions for
  // two fluids (TRT for density distribution, BGK for concentration distribution)

  double dv[3], feq[2*lbsy.nq], collneg[lbsy.nq];
  double invmass, relax, relaxphi, source, omega1, omega2, omegaplus, omegaminus, pb, mu, lambda;
  double modv,eixux,eiyuy,eizuz,eixdux,eiyduy,eizduz;
  double *pt2 = &startpos[0];
  double *pt3 = &gradient[0];
  double *pt4 = &bodyforce[0];
  int qdim = lbsy.nf+lbsy.nc+lbsy.nt;

  omega1 = 2.0*omega[0]*omega[1]/(2.0*omega[0]+(1.0+rho[1])*(omega[1]-omega[0]));
  pb = fGetBulkPressureSwift(rho[0], rho[1], T);
  lambda = fGetLambdaSwift(rho[0], omega1, T);
  mu = fGetPotentialSwift(rho[1], pt3[7]);

  omega2 = fTRTOmegaAntisymmetric(omega1, lbtrtmagic);
  omegaplus = 0.5*(omega1+omega2);
  omegaminus = 0.5*(omega1-omega2);
  invmass = fReciprocal(rho[0]);
  dv[0] = pt4[0] * invmass;
  dv[1] = pt4[1] * invmass;
  dv[2] = pt4[2] * invmass;
  fGetEquilibriumFSwiftTwoFluid(feq, sitespeed, rho[0], rho[1], pb, mu, lambda, pt3);
  relax = 1.0 - omegaplus;
  relaxphi = 1.0 - lbtmob;
  modv = dv[0]*(2.0*sitespeed[0]+dv[0]) + dv[1]*(2.0*sitespeed[1]+dv[1]) + dv[2]*(2.0*sitespeed[2]+dv[2]);
  for(int i=0; i<lbsy.nq; i++) {
    collneg[i] = feq[2*i] - pt2[i*qdim];
  }
  for(int i=0; i<lbsy.nq; i++){
    int k = lbopv[i];
    eixux =  lbvx[i]*sitespeed[0];
    eiyuy =  lbvy[i]*sitespeed[1];
    eizuz =  lbvz[i]*sitespeed[2];
    eixdux = lbvx[i]*dv[0];
    eiyduy = lbvy[i]*dv[1];
    eizduz = lbvz[i]*dv[2];
    source = rho[0] * lbw[i] * (3.0 * (eixdux+eiyduy+eizduz) +
                                4.5 * (eixdux*(eixdux+2.0*(eixux+eiyuy+eizuz+eiyduy+eizduz)) +
                                       eiyduy*(eiyduy+2.0*(eixux+eiyuy+eizuz+eizduz)) +
                                       eizduz*(eizduz+2.0*(eixux+eiyuy+eizuz))) -
                                1.5 * modv);
    pt2[i*qdim  ] = relax    * pt2[i*qdim  ] + feq[2*i  ]*omegaplus + collneg[k]*omegaminus + source;
    pt2[i*qdim+1] = relaxphi * pt2[i*qdim+1] + feq[2*i+1]*lbtmob;
  }

  pt2 = NULL;
  pt3 = NULL;
  pt4 = NULL;
  return 0;
}

int fSiteFluidCollisionTRTGuoSwiftOneFluid(double* startpos, double *sitespeed, double *omega, double *rho, double* gradient, double* bodyforce, double T)
{
    
  // calculate fluid collisions at grid point: uses two relaxation time scheme with
  // Guo forcing term and Swift free-energy interactions for one fluid
    
  double speed[3], force[3], feq[lbsy.nq], collneg[lbsy.nq], source[lbsy.nq];
  double udot, invmass, relax, halfrelax, ex, ey, ez, omeganeg, omegaplus, omegaminus, pb, lambda;
  double *pt2 = &startpos[0];
  double *pt3 = &gradient[0];
  double *pt4 = &bodyforce[0];
  int qdim = lbsy.nf+lbsy.nc+lbsy.nt;

  pb = fGetBulkPressureSwift(rho[0], 0.0, T);
  lambda = fGetLambdaSwift(rho[0], omega[0], T);
    
  invmass = fReciprocal(rho[0]);
  force[0] = pt4[0];
  force[1] = pt4[1];
  force[2] = pt4[2];
  speed[0] = sitespeed[0] + 0.5 * force[0] * invmass;
  speed[1] = sitespeed[1] + 0.5 * force[1] * invmass;
  speed[2] = sitespeed[2] + 0.5 * force[2] * invmass;
  fGetEquilibriumFSwiftOneFluid(feq, speed, rho[0], pb, lambda, pt3);
  omeganeg = fTRTOmegaAntisymmetric(omega[0], lbtrtmagic);
  omegaplus = 0.5*(omega[0]+omeganeg);
  omegaminus = 0.5*(omega[0]-omeganeg);
  relax = 1.0 - omegaplus;
  halfrelax = 1.0 - 0.5*omegaplus;
  for(int i=0; i<lbsy.nq; i++){
    ex = lbvx[i];
    ey = lbvy[i];
    ez = lbvz[i];
    udot = ex * speed[0] + ey * speed[1] + ez * speed[2];
    source[i] = (3.0*(ex-speed[0]) + 9.0*udot*ex) * force[0]
              + (3.0*(ey-speed[1]) + 9.0*udot*ey) * force[1]
              + (3.0*(ez-speed[2]) + 9.0*udot*ez) * force[2];
    collneg[i] = feq[i] - pt2[i*qdim];
  }
  for(int i=0; i<lbsy.nq; i++) {
    int k = lbopv[i];
    pt2[i*qdim] = relax*pt2[i*qdim] + halfrelax*lbw[i]*source[i] + feq[i]*omegaplus
                + (collneg[k]-0.5*lbw[k]*source[k])*omegaminus;
  }
    
  pt2 = NULL;
  pt3 = NULL;
  pt4 = NULL;
  return 0;
}

int fSiteFluidCollisionTRTGuoSwiftTwoFluid(double* startpos, double *sitespeed, double *omega, double *rho, double* gradient, double* bodyforce, double T)
{
    
  // calculate fluid collisions at grid point: uses two relaxation time scheme with
  // Guo forcing term and Swift free-energy interactions for two fluids (TRT for
  // density distribution, BGK for concentration distribution)
    
  double speed[3], force[3], feq[2*lbsy.nq], collneg[lbsy.nq], source[lbsy.nq];
  double udot, invmass, relax, halfrelax, ex, ey, ez, omegaplus, omegaminus;
  double relaxphi, pb, mu, lambda, omega1, omega2;
  double *pt2 = &startpos[0];
  double *pt3 = &gradient[0];
  double *pt4 = &bodyforce[0];
  int qdim = lbsy.nf+lbsy.nc+lbsy.nt;

  omega1 = 2.0*omega[0]*omega[1]/(2.0*omega[0]+(1.0+rho[1])*(omega[1]-omega[0]));
  pb = fGetBulkPressureSwift(rho[0], rho[1], T);
  lambda = fGetLambdaSwift(rho[0], omega1, T);
  mu = fGetPotentialSwift(rho[1], pt3[7]);

  omega2 = fTRTOmegaAntisymmetric(omega1, lbtrtmagic);
  omegaplus = 0.5*(omega1+omega2);
  omegaminus = 0.5*(omega1-omega2);
  invmass = fReciprocal(rho[0]);
  force[0] = pt4[0];
  force[1] = pt4[1];
  force[2] = pt4[2];
  speed[0] = sitespeed[0] + 0.5 * force[0] * invmass;
  speed[1] = sitespeed[1] + 0.5 * force[1] * invmass;
  speed[2] = sitespeed[2] + 0.5 * force[2] * invmass;
  fGetEquilibriumFSwiftTwoFluid(feq, speed, rho[0], rho[1], pb, mu, lambda, pt3);
  relax = 1.0 - omegaplus;
  halfrelax = 1.0 - 0.5*omegaplus;
  relaxphi = 1.0 - lbtmob;
  for(int i=0; i<lbsy.nq; i++){
    ex = lbvx[i];
    ey = lbvy[i];
    ez = lbvz[i];
    udot = ex * speed[0] + ey * speed[1] + ez * speed[2];
    source[i] = (3.0*(ex-speed[0]) + 9.0*udot*ex) * force[0]
              + (3.0*(ey-speed[1]) + 9.0*udot*ey) * force[1]
              + (3.0*(ez-speed[2]) + 9.0*udot*ez) * force[2];
    collneg[i] = feq[i] - pt2[i*qdim];
  }
  for(int i=0; i<lbsy.nq; i++) {
    int k = lbopv[i];
    pt2[i*qdim  ] = relax*pt2[i*qdim] + halfrelax*lbw[i]*source[i] + feq[2*i]*omegaplus
                  + (collneg[k]-0.5*lbw[k]*source[k])*omegaminus;
    pt2[i*qdim+1] = relaxphi*pt2[i*qdim+1] + feq[2*i+1]*lbtmob;
  }
    
  pt2 = NULL;
  pt3 = NULL;
  pt4 = NULL;
  return 0;
}

int fSiteFluidCollisionTRTHeSwiftOneFluid(double* startpos, double *sitespeed, double *omega, double *rho, double* gradient, double* bodyforce, double T)
{
    
  // calculate fluid collisions at grid point: uses two relaxation time scheme with
  // He forcing term and Swift free-energy interactions for one fluid
    
  double speed[3], force[3], feq[lbsy.nq], collneg[lbsy.nq], source[lbsy.nq];
  double udot, fdot, modv, modf, invmass, relax, halfrelax, ex, ey, ez, omeganeg, omegaplus, omegaminus, pb, lambda;
  double *pt2 = &startpos[0];
  double *pt3 = &gradient[0];
  double *pt4 = &bodyforce[0];
  int qdim = lbsy.nf+lbsy.nc+lbsy.nt;

  pb = fGetBulkPressureSwift(rho[0], 0.0, T);
  lambda = fGetLambdaSwift(rho[0], omega[0], T);
    
  invmass = fReciprocal(rho[0]);
  force[0] = pt4[0];
  force[1] = pt4[1];
  force[2] = pt4[2];
  speed[0] = sitespeed[0] + 0.5 * force[0] * invmass;
  speed[1] = sitespeed[1] + 0.5 * force[1] * invmass;
  speed[2] = sitespeed[2] + 0.5 * force[2] * invmass;
  modv = speed[0] * speed[0] + speed[1] * speed[1] + speed[2] * speed[2];
  modf = speed[0] * force[0] + speed[1] * force[1] + speed[2] * force[2];
  fGetEquilibriumFSwiftOneFluid(feq, speed, rho[0], pb, lambda, pt3);
  omeganeg = fTRTOmegaAntisymmetric(omega[0], lbtrtmagic);
  omegaplus = 0.5*(omega[0]+omeganeg);
  omegaminus = 0.5*(omega[0]-omeganeg);
  relax = 1.0 - omegaplus;
  halfrelax = 1.0 - 0.5*omegaplus;
  for(int i=0; i<lbsy.nq; i++){
    ex = lbvx[i];
    ey = lbvy[i];
    ez = lbvz[i];
    udot = ex * speed[0] + ey * speed[1] + ez * speed[2];
    fdot = ex * force[0] + ey * force[1] + ez * force[2];
    source[i] = 3.0*(fdot-modf)*(1.0+3.0*udot) + 4.5*fdot*(3.0*udot*udot-modv);
    collneg[i] = feq[i] - pt2[i*qdim];
  }
  for(int i=0; i<lbsy.nq; i++) {
    int k = lbopv[i];
    pt2[i*qdim] = relax*pt2[i*qdim] + halfrelax*lbw[i]*source[i] + feq[i]*omegaplus
                + (collneg[k]-0.5*lbw[k]*source[k])*omegaminus;
  }
    
  pt2 = NULL;
  pt3 = NULL;
  pt4 = NULL;
  return 0;
}

int fSiteFluidCollisionTRTHeSwiftTwoFluid(double* startpos, double *sitespeed, double *omega, double *rho, double* gradient, double* bodyforce, double T)
{
    
  // calculate fluid collisions at grid point: uses two relaxation time scheme with
  // He forcing term and Swift free-energy interactions for two fluids (TRT for
  // density distribution, BGK for concentration distribution)
    
  double speed[3], force[3], feq[2*lbsy.nq], collneg[lbsy.nq], source[lbsy.nq];
  double udot, fdot, modv, modf, invmass, relax, halfrelax, ex, ey, ez, omegaplus, omegaminus;
  double relaxphi, pb, mu, lambda, omega1, omega2;
  double *pt2 = &startpos[0];
  double *pt3 = &gradient[0];
  double *pt4 = &bodyforce[0];
  int qdim = lbsy.nf+lbsy.nc+lbsy.nt;

  omega1 = 2.0*omega[0]*omega[1]/(2.0*omega[0]+(1.0+rho[1])*(omega[1]-omega[0]));
  pb = fGetBulkPressureSwift(rho[0], rho[1], T);
  lambda = fGetLambdaSwift(rho[0], omega1, T);
  mu = fGetPotentialSwift(rho[1], pt3[7]);

  omega2 = fTRTOmegaAntisymmetric(omega1, lbtrtmagic);
  omegaplus = 0.5*(omega1+omega2);
  omegaminus = 0.5*(omega1-omega2);
  invmass = fReciprocal(rho[0]);
  force[0] = pt4[0];
  force[1] = pt4[1];
  force[2] = pt4[2];
  speed[0] = sitespeed[0] + 0.5 * force[0] * invmass;
  speed[1] = sitespeed[1] + 0.5 * force[1] * invmass;
  speed[2] = sitespeed[2] + 0.5 * force[2] * invmass;
  modv = speed[0] * speed[0] + speed[1] * speed[1] + speed[2] * speed[2];
  modf = speed[0] * force[0] + speed[1] * force[1] + speed[2] * force[2];
  fGetEquilibriumFSwiftTwoFluid(feq, speed, rho[0], rho[1], pb, mu, lambda, pt3);
  relax = 1.0 - omegaplus;
  halfrelax = 1.0 - 0.5*omegaplus;
  relaxphi = 1.0 - lbtmob;
  for(int i=0; i<lbsy.nq; i++){
    ex = lbvx[i];
    ey = lbvy[i];
    ez = lbvz[i];
    udot = ex * speed[0] + ey * speed[1] + ez * speed[2];
    fdot = ex * force[0] + ey * force[1] + ez * force[2];
    source[i] = 3.0*(fdot-modf)*(1.0+3.0*udot) + 4.5*fdot*(3.0*udot*udot-modv);
    collneg[i] = feq[i] - pt2[i*qdim];
  }
  for(int i=0; i<lbsy.nq; i++) {
    int k = lbopv[i];
    pt2[i*qdim  ] = relax*pt2[i*qdim] + halfrelax*lbw[i]*source[i] + feq[2*i]*omegaplus
                  + (collneg[k]-0.5*lbw[k]*source[k])*omegaminus;
    pt2[i*qdim+1] = relaxphi*pt2[i*qdim+1] + feq[2*i+1]*lbtmob;
  }
    
  pt2 = NULL;
  pt3 = NULL;
  pt4 = NULL;
  return 0;
}

// Collision loops over all grid points

int fCollisionTRT()
{
  long Tmax = lbdm.touter;
  double freq = (lbbdforcetyp==1)*sin(lboscilfreq*(lbcurstep-lbequstep));

  if(!incompress) {

   #pragma omp parallel
   {
      double interforce_t[3*lbsy.nf], sitespeed_t[3], rho_t[lbsy.nf];
      double *interforce = &interforce_t[0];
      double *sitespeed = &sitespeed_t[0];
      double *rho = &rho_t[0];

      #pragma omp for
      for(long il=0; il<Tmax; il++) {
        if(lbphi[il] != 11) {
          fGetSpeedAllMassSite(sitespeed, rho, &lbf[il*lbsitelength]);
          for(int ll=0; ll<3*lbsy.nf; ll++)
	        interforce[ll] = lbinterforce[il*3*lbsy.nf+ll] + lbheatforce[il*3*lbsy.nf+ll] + postequil*(lbbdforce[ll]+lboscilforce[ll]*freq);
          if(lbphi[il] != 12 && lbphi[il] != 13)
            fSiteFluidCollisionTRT(&lbf[il*lbsitelength], sitespeed, &lbomega[il*lbsy.nf], rho, interforce);
          fSiteSoluteCollisionBGK(&lbf[il*lbsitelength + lbsy.nf], sitespeed);
          fSiteThermalCollisionBGK(&lbf[il*lbsitelength + (lbsy.nf+lbsy.nc)], sitespeed);
        }
      }
    }
  }
  else {
      
   #pragma omp parallel
   {
      double interforce_t[3*lbsy.nf], sitespeed_t[3], rho_t[lbsy.nf];
      double *interforce = &interforce_t[0];
      double *sitespeed = &sitespeed_t[0];
      double *rho = &rho_t[0];

      #pragma omp for
      for(long il=0; il<lbdm.touter; il++) {
        if(lbphi[il] != 11) {
          fGetSpeedIncomAllMassSite(sitespeed, rho, &lbf[il*lbsitelength]);
          for(int ll=0; ll<3*lbsy.nf; ll++)
	        interforce[ll] = lbinterforce[il*3*lbsy.nf+ll] + lbheatforce[il*3*lbsy.nf+ll] + postequil*(lbbdforce[ll]+lboscilforce[ll]*freq);
          if(lbphi[il] != 12 && lbphi[il] != 13)
            fSiteFluidIncomCollisionTRT(&lbf[il*lbsitelength], sitespeed, &lbomega[il*lbsy.nf], rho, interforce);
          fSiteSoluteCollisionBGK(&lbf[il*lbsitelength + lbsy.nf], sitespeed);
          fSiteThermalCollisionBGK(&lbf[il*lbsitelength + (lbsy.nf+lbsy.nc)], sitespeed);
        }
      }
    }
  }
  return 0;
}

int fCollisionTRTEDM()
{
  long Tmax = lbdm.touter;
  double freq = (lbbdforcetyp==1)*sin(lboscilfreq*(lbcurstep-lbequstep));
    
  if(!incompress) {
        
    #pragma omp parallel
    {
      double interforce_t[3*lbsy.nf], sitespeed_t[3], rho_t[lbsy.nf];
      double *interforce = &interforce_t[0];
      double *sitespeed = &sitespeed_t[0];
      double *rho = &rho_t[0];
        
      #pragma omp for
      for(long il=0; il<Tmax; il++) {
        if(lbphi[il] != 11) {
          fGetSpeedAllMassSite(sitespeed, rho, &lbf[il*lbsitelength]);
          for(int ll=0; ll<3*lbsy.nf; ll++)
	        interforce[ll] = lbinterforce[il*3*lbsy.nf+ll] + lbheatforce[il*3*lbsy.nf+ll] + postequil*(lbbdforce[ll]+lboscilforce[ll]*freq);
          if(lbphi[il] != 12 && lbphi[il] != 13)
            fSiteFluidCollisionTRTEDM(&lbf[il*lbsitelength], sitespeed, &lbomega[il*lbsy.nf], rho, interforce);
          fSiteSoluteCollisionBGK(&lbf[il*lbsitelength + lbsy.nf], sitespeed);
          fSiteThermalCollisionBGK(&lbf[il*lbsitelength + (lbsy.nf+lbsy.nc)], sitespeed);
        }
      }
    }
  }
  else {
        
    #pragma omp parallel
    {
      double interforce_t[3*lbsy.nf], sitespeed_t[3], rho_t[lbsy.nf];
      double *interforce = &interforce_t[0];
      double *sitespeed = &sitespeed_t[0];
      double *rho = &rho_t[0];
        
      #pragma omp for
      for(long il=0; il<Tmax; il++) {
        if(lbphi[il] != 11) {
          fGetSpeedIncomAllMassSite(sitespeed, rho, &lbf[il*lbsitelength]);
          for(int ll=0; ll<3*lbsy.nf; ll++)
	        interforce[ll] = lbinterforce[il*3*lbsy.nf+ll] + lbheatforce[il*3*lbsy.nf+ll] + postequil*(lbbdforce[ll]+lboscilforce[ll]*freq);
          if(lbphi[il] != 12 && lbphi[il] != 13)
            fSiteFluidIncomCollisionTRTEDM(&lbf[il*lbsitelength], sitespeed, &lbomega[il*lbsy.nf], rho, interforce);
          fSiteSoluteCollisionBGK(&lbf[il*lbsitelength + lbsy.nf], sitespeed);
          fSiteThermalCollisionBGK(&lbf[il*lbsitelength + (lbsy.nf+lbsy.nc)], sitespeed);
        }
      }
    }
  }
  return 0;
}

int fCollisionTRTGuo()
{
  long Tmax = lbdm.touter;
  double freq = (lbbdforcetyp==1)*sin(lboscilfreq*(lbcurstep-lbequstep));

  if(!incompress) {
        
    #pragma omp parallel
    {
      double interforce_t[3*lbsy.nf], sitespeed_t[3], rho_t[lbsy.nf];
      double *interforce = &interforce_t[0];
      double *sitespeed = &sitespeed_t[0];
      double *rho = &rho_t[0];
        
      #pragma omp for
      for(long il=0; il<Tmax; il++) {
        if(lbphi[il] != 11) {
          fGetSpeedAllMassSite(sitespeed, rho, &lbf[il*lbsitelength]);
          for(int ll=0; ll<3*lbsy.nf; ll++)
	        interforce[ll] = lbinterforce[il*3*lbsy.nf+ll] + lbheatforce[il*3*lbsy.nf+ll] + postequil*(lbbdforce[ll]+lboscilforce[ll]*freq);
          if(lbphi[il] != 12 && lbphi[il] != 13)
            fSiteFluidCollisionTRTGuo(&lbf[il*lbsitelength], sitespeed, &lbomega[il*lbsy.nf], rho, interforce);
          fSiteSoluteCollisionBGK(&lbf[il*lbsitelength + lbsy.nf], sitespeed);
          fSiteThermalCollisionBGK(&lbf[il*lbsitelength + (lbsy.nf+lbsy.nc)], sitespeed);
        }
      }
    }
  }
  else {
        
    #pragma omp parallel
    {
      double interforce_t[3*lbsy.nf], sitespeed_t[3], rho_t[lbsy.nf];
      double *interforce = &interforce_t[0];
      double *sitespeed = &sitespeed_t[0];
      double *rho = &rho_t[0];
        
      #pragma omp for
      for(long il=0; il<Tmax; il++) {
        if(lbphi[il] != 11) {
          fGetSpeedIncomAllMassSite(sitespeed, rho, &lbf[il*lbsitelength]);
          for(int ll=0; ll<3*lbsy.nf; ll++)
	        interforce[ll] = lbinterforce[il*3*lbsy.nf+ll] + lbheatforce[il*3*lbsy.nf+ll] + postequil*(lbbdforce[ll]+lboscilforce[ll]*freq);
          if(lbphi[il] != 12 && lbphi[il] != 13)
            fSiteFluidIncomCollisionTRTGuo(&lbf[il*lbsitelength], sitespeed, &lbomega[il*lbsy.nf], rho, interforce);
          fSiteSoluteCollisionBGK(&lbf[il*lbsitelength + lbsy.nf], sitespeed);
          fSiteThermalCollisionBGK(&lbf[il*lbsitelength + (lbsy.nf+lbsy.nc)], sitespeed);
        }
      }
    }
  }
  return 0;
}

int fCollisionTRTHe()
{
  long Tmax = lbdm.touter;
  double freq = (lbbdforcetyp==1)*sin(lboscilfreq*(lbcurstep-lbequstep));

  if(!incompress) {
      
    #pragma omp parallel
    {
      double interforce_t[3*lbsy.nf], sitespeed_t[3], rho_t[lbsy.nf];
      double *interforce = &interforce_t[0];
      double *sitespeed = &sitespeed_t[0];
      double *rho = &rho_t[0];
        
      #pragma omp for
      for(long il=0; il<Tmax; il++) {
        if(lbphi[il] != 11) {
          fGetSpeedAllMassSite(sitespeed, rho, &lbf[il*lbsitelength]);
          for(int ll=0; ll<3*lbsy.nf; ll++)
	        interforce[ll] = lbinterforce[il*3*lbsy.nf+ll] + lbheatforce[il*3*lbsy.nf+ll] + postequil*(lbbdforce[ll]+lboscilforce[ll]*freq);
          if(lbphi[il] != 12 && lbphi[il] != 13)
            fSiteFluidCollisionTRTHe(&lbf[il*lbsitelength], sitespeed, &lbomega[il*lbsy.nf], rho, interforce);
          fSiteSoluteCollisionBGK(&lbf[il*lbsitelength + lbsy.nf], sitespeed);
          fSiteThermalCollisionBGK(&lbf[il*lbsitelength + (lbsy.nf+lbsy.nc)], sitespeed);
        }
      }
    }
  }
  else {
      
    #pragma omp parallel
    {
      double interforce_t[3*lbsy.nf], sitespeed_t[3], rho_t[lbsy.nf];
      double *interforce = &interforce_t[0];
      double *sitespeed = &sitespeed_t[0];
      double *rho = &rho_t[0];
        
      #pragma omp for
      for(long il=0; il<Tmax; il++) {
        if(lbphi[il] != 11) {
          fGetSpeedIncomAllMassSite(sitespeed, rho, &lbf[il*lbsitelength]);
          for(int ll=0; ll<3*lbsy.nf; ll++)
	        interforce[ll] = lbinterforce[il*3*lbsy.nf+ll] + lbheatforce[il*3*lbsy.nf+ll] + postequil*(lbbdforce[ll]+lboscilforce[ll]*freq);
          if(lbphi[il] != 12 && lbphi[il] != 13)
            fSiteFluidIncomCollisionTRTHe(&lbf[il*lbsitelength], sitespeed, &lbomega[il*lbsy.nf], rho, interforce);
          fSiteSoluteCollisionBGK(&lbf[il*lbsitelength + lbsy.nf], sitespeed);
          fSiteThermalCollisionBGK(&lbf[il*lbsitelength + (lbsy.nf+lbsy.nc)], sitespeed);
        }
      }
    }
  }
  return 0;
}

int fCollisionTRTShanChen()
{
  long Tmax = lbdm.touter;
  double freq = (lbbdforcetyp==1)*sin(lboscilfreq*(lbcurstep-lbequstep));

  if(!incompress) {

   #pragma omp parallel
   {
      double interforce_t[3*lbsy.nf], sitespeed_t[3], rho_t[lbsy.nf];
      double *interforce = &interforce_t[0];
      double *sitespeed = &sitespeed_t[0];
      double *rho = &rho_t[0];

      #pragma omp for
      for(long il=0; il<Tmax; il++) {
        if(lbphi[il] != 11) {
          fGetSpeedShanChenAllMassSite(sitespeed, rho, &lbf[il*lbsitelength], &lbomega[il*lbsy.nf]);
          for(int ll=0; ll<3*lbsy.nf; ll++)
	        interforce[ll] = lbinterforce[il*3*lbsy.nf+ll] + lbheatforce[il*3*lbsy.nf+ll] + postequil*(lbbdforce[ll]+lboscilforce[ll]*freq);
          if(lbphi[il] != 12 && lbphi[il] != 13)
            fSiteFluidCollisionTRT(&lbf[il*lbsitelength], sitespeed, &lbomega[il*lbsy.nf], rho, interforce);
          fSiteSoluteCollisionBGK(&lbf[il*lbsitelength + lbsy.nf], sitespeed);
          fSiteThermalCollisionBGK(&lbf[il*lbsitelength + (lbsy.nf+lbsy.nc)], sitespeed);
        }
      }
    }
  }
  else {
      
   #pragma omp parallel
   {
      double interforce_t[3*lbsy.nf], sitespeed_t[3], rho_t[lbsy.nf];
      double *interforce = &interforce_t[0];
      double *sitespeed = &sitespeed_t[0];
      double *rho = &rho_t[0];

      #pragma omp for
      for(long il=0; il<lbdm.touter; il++) {
        if(lbphi[il] != 11) {
          fGetSpeedShanChenIncomAllMassSite(sitespeed, rho, &lbf[il*lbsitelength], &lbomega[il*lbsy.nf]);
          for(int ll=0; ll<3*lbsy.nf; ll++)
	        interforce[ll] = lbinterforce[il*3*lbsy.nf+ll] + lbheatforce[il*3*lbsy.nf+ll] + postequil*(lbbdforce[ll]+lboscilforce[ll]*freq);
          if(lbphi[il] != 12 && lbphi[il] != 13)
            fSiteFluidIncomCollisionTRT(&lbf[il*lbsitelength], sitespeed, &lbomega[il*lbsy.nf], rho, interforce);
          fSiteSoluteCollisionBGK(&lbf[il*lbsitelength + lbsy.nf], sitespeed);
          fSiteThermalCollisionBGK(&lbf[il*lbsitelength + (lbsy.nf+lbsy.nc)], sitespeed);
        }
      }
    }
  }
  return 0;
}

int fCollisionTRTEDMShanChen()
{
  long Tmax = lbdm.touter;
  double freq = (lbbdforcetyp==1)*sin(lboscilfreq*(lbcurstep-lbequstep));
    
  if(!incompress) {
        
    #pragma omp parallel
    {
      double interforce_t[3*lbsy.nf], sitespeed_t[3], rho_t[lbsy.nf];
      double *interforce = &interforce_t[0];
      double *sitespeed = &sitespeed_t[0];
      double *rho = &rho_t[0];
        
      #pragma omp for
      for(long il=0; il<Tmax; il++) {
        if(lbphi[il] != 11) {
          fGetSpeedShanChenAllMassSite(sitespeed, rho, &lbf[il*lbsitelength], &lbomega[il*lbsy.nf]);
          for(int ll=0; ll<3*lbsy.nf; ll++)
	        interforce[ll] = lbinterforce[il*3*lbsy.nf+ll] + lbheatforce[il*3*lbsy.nf+ll] + postequil*(lbbdforce[ll]+lboscilforce[ll]*freq);
          if(lbphi[il] != 12 && lbphi[il] != 13)
            fSiteFluidCollisionTRTEDM(&lbf[il*lbsitelength], sitespeed, &lbomega[il*lbsy.nf], rho, interforce);
          fSiteSoluteCollisionBGK(&lbf[il*lbsitelength + lbsy.nf], sitespeed);
          fSiteThermalCollisionBGK(&lbf[il*lbsitelength + (lbsy.nf+lbsy.nc)], sitespeed);
        }
      }
    }
  }
  else {
        
    #pragma omp parallel
    {
      double interforce_t[3*lbsy.nf], sitespeed_t[3], rho_t[lbsy.nf];
      double *interforce = &interforce_t[0];
      double *sitespeed = &sitespeed_t[0];
      double *rho = &rho_t[0];
        
      #pragma omp for
      for(long il=0; il<Tmax; il++) {
        if(lbphi[il] != 11) {
          fGetSpeedShanChenIncomAllMassSite(sitespeed, rho, &lbf[il*lbsitelength], &lbomega[il*lbsy.nf]);
          for(int ll=0; ll<3*lbsy.nf; ll++)
	        interforce[ll] = lbinterforce[il*3*lbsy.nf+ll] + lbheatforce[il*3*lbsy.nf+ll] + postequil*(lbbdforce[ll]+lboscilforce[ll]*freq);
          if(lbphi[il] != 12 && lbphi[il] != 13)
            fSiteFluidIncomCollisionTRTEDM(&lbf[il*lbsitelength], sitespeed, &lbomega[il*lbsy.nf], rho, interforce);
          fSiteSoluteCollisionBGK(&lbf[il*lbsitelength + lbsy.nf], sitespeed);
          fSiteThermalCollisionBGK(&lbf[il*lbsitelength + (lbsy.nf+lbsy.nc)], sitespeed);
        }
      }
    }
  }
  return 0;
}

int fCollisionTRTGuoShanChen()
{
  long Tmax = lbdm.touter;
  double freq = (lbbdforcetyp==1)*sin(lboscilfreq*(lbcurstep-lbequstep));

  if(!incompress) {
        
    #pragma omp parallel
    {
      double interforce_t[3*lbsy.nf], sitespeed_t[3], rho_t[lbsy.nf];
      double *interforce = &interforce_t[0];
      double *sitespeed = &sitespeed_t[0];
      double *rho = &rho_t[0];
        
      #pragma omp for
      for(long il=0; il<Tmax; il++) {
        if(lbphi[il] != 11) {
          fGetSpeedShanChenAllMassSite(sitespeed, rho, &lbf[il*lbsitelength], &lbomega[il*lbsy.nf]);
          for(int ll=0; ll<3*lbsy.nf; ll++)
	        interforce[ll] = lbinterforce[il*3*lbsy.nf+ll] + lbheatforce[il*3*lbsy.nf+ll] + postequil*(lbbdforce[ll]+lboscilforce[ll]*freq);
          if(lbphi[il] != 12 && lbphi[il] != 13)
            fSiteFluidCollisionTRTGuo(&lbf[il*lbsitelength], sitespeed, &lbomega[il*lbsy.nf], rho, interforce);
          fSiteSoluteCollisionBGK(&lbf[il*lbsitelength + lbsy.nf], sitespeed);
          fSiteThermalCollisionBGK(&lbf[il*lbsitelength + (lbsy.nf+lbsy.nc)], sitespeed);
        }
      }
    }
  }
  else {
        
    #pragma omp parallel
    {
      double interforce_t[3*lbsy.nf], sitespeed_t[3], rho_t[lbsy.nf];
      double *interforce = &interforce_t[0];
      double *sitespeed = &sitespeed_t[0];
      double *rho = &rho_t[0];
        
      #pragma omp for
      for(long il=0; il<Tmax; il++) {
        if(lbphi[il] != 11) {
          fGetSpeedShanChenIncomAllMassSite(sitespeed, rho, &lbf[il*lbsitelength], &lbomega[il*lbsy.nf]);
          for(int ll=0; ll<3*lbsy.nf; ll++)
	        interforce[ll] = lbinterforce[il*3*lbsy.nf+ll] + lbheatforce[il*3*lbsy.nf+ll] + postequil*(lbbdforce[ll]+lboscilforce[ll]*freq);
          if(lbphi[il] != 12 && lbphi[il] != 13)
            fSiteFluidIncomCollisionTRTGuo(&lbf[il*lbsitelength], sitespeed, &lbomega[il*lbsy.nf], rho, interforce);
          fSiteSoluteCollisionBGK(&lbf[il*lbsitelength + lbsy.nf], sitespeed);
          fSiteThermalCollisionBGK(&lbf[il*lbsitelength + (lbsy.nf+lbsy.nc)], sitespeed);
        }
      }
    }
  }
  return 0;
}

int fCollisionTRTHeShanChen()
{
  long Tmax = lbdm.touter;
  double freq = (lbbdforcetyp==1)*sin(lboscilfreq*(lbcurstep-lbequstep));

  if(!incompress) {
      
    #pragma omp parallel
    {
      double interforce_t[3*lbsy.nf], sitespeed_t[3], rho_t[lbsy.nf];
      double *interforce = &interforce_t[0];
      double *sitespeed = &sitespeed_t[0];
      double *rho = &rho_t[0];
        
      #pragma omp for
      for(long il=0; il<Tmax; il++) {
        if(lbphi[il] != 11) {
          fGetSpeedShanChenAllMassSite(sitespeed, rho, &lbf[il*lbsitelength], &lbomega[il*lbsy.nf]);
          for(int ll=0; ll<3*lbsy.nf; ll++)
	        interforce[ll] = lbinterforce[il*3*lbsy.nf+ll] + lbheatforce[il*3*lbsy.nf+ll] + postequil*(lbbdforce[ll]+lboscilforce[ll]*freq);
          if(lbphi[il] != 12 && lbphi[il] != 13)
            fSiteFluidCollisionTRTHe(&lbf[il*lbsitelength], sitespeed, &lbomega[il*lbsy.nf], rho, interforce);
          fSiteSoluteCollisionBGK(&lbf[il*lbsitelength + lbsy.nf], sitespeed);
          fSiteThermalCollisionBGK(&lbf[il*lbsitelength + (lbsy.nf+lbsy.nc)], sitespeed);
        }
      }
    }
  }
  else {
      
    #pragma omp parallel
    {
      double interforce_t[3*lbsy.nf], sitespeed_t[3], rho_t[lbsy.nf];
      double *interforce = &interforce_t[0];
      double *sitespeed = &sitespeed_t[0];
      double *rho = &rho_t[0];
        
      #pragma omp for
      for(long il=0; il<Tmax; il++) {
        if(lbphi[il] != 11) {
          fGetSpeedShanChenIncomAllMassSite(sitespeed, rho, &lbf[il*lbsitelength], &lbomega[il*lbsy.nf]);
          for(int ll=0; ll<3*lbsy.nf; ll++)
	        interforce[ll] = lbinterforce[il*3*lbsy.nf+ll] + lbheatforce[il*3*lbsy.nf+ll] + postequil*(lbbdforce[ll]+lboscilforce[ll]*freq);
          if(lbphi[il] != 12 && lbphi[il] != 13)
            fSiteFluidIncomCollisionTRTHe(&lbf[il*lbsitelength], sitespeed, &lbomega[il*lbsy.nf], rho, interforce);
          fSiteSoluteCollisionBGK(&lbf[il*lbsitelength + lbsy.nf], sitespeed);
          fSiteThermalCollisionBGK(&lbf[il*lbsitelength + (lbsy.nf+lbsy.nc)], sitespeed);
        }
      }
    }
  }
  return 0;
}

int fCollisionTRTLishchuk()
{
  int numpair = 3 * lbsy.nf * (lbsy.nf-1) / 2;
  long Tmax = lbdm.touter;
  double freq = (lbbdforcetyp==1)*sin(lboscilfreq*(lbcurstep-lbequstep));

  if(!incompress) {
      
    #pragma omp parallel
    {
      double interforce_t[3*lbsy.nf], sitespeed_t[3], rho_t[lbsy.nf];
      double *interforce = &interforce_t[0];
      double *sitespeed = &sitespeed_t[0];
      double *rho = &rho_t[0];

      #pragma omp for
      for(long il=0; il<Tmax; il++) {
        if(lbphi[il] != 11) {
          fGetSpeedAllMassSite(sitespeed, rho, &lbf[il*lbsitelength]);
          double invallmass = 0.0;
          for(int ll=0; ll<lbsy.nf; ll++)
            invallmass += rho[ll];
          invallmass = fReciprocal(invallmass);
          interforce[0] = lbinterforce[3*il  ]; interforce[1] = lbinterforce[3*il+1]; interforce[2] = lbinterforce[3*il+2];
          for(int ll=0; ll<lbsy.nf; ll++) {
            double frac = rho[ll] * invallmass;
	        interforce[0] += frac*(lbheatforce[il*3*lbsy.nf+3*ll  ]+postequil*(lbbdforce[3*ll  ]+lboscilforce[3*ll  ]*freq));
            interforce[1] += frac*(lbheatforce[il*3*lbsy.nf+3*ll+1]+postequil*(lbbdforce[3*ll+1]+lboscilforce[3*ll+1]*freq));
	        interforce[2] += frac*(lbheatforce[il*3*lbsy.nf+3*ll+2]+postequil*(lbbdforce[3*ll+2]+lboscilforce[3*ll+2]*freq));
          }
          if(lbphi[il] != 12 && lbphi[il] != 13)
            fSiteFluidCollisionTRTLishchuk(&lbf[il*lbsitelength], sitespeed, &lbomega[il*lbsy.nf], rho, interforce, &lbft[il*numpair]);
          fSiteSoluteCollisionBGK(&lbf[il*lbsitelength + lbsy.nf], sitespeed);
          fSiteThermalCollisionBGK(&lbf[il*lbsitelength + (lbsy.nf+lbsy.nc)], sitespeed);
        }
      }
    }
  }
  else {
      
    #pragma omp parallel
    {
      double interforce_t[3*lbsy.nf], sitespeed_t[3], rho_t[lbsy.nf];
      double *interforce = &interforce_t[0];
      double *sitespeed = &sitespeed_t[0];
      double *rho = &rho_t[0];

      #pragma omp for
      for(long il=0; il<Tmax; il++) {
        if(lbphi[il] != 11) {
          fGetSpeedIncomAllMassSite(sitespeed, rho, &lbf[il*lbsitelength]);
          double invallmass = 0.0;
          for(int ll=0; ll<lbsy.nf; ll++)
            invallmass += rho[ll];
          invallmass = fReciprocal(invallmass);
          interforce[0] = lbinterforce[3*il  ]; interforce[1] = lbinterforce[3*il+1]; interforce[2] = lbinterforce[3*il+2];
          for(int ll=0; ll<lbsy.nf; ll++) {
            double frac = rho[ll] * invallmass;
	        interforce[0] += frac*(lbheatforce[il*3*lbsy.nf+3*ll  ]+postequil*(lbbdforce[3*ll  ]+lboscilforce[3*ll  ]*freq));
            interforce[1] += frac*(lbheatforce[il*3*lbsy.nf+3*ll+1]+postequil*(lbbdforce[3*ll+1]+lboscilforce[3*ll+1]*freq));
	        interforce[2] += frac*(lbheatforce[il*3*lbsy.nf+3*ll+2]+postequil*(lbbdforce[3*ll+2]+lboscilforce[3*ll+2]*freq));
          }
          if(lbphi[il] != 12 && lbphi[il] != 13)
            fSiteFluidIncomCollisionTRTLishchuk(&lbf[il*lbsitelength], sitespeed, &lbomega[il*lbsy.nf], rho, interforce, &lbft[il*numpair]);
          fSiteSoluteCollisionBGK(&lbf[il*lbsitelength + lbsy.nf], sitespeed);
          fSiteThermalCollisionBGK(&lbf[il*lbsitelength + (lbsy.nf+lbsy.nc)], sitespeed);
        }
      }
    }
  }
  return 0;
}

int fCollisionTRTEDMLishchuk()
{
  int numpair = 3 * lbsy.nf * (lbsy.nf-1) / 2;
  long Tmax = lbdm.touter;
  double freq = (lbbdforcetyp==1)*sin(lboscilfreq*(lbcurstep-lbequstep));

  if(!incompress) {

    #pragma omp parallel
    {
      double interforce_t[3*lbsy.nf], sitespeed_t[3], rho_t[lbsy.nf];
      double *interforce = &interforce_t[0];
      double *sitespeed = &sitespeed_t[0];
      double *rho = &rho_t[0];

      #pragma omp for
      for(long il=0; il<Tmax; il++) {
        if(lbphi[il] != 11) {
          fGetSpeedAllMassSite(sitespeed, rho, &lbf[il*lbsitelength]);
          double invallmass = 0.0;
          for(int ll=0; ll<lbsy.nf; ll++)
            invallmass += rho[ll];
          invallmass = fReciprocal(invallmass);
          interforce[0] = lbinterforce[3*il  ]; interforce[1] = lbinterforce[3*il+1]; interforce[2] = lbinterforce[3*il+2];
          for(int ll=0; ll<lbsy.nf; ll++) {
            double frac = rho[ll] * invallmass;
	        interforce[0] += frac*(lbheatforce[il*3*lbsy.nf+3*ll  ]+postequil*(lbbdforce[3*ll  ]+lboscilforce[3*ll  ]*freq));
            interforce[1] += frac*(lbheatforce[il*3*lbsy.nf+3*ll+1]+postequil*(lbbdforce[3*ll+1]+lboscilforce[3*ll+1]*freq));
	        interforce[2] += frac*(lbheatforce[il*3*lbsy.nf+3*ll+2]+postequil*(lbbdforce[3*ll+2]+lboscilforce[3*ll+2]*freq));
          }
          if(lbphi[il] != 12 && lbphi[il] != 13)
            fSiteFluidCollisionTRTEDMLishchuk(&lbf[il*lbsitelength], sitespeed, &lbomega[il*lbsy.nf], rho, interforce, &lbft[il*numpair]);
          fSiteSoluteCollisionBGK(&lbf[il*lbsitelength + lbsy.nf], sitespeed);
          fSiteThermalCollisionBGK(&lbf[il*lbsitelength + (lbsy.nf+lbsy.nc)], sitespeed);
        }
      }
    }
  }
  else {

    #pragma omp parallel
    {
      double interforce_t[3*lbsy.nf], sitespeed_t[3], rho_t[lbsy.nf];
      double *interforce = &interforce_t[0];
      double *sitespeed = &sitespeed_t[0];
      double *rho = &rho_t[0];

      #pragma omp for
      for(long il=0; il<Tmax; il++) {
        if(lbphi[il] != 11) {
          fGetSpeedIncomAllMassSite(sitespeed, rho, &lbf[il*lbsitelength]);
          double invallmass = 0.0;
          for(int ll=0; ll<lbsy.nf; ll++)
            invallmass += rho[ll];
          invallmass = fReciprocal(invallmass);
          interforce[0] = lbinterforce[3*il  ]; interforce[1] = lbinterforce[3*il+1]; interforce[2] = lbinterforce[3*il+2];
          for(int ll=0; ll<lbsy.nf; ll++) {
            double frac = rho[ll] * invallmass;
	        interforce[0] += frac*(lbheatforce[il*3*lbsy.nf+3*ll  ]+postequil*(lbbdforce[3*ll  ]+lboscilforce[3*ll  ]*freq));
            interforce[1] += frac*(lbheatforce[il*3*lbsy.nf+3*ll+1]+postequil*(lbbdforce[3*ll+1]+lboscilforce[3*ll+1]*freq));
	        interforce[2] += frac*(lbheatforce[il*3*lbsy.nf+3*ll+2]+postequil*(lbbdforce[3*ll+2]+lboscilforce[3*ll+2]*freq));
          }
          if(lbphi[il] != 12 && lbphi[il] != 13)
            fSiteFluidIncomCollisionTRTEDMLishchuk(&lbf[il*lbsitelength], sitespeed, &lbomega[il*lbsy.nf], rho, interforce, &lbft[il*numpair]);
          fSiteSoluteCollisionBGK(&lbf[il*lbsitelength + lbsy.nf], sitespeed);
          fSiteThermalCollisionBGK(&lbf[il*lbsitelength + (lbsy.nf+lbsy.nc)], sitespeed);
        }
      }
    }
  }
  return 0;
}

int fCollisionTRTGuoLishchuk()
{
  int numpair = 3 * lbsy.nf * (lbsy.nf-1) / 2;
  long Tmax = lbdm.touter;
  double freq = (lbbdforcetyp==1)*sin(lboscilfreq*(lbcurstep-lbequstep));

  if(!incompress) {

    #pragma omp parallel
    {
      double interforce_t[3*lbsy.nf], sitespeed_t[3], rho_t[lbsy.nf];
      double *interforce = &interforce_t[0];
      double *sitespeed = &sitespeed_t[0];
      double *rho = &rho_t[0];

      #pragma omp for
      for(long il=0; il<Tmax; il++) {
        if(lbphi[il] != 11) {
          fGetSpeedAllMassSite(sitespeed, rho, &lbf[il*lbsitelength]);
          double invallmass = 0.0;
          for(int ll=0; ll<lbsy.nf; ll++)
            invallmass += rho[ll];
          invallmass = fReciprocal(invallmass);
          interforce[0] = lbinterforce[3*il  ]; interforce[1] = lbinterforce[3*il+1]; interforce[2] = lbinterforce[3*il+2];
          for(int ll=0; ll<lbsy.nf; ll++) {
            double frac = rho[ll] * invallmass;
	        interforce[0] += frac*(lbheatforce[il*3*lbsy.nf+3*ll  ]+postequil*(lbbdforce[3*ll  ]+lboscilforce[3*ll  ]*freq));
            interforce[1] += frac*(lbheatforce[il*3*lbsy.nf+3*ll+1]+postequil*(lbbdforce[3*ll+1]+lboscilforce[3*ll+1]*freq));
	        interforce[2] += frac*(lbheatforce[il*3*lbsy.nf+3*ll+2]+postequil*(lbbdforce[3*ll+2]+lboscilforce[3*ll+2]*freq));
          }
          if(lbphi[il] != 12 && lbphi[il] != 13)
            fSiteFluidCollisionTRTGuoLishchuk(&lbf[il*lbsitelength], sitespeed, &lbomega[il*lbsy.nf], rho, interforce, &lbft[il*numpair]);
          fSiteSoluteCollisionBGK(&lbf[il*lbsitelength + lbsy.nf], sitespeed);
          fSiteThermalCollisionBGK(&lbf[il*lbsitelength + (lbsy.nf+lbsy.nc)], sitespeed);
        }
      }
    }
  }
  else {

    #pragma omp parallel
    {
      double interforce_t[3*lbsy.nf], sitespeed_t[3], rho_t[lbsy.nf];
      double *interforce = &interforce_t[0];
      double *sitespeed = &sitespeed_t[0];
      double *rho = &rho_t[0];

      #pragma omp for
      for(long il=0; il<Tmax; il++) {
        if(lbphi[il] != 11) {
          fGetSpeedIncomAllMassSite(sitespeed, rho, &lbf[il*lbsitelength]);
          double invallmass = 0.0;
          for(int ll=0; ll<lbsy.nf; ll++)
            invallmass += rho[ll];
          invallmass = fReciprocal(invallmass);
          interforce[0] = lbinterforce[3*il  ]; interforce[1] = lbinterforce[3*il+1]; interforce[2] = lbinterforce[3*il+2];
          for(int ll=0; ll<lbsy.nf; ll++) {
            double frac = rho[ll] * invallmass;
	        interforce[0] += frac*(lbheatforce[il*3*lbsy.nf+3*ll  ]+postequil*(lbbdforce[3*ll  ]+lboscilforce[3*ll  ]*freq));
            interforce[1] += frac*(lbheatforce[il*3*lbsy.nf+3*ll+1]+postequil*(lbbdforce[3*ll+1]+lboscilforce[3*ll+1]*freq));
	        interforce[2] += frac*(lbheatforce[il*3*lbsy.nf+3*ll+2]+postequil*(lbbdforce[3*ll+2]+lboscilforce[3*ll+2]*freq));
          }
          if(lbphi[il] != 12 && lbphi[il] != 13)
           fSiteFluidIncomCollisionTRTGuoLishchuk(&lbf[il*lbsitelength], sitespeed, &lbomega[il*lbsy.nf], rho, interforce, &lbft[il*numpair]);
          fSiteSoluteCollisionBGK(&lbf[il*lbsitelength + lbsy.nf], sitespeed);
          fSiteThermalCollisionBGK(&lbf[il*lbsitelength + (lbsy.nf+lbsy.nc)], sitespeed);
        }
      }
    }
  }
  return 0;
}


int fCollisionTRTHeLishchuk()
{
  int numpair = 3 * lbsy.nf * (lbsy.nf-1) / 2;
  long Tmax = lbdm.touter;
  double freq = (lbbdforcetyp==1)*sin(lboscilfreq*(lbcurstep-lbequstep));

  if(!incompress) {

    #pragma omp parallel
    {
      double interforce_t[3*lbsy.nf], sitespeed_t[3], rho_t[lbsy.nf];
      double *interforce = &interforce_t[0];
      double *sitespeed = &sitespeed_t[0];
      double *rho = &rho_t[0];

      #pragma omp for
      for(long il=0; il<Tmax; il++) {
        if(lbphi[il] != 11) {
          fGetSpeedAllMassSite(sitespeed, rho, &lbf[il*lbsitelength]);
          double invallmass = 0.0;
          for(int ll=0; ll<lbsy.nf; ll++)
            invallmass += rho[ll];
          invallmass = fReciprocal(invallmass);
          interforce[0] = lbinterforce[3*il  ]; interforce[1] = lbinterforce[3*il+1]; interforce[2] = lbinterforce[3*il+2];
          for(int ll=0; ll<lbsy.nf; ll++) {
            double frac = rho[ll] * invallmass;
	        interforce[0] += frac*(lbheatforce[il*3*lbsy.nf+3*ll  ]+postequil*(lbbdforce[3*ll  ]+lboscilforce[3*ll  ]*freq));
            interforce[1] += frac*(lbheatforce[il*3*lbsy.nf+3*ll+1]+postequil*(lbbdforce[3*ll+1]+lboscilforce[3*ll+1]*freq));
	        interforce[2] += frac*(lbheatforce[il*3*lbsy.nf+3*ll+2]+postequil*(lbbdforce[3*ll+2]+lboscilforce[3*ll+2]*freq));
          }
          if(lbphi[il] != 12 && lbphi[il] != 13)
            fSiteFluidCollisionTRTHeLishchuk(&lbf[il*lbsitelength], sitespeed, &lbomega[il*lbsy.nf], rho, interforce, &lbft[il*numpair]);
          fSiteSoluteCollisionBGK(&lbf[il*lbsitelength + lbsy.nf], sitespeed);
          fSiteThermalCollisionBGK(&lbf[il*lbsitelength + (lbsy.nf+lbsy.nc)], sitespeed);
        }
      }
    }
  }
  else {

    #pragma omp parallel
    {
      double interforce_t[3*lbsy.nf], sitespeed_t[3], rho_t[lbsy.nf];
      double *interforce = &interforce_t[0];
      double *sitespeed = &sitespeed_t[0];
      double *rho = &rho_t[0];

      #pragma omp for
      for(long il=0; il<Tmax; il++) {
        if(lbphi[il] != 11) {
          fGetSpeedIncomAllMassSite(sitespeed, rho, &lbf[il*lbsitelength]);
          double invallmass = 0.0;
          for(int ll=0; ll<lbsy.nf; ll++)
            invallmass += rho[ll];
          invallmass = fReciprocal(invallmass);
          interforce[0] = lbinterforce[3*il  ]; interforce[1] = lbinterforce[3*il+1]; interforce[2] = lbinterforce[3*il+2];
          for(int ll=0; ll<lbsy.nf; ll++) {
            double frac = rho[ll] * invallmass;
	        interforce[0] += frac*(lbheatforce[il*3*lbsy.nf+3*ll  ]+postequil*(lbbdforce[3*ll  ]+lboscilforce[3*ll  ]*freq));
            interforce[1] += frac*(lbheatforce[il*3*lbsy.nf+3*ll+1]+postequil*(lbbdforce[3*ll+1]+lboscilforce[3*ll+1]*freq));
	        interforce[2] += frac*(lbheatforce[il*3*lbsy.nf+3*ll+2]+postequil*(lbbdforce[3*ll+2]+lboscilforce[3*ll+2]*freq));
          }
          if(lbphi[il] != 12 && lbphi[il] != 13)
           fSiteFluidIncomCollisionTRTHeLishchuk(&lbf[il*lbsitelength], sitespeed, &lbomega[il*lbsy.nf], rho, interforce, &lbft[il*numpair]);
          fSiteSoluteCollisionBGK(&lbf[il*lbsitelength + lbsy.nf], sitespeed);
          fSiteThermalCollisionBGK(&lbf[il*lbsitelength + (lbsy.nf+lbsy.nc)], sitespeed);
        }
      }
    }
  }
  return 0;
}


int fCollisionTRTLishchukLocal()
{
  int numpair = 3 * lbsy.nf * (lbsy.nf-1) / 2;
  int threed = (lbsy.nd>2);
  long Tmax = lbdm.touter;
  double freq = (lbbdforcetyp==1)*sin(lboscilfreq*(lbcurstep-lbequstep));

  if(!incompress) {
      
    #pragma omp parallel
    {
      double interforce_t[3*lbsy.nf], sitespeed_t[3], rho_t[lbsy.nf];
      double *interforce = &interforce_t[0];
      double *sitespeed = &sitespeed_t[0];
      double *rho = &rho_t[0];

      #pragma omp for
      for(long il=0; il<Tmax; il++) {
        if(lbphi[il] != 11) {
          fGetSpeedAllMassSite(sitespeed, rho, &lbf[il*lbsitelength]);
          double invallmass = 0.0;
          for(int ll=0; ll<lbsy.nf; ll++)
            invallmass += rho[ll];
          invallmass = fReciprocal(invallmass);
          interforce[0] = lbinterforce[3*il  ]; interforce[1] = lbinterforce[3*il+1]; interforce[2] = lbinterforce[3*il+2];
          for(int ll=0; ll<lbsy.nf; ll++) {
            double frac = rho[ll] * invallmass;
	        interforce[0] += frac*(lbheatforce[il*3*lbsy.nf+3*ll  ]+postequil*(lbbdforce[3*ll  ]+lboscilforce[3*ll  ]*freq));
            interforce[1] += frac*(lbheatforce[il*3*lbsy.nf+3*ll+1]+postequil*(lbbdforce[3*ll+1]+lboscilforce[3*ll+1]*freq));
	        interforce[2] += frac*(lbheatforce[il*3*lbsy.nf+3*ll+2]+postequil*(lbbdforce[3*ll+2]+lboscilforce[3*ll+2]*freq));
          }
          if(lbphi[il] != 12 && lbphi[il] != 13)
	        fSiteFluidCollisionTRTLishchukLocal(&lbf[il*lbsitelength], sitespeed, &lbomega[il*lbsy.nf], rho, interforce, &lbft[il*numpair], threed);
          fSiteSoluteCollisionBGK(&lbf[il*lbsitelength + lbsy.nf], sitespeed);
          fSiteThermalCollisionBGK(&lbf[il*lbsitelength + (lbsy.nf+lbsy.nc)], sitespeed);
        }
      }
    }
  }
  else {
      
    #pragma omp parallel
    {
      double interforce_t[3*lbsy.nf], sitespeed_t[3], rho_t[lbsy.nf];
      double *interforce = &interforce_t[0];
      double *sitespeed = &sitespeed_t[0];
      double *rho = &rho_t[0];

      #pragma omp for
      for(long il=0; il<Tmax; il++) {
        if(lbphi[il] != 11) {
          fGetSpeedIncomAllMassSite(sitespeed, rho, &lbf[il*lbsitelength]);
          double invallmass = 0.0;
          for(int ll=0; ll<lbsy.nf; ll++)
            invallmass += rho[ll];
          invallmass = fReciprocal(invallmass);
          interforce[0] = lbinterforce[3*il  ]; interforce[1] = lbinterforce[3*il+1]; interforce[2] = lbinterforce[3*il+2];
          for(int ll=0; ll<lbsy.nf; ll++) {
            double frac = rho[ll] * invallmass;
	        interforce[0] += frac*(lbheatforce[il*3*lbsy.nf+3*ll  ]+postequil*(lbbdforce[3*ll  ]+lboscilforce[3*ll  ]*freq));
            interforce[1] += frac*(lbheatforce[il*3*lbsy.nf+3*ll+1]+postequil*(lbbdforce[3*ll+1]+lboscilforce[3*ll+1]*freq));
	        interforce[2] += frac*(lbheatforce[il*3*lbsy.nf+3*ll+2]+postequil*(lbbdforce[3*ll+2]+lboscilforce[3*ll+2]*freq));
          }
          if(lbphi[il] != 12 && lbphi[il] != 13)
            fSiteFluidIncomCollisionTRTLishchukLocal(&lbf[il*lbsitelength], sitespeed, &lbomega[il*lbsy.nf], rho, interforce, &lbft[il*numpair], threed);
          fSiteSoluteCollisionBGK(&lbf[il*lbsitelength + lbsy.nf], sitespeed);
          fSiteThermalCollisionBGK(&lbf[il*lbsitelength + (lbsy.nf+lbsy.nc)], sitespeed);
        }
      }
    }
  }
  return 0;
}

int fCollisionTRTEDMLishchukLocal()
{
  int numpair = 3 * lbsy.nf * (lbsy.nf-1) / 2;
  int threed = (lbsy.nd>2);
  long Tmax = lbdm.touter;
  double freq = (lbbdforcetyp==1)*sin(lboscilfreq*(lbcurstep-lbequstep));

  if(!incompress) {

    #pragma omp parallel
    {
      double interforce_t[3*lbsy.nf], sitespeed_t[3], rho_t[lbsy.nf];
      double *interforce = &interforce_t[0];
      double *sitespeed = &sitespeed_t[0];
      double *rho = &rho_t[0];

      #pragma omp for
      for(long il=0; il<Tmax; il++) {
        if(lbphi[il] != 11) {
          fGetSpeedAllMassSite(sitespeed, rho, &lbf[il*lbsitelength]);
          double invallmass = 0.0;
          for(int ll=0; ll<lbsy.nf; ll++)
            invallmass += rho[ll];
          invallmass = fReciprocal(invallmass);
          interforce[0] = lbinterforce[3*il  ]; interforce[1] = lbinterforce[3*il+1]; interforce[2] = lbinterforce[3*il+2];
          for(int ll=0; ll<lbsy.nf; ll++) {
            double frac = rho[ll] * invallmass;
	        interforce[0] += frac*(lbheatforce[il*3*lbsy.nf+3*ll  ]+postequil*(lbbdforce[3*ll  ]+lboscilforce[3*ll  ]*freq));
            interforce[1] += frac*(lbheatforce[il*3*lbsy.nf+3*ll+1]+postequil*(lbbdforce[3*ll+1]+lboscilforce[3*ll+1]*freq));
	        interforce[2] += frac*(lbheatforce[il*3*lbsy.nf+3*ll+2]+postequil*(lbbdforce[3*ll+2]+lboscilforce[3*ll+2]*freq));
          }
          if(lbphi[il] != 12 && lbphi[il] != 13)
            fSiteFluidCollisionTRTEDMLishchukLocal(&lbf[il*lbsitelength], sitespeed, &lbomega[il*lbsy.nf], rho, interforce, &lbft[il*numpair], threed);
          fSiteSoluteCollisionBGK(&lbf[il*lbsitelength + lbsy.nf], sitespeed);
          fSiteThermalCollisionBGK(&lbf[il*lbsitelength + (lbsy.nf+lbsy.nc)], sitespeed);
        }
      }
    }
  }
  else {

    #pragma omp parallel
    {
      double interforce_t[3*lbsy.nf], sitespeed_t[3], rho_t[lbsy.nf];
      double *interforce = &interforce_t[0];
      double *sitespeed = &sitespeed_t[0];
      double *rho = &rho_t[0];

      #pragma omp for
      for(long il=0; il<Tmax; il++) {
        if(lbphi[il] != 11) {
          fGetSpeedIncomAllMassSite(sitespeed, rho, &lbf[il*lbsitelength]);
          double invallmass = 0.0;
          for(int ll=0; ll<lbsy.nf; ll++)
            invallmass += rho[ll];
          invallmass = fReciprocal(invallmass);
          interforce[0] = lbinterforce[3*il  ]; interforce[1] = lbinterforce[3*il+1]; interforce[2] = lbinterforce[3*il+2];
          for(int ll=0; ll<lbsy.nf; ll++) {
            double frac = rho[ll] * invallmass;
	        interforce[0] += frac*(lbheatforce[il*3*lbsy.nf+3*ll  ]+postequil*(lbbdforce[3*ll  ]+lboscilforce[3*ll  ]*freq));
            interforce[1] += frac*(lbheatforce[il*3*lbsy.nf+3*ll+1]+postequil*(lbbdforce[3*ll+1]+lboscilforce[3*ll+1]*freq));
	        interforce[2] += frac*(lbheatforce[il*3*lbsy.nf+3*ll+2]+postequil*(lbbdforce[3*ll+2]+lboscilforce[3*ll+2]*freq));
          }
          if(lbphi[il] != 12 && lbphi[il] != 13)
              fSiteFluidIncomCollisionTRTEDMLishchukLocal(&lbf[il*lbsitelength], sitespeed, &lbomega[il*lbsy.nf], rho, interforce, &lbft[il*numpair], threed);
          fSiteSoluteCollisionBGK(&lbf[il*lbsitelength + lbsy.nf], sitespeed);
          fSiteThermalCollisionBGK(&lbf[il*lbsitelength + (lbsy.nf+lbsy.nc)], sitespeed);
        }
      }
    }
  }
  return 0;
}

int fCollisionTRTGuoLishchukLocal()
{
  int numpair = 3 * lbsy.nf * (lbsy.nf-1) / 2;
  int threed = (lbsy.nd>2);
  long Tmax = lbdm.touter;
  double freq = (lbbdforcetyp==1)*sin(lboscilfreq*(lbcurstep-lbequstep));

  if(!incompress) {

    #pragma omp parallel
    {
      double interforce_t[3*lbsy.nf], sitespeed_t[3], rho_t[lbsy.nf];
      double *interforce = &interforce_t[0];
      double *sitespeed = &sitespeed_t[0];
      double *rho = &rho_t[0];

      #pragma omp for
      for(long il=0; il<Tmax; il++) {
        if(lbphi[il] != 11) {
          fGetSpeedAllMassSite(sitespeed, rho, &lbf[il*lbsitelength]);
          double invallmass = 0.0;
          for(int ll=0; ll<lbsy.nf; ll++)
            invallmass += rho[ll];
          invallmass = fReciprocal(invallmass);
          interforce[0] = lbinterforce[3*il  ]; interforce[1] = lbinterforce[3*il+1]; interforce[2] = lbinterforce[3*il+2];
          for(int ll=0; ll<lbsy.nf; ll++) {
            double frac = rho[ll] * invallmass;
	        interforce[0] += frac*(lbheatforce[il*3*lbsy.nf+3*ll  ]+postequil*(lbbdforce[3*ll  ]+lboscilforce[3*ll  ]*freq));
            interforce[1] += frac*(lbheatforce[il*3*lbsy.nf+3*ll+1]+postequil*(lbbdforce[3*ll+1]+lboscilforce[3*ll+1]*freq));
	        interforce[2] += frac*(lbheatforce[il*3*lbsy.nf+3*ll+2]+postequil*(lbbdforce[3*ll+2]+lboscilforce[3*ll+2]*freq));
          }
          if(lbphi[il] != 12 && lbphi[il] != 13)
            fSiteFluidCollisionTRTGuoLishchukLocal(&lbf[il*lbsitelength], sitespeed, &lbomega[il*lbsy.nf], rho, interforce, &lbft[il*numpair], threed);
          fSiteSoluteCollisionBGK(&lbf[il*lbsitelength + lbsy.nf], sitespeed);
          fSiteThermalCollisionBGK(&lbf[il*lbsitelength + (lbsy.nf+lbsy.nc)], sitespeed);
        }
      }
    }
  }
  else {

    #pragma omp parallel
    {
      double interforce_t[3*lbsy.nf], sitespeed_t[3], rho_t[lbsy.nf];
      double *interforce = &interforce_t[0];
      double *sitespeed = &sitespeed_t[0];
      double *rho = &rho_t[0];

      #pragma omp for
      for(long il=0; il<Tmax; il++) {
        if(lbphi[il] != 11) {
          fGetSpeedIncomAllMassSite(sitespeed, rho, &lbf[il*lbsitelength]);
          double invallmass = 0.0;
          for(int ll=0; ll<lbsy.nf; ll++)
            invallmass += rho[ll];
          invallmass = fReciprocal(invallmass);
          interforce[0] = lbinterforce[3*il  ]; interforce[1] = lbinterforce[3*il+1]; interforce[2] = lbinterforce[3*il+2];
          for(int ll=0; ll<lbsy.nf; ll++) {
            double frac = rho[ll] * invallmass;
	        interforce[0] += frac*(lbheatforce[il*3*lbsy.nf+3*ll  ]+postequil*(lbbdforce[3*ll  ]+lboscilforce[3*ll  ]*freq));
            interforce[1] += frac*(lbheatforce[il*3*lbsy.nf+3*ll+1]+postequil*(lbbdforce[3*ll+1]+lboscilforce[3*ll+1]*freq));
	        interforce[2] += frac*(lbheatforce[il*3*lbsy.nf+3*ll+2]+postequil*(lbbdforce[3*ll+2]+lboscilforce[3*ll+2]*freq));
          }
          if(lbphi[il] != 12 && lbphi[il] != 13)
            fSiteFluidIncomCollisionTRTGuoLishchukLocal(&lbf[il*lbsitelength], sitespeed, &lbomega[il*lbsy.nf], rho, interforce, &lbft[il*numpair], threed);
          fSiteSoluteCollisionBGK(&lbf[il*lbsitelength + lbsy.nf], sitespeed);
          fSiteThermalCollisionBGK(&lbf[il*lbsitelength + (lbsy.nf+lbsy.nc)], sitespeed);
        }
      }
    }
  }
  return 0;
}


int fCollisionTRTHeLishchukLocal()
{
  int numpair = 3 * lbsy.nf * (lbsy.nf-1) / 2;
  int threed = (lbsy.nd>2);
  long Tmax = lbdm.touter;
  double freq = (lbbdforcetyp==1)*sin(lboscilfreq*(lbcurstep-lbequstep));

  if(!incompress) {

    #pragma omp parallel
    {
      double interforce_t[3*lbsy.nf], sitespeed_t[3], rho_t[lbsy.nf];
      double *interforce = &interforce_t[0];
      double *sitespeed = &sitespeed_t[0];
      double *rho = &rho_t[0];

      #pragma omp for
      for(long il=0; il<Tmax; il++) {
        if(lbphi[il] != 11) {
          fGetSpeedAllMassSite(sitespeed, rho, &lbf[il*lbsitelength]);
          double invallmass = 0.0;
          for(int ll=0; ll<lbsy.nf; ll++)
            invallmass += rho[ll];
          invallmass = fReciprocal(invallmass);
          interforce[0] = lbinterforce[3*il  ]; interforce[1] = lbinterforce[3*il+1]; interforce[2] = lbinterforce[3*il+2];
          for(int ll=0; ll<lbsy.nf; ll++) {
            double frac = rho[ll] * invallmass;
	        interforce[0] += frac*(lbheatforce[il*3*lbsy.nf+3*ll  ]+postequil*(lbbdforce[3*ll  ]+lboscilforce[3*ll  ]*freq));
            interforce[1] += frac*(lbheatforce[il*3*lbsy.nf+3*ll+1]+postequil*(lbbdforce[3*ll+1]+lboscilforce[3*ll+1]*freq));
	        interforce[2] += frac*(lbheatforce[il*3*lbsy.nf+3*ll+2]+postequil*(lbbdforce[3*ll+2]+lboscilforce[3*ll+2]*freq));
          }
          if(lbphi[il] != 12 && lbphi[il] != 13)
            fSiteFluidCollisionTRTHeLishchukLocal(&lbf[il*lbsitelength], sitespeed, &lbomega[il*lbsy.nf], rho, interforce, &lbft[il*numpair], threed);
          fSiteSoluteCollisionBGK(&lbf[il*lbsitelength + lbsy.nf], sitespeed);
          fSiteThermalCollisionBGK(&lbf[il*lbsitelength + (lbsy.nf+lbsy.nc)], sitespeed);
        }
      }
    }
  }
  else {

    #pragma omp parallel
    {
      double interforce_t[3*lbsy.nf], sitespeed_t[3], rho_t[lbsy.nf];
      double *interforce = &interforce_t[0];
      double *sitespeed = &sitespeed_t[0];
      double *rho = &rho_t[0];

      #pragma omp for
      for(long il=0; il<Tmax; il++) {
        if(lbphi[il] != 11) {
          fGetSpeedIncomAllMassSite(sitespeed, rho, &lbf[il*lbsitelength]);
          double invallmass = 0.0;
          for(int ll=0; ll<lbsy.nf; ll++)
            invallmass += rho[ll];
          invallmass = fReciprocal(invallmass);
          interforce[0] = lbinterforce[3*il  ]; interforce[1] = lbinterforce[3*il+1]; interforce[2] = lbinterforce[3*il+2];
          for(int ll=0; ll<lbsy.nf; ll++) {
            double frac = rho[ll] * invallmass;
	        interforce[0] += frac*(lbheatforce[il*3*lbsy.nf+3*ll  ]+postequil*(lbbdforce[3*ll  ]+lboscilforce[3*ll  ]*freq));
            interforce[1] += frac*(lbheatforce[il*3*lbsy.nf+3*ll+1]+postequil*(lbbdforce[3*ll+1]+lboscilforce[3*ll+1]*freq));
	        interforce[2] += frac*(lbheatforce[il*3*lbsy.nf+3*ll+2]+postequil*(lbbdforce[3*ll+2]+lboscilforce[3*ll+2]*freq));
          }
          if(lbphi[il] != 12 && lbphi[il] != 13)
            fSiteFluidIncomCollisionTRTHeLishchukLocal(&lbf[il*lbsitelength], sitespeed, &lbomega[il*lbsy.nf], rho, interforce, &lbft[il*numpair], threed);
          fSiteSoluteCollisionBGK(&lbf[il*lbsitelength + lbsy.nf], sitespeed);
          fSiteThermalCollisionBGK(&lbf[il*lbsitelength + (lbsy.nf+lbsy.nc)], sitespeed);
        }
      }
    }
  }
  return 0;
}


int fCollisionTRTSwift()
{
  long Tmax = lbdm.touter;
  double freq = (lbbdforcetyp==1)*sin(lboscilfreq*(lbcurstep-lbequstep));

  if(lbsy.nf>1) {

   #pragma omp parallel
   {
      double interforce_t[3*lbsy.nf], sitespeed_t[3], rho_t[lbsy.nf];
      double *interforce = &interforce_t[0];
      double *sitespeed = &sitespeed_t[0];
      double *rho = &rho_t[0];

      #pragma omp for
      for(long il=0; il<Tmax; il++) {
        fGetOneSpeedSite(sitespeed, &lbf[il*lbsitelength]);
        double T = (lbsy.nt>0)?fGetTemperatureSite(il):lbsyst;
        if(lbneigh[il]>0 && lbphi[il]==0) {
          sitespeed[0] = 0.0; sitespeed[1] = 0.0; sitespeed[2] = 0.0;
        }
        if(lbphi[il] != 11) {
          fGetAllMassSite(rho, &lbf[il*lbsitelength]);
          double frac = 0.5*(1.0+rho[1]);
          for(int ll=0; ll<3; ll++)
            interforce [ll] = frac*(lbinterforce[il*3*lbsy.nf+ll]+lbheatforce[il*3*lbsy.nf+ll]+postequil*(lbbdforce[ll]+lboscilforce[ll]*freq))
                            + (1.0-frac)*(lbinterforce[il*3*lbsy.nf+3+ll]+lbheatforce[il*3*lbsy.nf+3+ll]+postequil*(lbbdforce[3+ll]+lboscilforce[3+ll]*freq));
          if(lbphi[il] != 12 && lbphi[il] != 13)
            fSiteFluidCollisionTRTSwiftTwoFluid(&lbf[il*lbsitelength], sitespeed, &lbomega[il*lbsy.nf], rho, &lbft[8*il], interforce, T);
          fSiteSoluteCollisionBGK(&lbf[il*lbsitelength + lbsy.nf], sitespeed);
          fSiteThermalCollisionBGK(&lbf[il*lbsitelength + lbsy.nf+lbsy.nc], sitespeed);
        }
      }
    }
  }
  else {
      
   #pragma omp parallel
   {
      double interforce_t[3*lbsy.nf], sitespeed_t[3], rho_t[lbsy.nf];
      double *interforce = &interforce_t[0];
      double *sitespeed = &sitespeed_t[0];
      double *rho = &rho_t[0];

      #pragma omp for
      for(long il=0; il<Tmax; il++) {
        fGetOneSpeedSite(sitespeed, &lbf[il*lbsitelength]);
        double T = (lbsy.nt>0)?fGetTemperatureSite(il):lbsyst;
        if(lbneigh[il]>0 && lbphi[il]==0) {
          sitespeed[0] = 0.0; sitespeed[1] = 0.0; sitespeed[2] = 0.0;
        }
        if(lbphi[il] != 11) {
          fGetAllMassSite(rho, &lbf[il*lbsitelength]);
          for(int ll=0; ll<3; ll++)
            interforce [ll] = lbinterforce[il*3*lbsy.nf+ll]+lbheatforce[il*3*lbsy.nf+ll]+postequil*(lbbdforce[ll]+lboscilforce[ll]*freq);
          if(lbphi[il] != 12 && lbphi[il] != 13)
            fSiteFluidCollisionTRTSwiftOneFluid(&lbf[il*lbsitelength], sitespeed, &lbomega[il*lbsy.nf], rho, &lbft[4*il], interforce, T);
          fSiteSoluteCollisionBGK(&lbf[il*lbsitelength + lbsy.nf], sitespeed);
          fSiteThermalCollisionBGK(&lbf[il*lbsitelength + lbsy.nf+lbsy.nc], sitespeed);
        }
      }
    }
  }
  return 0;
}

int fCollisionTRTEDMSwift()
{
  long Tmax = lbdm.touter;
  double freq = (lbbdforcetyp==1)*sin(lboscilfreq*(lbcurstep-lbequstep));

  if(lbsy.nf>1) {

   #pragma omp parallel
   {
      double interforce_t[3*lbsy.nf], sitespeed_t[3], rho_t[lbsy.nf];
      double *interforce = &interforce_t[0];
      double *sitespeed = &sitespeed_t[0];
      double *rho = &rho_t[0];

      #pragma omp for
      for(long il=0; il<Tmax; il++) {
        fGetOneSpeedSite(sitespeed, &lbf[il*lbsitelength]);
        double T = (lbsy.nt>0)?fGetTemperatureSite(il):lbsyst;
        if(lbneigh[il]>0 && lbphi[il]==0) {
          sitespeed[0] = 0.0; sitespeed[1] = 0.0; sitespeed[2] = 0.0;
        }
        if(lbphi[il] != 11) {
          fGetAllMassSite(rho, &lbf[il*lbsitelength]);
          double frac = 0.5*(1.0+rho[1]);
          for(int ll=0; ll<3; ll++)
            interforce [ll] = frac*(lbinterforce[il*3*lbsy.nf+ll]+lbheatforce[il*3*lbsy.nf+ll]+postequil*(lbbdforce[ll]+lboscilforce[ll]*freq))
                            + (1.0-frac)*(lbinterforce[il*3*lbsy.nf+3+ll]+lbheatforce[il*3*lbsy.nf+3+ll]+postequil*(lbbdforce[3+ll]+lboscilforce[3+ll]*freq));
          if(lbphi[il] != 12 && lbphi[il] != 13)
            fSiteFluidCollisionTRTEDMSwiftTwoFluid(&lbf[il*lbsitelength], sitespeed, &lbomega[il*lbsy.nf], rho, &lbft[8*il], interforce, T);
          fSiteSoluteCollisionBGK(&lbf[il*lbsitelength + lbsy.nf], sitespeed);
          fSiteThermalCollisionBGK(&lbf[il*lbsitelength + lbsy.nf+lbsy.nc], sitespeed);
        }
      }
    }
  }
  else {
      
   #pragma omp parallel
   {
      double interforce_t[3*lbsy.nf], sitespeed_t[3], rho_t[lbsy.nf];
      double *interforce = &interforce_t[0];
      double *sitespeed = &sitespeed_t[0];
      double *rho = &rho_t[0];

      #pragma omp for
      for(long il=0; il<Tmax; il++) {
        fGetOneSpeedSite(sitespeed, &lbf[il*lbsitelength]);
        double T = (lbsy.nt>0)?fGetTemperatureSite(il):lbsyst;
        if(lbneigh[il]>0 && lbphi[il]==0) {
          sitespeed[0] = 0.0; sitespeed[1] = 0.0; sitespeed[2] = 0.0;
        }
        if(lbphi[il] != 11) {
          fGetAllMassSite(rho, &lbf[il*lbsitelength]);
          for(int ll=0; ll<3; ll++)
            interforce [ll] = lbinterforce[il*3*lbsy.nf+ll]+lbheatforce[il*3*lbsy.nf+ll]+postequil*(lbbdforce[ll]+lboscilforce[ll]*freq);
          if(lbphi[il] != 12 && lbphi[il] != 13)
            fSiteFluidCollisionTRTEDMSwiftOneFluid(&lbf[il*lbsitelength], sitespeed, &lbomega[il*lbsy.nf], rho, &lbft[4*il], interforce, T);
          fSiteSoluteCollisionBGK(&lbf[il*lbsitelength + lbsy.nf], sitespeed);
          fSiteThermalCollisionBGK(&lbf[il*lbsitelength + lbsy.nf+lbsy.nc], sitespeed);
        }
      }
    }
  }
  return 0;
}

int fCollisionTRTGuoSwift()
{
  long Tmax = lbdm.touter;
  double freq = (lbbdforcetyp==1)*sin(lboscilfreq*(lbcurstep-lbequstep));

  if(lbsy.nf>1) {

   #pragma omp parallel
   {
      double interforce_t[3*lbsy.nf], sitespeed_t[3], rho_t[lbsy.nf];
      double *interforce = &interforce_t[0];
      double *sitespeed = &sitespeed_t[0];
      double *rho = &rho_t[0];

      #pragma omp for
      for(long il=0; il<Tmax; il++) {
        fGetOneSpeedSite(sitespeed, &lbf[il*lbsitelength]);
        double T = (lbsy.nt>0)?fGetTemperatureSite(il):lbsyst;
        if(lbneigh[il]>0 && lbphi[il]==0) {
          sitespeed[0] = 0.0; sitespeed[1] = 0.0; sitespeed[2] = 0.0;
        }
        if(lbphi[il] != 11) {
          fGetAllMassSite(rho, &lbf[il*lbsitelength]);
          double frac = 0.5*(1.0+rho[1]);
          for(int ll=0; ll<3; ll++)
            interforce [ll] = frac*(lbinterforce[il*3*lbsy.nf+ll]+lbheatforce[il*3*lbsy.nf+ll]+postequil*(lbbdforce[ll]+lboscilforce[ll]*freq))
                            + (1.0-frac)*(lbinterforce[il*3*lbsy.nf+3+ll]+lbheatforce[il*3*lbsy.nf+3+ll]+postequil*(lbbdforce[3+ll]+lboscilforce[3+ll]*freq));
          if(lbphi[il] != 12 && lbphi[il] != 13)
            fSiteFluidCollisionTRTGuoSwiftTwoFluid(&lbf[il*lbsitelength], sitespeed, &lbomega[il*lbsy.nf], rho, &lbft[8*il], interforce, T);
          fSiteSoluteCollisionBGK(&lbf[il*lbsitelength + lbsy.nf], sitespeed);
          fSiteThermalCollisionBGK(&lbf[il*lbsitelength + lbsy.nf+lbsy.nc], sitespeed);
        }
      }
    }
  }
  else {
      
   #pragma omp parallel
   {
      double interforce_t[3*lbsy.nf], sitespeed_t[3], rho_t[lbsy.nf];
      double *interforce = &interforce_t[0];
      double *sitespeed = &sitespeed_t[0];
      double *rho = &rho_t[0];

      #pragma omp for
      for(long il=0; il<Tmax; il++) {
        fGetOneSpeedSite(sitespeed, &lbf[il*lbsitelength]);
        double T = (lbsy.nt>0)?fGetTemperatureSite(il):lbsyst;
        if(lbneigh[il]>0 && lbphi[il]==0) {
          sitespeed[0] = 0.0; sitespeed[1] = 0.0; sitespeed[2] = 0.0;
        }
        if(lbphi[il] != 11) {
          fGetAllMassSite(rho, &lbf[il*lbsitelength]);
          for(int ll=0; ll<3; ll++)
            interforce [ll] = lbinterforce[il*3*lbsy.nf+ll]+lbheatforce[il*3*lbsy.nf+ll]+postequil*(lbbdforce[ll]+lboscilforce[ll]*freq);
          if(lbphi[il] != 12 && lbphi[il] != 13)
            fSiteFluidCollisionTRTGuoSwiftOneFluid(&lbf[il*lbsitelength], sitespeed, &lbomega[il*lbsy.nf], rho, &lbft[4*il], interforce, T);
          fSiteSoluteCollisionBGK(&lbf[il*lbsitelength + lbsy.nf], sitespeed);
          fSiteThermalCollisionBGK(&lbf[il*lbsitelength + lbsy.nf+lbsy.nc], sitespeed);
        }
      }
    }
  }
  return 0;
}

int fCollisionTRTHeSwift()
{
  long Tmax = lbdm.touter;
  double freq = (lbbdforcetyp==1)*sin(lboscilfreq*(lbcurstep-lbequstep));

  if(lbsy.nf>1) {

   #pragma omp parallel
   {
      double interforce_t[3*lbsy.nf], sitespeed_t[3], rho_t[lbsy.nf];
      double *interforce = &interforce_t[0];
      double *sitespeed = &sitespeed_t[0];
      double *rho = &rho_t[0];

      #pragma omp for
      for(long il=0; il<Tmax; il++) {
        fGetOneSpeedSite(sitespeed, &lbf[il*lbsitelength]);
        double T = (lbsy.nt>0)?fGetTemperatureSite(il):lbsyst;
        if(lbneigh[il]>0 && lbphi[il]==0) {
          sitespeed[0] = 0.0; sitespeed[1] = 0.0; sitespeed[2] = 0.0;
        }
        if(lbphi[il] != 11) {
          fGetAllMassSite(rho, &lbf[il*lbsitelength]);
          double frac = 0.5*(1.0+rho[1]);
          for(int ll=0; ll<3; ll++)
            interforce [ll] = frac*(lbinterforce[il*3*lbsy.nf+ll]+lbheatforce[il*3*lbsy.nf+ll]+postequil*(lbbdforce[ll]+lboscilforce[ll]*freq))
                            + (1.0-frac)*(lbinterforce[il*3*lbsy.nf+3+ll]+lbheatforce[il*3*lbsy.nf+3+ll]+postequil*(lbbdforce[3+ll]+lboscilforce[3+ll]*freq));
          if(lbphi[il] != 12 && lbphi[il] != 13)
            fSiteFluidCollisionTRTHeSwiftTwoFluid(&lbf[il*lbsitelength], sitespeed, &lbomega[il*lbsy.nf], rho, &lbft[8*il], interforce, T);
          fSiteSoluteCollisionBGK(&lbf[il*lbsitelength + lbsy.nf], sitespeed);
          fSiteThermalCollisionBGK(&lbf[il*lbsitelength + lbsy.nf+lbsy.nc], sitespeed);
        }
      }
    }
  }
  else {
      
   #pragma omp parallel
   {
      double interforce_t[3*lbsy.nf], sitespeed_t[3], rho_t[lbsy.nf];
      double *interforce = &interforce_t[0];
      double *sitespeed = &sitespeed_t[0];
      double *rho = &rho_t[0];

      #pragma omp for
      for(long il=0; il<Tmax; il++) {
        fGetOneSpeedSite(sitespeed, &lbf[il*lbsitelength]);
        double T = (lbsy.nt>0)?fGetTemperatureSite(il):lbsyst;
        if(lbneigh[il]>0 && lbphi[il]==0) {
          sitespeed[0] = 0.0; sitespeed[1] = 0.0; sitespeed[2] = 0.0;
        }
        if(lbphi[il] != 11) {
          fGetAllMassSite(rho, &lbf[il*lbsitelength]);
          for(int ll=0; ll<3; ll++)
            interforce [ll] = lbinterforce[il*3*lbsy.nf+ll]+lbheatforce[il*3*lbsy.nf+ll]+postequil*(lbbdforce[ll]+lboscilforce[ll]*freq);
          if(lbphi[il] != 12 && lbphi[il] != 13)
            fSiteFluidCollisionTRTHeSwiftOneFluid(&lbf[il*lbsitelength], sitespeed, &lbomega[il*lbsy.nf], rho, &lbft[4*il], interforce, T);
          fSiteSoluteCollisionBGK(&lbf[il*lbsitelength + lbsy.nf], sitespeed);
          fSiteThermalCollisionBGK(&lbf[il*lbsitelength + lbsy.nf+lbsy.nc], sitespeed);
        }
      }
    }
  }
  return 0;
}

