/***************************************************
 *   DL_MESO       Version 2.7                     *
 *   Authors   :   R. S. Qin, M. A. Seaton         *
 *                 J. Meng                         *
 *   Copyright :   UKRI STFC Daresbury Laboratory  *
 *             :   09/12/2018                      *
 ***************************************************/

double fGetRelaxationFrequency(int typ, double gamma, double rho, double a, double b, double c, double d, double n)
{
  // calculate relaxation time from shear rate
  // for given rheological models

  double omega, taueff, mueff, mu0, muinf, yield, m, papanamult, lambda;

  omega = 1.0;
  switch (typ) {
    case 0: // Simple Newtonian fluid: constant kinematic viscosity
      omega = a;
      break;
    case 1: // Density-dependent Newtonian fluid: mu = mu0
      mu0 = a;
      taueff = mu0*lbrcssq*fReciprocal(rho) + 0.5;
      omega = fReciprocal(taueff);
      break;
    case 2: // Power-law fluid: mu = mu0 * gamma^(n-1)
      mu0 = a;
      mueff = mu0*pow(gamma,n);
      taueff = mueff*lbrcssq*fReciprocal(rho) + 0.5;
      omega = fReciprocal(taueff);
      break;
    case 3: // Bingham plastic: mu = mu0 + yield / gamma * (1.0-exp(-m*gamma))
      mu0 = a;
      yield = b;
      m = c;
      mueff = mu0+(1.0-exp(-m*gamma))*yield*fReciprocal(gamma);
      taueff = mueff*lbrcssq*fReciprocal(rho) + 0.5;
      omega = fReciprocal(taueff);
      break;
    case 4: // Herschel-Bulkley: mu = K * gamma^(n-1) + yield / gamma * (1.0-exp(-m*gamma))
      mu0 = a;
      yield = b;
      m = c;
      mueff = mu0*pow(gamma,n)+(1.0-exp(-m*gamma))*yield*fReciprocal(gamma);
      taueff = mueff*lbrcssq*fReciprocal(rho) + 0.5;
      omega = fReciprocal(taueff);
      break;
    case 5: // Casson: mu = (sqrt(mu0) + sqrt(yield/gamma) * (1.0-exp(-m*gamma))^2
      mu0 = a;
      yield = b;
      m = c;
      papanamult = (1.0-exp(-m*gamma))*fReciprocal(sqrt(gamma));
      // d = 2.0*sqrt(mu0*yield)
      mueff = mu0 + papanamult * (d + yield * papanamult);
      taueff = mueff*lbrcssq*fReciprocal(rho) + 0.5;
      omega = fReciprocal(taueff);
      break;
    case 6: // Carreau-Yasuda: mu = muinf + (mu0 - muinf) * (1 + (lambda * gamma)^m)^((n-1)/a)
      muinf = a;
      mu0 = b;
      lambda = c;
      m = d;
      yield = 1.0 + pow(lambda*gamma, m);
      mueff = muinf + mu0 * pow(yield, n);
      taueff = mueff*lbrcssq*fReciprocal(rho) + 0.5;
      omega = fReciprocal(taueff);
      break;
  }
  return omega;
}

int fGetShearRateBGK(double *shearrate, long tpos)
{
  // calculate shear rates for given lattice site
  // for subsequent calculations of relaxation times
  // (used with BGK calculations for compressible fluids)
    
  double rho, rrho, fluidshear;
  int qdim=lbsy.nf+lbsy.nc+lbsy.nt;
  double cx, cy, cz, fi, modv, uv;
  double pixx, piyy, pizz, pixy, pixz, piyz;
  double threed = (lbsy.nd==3);
  double sitespeed[3];
  double *f=&lbf[tpos*lbsitelength];

  fGetSpeedSite(sitespeed, f);
  modv = sitespeed[0]*sitespeed[0]+sitespeed[1]*sitespeed[1]+sitespeed[2]*sitespeed[2];
  rho = fGetTotMassSite(&lbf[tpos*lbsitelength]);
  rrho = fReciprocal(rho);

  pixx = 0.0; piyy = 0.0; pizz = 0.0; pixy = 0.0; pixz = 0.0; piyz = 0.0;
  for(int xi=0; xi<lbsy.nq; xi++) {
    cx=lbvx[xi];
    cy=lbvy[xi];
    cz=lbvz[xi];
    uv = cx*sitespeed[0]+cy*sitespeed[1]+cz*sitespeed[2];
    fi = -rho*lbw[xi]*(1.0+3.0*uv+4.5*uv*uv-1.5*modv);
    for(int k=0; k<lbsy.nf; k++)
      fi += f[xi*qdim+k];
      
    // obtain contributions to shear rate (xx, yy, xy/yx, zz, xz/zx, yz/zy)
    pixx += cx*cx*fi;
    piyy += cy*cy*fi;
    pizz += cz*cz*fi*threed;
    pixy += cx*cy*fi;
    pixz += cx*cz*fi*threed;
    piyz += cy*cz*fi*threed;
  }
  fluidshear = sqrt(0.5*(pixx*pixx+piyy*piyy+pizz*pizz)+pixy*pixy+pixz*pixz+piyz*piyz);

  for(int k=0; k<lbsy.nf; k++) {
    shearrate[k] = lbrcssq*lbomega[tpos*lbsy.nf+k]*fluidshear*rrho;
  }
  return 0;
}

int fGetShearRateBGKIncom(double *shearrate, long tpos)
{
  // calculate shear rates for given lattice site
  // for subsequent calculations of relaxation times
  // (used with BGK calculations for incompressible fluids)
    
  double rho, rrho0, fluidshear;
  int qdim=lbsy.nf+lbsy.nc+lbsy.nt;
  double cx, cy, cz, fi, modv, uv;
  double pixx, piyy, pizz, pixy, pixz, piyz;
  double threed = (lbsy.nd==3);
  double sitespeed[3];
  double *f=&lbf[tpos*lbsitelength];

  fGetSpeedSite(sitespeed, f);
  modv = sitespeed[0]*sitespeed[0]+sitespeed[1]*sitespeed[1]+sitespeed[2]*sitespeed[2];
  rho = fGetTotMassSite(&lbf[tpos*lbsitelength]);

  pixx = 0.0; piyy = 0.0; pizz = 0.0; pixy = 0.0; pixz = 0.0; piyz = 0.0;
  for(int xi=0; xi<lbsy.nq; xi++) {
    cx=lbvx[xi];
    cy=lbvy[xi];
    cz=lbvz[xi];
    uv = cx*sitespeed[0]+cy*sitespeed[1]+cz*sitespeed[2];
    fi = -lbw[xi]*rho;
    for(int k=0; k<lbsy.nf; k++)
      fi += (f[xi*qdim+k]-lbw[xi]*lbincp[k]*(3.0*uv+4.5*uv*uv-1.5*modv));
      // obtain contributions to shear rate (xx, yy, xy/yx, zz, xz/zx, yz/zy)
    pixx += cx*cx*fi;
    piyy += cy*cy*fi;
    pizz += cz*cz*fi*threed;
    pixy += cx*cy*fi;
    pixz += cx*cz*fi*threed;
    piyz += cy*cz*fi*threed;
  }
  fluidshear = sqrt(0.5*(pixx*pixx+piyy*piyy+pizz*pizz)+pixy*pixy+pixz*pixz+piyz*piyz);

  for(int k=0; k<lbsy.nf; k++) {
    rrho0 = fReciprocal(lbincp[k]);
    shearrate[k] = lbrcssq*lbomega[tpos*lbsy.nf+k]*fluidshear*rrho0;
  }
  return 0;
}

int fGetShearRateTRT(double *shearrate, long tpos)
{
  // calculate shear rates for given lattice site
  // for subsequent calculations of relaxation times
  // (used with TRT calculations for compressible fluids)
    
  double rho, rrho, fluidshear, omegaplus, omegaminus, omeganeg;
  int qdim=lbsy.nf+lbsy.nc+lbsy.nt;
  double cx, cy, cz, fi, modv, uv;
  double pixx, piyy, pizz, pixy, pixz, piyz;
  double threed = (lbsy.nd==3);
  double sitespeed[3], fneq[lbsy.nq];
  double *f=&lbf[tpos*lbsitelength];

  fGetSpeedSite(sitespeed, f);
  modv = sitespeed[0]*sitespeed[0]+sitespeed[1]*sitespeed[1]+sitespeed[2]*sitespeed[2];
  rho = fGetTotMassSite(&lbf[tpos*lbsitelength]);
  rrho = fReciprocal(rho);

  // calculate non-equilibrium distribution functions (for all fluids)
    
  for(int i=0; i<lbsy.nq; i++) {
    uv = lbvx[i]*sitespeed[0]+lbvy[i]*sitespeed[1]+lbvz[i]*sitespeed[2];
    fneq[i] = -rho*lbw[i]*(1.0+3.0*uv+4.5*uv*uv-1.5*modv);
    for(int k=0; k<lbsy.nf; k++) {
      fneq[i] += f[i*qdim+k];
    }
  }

  // loop through fluids to find shear rates
  // (using individual values of symmetric and
  // antisymmetric relaxation times)

  for(int k=0; k<lbsy.nf; k++) {
    pixx = 0.0; piyy = 0.0; pizz = 0.0; pixy = 0.0; pixz = 0.0; piyz = 0.0;
    omeganeg = fTRTOmegaAntisymmetric(lbomega[lbsy.nf*tpos+k], lbtrtmagic);
    omegaplus = 0.5 * (lbomega[lbsy.nf*tpos+k] + omeganeg);
    omegaminus = 0.5 * (lbomega[lbsy.nf*tpos+k] - omeganeg);
    for(int xi=0; xi<lbsy.nq; xi++) {
      cx=lbvx[xi];
      cy=lbvy[xi];
      cz=lbvz[xi];
      int xj = lbopv[xi];
      fi = omegaplus * fneq[xi] + omegaminus * fneq[xj];
      // obtain contributions to shear rate (xx, yy, xy/yx, zz, xz/zx, yz/zy)
      pixx += cx*cx*fi;
      piyy += cy*cy*fi;
      pizz += cz*cz*fi*threed;
      pixy += cx*cy*fi;
      pixz += cx*cz*fi*threed;
      piyz += cy*cz*fi*threed;
    }
    fluidshear = sqrt(0.5*(pixx*pixx+piyy*piyy+pizz*pizz)+pixy*pixy+pixz*pixz+piyz*piyz);
    shearrate[k] = lbrcssq*fluidshear*rrho;
  }
  return 0;
}

int fGetShearRateTRTIncom(double *shearrate, long tpos)
{
  // calculate shear rates for given lattice site
  // for subsequent calculations of relaxation times
  // (used with TRT calculations for incompressible fluids)
    
  double rho, rrho0, fluidshear, omegaplus, omegaminus, omeganeg;
  int qdim=lbsy.nf+lbsy.nc+lbsy.nt;
  double cx, cy, cz, fi, modv, uv;
  double pixx, piyy, pizz, pixy, pixz, piyz;
  double threed = (lbsy.nd==3);
  double sitespeed[3], fneq[lbsy.nq];
  double *f=&lbf[tpos*lbsitelength];

  fGetSpeedSite(sitespeed, f);
  modv = sitespeed[0]*sitespeed[0]+sitespeed[1]*sitespeed[1]+sitespeed[2]*sitespeed[2];
  rho = fGetTotMassSite(&lbf[tpos*lbsitelength]);
    
  // calculate non-equilibrium distribution functions (for all fluids)
    
  for(int i=0; i<lbsy.nq; i++) {
    uv = lbvx[i]*sitespeed[0]+lbvy[i]*sitespeed[1]+lbvz[i]*sitespeed[2];
    fneq[i] = -lbw[i]*rho;
    for(int k=0; k<lbsy.nf; k++) {
      fneq[i] += (f[i*qdim+k]-lbw[i]*lbincp[k]*(3.0*uv+4.5*uv*uv-1.5*modv));
    }
  }

  // loop through fluids to find shear rates
  // (using individual values of symmetric and
  // antisymmetric relaxation times)

  for(int k=0; k<lbsy.nf; k++) {
    rrho0 = fReciprocal(lbincp[k]);
    pixx = 0.0; piyy = 0.0; pizz = 0.0; pixy = 0.0; pixz = 0.0; piyz = 0.0;
    omeganeg = fTRTOmegaAntisymmetric(lbomega[lbsy.nf*tpos+k], lbtrtmagic);
    omegaplus = 0.5 * (lbomega[lbsy.nf*tpos+k] + omeganeg);
    omegaminus = 0.5 * (lbomega[lbsy.nf*tpos+k] - omeganeg);
    for(int xi=0; xi<lbsy.nq; xi++) {
      cx=lbvx[xi];
      cy=lbvy[xi];
      cz=lbvz[xi];
      int xj = lbopv[xi];
      fi = omegaplus * fneq[xi] + omegaminus * fneq[xj];
      // obtain contributions to shear rate (xx, yy, xy/yx, zz, xz/zx, yz/zy)
      pixx += cx*cx*fi;
      piyy += cy*cy*fi;
      pizz += cz*cz*fi*threed;
      pixy += cx*cy*fi;
      pixz += cx*cz*fi*threed;
      piyz += cy*cz*fi*threed;
    }
    fluidshear = sqrt(0.5*(pixx*pixx+piyy*piyy+pizz*pizz)+pixy*pixy+pixz*pixz+piyz*piyz);
    shearrate[k] = lbrcssq*fluidshear*rrho0;
  }
  return 0;
}

int fGetShearRateMRT(double *shearrate, long tpos)
{
  // calculate shear rates for given lattice site
  // for subsequent calculations of relaxation times
  // (used with MRT collisions for compressible fluids)
    
  double rho, rrho, fluidshear;
  int qdim=lbsy.nf+lbsy.nc+lbsy.nt;
  double cx, cy, cz, fi, msm, uv, modv;
  double pixx, piyy, pizz, pixy, pixz, piyz;
  double threed = (lbsy.nd==3);
  double sitespeed[3];
  double fneq[lbsy.nq], collide[lbsy.nq];
  double *f=&lbf[tpos*lbsitelength];
    
  rho = fGetTotMassSite(&lbf[tpos*lbsitelength]);
  rrho = fReciprocal(rho);
  fGetSpeedSite(sitespeed, f);
  modv = sitespeed[0]*sitespeed[0]+sitespeed[1]*sitespeed[1]+sitespeed[2]*sitespeed[2];
    
  // calculate non-equilibrium distribution functions (for all fluids)
    
  for(int i=0; i<lbsy.nq; i++) {
    uv = lbvx[i]*sitespeed[0]+lbvy[i]*sitespeed[1]+lbvz[i]*sitespeed[2];
    fneq[i] = -rho*lbw[i]*(1.0+3.0*uv+4.5*uv*uv-1.5*modv);
    for(int k=0; k<lbsy.nf; k++) {
      fneq[i] += f[i*qdim+k];
    }
  }

  // loop through fluids to find shear rates
  // (using individual values of shear and bulk
  // relaxation times)
    
  for(int k=0; k<lbsy.nf; k++) {
    pixx=0.0; piyy=0.0; pizz=0.0; pixy=0.0; pixz=0.0; piyz=0.0;
    fGetMRTCollide(collide, lbomega[tpos*lbsy.nf+k], lbtfbulk[k]);
    for(int i=0; i<lbsy.nq; i++) {
      cx = lbvx[i];
      cy = lbvy[i];
      cz = lbvz[i];
      fi = 0.0;
      for(int j=0; j<lbsy.nq; j++) {
        msm = 0.0;
        for(int m=0; m<lbsy.nq; m++) {
          msm += collide[m] * lbtrinv[i*lbsy.nq+m] * lbtr[m*lbsy.nq+j];
        }
        fi += msm * fneq[j];
      }
      // obtain contributions to shear rate (xx, yy, xy/yx, zz, xz/zx, yz/zy)
      pixx += cx*cx*fi;
      piyy += cy*cy*fi;
      pizz += cz*cz*fi*threed;
      pixy += cx*cy*fi;
      pixz += cx*cz*fi*threed;
      piyz += cy*cz*fi*threed;
    }
    fluidshear = sqrt(0.5*(pixx*pixx+piyy*piyy+pizz*pizz)+pixy*pixy+pixz*pixz+piyz*piyz);
    shearrate[k] = lbrcssq*fluidshear*rrho;
  }
  return 0;
}

int fGetShearRateMRTIncom(double *shearrate, long tpos)
{
  // calculate shear rates for given lattice site
  // for subsequent calculations of relaxation times
  // (used with MRT collisions for incompressible fluids)
    
  double rho, rrho0, fluidshear;
  int qdim=lbsy.nf+lbsy.nc+lbsy.nt;
  double cx, cy, cz, fi, msm, uv, modv;
  double pixx, piyy, pizz, pixy, pixz, piyz;
  double threed = (lbsy.nd==3);
  double sitespeed[3];
  double fneq[lbsy.nq], collide[lbsy.nq];
  double *f=&lbf[tpos*lbsitelength];
    
  rho = fGetTotMassSite(&lbf[tpos*lbsitelength]);
  fGetSpeedSite(sitespeed, f);
  modv = sitespeed[0]*sitespeed[0]+sitespeed[1]*sitespeed[1]+sitespeed[2]*sitespeed[2];
    
  // calculate non-equilibrium distribution functions (for all fluids)
    
  for(int i=0; i<lbsy.nq; i++) {
    uv = lbvx[i]*sitespeed[0]+lbvy[i]*sitespeed[1]+lbvz[i]*sitespeed[2];
    fneq[i] = -lbw[i]*rho;
    for(int k=0; k<lbsy.nf; k++) {
      fneq[i] += (f[i*qdim+k]-lbincp[k]*lbw[i]*(3.0*uv+4.5*uv*uv-1.5*modv));
    }
  }

  // loop through fluids to find shear rates
  // (using individual values of shear and bulk
  // relaxation times)
    
  for(int k=0; k<lbsy.nf; k++) {
    pixx=0.0; piyy=0.0; pizz=0.0; pixy=0.0; pixz=0.0; piyz=0.0;
    fGetMRTCollide(collide, lbomega[tpos*lbsy.nf+k], lbtfbulk[k]);
    for(int i=0; i<lbsy.nq; i++) {
      cx = lbvx[i];
      cy = lbvy[i];
      cz = lbvz[i];
      fi = 0.0;
      for(int j=0; j<lbsy.nq; j++) {
        msm = 0.0;
        for(int m=0; m<lbsy.nq; m++) {
          msm += collide[m] * lbtrinv[i*lbsy.nq+m] * lbtr[m*lbsy.nq+j];
        }
        fi += msm * fneq[j];
      }
      // obtain contributions to shear rate (xx, yy, xy/yx, zz, xz/zx, yz/zy)
      pixx += cx*cx*fi;
      piyy += cy*cy*fi;
      pizz += cz*cz*fi*threed;
      pixy += cx*cy*fi;
      pixz += cx*cz*fi*threed;
      piyz += cy*cz*fi*threed;
    }
    fluidshear = sqrt(0.5*(pixx*pixx+piyy*piyy+pizz*pizz)+pixy*pixy+pixz*pixz+piyz*piyz);
    rrho0 = fReciprocal(lbincp[k]);
    shearrate[k] = lbrcssq*fluidshear*rrho0;
  }
  return 0;
}

int fGetShearRateCLBED2Q9(double *shearrate, long tpos)
{
  // calculate shear rates for given lattice site
  // for subsequent calculations of relaxation times
  // (used with CLBE collisions for compressible fluids
  // using D2Q9 lattice)
    
  int qdim=lbsy.nf+lbsy.nc+lbsy.nt;
  double rho, rrho, fluidshear;
  double cx, cy, fi, mnsnm, uv, fourmult, modv, uxxyy, omegaminus;
  double pixx, piyy, pixy;
  double sitespeed[3];
  double fneq[lbsy.nq], collide[lbsy.nq*lbsy.nq], colldiag[lbsy.nq];
  double shift[lbsy.nq*lbsy.nq], mninv[lbsy.nq*lbsy.nq], nm[lbsy.nq*lbsy.nq];
  double *f=&lbf[tpos*lbsitelength];
    
  rho = fGetTotMassSite(&lbf[tpos*lbsitelength]);
  rrho = fReciprocal(rho);
  fGetSpeedSite(sitespeed, f);
  modv = sitespeed[0]*sitespeed[0]+sitespeed[1]*sitespeed[1];
  uxxyy = sitespeed[0]*sitespeed[0]*sitespeed[1]*sitespeed[1];
    
  // calculate non-equilibrium distribution functions (for all fluids)
    
  for(int i=0; i<lbsy.nq; i++) {
    uv = lbvx[i]*sitespeed[0]+lbvy[i]*sitespeed[1];
    fourmult = (3.0*lbvx[i]*lbvx[i]-1.0)*(3.0*lbvy[i]*lbvy[i]-1.0);
    fneq[i] = -rho*lbw[i]*(1.0+3.0*uv+4.5*uv*uv*(1.0+uv)-1.5*modv*(1.0+3.0*uv)+2.25*uxxyy*fourmult);
    for(int k=0; k<lbsy.nf; k++) {
      fneq[i] += f[i*qdim+k];
    }
  }

  // prepare matrices for calculating momentum flux tensor

  fGetCentralMomentTransformMatrix(nm, mninv, sitespeed);
  for(int i=0; i<lbsy.nq*lbsy.nq; i++)
    collide[i]=0.0;

  // loop through fluids to find shear rates
  // (using individual values of shear and bulk
  // relaxation times)

  for(int k=0; k<lbsy.nf; k++) {
    pixx=0.0; piyy=0.0; pixy=0.0;
    fGetCLBECollide(colldiag, lbomega[tpos*lbsy.nf+k], lbtfbulk[k], lbtfclb3[k], lbtfclb4[k]);
    for(int i=0; i<lbsy.nq; i++) {
      collide[i*lbsy.nq+i] = colldiag[i];
    }
    omegaminus = 0.5 * (lbtfbulk[k] - lbomega[tpos*lbsy.nf+k]);
    collide[31] = omegaminus;
    collide[39] = omegaminus;
    // calculate first matrix multiplication (product of inverse transforms into collision matrix)
    for(int i=0; i<lbsy.nq; i++) {
      for(int j=0; j<lbsy.nq; j++) {
        shift[i*lbsy.nq+j]=0.0;
        for(int m=0; m<lbsy.nq; m++) {
          shift[i*lbsy.nq+j] += mninv[i*lbsy.nq+m]*collide[m*lbsy.nq+j];
        }
      }
    }
    // calculate terms for each row by second matrix multiplication (inverse-collision product into transform product)
    for(int i=0; i<lbsy.nq; i++) {
      cx = lbvx[i];
      cy = lbvy[i];
      fi = 0.0;
      for(int j=0; j<lbsy.nq; j++) {
        mnsnm = 0.0;
        for(int m=0; m<lbsy.nq; m++) {
          mnsnm += shift[i*lbsy.nq+m] * nm[m*lbsy.nq+j];
        }
        fi += mnsnm * fneq[j];
      }
      // obtain contributions to shear rate (xx, yy, xy/yx, zz, xz/zx, yz/zy)
      pixx += cx*cx*fi;
      piyy += cy*cy*fi;
      pixy += cx*cy*fi;
    }
    fluidshear = sqrt(0.5*(pixx*pixx+piyy*piyy)+pixy*pixy);
    shearrate[k] = lbrcssq*fluidshear*rrho;
  }
  return 0;
}

int fGetShearRateCLBED3Q19(double *shearrate, long tpos)
{
  // calculate shear rates for given lattice site
  // for subsequent calculations of relaxation times
  // (used with CLBE collisions for compressible fluids
  // using D3Q19 lattice)
    
  int qdim=lbsy.nf+lbsy.nc+lbsy.nt;
  double c0=1.0/3.0;
  double rho, rrho, fluidshear;
  double cx, cy, cz, fi, mnsnm, uv, uxx, uyy, uzz, omegaminus;
  double eux,euy,euz,uxxyy,uxxzz,uyyzz,exx,eyy,ezz,exy,exz,eyz,e0,a0,a1,a2,a3,a4;
  double pixx, piyy, pizz, pixy, pixz, piyz;
  double sitespeed[3];
  double fneq[lbsy.nq], collide[lbsy.nq*lbsy.nq], colldiag[lbsy.nq];
  double shift[lbsy.nq*lbsy.nq], mninv[lbsy.nq*lbsy.nq], nm[lbsy.nq*lbsy.nq];
  double *f=&lbf[tpos*lbsitelength];
    
  rho = fGetTotMassSite(&lbf[tpos*lbsitelength]);
  rrho = fReciprocal(rho);
  fGetSpeedSite(sitespeed, f);
  uxx = sitespeed[0]*sitespeed[0];
  uyy = sitespeed[1]*sitespeed[1];
  uzz = sitespeed[2]*sitespeed[2];
  uxxyy = uxx*uyy;
  uxxzz = uxx*uzz;
  uyyzz = uyy*uzz;
    
  // calculate non-equilibrium distribution functions (for all fluids)
    
  for(int i=0; i<lbsy.nq; i++) {
    eux = lbvx[i]* sitespeed[0];
    euy = lbvy[i]* sitespeed[1];
    euz = lbvz[i]* sitespeed[2];
    uv = eux+euy+euz;
    exx = lbvx[i]*lbvx[i];
    eyy = lbvy[i]*lbvy[i];
    ezz = lbvz[i]*lbvz[i];
    exy = lbvx[i]*lbvy[i];
    exz = lbvx[i]*lbvz[i];
    eyz = lbvy[i]*lbvz[i];
    e0 = exx+eyy+ezz;
    a0 = 1.5*e0*(7.0-3.0*e0);
    a1 = 0.5*(5.0*e0+1.0)*(e0-2.0);
    a2 = 4.5*e0*(e0-1.0);
    a3 = 9.0*e0*(e0-2.0);
    a4 = 3.0*(e0-1.0)*(e0-2.0);
    fneq[i] = -rho*lbw[i]*(1.0+3.0*uv+9.0*(eux*euy+eux*euz+euy*euz)+(a0*exx+a1)*uxx+(a0*eyy+a1)*uyy+(a0*ezz+a1)*uzz
                           +(a2*exy+a3*lbvy[i]*(1.0-exx))*uxx*sitespeed[1]+(a2*exz+a3*lbvz[i]*(1.0-exx))*uxx*sitespeed[2]+(a2*exy+a3*lbvx[i]*(1.0-eyy))*uyy*sitespeed[0]
                           +(a2*eyz+a3*lbvz[i]*(1.0-eyy))*uyy*sitespeed[2]+(a2*exz+a3*lbvx[i]*(1.0-ezz))*uzz*sitespeed[0]+(a2*eyz+a3*lbvy[i]*(1.0-ezz))*uzz*sitespeed[1]
                           +(a2*exx*eyy+a3*exx+a3*eyy+a4)*uxxyy+(a2*exx*ezz+a3*exx+a3*ezz+a4)*uxxzz+(a2*eyy*ezz+a3*eyy+a3*ezz+a4)*uyyzz);
    for(int k=0; k<lbsy.nf; k++) {
      fneq[i] += f[i*qdim+k];
    }
  }

  // prepare matrices for calculating momentum flux tensor

  fGetCentralMomentTransformMatrix(nm, mninv, sitespeed);
  for(int i=0; i<lbsy.nq*lbsy.nq; i++)
    collide[i]=0.0;

  // loop through fluids to find shear rates
  // (using individual values of shear and bulk
  // relaxation times)

  for(int k=0; k<lbsy.nf; k++) {
    pixx=0.0; piyy=0.0; pizz=0.0; pixy=0.0; pixz=0.0; piyz=0.0;
    fGetCLBECollide(colldiag, lbomega[tpos*lbsy.nf+k], lbtfbulk[k], lbtfclb3[k], lbtfclb4[k]);
    for(int i=0; i<lbsy.nq; i++) {
      collide[i*lbsy.nq+i] = colldiag[i];
    }
    omegaminus = c0 * (lbtfbulk[k] - lbomega[tpos*lbsy.nf+k]);
    collide[141] = omegaminus;
    collide[142] = omegaminus;
    collide[159] = omegaminus;
    collide[161] = omegaminus;
    collide[178] = omegaminus;
    collide[179] = omegaminus;
    // calculate first matrix multiplication (product of inverse transforms into collision matrix)
    for(int i=0; i<lbsy.nq; i++) {
      for(int j=0; j<lbsy.nq; j++) {
        shift[i*lbsy.nq+j]=0.0;
        for(int m=0; m<lbsy.nq; m++) {
          shift[i*lbsy.nq+j] += mninv[i*lbsy.nq+m]*collide[m*lbsy.nq+j];
        }
      }
    }
    // calculate terms for each row by second matrix multiplication (inverse-collision product into transform product)
    for(int i=0; i<lbsy.nq; i++) {
      cx = lbvx[i];
      cy = lbvy[i];
      cz = lbvz[i];
      fi = 0.0;
      for(int j=0; j<lbsy.nq; j++) {
        mnsnm = 0.0;
        for(int m=0; m<lbsy.nq; m++) {
          mnsnm += shift[i*lbsy.nq+m] * nm[m*lbsy.nq+j];
        }
        fi += mnsnm * fneq[j];
      }
      // obtain contributions to shear rate (xx, yy, xy/yx, zz, xz/zx, yz/zy)
      pixx += cx*cx*fi;
      piyy += cy*cy*fi;
      pizz += cz*cz*fi;
      pixy += cx*cy*fi;
      pixz += cx*cz*fi;
      piyz += cy*cz*fi;
    }
    fluidshear = sqrt(0.5*(pixx*pixx+piyy*piyy+pizz*pizz)+pixy*pixy+pixz*pixz+piyz*piyz);
    shearrate[k] = lbrcssq*fluidshear*rrho;
  }
  return 0;
}

int fGetShearRateCLBED3Q27(double *shearrate, long tpos)
{
  // calculate shear rates for given lattice site
  // for subsequent calculations of relaxation times
  // (used with CLBE collisions for compressible fluids
  // using D3Q27 lattice)
    
  int qdim=lbsy.nf+lbsy.nc+lbsy.nt;
  double c0=1.0/3.0;
  double rho, rrho, fluidshear;
  double cx, cy, cz, fi, mnsnm, uv, modv, uxx, uyy, uzz, uxxyy, uxxzz, uyyzz, uxxyyzz, omegaminus;
  double eixux,eiyuy,eizuz,twomultx,twomulty,twomultz,fourmultxy,fourmultxz,fourmultyz,sixmult;
  double pixx, piyy, pizz, pixy, pixz, piyz;
  double sitespeed[3];
  double fneq[lbsy.nq], collide[lbsy.nq*lbsy.nq], colldiag[lbsy.nq];
  double shift[lbsy.nq*lbsy.nq], mninv[lbsy.nq*lbsy.nq], nm[lbsy.nq*lbsy.nq];
  double *f=&lbf[tpos*lbsitelength];
    
  rho = fGetTotMassSite(&lbf[tpos*lbsitelength]);
  rrho = fReciprocal(rho);
  fGetSpeedSite(sitespeed, f);
  uxxyy = sitespeed[0]*sitespeed[0]*sitespeed[1]*sitespeed[1];
  uxx = sitespeed[0]*sitespeed[0];
  uyy = sitespeed[1]*sitespeed[1];
  uzz = sitespeed[2]*sitespeed[2];
  modv = uxx+uyy+uzz;
  uxxyy = uxx*uyy;
  uxxzz = uxx*uzz;
  uyyzz = uyy*uzz;
  uxxyyzz = uxx*uyy*uzz;
    
  // calculate non-equilibrium distribution functions (for all fluids)
    
  for(int i=0; i<lbsy.nq; i++) {
    eixux = lbvx[i] * sitespeed[0];
    eiyuy = lbvy[i] * sitespeed[1];
    eizuz = lbvz[i] * sitespeed[2];
    uv = eixux+eiyuy+eizuz;
    twomultx = (3.0*lbvx[i]*lbvx[i]-1.0);
    twomulty = (3.0*lbvy[i]*lbvy[i]-1.0);
    twomultz = (3.0*lbvz[i]*lbvz[i]-1.0);
    fourmultxy = twomultx*twomulty;
    fourmultxz = twomultx*twomultz;
    fourmultyz = twomulty*twomultz;
    sixmult = fourmultxy*twomultz;
    fneq[i] = -rho*lbw[i]*(1.0+3.0*uv+4.5*uv*uv*(1.0+uv)-1.5*modv*(1.0+3.0*uv)
                           +13.5*(twomultx*uxx*eiyuy*eizuz+twomulty*uyy*eixux*eizuz+twomultz*uzz*eixux*eiyuy)
                           +2.25*(uxxyy*fourmultxy*(1.0+3.0*eizuz)+uxxzz*fourmultxz*(1.0+3.0*eiyuy)+uyyzz*fourmultyz*(1.0+3.0*eixux))
                           +3.375*uxxyyzz*sixmult);
    for(int k=0; k<lbsy.nf; k++) {
      fneq[i] += f[i*qdim+k];
    }
  }

  // prepare matrices for calculating momentum flux tensor

  fGetCentralMomentTransformMatrix(nm, mninv, sitespeed);
  for(int i=0; i<lbsy.nq*lbsy.nq; i++)
    collide[i]=0.0;

  // loop through fluids to find shear rates
  // (using individual values of shear and bulk
  // relaxation times)

  for(int k=0; k<lbsy.nf; k++) {
    pixx=0.0; piyy=0.0; pizz=0.0; pixy=0.0; pixz=0.0; piyz=0.0;
    fGetCLBECollide(colldiag, lbomega[tpos*lbsy.nf+k], lbtfbulk[k], lbtfclb3[k], lbtfclb4[k]);
    for(int i=0; i<lbsy.nq; i++) {
      collide[i*lbsy.nq+i] = colldiag[i];
    }
    omegaminus = c0 * (lbtfbulk[k] - lbomega[tpos*lbsy.nf+k]);
    collide[197] = omegaminus;
    collide[198] = omegaminus;
    collide[223] = omegaminus;
    collide[225] = omegaminus;
    collide[250] = omegaminus;
    collide[251] = omegaminus;
    // calculate first matrix multiplication (product of inverse transforms into collision matrix)
    for(int i=0; i<lbsy.nq; i++) {
      for(int j=0; j<lbsy.nq; j++) {
        shift[i*lbsy.nq+j]=0.0;
        for(int m=0; m<lbsy.nq; m++) {
          shift[i*lbsy.nq+j] += mninv[i*lbsy.nq+m]*collide[m*lbsy.nq+j];
        }
      }
    }
    // calculate terms for each row by second matrix multiplication (inverse-collision product into transform product)
    for(int i=0; i<lbsy.nq; i++) {
      cx = lbvx[i];
      cy = lbvy[i];
      cz = lbvz[i];
      fi = 0.0;
      for(int j=0; j<lbsy.nq; j++) {
        mnsnm = 0.0;
        for(int m=0; m<lbsy.nq; m++) {
          mnsnm += shift[i*lbsy.nq+m] * nm[m*lbsy.nq+j];
        }
        fi += mnsnm * fneq[j];
      }
      // obtain contributions to shear rate (xx, yy, xy/yx, zz, xz/zx, yz/zy)
      pixx += cx*cx*fi;
      piyy += cy*cy*fi;
      pizz += cz*cz*fi;
      pixy += cx*cy*fi;
      pixz += cx*cz*fi;
      piyz += cy*cz*fi;
    }
    fluidshear = sqrt(0.5*(pixx*pixx+piyy*piyy+pizz*pizz)+pixy*pixy+pixz*pixz+piyz*piyz);
    shearrate[k] = lbrcssq*fluidshear*rrho;
  }
  return 0;
}

int fGetShearRateBGKSwift(double *shearrate, long tpos)
{
  // calculate shear rates for given lattice site
  // for subsequent calculations of relaxation times
  // (used with BGK collisions and Swift free-energy
  // interactions)
    
  double rho[lbsy.nf], rrho, phi, fluidshear;
  int qdim=lbsy.nf+lbsy.nc+lbsy.nt;
  double cx, cy, cz, fi, modv, uv, edr, udr, ee, pb, lambda, omegat;
  double T, drdx, drdy, drdz, nabr, dfdx, dfdy, dfdz, nabf;
  double pixx, piyy, pizz, pixy, pixz, piyz;
  double threed = (lbsy.nd==3);
  double sitespeed[3];
  double *f=&lbf[tpos*lbsitelength];

  fGetAllMassSite(rho, f);
  rrho = fReciprocal(rho[0]);
  fGetOneSpeedSite(sitespeed, f);
  modv = sitespeed[0]*sitespeed[0]+sitespeed[1]*sitespeed[1]+sitespeed[2]*sitespeed[2];
  T = (lbsy.nt>0)?fGetTemperatureSite(tpos):lbsyst;
  drdx = (lbfeeos>0)?lbft[4*lbsy.nf*tpos  ]:0.0;
  drdy = (lbfeeos>0)?lbft[4*lbsy.nf*tpos+1]:0.0;
  drdz = (lbfeeos>0)?lbft[4*lbsy.nf*tpos+2]:0.0;
  nabr = (lbfeeos>0)?lbft[4*lbsy.nf*tpos+3]:0.0;

  if(lbsy.nf>1) {
    phi = rho[1];
    dfdx = lbft[4*lbsy.nf*tpos+4];
    dfdy = lbft[4*lbsy.nf*tpos+5];
    dfdz = lbft[4*lbsy.nf*tpos+6];
    nabf = lbft[4*lbsy.nf*tpos+7];
    omegat = 2.0*lbomega[lbsy.nf*tpos]*lbomega[lbsy.nf*tpos+1]/(2.0*lbomega[lbsy.nf*tpos]+(1.0+rho[1])*(lbomega[lbsy.nf*tpos+1]-lbomega[lbsy.nf*tpos]));
  }
  else {
    phi = 0.0;
    dfdx = 0.0;
    dfdy = 0.0;
    dfdz = 0.0;
    nabf = 0.0;
    omegat = lbomega[lbsy.nf*tpos];
  }
  pb = fGetBulkPressureSwift(rho[0], phi, T);
  lambda = fGetLambdaSwift(rho[0], omegat, T);

  pixx = 0.0; piyy = 0.0; pizz = 0.0; pixy = 0.0; pixz = 0.0; piyz = 0.0;
  for(int xi=0; xi<lbsy.nq; xi++) {
    cx=lbvx[xi];
    cy=lbvy[xi];
    cz=lbvz[xi];
    uv = cx*sitespeed[0]+cy*sitespeed[1]+cz*sitespeed[2];
    edr = cx*drdx+cy*drdy+cz*drdz;
    udr = drdx*sitespeed[0]+drdy*sitespeed[1]+drdz*sitespeed[2];
    ee = cx*cx+cy*cy+cz*cz;
    fi = f[xi*qdim]-rho[0]*lbw0[xi]-lbwi[xi]*(rho[0]*(uv+1.5*uv*uv-0.5*modv)+lambda*(3.0*uv*edr+(lbwgam[xi]*ee+lbwdel[xi])*udr))
                   -lbwpt[xi]*(pb-lbkappa*(rho[0]*nabr+phi*nabf))
                   -lbkappa*(lbwxx[xi]*(drdx*drdx+dfdx*dfdx)+lbwyy[xi]*(drdy*drdy+dfdy*dfdy)+lbwzz[xi]*(drdz*drdz+dfdz*dfdz)
                            +lbwxy[xi]*(drdx*drdy+dfdx*dfdy)+lbwxz[xi]*(drdx*drdz+dfdx*dfdz)+lbwyz[xi]*(drdy*drdz+dfdy*dfdz));
      
    // obtain contributions to shear rate (xx, yy, xy/yx, zz, xz/zx, yz/zy)
    pixx += cx*cx*fi;
    piyy += cy*cy*fi;
    pizz += cz*cz*fi*threed;
    pixy += cx*cy*fi;
    pixz += cx*cz*fi*threed;
    piyz += cy*cz*fi*threed;
  }
  fluidshear = sqrt(0.5*(pixx*pixx+piyy*piyy+pizz*pizz)+pixy*pixy+pixz*pixz+piyz*piyz);

  for(int fl=0; fl<lbsy.nf; fl++) {
    shearrate[fl] = lbrcssq*lbomega[tpos*lbsy.nf+fl]*fluidshear*rrho;
  }
  return 0;
}

int fGetShearRateTRTSwift(double *shearrate, long tpos)
{
  // calculate shear rates for given lattice site
  // for subsequent calculations of relaxation times
  // (used with TRT calculations and Swift free-energy
  // interactions)
    
  double rho[lbsy.nf], rrho, phi, fluidshear, omegaplus, omegaminus, omeganeg;
  int qdim=lbsy.nf+lbsy.nc+lbsy.nt;
  double cx, cy, cz, fi, modv, uv, edr, udr, ee, pb, lambda, omegat;
  double T, drdx, drdy, drdz, nabr, dfdx, dfdy, dfdz, nabf;
  double pixx, piyy, pizz, pixy, pixz, piyz;
  double threed = (lbsy.nd==3);
  double sitespeed[3], fneq[lbsy.nq];
  double *f=&lbf[tpos*lbsitelength];

  fGetAllMassSite(rho, f);
  rrho = fReciprocal(rho[0]);
  fGetOneSpeedSite(sitespeed, f);
  modv = sitespeed[0]*sitespeed[0]+sitespeed[1]*sitespeed[1]+sitespeed[2]*sitespeed[2];
  T = (lbsy.nt>0)?fGetTemperatureSite(tpos):lbsyst;
  drdx = (lbfeeos>0)?lbft[4*lbsy.nf*tpos  ]:0.0;
  drdy = (lbfeeos>0)?lbft[4*lbsy.nf*tpos+1]:0.0;
  drdz = (lbfeeos>0)?lbft[4*lbsy.nf*tpos+2]:0.0;
  nabr = (lbfeeos>0)?lbft[4*lbsy.nf*tpos+3]:0.0;

  if(lbsy.nf>1) {
    phi = rho[1];
    dfdx = lbft[4*lbsy.nf*tpos+4];
    dfdy = lbft[4*lbsy.nf*tpos+5];
    dfdz = lbft[4*lbsy.nf*tpos+6];
    nabf = lbft[4*lbsy.nf*tpos+7];
    omegat = 2.0*lbomega[lbsy.nf*tpos]*lbomega[lbsy.nf*tpos+1]/(2.0*lbomega[lbsy.nf*tpos]+(1.0+rho[1])*(lbomega[lbsy.nf*tpos+1]-lbomega[lbsy.nf*tpos]));
  }
  else {
    phi = 0.0;
    dfdx = 0.0;
    dfdy = 0.0;
    dfdz = 0.0;
    nabf = 0.0;
    omegat = lbomega[lbsy.nf*tpos];
  }
  pb = fGetBulkPressureSwift(rho[0], phi, T);
  lambda = fGetLambdaSwift(rho[0], omegat, T);

  // calculate non-equilibrium distribution functions (for all fluids)
    
  for(int i=0; i<lbsy.nq; i++) {
    cx=lbvx[i];
    cy=lbvy[i];
    cz=lbvz[i];
    uv = cx*sitespeed[0]+cy*sitespeed[1]+cz*sitespeed[2];
    edr = cx*drdx+cy*drdy+cz*drdz;
    udr = drdx*sitespeed[0]+drdy*sitespeed[1]+drdz*sitespeed[2];
    ee = cx*cx+cy*cy+cz*cz;
    fneq[i] = f[i*qdim]-rho[0]*lbw0[i]-lbwi[i]*(rho[0]*(uv+1.5*uv*uv-0.5*modv)+lambda*(3.0*uv*edr+(lbwgam[i]*ee+lbwdel[i])*udr))
                -lbwpt[i]*(pb-lbkappa*(rho[0]*nabr+phi*nabf))
                -lbkappa*(lbwxx[i]*(drdx*drdx+dfdx*dfdx)+lbwyy[i]*(drdy*drdy+dfdy*dfdy)+lbwzz[i]*(drdz*drdz+dfdz*dfdz)
                            +lbwxy[i]*(drdx*drdy+dfdx*dfdy)+lbwxz[i]*(drdx*drdz+dfdx*dfdz)+lbwyz[i]*(drdy*drdz+dfdy*dfdz));
  }

  // loop through fluids to find shear rates
  // (using individual values of symmetric and
  // antisymmetric relaxation times)

  for(int fl=0; fl<lbsy.nf; fl++) {
    pixx = 0.0; piyy = 0.0; pizz = 0.0; pixy = 0.0; pixz = 0.0; piyz = 0.0;
    omeganeg = fTRTOmegaAntisymmetric(lbomega[lbsy.nf*tpos+fl], lbtrtmagic);
    omegaplus = 0.5 * (lbomega[lbsy.nf*tpos+fl] + omeganeg);
    omegaminus = 0.5 * (lbomega[lbsy.nf*tpos+fl] - omeganeg);
    for(int xi=0; xi<lbsy.nq; xi++) {
      cx=lbvx[xi];
      cy=lbvy[xi];
      cz=lbvz[xi];
      int xj = lbopv[xi];
      fi = omegaplus * fneq[xi] + omegaminus * fneq[xj];
      // obtain contributions to shear rate (xx, yy, xy/yx, zz, xz/zx, yz/zy)
      pixx += cx*cx*fi;
      piyy += cy*cy*fi;
      pizz += cz*cz*fi*threed;
      pixy += cx*cy*fi;
      pixz += cx*cz*fi*threed;
      piyz += cy*cz*fi*threed;
    }
    fluidshear = sqrt(0.5*(pixx*pixx+piyy*piyy+pizz*pizz)+pixy*pixy+pixz*pixz+piyz*piyz);
    shearrate[fl] = lbrcssq*fluidshear*rrho;
  }
  return 0;
}


int fGetShearRateMRTSwift(double *shearrate, long tpos)
{
  // calculate shear rates for given lattice site
  // for subsequent calculations of relaxation times
  // (used with MRT calculations and Swift free-energy
  // interactions)
    
  double rho[lbsy.nf], rrho, phi, fluidshear;
  int qdim=lbsy.nf+lbsy.nc+lbsy.nt;
  double cx, cy, cz, fi, msm, modv, uv, edr, udr, ee, pb, lambda, omegat;
  double T, drdx, drdy, drdz, nabr, dfdx, dfdy, dfdz, nabf;
  double pixx, piyy, pizz, pixy, pixz, piyz;
  double threed = (lbsy.nd==3);
  double sitespeed[3], fneq[lbsy.nq], collide[lbsy.nf];
  double *f=&lbf[tpos*lbsitelength];

  fGetAllMassSite(rho, f);
  rrho = fReciprocal(rho[0]);
  fGetOneSpeedSite(sitespeed, f);
  modv = sitespeed[0]*sitespeed[0]+sitespeed[1]*sitespeed[1]+sitespeed[2]*sitespeed[2];
  T = (lbsy.nt>0)?fGetTemperatureSite(tpos):lbsyst;
  drdx = (lbfeeos>0)?lbft[4*lbsy.nf*tpos  ]:0.0;
  drdy = (lbfeeos>0)?lbft[4*lbsy.nf*tpos+1]:0.0;
  drdz = (lbfeeos>0)?lbft[4*lbsy.nf*tpos+2]:0.0;
  nabr = (lbfeeos>0)?lbft[4*lbsy.nf*tpos+3]:0.0;

  if(lbsy.nf>1) {
    phi = rho[1];
    dfdx = lbft[4*lbsy.nf*tpos+4];
    dfdy = lbft[4*lbsy.nf*tpos+5];
    dfdz = lbft[4*lbsy.nf*tpos+6];
    nabf = lbft[4*lbsy.nf*tpos+7];
    omegat = 2.0*lbomega[lbsy.nf*tpos]*lbomega[lbsy.nf*tpos+1]/(2.0*lbomega[lbsy.nf*tpos]+(1.0+rho[1])*(lbomega[lbsy.nf*tpos+1]-lbomega[lbsy.nf*tpos]));
  }
  else {
    phi = 0.0;
    dfdx = 0.0;
    dfdy = 0.0;
    dfdz = 0.0;
    nabf = 0.0;
    omegat = lbomega[lbsy.nf*tpos];
  }
  pb = fGetBulkPressureSwift(rho[0], phi, T);
  lambda = fGetLambdaSwift(rho[0], omegat, T);

  // calculate non-equilibrium distribution functions (for all fluids)
    
  for(int i=0; i<lbsy.nq; i++) {
    cx=lbvx[i];
    cy=lbvy[i];
    cz=lbvz[i];
    uv = cx*sitespeed[0]+cy*sitespeed[1]+cz*sitespeed[2];
    edr = cx*drdx+cy*drdy+cz*drdz;
    udr = drdx*sitespeed[0]+drdy*sitespeed[1]+drdz*sitespeed[2];
    ee = cx*cx+cy*cy+cz*cz;
    fneq[i] = f[i*qdim]-rho[0]*lbw0[i]-lbwi[i]*(rho[0]*(uv+1.5*uv*uv-0.5*modv)+lambda*(3.0*uv*edr+(lbwgam[i]*ee+lbwdel[i])*udr))
                -lbwpt[i]*(pb-lbkappa*(rho[0]*nabr+phi*nabf))
                -lbkappa*(lbwxx[i]*(drdx*drdx+dfdx*dfdx)+lbwyy[i]*(drdy*drdy+dfdy*dfdy)+lbwzz[i]*(drdz*drdz+dfdz*dfdz)
                            +lbwxy[i]*(drdx*drdy+dfdx*dfdy)+lbwxz[i]*(drdx*drdz+dfdx*dfdz)+lbwyz[i]*(drdy*drdz+dfdy*dfdz));
  }

  // loop through fluids to find shear rates
  // (using individual values of shear and bulk
  // relaxation times)
    
  for(int k=0; k<lbsy.nf; k++) {
    pixx=0.0; piyy=0.0; pizz=0.0; pixy=0.0; pixz=0.0; piyz=0.0;
    fGetMRTCollide(collide, lbomega[tpos*lbsy.nf+k], lbtfbulk[k]);
    for(int i=0; i<lbsy.nq; i++) {
      cx = lbvx[i];
      cy = lbvy[i];
      cz = lbvz[i];
      fi = 0.0;
      for(int j=0; j<lbsy.nq; j++) {
        msm = 0.0;
        for(int m=0; m<lbsy.nq; m++) {
          msm += collide[m] * lbtrinv[i*lbsy.nq+m] * lbtr[m*lbsy.nq+j];
        }
        fi += msm * fneq[j];
      }
      // obtain contributions to shear rate (xx, yy, xy/yx, zz, xz/zx, yz/zy)
      pixx += cx*cx*fi;
      piyy += cy*cy*fi;
      pizz += cz*cz*fi*threed;
      pixy += cx*cy*fi;
      pixz += cx*cz*fi*threed;
      piyz += cy*cz*fi*threed;
    }
    fluidshear = sqrt(0.5*(pixx*pixx+piyy*piyy+pizz*pizz)+pixy*pixy+pixz*pixz+piyz*piyz);
    shearrate[k] = lbrcssq*fluidshear*rrho;
  }
  return 0;
}


int fGetSystemOmega()
{
  // calculate relaxation times for all lattice sites
  // based on shear rates and provided rheological models
  int (*fGetShearRate)(double*, long);
  double shearrate[lbsy.nf], rho[lbsy.nf];
  long Tmax = lbdm.touter;
    
  fGetShearRate = &fGetShearRateBGK;
  switch (collide) {
    case 0: case 1: case 2: case 3:
      if(interact==20) {
        fGetShearRate = &fGetShearRateBGKSwift;
      }
      else if(!incompress) {
        fGetShearRate = &fGetShearRateBGK;
      }
      else {
        fGetShearRate = &fGetShearRateBGKIncom;
      }
      break;
    case 4: case 5: case 6: case 7:
      if(interact==20) {
        fGetShearRate = &fGetShearRateTRTSwift;
      }
      else if(!incompress) {
        fGetShearRate = &fGetShearRateTRT;
      }
      else {
        fGetShearRate = &fGetShearRateTRTIncom;
      }
    case 8: case 9: case 10: case 11:
      if(interact==20) {
        fGetShearRate = &fGetShearRateMRTSwift;
      }
      else if(!incompress) {
        fGetShearRate = &fGetShearRateMRT;
      }
      else {
        fGetShearRate = &fGetShearRateMRTIncom;
      }
      break;
    case 12: case 13: case 14: case 15:
      if(lbsy.nq==9)
        fGetShearRate = &fGetShearRateCLBED2Q9;
      else if(lbsy.nq==19)
        fGetShearRate = &fGetShearRateCLBED3Q19;
      else if(lbsy.nq==27)
        fGetShearRate = &fGetShearRateCLBED3Q27;
      break;
  }

  if(interact==20 && lbsy.nf>1) {
    #pragma omp parallel
    {
      double mass;
      #pragma omp for
      for(long il=0; il<Tmax; il++) {
        if(lbphi[il]!=11 && lbphi[il]!=12 && lbphi[il]!=13) {
          fGetAllMassSite(rho, &lbf[il*lbsitelength]);
          fGetShearRate(shearrate, il);
          mass = 0.5*rho[0]*(1.0+rho[1]);
          lbomega[lbsy.nf*il  ] = fGetRelaxationFrequency(lbrheo[0], shearrate[0], mass, lbrheoa[0], lbrheob[0], lbrheoc[0], lbrheod[0], lbrheopower[0]);
          mass = 0.5*rho[0]*(1.0-rho[1]);
          lbomega[lbsy.nf*il+1] = fGetRelaxationFrequency(lbrheo[1], shearrate[1], mass, lbrheoa[1], lbrheob[1], lbrheoc[1], lbrheod[1], lbrheopower[1]);
        }
      }
    }
  }
  else if (!incompress) {
    #pragma omp parallel
    {
      double mass;
      #pragma omp for
      for(long il=0; il<Tmax; il++) {
        if(lbphi[il]!=11 && lbphi[il]!=12 && lbphi[il]!=13) {
          mass = fGetTotMassSite(&lbf[il*lbsitelength]);
          fGetShearRate(shearrate, il);
          for(int k=0; k<lbsy.nf; k++) {
            lbomega[lbsy.nf*il+k] = fGetRelaxationFrequency(lbrheo[k], shearrate[k], mass, lbrheoa[k], lbrheob[k], lbrheoc[k], lbrheod[k], lbrheopower[k]);
          }
        }
      }
    }
  }
  else {
    #pragma omp parallel
    {
      #pragma omp for
      for(long il=0; il<Tmax; il++) {
        if(lbphi[il]!=11 && lbphi[il]!=12 && lbphi[il]!=13) {
          fGetShearRate(shearrate, il);
          for(int k=0; k<lbsy.nf; k++) {
            lbomega[lbsy.nf*il+k] = fGetRelaxationFrequency(lbrheo[k], shearrate[k], lbincp[k], lbrheoa[k], lbrheob[k], lbrheoc[k], lbrheod[k], lbrheopower[k]);
          }
        }
      }
    }
  }
  return 0;
}

int fGetSystemOmegaSimple()
{
  // calculate relaxation times for all lattice sites
  // (when only Newtonian fluids are involved: no shear rates calculated)
  double rho[lbsy.nf];
  long Tmax = lbdm.touter;
    
  if(interact==20 && lbsy.nf>1) {
    #pragma omp parallel
    {
      double mass;
      #pragma omp for
      for(long il=0; il<Tmax; il++) {
        if(lbphi[il]!=11 && lbphi[il]!=12 && lbphi[il]!=13) {
          fGetAllMassSite(rho, &lbf[il*lbsitelength]);
          mass = 0.5*rho[0]*(1.0+rho[1]);
          lbomega[lbsy.nf*il  ] = fGetRelaxationFrequency(lbrheo[0], 0.0, mass, lbrheoa[0], 0.0, 0.0, 0.0, 0.0);
          mass = 0.5*rho[0]*(1.0-rho[1]);
          lbomega[lbsy.nf*il+1] = fGetRelaxationFrequency(lbrheo[1], 0.0, mass, lbrheoa[1], 0.0, 0.0, 0.0, 0.0);
        }
      }
    }
  }
  else if (!incompress) {
    #pragma omp parallel
    {
      double mass;
      #pragma omp for
      for(long il=0; il<Tmax; il++) {
        if(lbphi[il]!=11 && lbphi[il]!=12 && lbphi[il]!=13) {
          mass = fGetTotMassSite(&lbf[il*lbsitelength]);
          for(int k=0; k<lbsy.nf; k++) {
            lbomega[lbsy.nf*il+k] = fGetRelaxationFrequency(lbrheo[k], 0.0, mass, lbrheoa[k], 0.0, 0.0, 0.0, 0.0);
          }
        }
      }
    }
  }
  else {
    #pragma omp parallel
    {
      #pragma omp for
      for(long il=0; il<Tmax; il++) {
        if(lbphi[il]!=11 && lbphi[il]!=12 && lbphi[il]!=13) {
          for(int k=0; k<lbsy.nf; k++) {
            lbomega[lbsy.nf*il+k] = fGetRelaxationFrequency(lbrheo[k], 0.0, lbincp[k], lbrheoa[k], 0.0, 0.0, 0.0, 0.0);
          }
        }
      }
    }
  }
  return 0;
}
