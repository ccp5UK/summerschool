import javax.swing.*;
import java.util.*;
import java.lang.*;
import java.io.*;
import java.awt.*;
import java.awt.event.*;
import java.awt.geom.*;
import java.awt.image.*;
/*
 *     DL_MESO_GUI
 *     author: R. S. Qin, M. A. Seaton
 *     copyright: UKRI STFC Daresbury Laboratory and CCP5
 *     2005, 2018
 */
class setFluid extends JFrame {
    
    setlbeSysEvt fluinilbe=new setlbeSysEvt(this);

    JLabel densitylabel = new JLabel("fluid densities:",
				     JLabel.RIGHT);
    JLabel inilabel = new JLabel("initial:", JLabel.RIGHT);
    JTextField[] inidensity = new JTextField[6];

    JLabel cstlabel = new JLabel("constant:", JLabel.RIGHT);
    JTextField[] cstdensity = new JTextField[6];
    
    JLabel velocitylabel = new JLabel("initial velocities:", JLabel.RIGHT);
    JLabel velxlabel = new JLabel("x:", JLabel.RIGHT);
    JTextField inivx = new JTextField("0.0",12);
    JLabel velylabel = new JLabel("y:", JLabel.RIGHT);
    JTextField inivy = new JTextField("0.0",12);
    JLabel velzlabel = new JLabel("z:", JLabel.RIGHT);
    JTextField inivz = new JTextField("0.0",12);
    
    JLabel viscositylabel = new JLabel("relaxation time:",
				       JLabel.RIGHT);
    JTextField[] viscosities = new JTextField[6];

    @SuppressWarnings("unchecked")
	JComboBox<String> [] rheo = new JComboBox[6];
    
    JLabel rheomodellabel = new JLabel("rheological model:", JLabel.RIGHT);
    JLabel rheoalabel = new JLabel("rheological parameter a:", JLabel.RIGHT);
    JLabel rheoblabel = new JLabel("rheological parameter b:", JLabel.RIGHT);
    JLabel rheoclabel = new JLabel("rheological parameter c:", JLabel.RIGHT);
    JLabel rheodlabel = new JLabel("rheological parameter d:", JLabel.RIGHT);
    JLabel rheonlabel = new JLabel("rheological power index:", JLabel.RIGHT);
    JTextField[] rheoaparam = new JTextField[6];
    JTextField[] rheobparam = new JTextField[6];
    JTextField[] rheocparam = new JTextField[6];
    JTextField[] rheodparam = new JTextField[6];
    JTextField[] rheopower = new JTextField[6];

    JLabel trtmagiclabel = new JLabel("trt magic number:", JLabel.RIGHT);
    JTextField trtmagic = new JTextField("0.375",12);
    
    JLabel bulkviscositylabel = new JLabel("bulk relaxation time:",
				       JLabel.RIGHT);
    JTextField[] bulkviscosities = new JTextField[6];
    
    JLabel relax3label = new JLabel("third-order relaxation time:",
				       JLabel.RIGHT);
    JTextField[] relax3 = new JTextField[6];
    
    JLabel relax4label = new JLabel("fourth-order relaxation time:",
				       JLabel.RIGHT);
    JTextField[] relax4 = new JTextField[6];
    
    JLabel mrtrelaxlabel = new JLabel("mrt frequencies:",JLabel.RIGHT);
    JTextField[] mrtrelax = new JTextField[8];
   
    JButton save = new JButton("SAVE F");
    JButton close = new JButton("CANCEL F");
    Font font=new Font("Dialog", Font.BOLD, 13);
    
    public setFluid(int totf, int nd, int nq, int coll, int inter, double[] densf, double[] iniv, double[] relaxtime, double[] mrtrelaxfreq, double trtm, int[] rheomod, double[] rheoa, double[] rheob, double[] rheoc, double[] rheod, double[] rheon) {

        super("LBE fluid properties");

        int maxitem;

        setBounds(160, 10, 220+81*totf, 692+54*totf);
        JPanel pane=new JPanel(new GridBagLayout());

        for(int i=0; i<totf; i++) {
            addItem(pane, new JLabel("fluid "+i), i+2, 0, 1, 1, GridBagConstraints.CENTER);
        }

        densitylabel.setFont(font);
        addItem(pane, densitylabel, 0, 1, 1, 1, GridBagConstraints.WEST);

        inilabel.setFont(font);
        addItem(pane, inilabel, 1, 1, 1, 1, GridBagConstraints.EAST);
        for(int i=0; i<totf; i++) {
            inidensity[i]=new JTextField(12);
            inidensity[i].setText(Double.toString(densf[2*i]));
            addItem(pane, inidensity[i], i+2, 1, 1, 1, GridBagConstraints.CENTER);
        }

        cstlabel.setFont(font);
        addItem(pane, cstlabel, 1, 2, 1, 1, GridBagConstraints.EAST);
        for(int i=0; i<totf; i++) {
            cstdensity[i]=new JTextField(12);
            cstdensity[i].setText(Double.toString(densf[2*i+1]));
            addItem(pane, cstdensity[i], i+2, 2, 1, 1, GridBagConstraints.CENTER);
        }

        velocitylabel.setFont(font);
        velxlabel.setFont(font);
        velylabel.setFont(font);
        velzlabel.setFont(font);
        addItem(pane, velocitylabel, 0, 3, 1, 1, GridBagConstraints.WEST);
        addItem(pane, velxlabel, 1, 3, 1, 1, GridBagConstraints.EAST);
        addItem(pane, velylabel, 1, 4, 1, 1, GridBagConstraints.EAST);
        addItem(pane, velzlabel, 1, 5, 1, 1, GridBagConstraints.EAST);
        inivx.setText(Double.toString(iniv[0]));
        inivy.setText(Double.toString(iniv[0]));
        inivz.setText(Double.toString(iniv[0]));
        addItem(pane, inivx, 2, 3, 1, 1, GridBagConstraints.CENTER);
        addItem(pane, inivy, 2, 4, 1, 1, GridBagConstraints.CENTER);
        addItem(pane, inivz, 2, 5, 1, 1, GridBagConstraints.CENTER);
        if(nd==2) {
            velzlabel.setEnabled(false);
            inivz.setEnabled(false);
            inivz.setEditable(false);
        }
        rheomodellabel.setFont(font);
        addItem(pane, rheomodellabel, 0, 6, 2, 1, GridBagConstraints.WEST);
        for(int i=0; i<totf; i++) {
            rheo[i] = new JComboBox<String>();
            rheo[i].addItem("simple Newtonian");
            rheo[i].addItem("Newtonian");
            rheo[i].addItem("power law");
            rheo[i].addItem("Bingham");
            rheo[i].addItem("Herschel-Bulkley");
            rheo[i].addItem("Casson");
            rheo[i].addItem("Carreau-Yasuda");
            rheo[i].setName("rheo"+i);
            rheo[i].addItemListener(fluinilbe);
            rheo[i].setSelectedIndex(rheomod[i]);
            addItem(pane, rheo[i], i+2, 6, 1, 1, GridBagConstraints.CENTER);
        }
        
        rheoalabel.setFont(font);
        addItem(pane, rheoalabel, 0, 7, 2, 1, GridBagConstraints.WEST);
        int ka = 0;
        for(int i=0; i<totf; i++) {
            if(rheomod[i]>0) ka = 1;
            rheoaparam[i]=new JTextField(12);
            rheoaparam[i].setText(Double.toString(rheoa[i]));
            if(rheomod[i]==0) {
              rheoaparam[i].setEnabled(false);
              rheoaparam[i].setEditable(false);
            }
            else {
              rheoaparam[i].setEnabled(true);
              rheoaparam[i].setEditable(true);
            }
            addItem(pane, rheoaparam[i], i+2, 7, 1, 1, GridBagConstraints.CENTER);
        }
        rheoalabel.setEnabled(ka>0);
        
        rheoblabel.setFont(font);
        addItem(pane, rheoblabel, 0, 8, 2, 1, GridBagConstraints.WEST);
        int kb = 0;
        for(int i=0; i<totf; i++) {
            if(rheomod[i]>2) kb = 1;
            rheobparam[i]=new JTextField(12);
            rheobparam[i].setText(Double.toString(rheob[i]));
            if(rheomod[i]<3) {
              rheobparam[i].setEnabled(false);
              rheobparam[i].setEditable(false);
            }
            else {
              rheobparam[i].setEnabled(true);
              rheobparam[i].setEditable(true);
            }
            addItem(pane, rheobparam[i], i+2, 8, 1, 1, GridBagConstraints.CENTER);
        }
        rheoblabel.setEnabled(kb>0);
        
        rheoclabel.setFont(font);
        addItem(pane, rheoclabel, 0, 9, 2, 1, GridBagConstraints.WEST);
        int kc = 0;
        for(int i=0; i<totf; i++) {
            if(rheomod[i]>2) kc = 1;
            rheocparam[i]=new JTextField(12);
            rheocparam[i].setText(Double.toString(rheoc[i]));
            if(rheomod[i]<3) {
              rheocparam[i].setEnabled(false);
              rheocparam[i].setEditable(false);
            }
            else {
              rheocparam[i].setEnabled(true);
              rheocparam[i].setEditable(true);
            }
            addItem(pane, rheocparam[i], i+2, 9, 1, 1, GridBagConstraints.CENTER);
        }
        rheoclabel.setEnabled(kc>0);
        
        rheodlabel.setFont(font);
        addItem(pane, rheodlabel, 0, 10, 2, 1, GridBagConstraints.WEST);
        int kd = 0;
        for(int i=0; i<totf; i++) {
            if(rheomod[i]>5) kd = 1;
            rheodparam[i]=new JTextField(12);
            rheodparam[i].setText(Double.toString(rheod[i]));
            if(rheomod[i]<3) {
              rheodparam[i].setEnabled(false);
              rheodparam[i].setEditable(false);
            }
            else {
              rheodparam[i].setEnabled(true);
              rheodparam[i].setEditable(true);
            }
            addItem(pane, rheodparam[i], i+2, 10, 1, 1, GridBagConstraints.CENTER);
        }
        rheodlabel.setEnabled(kd>0);
        
        rheonlabel.setFont(font);
        addItem(pane, rheonlabel, 0, 11, 2, 1, GridBagConstraints.WEST);
        int kn = 0;
        for(int i=0; i<totf; i++) {
            if(rheomod[i]==2 || rheomod[i]==4 || rheomod[i]==6) kn = 1;
            rheopower[i]=new JTextField(12);
            rheopower[i].setText(Double.toString(rheon[i]));
            if(rheomod[i]<2 || rheomod[i]==3 || rheomod[i]==5) {
              rheopower[i].setEnabled(false);
              rheopower[i].setEditable(false);
            }
            else {
              rheopower[i].setEnabled(true);
              rheopower[i].setEditable(true);
            }
            addItem(pane, rheopower[i], i+2, 11, 1, 1, GridBagConstraints.CENTER);
        }
        rheonlabel.setEnabled(kn>0);
        
        viscositylabel.setFont(font);
        addItem(pane, viscositylabel, 0, 12, 2, 1, GridBagConstraints.WEST);
        for(int i=0; i<totf; i++) {
            viscosities[i]=new JTextField(12);
            viscosities[i].setText(Double.toString(relaxtime[4*i]));
            addItem(pane, viscosities[i], i+2, 12, 1, 1, GridBagConstraints.CENTER);
        }
        maxitem = 13;
        if(coll>3 && coll<8) {
            trtmagiclabel.setFont(font);
            addItem(pane, trtmagiclabel, 0, 13, 2, 1, GridBagConstraints.WEST);
            trtmagic.setText(Double.toString(trtm));
            addItem(pane, trtmagic, 2, 13, 1, 1, GridBagConstraints.CENTER);
            maxitem = 14;
        }
        if(coll>7) {
            bulkviscositylabel.setFont(font);
            addItem(pane, bulkviscositylabel, 0, 13, 2, 1, GridBagConstraints.WEST);
            for(int i=0; i<totf; i++) {
                bulkviscosities[i]=new JTextField(12);
                bulkviscosities[i].setText(Double.toString(relaxtime[4*i+1]));
                addItem(pane, bulkviscosities[i], i+2, 13, 1, 1, GridBagConstraints.CENTER);
            }
        }
        if(coll>7 & coll<12) {
            mrtrelaxlabel.setFont(font);
            addItem(pane, mrtrelaxlabel, 0, 14, 1, 1, GridBagConstraints.WEST);
            switch (nq) {
                case 9:     addItem(pane, new JLabel("s2"), 1, 14, 1, 1, GridBagConstraints.EAST);
                            addItem(pane, new JLabel("s4"), 1, 15, 1, 1, GridBagConstraints.EAST);
                            mrtrelaxfreq[0] = (mrtrelaxfreq[0]>0.0)?mrtrelaxfreq[0]:(inter==20?1.0:1.14);
                            mrtrelaxfreq[1] = (mrtrelaxfreq[1]>0.0)?mrtrelaxfreq[1]:(inter==20?1.0:1.92);
                            maxitem = 16;
                            break;
                case 15:    addItem(pane, new JLabel("s2"), 1, 14, 1, 1, GridBagConstraints.EAST);
                            addItem(pane, new JLabel("s4"), 1, 15, 1, 1, GridBagConstraints.EAST);
                            addItem(pane, new JLabel("s14"), 1, 16, 1, 1, GridBagConstraints.EAST);
                            mrtrelaxfreq[0] = (mrtrelaxfreq[0]>0.0)?mrtrelaxfreq[0]:(inter==20?1.0:1.2);
                            mrtrelaxfreq[1] = (mrtrelaxfreq[1]>0.0)?mrtrelaxfreq[1]:(inter==20?1.0:1.6);
                            mrtrelaxfreq[2] = (mrtrelaxfreq[2]>0.0)?mrtrelaxfreq[2]:(inter==20?1.0:1.2);
                            maxitem = 17;
                            break;
                case 19:    addItem(pane, new JLabel("s2"), 1, 14, 1, 1, GridBagConstraints.EAST);
                            addItem(pane, new JLabel("s4"), 1, 15, 1, 1, GridBagConstraints.EAST);
                            addItem(pane, new JLabel("s16"), 1, 16, 1, 1, GridBagConstraints.EAST);
                            mrtrelaxfreq[0] = (mrtrelaxfreq[0]>0.0)?mrtrelaxfreq[0]:(inter==20?1.0:1.4);
                            mrtrelaxfreq[1] = (mrtrelaxfreq[1]>0.0)?mrtrelaxfreq[1]:(inter==20?1.0:1.2);
                            mrtrelaxfreq[2] = (mrtrelaxfreq[2]>0.0)?mrtrelaxfreq[2]:(inter==20?1.0:1.98);
                            maxitem = 17;
                            break;
                case 27:    addItem(pane, new JLabel("s10"), 1, 14, 1, 1, GridBagConstraints.EAST);
                            addItem(pane, new JLabel("s13"), 1, 15, 1, 1, GridBagConstraints.EAST);
                            addItem(pane, new JLabel("s16"), 1, 16, 1, 1, GridBagConstraints.EAST);
                            addItem(pane, new JLabel("s17"), 1, 17, 1, 1, GridBagConstraints.EAST);
                            addItem(pane, new JLabel("s18"), 1, 18, 1, 1, GridBagConstraints.EAST);
                            addItem(pane, new JLabel("s20"), 1, 19, 1, 1, GridBagConstraints.EAST);
                            addItem(pane, new JLabel("s23"), 1, 20, 1, 1, GridBagConstraints.EAST);
                            addItem(pane, new JLabel("s26"), 1, 21, 1, 1, GridBagConstraints.EAST);
                            mrtrelaxfreq[0] = (mrtrelaxfreq[0]>0.0)?mrtrelaxfreq[0]:(inter==20?1.0:1.5);
                            mrtrelaxfreq[1] = (mrtrelaxfreq[1]>0.0)?mrtrelaxfreq[1]:(inter==20?1.0:1.83);
                            mrtrelaxfreq[2] = (mrtrelaxfreq[2]>0.0)?mrtrelaxfreq[2]:(inter==20?1.0:1.4);
                            mrtrelaxfreq[3] = (mrtrelaxfreq[3]>0.0)?mrtrelaxfreq[3]:(inter==20?1.0:1.61);
                            mrtrelaxfreq[4] = (mrtrelaxfreq[4]>0.0)?mrtrelaxfreq[4]:(inter==20?1.0:1.98);
                            mrtrelaxfreq[5] = (mrtrelaxfreq[5]>0.0)?mrtrelaxfreq[5]:(inter==20?1.0:1.98);
                            mrtrelaxfreq[6] = (mrtrelaxfreq[6]>0.0)?mrtrelaxfreq[6]:(inter==20?1.0:1.74);
                            mrtrelaxfreq[7] = (mrtrelaxfreq[7]>0.0)?mrtrelaxfreq[7]:(inter==20?1.0:1.74);
                            maxitem = 22;
                            break;
            }
            for (int i=0; i<8; i++) {
                mrtrelax[i]=new JTextField(12);
                mrtrelax[i].setText(Double.toString(mrtrelaxfreq[i]));
            }
            addItem(pane, mrtrelax[0], 2, 14, 1, 1, GridBagConstraints.CENTER);
            addItem(pane, mrtrelax[1], 2, 15, 1, 1, GridBagConstraints.CENTER);
            if(nq>9)
                addItem(pane, mrtrelax[2], 2, 16, 1, 1, GridBagConstraints.CENTER);
            if(nq==27) {
                addItem(pane, mrtrelax[3], 2, 17, 1, 1, GridBagConstraints.CENTER);
                addItem(pane, mrtrelax[4], 2, 18, 1, 1, GridBagConstraints.CENTER);
                addItem(pane, mrtrelax[5], 2, 19, 1, 1, GridBagConstraints.CENTER);
                addItem(pane, mrtrelax[6], 2, 20, 1, 1, GridBagConstraints.CENTER);
                addItem(pane, mrtrelax[7], 2, 21, 1, 1, GridBagConstraints.CENTER);
            }
        }
        if(coll>11) {
            relax3label.setFont(font);
            addItem(pane, relax3label, 0, 14, 2, 1, GridBagConstraints.WEST);
            relax4label.setFont(font);
            addItem(pane, relax4label, 0, 15, 2, 1, GridBagConstraints.WEST);
            for(int i=0; i<totf; i++) {
                relax3[i]=new JTextField(12);
                relax3[i].setText(Double.toString(relaxtime[4*i+2]));
                addItem(pane, relax3[i], i+2, 14, 1, 1, GridBagConstraints.CENTER);
                relax4[i]=new JTextField(12);
                relax4[i].setText(Double.toString(relaxtime[4*i+3]));
                addItem(pane, relax4[i], i+2, 15, 1, 1, GridBagConstraints.CENTER);
            }
            maxitem = 16;
        }
        

        Box buttonBox = Box.createHorizontalBox();
        save.setFont(font);
        save.addActionListener(fluinilbe);
        buttonBox.add(save);
        close.setFont(font);
        close.addActionListener(fluinilbe);
        buttonBox.add(close);
        addItem(pane, buttonBox, 0, maxitem, 2+totf, 1, GridBagConstraints.WEST);

        this.add(pane);
        this.pack();
        setVisible(true);
    }

    private void addItem(JPanel p, JComponent c, int x, int y, int width, int height, int align)
    {
        GridBagConstraints gc = new GridBagConstraints();
        gc.gridx = x;
        gc.gridy = y;
        gc.gridwidth = width;
        gc.gridheight = height;
        gc.weightx = 100.0;
        gc.weighty = 100.0;
        gc.insets = new Insets(5, 5, 5, 5);
        gc.anchor = align;
        gc.fill = GridBagConstraints.NONE;
        p.add(c, gc);
    }

}
