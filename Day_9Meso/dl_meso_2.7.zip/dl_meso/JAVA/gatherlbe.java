import javax.swing.*;
import java.util.*;
import java.lang.*;
import java.io.*;
import java.awt.*;
import java.awt.event.*;
import java.awt.geom.*;
import java.awt.image.*;
/*
 *     DL_MESO_GUI
 *     author: R. S. Qin, M. A. Seaton
 *     copyright: UKRI STFC Daresbury Laboratory and CCP5
 *     2005, 2018
 */
class gatherlbe extends JPanel {
    gatherlbeEvt clbe = new gatherlbeEvt(this); 
    
    Font font=new Font("Dialog", Font.BOLD, 12);
    Color paneltop=new Color(170, 170, 230);
    
    JPanel row1 =new JPanel();
    
    JPanel row2b =new JPanel();
    JComboBox<String> command= new JComboBox<String>();
    JPanel row2c =new JPanel();
    JComboBox<String> vtktype = new JComboBox<String>();
     
    JLabel info1 = new JLabel("<html>This step is only required if the parallel DL_MESO code has<br/>"
                            + "been run and Plot3D Q or XML-formatted structured grid VTK files<br/>"
                            + "have been produced; prior compilation of the utilities is required.</html>");
    JPanel row31 =new JPanel();
    JButton runbutton = new JButton("Gather data");
    JPanel row32 = new JPanel();

    public gatherlbe() {
        setSize(620, 530);
        GridLayout gl =new GridLayout(6, 1, 5, 5);
        FlowLayout fl = new FlowLayout(FlowLayout.CENTER);
        BorderLayout bl = new BorderLayout();
        setLayout(gl);
        add(row1);
        command.addItem("Choose file type");
        command.addItem("Plot3D");
        command.addItem("VTK");
        command.addItem("lbout.dump to VTK");
        command.addItem("lbout.dump to lbin.init");
        command.addItemListener(clbe);
        vtktype.addItem("Choose variable output");
        vtktype.addItem("all");
        vtktype.addItem("density");
        vtktype.addItem("mass fraction");
        vtktype.addItem("solute concentration");
        vtktype.addItem("temperature");
        vtktype.addItemListener(clbe);
        vtktype.setEnabled(false);
        runbutton.addActionListener(clbe);
        row31.add(info1);
        add(row31);
        row2b.add(command);
        row2c.add(vtktype);
        add(row2b);
        add(row2c);
        row32.add(runbutton);
        add(row32);
    }

}
