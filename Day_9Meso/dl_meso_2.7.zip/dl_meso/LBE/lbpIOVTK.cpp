/***************************************************
 *   DL_MESO       Version 2.7                     *
 *   Authors   :   R. S. Qin, M. A. Seaton         *
 *   Copyright :   UKRI STFC Daresbury Laboratory  *
 *             :   09/12/2018                      *
 ***************************************************/

// XML VTK (structured grid) format output

int fOutputVTK(const char* filename="lbout")
{
  // output .vts file with properties for all fluids

  long offset;
  int iprop;
  char buf[80];
  int numberOfPoints,numberOfPointsAll;
  int start[3], end[3], startall[3], endall[3], length[3];
  int* intScalarBuffer;
  float* scalarBuffer;
  float* vectorBuffer;
  ofstream file;
  stringstream sstm;
  string header,footer;
  unsigned long headersize,footersize,startpos;
    
  // find extent and number of points for I/O group
  fGroupPieceRangeLocal(start,end);
  if(!lbmpiio) {
    startall[0] = start[0];
    startall[1] = start[1];
    startall[2] = start[2];
    endall[0] = end[0];
    endall[1] = end[1];
    endall[2] = end[2];
  }
  else {
    startall[0] = startall[1] = lbdm.bwid;
    startall[2] = (lbsy.nd==3)?lbdm.bwid:0;
    endall[0] = lbsy.nx+lbdm.bwid;
    endall[1] = lbsy.ny+lbdm.bwid;
    endall[2] = (lbsy.nd==3)?(lbsy.nz+lbdm.bwid):1;
  }
  numberOfPoints = fGroupPieceDataPoints(length);
  numberOfPointsAll = (lbmpiio)?lbsy.nx*lbsy.ny*lbsy.nz:numberOfPoints;

  // open file if root process for I/O group
  if(lbIOGroup.rank==0) {
    if(!lbmpiio && lbdm.size>lbIOGroup.size)
      sprintf(buf, "%s%.6dat%.6d.vts", filename, lbIOGroup.groupId, qVersion);
    else
      sprintf(buf, "%s%.6d.vts", filename, qVersion);
  }
  fOpenOutputBinaryFile(buf, file);
    
  sstm.str(string());
  // write file header
  if((!lbmpiio && lbIOGroup.rank==0) || (lbmpiio && lbIOGroup.groupId==0)) {
    sstm<<"<?xml version=\"1.0\"?>\n";
    sstm<<"<VTKFile type=\"StructuredGrid\" version=\"0.1\" byte_order=\"BigEndian\">\n";
    sstm<<"<StructuredGrid WholeExtent=\"";
    sstm<<(lbdm.xs+startall[0]-lbdm.bwid)<<" "<<(lbdm.xs+endall[0]-lbdm.bwid-1)<<" "
        <<(lbdm.ys+startall[1]-lbdm.bwid)<<" "<<(lbdm.ys+endall[1]-lbdm.bwid-1)<<" "
        <<((lbsy.nd==3)?(lbdm.zs+startall[2]-lbdm.bwid):0)<<" "<<((lbsy.nd==3)?(lbdm.zs+endall[2]-lbdm.bwid-1):0)<<"\">\n";
    sstm<<"<Piece Extent=\""
        <<(lbdm.xs+startall[0]-lbdm.bwid)<<" "<<(lbdm.xs+endall[0]-lbdm.bwid-1)<<" "
        <<(lbdm.ys+startall[1]-lbdm.bwid)<<" "<<(lbdm.ys+endall[1]-lbdm.bwid-1)<<" "
        <<((lbsy.nd==3)?(lbdm.zs+startall[2]-lbdm.bwid):0)<<" "<<((lbsy.nd==3)?(lbdm.zs+endall[2]-lbdm.bwid-1):0)<<"\">\n";

    sstm<<"<PointData Scalars=\"phase_field\" Vectors=\"velocity\">\n";

    // determine number of data points

    offset = 0;
    for(iprop=0; iprop<lbsy.nf; iprop++) {
      sstm<<"<DataArray Name=\"density_"<<iprop<<"\" type=\"Float32\" format=\"appended\" offset=\""<<offset<<"\">\n";
      offset += sizeof(float)*numberOfPointsAll + sizeof(unsigned int);
      sstm<<"</DataArray>\n";
    }
    for(iprop=0; iprop<lbsy.nf; iprop++) {
      sstm<<"<DataArray Name=\"fraction_"<<iprop<<"\" type=\"Float32\" format=\"appended\" offset=\""<<offset<<"\">\n";
      offset += sizeof(float)*numberOfPointsAll + sizeof(unsigned int);
      sstm<<"</DataArray>\n";
    }
    for(iprop=0; iprop<lbsy.nc; iprop++) {
      sstm<<"<DataArray Name=\"concentration_"<<iprop<<"\" type=\"Float32\" format=\"appended\" offset=\""<<offset<<"\">\n";
      offset += sizeof(float)*numberOfPointsAll + sizeof(unsigned int);
      sstm<<"</DataArray>\n";
    }
    if(lbsy.nt==1) {
      sstm<<"<DataArray Name=\"temperature\" type=\"Float32\" format=\"appended\" offset=\""<<offset<<"\">\n";
      offset += sizeof(float)*numberOfPointsAll + sizeof(unsigned int);
      sstm<<"</DataArray>\n";
    }
    sstm<<"<DataArray Name=\"velocity\" type=\"Float32\" NumberOfComponents=\"3\" format=\"appended\" offset=\""<<offset<<"\">\n";
    offset += 3*sizeof(float)*numberOfPointsAll + sizeof(unsigned int);
    sstm<<"</DataArray>\n";

    sstm<<"<DataArray Name=\"phase_field\" type=\"Int32\" format=\"appended\" offset=\""<<offset<<"\">\n";
    offset += sizeof(int)*numberOfPointsAll + sizeof(unsigned int);
    sstm<<"</DataArray>\n";
    sstm<<"</PointData>\n";
    sstm<<"<Points>\n";
    sstm<<"<DataArray type=\"Float32\" NumberOfComponents=\"3\" format=\"appended\" offset=\""<<offset<<"\">\n";
    sstm<<"</DataArray>\n";
    sstm<<"</Points>\n";
    sstm<<"</Piece>\n";
    sstm<<"</StructuredGrid>\n";

    sstm<<"<AppendedData encoding=\"raw\">\n";
    sstm<<"_";
  }
  header = sstm.str();
  headersize = header.length();
  footersize = 0;
  startpos = 0;
    
  // allocate buffers for collecting data

  scalarBuffer = (float*)malloc(numberOfPoints*sizeof(float));
  vectorBuffer = (float*)malloc(3*numberOfPoints*sizeof(float));
  intScalarBuffer = (int*)malloc(numberOfPoints*sizeof(int));

  // collect and write densities
    
  for(iprop=0; iprop<lbsy.nf; iprop++) {
    fGroupDensities(scalarBuffer, start, end, iprop, !bigend);
    fWriteVTKFloatBinaryData(scalarBuffer, numberOfPoints, startpos, header.c_str(), footer.c_str(), headersize, footersize, file);
    if(iprop==0) {
      header = "";
      headersize = 0;
    }
  }
    
  // collect and write mass fractions
    
  for(iprop=0; iprop<lbsy.nf; iprop++) {
    fGroupMassFractions(scalarBuffer, start, end, iprop, !bigend);
    fWriteVTKFloatBinaryData(scalarBuffer, numberOfPoints, startpos, header.c_str(), footer.c_str(), headersize, footersize, file);
  }
    
  // collect and write solute concentrations

  for(iprop=0; iprop<lbsy.nc; iprop++) {
    fGroupSoluteConcentrations(scalarBuffer, start, end, iprop, !bigend);
    fWriteVTKFloatBinaryData(scalarBuffer, numberOfPoints, startpos, header.c_str(), footer.c_str(), headersize, footersize, file);
  }
    
  // collect and write temperatures
    
  if(lbsy.nt==1) {
    fGroupTemperatures(scalarBuffer, start, end, !bigend);
    fWriteVTKFloatBinaryData(scalarBuffer, numberOfPoints, startpos, header.c_str(), footer.c_str(), headersize, footersize, file);
  }

  // collect and write velocities
    
  fGroupVelocities(vectorBuffer, start, end, !bigend);
  fWriteVTKFloatBinaryData(vectorBuffer, 3*numberOfPoints, startpos, header.c_str(), footer.c_str(), headersize, footersize, file);
    
  // collect and write phase field/space property

  fGroupPhaseField(intScalarBuffer, start, end, !bigend);
  fWriteVTKIntegerBinaryData(intScalarBuffer, numberOfPoints, startpos, header.c_str(), footer.c_str(), headersize, footersize, file);

  sstm.str(string());
  if((!lbmpiio && lbIOGroup.rank==0) || (lbmpiio && lbIOGroup.groupId==0)) {
    sstm<<"</AppendedData>\n";
    sstm<<"</VTKFile>\n";
  }
  footer = sstm.str();
  footersize = footer.length();
    
  // collect and write grid points

  fGroupGridPoints(vectorBuffer, start, end, !bigend);
  fWriteVTKFloatBinaryData(vectorBuffer, 3*numberOfPoints, startpos, header.c_str(), footer.c_str(), headersize, footersize, file);

  // close file and deallocate buffers

  fCloseOutputBinaryFile(file);

  free(scalarBuffer);
  free(vectorBuffer);
  free(intScalarBuffer);
  
  return 0;
}


int fsOutputVTK(const char* filename="lbout")
{
  int iprop;
  char buf[80];
  int numberOfPoints;
  int start[3], end[3], startall[3], endall[3], length[3];
  int* intScalarBuffer;
  float* scalarBuffer;
  float* vectorBuffer;
  ofstream file;
  stringstream sstm;
  string header,footer;
  unsigned long headersize,footersize,startpos;
    
  // find extent and number of points for I/O group
  fGroupPieceRangeLocal(start,end);
  if(!lbmpiio) {
    startall[0] = start[0];
    startall[1] = start[1];
    startall[2] = start[2];
    endall[0] = end[0];
    endall[1] = end[1];
    endall[2] = end[2];
  }
  else {
    startall[0] = startall[1] = lbdm.bwid;
    startall[2] = (lbsy.nd==3)?lbdm.bwid:0;
    endall[0] = lbsy.nx+lbdm.bwid;
    endall[1] = lbsy.ny+lbdm.bwid;
    endall[2] = (lbsy.nd==3)?(lbsy.nz+lbdm.bwid):1;
  }
  numberOfPoints = fGroupPieceDataPoints(length);

  // open file if root process for I/O group
  if(lbIOGroup.rank==0) {
    if(!lbmpiio && lbdm.size>lbIOGroup.size)
      sprintf(buf, "%s%.6dat%.6d.vts", filename, lbIOGroup.groupId, qVersion);
    else
      sprintf(buf, "%s%.6d.vts", filename, qVersion);
  }
  fOpenOutputANSIFile(buf, file);
    
  sstm.str(string());
  // write file header (with opening tags for grid points)
  if((!lbmpiio && lbIOGroup.rank==0) || (lbmpiio && lbIOGroup.groupId==0)) {
    sstm<<"<?xml version=\"1.0\"?>\n";
    sstm<<"<VTKFile type=\"StructuredGrid\" version=\"0.1\" byte_order=\"BigEndian\">\n";
    sstm<<"<StructuredGrid WholeExtent=\"";
    sstm<<(lbdm.xs+startall[0]-lbdm.bwid)<<" "<<(lbdm.xs+endall[0]-lbdm.bwid-1)<<" "
        <<(lbdm.ys+startall[1]-lbdm.bwid)<<" "<<(lbdm.ys+endall[1]-lbdm.bwid-1)<<" "
        <<((lbsy.nd==3)?(lbdm.zs+startall[2]-lbdm.bwid):0)<<" "<<((lbsy.nd==3)?(lbdm.zs+endall[2]-lbdm.bwid-1):0)<<"\">\n";
    sstm<<"<Piece Extent=\""
        <<(lbdm.xs+startall[0]-lbdm.bwid)<<" "<<(lbdm.xs+endall[0]-lbdm.bwid-1)<<" "
        <<(lbdm.ys+startall[1]-lbdm.bwid)<<" "<<(lbdm.ys+endall[1]-lbdm.bwid-1)<<" "
        <<((lbsy.nd==3)?(lbdm.zs+startall[2]-lbdm.bwid):0)<<" "<<((lbsy.nd==3)?(lbdm.zs+endall[2]-lbdm.bwid-1):0)<<"\">\n";
    sstm<<"<Points>\n";
    sstm<<"<DataArray type=\"Float32\" NumberOfComponents=\"3\" format=\"ascii\">\n";
  }
  startpos = 0;
  header = sstm.str();
  headersize = header.length();

  // allocate buffers for collecting data

  scalarBuffer = (float*)malloc(numberOfPoints*sizeof(float));
  vectorBuffer = (float*)malloc(3*numberOfPoints*sizeof(float));
  intScalarBuffer = (int*)malloc(numberOfPoints*sizeof(int));

  sstm.str(string());
  // write ending tags for grid points and tags for start of point data
  if((!lbmpiio && lbIOGroup.rank==0) || (lbmpiio && lbIOGroup.groupId==0)) {
    sstm<<"</DataArray>\n";
    sstm<<"</Points>\n";
    sstm<<"<PointData Scalars=\"density\" Vectors=\"velocity\">\n";
  }
  footer = sstm.str();
  footersize = footer.length();

  // collect and write grid points
    
  fGroupGridPoints(vectorBuffer, start, end, false);
  fWriteVTKFloatANSIData(vectorBuffer, 3*numberOfPoints, startpos, header.c_str(), footer.c_str(), headersize, footersize, file);
  
  // collect and write densities
    
  for(iprop=0; iprop<lbsy.nf; iprop++) {
    if((!lbmpiio && lbIOGroup.rank==0) || (lbmpiio && lbIOGroup.groupId==0)) {
      sstm.str(string());
      sstm<<"<DataArray Name=\"density_"<<iprop<<"\" type=\"Float32\" format=\"ascii\">\n";
      header = sstm.str();
      headersize = header.length();
      footer = "</DataArray>\n";
      footersize = footer.length();
    }
    fGroupDensities(scalarBuffer, start, end, iprop, false);
    fWriteVTKFloatANSIData(scalarBuffer, numberOfPoints, startpos, header.c_str(), footer.c_str(), headersize, footersize, file);
  }
  
  // collect and write mass fractions
    
  for(iprop=0; iprop<lbsy.nf; iprop++) {
    if((!lbmpiio && lbIOGroup.rank==0) || (lbmpiio && lbIOGroup.groupId==0)) {
      sstm.str(string());
      sstm<<"<DataArray Name=\"fraction_"<<iprop<<"\" type=\"Float32\" format=\"ascii\">\n";
      header = sstm.str();
      headersize = header.length();
      footer = "</DataArray>\n";
      footersize = footer.length();
    }
    fGroupMassFractions(scalarBuffer, start, end, iprop, false);
    fWriteVTKFloatANSIData(scalarBuffer, numberOfPoints, startpos, header.c_str(), footer.c_str(), headersize, footersize, file);
  }
  
  // collect and write solute concentrations
    
  for(iprop=0; iprop<lbsy.nc; iprop++) {
    if((!lbmpiio && lbIOGroup.rank==0) || (lbmpiio && lbIOGroup.groupId==0)) {
      sstm.str(string());
      sstm<<"<DataArray Name=\"concentration_"<<iprop<<"\" type=\"Float32\" format=\"ascii\">\n";
      header = sstm.str();
      headersize = header.length();
      footer = "</DataArray>\n";
      footersize = footer.length();
    }
    fGroupSoluteConcentrations(scalarBuffer, start, end, iprop, false);
    fWriteVTKFloatANSIData(scalarBuffer, numberOfPoints, startpos, header.c_str(), footer.c_str(), headersize, footersize, file);
  }
  
  // collect and write temperatures
    
  if(lbsy.nt==1) {
    if((!lbmpiio && lbIOGroup.rank==0) || (lbmpiio && lbIOGroup.groupId==0)) {
      sstm.str(string());
      sstm<<"<DataArray Name=\"temperature\" type=\"Float32\" format=\"ascii\">\n";
      header = sstm.str();
      headersize = header.length();
      footer = "</DataArray>\n";
      footersize = footer.length();
    }
    fGroupTemperatures(scalarBuffer, start, end, false);
    fWriteVTKFloatANSIData(scalarBuffer, numberOfPoints, startpos, header.c_str(), footer.c_str(), headersize, footersize, file);
  }

  // collect and write velocities

  if((!lbmpiio && lbIOGroup.rank==0) || (lbmpiio && lbIOGroup.groupId==0)) {
    sstm.str(string());
    sstm<<"<DataArray Name=\"velocity\" type=\"Float32\" NumberOfComponents=\"3\" format=\"ascii\">\n";
    header = sstm.str();
    headersize = header.length();
    footer = "</DataArray>\n";
    footersize = footer.length();
  }
  fGroupVelocities(vectorBuffer, start, end, false);
  fWriteVTKFloatANSIData(vectorBuffer, 3*numberOfPoints, startpos, header.c_str(), footer.c_str(), headersize, footersize, file);

  if((!lbmpiio && lbIOGroup.rank==0) || (lbmpiio && lbIOGroup.groupId==0)) {
    sstm.str(string());
    sstm<<"<DataArray Name=\"phase_field\" type=\"Int32\" format=\"ascii\">\n";
    header = sstm.str();
    headersize = header.length();
    sstm.str(string());
    sstm<<"</DataArray>\n";
    sstm<<"</PointData>\n";
    sstm<<"</Piece>\n";
    sstm<<"</StructuredGrid>\n";
    sstm<<"</VTKFile>\n";
    footer = sstm.str();
    footersize = footer.length();
  }

  // collect and write phase field/space property
    
  fGroupPhaseField(intScalarBuffer, start, end, false);
  fWriteVTKIntegerANSIData(intScalarBuffer, numberOfPoints, startpos, header.c_str(), footer.c_str(), headersize, footersize, file);

  // close file and deallocate buffers

  fCloseOutputANSIFile(file);
    
  free(scalarBuffer);
  free(vectorBuffer);
  free(intScalarBuffer);
    
  return 0;
}


int fOutputVTKP(const char* filename="lbout", int iprop=0)
{

  // output .vts file with macroscopic mass density and velocity for fluid iprop

  long offset;
  char buf[80];
  int numberOfPoints,numberOfPointsAll;
  int start[3], end[3], startall[3], endall[3], length[3];
  int* intScalarBuffer;
  float* scalarBuffer;
  float* vectorBuffer;
  ofstream file;
  stringstream sstm;
  string header,footer;
  unsigned long headersize,footersize,startpos;
    
  // find extent and number of points for I/O group
  fGroupPieceRangeLocal(start,end);
  if(!lbmpiio) {
    startall[0] = start[0];
    startall[1] = start[1];
    startall[2] = start[2];
    endall[0] = end[0];
    endall[1] = end[1];
    endall[2] = end[2];
  }
  else {
    startall[0] = startall[1] = lbdm.bwid;
    startall[2] = (lbsy.nd==3)?lbdm.bwid:0;
    endall[0] = lbsy.nx+lbdm.bwid;
    endall[1] = lbsy.ny+lbdm.bwid;
    endall[2] = (lbsy.nd==3)?(lbsy.nz+lbdm.bwid):1;
  }
  numberOfPoints = fGroupPieceDataPoints(length);
  numberOfPointsAll = (lbmpiio)?lbsy.nx*lbsy.ny*lbsy.nz:numberOfPoints;

  // open file if root process for I/O group
  if(lbIOGroup.rank==0) {
    if(!lbmpiio && lbdm.size>lbIOGroup.size)
      sprintf(buf, "%s%.6dat%.6d.vts", filename, lbIOGroup.groupId, qVersion);
    else
      sprintf(buf, "%s%.6d.vts", filename, qVersion);
  }
  fOpenOutputBinaryFile(buf, file);
    
  sstm.str(string());
  // write file header
  if((!lbmpiio && lbIOGroup.rank==0) || (lbmpiio && lbIOGroup.groupId==0)) {
    sstm<<"<?xml version=\"1.0\"?>\n";
    sstm<<"<VTKFile type=\"StructuredGrid\" version=\"0.1\" byte_order=\"BigEndian\">\n";
    sstm<<"<StructuredGrid WholeExtent=\"";
    sstm<<(lbdm.xs+startall[0]-lbdm.bwid)<<" "<<(lbdm.xs+endall[0]-lbdm.bwid-1)<<" "
        <<(lbdm.ys+startall[1]-lbdm.bwid)<<" "<<(lbdm.ys+endall[1]-lbdm.bwid-1)<<" "
        <<((lbsy.nd==3)?(lbdm.zs+startall[2]-lbdm.bwid):0)<<" "<<((lbsy.nd==3)?(lbdm.zs+endall[2]-lbdm.bwid-1):0)<<"\">\n";
    sstm<<"<Piece Extent=\""
        <<(lbdm.xs+startall[0]-lbdm.bwid)<<" "<<(lbdm.xs+endall[0]-lbdm.bwid-1)<<" "
        <<(lbdm.ys+startall[1]-lbdm.bwid)<<" "<<(lbdm.ys+endall[1]-lbdm.bwid-1)<<" "
        <<((lbsy.nd==3)?(lbdm.zs+startall[2]-lbdm.bwid):0)<<" "<<((lbsy.nd==3)?(lbdm.zs+endall[2]-lbdm.bwid-1):0)<<"\">\n";

    sstm<<"<PointData Scalars=\"phase_field\" Vectors=\"velocity\">\n";

    // determine number of data points

    offset = 0;
    sstm<<"<DataArray Name=\"density\" type=\"Float32\" format=\"appended\" offset=\""<<offset<<"\">\n";
    offset += sizeof(float)*numberOfPointsAll + sizeof(unsigned int);
    sstm<<"</DataArray>\n";
      
    sstm<<"<DataArray Name=\"velocity\" type=\"Float32\" NumberOfComponents=\"3\" format=\"appended\" offset=\""<<offset<<"\">\n";
    offset += 3*sizeof(float)*numberOfPointsAll + sizeof(unsigned int);
    sstm<<"</DataArray>\n";

    sstm<<"<DataArray Name=\"phase_field\" type=\"Int32\" format=\"appended\" offset=\""<<offset<<"\">\n";
    offset += sizeof(int)*numberOfPointsAll + sizeof(unsigned int);
    sstm<<"</DataArray>\n";
    sstm<<"</PointData>\n";
    sstm<<"<Points>\n";
    sstm<<"<DataArray type=\"Float32\" NumberOfComponents=\"3\" format=\"appended\" offset=\""<<offset<<"\">\n";
    sstm<<"</DataArray>\n";
    sstm<<"</Points>\n";
    sstm<<"</Piece>\n";
    sstm<<"</StructuredGrid>\n";

    sstm<<"<AppendedData encoding=\"raw\">\n";
    sstm<<"_";
  }
  header = sstm.str();
  headersize = header.length();
  footersize = 0;
  startpos = 0;
    
  // allocate buffers for collecting data

  scalarBuffer = (float*)malloc(numberOfPoints*sizeof(float));
  vectorBuffer = (float*)malloc(3*numberOfPoints*sizeof(float));
  intScalarBuffer = (int*)malloc(numberOfPoints*sizeof(int));

  // collect and write density
    
  fGroupDensities(scalarBuffer, start, end, iprop, !bigend);
  fWriteVTKFloatBinaryData(scalarBuffer, numberOfPoints, startpos, header.c_str(), footer.c_str(), headersize, footersize, file);
  header = "";
  headersize = 0;
    
  // collect and write velocities
    
  fGroupVelocities(vectorBuffer, start, end, !bigend);
  fWriteVTKFloatBinaryData(vectorBuffer, 3*numberOfPoints, startpos, header.c_str(), footer.c_str(), headersize, footersize, file);
    
  // collect and write phase field/space property

  fGroupPhaseField(intScalarBuffer, start, end, !bigend);
  fWriteVTKIntegerBinaryData(intScalarBuffer, numberOfPoints, startpos, header.c_str(), footer.c_str(), headersize, footersize, file);

  sstm.str(string());
  if((!lbmpiio && lbIOGroup.rank==0) || (lbmpiio && lbIOGroup.groupId==0)) {
    sstm<<"</AppendedData>\n";
    sstm<<"</VTKFile>\n";
  }
  footer = sstm.str();
  footersize = footer.length();
    
  // collect and write grid points

  fGroupGridPoints(vectorBuffer, start, end, !bigend);
  fWriteVTKFloatBinaryData(vectorBuffer, 3*numberOfPoints, startpos, header.c_str(), footer.c_str(), headersize, footersize, file);

  // close file and deallocate buffers

  fCloseOutputBinaryFile(file);

  free(scalarBuffer);
  free(vectorBuffer);
  free(intScalarBuffer);
  
  return 0;
}


int fsOutputVTKP(const char* filename="lbout", int iprop=0)
{
  char buf[80];
  int numberOfPoints;
  int start[3], end[3], startall[3], endall[3], length[3];
  int* intScalarBuffer;
  float* scalarBuffer;
  float* vectorBuffer;
  ofstream file;
  stringstream sstm;
  string header,footer;
  unsigned long headersize,footersize,startpos;
    
  // find extent and number of points for I/O group
  fGroupPieceRangeLocal(start,end);
  if(!lbmpiio) {
    startall[0] = start[0];
    startall[1] = start[1];
    startall[2] = start[2];
    endall[0] = end[0];
    endall[1] = end[1];
    endall[2] = end[2];
  }
  else {
    startall[0] = startall[1] = lbdm.bwid;
    startall[2] = (lbsy.nd==3)?lbdm.bwid:0;
    endall[0] = lbsy.nx+lbdm.bwid;
    endall[1] = lbsy.ny+lbdm.bwid;
    endall[2] = (lbsy.nd==3)?(lbsy.nz+lbdm.bwid):1;
  }
  numberOfPoints = fGroupPieceDataPoints(length);

  // open file if root process for I/O group
  if(lbIOGroup.rank==0) {
    if(!lbmpiio && lbdm.size>lbIOGroup.size)
      sprintf(buf, "%s%.6dat%.6d.vts", filename, lbIOGroup.groupId, qVersion);
    else
      sprintf(buf, "%s%.6d.vts", filename, qVersion);
  }
  fOpenOutputANSIFile(buf, file);
    
  sstm.str(string());
  // write file header (with opening tags for grid points)
  if((!lbmpiio && lbIOGroup.rank==0) || (lbmpiio && lbIOGroup.groupId==0)) {
    sstm<<"<?xml version=\"1.0\"?>\n";
    sstm<<"<VTKFile type=\"StructuredGrid\" version=\"0.1\" byte_order=\"BigEndian\">\n";
    sstm<<"<StructuredGrid WholeExtent=\"";
    sstm<<(lbdm.xs+startall[0]-lbdm.bwid)<<" "<<(lbdm.xs+endall[0]-lbdm.bwid-1)<<" "
        <<(lbdm.ys+startall[1]-lbdm.bwid)<<" "<<(lbdm.ys+endall[1]-lbdm.bwid-1)<<" "
        <<((lbsy.nd==3)?(lbdm.zs+startall[2]-lbdm.bwid):0)<<" "<<((lbsy.nd==3)?(lbdm.zs+endall[2]-lbdm.bwid-1):0)<<"\">\n";
    sstm<<"<Piece Extent=\""
        <<(lbdm.xs+startall[0]-lbdm.bwid)<<" "<<(lbdm.xs+endall[0]-lbdm.bwid-1)<<" "
        <<(lbdm.ys+startall[1]-lbdm.bwid)<<" "<<(lbdm.ys+endall[1]-lbdm.bwid-1)<<" "
        <<((lbsy.nd==3)?(lbdm.zs+startall[2]-lbdm.bwid):0)<<" "<<((lbsy.nd==3)?(lbdm.zs+endall[2]-lbdm.bwid-1):0)<<"\">\n";
    sstm<<"<Points>\n";
    sstm<<"<DataArray type=\"Float32\" NumberOfComponents=\"3\" format=\"ascii\">\n";
  }
  startpos = 0;
  header = sstm.str();
  headersize = header.length();

  // allocate buffers for collecting data

  scalarBuffer = (float*)malloc(numberOfPoints*sizeof(float));
  vectorBuffer = (float*)malloc(3*numberOfPoints*sizeof(float));
  intScalarBuffer = (int*)malloc(numberOfPoints*sizeof(int));

  sstm.str(string());
  // write ending tags for grid points and tags for start of point data
  if((!lbmpiio && lbIOGroup.rank==0) || (lbmpiio && lbIOGroup.groupId==0)) {
    sstm<<"</DataArray>\n";
    sstm<<"</Points>\n";
    sstm<<"<PointData Scalars=\"density\" Vectors=\"velocity\">\n";
  }
  footer = sstm.str();
  footersize = footer.length();

  // collect and write grid points
    
  fGroupGridPoints(vectorBuffer, start, end, false);
  fWriteVTKFloatANSIData(vectorBuffer, 3*numberOfPoints, startpos, header.c_str(), footer.c_str(), headersize, footersize, file);

  // collect and write densities
    
  if((!lbmpiio && lbIOGroup.rank==0) || (lbmpiio && lbIOGroup.groupId==0)) {
    sstm.str(string());
    sstm<<"<DataArray Name=\"density\" type=\"Float32\" format=\"ascii\">\n";
    header = sstm.str();
    headersize = header.length();
    footer = "</DataArray>\n";
    footersize = footer.length();
  }
  fGroupDensities(scalarBuffer, start, end, iprop, false);
  fWriteVTKFloatANSIData(scalarBuffer, numberOfPoints, startpos, header.c_str(), footer.c_str(), headersize, footersize, file);
  
  // collect and write velocities

  if((!lbmpiio && lbIOGroup.rank==0) || (lbmpiio && lbIOGroup.groupId==0)) {
    sstm.str(string());
    sstm<<"<DataArray Name=\"velocity\" type=\"Float32\" NumberOfComponents=\"3\" format=\"ascii\">\n";
    header = sstm.str();
    headersize = header.length();
    footer = "</DataArray>\n";
    footersize = footer.length();
  }
  fGroupVelocities(vectorBuffer, start, end, false);
  fWriteVTKFloatANSIData(vectorBuffer, 3*numberOfPoints, startpos, header.c_str(), footer.c_str(), headersize, footersize, file);

  if((!lbmpiio && lbIOGroup.rank==0) || (lbmpiio && lbIOGroup.groupId==0)) {
    sstm.str(string());
    sstm<<"<DataArray Name=\"phase_field\" type=\"Int32\" format=\"ascii\">\n";
    header = sstm.str();
    headersize = header.length();
    sstm.str(string());
    sstm<<"</DataArray>\n";
    sstm<<"</PointData>\n";
    sstm<<"</Piece>\n";
    sstm<<"</StructuredGrid>\n";
    sstm<<"</VTKFile>\n";
    footer = sstm.str();
    footersize = footer.length();
  }

  // collect and write phase field/space property
    
  fGroupPhaseField(intScalarBuffer, start, end, false);
  fWriteVTKIntegerANSIData(intScalarBuffer, numberOfPoints, startpos, header.c_str(), footer.c_str(), headersize, footersize, file);

  // close file and deallocate buffers

  fCloseOutputANSIFile(file);
    
  free(scalarBuffer);
  free(vectorBuffer);
  free(intScalarBuffer);
    
  return 0;
}


int fOutputVTKCA(const char* filename="lbout", int iprop=0)
{

  // output .vts file with mass fraction and velocity for fluid iprop

  long offset;
  char buf[80];
  int numberOfPoints,numberOfPointsAll;
  int start[3], end[3], startall[3], endall[3], length[3];
  int* intScalarBuffer;
  float* scalarBuffer;
  float* vectorBuffer;
  ofstream file;
  stringstream sstm;
  string header,footer;
  unsigned long headersize,footersize,startpos;
    
  // find extent and number of points for I/O group
  fGroupPieceRangeLocal(start,end);
  if(!lbmpiio) {
    startall[0] = start[0];
    startall[1] = start[1];
    startall[2] = start[2];
    endall[0] = end[0];
    endall[1] = end[1];
    endall[2] = end[2];
  }
  else {
    startall[0] = startall[1] = lbdm.bwid;
    startall[2] = (lbsy.nd==3)?lbdm.bwid:0;
    endall[0] = lbsy.nx+lbdm.bwid;
    endall[1] = lbsy.ny+lbdm.bwid;
    endall[2] = (lbsy.nd==3)?(lbsy.nz+lbdm.bwid):1;
  }
  numberOfPoints = fGroupPieceDataPoints(length);
  numberOfPointsAll = (lbmpiio)?lbsy.nx*lbsy.ny*lbsy.nz:numberOfPoints;

  // open file if root process for I/O group
  if(lbIOGroup.rank==0) {
    if(!lbmpiio && lbdm.size>lbIOGroup.size)
      sprintf(buf, "%s%.6dat%.6d.vts", filename, lbIOGroup.groupId, qVersion);
    else
      sprintf(buf, "%s%.6d.vts", filename, qVersion);
  }
  fOpenOutputBinaryFile(buf, file);
    
  sstm.str(string());
  // write file header
  if((!lbmpiio && lbIOGroup.rank==0) || (lbmpiio && lbIOGroup.groupId==0)) {
    sstm<<"<?xml version=\"1.0\"?>\n";
    sstm<<"<VTKFile type=\"StructuredGrid\" version=\"0.1\" byte_order=\"BigEndian\">\n";
    sstm<<"<StructuredGrid WholeExtent=\"";
    sstm<<(lbdm.xs+startall[0]-lbdm.bwid)<<" "<<(lbdm.xs+endall[0]-lbdm.bwid-1)<<" "
        <<(lbdm.ys+startall[1]-lbdm.bwid)<<" "<<(lbdm.ys+endall[1]-lbdm.bwid-1)<<" "
        <<((lbsy.nd==3)?(lbdm.zs+startall[2]-lbdm.bwid):0)<<" "<<((lbsy.nd==3)?(lbdm.zs+endall[2]-lbdm.bwid-1):0)<<"\">\n";
    sstm<<"<Piece Extent=\""
        <<(lbdm.xs+startall[0]-lbdm.bwid)<<" "<<(lbdm.xs+endall[0]-lbdm.bwid-1)<<" "
        <<(lbdm.ys+startall[1]-lbdm.bwid)<<" "<<(lbdm.ys+endall[1]-lbdm.bwid-1)<<" "
        <<((lbsy.nd==3)?(lbdm.zs+startall[2]-lbdm.bwid):0)<<" "<<((lbsy.nd==3)?(lbdm.zs+endall[2]-lbdm.bwid-1):0)<<"\">\n";

    sstm<<"<PointData Scalars=\"phase_field\" Vectors=\"velocity\">\n";

    // determine number of data points

    offset = 0;
    sstm<<"<DataArray Name=\"fraction\" type=\"Float32\" format=\"appended\" offset=\""<<offset<<"\">\n";
    offset += sizeof(float)*numberOfPointsAll + sizeof(unsigned int);
    sstm<<"</DataArray>\n";
      
    sstm<<"<DataArray Name=\"velocity\" type=\"Float32\" NumberOfComponents=\"3\" format=\"appended\" offset=\""<<offset<<"\">\n";
    offset += 3*sizeof(float)*numberOfPointsAll + sizeof(unsigned int);
    sstm<<"</DataArray>\n";

    sstm<<"<DataArray Name=\"phase_field\" type=\"Int32\" format=\"appended\" offset=\""<<offset<<"\">\n";
    offset += sizeof(int)*numberOfPointsAll + sizeof(unsigned int);
    sstm<<"</DataArray>\n";
    sstm<<"</PointData>\n";
    sstm<<"<Points>\n";
    sstm<<"<DataArray type=\"Float32\" NumberOfComponents=\"3\" format=\"appended\" offset=\""<<offset<<"\">\n";
    sstm<<"</DataArray>\n";
    sstm<<"</Points>\n";
    sstm<<"</Piece>\n";
    sstm<<"</StructuredGrid>\n";

    sstm<<"<AppendedData encoding=\"raw\">\n";
    sstm<<"_";
  }
  header = sstm.str();
  headersize = header.length();
  footersize = 0;
  startpos = 0;
    
  // allocate buffers for collecting data

  scalarBuffer = (float*)malloc(numberOfPoints*sizeof(float));
  vectorBuffer = (float*)malloc(3*numberOfPoints*sizeof(float));
  intScalarBuffer = (int*)malloc(numberOfPoints*sizeof(int));

  // collect and write mass fraction
    
  fGroupMassFractions(scalarBuffer, start, end, iprop, !bigend);
  fWriteVTKFloatBinaryData(scalarBuffer, numberOfPoints, startpos, header.c_str(), footer.c_str(), headersize, footersize, file);
  header = "";
  headersize = 0;
    
  // collect and write velocities
    
  fGroupVelocities(vectorBuffer, start, end, !bigend);
  fWriteVTKFloatBinaryData(vectorBuffer, 3*numberOfPoints, startpos, header.c_str(), footer.c_str(), headersize, footersize, file);
    
  // collect and write phase field/space property

  fGroupPhaseField(intScalarBuffer, start, end, !bigend);
  fWriteVTKIntegerBinaryData(intScalarBuffer, numberOfPoints, startpos, header.c_str(), footer.c_str(), headersize, footersize, file);

  sstm.str(string());
  if((!lbmpiio && lbIOGroup.rank==0) || (lbmpiio && lbIOGroup.groupId==0)) {
    sstm<<"</AppendedData>\n";
    sstm<<"</VTKFile>\n";
  }
  footer = sstm.str();
  footersize = footer.length();
    
  // collect and write grid points

  fGroupGridPoints(vectorBuffer, start, end, !bigend);
  fWriteVTKFloatBinaryData(vectorBuffer, 3*numberOfPoints, startpos, header.c_str(), footer.c_str(), headersize, footersize, file);

  // close file and deallocate buffers

  fCloseOutputBinaryFile(file);

  free(scalarBuffer);
  free(vectorBuffer);
  free(intScalarBuffer);
  
  return 0;
}


int fsOutputVTKCA(const char* filename="lbout", int iprop=0)
{
  char buf[80];
  int numberOfPoints;
  int start[3], end[3], startall[3], endall[3], length[3];
  int* intScalarBuffer;
  float* scalarBuffer;
  float* vectorBuffer;
  ofstream file;
  stringstream sstm;
  string header,footer;
  unsigned long headersize,footersize,startpos;
    
  // find extent and number of points for I/O group
  fGroupPieceRangeLocal(start,end);
  if(!lbmpiio) {
    startall[0] = start[0];
    startall[1] = start[1];
    startall[2] = start[2];
    endall[0] = end[0];
    endall[1] = end[1];
    endall[2] = end[2];
  }
  else {
    startall[0] = startall[1] = lbdm.bwid;
    startall[2] = (lbsy.nd==3)?lbdm.bwid:0;
    endall[0] = lbsy.nx+lbdm.bwid;
    endall[1] = lbsy.ny+lbdm.bwid;
    endall[2] = (lbsy.nd==3)?(lbsy.nz+lbdm.bwid):1;
  }
  numberOfPoints = fGroupPieceDataPoints(length);

  // open file if root process for I/O group
  if(lbIOGroup.rank==0) {
    if(!lbmpiio && lbdm.size>lbIOGroup.size)
      sprintf(buf, "%s%.6dat%.6d.vts", filename, lbIOGroup.groupId, qVersion);
    else
      sprintf(buf, "%s%.6d.vts", filename, qVersion);
  }
  fOpenOutputANSIFile(buf, file);
    
  sstm.str(string());
  // write file header (with opening tags for grid points)
  if((!lbmpiio && lbIOGroup.rank==0) || (lbmpiio && lbIOGroup.groupId==0)) {
    sstm<<"<?xml version=\"1.0\"?>\n";
    sstm<<"<VTKFile type=\"StructuredGrid\" version=\"0.1\" byte_order=\"BigEndian\">\n";
    sstm<<"<StructuredGrid WholeExtent=\"";
    sstm<<(lbdm.xs+startall[0]-lbdm.bwid)<<" "<<(lbdm.xs+endall[0]-lbdm.bwid-1)<<" "
        <<(lbdm.ys+startall[1]-lbdm.bwid)<<" "<<(lbdm.ys+endall[1]-lbdm.bwid-1)<<" "
        <<((lbsy.nd==3)?(lbdm.zs+startall[2]-lbdm.bwid):0)<<" "<<((lbsy.nd==3)?(lbdm.zs+endall[2]-lbdm.bwid-1):0)<<"\">\n";
    sstm<<"<Piece Extent=\""
        <<(lbdm.xs+startall[0]-lbdm.bwid)<<" "<<(lbdm.xs+endall[0]-lbdm.bwid-1)<<" "
        <<(lbdm.ys+startall[1]-lbdm.bwid)<<" "<<(lbdm.ys+endall[1]-lbdm.bwid-1)<<" "
        <<((lbsy.nd==3)?(lbdm.zs+startall[2]-lbdm.bwid):0)<<" "<<((lbsy.nd==3)?(lbdm.zs+endall[2]-lbdm.bwid-1):0)<<"\">\n";
    sstm<<"<Points>\n";
    sstm<<"<DataArray type=\"Float32\" NumberOfComponents=\"3\" format=\"ascii\">\n";
  }
  startpos = 0;
  header = sstm.str();
  headersize = header.length();

  // allocate buffers for collecting data

  scalarBuffer = (float*)malloc(numberOfPoints*sizeof(float));
  vectorBuffer = (float*)malloc(3*numberOfPoints*sizeof(float));
  intScalarBuffer = (int*)malloc(numberOfPoints*sizeof(int));

  sstm.str(string());
  // write ending tags for grid points and tags for start of point data
  if((!lbmpiio && lbIOGroup.rank==0) || (lbmpiio && lbIOGroup.groupId==0)) {
    sstm<<"</DataArray>\n";
    sstm<<"</Points>\n";
    sstm<<"<PointData Scalars=\"fraction\" Vectors=\"velocity\">\n";
  }
  footer = sstm.str();
  footersize = footer.length();

  // collect and write grid points
    
  fGroupGridPoints(vectorBuffer, start, end, false);
  fWriteVTKFloatANSIData(vectorBuffer, 3*numberOfPoints, startpos, header.c_str(), footer.c_str(), headersize, footersize, file);

  // collect and write mass fractions
    
  if((!lbmpiio && lbIOGroup.rank==0) || (lbmpiio && lbIOGroup.groupId==0)) {
    sstm.str(string());
    sstm<<"<DataArray Name=\"fraction\" type=\"Float32\" format=\"ascii\">\n";
    header = sstm.str();
    headersize = header.length();
    footer = "</DataArray>\n";
    footersize = footer.length();
  }
  fGroupMassFractions(scalarBuffer, start, end, iprop, false);
  fWriteVTKFloatANSIData(scalarBuffer, numberOfPoints, startpos, header.c_str(), footer.c_str(), headersize, footersize, file);
  
  // collect and write velocities

  if((!lbmpiio && lbIOGroup.rank==0) || (lbmpiio && lbIOGroup.groupId==0)) {
    sstm.str(string());
    sstm<<"<DataArray Name=\"velocity\" type=\"Float32\" NumberOfComponents=\"3\" format=\"ascii\">\n";
    header = sstm.str();
    headersize = header.length();
    footer = "</DataArray>\n";
    footersize = footer.length();
  }
  fGroupVelocities(vectorBuffer, start, end, false);
  fWriteVTKFloatANSIData(vectorBuffer, 3*numberOfPoints, startpos, header.c_str(), footer.c_str(), headersize, footersize, file);

  if((!lbmpiio && lbIOGroup.rank==0) || (lbmpiio && lbIOGroup.groupId==0)) {
    sstm.str(string());
    sstm<<"<DataArray Name=\"phase_field\" type=\"Int32\" format=\"ascii\">\n";
    header = sstm.str();
    headersize = header.length();
    sstm.str(string());
    sstm<<"</DataArray>\n";
    sstm<<"</PointData>\n";
    sstm<<"</Piece>\n";
    sstm<<"</StructuredGrid>\n";
    sstm<<"</VTKFile>\n";
    footer = sstm.str();
    footersize = footer.length();
  }

  // collect and write phase field/space property
    
  fGroupPhaseField(intScalarBuffer, start, end, false);
  fWriteVTKIntegerANSIData(intScalarBuffer, numberOfPoints, startpos, header.c_str(), footer.c_str(), headersize, footersize, file);

  // close file and deallocate buffers

  fCloseOutputANSIFile(file);
    
  free(scalarBuffer);
  free(vectorBuffer);
  free(intScalarBuffer);
    
  return 0;
}


int fOutputVTKCB(const char* filename="lbout", int iprop=0)
{
  // output .vts file with concentration and velocity for solute iprop

  long offset;
  char buf[80];
  int numberOfPoints,numberOfPointsAll;
  int start[3], end[3], startall[3], endall[3], length[3];
  int* intScalarBuffer;
  float* scalarBuffer;
  float* vectorBuffer;
  ofstream file;
  stringstream sstm;
  string header,footer;
  unsigned long headersize,footersize,startpos;
    
  // find extent and number of points for I/O group
  fGroupPieceRangeLocal(start,end);
  if(!lbmpiio) {
    startall[0] = start[0];
    startall[1] = start[1];
    startall[2] = start[2];
    endall[0] = end[0];
    endall[1] = end[1];
    endall[2] = end[2];
  }
  else {
    startall[0] = startall[1] = lbdm.bwid;
    startall[2] = (lbsy.nd==3)?lbdm.bwid:0;
    endall[0] = lbsy.nx+lbdm.bwid;
    endall[1] = lbsy.ny+lbdm.bwid;
    endall[2] = (lbsy.nd==3)?(lbsy.nz+lbdm.bwid):1;
  }
  numberOfPoints = fGroupPieceDataPoints(length);
  numberOfPointsAll = (lbmpiio)?lbsy.nx*lbsy.ny*lbsy.nz:numberOfPoints;

  // open file if root process for I/O group
  if(lbIOGroup.rank==0) {
    if(!lbmpiio && lbdm.size>lbIOGroup.size)
      sprintf(buf, "%s%.6dat%.6d.vts", filename, lbIOGroup.groupId, qVersion);
    else
      sprintf(buf, "%s%.6d.vts", filename, qVersion);
  }
  fOpenOutputBinaryFile(buf, file);
    
  sstm.str(string());
  // write file header
  if((!lbmpiio && lbIOGroup.rank==0) || (lbmpiio && lbIOGroup.groupId==0)) {
    sstm<<"<?xml version=\"1.0\"?>\n";
    sstm<<"<VTKFile type=\"StructuredGrid\" version=\"0.1\" byte_order=\"BigEndian\">\n";
    sstm<<"<StructuredGrid WholeExtent=\"";
    sstm<<(lbdm.xs+startall[0]-lbdm.bwid)<<" "<<(lbdm.xs+endall[0]-lbdm.bwid-1)<<" "
        <<(lbdm.ys+startall[1]-lbdm.bwid)<<" "<<(lbdm.ys+endall[1]-lbdm.bwid-1)<<" "
        <<((lbsy.nd==3)?(lbdm.zs+startall[2]-lbdm.bwid):0)<<" "<<((lbsy.nd==3)?(lbdm.zs+endall[2]-lbdm.bwid-1):0)<<"\">\n";
    sstm<<"<Piece Extent=\""
        <<(lbdm.xs+startall[0]-lbdm.bwid)<<" "<<(lbdm.xs+endall[0]-lbdm.bwid-1)<<" "
        <<(lbdm.ys+startall[1]-lbdm.bwid)<<" "<<(lbdm.ys+endall[1]-lbdm.bwid-1)<<" "
        <<((lbsy.nd==3)?(lbdm.zs+startall[2]-lbdm.bwid):0)<<" "<<((lbsy.nd==3)?(lbdm.zs+endall[2]-lbdm.bwid-1):0)<<"\">\n";

    sstm<<"<PointData Scalars=\"phase_field\" Vectors=\"velocity\">\n";

    // determine number of data points

    offset = 0;
    sstm<<"<DataArray Name=\"concentration\" type=\"Float32\" format=\"appended\" offset=\""<<offset<<"\">\n";
    offset += sizeof(float)*numberOfPointsAll + sizeof(unsigned int);
    sstm<<"</DataArray>\n";
      
    sstm<<"<DataArray Name=\"velocity\" type=\"Float32\" NumberOfComponents=\"3\" format=\"appended\" offset=\""<<offset<<"\">\n";
    offset += 3*sizeof(float)*numberOfPointsAll + sizeof(unsigned int);
    sstm<<"</DataArray>\n";

    sstm<<"<DataArray Name=\"phase_field\" type=\"Int32\" format=\"appended\" offset=\""<<offset<<"\">\n";
    offset += sizeof(int)*numberOfPointsAll + sizeof(unsigned int);
    sstm<<"</DataArray>\n";
    sstm<<"</PointData>\n";
    sstm<<"<Points>\n";
    sstm<<"<DataArray type=\"Float32\" NumberOfComponents=\"3\" format=\"appended\" offset=\""<<offset<<"\">\n";
    sstm<<"</DataArray>\n";
    sstm<<"</Points>\n";
    sstm<<"</Piece>\n";
    sstm<<"</StructuredGrid>\n";

    sstm<<"<AppendedData encoding=\"raw\">\n";
    sstm<<"_";
  }
  header = sstm.str();
  headersize = header.length();
  footersize = 0;
  startpos = 0;
    
  // allocate buffers for collecting data

  scalarBuffer = (float*)malloc(numberOfPoints*sizeof(float));
  vectorBuffer = (float*)malloc(3*numberOfPoints*sizeof(float));
  intScalarBuffer = (int*)malloc(numberOfPoints*sizeof(int));

  // collect and write solute concentration
    
  fGroupSoluteConcentrations(scalarBuffer, start, end, iprop, !bigend);
  fWriteVTKFloatBinaryData(scalarBuffer, numberOfPoints, startpos, header.c_str(), footer.c_str(), headersize, footersize, file);
  header = "";
  headersize = 0;
    
  // collect and write velocities
    
  fGroupVelocities(vectorBuffer, start, end, !bigend);
  fWriteVTKFloatBinaryData(vectorBuffer, 3*numberOfPoints, startpos, header.c_str(), footer.c_str(), headersize, footersize, file);
    
  // collect and write phase field/space property

  fGroupPhaseField(intScalarBuffer, start, end, !bigend);
  fWriteVTKIntegerBinaryData(intScalarBuffer, numberOfPoints, startpos, header.c_str(), footer.c_str(), headersize, footersize, file);

  sstm.str(string());
  if((!lbmpiio && lbIOGroup.rank==0) || (lbmpiio && lbIOGroup.groupId==0)) {
    sstm<<"</AppendedData>\n";
    sstm<<"</VTKFile>\n";
  }
  footer = sstm.str();
  footersize = footer.length();
    
  // collect and write grid points

  fGroupGridPoints(vectorBuffer, start, end, !bigend);
  fWriteVTKFloatBinaryData(vectorBuffer, 3*numberOfPoints, startpos, header.c_str(), footer.c_str(), headersize, footersize, file);

  // close file and deallocate buffers

  fCloseOutputBinaryFile(file);

  free(scalarBuffer);
  free(vectorBuffer);
  free(intScalarBuffer);
  
  return 0;
}


int fsOutputVTKCB(const char* filename="lbout", int iprop=0)
{
  char buf[80];
  int numberOfPoints;
  int start[3], end[3], startall[3], endall[3], length[3];
  int* intScalarBuffer;
  float* scalarBuffer;
  float* vectorBuffer;
  ofstream file;
  stringstream sstm;
  string header,footer;
  unsigned long headersize,footersize,startpos;
    
  // find extent and number of points for I/O group
  fGroupPieceRangeLocal(start,end);
  if(!lbmpiio) {
    startall[0] = start[0];
    startall[1] = start[1];
    startall[2] = start[2];
    endall[0] = end[0];
    endall[1] = end[1];
    endall[2] = end[2];
  }
  else {
    startall[0] = startall[1] = lbdm.bwid;
    startall[2] = (lbsy.nd==3)?lbdm.bwid:0;
    endall[0] = lbsy.nx+lbdm.bwid;
    endall[1] = lbsy.ny+lbdm.bwid;
    endall[2] = (lbsy.nd==3)?(lbsy.nz+lbdm.bwid):1;
  }
  numberOfPoints = fGroupPieceDataPoints(length);

  // open file if root process for I/O group
  if(lbIOGroup.rank==0) {
    if(!lbmpiio && lbdm.size>lbIOGroup.size)
      sprintf(buf, "%s%.6dat%.6d.vts", filename, lbIOGroup.groupId, qVersion);
    else
      sprintf(buf, "%s%.6d.vts", filename, qVersion);
  }
  fOpenOutputANSIFile(buf, file);
    
  sstm.str(string());
  // write file header (with opening tags for grid points)
  if((!lbmpiio && lbIOGroup.rank==0) || (lbmpiio && lbIOGroup.groupId==0)) {
    sstm<<"<?xml version=\"1.0\"?>\n";
    sstm<<"<VTKFile type=\"StructuredGrid\" version=\"0.1\" byte_order=\"BigEndian\">\n";
    sstm<<"<StructuredGrid WholeExtent=\"";
    sstm<<(lbdm.xs+startall[0]-lbdm.bwid)<<" "<<(lbdm.xs+endall[0]-lbdm.bwid-1)<<" "
        <<(lbdm.ys+startall[1]-lbdm.bwid)<<" "<<(lbdm.ys+endall[1]-lbdm.bwid-1)<<" "
        <<((lbsy.nd==3)?(lbdm.zs+startall[2]-lbdm.bwid):0)<<" "<<((lbsy.nd==3)?(lbdm.zs+endall[2]-lbdm.bwid-1):0)<<"\">\n";
    sstm<<"<Piece Extent=\""
        <<(lbdm.xs+startall[0]-lbdm.bwid)<<" "<<(lbdm.xs+endall[0]-lbdm.bwid-1)<<" "
        <<(lbdm.ys+startall[1]-lbdm.bwid)<<" "<<(lbdm.ys+endall[1]-lbdm.bwid-1)<<" "
        <<((lbsy.nd==3)?(lbdm.zs+startall[2]-lbdm.bwid):0)<<" "<<((lbsy.nd==3)?(lbdm.zs+endall[2]-lbdm.bwid-1):0)<<"\">\n";
    sstm<<"<Points>\n";
    sstm<<"<DataArray type=\"Float32\" NumberOfComponents=\"3\" format=\"ascii\">\n";
  }
  startpos = 0;
  header = sstm.str();
  headersize = header.length();

  // allocate buffers for collecting data

  scalarBuffer = (float*)malloc(numberOfPoints*sizeof(float));
  vectorBuffer = (float*)malloc(3*numberOfPoints*sizeof(float));
  intScalarBuffer = (int*)malloc(numberOfPoints*sizeof(int));

  sstm.str(string());
  // write ending tags for grid points and tags for start of point data
  if((!lbmpiio && lbIOGroup.rank==0) || (lbmpiio && lbIOGroup.groupId==0)) {
    sstm<<"</DataArray>\n";
    sstm<<"</Points>\n";
    sstm<<"<PointData Scalars=\"concentration\" Vectors=\"velocity\">\n";
  }
  footer = sstm.str();
  footersize = footer.length();

  // collect and write grid points
    
  fGroupGridPoints(vectorBuffer, start, end, false);
  fWriteVTKFloatANSIData(vectorBuffer, 3*numberOfPoints, startpos, header.c_str(), footer.c_str(), headersize, footersize, file);

  // collect and write solute concentrations
    
  if((!lbmpiio && lbIOGroup.rank==0) || (lbmpiio && lbIOGroup.groupId==0)) {
    sstm.str(string());
    sstm<<"<DataArray Name=\"concentration\" type=\"Float32\" format=\"ascii\">\n";
    header = sstm.str();
    headersize = header.length();
    footer = "</DataArray>\n";
    footersize = footer.length();
  }
  fGroupSoluteConcentrations(scalarBuffer, start, end, iprop, false);
  fWriteVTKFloatANSIData(scalarBuffer, numberOfPoints, startpos, header.c_str(), footer.c_str(), headersize, footersize, file);
  
  // collect and write velocities

  if((!lbmpiio && lbIOGroup.rank==0) || (lbmpiio && lbIOGroup.groupId==0)) {
    sstm.str(string());
    sstm<<"<DataArray Name=\"velocity\" type=\"Float32\" NumberOfComponents=\"3\" format=\"ascii\">\n";
    header = sstm.str();
    headersize = header.length();
    footer = "</DataArray>\n";
    footersize = footer.length();
  }
  fGroupVelocities(vectorBuffer, start, end, false);
  fWriteVTKFloatANSIData(vectorBuffer, 3*numberOfPoints, startpos, header.c_str(), footer.c_str(), headersize, footersize, file);

  if((!lbmpiio && lbIOGroup.rank==0) || (lbmpiio && lbIOGroup.groupId==0)) {
    sstm.str(string());
    sstm<<"<DataArray Name=\"phase_field\" type=\"Int32\" format=\"ascii\">\n";
    header = sstm.str();
    headersize = header.length();
    sstm.str(string());
    sstm<<"</DataArray>\n";
    sstm<<"</PointData>\n";
    sstm<<"</Piece>\n";
    sstm<<"</StructuredGrid>\n";
    sstm<<"</VTKFile>\n";
    footer = sstm.str();
    footersize = footer.length();
  }

  // collect and write phase field/space property
    
  fGroupPhaseField(intScalarBuffer, start, end, false);
  fWriteVTKIntegerANSIData(intScalarBuffer, numberOfPoints, startpos, header.c_str(), footer.c_str(), headersize, footersize, file);

  // close file and deallocate buffers

  fCloseOutputANSIFile(file);
    
  free(scalarBuffer);
  free(vectorBuffer);
  free(intScalarBuffer);
    
  return 0;
}


int fOutputVTKT(const char* filename="lbout")
{

  // output .vts file with scalar temperature and velocity

  long offset;
  char buf[80];
  int numberOfPoints,numberOfPointsAll;
  int start[3], end[3], startall[3], endall[3], length[3];
  int* intScalarBuffer;
  float* scalarBuffer;
  float* vectorBuffer;
  ofstream file;
  stringstream sstm;
  string header,footer;
  unsigned long headersize,footersize,startpos;
    
  // find extent and number of points for I/O group
  fGroupPieceRangeLocal(start,end);
  if(!lbmpiio) {
    startall[0] = start[0];
    startall[1] = start[1];
    startall[2] = start[2];
    endall[0] = end[0];
    endall[1] = end[1];
    endall[2] = end[2];
  }
  else {
    startall[0] = startall[1] = lbdm.bwid;
    startall[2] = (lbsy.nd==3)?lbdm.bwid:0;
    endall[0] = lbsy.nx+lbdm.bwid;
    endall[1] = lbsy.ny+lbdm.bwid;
    endall[2] = (lbsy.nd==3)?(lbsy.nz+lbdm.bwid):1;
  }
  numberOfPoints = fGroupPieceDataPoints(length);
  numberOfPointsAll = (lbmpiio)?lbsy.nx*lbsy.ny*lbsy.nz:numberOfPoints;

  // open file if root process for I/O group
  if(lbIOGroup.rank==0) {
    if(!lbmpiio && lbdm.size>lbIOGroup.size)
      sprintf(buf, "%s%.6dat%.6d.vts", filename, lbIOGroup.groupId, qVersion);
    else
      sprintf(buf, "%s%.6d.vts", filename, qVersion);
  }
  fOpenOutputBinaryFile(buf, file);
    
  sstm.str(string());
  // write file header
  if((!lbmpiio && lbIOGroup.rank==0) || (lbmpiio && lbIOGroup.groupId==0)) {
    sstm<<"<?xml version=\"1.0\"?>\n";
    sstm<<"<VTKFile type=\"StructuredGrid\" version=\"0.1\" byte_order=\"BigEndian\">\n";
    sstm<<"<StructuredGrid WholeExtent=\"";
    sstm<<(lbdm.xs+startall[0]-lbdm.bwid)<<" "<<(lbdm.xs+endall[0]-lbdm.bwid-1)<<" "
        <<(lbdm.ys+startall[1]-lbdm.bwid)<<" "<<(lbdm.ys+endall[1]-lbdm.bwid-1)<<" "
        <<((lbsy.nd==3)?(lbdm.zs+startall[2]-lbdm.bwid):0)<<" "<<((lbsy.nd==3)?(lbdm.zs+endall[2]-lbdm.bwid-1):0)<<"\">\n";
    sstm<<"<Piece Extent=\""
        <<(lbdm.xs+startall[0]-lbdm.bwid)<<" "<<(lbdm.xs+endall[0]-lbdm.bwid-1)<<" "
        <<(lbdm.ys+startall[1]-lbdm.bwid)<<" "<<(lbdm.ys+endall[1]-lbdm.bwid-1)<<" "
        <<((lbsy.nd==3)?(lbdm.zs+startall[2]-lbdm.bwid):0)<<" "<<((lbsy.nd==3)?(lbdm.zs+endall[2]-lbdm.bwid-1):0)<<"\">\n";

    sstm<<"<PointData Scalars=\"phase_field\" Vectors=\"velocity\">\n";

    // determine number of data points

    offset = 0;
    sstm<<"<DataArray Name=\"temperature\" type=\"Float32\" format=\"appended\" offset=\""<<offset<<"\">\n";
    offset += sizeof(float)*numberOfPointsAll + sizeof(unsigned int);
    sstm<<"</DataArray>\n";
      
    sstm<<"<DataArray Name=\"velocity\" type=\"Float32\" NumberOfComponents=\"3\" format=\"appended\" offset=\""<<offset<<"\">\n";
    offset += 3*sizeof(float)*numberOfPointsAll + sizeof(unsigned int);
    sstm<<"</DataArray>\n";

    sstm<<"<DataArray Name=\"phase_field\" type=\"Int32\" format=\"appended\" offset=\""<<offset<<"\">\n";
    offset += sizeof(int)*numberOfPointsAll + sizeof(unsigned int);
    sstm<<"</DataArray>\n";
    sstm<<"</PointData>\n";
    sstm<<"<Points>\n";
    sstm<<"<DataArray type=\"Float32\" NumberOfComponents=\"3\" format=\"appended\" offset=\""<<offset<<"\">\n";
    sstm<<"</DataArray>\n";
    sstm<<"</Points>\n";
    sstm<<"</Piece>\n";
    sstm<<"</StructuredGrid>\n";

    sstm<<"<AppendedData encoding=\"raw\">\n";
    sstm<<"_";
  }
  header = sstm.str();
  headersize = header.length();
  footersize = 0;
  startpos = 0;
    
  // allocate buffers for collecting data

  scalarBuffer = (float*)malloc(numberOfPoints*sizeof(float));
  vectorBuffer = (float*)malloc(3*numberOfPoints*sizeof(float));
  intScalarBuffer = (int*)malloc(numberOfPoints*sizeof(int));

  // collect and write temperatures
    
  fGroupTemperatures(scalarBuffer, start, end, !bigend);
  fWriteVTKFloatBinaryData(scalarBuffer, numberOfPoints, startpos, header.c_str(), footer.c_str(), headersize, footersize, file);
  header = "";
  headersize = 0;
    
  // collect and write velocities
    
  fGroupVelocities(vectorBuffer, start, end, !bigend);
  fWriteVTKFloatBinaryData(vectorBuffer, 3*numberOfPoints, startpos, header.c_str(), footer.c_str(), headersize, footersize, file);
    
  // collect and write phase field/space property

  fGroupPhaseField(intScalarBuffer, start, end, !bigend);
  fWriteVTKIntegerBinaryData(intScalarBuffer, numberOfPoints, startpos, header.c_str(), footer.c_str(), headersize, footersize, file);

  sstm.str(string());
  if((!lbmpiio && lbIOGroup.rank==0) || (lbmpiio && lbIOGroup.groupId==0)) {
    sstm<<"</AppendedData>\n";
    sstm<<"</VTKFile>\n";
  }
  footer = sstm.str();
  footersize = footer.length();
    
  // collect and write grid points

  fGroupGridPoints(vectorBuffer, start, end, !bigend);
  fWriteVTKFloatBinaryData(vectorBuffer, 3*numberOfPoints, startpos, header.c_str(), footer.c_str(), headersize, footersize, file);

  // close file and deallocate buffers

  fCloseOutputBinaryFile(file);

  free(scalarBuffer);
  free(vectorBuffer);
  free(intScalarBuffer);
  
  return 0;
}


int fsOutputVTKT(const char* filename="lbout")
{
  char buf[80];
  int numberOfPoints;
  int start[3], end[3], startall[3], endall[3], length[3];
  int* intScalarBuffer;
  float* scalarBuffer;
  float* vectorBuffer;
  ofstream file;
  stringstream sstm;
  string header,footer;
  unsigned long headersize,footersize,startpos;
    
  // find extent and number of points for I/O group
  fGroupPieceRangeLocal(start,end);
  if(!lbmpiio) {
    startall[0] = start[0];
    startall[1] = start[1];
    startall[2] = start[2];
    endall[0] = end[0];
    endall[1] = end[1];
    endall[2] = end[2];
  }
  else {
    startall[0] = startall[1] = lbdm.bwid;
    startall[2] = (lbsy.nd==3)?lbdm.bwid:0;
    endall[0] = lbsy.nx+lbdm.bwid;
    endall[1] = lbsy.ny+lbdm.bwid;
    endall[2] = (lbsy.nd==3)?(lbsy.nz+lbdm.bwid):1;
  }
  numberOfPoints = fGroupPieceDataPoints(length);

  // open file if root process for I/O group
  if(lbIOGroup.rank==0) {
    if(!lbmpiio && lbdm.size>lbIOGroup.size)
      sprintf(buf, "%s%.6dat%.6d.vts", filename, lbIOGroup.groupId, qVersion);
    else
      sprintf(buf, "%s%.6d.vts", filename, qVersion);
  }
  fOpenOutputANSIFile(buf, file);
    
  sstm.str(string());
  // write file header (with opening tags for grid points)
  if((!lbmpiio && lbIOGroup.rank==0) || (lbmpiio && lbIOGroup.groupId==0)) {
    sstm<<"<?xml version=\"1.0\"?>\n";
    sstm<<"<VTKFile type=\"StructuredGrid\" version=\"0.1\" byte_order=\"BigEndian\">\n";
    sstm<<"<StructuredGrid WholeExtent=\"";
    sstm<<(lbdm.xs+startall[0]-lbdm.bwid)<<" "<<(lbdm.xs+endall[0]-lbdm.bwid-1)<<" "
        <<(lbdm.ys+startall[1]-lbdm.bwid)<<" "<<(lbdm.ys+endall[1]-lbdm.bwid-1)<<" "
        <<((lbsy.nd==3)?(lbdm.zs+startall[2]-lbdm.bwid):0)<<" "<<((lbsy.nd==3)?(lbdm.zs+endall[2]-lbdm.bwid-1):0)<<"\">\n";
    sstm<<"<Piece Extent=\""
        <<(lbdm.xs+startall[0]-lbdm.bwid)<<" "<<(lbdm.xs+endall[0]-lbdm.bwid-1)<<" "
        <<(lbdm.ys+startall[1]-lbdm.bwid)<<" "<<(lbdm.ys+endall[1]-lbdm.bwid-1)<<" "
        <<((lbsy.nd==3)?(lbdm.zs+startall[2]-lbdm.bwid):0)<<" "<<((lbsy.nd==3)?(lbdm.zs+endall[2]-lbdm.bwid-1):0)<<"\">\n";
    sstm<<"<Points>\n";
    sstm<<"<DataArray type=\"Float32\" NumberOfComponents=\"3\" format=\"ascii\">\n";
  }
  startpos = 0;
  header = sstm.str();
  headersize = header.length();

  // allocate buffers for collecting data

  scalarBuffer = (float*)malloc(numberOfPoints*sizeof(float));
  vectorBuffer = (float*)malloc(3*numberOfPoints*sizeof(float));
  intScalarBuffer = (int*)malloc(numberOfPoints*sizeof(int));

  sstm.str(string());
  // write ending tags for grid points and tags for start of point data
  if((!lbmpiio && lbIOGroup.rank==0) || (lbmpiio && lbIOGroup.groupId==0)) {
    sstm<<"</DataArray>\n";
    sstm<<"</Points>\n";
    sstm<<"<PointData Scalars=\"temperature\" Vectors=\"velocity\">\n";
  }
  footer = sstm.str();
  footersize = footer.length();

  // collect and write grid points
    
  fGroupGridPoints(vectorBuffer, start, end, false);
  fWriteVTKFloatANSIData(vectorBuffer, 3*numberOfPoints, startpos, header.c_str(), footer.c_str(), headersize, footersize, file);

  // collect and write temperatures
    
  if((!lbmpiio && lbIOGroup.rank==0) || (lbmpiio && lbIOGroup.groupId==0)) {
    sstm.str(string());
    sstm<<"<DataArray Name=\"temperature\" type=\"Float32\" format=\"ascii\">\n";
    header = sstm.str();
    headersize = header.length();
    footer = "</DataArray>\n";
    footersize = footer.length();
  }
  fGroupTemperatures(scalarBuffer, start, end, false);
  fWriteVTKFloatANSIData(scalarBuffer, numberOfPoints, startpos, header.c_str(), footer.c_str(), headersize, footersize, file);
  
  // collect and write velocities

  if((!lbmpiio && lbIOGroup.rank==0) || (lbmpiio && lbIOGroup.groupId==0)) {
    sstm.str(string());
    sstm<<"<DataArray Name=\"velocity\" type=\"Float32\" NumberOfComponents=\"3\" format=\"ascii\">\n";
    header = sstm.str();
    headersize = header.length();
    footer = "</DataArray>\n";
    footersize = footer.length();
  }
  fGroupVelocities(vectorBuffer, start, end, false);
  fWriteVTKFloatANSIData(vectorBuffer, 3*numberOfPoints, startpos, header.c_str(), footer.c_str(), headersize, footersize, file);

  if((!lbmpiio && lbIOGroup.rank==0) || (lbmpiio && lbIOGroup.groupId==0)) {
    sstm.str(string());
    sstm<<"<DataArray Name=\"phase_field\" type=\"Int32\" format=\"ascii\">\n";
    header = sstm.str();
    headersize = header.length();
    sstm.str(string());
    sstm<<"</DataArray>\n";
    sstm<<"</PointData>\n";
    sstm<<"</Piece>\n";
    sstm<<"</StructuredGrid>\n";
    sstm<<"</VTKFile>\n";
    footer = sstm.str();
    footersize = footer.length();
  }

  // collect and write phase field/space property
    
  fGroupPhaseField(intScalarBuffer, start, end, false);
  fWriteVTKIntegerANSIData(intScalarBuffer, numberOfPoints, startpos, header.c_str(), footer.c_str(), headersize, footersize, file);

  // close file and deallocate buffers

  fCloseOutputANSIFile(file);
    
  free(scalarBuffer);
  free(vectorBuffer);
  free(intScalarBuffer);
    
  return 0;
}

