import javax.swing.*;
import java.util.*;
import java.lang.*;
import java.io.*;
import java.awt.*;
import java.awt.event.*;
import java.awt.geom.*;
import java.awt.image.*;
/*
 *     DL_MESO_GUI
 *     author: M. A. Seaton - from code by R. S. Qin
 *     copyright: UKRI STFC Daresbury Laboratory and CCP5
 *     2005, 2018
 */
class setdpdInteract extends JPanel {

    /*
      DL_MESO_GUI 
      Set DPD interactions and molecules
      Author    :   M. A. Seaton
      Copyright :   STFC Daresbury Laboratory              
      Control Panel  
    */
    
    setdpdInteractEvt dpdinteract=new setdpdInteractEvt(this);

    Font font=new Font("Dialog", Font.BOLD, 13);
    Color bgcolor=new Color(170, 200, 190);
    Color focolor=new Color(10, 10, 15);
    Color paneltop=new Color(170, 170, 230);

    JLabel compiled=new JLabel("<html>Prior compilation of molecule-generate<br/>utility required</html>", JLabel.RIGHT);
    JLabel numspecies=new JLabel("number of species:", JLabel.RIGHT);
    JLabel exterforce=new JLabel("external force:", JLabel.RIGHT);
    JLabel textedit=new JLabel("text editor:", JLabel.RIGHT);

    JSpinner species=new JSpinner(new SpinnerNumberModel(1, 1, 10, 1));
    JComboBox<String> external=new JComboBox<String>();
    JComboBox<String> editor=new JComboBox<String>();
    JTextField otheredit=new JTextField();

    JButton setspecies = new JButton("set species");
    JButton setinteract = new JButton("set interactions");
    JButton createmolecule = new JButton("create molecules");
    JButton exterparam = new JButton("set parameters");
    JButton editfile = new JButton("edit FIELD file");

    JButton openfield = new JButton("OPEN");
    JButton savefield = new JButton("SAVE");
    
    public setdpdInteract() {
	setSize(620, 530);
        JPanel panel1 = new JPanel();
        panel1.setLayout(new GridBagLayout());
	
        setspecies.setFont(font);
        addItem(panel1, numspecies, 0, 0, 1, 1, GridBagConstraints.WEST);
        compiled.setFont(font);
        addItem(panel1, compiled, 0, 3, 2, 1, GridBagConstraints.CENTER);
        exterforce.setFont(font);
        addItem(panel1, exterforce, 0, 6, 1, 1, GridBagConstraints.WEST);
        textedit.setFont(font);
        addItem(panel1, textedit, 0, 8, 1, 1, GridBagConstraints.WEST);

        addItem(panel1, species, 1, 0, 1, 1, GridBagConstraints.WEST);

        external.addItem("none");
        external.addItem("gravity");
        external.addItem("linear shear");
        external.addItem("electric field");
        external.setFont(font);
        external.addItemListener(dpdinteract);
        addItemFill(panel1, external, 1, 6, 1, 1, GridBagConstraints.CENTER, GridBagConstraints.HORIZONTAL);

        editor.addItem("dlmesoEditor");
        editor.addItem("emacs");
        editor.addItem("vi");
        editor.addItem("notepad");
        editor.addItem("other ...");
        editor.setFont(font);
        editor.addItemListener(dpdinteract);
        editor.setEnabled(false);
        addItemFill(panel1, editor, 1, 8, 1, 1, GridBagConstraints.CENTER, GridBagConstraints.HORIZONTAL);
        otheredit.setEnabled(false);
        addItemFill(panel1, otheredit, 1, 9, 1, 1, GridBagConstraints.CENTER, GridBagConstraints.HORIZONTAL);

        JSeparator sep1 = new JSeparator(JSeparator.HORIZONTAL);
        addItemFillSep(panel1, sep1, 2, GridBagConstraints.HORIZONTAL);

        JSeparator sep2 = new JSeparator(JSeparator.HORIZONTAL);
        addItemFillSep(panel1, sep2, 5, GridBagConstraints.HORIZONTAL);

        JSeparator sep3 = new JSeparator(JSeparator.HORIZONTAL);
        addItemFillSep(panel1, sep3, 7, GridBagConstraints.HORIZONTAL);

        setspecies.setFont(font);
        setspecies.addActionListener(dpdinteract);
        addItemFill(panel1, setspecies, 2, 0, 1, 1, GridBagConstraints.WEST, GridBagConstraints.HORIZONTAL);

        setinteract.setFont(font);
        setinteract.addActionListener(dpdinteract);
        addItemFill(panel1, setinteract, 2, 1, 1, 1, GridBagConstraints.WEST, GridBagConstraints.HORIZONTAL);

        createmolecule.setFont(font);
        createmolecule.setEnabled(true);
        createmolecule.addActionListener(dpdinteract);
        addItemFill(panel1, createmolecule, 2, 3, 1, 1, GridBagConstraints.WEST, GridBagConstraints.HORIZONTAL);

        exterparam.setFont(font);
        exterparam.setEnabled(true);
        exterparam.addActionListener(dpdinteract);
        addItemFill(panel1, exterparam, 2, 6, 1, 1, GridBagConstraints.WEST, GridBagConstraints.HORIZONTAL);

        editfile.setFont(font);
        editfile.setEnabled(false);
        editfile.addActionListener(dpdinteract);
        addItemFill(panel1, editfile, 2, 8, 1, 1, GridBagConstraints.WEST, GridBagConstraints.HORIZONTAL);

        Box buttonbox = Box.createHorizontalBox();
        openfield.setFont(font);
        openfield.setBackground(bgcolor);
        openfield.addActionListener(dpdinteract);
        savefield.setFont(font);
        savefield.setBackground(bgcolor);
        savefield.addActionListener(dpdinteract);
        buttonbox.add(openfield);
        buttonbox.add(savefield);
        addItemPadding(panel1, buttonbox, 0, 10, 3, 1, GridBagConstraints.CENTER, 20);

        this.add(panel1);
    }

    private void addItem(JPanel p, JComponent c, int x, int y, int width, int height, int align)
    {
        GridBagConstraints gc = new GridBagConstraints();
        gc.gridx = x;
        gc.gridy = y;
        gc.gridwidth = width;
        gc.gridheight = height;
        gc.weightx = 100.0;
        gc.weighty = 100.0;
        gc.insets = new Insets(5, 5, 5, 5);
        gc.anchor = align;
        gc.fill = GridBagConstraints.NONE;
        p.add(c, gc);
    }

    private void addItemFill(JPanel p, JComponent c, int x, int y, int width, int height, int align, int fill)
    {
        GridBagConstraints gc = new GridBagConstraints();
        gc.gridx = x;
        gc.gridy = y;
        gc.gridwidth = width;
        gc.gridheight = height;
        gc.weightx = 100.0;
        gc.weighty = 100.0;
        gc.insets = new Insets(5, 5, 5, 5);
        gc.anchor = align;
        gc.fill = fill;
        p.add(c, gc);
    }

    private void addItemFillSep(JPanel p, JComponent c, int y, int fill)
    {
        GridBagConstraints gc = new GridBagConstraints();
        gc.gridx = 0;
        gc.gridy = y;
        gc.gridwidth = 5;
        gc.gridheight = 1;
        gc.weightx = 1;
        gc.weighty = 1;
        gc.insets = new Insets(5, 5, 5, 5);
        gc.anchor = GridBagConstraints.CENTER;
        gc.fill = fill;
        p.add(c, gc);
    }

    private void addItemPadding(JPanel p, JComponent c, int x, int y, int width, int height, int align, int padding)
    {
        GridBagConstraints gc = new GridBagConstraints();
        gc.gridx = x;
        gc.gridy = y;
        gc.gridwidth = width;
        gc.gridheight = height;
        gc.weightx = 100.0;
        gc.weighty = 100.0;
        gc.insets = new Insets(padding, padding, padding, padding);
        gc.anchor = align;
        gc.fill = GridBagConstraints.NONE;
        p.add(c, gc);
    }

}
