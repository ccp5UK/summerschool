#include "slbe.hpp"

int main(int argc, char* argv[])
{
  bigend = fBigEndian();
  fDefineSystem();
  fSetSerialDomain();
  fStartDLMESO();
  fMemoryAllocation();
  fGetModel();
  fPrintSystemInfo();
  fsPrintDomainInfo();
  fInputParameters();
  fPrintParameters();
  fReadSpaceParameter();
  fsCreateIOGroups();
  fNeighbourBoundary();
  fInitializeSystem();               // assuming no restart for this simulation
  fReadInitialState();
  if(outformat==2)                   // Grid for Plot3D output files
    fsOutputGrid(); 
  if(interact==1 || interact==2)
    fCalcPotential_ShanChen();
  timetotal=fCheckTimeSerial();
  for(lbcurstep=0; lbcurstep<= lbtotstep; lbcurstep++) {
    if(i%lbsave  == 0) {
      fsOutputVTKP();                // Substitute with required file type and/or output
      qVersion++;
      cout << lbcurstep << " \t ";
      fPrintDomainMass();
      fPrintDomainMomentum();
    }
    fInteractionForceZero();         // Remove if no Boussinesq forces or mesophase interactions used
    fCalcPotential_ShanChen();       // Substitute with required potential/phase index/density/concentration gradients
                                     // (or remove if no mesophase interactions required)
    fsInteractionForceShanChen();    // Substitute with required mesophase interactions and/or add additional forces
    switch (nonnewtonian) {          // Remove this switch block if only simple Newtonian fluids are in use
      case 1:
        fGetSystemOmegaSimple();
        break;
      case 2:
        fGetSystemOmega();
        break;
    }
    fCollisionBGK();                 // Substitute with required collision and forcing algorithm
    fPostCollBoundary();
    fPropagationSwap();
    fPostPropBoundary();
  }
  timetotal=fCheckTimeSerial();
  fFreeMemory();
  fFinishDLMESO();
  return 0;
}

    
