#include <iostream>
#include <iomanip>
#include <fstream>
#include <string>
#include <cstring>
#include <cstdlib>
#include <stdio.h>
#include <sys/stat.h>
using namespace std;
int outtype,numfluid,numsolute,numtemp;

/**************************************************
 *   DL_MESO       Version 2.7                    *
 *   Authors   :   R. S. Qin, M. A. Seaton        *
 *   Copyright :   UKRI STFC Daresbury Laboratory *
 *             :   09/12/2018                     *
 **************************************************/

class cGatherData
{

  // creates initialization file (lbin.init) from restart file (lbout.dump) to
  // allow new simulation from result of a previous one
    
public:

  cGatherData()
    {

      getsize();
      writeinit();

    }

  ~cGatherData()
    {

    }

  int getsize();
  int writeinit();

protected:

  int nd;
  int nq;
  int nx, ny, nz;
  int nf, nc, nt, pf;
  int lbsitelength;
  int incompress;
  double* lbincp;
  double* lbvx;
  double* lbvy;
  double* lbvz;
  unsigned long inheader, outheader;
  int bigend;

};

void quickSortIndexed(unsigned long *arr, unsigned long *index, unsigned long len);

int cGatherData::getsize()
{

  int buffer[12];

  ifstream file("lbout.dump", ios::binary);

  if(!file) {
    cout<<"error opening "<<"lbout.dump"<<" file\n";
    exit(1);
  }

  file.read((char*)buffer, 12*sizeof(int));

  // read in required properties for creating initialization file
    
  nd         = buffer[0];
  nq         = buffer[1];
  nx         = buffer[2];
  ny         = buffer[3];
  nz         = buffer[4];
  nf         = buffer[5];
  nc         = buffer[6];
  nt         = buffer[7];
  pf         = buffer[8];
  incompress = buffer[11];

  // allocate arrays for constant densities and lattice links
    
  lbincp = new double[nf];
  lbvx = new double[nq];
  lbvy = new double[nq];
  lbvz = new double[nq];
    
  // read constant densities for incompressible fluid simulations (if needed)
  
  if(incompress>0)
    file.read((char*)lbincp, nf*sizeof(double));

  lbsitelength = nq * (nf+nc+nt) + pf;

  // assign lattice link vectors based on scheme

  switch (nq) {
    case 9: // D2Q9
      lbvx[0]=0;    lbvy[0]=0;    lbvz[0]=0;
      lbvx[1]=-1;   lbvy[1]=1;    lbvz[1]=0;
      lbvx[2]=-1;   lbvy[2]=0;    lbvz[2]=0;
      lbvx[3]=-1;   lbvy[3]=-1;   lbvz[3]=0;
      lbvx[4]=0;    lbvy[4]=-1;   lbvz[4]=0;
      lbvx[5]=1;    lbvy[5]=-1;   lbvz[5]=0;
      lbvx[6]=1;    lbvy[6]=0;    lbvz[6]=0;
      lbvx[7]=1;    lbvy[7]=1;    lbvz[7]=0;
      lbvx[8]=0;    lbvy[8]=1;    lbvz[8]=0;
      break;
    case 15: // D3Q15
      lbvx[0]=0;    lbvy[0]=0;    lbvz[0]=0;
      lbvx[1]=-1;   lbvy[1]=0;    lbvz[1]=0;
      lbvx[2]=0;    lbvy[2]=-1;   lbvz[2]=0;
      lbvx[3]=0;    lbvy[3]=0;    lbvz[3]=-1;
      lbvx[4]=-1;   lbvy[4]=-1;   lbvz[4]=-1;
      lbvx[5]=-1;   lbvy[5]=-1;   lbvz[5]=1;
      lbvx[6]=-1;   lbvy[6]=1;    lbvz[6]=-1;
      lbvx[7]=-1;   lbvy[7]=1;    lbvz[7]=1;
      lbvx[8]=1;    lbvy[8]=0;    lbvz[8]=0;
      lbvx[9]=0;    lbvy[9]=1;    lbvz[9]=0;
      lbvx[10]=0;   lbvy[10]=0;   lbvz[10]=1;
      lbvx[11]=1;   lbvy[11]=1;   lbvz[11]=1;
      lbvx[12]=1;   lbvy[12]=1;   lbvz[12]=-1;
      lbvx[13]=1;   lbvy[13]=-1;  lbvz[13]=1;
      lbvx[14]=1;   lbvy[14]=-1;  lbvz[14]=-1;
      break;
    case 19: // D3Q19
      lbvx[0]=0;    lbvy[0]=0;    lbvz[0]=0;
      lbvx[1]=-1;   lbvy[1]=0;    lbvz[1]=0;
      lbvx[2]=0;    lbvy[2]=-1;   lbvz[2]=0;
      lbvx[3]=0;    lbvy[3]=0;    lbvz[3]=-1;
      lbvx[4]=-1;   lbvy[4]=-1;   lbvz[4]=0;
      lbvx[5]=-1;   lbvy[5]=1;    lbvz[5]=0;
      lbvx[6]=-1;   lbvy[6]=0;    lbvz[6]=-1;
      lbvx[7]=-1;   lbvy[7]=0;    lbvz[7]=1;
      lbvx[8]=0;    lbvy[8]=-1;   lbvz[8]=-1;
      lbvx[9]=0;    lbvy[9]=-1;   lbvz[9]=1;
      lbvx[10]=1;   lbvy[10]=0;   lbvz[10]=0;
      lbvx[11]=0;   lbvy[11]=1;   lbvz[11]=0;
      lbvx[12]=0;   lbvy[12]=0;   lbvz[12]=1;
      lbvx[13]=1;   lbvy[13]=1;   lbvz[13]=0;
      lbvx[14]=1;   lbvy[14]=-1;  lbvz[14]=0;
      lbvx[15]=1;   lbvy[15]=0;   lbvz[15]=1;
      lbvx[16]=1;   lbvy[16]=0;   lbvz[16]=-1;
      lbvx[17]=0;   lbvy[17]=1;   lbvz[17]=1;
      lbvx[18]=0;   lbvy[18]=1;   lbvz[18]=-1;
      break;
    case 27: // D3Q27
      lbvx[0]=0;    lbvy[0]=0;    lbvz[0]=0;
      lbvx[1]=-1;   lbvy[1]=0;    lbvz[1]=0;
      lbvx[2]=0;    lbvy[2]=-1;   lbvz[2]=0;
      lbvx[3]=0;    lbvy[3]=0;    lbvz[3]=-1;
      lbvx[4]=-1;   lbvy[4]=-1;   lbvz[4]=0;
      lbvx[5]=-1;   lbvy[5]=1;    lbvz[5]=0;
      lbvx[6]=-1;   lbvy[6]=0;    lbvz[6]=-1;
      lbvx[7]=-1;   lbvy[7]=0;    lbvz[7]=1;
      lbvx[8]=0;    lbvy[8]=-1;   lbvz[8]=-1;
      lbvx[9]=0;    lbvy[9]=-1;   lbvz[9]=1;
      lbvx[10]=-1;  lbvy[10]=-1;  lbvz[10]=-1;
      lbvx[11]=-1;  lbvy[11]=-1;  lbvz[11]=1;
      lbvx[12]=-1;  lbvy[12]=1;   lbvz[12]=-1;
      lbvx[13]=-1;  lbvy[13]=1;   lbvz[13]=1;
      lbvx[14]=1;   lbvy[14]=0;   lbvz[14]=0;
      lbvx[15]=0;   lbvy[15]=1;   lbvz[15]=0;
      lbvx[16]=0;   lbvy[16]=0;   lbvz[16]=1;
      lbvx[17]=1;   lbvy[17]=1;   lbvz[17]=0;
      lbvx[18]=1;   lbvy[18]=-1;  lbvz[18]=0;
      lbvx[19]=1;   lbvy[19]=0;   lbvz[19]=1;
      lbvx[20]=1;   lbvy[20]=0;   lbvz[20]=-1;
      lbvx[21]=0;   lbvy[21]=1;   lbvz[21]=1;
      lbvx[22]=0;   lbvy[22]=1;   lbvz[22]=-1;
      lbvx[23]=1;   lbvy[23]=1;   lbvz[23]=1;
      lbvx[24]=1;   lbvy[24]=1;   lbvz[24]=-1;
      lbvx[25]=1;   lbvy[25]=-1;  lbvz[25]=1;
      lbvx[26]=1;   lbvy[26]=-1;  lbvz[26]=-1;
      break;
  }

  // note where the header ends and close file
    
  inheader = file.tellg();
  file.close();

  cout << "Creating lbin.init file from lbout.dump file at timestep " << buffer[9] << endl;

  return 0;
  
}


int cGatherData::writeinit()
{
  unsigned long inpos,ilpos;
  ifstream infile("lbout.dump", ios::binary);
  ofstream outfile("lbin.init");
  unsigned long* posil;
  unsigned long* posindex;
  double databuf[lbsitelength],rho[nf],conc[nc],v[3];
  double temp,mass0,rmass0,px,py,pz;
  int ipos[3];
  int qdim = nf+nc+nt;
  long datalength = nx*ny*nz;

  // read in positions and work out order required for writing data
  // (applying quicksort while preserving original indices)

  posil    = new unsigned long[datalength];
  posindex = new unsigned long[datalength];
  for(long il=0; il<datalength; il++) {
    inpos = inheader + 3*sizeof(int)*il;
    infile.seekg(inpos, ios::beg);
    infile.read((char*)ipos, 3*sizeof(int));
    posil[il] = ipos[0] + nx*(ipos[1] + ny*ipos[2]);
    posindex[il] = il;
  }
  quickSortIndexed(posil, posindex, datalength);

  // run through each point in order of writing (in iteration speed order x -> y -> z),
  // find distribution functions for given point and calculate required properties
    
  for(long il=0; il<datalength; il++) {
    // grid point
    if(nd==3) {
      ipos[0] = il % nx;
      ipos[2] = il / (nx*ny);
      ipos[1] = (il % (nx*ny)) / nx;
    }
    else {
      ipos[0] = il % nx;
      ipos[1] = il / nx;
      ipos[2] = 0;
    }
    ilpos = posindex[il];
    inpos = inheader + 3*sizeof(int)*datalength + (lbsitelength+nf)*sizeof(double)*ilpos;
    infile.seekg(inpos, ios::beg);
    infile.read((char*)databuf, lbsitelength*sizeof(double));
    mass0=0.0; px=0.0; py=0.0; pz=0.0;
    // work out densities and fluid velocity
    for(int i=0; i<nf; i++) {
      rho[i] = 0.0;
      for(int m=0; m<nq; m++) {
        rho[i] += databuf[m*qdim+i];
        px += databuf[m*qdim+i]*lbvx[m];
        py += databuf[m*qdim+i]*lbvy[m];
        pz += databuf[m*qdim+i]*lbvz[m];
      }
      mass0 += ((incompress)?lbincp[i]:rho[i]);
    }
    if(mass0>0.0)
      rmass0 = 1.0/mass0;
    else
      rmass0 = 0.0;
    v[0] = px*rmass0;
    v[1] = py*rmass0;
    v[2] = pz*rmass0;
    // work out solute concentrations
    for(int i=0; i<nc; i++) {
      conc[i] = 0.0;
      for(int m=0; m<nq; m++) {
        conc[i] += databuf[m*qdim+nf+i];
      }
    }
    // work out temperature
    if(nt>0) {
      temp = 0.0;
      for(int m=0; m<nq; m++) {
        temp += databuf[m*qdim+nf+nc];
      }
    }
    // now write line in lbin.init file
      outfile << ipos[0] << " " << ipos[1] << " " << ipos[2] << " " << v[0] << " " << v[1] << " " << v[2];
      for(int m=0; m<nf; m++)
        outfile << " " << rho[m];
      for(int m=0; m<nc; m++)
        outfile << " " << conc[m];
      if(nt>0)
        outfile << " " << temp;
      outfile << endl;
  }
    
  // close files
  infile.close();
  outfile.close();

  return 0;
}

void quickSortIndexed(unsigned long *arr, unsigned long *index, unsigned long len)
{
  if(len<2) return;
  unsigned long pivot = arr[len/2];
  unsigned long i, j, temp;
  for (i=0, j=len-1; ; i++, j--) {
    while (arr[i]<pivot) i++;
    while (arr[j]>pivot) j--;
      
    if(i>=j) break;
      
    temp = arr[i];
    arr[i] = arr[j];
    arr[j] = temp;
    temp = index[i];
    index[i] = index[j];
    index[j] = temp;
  }
  quickSortIndexed(arr, index, i);
  quickSortIndexed(arr+i, index+i, len-i);
}


int main(int argc, char* argv[])
{
  string word;
  for(int i=1; i<argc; i++) {
    word = argv[i];
    if(word.compare(0,2,"-h")==0 || word.compare(0,2,"-H")==0) {
      cout << "DL_MESO dump to initial state utility, creates a " << endl;
      cout << "lbin.init file from lbout.dump file created during" << endl;
      cout << "calculation as initial state for new simulation" << endl;
      cout << "Usage: " << argv[0] << " [OPTIONS]" << endl << endl;
      cout << "Options:" << endl << endl;
      cout << "-h" << endl;
      cout << "       display this help and exit" << endl << endl;
      exit(0);
    }
  }

  cGatherData aa;

  return 0;
}
