/***************************************************
 *   DL_MESO       Version 2.7                     *
 *   Authors   :   R. S. Qin, M. A. Seaton         *
 *   Copyright :   UKRI STFC Daresbury Laboratory  *
 *             :   09/12/2018                      *
 ***************************************************/

int fGetCentralMomentEquilibriumF(double *meq, double rho)
{

  // calculate equilibrium moments, raw-to-central shift and inverse
  // matrices of compressible fluid for CLBE collision schemes:
  // not suitable for incompressible fluid
    
  const double c1 = 1.0/3.0;
  const double c2 = 1.0/9.0;
  const double c3 = 1.0/27.0;
    
  if(lbsy.nq == 9) {
    meq[0] = rho;       // M_00 (density)
    meq[1] = 0.0;       // M_10 (x-momentum)
    meq[2] = 0.0;       // M_01 (y-momentum)
    meq[3] = c1 * rho;  // M_20
    meq[4] = c1 * rho;  // M_02
    meq[5] = 0.0;       // M_11
    meq[6] = 0.0;       // M_21
    meq[7] = 0.0;       // M_12
    meq[8] = c2 * rho;  // M_22
  }
  else if(lbsy.nq == 19) {
    meq[0]  = rho;       // M_000 (density)
    meq[1]  = 0.0;       // M_100 (x-momentum)
    meq[2]  = 0.0;       // M_010 (y-momentum)
    meq[3]  = 0.0;       // M_001 (z-momentum)
    meq[4]  = 0.0;       // M_110
    meq[5]  = 0.0;       // M_101
    meq[6]  = 0.0;       // M_011
    meq[7]  = c1 * rho;  // M_200
    meq[8]  = c1 * rho;  // M_020
    meq[9]  = c1 * rho;  // M_002
    meq[10] = 0.0;       // M_120
    meq[11] = 0.0;       // M_102
    meq[12] = 0.0;       // M_210
    meq[13] = 0.0;       // M_201
    meq[14] = 0.0;       // M_012
    meq[15] = 0.0;       // M_021
    meq[16] = c2 * rho;  // M_220
    meq[17] = c2 * rho;  // M_202
    meq[18] = c2 * rho;  // M_022
  }
  else if(lbsy.nq == 27) {
    meq[0]  = rho;       // M_000 (density)
    meq[1]  = 0.0;       // M_100 (x-momentum)
    meq[2]  = 0.0;       // M_010 (y-momentum)
    meq[3]  = 0.0;       // M_001 (z-momentum)
    meq[4]  = 0.0;       // M_110
    meq[5]  = 0.0;       // M_101
    meq[6]  = 0.0;       // M_011
    meq[7]  = c1 * rho;  // M_200
    meq[8]  = c1 * rho;  // M_020
    meq[9]  = c1 * rho;  // M_002
    meq[10] = 0.0;       // M_120
    meq[11] = 0.0;       // M_102
    meq[12] = 0.0;       // M_210
    meq[13] = 0.0;       // M_201
    meq[14] = 0.0;       // M_012
    meq[15] = 0.0;       // M_021
    meq[16] = 0.0;       // M_111
    meq[17] = c2 * rho;  // M_220
    meq[18] = c2 * rho;  // M_202
    meq[19] = c2 * rho;  // M_022
    meq[20] = 0.0;       // M_211
    meq[21] = 0.0;       // M_121
    meq[22] = 0.0;       // M_112
    meq[23] = 0.0;       // M_122
    meq[24] = 0.0;       // M_212
    meq[25] = 0.0;       // M_221
    meq[26] = c3 * rho;  // M_222
  }
  else if(lbdm.rank ==0) {
    cout << "the cascaded LBE scheme for D" << lbsy.nd << "Q" << lbsy.nq << " model has not been defined" << endl;
    if(lbsy.nd == 2)
      cout << "the D2Q9 model can be used" << endl;
    else
      cout << "the D3Q19 or D3Q27 models can be used" << endl;
    exit(1);
  }
  return 0;
}

int fGetCentralMomentTransformMatrix(double *rcsh, double *rcshinv, double *u)
{
  // calculate full transform and inverse matrices from distribution
  // functions to central moments (and vice versa): matrix products
  // of transform and shift matrices
    
  double ux = u[0];
  double uy = u[1];
  double uz = u[2];
  double uxux = ux*ux;
  double uyuy = uy*uy;
  double uzuz = uz*uz;
  double uxuy = ux*uy;
  double uxuz = ux*uz;
  double uyuz = uy*uz;
  double onemux = 1.0-ux;
  double onepux = 1.0+ux;
  double onemtwoux = 1.0-2.0*ux;
  double oneptwoux = 1.0+2.0*ux;
  double onemuxsq = onemux*onemux;
  double onepuxsq = onepux*onepux;
  double onemuxux = 1.0-uxux;
  double onemuy = 1.0-uy;
  double onepuy = 1.0+uy;
  double onemtwouy = 1.0-2.0*uy;
  double oneptwouy = 1.0+2.0*uy;
  double onemuysq = onemuy*onemuy;
  double onepuysq = onepuy*onepuy;
  double onemuyuy = 1.0-uyuy;
  double onemuz = 1.0-uz;
  double onepuz = 1.0+uz;
  double onemtwouz = 1.0-2.0*uz;
  double oneptwouz = 1.0+2.0*uz;
  double onemuzsq = onemuz*onemuz;
  double onepuzsq = onepuz*onepuz;
  double onemuzuz = 1.0-uzuz;
    
  if(lbsy.nq == 9) {
    double shift[81] = {      1.0,               1.0,           1.0,               1.0,           1.0,               1.0,           1.0,               1.0,           1.0,
                              -ux,           -onepux,       -onepux,           -onepux,           -ux,            onemux,        onemux,            onemux,           -ux,
                              -uy,            onemuy,           -uy,           -onepuy,       -onepuy,           -onepuy,           -uy,            onemuy,        onemuy,
                             uxux,          onepuxsq,      onepuxsq,          onepuxsq,          uxux,          onemuxsq,      onemuxsq,          onemuxsq,          uxux,
                             uyuy,          onemuysq,          uyuy,          onepuysq,      onepuysq,          onepuysq,          uyuy,          onemuysq,      onemuysq,
                             uxuy,    -onepux*onemuy,     onepux*uy,     onepux*onepuy,     ux*onepuy,    -onemux*onepuy,    -onemux*uy,     onemux*onemuy,    -ux*onemuy,
                         -uxux*uy,   onepuxsq*onemuy,  -onepuxsq*uy,  -onepuxsq*onepuy,  -uxux*onepuy,  -onemuxsq*onepuy,  -onemuxsq*uy,   onemuxsq*onemuy,  -uxux*onemuy,
                         -ux*uyuy,  -onepux*onemuysq,  -onepux*uyuy,  -onepux*onepuysq,  -ux*onepuxsq,   onemux*onepuysq,   onemux*uyuy,   onemux*onemuysq,  -ux*onemuysq,
                        uxux*uyuy, onepuxsq*onemuysq, onepuxsq*uyuy, onepuxsq*onepuysq, uxux*onepuysq, onemuxsq*onepuysq, onemuxsq*uyuy, onemuxsq*onemuysq, uxux*onemuysq };
    double shinv[81] = {        onemuxux*onemuyuy,          -2.0*ux*onemuyuy,          -2.0*onemuxux*uy,       -onemuyuy,       -onemuxux,                  4.0*uxuy,          2.0*uy,          2.0*ux,  1.0,
                         -0.25*uxuy*onemux*onepuy, -0.25*uy*onemtwoux*onepuy, -0.25*ux*onemux*oneptwouy,  0.25*uy*onepuy, -0.25*ux*onemux, -0.25*onemtwoux*oneptwouy,  0.25*oneptwouy, -0.25*onemtwoux, 0.25,
                          -0.5*ux*onemux*onemuyuy,   -0.5*onemtwoux*onemuyuy,              ux*uy*onemux,    0.5*onemuyuy,   0.5*ux*onemux,              onemtwoux*uy,             -uy,   0.5*onemtwoux, -0.5,
                          0.25*uxuy*onemux*onemuy,  0.25*uy*onemtwoux*onemuy,  0.25*ux*onemux*onemtwouy, -0.25*uy*onemuy, -0.25*ux*onemux,  0.25*onemtwoux*onemtwouy, -0.25*onemtwouy, -0.25*onemtwoux, 0.25,
                          -0.5*uy*onemuxux*onemuy,              ux*uy*onemuy,   -0.5*onemuxux*onemtwouy,   0.5*uy*onemuy,    0.5*onemuxux,              ux*onemtwouy,   0.5*onemtwouy,             -ux, -0.5,
                         -0.25*uxuy*onepux*onemuy, -0.25*uy*oneptwoux*onemuy, -0.25*ux*onepux*onemtwouy, -0.25*uy*onemuy,  0.25*ux*onepux, -0.25*oneptwoux*onemtwouy, -0.25*onemtwouy,  0.25*oneptwoux, 0.25,
                           0.5*ux*onepux*onemuyuy,    0.5*oneptwoux*onemuyuy,             -ux*uy*onepux,    0.5*onemuyuy,  -0.5*ux*onepux,             -oneptwoux*uy,             -uy,  -0.5*oneptwoux, -0.5,
                          0.25*uxuy*onepux*onepuy,  0.25*uy*oneptwoux*onepuy,  0.25*ux*onepux*oneptwouy,  0.25*uy*onepuy,  0.25*ux*onepux,  0.25*oneptwoux*oneptwouy,  0.25*oneptwouy,  0.25*oneptwoux, 0.25,
                           0.5*uy*onemuxux*onepuy,             -ux*uy*onepuy,    0.5*onemuxux*oneptwouy,  -0.5*uy*onepuy,    0.5*onemuxux,             -ux*oneptwouy,  -0.5*oneptwouy,             -ux, -0.5 };
    std::copy (shift, shift+81, rcsh);
    std::copy (shinv, shinv+81, rcshinv);
  }
  else if(lbsy.nq == 19) {
    double onemuxuxmuyuy = 1.0-uxux-uyuy;
    double onemuxuxmuzuz = 1.0-uxux-uzuz;
    double onemuyuymuzuz = 1.0-uyuy-uzuz;
    double onemuxuxmuyuymuzuz = 1.0-uxux-uyuy-uzuz+uxux*uyuy+uxux*uzuz+uyuy*uzuz;
    double shift[361] = {      1.0,           1.0,           1.0,           1.0,               1.0,               1.0,               1.0,               1.0,               1.0,               1.0,           1.0,           1.0,           1.0,               1.0,               1.0,               1.0,               1.0,               1.0,               1.0,
                               -ux,       -onepux,           -ux,           -ux,           -onepux,           -onepux,           -onepux,           -onepux,               -ux,               -ux,        onemux,           -ux,           -ux,            onemux,            onemux,            onemux,            onemux,               -ux,               -ux,
                               -uy,           -uy,       -onepuy,           -uy,           -onepuy,            onemuy,               -uy,               -uy,           -onepuy,           -onepuy,           -uy,        onemuy,           -uy,            onemuy,           -onepuy,               -uy,               -uy,            onemuy,            onemuy,
                               -uz,           -uz,           -uz,       -onepuz,               -uz,               -uz,           -onepuz,            onemuz,           -onepuz,            onemuz,           -uz,           -uz,        onemuz,               -uz,               -uz,            onemuz,           -onepuz,            onemuz,           -onepuz,
                              uxuy,     onepux*uy,     ux*onepuy,          uxuy,     onepux*onepuy,    -onepux*onemuy,         onepux*uy,         onepux*uy,         ux*onepuy,         ux*onepuy,    -onemux*uy,    -ux*onemuy,          uxuy,     onemux*onemuy,    -onemux*onepuy,        -onemux*uy,        -onemux*uy,        -ux*onemuy,        -ux*onemuy,
                              uxuz,     onepux*uz,          uxuz,     ux*onepuz,         onepux*uz,         onepux*uz,     onepux*onepuz,    -onepux*onemuz,         ux*onepuz,        -ux*onemuz,    -onemux*uz,          uxuz,    -ux*onemuz,        -onemux*uz,        -onemux*uz,     onemux*onemuz,    -onemux*onepuz,        -ux*onemuz,         ux*onepuz,
                              uyuz,          uyuz,     onepuy*uz,     uy*onepuz,         onepuy*uz,        -onemuy*uz,         uy*onepuz,        -uy*onemuz,     onepuy*onepuz,    -onepuy*onemuz,          uyuz,    -onemuy*uz,    -uy*onemuz,        -onemuy*uz,         onepuy*uz,        -uy*onemuz,         uy*onepuz,     onemuy*onemuz,    -onemuy*onepuz,
                              uxux,      onepuxsq,          uxux,          uxux,          onepuxsq,          onepuxsq,          onepuxsq,          onepuxsq,              uxux,              uxux,      onemuxsq,          uxux,          uxux,          onemuxsq,          onemuxsq,          onemuxsq,          onemuxsq,              uxux,              uxux,
                              uyuy,          uyuy,      onepuysq,          uyuy,          onepuysq,          onemuysq,              uyuy,              uyuy,          onepuysq,          onepuysq,          uyuy,      onemuysq,          uyuy,          onemuysq,          onepuysq,              uyuy,              uyuy,          onemuysq,          onemuysq,
                              uzuz,          uzuz,          uzuz,      onepuzsq,              uzuz,              uzuz,          onepuzsq,          onemuzsq,          onepuzsq,          onemuzsq,          uzuz,          uzuz,      onemuzsq,              uzuz,              uzuz,          onemuzsq,          onepuzsq,          onemuzsq,          onepuzsq,
                          -ux*uyuy,  -onepux*uyuy,  -ux*onepuysq,      -ux*uyuy,  -onepux*onepuysq,  -onepux*onemuysq,      -onepux*uyuy,      -onepux*uyuy,      -ux*onepuysq,      -ux*onepuysq,   onemux*uyuy,  -ux*onemuysq,      -ux*uyuy,   onemux*onemuysq,   onemux*onepuysq,       onemux*uyuy,       onemux*uyuy,      -ux*onemuysq,      -ux*onemuysq,
                          -ux*uzuz,  -onepux*uzuz,      -ux*uzuz,  -ux*onepuzsq,      -onepux*uzuz,      -onepux*uzuz,  -onepux*onepuzsq,  -onepux*onemuzsq,      -ux*onepuzsq,      -ux*onemuzsq,   onemux*uzuz,      -ux*uzuz,  -ux*onemuzsq,       onemux*uzuz,       onemux*uzuz,   onemux*onemuzsq,   onemux*onepuzsq,      -ux*onemuzsq,      -uy*onepuzsq,
                          -uxux*uy,  -onepuxsq*uy,  -uxux*onepuy,      -uxux*uy,  -onepuxsq*onepuy,   onepuxsq*onemuy,      -onepuxsq*uy,      -onepuxsq*uy,      -uxux*onepuy,      -uxux*onepuy,  -onemuxsq*uy,   uxux*onemuy,      -uxux*uy,   onemuxsq*onemuy,  -onemuxsq*onepuy,      -onemuxsq*uy,      -onemuxsq*uy,       uxux*onemuy,       uxux*onemuy,
                          -uxux*uz,  -onepuxsq*uz,      -uxux*uz,  -uyuy*onepuz,      -onepuxsq*uz,      -onepuxsq*uz,  -onepuxsq*onepuz,  -onepuxsq*onemuz,      -uxux*onepuz,       uxux*onemuz,  -onemuxsq*uz,      -uxux*uz,   uxux*onemuz,      -onemuxsq*uz,      -onemuxsq*uz,   onemuxsq*onemuz,  -onemuxsq*onepuz,       uxux*onemuz,      -uxux*onepuz,
                          -uy*uzuz,      -uy*uzuz,  -onepuy*uzuz,  -uy*onepuzsq,      -onepuy*uzuz,       onemuy*uzuz,      -uy*onepuzsq,      -uy*onemuzsq,  -onepuy*onepuzsq,  -onepuy*onemuzsq,      -uy*uzuz,   onemuy*uzuz,  -uy*onemuzsq,       onemuy*uzuz,      -onepuy*uzuz,      -uy*onemuzsq,      -uy*onepuzsq,   onemuy*onemuzsq,   onemuy*onepuzsq,
                          -uyuy*uz,      -uyuy*uz,  -onepuysq*uz,  -uyuy*onepuz,      -onepuysq*uz,      -onemuysq*uz,      -uyuy*onepuz,      -uyuy*onemuz,  -onepuysq*onepuz,   onepuysq*onemuz,      -uyuy*uz,  -onemuysq*uz,   uyuy*onemuz,      -onemuysq*uz,      -onepuysq*uz,       uyuy*onemuz,      -uyuy*onepuz,   onemuysq*onemuz,  -onemuysq*onepuz,
                         uxux*uyuy, onepuxsq*uyuy, uxux*onepuysq,     uxux*uyuy, onepuxsq*onepuysq, onepuxsq*onemuysq,     onepuxsq*uyuy,     onepuxsq*uyuy,     uxux*onepuysq,     uxux*onepuysq, onemuxsq*uyuy, uxux*onemuysq,     uxux*uyuy, onemuxsq*onemuysq, onemuxsq*onepuysq,     onemuxsq*uyuy,     onemuxsq*uyuy,     uxux*onemuysq,     uxux*onemuysq,
                         uxux*uzuz, onepuxsq*uzuz,     uxux*uzuz, uxux*onepuzsq,     onepuxsq*uzuz,     onepuxsq*uzuz, onepuxsq*onepuxsq, onepuxsq*onemuzsq,     uxux*onepuzsq,     uxux*onemuzsq, onemuxsq*uzuz,     uxux*uzuz, uxux*onemuzsq,     onemuxsq*uzuz,     onemuxsq*uzuz, onemuxsq*onemuzsq, onemuxsq*onepuzsq,     uxux*onemuzsq,     uxux*onepuzsq,
                         uyuy*uzuz,     uyuy*uzuz, onepuysq*uzuz, uyuy*onepuzsq,     onepuysq*uzuz,     onemuysq*uzuz,     uyuy*onepuzsq,     uyuy*onemuzsq, onepuysq*onepuzsq, onepuysq*onemuzsq,     uyuy*uzuz, onemuysq*uzuz, uyuy*onemuzsq,     onemuysq*uzuz,     onepuysq*uzuz,     uyuy*onemuzsq,     uyuy*onepuzsq, onemuysq*onemuzsq, onemuysq*onepuzsq };
    double shinv[361] = {           onemuxuxmuyuymuzuz,        -2.0*ux*onemuyuymuzuz,        -2.0*uy*onemuxuxmuzuz,        -2.0*uz*onemuxuxmuyuy,                  4.0*uxuy,                  4.0*uxuz,                  4.0*uyuz,    -onemuyuymuzuz,    -onemuxuxmuzuz,    -onemuxuxmuyuy,          2.0*ux,          2.0*ux,          2.0*uy,          2.0*uz,          2.0*uy,          2.0*uz,  1.0,  1.0,  1.0,
                          -0.5*ux*onemux*onemuyuymuzuz, -0.5*onemtwoux*onemuyuymuzuz,                  uxuy*onemux,                  uxuz*onemux,              onemtwoux*uy,              onemtwoux*uz,                       0.0, 0.5*onemuyuymuzuz,     0.5*ux*onemux,     0.5*ux*onemux,   0.5*onemtwoux,   0.5*onemtwoux,             -uy,             -uz,             0.0,             0.0, -0.5, -0.5,  0.0,
                          -0.5*uy*onemuy*onemuxuxmuzuz,                  uxuy*onemuy, -0.5*onemtwouy*onemuxuxmuzuz,                  uyuz*onemuy,              ux*onemtwouy,                       0.0,              onemtwouy*uz,     0.5*uy*onemuy, 0.5*onemuxuxmuzuz,     0.5*uy*onemuy,             -ux,             0.0,   0.5*onemtwouy,             0.0,   0.5*onemtwouy,             -uz, -0.5,  0.0, -0.5,
                          -0.5*uz*onemuz*onemuxuxmuyuy,                  uxuz*onemuz,                  uyuz*onemuz, -0.5*onemtwouz*onemuxuxmuyuy,                       0.0,              ux*onemtwouz,              uy*onemtwouz,     0.5*uz*onemuz,     0.5*uz*onemuz, 0.5*onemuxuxmuyuy,             0.0,             -ux,             0.0,   0.5*onemtwouz,             -uy,   0.5*onemtwouz,  0.0, -0.5, -0.5,
                               0.25*uxuy*onemux*onemuy,     0.25*onemtwoux*uy*onemuy,     0.25*ux*onemux*onemtwouy,                          0.0,  0.25*onemtwoux*onemtwouy,                       0.0,                       0.0,   -0.25*uy*onemuy,   -0.25*ux*onemux,               0.0, -0.25*onemtwoux,             0.0, -0.25*onemtwouy,             0.0,             0.0,             0.0, 0.25,  0.0,  0.0,
                              -0.25*uxuy*onemux*onepuy,    -0.25*onemtwoux*uy*onepuy,    -0.25*ux*onemux*oneptwouy,                          0.0, -0.25*onemtwoux*oneptwouy,                       0.0,                       0.0,    0.25*uy*onepuy,   -0.25*ux*onemux,               0.0, -0.25*onemtwoux,             0.0,  0.25*oneptwouy,             0.0,             0.0,             0.0, 0.25,  0.0,  0.0,
                               0.25*uxuz*onemux*onemuz,     0.25*onemtwoux*uz*onemuz,                          0.0,     0.25*ux*onemux*onemtwouz,                       0.0,  0.25*onemtwoux*onemtwouz,                       0.0,   -0.25*uz*onemuz,               0.0,   -0.25*ux*onemux,             0.0, -0.25*onemtwoux,             0.0, -0.25*onemtwouz,             0.0,             0.0,  0.0, 0.25,  0.0,
                              -0.25*uxuz*onemux*onepuz,    -0.25*onemtwoux*uz*onepuz,                          0.0,    -0.25*ux*onemux*oneptwouz,                       0.0, -0.25*onemtwoux*oneptwouz,                       0.0,    0.25*uz*onepuz,               0.0,   -0.25*ux*onemux,             0.0, -0.25*onemtwoux,             0.0,  0.25*oneptwouy,             0.0,             0.0,  0.0, 0.25,  0.0,
                               0.25*uyuz*onemuy*onemuz,                          0.0,     0.25*onemtwouy*uz*onemuz,     0.25*uy*onemuy*onemtwouz,                       0.0,                       0.0,  0.25*onemtwouy*onemtwouz,               0.0,   -0.25*uz*onemuz,   -0.25*uy*onemuy,             0.0,             0.0,             0.0,             0.0, -0.25*onemtwouy, -0.25*onemtwouz,  0.0,  0.0, 0.25,
                              -0.25*uyuz*onemuy*onepuz,                          0.0,    -0.25*onemtwouy*uz*onepuz,    -0.25*uy*onemuy*oneptwouz,                       0.0,                       0.0, -0.25*onemtwouy*oneptwouz,               0.0,    0.25*uz*onepuz,   -0.25*uy*onemuy,             0.0,             0.0,             0.0,             0.0, -0.25*onemtwouy,  0.25*oneptwouy,  0.0,  0.0, 0.25,
                           0.5*ux*onepux*onemuyuymuzuz,  0.5*oneptwoux*onemuyuymuzuz,                 -uxuy*onepux,                 -uxuz*onepux,             -oneptwoux*uy,             -oneptwoux*uz,                       0.0, 0.5*onemuyuymuzuz,    -0.5*ux*onepux,    -0.5*ux*onepux,  -0.5*oneptwoux,  -0.5*oneptwoux,             -uy,             -uz,             0.0,             0.0, -0.5, -0.5,  0.0,
                           0.5*uy*onepuy*onemuxuxmuzuz,                 -uxuy*onepuy,  0.5*oneptwouy*onemuxuxmuzuz,                 -uyuz*onepuy,             -ux*oneptwouy,                       0.0,             -oneptwouy*uz,    -0.5*uy*onepuy, 0.5*onemuxuxmuzuz,    -0.5*uy*onepuy,             -ux,             0.0,  -0.5*oneptwouy,             0.0,  -0.5*oneptwouy,             -uz, -0.5,  0.0, -0.5,
                           0.5*uz*onepuz*onemuxuxmuyuy,                 -uxuz*onepuz,                 -uyuz*onepuz,  0.5*oneptwouz*onemuxuxmuyuy,                       0.0,             -ux*oneptwouz,             -uy*oneptwouz,    -0.5*uz*onepuz,    -0.5*uz*onepuz, 0.5*onemuxuxmuyuy,             0.0,             -ux,             0.0,  -0.5*oneptwouz,             -uy,  -0.5*oneptwouz,  0.0, -0.5, -0.5,
                               0.25*uxuy*onepux*onepuy,     0.25*oneptwoux*uy*onepuy,     0.25*ux*onepux*oneptwouy,                          0.0,  0.25*oneptwoux*oneptwouy,                       0.0,                       0.0,    0.25*uy*onepuy,    0.25*ux*onepux,               0.0,  0.25*oneptwoux,             0.0,  0.25*oneptwouy,             0.0,             0.0,             0.0, 0.25,  0.0,  0.0,
                              -0.25*uxuy*onepux*onemuy,    -0.25*oneptwoux*uy*onemuy,    -0.25*ux*onepux*onemtwouy,                          0.0, -0.25*oneptwoux*onemtwouy,                       0.0,                       0.0,   -0.25*uy*onemuy,    0.25*ux*onepux,               0.0,  0.25*oneptwoux,             0.0, -0.25*onemtwouy,             0.0,             0.0,             0.0, 0.25,  0.0,  0.0,
                               0.25*uxuz*onepux*onepuz,     0.25*oneptwoux*uz*onepuz,                          0.0,     0.25*ux*onepux*oneptwouz,                       0.0,  0.25*oneptwoux*oneptwouz,                       0.0,    0.25*uz*onepuz,               0.0,    0.25*ux*onepux,             0.0,  0.25*oneptwoux,             0.0,  0.25*oneptwouz,             0.0,             0.0,  0.0, 0.25,  0.0,
                              -0.25*uxuz*onepux*onemuz,    -0.25*oneptwoux*uz*onemuz,                          0.0,    -0.25*ux*onepux*onemtwouz,                       0.0, -0.25*oneptwoux*onemtwouz,                       0.0,   -0.25*uz*onemuz,               0.0,    0.25*ux*onepux,             0.0,  0.25*oneptwoux,             0.0, -0.25*onemtwouy,             0.0,             0.0,  0.0, 0.25,  0.0,
                               0.25*uyuz*onepuy*onepuz,                          0.0,     0.25*oneptwouy*uz*onepuz,     0.25*uy*onepuy*oneptwouz,                       0.0,                       0.0,  0.25*oneptwouy*oneptwouz,               0.0,    0.25*uz*onepuz,    0.25*uy*onepuy,             0.0,             0.0,             0.0,             0.0,  0.25*oneptwouy,  0.25*oneptwouz,  0.0,  0.0, 0.25,
                              -0.25*uyuz*onepuy*onemuz,                          0.0,    -0.25*oneptwouy*uz*onemuz,    -0.25*uy*onepuy*onemtwouz,                       0.0,                       0.0, -0.25*oneptwouy*onemtwouz,               0.0,   -0.25*uz*onemuz,    0.25*uy*onepuy,             0.0,             0.0,             0.0,             0.0,  0.25*oneptwouy, -0.25*onemtwouz,  0.0,  0.0, 0.25 };
    std::copy (shift, shift+361, rcsh);
    std::copy (shinv, shinv+361, rcshinv);
  }
  else if(lbsy.nq == 27) {
    double uxuyuz = ux*uy*uz;
    double shift[729] = {          1.0,                1.0,                1.0,                1.0,                    1.0,                    1.0,                    1.0,                    1.0,                    1.0,                    1.0,                        1.0,                        1.0,                        1.0,                        1.0,                1.0,                1.0,                1.0,                    1.0,                    1.0,                    1.0,                    1.0,                    1.0,                    1.0,                        1.0,                        1.0,                        1.0,                        1.0,
                                   -ux,            -onepux,                -ux,                -ux,                -onepux,                -onepux,                -onepux,                -onepux,                    -ux,                    -ux,                    -onepux,                    -onepux,                    -onepux,                    -onepux,             onemux,                -ux,                -ux,                 onemux,                 onemux,                 onemux,                 onemux,                    -ux,                    -ux,                     onemux,                     onemux,                     onemux,                     onemux,
                                   -uy,                -uy,            -onepuy,                -uy,                -onepuy,                 onemuy,                    -uy,                    -uy,                -onepuy,                -onepuy,                    -onepuy,                    -onepuy,                     onemuy,                     onemuy,                -uy,             onemuy,                -uy,                 onemuy,                -onepuy,                    -uy,                    -uy,                 onemuy,                 onemuy,                     onemuy,                     onemuy,                    -onepuy,                    -onepuy,
                                   -uz,                -uz,                -uz,            -onepuz,                    -uz,                    -uz,                -onepuz,                 onemuz,                -onepuz,                 onemuz,                    -onepuz,                     onemuz,                    -onepuz,                     onemuz,                -uz,                -uz,             onemuz,                    -uz,                    -uz,                 onemuz,                -onepuz,                 onemuz,                -onepuz,                     onemuz,                    -onepuz,                     onemuz,                    -onepuz,
                                  uxuy,          onepux*uy,          ux*onepuy,               uxuy,          onepux*onepuy,         -onepux*onemuy,              onepux*uy,              onepux*uy,              ux*onepuy,              ux*onepuy,              onepux*onepuy,              onepux*onepuy,             -onepux*onemuy,             -onepux*onemuy,         -onemux*uy,         -ux*onemuy,               uxuy,          onemux*onemuy,         -onemux*onepuy,             -onemux*uy,             -onemux*uy,             -ux*onemuy,             -ux*onemuy,              onemux*onemuy,              onemux*onemuy,             -onemux*onepuy,             -onemux*onepuy,
                                  uxuz,          onepux*uz,               uxuz,          ux*onepuz,              onepux*uz,              onepux*uz,          onepux*onepuz,         -onepux*onemuz,              ux*onepuz,             -ux*onemuz,              onepux*onepuz,             -onepux*onemuz,              onepux*onepuz,             -onepux*onemuz,         -onemux*uz,               uxuz,         -ux*onemuz,             -onemux*uz,             -onemux*uz,          onemux*onemuz,         -onemux*onepuz,             -ux*onemuz,              ux*onepuz,              onemux*onemuz,             -onemux*onepuz,              onemux*onemuz,             -onemux*onepuz,
                                  uyuz,               uyuz,          onepuy*uz,          uy*onepuz,              onepuy*uz,             -onemuy*uz,              uy*onepuz,             -uy*onemuz,          onepuy*onepuz,         -onepuy*onemuz,              onepuy*onepuz,             -onepuy*onemuz,             -onemuy*onepuz,              onemuy*onemuz,               uyuz,         -onemuy*uz,         -uy*onemuz,             -onemuy*uz,              onepuy*uz,             -uy*onemuz,              uy*onepuz,          onemuy*onemuz,         -onemuy*onepuz,              onemuy*onemuz,             -onemuy*onepuz,             -onepuy*onemuz,              onepuy*onepuz,
                                  uxux,           onepuxsq,               uxux,               uxux,               onepuxsq,               onepuxsq,               onepuxsq,               onepuxsq,                   uxux,                   uxux,                   onepuxsq,                   onepuxsq,                   onepuxsq,                   onepuxsq,           onemuxsq,               uxux,               uxux,               onemuxsq,               onemuxsq,               onemuxsq,               onemuxsq,                   uxux,                   uxux,                   onemuxsq,                   onemuxsq,                   onemuxsq,                   onemuxsq,
                                  uyuy,               uyuy,           onepuysq,               uyuy,               onepuysq,               onemuysq,                   uyuy,                   uyuy,               onepuysq,               onepuysq,                   onepuysq,                   onepuysq,                   onemuysq,                   onemuysq,               uyuy,           onemuysq,               uyuy,               onemuysq,               onepuysq,                   uyuy,                   uyuy,               onemuysq,               onemuysq,                   onemuysq,                   onemuysq,                   onepuysq,                   onepuysq,
                                  uzuz,               uzuz,               uzuz,           onepuzsq,                   uzuz,                   uzuz,               onepuzsq,               onemuzsq,               onepuzsq,               onemuzsq,                   onepuzsq,                   onemuzsq,                   onepuzsq,                   onemuzsq,               uzuz,               uzuz,           onemuzsq,                   uzuz,                   uzuz,               onemuzsq,               onepuzsq,               onemuzsq,               onepuzsq,                   onemuzsq,                   onepuzsq,                   onemuzsq,                   onepuzsq,
                              -ux*uyuy,       -onepux*uyuy,       -ux*onepuysq,           -ux*uyuy,       -onepux*onepuysq,       -onepux*onemuysq,           -onepux*uyuy,           -onepux*uyuy,           -ux*onepuysq,           -ux*onepuysq,           -onepux*onepuysq,           -onepux*onepuysq,           -onepux*onemuysq,           -onepux*onemuysq,        onemux*uyuy,       -ux*onemuysq,           -ux*uyuy,        onemux*onemuysq,        onemux*onepuysq,            onemux*uyuy,            onemux*uyuy,           -ux*onemuysq,           -ux*onemuysq,            onemux*onemuysq,            onemux*onemuysq,            onemux*onepuysq,            onemux*onepuysq,
                              -ux*uzuz,       -onepux*uzuz,           -ux*uzuz,       -ux*onepuzsq,           -onepux*uzuz,           -onepux*uzuz,       -onepux*onepuzsq,       -onepux*onemuzsq,           -ux*onepuzsq,           -ux*onemuzsq,           -onepux*onepuzsq,           -onepux*onemuzsq,           -onepux*onepuzsq,           -onepux*onemuzsq,        onemux*uzuz,           -ux*uzuz,       -ux*onemuzsq,            onemux*uzuz,            onemux*uzuz,        onemux*onemuzsq,        onemux*onepuzsq,           -ux*onemuzsq,           -ux*onepuzsq,            onemux*onemuzsq,            onemux*onepuzsq,            onemux*onemuzsq,            onemux*onepuzsq,
                              -uxux*uy,       -onepuxsq*uy,       -uxux*onepuy,           -uxux*uy,       -onepuxsq*onepuy,        onepuxsq*onemuy,           -onepuxsq*uy,           -onepuxsq*uy,           -uxux*onepuy,           -uxux*onepuy,           -onepuxsq*onepuy,           -onepuxsq*onepuy,            onepuxsq*onemuy,            onepuxsq*onemuy,       -onemuxsq*uy,        uxux*onemuy,           -uxux*uy,        onemuxsq*onemuy,       -onemuxsq*onepuy,           -onemuxsq*uy,           -onemuxsq*uy,            uxux*onemuy,            uxux*onemuy,            onemuxsq*onemuy,            onemuxsq*onemuy,           -onemuxsq*onepuy,           -onemuxsq*onepuy,
                              -uxux*uz,       -onepuxsq*uz,           -uxux*uz,       -uxux*onepuz,           -onepuxsq*uz,           -onepuxsq*uz,       -onepuxsq*onepuz,        onepuxsq*onemuz,           -uxux*onepuz,            uxux*onemuz,           -onepuxsq*onepuz,            onepuxsq*onemuz,           -onepuxsq*onepuz,            onepuxsq*onemuz,       -onemuxsq*uz,           -uxux*uz,        uxux*onemuz,           -onemuxsq*uz,           -onemuxsq*uz,        onemuxsq*onemuz,       -onemuxsq*onepuz,            uxux*onemuz,           -uxux*onepuz,            onemuxsq*onemuz,           -onemuxsq*onepuz,            onemuxsq*onemuz,           -onemuxsq*onepuz,
                              -uy*uzuz,           -uy*uzuz,       -onepuy*uzuz,       -uy*onepuzsq,           -onepuy*uzuz,            onemuy*uzuz,           -uy*onepuzsq,           -uy*onemuzsq,       -onepuy*onepuzsq,       -onepuy*onemuzsq,           -onepuy*onepuzsq,           -onepuy*onemuzsq,            onemuy*onepuzsq,            onemuy*onemuzsq,           -uy*uzuz,        onemuy*uzuz,       -uy*onemuzsq,            onemuy*uzuz,           -onepuy*uzuz,           -uy*onemuzsq,           -uy*onepuzsq,        onemuy*onemuzsq,        onemuy*onepuzsq,            onemuy*onemuzsq,            onemuy*onepuzsq,           -onepuy*onemuzsq,           -onepuy*onepuzsq,
                              -uyuy*uz,           -uyuy*uz,       -onepuysq*uz,       -uyuy*onepuz,           -onepuysq*uz,           -onemuysq*uz,           -uyuy*onepuz,            uyuy*onemuz,       -onepuysq*onepuz,        onepuysq*onemuz,           -onepuysq*onepuz,            onepuysq*onemuz,           -onemuysq*onepuz,            onemuysq*onemuz,           -uyuy*uz,       -onemuysq*uz,        uyuy*onemuz,           -onemuysq*uz,           -onepuysq*uz,            uyuy*onemuz,           -uyuy*onepuz,        onemuysq*onemuz,       -onemuysq*onepuz,            onemuysq*onemuz,           -onemuysq*onepuz,            onepuysq*onemuz,           -onepuysq*onepuz,
                               -uxuyuz,       -onepux*uyuz,       -uxuz*onepuy,       -uxuy*onepuz,      -onepux*onepuy*uz,       onepux*onemuy*uz,      -onepux*uy*onepuz,       onepux*uy*onemuz,      -ux*onepuy*onepuz,       ux*onepuy*onemuz,      -onepux*onepuy*onepuz,       onepux*onepuy*onemuz,       onepux*onemuy*onepuz,      -onepux*onemuy*onemuz,        onemux*uyuz,        uxuz*onemuy,        uxuy*onemuz,      -onemux*onemuy*uz,       onemux*onepuy*uz,      -onemux*uy*onemuz,       onemux*uy*onepuz,      -ux*onemuy*onemuz,       ux*onemuy*onepuz,       onemux*onemuy*onemuz,      -onemux*onemuy*onepuz,      -onemux*onepuy*onemuz,       onemux*onepuy*onepuz,
                             uxux*uyuy,      onepuxsq*uyuy,      uxux*onepuysq,          uxux*uyuy,      onepuxsq*onepuysq,      onepuxsq*onemuysq,          onepuxsq*uyuy,          onepuxsq*uyuy,          uxux*onepuysq,          uxux*onepuysq,          onepuxsq*onepuysq,          onepuxsq*onepuysq,          onepuxsq*onemuysq,          onepuxsq*onemuysq,      onemuxsq*uyuy,      uxux*onemuysq,          uxux*uyuy,      onemuxsq*onemuysq,      onemuxsq*onepuysq,          onemuxsq*uyuy,          onemuxsq*uyuy,          uxux*onemuysq,          uxux*onemuysq,          onemuxsq*onemuysq,          onemuxsq*onemuysq,          onemuxsq*onepuysq,          onemuxsq*onepuysq,
                             uxux*uzuz,      onepuxsq*uzuz,          uxux*uzuz,      uxux*onepuzsq,          onepuxsq*uzuz,          onepuxsq*uzuz,      onepuxsq*onepuzsq,      onepuxsq*onemuzsq,          uxux*onepuzsq,          uxux*onemuzsq,          onepuxsq*onepuzsq,          onepuxsq*onemuzsq,          onepuxsq*onepuzsq,          onepuxsq*onemuzsq,      onemuxsq*uzuz,          uxux*uzuz,      uxux*onemuzsq,          onemuxsq*uzuz,          onemuxsq*uzuz,      onemuxsq*onemuzsq,      onemuxsq*onepuzsq,          uxux*onemuzsq,          uxux*onepuzsq,          onemuxsq*onemuzsq,          onemuxsq*onepuzsq,          onemuxsq*onemuzsq,          onemuxsq*onepuzsq,
                             uyuy*uzuz,          uyuy*uzuz,      onepuysq*uzuz,      uyuy*onepuzsq,          onepuysq*uzuz,          onemuysq*uzuz,          uyuy*onepuzsq,          uyuy*onemuzsq,      onepuysq*onepuzsq,      onepuysq*onemuzsq,          onepuysq*onepuzsq,          onepuysq*onemuzsq,          onemuysq*onepuzsq,          onemuysq*onemuzsq,          uyuy*uzuz,      onemuysq*uzuz,      uyuy*onemuzsq,          onemuysq*uzuz,          onepuysq*uzuz,          uyuy*onemuzsq,          uyuy*onepuzsq,      onemuysq*onemuzsq,      onemuysq*onepuzsq,          onemuysq*onemuzsq,          onemuysq*onepuzsq,          onepuysq*onemuzsq,          onepuysq*onepuzsq,
                             uxux*uyuz,      onepuxsq*uyuz,     uxux*onepuy*uz,     uxux*uy*onepuz,     onepuxsq*onepuy*uz,    -onepuxsq*onemuy*uz,     onepuxsq*uy*onepuz,    -onepuxsq*uy*onemuz,     uxux*onepuy*onepuz,    -uxux*onepuy*onemuz,     onepuxsq*onepuy*onepuz,    -onepuxsq*onepuy*onemuz,    -onepuxsq*onemuy*onepuz,     onepuxsq*onemuy*onemuz,      onemuxsq*uyuz,    -uxux*onemuy*uz,    -uxux*uy*onemuz,    -onemuxsq*onemuy*uz,     onemuxsq*onepuy*uz,    -onemuxsq*uy*onemuz,     onemuxsq*uy*onepuz,     uxux*onemuy*onemuz,    -uxux*onemuy*onepuz,     onemuxsq*onemuy*onemuz,    -onemuxsq*onemuy*onepuz,    -onemuxsq*onepuy*onemuz,     onemuxsq*onepuy*onepuz,
                             uyuy*uxuz,     onepux*uyuy*uz,      uxuz*onepuysq,     ux*uyuy*onepuz,     onepux*onepuysq*uz,     onepux*onemuysq*uz,     onepux*uyuy*onepuz,    -onepux*uyuy*onemuz,     ux*onepuysq*onepuz,    -ux*onepuysq*onemuz,     onepux*onepuysq*onepuz,    -onepux*onepuysq*onemuz,     onepux*onemuysq*onepuz,    -onepux*onemuysq*onemuz,    -onemux*uyuy*uz,      onemuysq*uxuz,    -ux*uyuy*onemuz,    -onemux*onemuysq*uz,    -onemux*onepuysq*uz,     onemux*uyuy*onemuz,    -onemux*uyuy*onepuz,    -ux*onemuysq*onemuz,     ux*onemuysq*onepuz,     onemux*onemuysq*onemuz,    -onemux*onemuysq*onepuz,     onemux*onepuysq*onemuz,    -onemux*onepuysq*onepuz,
                             uzuz*uxuy,     onepux*uy*uzuz,     ux*onepuy*uzuz,      uxuy*onepuzsq,     onepux*onepuy*uzuz,    -onepux*onemuy*uzuz,     onepux*uy*onepuzsq,     onepux*uy*onemuzsq,     ux*onepuy*onepuzsq,     ux*onepuy*onemuzsq,     onepux*onepuy*onepuzsq,     onepux*onepuy*onemuzsq,    -onepux*onemuy*onepuzsq,    -onepux*onemuy*onemuzsq,    -onemux*uy*uzuz,    -ux*onemuy*uzuz,      uxuy*onemuzsq,     onemux*onemuy*uzuz,    -onemux*onepuy*uzuz,    -onemux*uy*onemuzsq,    -onemux*uy*onepuzsq,    -ux*onemuy*onemuzsq,    -ux*onemuy*onepuzsq,     onemux*onemuy*onemuzsq,     onemux*onemuy*onepuzsq,    -onemux*onepuy*onemuzsq,    -onemux*onepuy*onepuzsq,
                          -uxuyuz*uyuz,  -onepux*uyuy*uzuz,  -ux*onepuysq*uzuz,  -ux*uyuy*onepuzsq,  -onepux*onepuysq*uzuz,  -onepux*onemuysq*uzuz,  -onepux*uyuy*onepuzsq,  -onepux*uyuy*onemuzsq,  -ux*onepuysq*onepuzsq,  -ux*onepuysq*onemuzsq,  -onepux*onepuysq*onepuzsq,  -onepux*onepuysq*onemuzsq,  -onepux*onemuysq*onepuzsq,  -onepux*onemuysq*onemuzsq,   onemux*uyuy*uzuz,  -ux*onemuysq*uzuz,  -ux*uyuy*onemuzsq,   onemux*onemuysq*uzuz,   onemux*onepuysq*uzuz,   onemux*uyuy*onemuzsq,   onemux*uyuy*onepuzsq,  -ux*onemuysq*onemuzsq,  -ux*onemuysq*onepuzsq,   onemux*onemuysq*onemuzsq,   onemux*onemuysq*onepuzsq,   onemux*onepuysq*onemuzsq,   onemux*onepuysq*onepuzsq,
                          -uxuyuz*uxuz,  -onepuxsq*uy*uzuz,  -uxux*onepuy*uzuz,  -uxux*uy*onepuzsq,  -onepuxsq*onepuy*uzuz,   onepuxsq*onemuy*uzuz,  -onepuxsq*uy*onepuzsq,  -onepuxsq*uy*onemuzsq,  -uxux*onepuy*onepuzsq,  -uxux*onepuy*onemuzsq,  -onepuxsq*onepuy*onepuzsq,  -onepuxsq*onepuy*onemuzsq,   onepuxsq*onemuy*onepuzsq,   onepuxsq*onemuy*onemuzsq,  -onemuxsq*uy*uzuz,   uxux*onemuy*uzuz,  -uxux*uy*onemuzsq,   onemuxsq*onemuy*uzuz,  -onemuxsq*onepuy*uzuz,  -onemuxsq*uy*onemuzsq,  -onemuxsq*uy*onepuzsq,   uxux*onemuy*onemuzsq,   uxux*onemuy*onepuzsq,   onemuxsq*onemuy*onemuzsq,   onemuxsq*onemuy*onepuzsq,  -onemuxsq*onepuy*onemuzsq,  -onemuxsq*onepuy*onepuzsq,
                          -uxuyuz*uxuy,  -onepuxsq*uyuy*uz,  -uxux*onepuysq*uz,  -uxux*uyuy*onepuz,  -onepuxsq*onepuysq*uz,  -onepuxsq*onemuysq*uz,  -onepuxsq*uyuy*onepuz,   onepuxsq*uyuy*onemuz,  -uxux*onepuysq*onepuz,   uxux*onepuysq*onemuz,  -onepuxsq*onepuysq*onepuz,   onepuxsq*onepuysq*onemuz,  -onepuxsq*onemuysq*onepuz,   onepuxsq*onemuysq*onemuz,  -onemuxsq*uyuy*uz,  -uxux*onemuysq*uz,   uxux*uyuy*onemuz,  -onemuxsq*onemuysq*uz,  -onemuxsq*onepuysq*uz,   onemuxsq*uyuy*onemuz,  -onemuxsq*uyuy*onepuz,   uxux*onemuysq*onemuz,  -uxux*onemuysq*onepuz,   onemuxsq*onemuysq*onemuz,  -onemuxsq*onemuysq*onepuz,   onemuxsq*onepuysq*onemuz,  -onemuxsq*onepuysq*onepuz,
                         uxuyuz*uxuyuz, onepuxsq*uyuy*uzuz, uxux*onepuysq*uzuz, uxux*uyuy*onepuzsq, onepuxsq*onepuysq*uzuz, onepuxsq*onemuysq*uzuz, onepuxsq*uyuy*onepuzsq, onepuxsq*uyuy*onemuzsq, uxux*onepuysq*onepuzsq, uxux*onepuysq*onemuzsq, onepuxsq*onepuysq*onepuzsq, onepuxsq*onepuysq*onemuzsq, onepuxsq*onemuysq*onepuzsq, onepuxsq*onemuysq*onemuzsq, onemuxsq*uyuy*uzuz, uxux*onemuysq*uzuz, uxux*uyuy*onemuzsq, onemuxsq*onemuysq*uzuz, onemuxsq*onepuysq*uzuz, onemuxsq*uyuy*onemuzsq, onemuxsq*uyuy*onepuzsq, uxux*onemuysq*onemuzsq, uxux*onemuysq*onepuzsq, onemuxsq*onemuysq*onemuzsq, onemuxsq*onemuysq*onepuzsq, onemuxsq*onepuysq*onemuzsq, onemuxsq*onepuysq*onepuzsq };
    double shinv[729] = {        onemuxux*onemuyuy*onemuzuz,           -2.0*ux*onemuyuy*onemuzuz,           -2.0*onemuxux*uy*onemuzuz,           -2.0*onemuxux*onemuyuy*uz,                    4.0*uxuy*onemuzuz,                    4.0*uxuz*onemuyuy,	                   4.0*uyuz*onemuxux,        -onemuyuy*onemuzuz,		-onemuxux*onemuzuz,        -onemuxux*onemuyuy,            2.0*ux*onemuzuz,            2.0*ux*onemuyuy,            2.0*uy*onemuzuz,            2.0*onemuyuy*uz,            2.0*onemuxux*uy,            2.0*onemuxux*uz,                          -8.0*uxuyuz,         onemuzuz,         onemuyuy,         onemuxux,                  -4.0*uyuz,                  -4.0*uxuz,                  -4.0*uxuy,          -2.0*ux,          -2.0*uy,          -2.0*uz,  -1.0,
                           -0.5*onemux*ux*onemuyuy*onemuzuz,    -0.5*onemtwoux*onemuyuy*onemuzuz,                uxuy*onemux*onemuzuz,                uxuz*onemux*onemuyuy,                onemtwoux*uy*onemuzuz,                onemtwoux*onemuyuy*uz,                   -2.0*uxuyuz*onemux,     0.5*onemuyuy*onemuzuz,    0.5*onemux*ux*onemuzuz,    0.5*onemux*ux*onemuyuy,     0.5*onemtwoux*onemuzuz,     0.5*onemtwoux*onemuyuy,               -uy*onemuzuz,               -onemuyuy*uz,               -uxuy*onemux,               -uxuz*onemux,                  -2.0*uyuz*onemtwoux,    -0.5*onemuzuz,    -0.5*onemuyuy,   -0.5*onemux*ux,                   2.0*uyuz,              -onemtwoux*uz,              -onemtwoux*uy,   -0.5*onemtwoux,               uy,               uz,   0.5,
                           -0.5*onemuxux*onemuy*uy*onemuzuz,                uxuy*onemuy*onemuzuz,    -0.5*onemuxux*onemtwouy*onemuzuz,                uyuz*onemuxux*onemuy,                ux*onemtwouy*onemuzuz,                   -2.0*uxuyuz*onemuy,                onemuxux*onemtwouy*uz,    0.5*onemuy*uy*onemuzuz,     0.5*onemuxux*onemuzuz,	   0.5*onemuxux*onemuy*uy,               -ux*onemuzuz,               -uxuy*onemuy,     0.5*onemtwouy*onemuzuz,               -uyuz*onemuy,     0.5*onemuxux*onemtwouy,               -onemuxux*uz,                  -2.0*uxuz*onemtwouy,    -0.5*onemuzuz,   -0.5*onemuy*uy,    -0.5*onemuxux,              -onemtwouy*uz,                   2.0*uxuz,              -ux*onemtwouy,               ux,   -0.5*onemtwouy,               uz,   0.5,
                           -0.5*onemuxux*onemuyuy*onemuz*uz,                uxuz*onemuyuy*onemuz,                uyuz*onemuxux*onemuz,    -0.5*onemuxux*onemuyuy*onemtwouz,	                  -2.0*uxuyuz*onemuz,                ux*onemuyuy*onemtwouz,                onemuxux*uy*onemtwouz,    0.5*onemuyuy*onemuz*uz,    0.5*onemuxux*onemuz*uz,     0.5*onemuxux*onemuyuy,               -uxuz*onemuz,                ux*onemuyuy,               -uyuz*onemuz,     0.5*onemuyuy*onemtwouz,               -onemuxux*uy,     0.5*onemuxux*onemtwouz,                  -2.0*uxuy*onemtwouz,   -0.5*onemuz*uz,    -0.5*onemuyuy,    -0.5*onemuxux,              -uy*onemtwouz,              -ux*onemtwouz,                   2.0*uxuy,               ux,               uy,   -0.5*onemtwouz,   0.5,
                           0.25*uxuy*onemux*onemuy*onemuzuz,   0.25*onemtwoux*onemuy*uy*onemuzuz,   0.25*onemux*ux*onemtwouy*onemuzuz,           -0.5*uxuyuz*onemux*onemuy,	   0.25*onemtwoux*onemtwouy*onemuzuz,           -0.5*uyuz*onemtwoux*onemuy,           -0.5*uxuz*onemux*onemtwouy,  -0.25*onemuy*uy*onemuzuz,  -0.25*onemux*ux*onemuzuz,	 -0.25*uxuy*onemux*onemuy,   -0.25*onemtwoux*onemuzuz,  -0.25*onemtwoux*onemuy*uy,   -0.25*onemtwouy*onemuzuz,            0.5*uyuz*onemuy,  -0.25*onemux*ux*onemtwouy,            0.5*uxuz*onemux,          -0.5*onemtwoux*onemtwouy*uz,    0.25*onemuzuz,   0.25*onemuy*uy,   0.25*onemux*ux,           0.5*onemtwouy*uz,           0.5*onemtwoux*uz,  -0.25*onemtwoux*onemtwouy,   0.25*onemtwoux,   0.25*onemtwouy,          -0.5*uz, -0.25,
                          -0.25*uxuy*onemux*onepuy*onemuzuz,  -0.25*onemtwoux*uy*onepuy*onemuzuz,  -0.25*onemux*ux*oneptwouy*onemuzuz,            0.5*uxuyuz*onemux*onepuy,   -0.25*onemtwoux*oneptwouy*onemuzuz,           0.5*onemtwoux*uy*onepuy*uz,            0.5*uxuz*onemux*oneptwouy,   0.25*uy*onepuy*onemuzuz,  -0.25*onemux*ux*onemuzuz,	  0.25*uxuy*onemux*onepuy,   -0.25*onemtwoux*onemuzuz,   0.25*onemtwoux*uy*onepuy,    0.25*oneptwouy*onemuzuz,           -0.5*uyuz*onepuy,   0.25*onemux*ux*oneptwouy,            0.5*uxuz*onemux,           0.5*onemtwoux*oneptwouy*uz,    0.25*onemuzuz,  -0.25*uy*onepuy,   0.25*onemux*ux,          -0.5*oneptwouy*uz,           0.5*onemtwoux*uz,   0.25*onemtwoux*oneptwouy,   0.25*onemtwoux,  -0.25*oneptwouy,          -0.5*uz, -0.25,
                           0.25*uxuz*onemux*onemuyuy*onemuz,   0.25*onemtwoux*onemuyuy*onemuz*uz,           -0.5*uxuyuz*onemux*onemuz,   0.25*onemux*ux*onemuyuy*onemtwouz,           -0.5*uyuz*onemtwoux*onemuz,    0.25*onemtwoux*onemuyuy*onemtwouz,	          -0.5*uxuy*onemux*onemtwouz,  -0.25*onemuyuy*onemuz*uz,  -0.25*uxuz*onemux*onemuz,	 -0.25*onemux*ux*onemuyuy,  -0.25*onemtwoux*onemuz*uz,   -0.25*onemtwoux*onemuyuy,            0.5*uyuz*onemuz,   -0.25*onemuyuy*onemtwouz,            0.5*uxuy*onemux,  -0.25*onemux*ux*onemtwouz,          -0.5*onemtwoux*uy*onemtwouz,   0.25*onemuz*uz,    0.25*onemuyuy,   0.25*onemux*ux,           0.5*uy*onemtwouz,  -0.25*onemtwoux*onemtwouz,           0.5*onemtwoux*uy,   0.25*onemtwoux,          -0.5*uy,   0.25*onemtwouz, -0.25,
                          -0.25*uxuz*onemux*onemuyuy*onepuz,  -0.25*onemtwoux*onemuyuy*uz*onepuz,            0.5*uxuyuz*onemux*onepuz,  -0.25*onemux*ux*onemuyuy*oneptwouz,	           0.5*uyuz*onemtwoux*onepuz,   -0.25*onemtwoux*onemuyuy*oneptwouz,	           0.5*uxuy*onemux*oneptwouz,   0.25*onemuyuy*uz*onepuz,   0.25*uxuz*onemux*onepuz,	 -0.25*onemux*ux*onemuyuy,   0.25*onemtwoux*uz*onepuz,   -0.25*onemtwoux*onemuyuy,           -0.5*uyuz*onepuz,    0.25*onemuyuy*oneptwouz,            0.5*uxuy*onemux,   0.25*onemux*ux*oneptwouz,           0.5*onemtwoux*uy*oneptwouz,  -0.25*uz*onepuz,    0.25*onemuyuy,   0.25*onemux*ux,          -0.5*uy*oneptwouz,   0.25*onemtwoux*oneptwouz,           0.5*onemtwoux*uy,   0.25*onemtwoux,          -0.5*uy,  -0.25*oneptwouz, -0.25,
                           0.25*uyuz*onemuxux*onemuy*onemuz,           -0.5*uxuyuz*onemuy*onemuz,   0.25*onemuxux*onemtwouy*onemuz*uz,   0.25*onemuxux*onemuy*uy*onemtwouz,	          -0.5*uxuz*onemtwouy*onemuz,           -0.5*uxuy*onemuy*onemtwouz,    0.25*onemuxux*onemtwouy*onemtwouz,  -0.25*uyuz*onemuy*onemuz,  -0.25*onemuxux*onemuz*uz,	 -0.25*onemuxux*onemuy*uy,            0.5*uxuz*onemuz,            0.5*uxuy*onemuy,  -0.25*onemtwouy*onemuz*uz,  -0.25*onemuy*uy*onemtwouz,   -0.25*onemuxux*onemtwouy,   -0.25*onemuxux*onemtwouz,          -0.5*ux*onemtwouy*onemtwouz,   0.25*onemuz*uz,   0.25*onemuy*uy,    0.25*onemuxux,  -0.25*onemtwouy*onemtwouz,           0.5*ux*onemtwouz,           0.5*ux*onemtwouy,          -0.5*ux,   0.25*onemtwouy,   0.25*onemtwouz, -0.25,
                          -0.25*uyuz*onemuxux*onemuy*onepuz,            0.5*uxuyuz*onemuy*onepuz,  -0.25*onemuxux*onemtwouy*uz*onepuz,  -0.25*onemuxux*onemuy*uy*oneptwouz,	           0.5*uxuz*onemtwouy*onepuz,            0.5*uxuy*onemuy*oneptwouz,   -0.25*onemuxux*onemtwouy*oneptwouz,   0.25*uyuz*onemuy*onepuz,   0.25*onemuxux*uz*onepuz,	 -0.25*onemuxux*onemuy*uy,           -0.5*uxuz*onepuz,            0.5*uxuy*onemuy,   0.25*onemtwouy*uz*onepuz,   0.25*onemuy*uy*oneptwouz,   -0.25*onemuxux*onemtwouy,    0.25*onemuxux*oneptwouz,           0.5*ux*onemtwouy*oneptwouz,  -0.25*uz*onepuz,   0.25*onemuy*uy,    0.25*onemuxux,   0.25*onemtwouy*oneptwouz,          -0.5*ux*oneptwouz,           0.5*ux*onemtwouy,          -0.5*ux,   0.25*onemtwouy,  -0.25*oneptwouz, -0.25,
                         -0.125*uxuyuz*onemux*onemuy*onemuz, -0.125*uyuz*onemtwoux*onemuy*onemuz, -0.125*uxuz*onemux*onemtwouy*onemuz, -0.125*uxuy*onemux*onemuy*onemtwouz,	-0.125*onemtwoux*onemtwouy*onemuz*uz, -0.125*onemtwoux*onemuy*uy*onemtwouz,	-0.125*onemux*ux*onemtwouy*onemtwouz,  0.125*uyuz*onemuy*onemuz,  0.125*uxuz*onemux*onemuz,	 0.125*uxuy*onemux*onemuy,  0.125*onemtwoux*onemuz*uz,  0.125*onemtwoux*onemuy*uy,  0.125*onemtwouy*onemuz*uz,  0.125*onemuy*uy*onemtwouz,  0.125*onemux*ux*onemtwouy,  0.125*onemux*ux*onemtwouz, -0.125*onemtwoux*onemtwouy*onemtwouz, -0.125*onemuz*uz, -0.125*onemuy*uy, -0.125*onemux*ux,  0.125*onemtwouy*onemtwouz,  0.125*onemtwoux*onemtwouz,  0.125*onemtwoux*onemtwouy, -0.125*onemtwoux, -0.125*onemtwouy, -0.125*onemtwouz, 0.125,
                          0.125*uxuyuz*onemux*onemuy*onepuz,  0.125*uyuz*onemtwoux*onemuy*onepuz,  0.125*uxuz*onemux*onemtwouy*onepuz,  0.125*uxuy*onemux*onemuy*oneptwouz,  0.125*onemtwoux*onemtwouy*uz*onepuz,  0.125*onemtwoux*onemuy*uy*oneptwouz,	 0.125*onemux*ux*onemtwouy*oneptwouz, -0.125*uyuz*onemuy*onepuz, -0.125*uxuz*onemux*onepuz,	 0.125*uxuy*onemux*onemuy, -0.125*onemtwoux*uz*onepuz,  0.125*onemtwoux*onemuy*uy, -0.125*onemtwouy*uz*onepuz, -0.125*onemuy*uy*oneptwouz,  0.125*onemux*ux*onemtwouy, -0.125*onemux*ux*oneptwouz,  0.125*onemtwoux*onemtwouy*oneptwouz,  0.125*uz*onepuz, -0.125*onemuy*uy, -0.125*onemux*ux, -0.125*onemtwouy*oneptwouz, -0.125*onemtwoux*oneptwouz,  0.125*onemtwoux*onemtwouy, -0.125*onemtwoux, -0.125*onemtwouy,  0.125*oneptwouz, 0.125,
                          0.125*uxuyuz*onemux*onepuy*onemuz,  0.125*uyuz*onemtwoux*onepuy*onemuz,  0.125*uxuz*onemux*oneptwouy*onemuz,  0.125*uxuy*onemux*onepuy*onemtwouz,  0.125*onemtwoux*oneptwouy*onemuz*uz,  0.125*onemtwoux*uy*onepuy*onemtwouz,	 0.125*onemux*ux*oneptwouy*onemtwouz, -0.125*uyuz*onepuy*onemuz,  0.125*uxuz*onemux*onemuz,	-0.125*uxuy*onemux*onepuy,  0.125*onemtwoux*onemuz*uz, -0.125*onemtwoux*uy*onepuy, -0.125*oneptwouy*onemuz*uz, -0.125*uy*onepuy*onemtwouz, -0.125*onemux*ux*oneptwouy,  0.125*onemux*ux*onemtwouz,  0.125*onemtwoux*oneptwouy*onemtwouz, -0.125*onemuz*uz,  0.125*uy*onepuy, -0.125*onemux*ux, -0.125*oneptwouy*onemtwouz,  0.125*onemtwoux*onemtwouz, -0.125*onemtwoux*oneptwouy, -0.125*onemtwoux,  0.125*oneptwouy, -0.125*onemtwouz, 0.125,
                         -0.125*uxuyuz*onemux*onepuy*onepuz, -0.125*uyuz*onemtwoux*onepuy*onepuz, -0.125*uxuz*onemux*oneptwouy*onepuz, -0.125*uxuy*onemux*onepuy*oneptwouz,	-0.125*onemtwoux*oneptwouy*uz*onepuz, -0.125*onemtwoux*uy*onepuy*oneptwouz,	-0.125*onemux*ux*oneptwouy*oneptwouz,  0.125*uyuz*onepuy*onepuz, -0.125*uxuz*onemux*onepuz,	-0.125*uxuy*onemux*onepuy, -0.125*onemtwoux*uz*onepuz, -0.125*onemtwoux*uy*onepuy,  0.125*oneptwouy*uz*onepuz,  0.125*uy*onepuy*oneptwouz, -0.125*onemux*ux*oneptwouy, -0.125*onemux*ux*oneptwouz, -0.125*onemtwoux*oneptwouy*oneptwouz,  0.125*uz*onepuz,  0.125*uy*onepuy, -0.125*onemux*ux,  0.125*oneptwouy*oneptwouz, -0.125*onemtwoux*oneptwouz, -0.125*onemtwoux*oneptwouy, -0.125*onemtwoux,  0.125*oneptwouy,  0.125*oneptwouz, 0.125,
                            0.5*ux*onepux*onemuyuy*onemuzuz,     0.5*oneptwoux*onemuyuy*onemuzuz,               -uxuy*onepux*onemuzuz,               -uxuz*onepux*onemuyuy,               -oneptwoux*uy*onemuzuz,               -oneptwoux*onemuyuy*uz,                    2.0*uxuyuz*onepux,     0.5*onemuyuy*onemuzuz,   -0.5*ux*onepux*onemuzuz,	  -0.5*ux*onepux*onemuyuy,    -0.5*oneptwoux*onemuzuz,    -0.5*oneptwoux*onemuyuy,               -uy*onemuzuz,               -onemuyuy*uz,                uxuy*onepux,                uxuz*onepux,                   2.0*uyuz*oneptwoux,    -0.5*onemuzuz,    -0.5*onemuyuy,    0.5*ux*onepux,                   2.0*uyuz,               oneptwoux*uz,               oneptwoux*uy,    0.5*oneptwoux,               uy,               uz,   0.5,
                            0.5*onemuxux*uy*onepuy*onemuzuz,               -uxuy*onepuy*onemuzuz,     0.5*onemuxux*oneptwouy*onemuzuz,               -uyuz*onemuxux*onepuy,               -ux*oneptwouy*onemuzuz,                    2.0*uxuyuz*onepuy,               -onemuxux*oneptwouy*uz,   -0.5*uy*onepuy*onemuzuz,     0.5*onemuxux*onemuzuz,   -0.5*onemuxux*uy*onepuy,               -ux*onemuzuz,                uxuy*onepuy,    -0.5*oneptwouy*onemuzuz,                uyuz*onepuy,    -0.5*onemuxux*oneptwouy,               -onemuxux*uz,                   2.0*uxuz*oneptwouy,    -0.5*onemuzuz,    0.5*uy*onepuy,    -0.5*onemuxux,               oneptwouy*uz,                   2.0*uxuz,               ux*oneptwouy,               ux,    0.5*oneptwouy,               uz,   0.5,
                            0.5*onemuxux*onemuyuy*uz*onepuz,               -uxuz*onemuyuy*onepuz,               -uyuz*onemuxux*onepuz,     0.5*onemuxux*onemuyuy*oneptwouz,                    2.0*uxuyuz*onepuz,               -ux*onemuyuy*oneptwouz,               -onemuxux*uy*oneptwouz,   -0.5*onemuyuy*uz*onepuz,   -0.5*onemuxux*uz*onepuz,	    0.5*onemuxux*onemuyuy,                uxuz*onepuz,               -ux*onemuyuy,                uyuz*onepuz,    -0.5*onemuyuy*oneptwouz,               -onemuxux*uy,    -0.5*onemuxux*oneptwouz,                   2.0*uxuy*oneptwouz,    0.5*uz*onepuz,    -0.5*onemuyuy,    -0.5*onemuxux,               uy*oneptwouz,               ux*oneptwouz,                   2.0*uxuy,               ux,               uy,    0.5*oneptwouz,   0.5,
                           0.25*uxuy*onepux*onepuy*onemuzuz,   0.25*oneptwoux*uy*onepuy*onemuzuz,   0.25*ux*onepux*oneptwouy*onemuzuz,           -0.5*uxuyuz*onepux*onepuy,    0.25*oneptwoux*oneptwouy*onemuzuz,           -0.5*uyuz*oneptwoux*onepuy,           -0.5*uxuz*onepux*oneptwouy,   0.25*uy*onepuy*onemuzuz,   0.25*ux*onepux*onemuzuz,  -0.25*uxuy*onepux*onepuy,    0.25*oneptwoux*onemuzuz,  -0.25*oneptwoux*uy*onepuy,    0.25*oneptwouy*onemuzuz,           -0.5*uyuz*onepuy,  -0.25*ux*onepux*oneptwouy,           -0.5*uxuz*onepux,          -0.5*oneptwoux*oneptwouy*uz,    0.25*onemuzuz,  -0.25*uy*onepuy,  -0.25*ux*onepux,          -0.5*oneptwouy*uz,          -0.5*oneptwoux*uz,  -0.25*oneptwoux*oneptwouy,  -0.25*oneptwoux,  -0.25*oneptwouy,          -0.5*uz, -0.25,
                          -0.25*uxuy*onepux*onemuy*onemuzuz,  -0.25*oneptwoux*onemuy*uy*onemuzuz,  -0.25*ux*onepux*onemtwouy*onemuzuz,            0.5*uxuyuz*onepux*onemuy,   -0.25*oneptwoux*onemtwouy*onemuzuz,            0.5*uyuz*oneptwoux*onemuy,            0.5*uxuz*onepux*onemtwouy,  -0.25*onemuy*uy*onemuzuz,   0.25*ux*onepux*onemuzuz,	  0.25*uxuy*onepux*onemuy,    0.25*oneptwoux*onemuzuz,   0.25*oneptwoux*onemuy*uy,   -0.25*onemtwouy*onemuzuz,            0.5*uyuz*onemuy,   0.25*ux*onepux*onemtwouy,           -0.5*uxuz*onepux,           0.5*oneptwoux*onemtwouy*uz,    0.25*onemuzuz,   0.25*onemuy*uy,  -0.25*ux*onepux,           0.5*onemtwouy*uz,          -0.5*oneptwoux*uz,   0.25*oneptwoux*onemtwouy,  -0.25*oneptwoux,   0.25*onemtwouy,          -0.5*uz, -0.25,
                           0.25*uxuz*onepux*onemuyuy*onepuz,   0.25*oneptwoux*onemuyuy*uz*onepuz,           -0.5*uxuyuz*onepux*onepuz,   0.25*ux*onepux*onemuyuy*oneptwouz,           -0.5*uyuz*oneptwoux*onepuz,    0.25*oneptwoux*onemuyuy*oneptwouz,	          -0.5*uxuy*onepux*oneptwouz,   0.25*onemuyuy*uz*onepuz,  -0.25*uxuz*onepux*onepuz,	  0.25*ux*onepux*onemuyuy,  -0.25*oneptwoux*uz*onepuz,    0.25*oneptwoux*onemuyuy,           -0.5*uyuz*onepuz,    0.25*onemuyuy*oneptwouz,           -0.5*uxuy*onepux,  -0.25*ux*onepux*oneptwouz,          -0.5*oneptwoux*uy*oneptwouz,  -0.25*uz*onepuz,    0.25*onemuyuy,  -0.25*ux*onepux,          -0.5*uy*oneptwouz,  -0.25*oneptwoux*oneptwouz,          -0.5*oneptwoux*uy,  -0.25*oneptwoux,          -0.5*uy,  -0.25*oneptwouz, -0.25,
                          -0.25*uxuz*onepux*onemuyuy*onemuz,  -0.25*oneptwoux*onemuyuy*onemuz*uz,            0.5*uxuyuz*onepux*onemuz,  -0.25*ux*onepux*onemuyuy*onemtwouz,            0.5*uyuz*oneptwoux*onemuz,   -0.25*oneptwoux*onemuyuy*onemtwouz,	           0.5*uxuy*onepux*onemtwouz,  -0.25*onemuyuy*onemuz*uz,   0.25*uxuz*onepux*onemuz,	  0.25*ux*onepux*onemuyuy,   0.25*oneptwoux*onemuz*uz,    0.25*oneptwoux*onemuyuy,            0.5*uyuz*onemuz,   -0.25*onemuyuy*onemtwouz,           -0.5*uxuy*onepux,   0.25*ux*onepux*onemtwouz,           0.5*oneptwoux*uy*onemtwouz,   0.25*onemuz*uz,    0.25*onemuyuy,  -0.25*ux*onepux,           0.5*uy*onemtwouz,   0.25*oneptwoux*onemtwouz,          -0.5*oneptwoux*uy,  -0.25*oneptwoux,          -0.5*uy,   0.25*onemtwouz, -0.25,
                           0.25*uyuz*onemuxux*onepuy*onepuz,           -0.5*uxuyuz*onepuy*onepuz,   0.25*onemuxux*oneptwouy*uz*onepuz,   0.25*onemuxux*uy*onepuy*oneptwouz,	          -0.5*uxuz*oneptwouy*onepuz,           -0.5*uxuy*onepuy*oneptwouz,    0.25*onemuxux*oneptwouy*oneptwouz,  -0.25*uyuz*onepuy*onepuz,   0.25*onemuxux*uz*onepuz,	  0.25*onemuxux*uy*onepuy,           -0.5*uxuz*onepuz,           -0.5*uxuy*onepuy,  -0.25*oneptwouy*uz*onepuz,  -0.25*uy*onepuy*oneptwouz,    0.25*onemuxux*oneptwouy,    0.25*onemuxux*oneptwouz,          -0.5*ux*oneptwouy*oneptwouz,  -0.25*uz*onepuz,  -0.25*uy*onepuy,    0.25*onemuxux,  -0.25*oneptwouy*oneptwouz,          -0.5*ux*oneptwouz,          -0.5*ux*oneptwouy,          -0.5*ux,  -0.25*oneptwouy,  -0.25*oneptwouz, -0.25,
                          -0.25*uyuz*onemuxux*onepuy*onemuz,            0.5*uxuyuz*onepuy*onemuz,  -0.25*onemuxux*oneptwouy*onemuz*uz,  -0.25*onemuxux*uy*onepuy*onemtwouz,	           0.5*uxuz*oneptwouy*onemuz,            0.5*uxuy*onepuy*onemtwouz,   -0.25*onemuxux*oneptwouy*onemtwouz,   0.25*uyuz*onepuy*onemuz,  -0.25*onemuxux*onemuz*uz,	  0.25*onemuxux*uy*onepuy,            0.5*uxuz*onemuz,           -0.5*uxuy*onepuy,   0.25*oneptwouy*onemuz*uz,   0.25*uy*onepuy*onemtwouz,    0.25*onemuxux*oneptwouy,   -0.25*onemuxux*onemtwouz,           0.5*ux*oneptwouy*onemtwouz,   0.25*onemuz*uz,  -0.25*uy*onepuy,    0.25*onemuxux,   0.25*oneptwouy*onemtwouz,           0.5*ux*onemtwouz,          -0.5*ux*oneptwouy,          -0.5*ux,  -0.25*oneptwouy,   0.25*onemtwouz, -0.25,
                          0.125*uxuyuz*onepux*onepuy*onepuz,  0.125*uyuz*oneptwoux*onepuy*onepuz,  0.125*uxuz*onepux*oneptwouy*onepuz,  0.125*uxuy*onepux*onepuy*oneptwouz,	 0.125*oneptwoux*oneptwouy*uz*onepuz,  0.125*oneptwoux*uy*onepuy*oneptwouz,	 0.125*ux*onepux*oneptwouy*oneptwouz,  0.125*uyuz*onepuy*onepuz,  0.125*uxuz*onepux*onepuz,	 0.125*uxuy*onepux*onepuy,  0.125*oneptwoux*uz*onepuz,  0.125*oneptwoux*uy*onepuy,  0.125*oneptwouy*uz*onepuz,  0.125*uy*onepuy*oneptwouz,  0.125*ux*onepux*oneptwouy,  0.125*ux*onepux*oneptwouz,  0.125*oneptwoux*oneptwouy*oneptwouz,  0.125*uz*onepuz,  0.125*uy*onepuy,  0.125*ux*onepux,  0.125*oneptwouy*oneptwouz,  0.125*oneptwoux*oneptwouz,  0.125*oneptwoux*oneptwouy,  0.125*oneptwoux,  0.125*oneptwouy,  0.125*oneptwouz, 0.125,
                         -0.125*uxuyuz*onepux*onepuy*onemuz, -0.125*uyuz*oneptwoux*onepuy*onemuz, -0.125*uxuz*onepux*oneptwouy*onemuz, -0.125*uxuy*onepux*onepuy*onemtwouz,	-0.125*oneptwoux*oneptwouy*onemuz*uz, -0.125*oneptwoux*uy*onepuy*onemtwouz,	-0.125*ux*onepux*oneptwouy*onemtwouz, -0.125*uyuz*onepuy*onemuz, -0.125*uxuz*onepux*onemuz,	 0.125*uxuy*onepux*onepuy, -0.125*oneptwoux*onemuz*uz,  0.125*oneptwoux*uy*onepuy, -0.125*oneptwouy*onemuz*uz, -0.125*uy*onepuy*onemtwouz,  0.125*ux*onepux*oneptwouy, -0.125*ux*onepux*onemtwouz, -0.125*oneptwoux*oneptwouy*onemtwouz, -0.125*onemuz*uz,  0.125*uy*onepuy,  0.125*ux*onepux, -0.125*oneptwouy*onemtwouz, -0.125*oneptwoux*onemtwouz,  0.125*oneptwoux*oneptwouy,  0.125*oneptwoux,  0.125*oneptwouy, -0.125*onemtwouz, 0.125,
                         -0.125*uxuyuz*onepux*onemuy*onepuz, -0.125*uyuz*oneptwoux*onemuy*onepuz, -0.125*uxuz*onepux*onemtwouy*onepuz, -0.125*uxuy*onepux*onemuy*oneptwouz,	-0.125*oneptwoux*onemtwouy*uz*onepuz, -0.125*oneptwoux*onemuy*uy*oneptwouz,	-0.125*ux*onepux*onemtwouy*oneptwouz, -0.125*uyuz*onemuy*onepuz,  0.125*uxuz*onepux*onepuz,	-0.125*uxuy*onepux*onemuy,  0.125*oneptwoux*uz*onepuz, -0.125*oneptwoux*onemuy*uy, -0.125*onemtwouy*uz*onepuz, -0.125*onemuy*uy*oneptwouz, -0.125*ux*onepux*onemtwouy,  0.125*ux*onepux*oneptwouz, -0.125*oneptwoux*onemtwouy*oneptwouz,  0.125*uz*onepuz, -0.125*onemuy*uy,  0.125*ux*onepux, -0.125*onemtwouy*oneptwouz,  0.125*oneptwoux*oneptwouz, -0.125*oneptwoux*onemtwouy,  0.125*oneptwoux, -0.125*onemtwouy,  0.125*oneptwouz, 0.125,
                          0.125*uxuyuz*onepux*onemuy*onemuz,  0.125*uyuz*oneptwoux*onemuy*onemuz,  0.125*uxuz*onepux*onemtwouy*onemuz,  0.125*uxuy*onepux*onemuy*onemtwouz,	 0.125*oneptwoux*onemtwouy*onemuz*uz,  0.125*oneptwoux*onemuy*uy*onemtwouz,  0.125*ux*onepux*onemtwouy*onemtwouz,  0.125*uyuz*onemuy*onemuz, -0.125*uxuz*onepux*onemuz,	-0.125*uxuy*onepux*onemuy, -0.125*oneptwoux*onemuz*uz, -0.125*oneptwoux*onemuy*uy,  0.125*onemtwouy*onemuz*uz,  0.125*onemuy*uy*onemtwouz, -0.125*ux*onepux*onemtwouy, -0.125*ux*onepux*onemtwouz,  0.125*oneptwoux*onemtwouy*onemtwouz, -0.125*onemuz*uz, -0.125*onemuy*uy,  0.125*ux*onepux,  0.125*onemtwouy*onemtwouz, -0.125*oneptwoux*onemtwouz, -0.125*oneptwoux*onemtwouy,  0.125*oneptwoux, -0.125*onemtwouy, -0.125*onemtwouz, 0.125 };
    std::copy (shift, shift+729, rcsh);
    std::copy (shinv, shinv+729, rcshinv);
  }
  else if(lbdm.rank ==0) {
    cout << "the cascaded LBE scheme for D" << lbsy.nd << "Q" << lbsy.nq << " model has not been defined" << endl;
    if(lbsy.nd == 2)
      cout << "the D2Q9 model can be used" << endl;
    else
      cout << "the D3Q19 or D3Q27 models can be used" << endl;
    exit(1);
  }
  return 0;
}

int fGetCentralMomentForceGuo(double *source, double *v, double *force)
{

  // calculate Guo forcing terms in terms of cemtral moments for CLBE collision schemes

  const double c1 = 1.0/3.0;
  const double c2 = 2.0/3.0;
  const double c3 = 1.0/9.0;

  double vxvx = v[0] * v[0];
  double vyvy = v[1] * v[1];
  double vzvz = v[2] * v[2];
  double vxvy = v[0] * v[1];
  double vxvz = v[0] * v[2];
  double vyvz = v[1] * v[2];
    
  if(lbsy.nq == 9) {
    // D2Q9
    source[0] = 0.0;
    source[1] = force[0];
    source[2] = force[1];
    source[3] = 0.0;
    source[4] = 0.0;
    source[5] = 0.0;
    source[6] = force[1] * (c1 - vxvx) - 2.0 * vxvy * force[0];
    source[7] = force[0] * (c1 - vyvy) - 2.0 * vxvy * force[1];
    source[8] = 4.0 * vxvy * (v[1] * force[0] + v[0] * force[1]);
  }
  else if(lbsy.nq == 19) {
    // D3Q19
    source[0]  = 0.0;
    source[1]  = force[0];
    source[2]  = force[1];
    source[3]  = force[2];
    source[4]  = 0.0;
    source[5]  = 0.0;
    source[6]  = 0.0;
    source[7]  = 0.0;
    source[8]  = 0.0;
    source[9]  = 0.0;
    source[10] = force[0] * (c1 - vyvy) - 2.0 * vxvy * force[1];
    source[11] = force[0] * (c1 - vzvz) - 2.0 * vxvz * force[2];
    source[12] = force[1] * (c1 - vxvx) - 2.0 * vxvy * force[0];
    source[13] = force[2] * (c1 - vxvx) - 2.0 * vxvz * force[0];
    source[14] = force[1] * (c1 - vzvz) - 2.0 * vyvz * force[2];
    source[15] = force[2] * (c1 - vyvy) - 2.0 * vyvz * force[1];
    source[16] = 4.0 * vxvy * (v[1] * force[0] + v[0] * force[1]) - c1 * v[2] * force[2];
    source[17] = 4.0 * vxvz * (v[2] * force[0] + v[0] * force[2]) - c1 * v[1] * force[1];
    source[18] = 4.0 * vyvz * (v[2] * force[1] + v[1] * force[2]) - c1 * v[0] * force[0];
  }
  else if(lbsy.nq == 27) {
    source[0]  = 0.0;
    source[1]  = force[0];
    source[2]  = force[1];
    source[3]  = force[2];
    source[4]  = 0.0;
    source[5]  = 0.0;
    source[6]  = 0.0;
    source[7]  = 0.0;
    source[8]  = 0.0;
    source[9]  = 0.0;
    source[10] = force[0] * (c1 - vyvy) - 2.0 * vxvy * force[1];
    source[11] = force[0] * (c1 - vzvz) - 2.0 * vxvz * force[2];
    source[12] = force[1] * (c1 - vxvx) - 2.0 * vxvy * force[0];
    source[13] = force[2] * (c1 - vxvx) - 2.0 * vxvz * force[0];
    source[14] = force[1] * (c1 - vzvz) - 2.0 * vyvz * force[2];
    source[15] = force[2] * (c1 - vyvy) - 2.0 * vyvz * force[1];
    source[16] = -(vyvz * force[0] + vxvz * force[1] + vxvy * force[2]);
    source[17] = 4.0 * vxvy * (v[1] * force[0] + v[0] * force[1]);
    source[18] = 4.0 * vxvz * (v[2] * force[0] + v[0] * force[2]);
    source[19] = 4.0 * vyvz * (v[2] * force[1] + v[1] * force[2]);
    source[20] = 2.0 * v[0] * (2.0 * vyvz * force[0] + vxvz * force[1] + vxvy * force[2]);
    source[21] = 2.0 * v[1] * (vyvz * force[0] + 2.0 * vxvz * force[1] + vxvy * force[2]);
    source[22] = 2.0 * v[2] * (vyvz * force[0] + vxvz * force[1] + 2.0 * vxvy * force[2]);
    source[23] = force[0] * (c3 - c1 * (vyvy + vzvz) - 3.0*vyvy*vzvz) - (v[2] * force[1] + v[1] * force[2]) * (c2 * v[0] + 6.0*v[0]*vyvz);
    source[24] = force[1] * (c3 - c1 * (vxvx + vzvz) - 3.0*vxvx*vzvz) - (v[2] * force[0] + v[0] * force[2]) * (c2 * v[1] + 6.0*v[1]*vxvz);
    source[25] = force[2] * (c3 - c1 * (vxvx + vyvy) - 3.0*vxvx*vyvy) - (v[1] * force[0] + v[0] * force[1]) * (c2 * v[2] + 6.0*v[2]*vxvy);
    source[26] = c1*(source[16]+source[17]+source[18]) + 8.0*vxvy*v[2]*(vyvz*force[0]+vxvz*force[1]+vxvy*force[2]);
  }
  else if(lbdm.rank ==0) {
    cout << "the cascaded LBE scheme for D" << lbsy.nd << "Q" << lbsy.nq << " model has not been defined" << endl;
    if(lbsy.nd == 2)
      cout << "the D2Q9 model can be used" << endl;
    else
      cout << "the D3Q19 or D3Q27 models can be used" << endl;
    exit(1);
  }
  return 0;
}


int fGetCentralMomentForceHe(double *source, double *force)
{

  // calculate He forcing terms in terms of cemtral moments for CLBE collision schemes

  const double c1 = 1.0/3.0;
  const double c3 = 1.0/9.0;

  if(lbsy.nq == 9) {
    // D2Q9
    source[0] = 0.0;
    source[1] = force[0];
    source[2] = force[1];
    source[3] = 0.0;
    source[4] = 0.0;
    source[5] = 0.0;
    source[6] = c1 * force[1];
    source[7] = c1 * force[0];
    source[8] = 0.0;
  }
  else if(lbsy.nq == 19) {
    // D3Q19
    source[0]  = 0.0;
    source[1]  = force[0];
    source[2]  = force[1];
    source[3]  = force[2];
    source[4]  = 0.0;
    source[5]  = 0.0;
    source[6]  = 0.0;
    source[7]  = 0.0;
    source[8]  = 0.0;
    source[9]  = 0.0;
    source[10] = c1 * force[0];
    source[11] = c1 * force[0];
    source[12] = c1 * force[1];
    source[13] = c1 * force[2];
    source[14] = c1 * force[1];
    source[15] = c1 * force[2];
    source[16] = 0.0;
    source[17] = 0.0;
    source[18] = 0.0;
  }
  else if(lbsy.nq == 27) {
    source[0]  = 0.0;
    source[1]  = force[0];
    source[2]  = force[1];
    source[3]  = force[2];
    source[4]  = 0.0;
    source[5]  = 0.0;
    source[6]  = 0.0;
    source[7]  = 0.0;
    source[8]  = 0.0;
    source[9]  = 0.0;
    source[10] = c1 * force[0];
    source[11] = c1 * force[0];
    source[12] = c1 * force[1];
    source[13] = c1 * force[2];
    source[14] = c1 * force[1];
    source[15] = c1 * force[2];
    source[16] = 0.0;
    source[17] = 0.0;
    source[18] = 0.0;
    source[19] = 0.0;
    source[20] = 0.0;
    source[21] = 0.0;
    source[22] = 0.0;
    source[23] = c3 * force[0];
    source[24] = c3 * force[1];
    source[25] = c3 * force[2];
    source[26] = 0.0;
  }
  else if(lbdm.rank ==0) {
    cout << "the cascaded LBE scheme for D" << lbsy.nd << "Q" << lbsy.nq << " model has not been defined" << endl;
    if(lbsy.nd == 2)
      cout << "the D2Q9 model can be used" << endl;
    else
      cout << "the D3Q19 or D3Q27 models can be used" << endl;
    exit(1);
  }
  return 0;
}


int fGetCLBECollide(double *collide, double omegashear, double omegabulk, double omegathree, double omegafour)
{

  // calculate collision parameters for CLBE collision schemes

  const double c1 = 1.0/3.0;
  double omegaplus;
    
  if(lbsy.nq == 9) {
    // D2Q9
    omegaplus = 0.5 * (omegabulk + omegashear);
    collide[0] = 1.0;         // fixed parameter for conserved moment (density)
    collide[1] = 1.0;         // fixed parameter for conserved moment (x-momentum)
    collide[2] = 1.0;         // fixed parameter for conserved moment (y-momentum)
    collide[3] = omegaplus;
    collide[4] = omegaplus;
    collide[5] = omegashear;
    collide[6] = omegathree;
    collide[7] = omegathree;
    collide[8] = omegafour;
  }
  else if(lbsy.nq == 19) {
    // D3Q19
    omegaplus = c1 * (omegabulk + 2.0 * omegashear);
    collide[0]  = 1.0;        // fixed parameter for conserved moment (density)
    collide[1]  = 1.0;        // fixed parameter for conserved moment (x-momentum)
    collide[2]  = 1.0;        // fixed parameter for conserved moment (y-momentum)
    collide[3]  = 1.0;        // fixed parameter for conserved moment (z-momentum)
    collide[4]  = omegashear;
    collide[5]  = omegashear;
    collide[6]  = omegashear;
    collide[7]  = omegaplus;
    collide[8]  = omegaplus;
    collide[9]  = omegaplus;
    collide[10] = omegathree;
    collide[11] = omegathree;
    collide[12] = omegathree;
    collide[13] = omegathree;
    collide[14] = omegathree;
    collide[15] = omegathree;
    collide[16] = omegafour;
    collide[17] = omegafour;
    collide[18] = omegafour;
  }
  else if(lbsy.nq == 27) {
    // D3Q27
    omegaplus = c1 * (omegabulk + 2.0 * omegashear);
    collide[0]  = 1.0;        // fixed parameter for conserved moment (density)
    collide[1]  = 1.0;        // fixed parameter for conserved moment (x-momentum)
    collide[2]  = 1.0;        // fixed parameter for conserved moment (y-momentum)
    collide[3]  = 1.0;        // fixed parameter for conserved moment (z-momentum)
    collide[4]  = omegashear;
    collide[5]  = omegashear;
    collide[6]  = omegashear;
    collide[7]  = omegaplus;
    collide[8]  = omegaplus;
    collide[9]  = omegaplus;
    collide[10] = omegathree;
    collide[11] = omegathree;
    collide[12] = omegathree;
    collide[13] = omegathree;
    collide[14] = omegathree;
    collide[15] = omegathree;
    collide[16] = 1.0;         // fixed parameter for higher-order moment
    collide[17] = omegafour;
    collide[18] = omegafour;
    collide[19] = omegafour;
    collide[20] = 1.0;         // fixed parameter for higher-order moment
    collide[21] = 1.0;         // fixed parameter for higher-order moment
    collide[22] = 1.0;         // fixed parameter for higher-order moment
    collide[23] = 1.0;         // fixed parameter for higher-order moment
    collide[24] = 1.0;         // fixed parameter for higher-order moment
    collide[25] = 1.0;         // fixed parameter for higher-order moment
    collide[26] = 1.0;         // fixed parameter for higher-order moment
}
  else if(lbdm.rank ==0) {
    cout << "the cascaded LBE scheme for D" << lbsy.nd << "Q" << lbsy.nq << " model has not been defined" << endl;
    if(lbsy.nd == 2)
      cout << "the D2Q9 model can be used" << endl;
    else
      cout << "the D3Q19 or D3Q27 models can be used" << endl;
    exit(1);
  }
  return 0;
}

// Standard fluid collisions

int fSiteFluidCollisionCLBE(double* startpos, double *sitespeed, double *omega, double *omegabulk, double *omega3, double *omega4, double *rho, double* bodyforce)
{
  
  // calculate fluid collisions at grid point: uses cascaded LBE scheme

  int offset;
  double speed[3], meq[lbsy.nq];
  double cenmoment[lbsy.nq], collide[lbsy.nq], momcorr[lbsy.nq];
  double shift[lbsy.nq*lbsy.nq], invshift[lbsy.nq*lbsy.nq];
  double invmassrelax, omegaminus, mxx, myy, mzz;
  double *pt2 = &startpos[0];
  double *pt3 = &bodyforce[0];
  int qdim = lbsy.nf+lbsy.nc+lbsy.nt;

  for(int k=0; k<lbsy.nf; k++) {
    invmassrelax = fReciprocal(omega[k]*rho[k]);
    speed[0] = sitespeed[0] + pt3[3*k]   * invmassrelax;
    speed[1] = sitespeed[1] + pt3[3*k+1] * invmassrelax;
    speed[2] = sitespeed[2] + pt3[3*k+2] * invmassrelax;
    fGetCentralMomentEquilibriumF(&meq[0], rho[k]);
    fGetCentralMomentTransformMatrix(shift, invshift, speed);
    fGetCLBECollide(collide, omega[k], omegabulk[k], omega3[k], omega4[k]);
    // transform distribution functions to central moments
    for(int i=0; i<lbsy.nq; i++) {
      cenmoment[i] = 0.0;
      momcorr[i] = 0.0;
      for(int j=0; j<lbsy.nq; j++) {
        cenmoment[i] += pt2[j*qdim+k] * shift[i*lbsy.nq+j];
      }
    }
    // find antisymmetric corrections required for second-order moments
    offset = 3 + 4 * (lbsy.nd - 2);
    omegaminus = (omegabulk[k] - omega[k]) / ((double)lbsy.nd);
    mxx = omegaminus * (meq[offset]   - cenmoment[offset]  );
    myy = omegaminus * (meq[offset+1] - cenmoment[offset+1]);
    mzz = (lbsy.nd>2)?(omegaminus*(meq[offset+2] - cenmoment[offset+2])):0.0;
    momcorr[offset] = myy + mzz;
    momcorr[offset+1] = mxx + mzz;
    momcorr[offset+2] = (lbsy.nd>2)?(mxx+myy):0.0;
    // collide central moments (including antisymmetric corrections)
    // and shift back into post-collision distribution functions
    for(int i=0; i<lbsy.nq; i++) {
      cenmoment[i] = (1.0 - collide[i]) * cenmoment[i] + collide[i] * meq[i] + momcorr[i];
    }
    for(int i=0; i<lbsy.nq; i++) {
      pt2[i*qdim+k] = 0.0;
      for(int j=0; j<lbsy.nq; j++) {
        pt2[i*qdim+k] += cenmoment[j] * invshift[i*lbsy.nq+j];
      }
    }
  }

  pt2 = NULL;
  pt3 = NULL;  
  return 0;
}


int fSiteFluidCollisionCLBEEDM(double* startpos, double *sitespeed, double *omega, double *omegabulk, double *omega3, double *omega4, double *rho, double* bodyforce)
{
  
  // calculate fluid collisions at grid point: uses cascaded LBE scheme
  // with Exact Difference Method forcing term

  int offset;
  double dv[3], meq[lbsy.nq];
  double cenmoment[lbsy.nq], collide[lbsy.nq], momcorr[lbsy.nq];
  double shift[lbsy.nq*lbsy.nq], invshift[lbsy.nq*lbsy.nq];
  double invmass, omegaminus, mxx, myy, mzz;
  double modv,eixeix,eiyeiy,eizeiz,eixux,eiyuy,eizuz,eixdux,eiyduy,eizduz,vxvx,vyvy,vzvz;
  double *pt2 = &startpos[0];
  double *pt3 = &bodyforce[0];
  int qdim = lbsy.nf+lbsy.nc+lbsy.nt;

  fGetCentralMomentTransformMatrix(shift, invshift, sitespeed);

  for(int k=0; k<lbsy.nf; k++) {
    invmass = fReciprocal(rho[k]);
    dv[0] = pt3[3*k]   * invmass;
    dv[1] = pt3[3*k+1] * invmass;
    dv[2] = pt3[3*k+2] * invmass;
    modv = dv[0]*(2.0*sitespeed[0]+dv[0]) + dv[1]*(2.0*sitespeed[1]+dv[1]) + dv[2]*(2.0*sitespeed[2]+dv[2]);
    fGetCentralMomentEquilibriumF(&meq[0], rho[k]);
    fGetCLBECollide(collide, omega[k], omegabulk[k], omega3[k], omega4[k]);
    // transform distribution functions to central moments
    for(int i=0; i<lbsy.nq; i++) {
      cenmoment[i] = 0.0;
      momcorr[i] = 0.0;
      for(int j=0; j<lbsy.nq; j++) {
        cenmoment[i] += pt2[j*qdim+k] * shift[i*lbsy.nq+j];
      }
    }
    // find antisymmetric corrections required for second-order moments
    offset = 3 + 4 * (lbsy.nd - 2);
    omegaminus = (omegabulk[k] - omega[k]) / ((double)lbsy.nd);
    mxx = omegaminus * (meq[offset]   - cenmoment[offset]  );
    myy = omegaminus * (meq[offset+1] - cenmoment[offset+1]);
    mzz = (lbsy.nd>2)?(omegaminus*(meq[offset+2] - cenmoment[offset+2])):0.0;
    momcorr[offset] = myy + mzz;
    momcorr[offset+1] = mxx + mzz;
    momcorr[offset+2] = (lbsy.nd>2)?(mxx+myy):0.0;
    // collide central moments (including antisymmetric corrections)
    // and shift back into post-collision distribution functions,
    // adding third-order EDM forcing terms
    vxvx = (sitespeed[0]+dv[0])*(sitespeed[0]+dv[0]);
    vyvy = (sitespeed[1]+dv[1])*(sitespeed[1]+dv[1]);
    vzvz = (sitespeed[2]+dv[2])*(sitespeed[2]+dv[2]);
    for(int i=0; i<lbsy.nq; i++) {
      cenmoment[i] = (1.0 - collide[i]) * cenmoment[i] + collide[i] * meq[i] + momcorr[i];
    }
    for(int i=0; i<lbsy.nq; i++) {
      eixeix = lbvx[i] * lbvx[i];
      eiyeiy = lbvy[i] * lbvy[i];
      eizeiz = lbvz[i] * lbvz[i];
      eixux =  lbvx[i] * sitespeed[0];
      eiyuy =  lbvy[i] * sitespeed[1];
      eizuz =  lbvz[i] * sitespeed[2];
      eixdux = lbvx[i] * dv[0];
      eiyduy = lbvy[i] * dv[1];
      eizduz = lbvz[i] * dv[2];
      pt2[i*qdim+k] = rho[k] * lbw[i] * (3.0 * (eixdux+eiyduy+eizduz) +
                                         4.5 * (eixdux*(eixdux+2.0*(eixux+eiyuy+eizuz+eiyduy+eizduz)) +
                                         eiyduy*(eiyduy+2.0*(eixux+eiyuy+eizuz+eizduz)) +
                                         eizduz*(eizduz+2.0*(eixux+eiyuy+eizuz)) +
                                         (3.0*eixeix-1.0)*((eiyduy+eizduz)*vxvx+(eiyuy+eizuz)*dv[0]*(2.0+dv[0])) +
                                         (3.0*eiyeiy-1.0)*((eixdux+eizduz)*vyvy+(eixux+eizuz)*dv[1]*(2.0+dv[1])) +
                                         (3.0*eizeiz-1.0)*((eixdux+eiyduy)*vzvz+(eixux+eiyuy)*dv[2]*(2.0+dv[2])) +
                                         6.0*(eixdux*(eiyuy+eiyduy)*(eizuz+eizduz)+eixux*(eiyduy*(eizuz+eizduz)+eiyuy*eizduz))) - 1.5*modv);
      for(int j=0; j<lbsy.nq; j++) {
        pt2[i*qdim+k] += cenmoment[j] * invshift[i*lbsy.nq+j];
      }
    }
  }

  pt2 = NULL;
  pt3 = NULL;
  return 0;
}


int fSiteFluidCollisionCLBEGuo(double* startpos, double *sitespeed, double *omega, double *omegabulk, double *omega3, double *omega4, double *rho, double* bodyforce)
{
  
  // calculate fluid collisions at grid point: uses cascaded LBE scheme
  // with Guo-based forcing terms

  int offset;
  double speed[3], force[3], meq[lbsy.nq];
  double cenmoment[lbsy.nq], collide[lbsy.nq], source[lbsy.nq], momcorr[lbsy.nq];
  double shift[lbsy.nq*lbsy.nq], invshift[lbsy.nq*lbsy.nq];
  double invmass, omegaminus, mxx, myy, mzz;
  double *pt2 = &startpos[0];
  double *pt3 = &bodyforce[0];
  int qdim = lbsy.nf+lbsy.nc+lbsy.nt;

  for(int k=0; k<lbsy.nf; k++) {
    invmass = fReciprocal(rho[k]);
    force[0] = pt3[3*k];
    force[1] = pt3[3*k+1];
    force[2] = pt3[3*k+2];
    speed[0] = sitespeed[0] + 0.5 * force[0] * invmass;
    speed[1] = sitespeed[1] + 0.5 * force[1] * invmass;
    speed[2] = sitespeed[2] + 0.5 * force[2] * invmass;
    fGetCentralMomentEquilibriumF(&meq[0], rho[k]);
    fGetCentralMomentTransformMatrix(shift, invshift, speed);
    fGetCentralMomentForceGuo(source, speed, force);
    fGetCLBECollide(collide, omega[k], omegabulk[k], omega3[k], omega4[k]);
    // transform distribution functions to central moments
    for(int i=0; i<lbsy.nq; i++) {
      cenmoment[i] = 0.0;
      momcorr[i] = 0.0;
      for(int j=0; j<lbsy.nq; j++) {
        cenmoment[i] += pt2[j*qdim+k] * shift[i*lbsy.nq+j];
      }
    }
    // find antisymmetric corrections required for second-order moments
    offset = 3 + 4 * (lbsy.nd - 2);
    omegaminus = (omegabulk[k] - omega[k]) / ((double)lbsy.nd);
    mxx = omegaminus * (meq[offset]   - cenmoment[offset]   - 0.5 * source[offset]  );
    myy = omegaminus * (meq[offset+1] - cenmoment[offset+1] - 0.5 * source[offset+1]);
    mzz = (lbsy.nd>2)?(omegaminus*(meq[offset+2]-cenmoment[offset+2] - 0.5*source[offset+2])):0.0;
    momcorr[offset] = myy + mzz;
    momcorr[offset+1] = mxx + mzz;
    momcorr[offset+2] = (lbsy.nd>2)?(mxx+myy):0.0;
    // collide central moments (including antisymmetric corrections
    // and forcing terms) and shift back into post-collision
    // distribution functions
    for(int i=0; i<lbsy.nq; i++) {
      cenmoment[i] = (1.0 - collide[i]) * cenmoment[i] + collide[i] * meq[i] + (1.0 - 0.5 * collide[i]) * source[i] + momcorr[i];
    }
    for(int i=0; i<lbsy.nq; i++) {
      pt2[i*qdim+k] = 0.0;
      for(int j=0; j<lbsy.nq; j++) {
        pt2[i*qdim+k] += cenmoment[j] * invshift[i*lbsy.nq+j];
      }
    }
  }

  pt2 = NULL;
  pt3 = NULL;
  return 0;
}


int fSiteFluidCollisionCLBEHe(double* startpos, double *sitespeed, double *omega, double *omegabulk, double *omega3, double *omega4, double *rho, double* bodyforce)
{
  
  // calculate fluid collisions at grid point: uses cascaded LBE scheme
  // with He forcing terms

  int offset;
  double speed[3], force[3], meq[lbsy.nq];
  double cenmoment[lbsy.nq], collide[lbsy.nq], source[lbsy.nq], momcorr[lbsy.nq];
  double shift[lbsy.nq*lbsy.nq], invshift[lbsy.nq*lbsy.nq];
  double invmass, omegaminus, mxx, myy, mzz;
  double *pt2 = &startpos[0];
  double *pt3 = &bodyforce[0];
  int qdim = lbsy.nf+lbsy.nc+lbsy.nt;

  for(int k=0; k<lbsy.nf; k++) {
    invmass = fReciprocal(rho[k]);
    force[0] = pt3[3*k];
    force[1] = pt3[3*k+1];
    force[2] = pt3[3*k+2];
    speed[0] = sitespeed[0] + 0.5 * force[0] * invmass;
    speed[1] = sitespeed[1] + 0.5 * force[1] * invmass;
    speed[2] = sitespeed[2] + 0.5 * force[2] * invmass;
    fGetCentralMomentEquilibriumF(&meq[0], rho[k]);
    fGetCentralMomentTransformMatrix(shift, invshift, speed);
    fGetCentralMomentForceHe(source, force);
    fGetCLBECollide(collide, omega[k], omegabulk[k], omega3[k], omega4[k]);
    // transform distribution functions to central moments
    for(int i=0; i<lbsy.nq; i++) {
      cenmoment[i] = 0.0;
      momcorr[i] = 0.0;
      for(int j=0; j<lbsy.nq; j++) {
        cenmoment[i] += pt2[j*qdim+k] * shift[i*lbsy.nq+j];
      }
    }
    // find antisymmetric corrections required for second-order moments
    offset = 3 + 4 * (lbsy.nd - 2);
    omegaminus = (omegabulk[k] - omega[k]) / ((double)lbsy.nd);
    mxx = omegaminus * (meq[offset]   - cenmoment[offset]   - 0.5 * source[offset]  );
    myy = omegaminus * (meq[offset+1] - cenmoment[offset+1] - 0.5 * source[offset+1]);
    mzz = (lbsy.nd>2)?(omegaminus*(meq[offset+2]-cenmoment[offset+2] - 0.5*source[offset+2])):0.0;
    momcorr[offset] = myy + mzz;
    momcorr[offset+1] = mxx + mzz;
    momcorr[offset+2] = (lbsy.nd>2)?(mxx+myy):0.0;
    // collide central moments (including antisymmetric corrections
    // and forcing terms) and shift back into post-collision
    // distribution functions
    for(int i=0; i<lbsy.nq; i++) {
      cenmoment[i] = (1.0 - collide[i]) * cenmoment[i] + collide[i] * meq[i] + (1.0 - 0.5 * collide[i]) * source[i] + momcorr[i];
    }
    for(int i=0; i<lbsy.nq; i++) {
      pt2[i*qdim+k] = 0.0;
      for(int j=0; j<lbsy.nq; j++) {
        pt2[i*qdim+k] += cenmoment[j] * invshift[i*lbsy.nq+j];
      }
    }
  }

  pt2 = NULL;
  pt3 = NULL;
  return 0;
}


// Achromatic fluid collisions with pre-calculated interfacial forces and phase segregation

int fSiteFluidCollisionCLBELishchuk(double* startpos, double *sitespeed, double *omega, double *omegabulk, double *omega3, double *omega4, double *rho, double* bodyforce, double* phaseindex)
{
  
  // CLBE collision of achromatic fluid and D'Ortona segregation
  // calculate fluid collisions at grid point: uses cascaded LBE scheme

  int offset;
  double speed[3], meq[lbsy.nq];
  double seg[lbsy.nf*lbsy.nq], lbfac[lbsy.nq];
  double cenmoment[lbsy.nq], collide[lbsy.nq], momcorr[lbsy.nq];
  double shift[lbsy.nq*lbsy.nq], invshift[lbsy.nq*lbsy.nq];
  double omegat,omegabulkt,omega3t,omega4t,segcomp,segpiece;
  double allmass,invallmass,relax,omegaminus,nx,ny,nz,mxx,myy,mzz;
  double *pt2 = &startpos[0];
  double *pt3 = &bodyforce[0];
  double *pt4 = &phaseindex[0];
  int numpair = lbsy.nf*(lbsy.nf-1)/2;
  int qdim = lbsy.nf+lbsy.nc+lbsy.nt;

  allmass = 0.0;
  omegat = 0.0;
  omegabulkt = 0.0;
  omega3t = 0.0;
  omega4t = 0.0;

  for(int j=0; j<lbsy.nf; j++) {
    allmass += rho[j];
    omegat += omega[j] * rho[j];
    omegabulkt += omegabulk[j] * rho[j];
    omega3t += omega3[j] * rho[j];
    omega4t += omega4[j] * rho[j];
  }

  invallmass = fReciprocal(allmass);
  omegat *= invallmass;
  omegabulkt *= invallmass;
  omega3t *= invallmass;
  omega4t *= invallmass;
  relax = fReciprocal(omegat);
    
  speed[0] = sitespeed[0] + pt3[0] * relax * invallmass;
  speed[1] = sitespeed[1] + pt3[1] * relax * invallmass;
  speed[2] = sitespeed[2] + pt3[2] * relax * invallmass;

  fGetCentralMomentEquilibriumF(&meq[0], allmass);
  fGetCentralMomentTransformMatrix(shift, invshift, speed);
  fGetCLBECollide(collide, omegat, omegabulkt, omega3t, omega4t);

  // combine distribution functions to give achromatic distribution functions
  for(int i=0; i<lbsy.nq; i++) {
    lbfac[i] = 0.0;
    for(int j=0; j<lbsy.nf; i++) {
      lbfac[i] += pt2[i*qdim+j];
      seg[i*lbsy.nf+j] = 0.0;
    }
  }

  // calculate segregation terms
  for(int k=0; k<numpair; k++) {
    int i = lbspair[2*k  ];
    int j = lbspair[2*k+1];
    nx = pt4[3*k  ];
    ny = pt4[3*k+1];
    nz = pt4[3*k+2];
    segpiece = lbseg[lbsy.nf*j+i] * rho[i] * rho[j] * invallmass * invallmass;
    for(int m=0; m<lbsy.nq; m++) {
      segcomp = segpiece * (lbvwx[m]*nx + lbvwy[m]*ny + lbvwz[m]*nz);
      seg[m*lbsy.nf+i] += segcomp;
      seg[m*lbsy.nf+j] -= segcomp;
    }
  }

  // transform distribution functions to central moments
  for(int i=0; i<lbsy.nq; i++) {
    cenmoment[i] = 0.0;
    momcorr[i] = 0.0;
    for(int j=0; j<lbsy.nq; j++) {
      cenmoment[i] += lbfac[j] * shift[i*lbsy.nq+j];
    }
  }
    
  // find antisymmetric corrections required for second-order moments
  offset = 3 + 4 * (lbsy.nd - 2);
  omegaminus = (omegabulkt - omegat) / ((double)lbsy.nd);
  mxx = omegaminus * (meq[offset]   - cenmoment[offset]  );
  myy = omegaminus * (meq[offset+1] - cenmoment[offset+1]);
  mzz = (lbsy.nd>2)?(omegaminus*(meq[offset+2] - cenmoment[offset+2])):0.0;
  momcorr[offset] = myy + mzz;
  momcorr[offset+1] = mxx + mzz;
  momcorr[offset+2] = (lbsy.nd>2)?(mxx+myy):0.0;
    
  // collide central moments (including antisymmetric corrections)
  // and shift back into post-collision distribution functions
  for(int i=0; i<lbsy.nq; i++) {
    cenmoment[i] = (1.0 - collide[i]) * cenmoment[i] + collide[i] * meq[i] + momcorr[i];
  }
  for(int i=0; i<lbsy.nq; i++) {
    lbfac[i] = 0.0;
    for(int j=0; j<lbsy.nq; j++) {
      lbfac[i] += cenmoment[j] * invshift[i*lbsy.nq+j];
    }
  }

  // segregate fluids back out
  for(int m=0; m<lbsy.nq; m++) {
    for(int i=0; i<lbsy.nf; i++) {
      pt2[m*qdim+i] = rho[i] * lbfac[m] * invallmass + seg[m*lbsy.nf+i];
    }
  }

  pt2 = NULL;
  pt3 = NULL;
  pt4 = NULL;
  return 0;
}

int fSiteFluidCollisionCLBEEDMLishchuk(double* startpos, double *sitespeed, double *omega, double *omegabulk, double *omega3, double *omega4, double *rho, double* bodyforce, double *phaseindex)
{
  
  // CLBE collision of achromatic fluid and D'Ortona segregation
  // calculate fluid collisions at grid point: uses cascaded LBE scheme
  // with Exact Difference Method forcing term

  int offset;
  double dv[3], meq[lbsy.nq];
  double seg[lbsy.nf*lbsy.nq], lbfac[lbsy.nq];
  double cenmoment[lbsy.nq], collide[lbsy.nq], momcorr[lbsy.nq];
  double shift[lbsy.nq*lbsy.nq], invshift[lbsy.nq*lbsy.nq];
  double omegat,omegabulkt,omega3t,omega4t,segcomp,segpiece;
  double allmass,invallmass,omegaminus,nx,ny,nz,mxx,myy,mzz;
  double modv,eixeix,eiyeiy,eizeiz,eixux,eiyuy,eizuz,eixdux,eiyduy,eizduz,vxvx,vyvy,vzvz;
  double *pt2 = &startpos[0];
  double *pt3 = &bodyforce[0];
  double *pt4 = &phaseindex[0];
  int numpair = lbsy.nf*(lbsy.nf-1)/2;
  int qdim = lbsy.nf+lbsy.nc+lbsy.nt;

  allmass = 0.0;
  omegat = 0.0;
  omegabulkt = 0.0;
  omega3t = 0.0;
  omega4t = 0.0;

  for(int j=0; j<lbsy.nf; j++) {
    allmass += rho[j];
    omegat += omega[j] * rho[j];
    omegabulkt += omegabulk[j] * rho[j];
    omega3t += omega3[j] * rho[j];
    omega4t += omega4[j] * rho[j];
  }

  invallmass = fReciprocal(allmass);
  omegat *= invallmass;
  omegabulkt *= invallmass;
  omega3t *= invallmass;
  omega4t *= invallmass;

  dv[0] = pt3[0] * invallmass;
  dv[1] = pt3[1] * invallmass;
  dv[2] = pt3[2] * invallmass;
  modv = dv[0]*(2.0*sitespeed[0]+dv[0]) + dv[1]*(2.0*sitespeed[1]+dv[1]) + dv[2]*(2.0*sitespeed[2]+dv[2]);
  vxvx = (sitespeed[0]+dv[0])*(sitespeed[0]+dv[0]);
  vyvy = (sitespeed[1]+dv[1])*(sitespeed[1]+dv[1]);
  vzvz = (sitespeed[2]+dv[2])*(sitespeed[2]+dv[2]);

  fGetCentralMomentEquilibriumF(&meq[0], allmass);
  fGetCentralMomentTransformMatrix(shift, invshift, sitespeed);
  fGetCLBECollide(collide, omegat, omegabulkt, omega3t, omega4t);

  // combine distribution functions to give achromatic distribution functions
  for(int i=0; i<lbsy.nq; i++) {
    lbfac[i] = 0.0;
    for(int j=0; j<lbsy.nf; i++) {
      lbfac[i] += pt2[i*qdim+j];
      seg[i*lbsy.nf+j] = 0.0;
    }
  }

  // calculate segregation terms
  for(int k=0; k<numpair; k++) {
    int i = lbspair[2*k  ];
    int j = lbspair[2*k+1];
    nx = pt4[3*k  ];
    ny = pt4[3*k+1];
    nz = pt4[3*k+2];
    segpiece = lbseg[lbsy.nf*j+i] * rho[i] * rho[j] * invallmass * invallmass;
    for(int m=0; m<lbsy.nq; m++) {
      segcomp = segpiece * (lbvwx[m]*nx + lbvwy[m]*ny + lbvwz[m]*nz);
      seg[m*lbsy.nf+i] += segcomp;
      seg[m*lbsy.nf+j] -= segcomp;
    }
  }

  // transform distribution functions to central moments
  for(int i=0; i<lbsy.nq; i++) {
    cenmoment[i] = 0.0;
    momcorr[i] = 0.0;
    for(int j=0; j<lbsy.nq; j++) {
      cenmoment[i] += lbfac[j] * shift[i*lbsy.nq+j];
    }
  }
    
  // find antisymmetric corrections required for second-order moments
  offset = 3 + 4 * (lbsy.nd - 2);
  omegaminus = (omegabulkt - omegat) / ((double)lbsy.nd);
  mxx = omegaminus * (meq[offset]   - cenmoment[offset]  );
  myy = omegaminus * (meq[offset+1] - cenmoment[offset+1]);
  mzz = (lbsy.nd>2)?(omegaminus*(meq[offset+2] - cenmoment[offset+2])):0.0;
  momcorr[offset] = myy + mzz;
  momcorr[offset+1] = mxx + mzz;
  momcorr[offset+2] = (lbsy.nd>2)?(mxx+myy):0.0;

  // collide central moments (including antisymmetric corrections)
  // and shift back into post-collision distribution functions,
  // applying third-order EDM forcing terms
  for(int i=0; i<lbsy.nq; i++) {
    cenmoment[i] = (1.0 - collide[i]) * cenmoment[i] + collide[i] * meq[i] + momcorr[i];
  }
  for(int i=0; i<lbsy.nq; i++) {
    eixeix = lbvx[i] * lbvx[i];
    eiyeiy = lbvy[i] * lbvy[i];
    eizeiz = lbvz[i] * lbvz[i];
    eixux =  lbvx[i] * sitespeed[0];
    eiyuy =  lbvy[i] * sitespeed[1];
    eizuz =  lbvz[i] * sitespeed[2];
    eixdux = lbvx[i] * dv[0];
    eiyduy = lbvy[i] * dv[1];
    eizduz = lbvz[i] * dv[2];
    lbfac[i] = allmass * lbw[i] * (3.0 * (eixdux+eiyduy+eizduz) +
                                   4.5 * (eixdux*(eixdux+2.0*(eixux+eiyuy+eizuz+eiyduy+eizduz)) +
                                          eiyduy*(eiyduy+2.0*(eixux+eiyuy+eizuz+eizduz)) +
                                          eizduz*(eizduz+2.0*(eixux+eiyuy+eizuz)) +
                                         (3.0*eixeix-1.0)*((eiyduy+eizduz)*vxvx+(eiyuy+eizuz)*dv[0]*(2.0+dv[0])) +
                                         (3.0*eiyeiy-1.0)*((eixdux+eizduz)*vyvy+(eixux+eizuz)*dv[1]*(2.0+dv[1])) +
                                         (3.0*eizeiz-1.0)*((eixdux+eiyduy)*vzvz+(eixux+eiyuy)*dv[2]*(2.0+dv[2])) +
                                         6.0*(eixdux*(eiyuy+eiyduy)*(eizuz+eizduz)+eixux*(eiyduy*(eizuz+eizduz)+eiyuy*eizduz))) - 1.5*modv);
    for(int j=0; j<lbsy.nq; j++) {
      lbfac[i] += cenmoment[j] * invshift[i*lbsy.nq+j];
    }
  }

  // segregate fluids back out
  for(int m=0; m<lbsy.nq; m++) {
    for(int i=0; i<lbsy.nf; i++) {
      pt2[m*qdim+i] = rho[i] * lbfac[m] * invallmass + seg[m*lbsy.nf+i];
    }
  }

  pt2 = NULL;
  pt3 = NULL;
  pt4 = NULL;
  return 0;
}


int fSiteFluidCollisionCLBEGuoLishchuk(double* startpos, double *sitespeed, double *omega, double *omegabulk, double *omega3, double *omega4, double *rho, double* bodyforce, double *phaseindex)
{
  
  // CLBE collision of achromatic fluid and D'Ortona segregation
  // calculate fluid collisions at grid point: uses cascaded LBE scheme
  // with Guo-based forcing terms

  int offset;
  double force[3], speed[3], meq[lbsy.nq];
  double seg[lbsy.nf*lbsy.nq], lbfac[lbsy.nq];
  double cenmoment[lbsy.nq], collide[lbsy.nq], source[lbsy.nq], momcorr[lbsy.nq];
  double shift[lbsy.nq*lbsy.nq], invshift[lbsy.nq*lbsy.nq];
  double omegat,omegabulkt,omega3t,omega4t,segcomp,segpiece;
  double allmass,invallmass,omegaminus,nx,ny,nz,mxx,myy,mzz;
  double *pt2 = &startpos[0];
  double *pt3 = &bodyforce[0];
  double *pt4 = &phaseindex[0];
  int numpair = lbsy.nf*(lbsy.nf-1)/2;
  int qdim = lbsy.nf+lbsy.nc+lbsy.nt;

  allmass = 0.0;
  omegat = 0.0;
  omegabulkt = 0.0;
  omega3t = 0.0;
  omega4t = 0.0;

  for(int j=0; j<lbsy.nf; j++) {
    allmass += rho[j];
    omegat += omega[j] * rho[j];
    omegabulkt += omegabulk[j] * rho[j];
    omega3t += omega3[j] * rho[j];
    omega4t += omega4[j] * rho[j];
  }

  invallmass = fReciprocal(allmass);
  omegat *= invallmass;
  omegabulkt *= invallmass;
  omega3t *= invallmass;
  omega4t *= invallmass;
    
  force[0] = pt3[0];
  force[1] = pt3[1];
  force[2] = pt3[2];
  speed[0] = sitespeed[0] + 0.5 * force[0] * invallmass;
  speed[1] = sitespeed[1] + 0.5 * force[1] * invallmass;
  speed[2] = sitespeed[2] + 0.5 * force[2] * invallmass;
    
  fGetCentralMomentEquilibriumF(&meq[0], allmass);
  fGetCentralMomentTransformMatrix(shift, invshift, speed);
  fGetCentralMomentForceGuo(source, speed, force);
  fGetCLBECollide(collide, omegat, omegabulkt, omega3t, omega4t);

  // combine distribution functions to give achromatic distribution functions
  for(int i=0; i<lbsy.nq; i++) {
    lbfac[i] = 0.0;
    for(int j=0; j<lbsy.nf; i++) {
      lbfac[i] += pt2[i*qdim+j];
      seg[i*lbsy.nf+j] = 0.0;
    }
  }

  // calculate segregation terms
  for(int k=0; k<numpair; k++) {
    int i = lbspair[2*k  ];
    int j = lbspair[2*k+1];
    nx = pt4[3*k  ];
    ny = pt4[3*k+1];
    nz = pt4[3*k+2];
    segpiece = lbseg[lbsy.nf*j+i] * rho[i] * rho[j] * invallmass * invallmass;
    for(int m=0; m<lbsy.nq; m++) {
      segcomp = segpiece * (lbvwx[m]*nx + lbvwy[m]*ny + lbvwz[m]*nz);
      seg[m*lbsy.nf+i] += segcomp;
      seg[m*lbsy.nf+j] -= segcomp;
    }
  }

  // transform distribution functions to central moments
  for(int i=0; i<lbsy.nq; i++) {
    cenmoment[i] = 0.0;
    momcorr[i] = 0.0;
    for(int j=0; j<lbsy.nq; j++) {
      cenmoment[i] += lbfac[j] * shift[i*lbsy.nq+j];
    }
  }
    
  // find antisymmetric corrections required for second-order moments
  offset = 3 + 4 * (lbsy.nd - 2);
  omegaminus = (omegabulkt - omegat) / ((double)lbsy.nd);
  mxx = omegaminus * (meq[offset]   - cenmoment[offset]   - 0.5 * source[offset]  );
  myy = omegaminus * (meq[offset+1] - cenmoment[offset+1] - 0.5 * source[offset+1]);
  mzz = (lbsy.nd>2)?(omegaminus*(meq[offset+2]-cenmoment[offset+2] - 0.5*source[offset+2])):0.0;
  momcorr[offset] = myy + mzz;
  momcorr[offset+1] = mxx + mzz;
  momcorr[offset+2] = (lbsy.nd>2)?(mxx+myy):0.0;

  // collide central moments (including antisymmetric corrections
  // and forcing terms) and shift back into post-collision
  // distribution functions
  for(int i=0; i<lbsy.nq; i++) {
    cenmoment[i] = (1.0 - collide[i]) * cenmoment[i] + collide[i] * meq[i] + (1.0 - 0.5 * collide[i]) * source[i] + momcorr[i];
  }
  for(int i=0; i<lbsy.nq; i++) {
    lbfac[i] = 0.0;
    for(int j=0; j<lbsy.nq; j++) {
      lbfac[i] += cenmoment[j] * invshift[i*lbsy.nq+j];
    }
  }

  // segregate fluids back out
  for(int m=0; m<lbsy.nq; m++) {
    for(int i=0; i<lbsy.nf; i++) {
      pt2[m*qdim+i] = rho[i] * lbfac[m] * invallmass + seg[m*lbsy.nf+i];
    }
  }

  pt2 = NULL;
  pt3 = NULL;
  pt4 = NULL;
  return 0;
}


int fSiteFluidCollisionCLBEHeLishchuk(double* startpos, double *sitespeed, double *omega, double *omegabulk, double *omega3, double *omega4, double *rho, double* bodyforce, double *phaseindex)
{
  
  // CLBE collision of achromatic fluid and D'Ortona segregation
  // calculate fluid collisions at grid point: uses cascaded LBE scheme
  // with He forcing terms

  int offset;
  double force[3], speed[3], meq[lbsy.nq];
  double seg[lbsy.nf*lbsy.nq], lbfac[lbsy.nq];
  double cenmoment[lbsy.nq], collide[lbsy.nq], source[lbsy.nq], momcorr[lbsy.nq];
  double shift[lbsy.nq*lbsy.nq], invshift[lbsy.nq*lbsy.nq];
  double omegat,omegabulkt,omega3t,omega4t,segcomp,segpiece;
  double allmass,invallmass,omegaminus,nx,ny,nz,mxx,myy,mzz;
  double *pt2 = &startpos[0];
  double *pt3 = &bodyforce[0];
  double *pt4 = &phaseindex[0];
  int numpair = lbsy.nf*(lbsy.nf-1)/2;
  int qdim = lbsy.nf+lbsy.nc+lbsy.nt;

  allmass = 0.0;
  omegat = 0.0;
  omegabulkt = 0.0;
  omega3t = 0.0;
  omega4t = 0.0;

  for(int j=0; j<lbsy.nf; j++) {
    allmass += rho[j];
    omegat += omega[j] * rho[j];
    omegabulkt += omegabulk[j] * rho[j];
    omega3t += omega3[j] * rho[j];
    omega4t += omega4[j] * rho[j];
  }

  invallmass = fReciprocal(allmass);
  omegat *= invallmass;
  omegabulkt *= invallmass;
  omega3t *= invallmass;
  omega4t *= invallmass;
    
  force[0] = pt3[0];
  force[1] = pt3[1];
  force[2] = pt3[2];
  speed[0] = sitespeed[0] + 0.5 * force[0] * invallmass;
  speed[1] = sitespeed[1] + 0.5 * force[1] * invallmass;
  speed[2] = sitespeed[2] + 0.5 * force[2] * invallmass;
    
  fGetCentralMomentEquilibriumF(&meq[0], allmass);
  fGetCentralMomentTransformMatrix(shift, invshift, speed);
  fGetCentralMomentForceHe(source, force);
  fGetCLBECollide(collide, omegat, omegabulkt, omega3t, omega4t);

  // combine distribution functions to give achromatic distribution functions
  for(int i=0; i<lbsy.nq; i++) {
    lbfac[i] = 0.0;
    for(int j=0; j<lbsy.nf; i++) {
      lbfac[i] += pt2[i*qdim+j];
      seg[i*lbsy.nf+j] = 0.0;
    }
  }

  // calculate segregation terms
  for(int k=0; k<numpair; k++) {
    int i = lbspair[2*k  ];
    int j = lbspair[2*k+1];
    nx = pt4[3*k  ];
    ny = pt4[3*k+1];
    nz = pt4[3*k+2];
    segpiece = lbseg[lbsy.nf*j+i] * rho[i] * rho[j] * invallmass * invallmass;
    for(int m=0; m<lbsy.nq; m++) {
      segcomp = segpiece * (lbvwx[m]*nx + lbvwy[m]*ny + lbvwz[m]*nz);
      seg[m*lbsy.nf+i] += segcomp;
      seg[m*lbsy.nf+j] -= segcomp;
    }
  }

  // transform distribution functions to central moments
  for(int i=0; i<lbsy.nq; i++) {
    cenmoment[i] = 0.0;
    momcorr[i] = 0.0;
    for(int j=0; j<lbsy.nq; j++) {
      cenmoment[i] += lbfac[j] * shift[i*lbsy.nq+j];
    }
  }
    
  // find antisymmetric corrections required for second-order moments
  offset = 3 + 4 * (lbsy.nd - 2);
  omegaminus = (omegabulkt - omegat) / ((double)lbsy.nd);
  mxx = omegaminus * (meq[offset]   - cenmoment[offset]   - 0.5 * source[offset]  );
  myy = omegaminus * (meq[offset+1] - cenmoment[offset+1] - 0.5 * source[offset+1]);
  mzz = (lbsy.nd>2)?(omegaminus*(meq[offset+2]-cenmoment[offset+2] - 0.5*source[offset+2])):0.0;
  momcorr[offset] = myy + mzz;
  momcorr[offset+1] = mxx + mzz;
  momcorr[offset+2] = (lbsy.nd>2)?(mxx+myy):0.0;

  // collide central moments (including antisymmetric corrections
  // and forcing terms) and shift back into post-collision
  // distribution functions
  for(int i=0; i<lbsy.nq; i++) {
    cenmoment[i] = (1.0 - collide[i]) * cenmoment[i] + collide[i] * meq[i] + (1.0 - 0.5 * collide[i]) * source[i] + momcorr[i];
  }
  for(int i=0; i<lbsy.nq; i++) {
    lbfac[i] = 0.0;
    for(int j=0; j<lbsy.nq; j++) {
      lbfac[i] += cenmoment[j] * invshift[i*lbsy.nq+j];
    }
  }

  // segregate fluids back out
  for(int m=0; m<lbsy.nq; m++) {
    for(int i=0; i<lbsy.nf; i++) {
      pt2[m*qdim+i] = rho[i] * lbfac[m] * invallmass + seg[m*lbsy.nf+i];
    }
  }

  pt2 = NULL;
  pt3 = NULL;
  pt4 = NULL;
  return 0;
}


// Achromatic fluid collisions with local forcing terms and phase segregation

int fSiteFluidCollisionCLBELishchukLocal(double* startpos, double *sitespeed, double *omega, double *omegabulk, double *omega3, double *omega4, double *rho, double* bodyforce, double* phaseindex, int threed)
{
  
  // CLBE collision of achromatic fluid and D'Ortona segregation
  // calculate interfacial forcing terms and fluid collisions at grid point:
  // using cascaded LBE scheme

  int offset;
  double speed[3], meq[lbsy.nq];
  double seg[lbsy.nf*lbsy.nq], lbfac[lbsy.nq], phaseforce[lbsy.nq];
  double cenmoment[lbsy.nq], collide[lbsy.nq], momcorr[lbsy.nq];
  double shift[lbsy.nq*lbsy.nq], invshift[lbsy.nq*lbsy.nq];
  double omegat,omegabulkt,omega3t,omega4t,segcomp,segpiece,forceconst;
  double allmass,invallmass,relax,omegaminus,nx,ny,nz,ex,ey,ez,mxx,myy,mzz;
  double *pt2 = &startpos[0];
  double *pt3 = &bodyforce[0];
  double *pt4 = &phaseindex[0];
  int numpair = lbsy.nf*(lbsy.nf-1)/2;
  int qdim = lbsy.nf+lbsy.nc+lbsy.nt;

  allmass = 0.0;
  omegat = 0.0;
  omegabulkt = 0.0;
  omega3t = 0.0;
  omega4t = 0.0;

  for(int j=0; j<lbsy.nf; j++) {
    allmass += rho[j];
    omegat += omega[j] * rho[j];
    omegabulkt += omegabulk[j] * rho[j];
    omega3t += omega3[j] * rho[j];
    omega4t += omega4[j] * rho[j];
  }

  invallmass = fReciprocal(allmass);
  omegat *= invallmass;
  omegabulkt *= invallmass;
  omega3t *= invallmass;
  omega4t *= invallmass;
  relax = fReciprocal(omegat);
    
  speed[0] = sitespeed[0] + pt3[0] * relax * invallmass;
  speed[1] = sitespeed[1] + pt3[1] * relax * invallmass;
  speed[2] = sitespeed[2] + pt3[2] * relax * invallmass;

  fGetCentralMomentEquilibriumF(&meq[0], allmass);
  fGetCentralMomentTransformMatrix(shift, invshift, speed);
  fGetCLBECollide(collide, omegat, omegabulkt, omega3t, omega4t);

  // combine distribution functions to give achromatic distribution functions
  for(int i=0; i<lbsy.nq; i++) {
    lbfac[i] = 0.0;
    phaseforce[i] = 0.0;
    for(int j=0; j<lbsy.nf; i++) {
      lbfac[i] += pt2[i*qdim+j];
      seg[i*lbsy.nf+j] = 0.0;
    }
  }

  // calculate local forcing and segregation terms

  for(int k=0; k<numpair; k++) {
    int i = lbspair[2*k  ];
    int j = lbspair[2*k+1];
    nx = pt4[3*k  ];
    ny = pt4[3*k+1];
    nz = pt4[3*k+2];
    forceconst = lbseg[lbsy.nf*j+i] * lbg[lbsy.nf*j+i] * rho[i] * rho[j];
    segpiece = lbseg[lbsy.nf*j+i] * rho[i] * rho[j] * invallmass * invallmass;
    for(int m=0; m<lbsy.nq; m++) {
      ex = lbvx[m];
      ey = lbvy[m];
      ez = lbvz[m];
      phaseforce[m] += forceconst * ((nx*nx-1.0)*(ex*ex-lbcssq) + (ny*ny-1.0)*(ey*ey-lbcssq) + 2.0*nx*ny*ex*ey
                     + threed*((nz*nz-1.0)*(ez*ez-lbcssq) + 2.0*nz*ez*(nx*ex+ny*ey)));
      segcomp = segpiece * (lbvwx[m]*nx + lbvwy[m]*ny);
      seg[m*lbsy.nf+i] += segcomp;
      seg[m*lbsy.nf+j] -= segcomp;
    }
  }

  // calculate segregation terms
  for(int k=0; k<numpair; k++) {
    int i = lbspair[2*k  ];
    int j = lbspair[2*k+1];
    nx = pt4[3*k  ];
    ny = pt4[3*k+1];
    nz = pt4[3*k+2];
    segpiece = lbseg[lbsy.nf*j+i] * rho[i] * rho[j] * invallmass * invallmass;
    for(int m=0; m<lbsy.nq; m++) {
      segcomp = segpiece * (lbvwx[m]*nx + lbvwy[m]*ny + lbvwz[m]*nz);
      seg[m*lbsy.nf+i] += segcomp;
      seg[m*lbsy.nf+j] -= segcomp;
    }
  }

  // transform distribution functions to central moments
  for(int i=0; i<lbsy.nq; i++) {
    cenmoment[i] = 0.0;
    momcorr[i] = 0.0;
    for(int j=0; j<lbsy.nq; j++) {
      cenmoment[i] += lbfac[j] * shift[i*lbsy.nq+j];
    }
  }
    
  // find antisymmetric corrections required for second-order moments
  offset = 3 + 4 * (lbsy.nd - 2);
  omegaminus = (omegabulkt - omegat) / ((double)lbsy.nd);
  mxx = omegaminus * (meq[offset]   - cenmoment[offset]  );
  myy = omegaminus * (meq[offset+1] - cenmoment[offset+1]);
  mzz = (lbsy.nd>2)?(omegaminus*(meq[offset+2] - cenmoment[offset+2])):0.0;
  momcorr[offset] = myy + mzz;
  momcorr[offset+1] = mxx + mzz;
  momcorr[offset+2] = (lbsy.nd>2)?(mxx+myy):0.0;

  // collide central moments (including antisymmetric corrections)
  // and shift back into post-collision distribution functions,
  // applying local forcing terms
  for(int i=0; i<lbsy.nq; i++) {
    cenmoment[i] = (1.0 - collide[i]) * cenmoment[i] + collide[i] * meq[i] + momcorr[i];
  }
  forceconst = omegat * invallmass * invallmass * invallmass * lbrcssq * lbrcssq;
  for(int i=0; i<lbsy.nq; i++) {
    lbfac[i] = lbw[i]*forceconst*phaseforce[i];
    for(int j=0; j<lbsy.nq; j++) {
      lbfac[i] += cenmoment[j] * invshift[i*lbsy.nq+j];
    }
  }

  // segregate fluids back out
  for(int m=0; m<lbsy.nq; m++) {
    for(int i=0; i<lbsy.nf; i++) {
      pt2[m*qdim+i] = rho[i] * lbfac[m] * invallmass + seg[m*lbsy.nf+i];
    }
  }

  pt2 = NULL;
  pt3 = NULL;
  pt4 = NULL;
  return 0;
}


int fSiteFluidCollisionCLBEEDMLishchukLocal(double* startpos, double *sitespeed, double *omega, double *omegabulk, double *omega3, double *omega4, double *rho, double* bodyforce, double *phaseindex, int threed)
{
  
  // CLBE collision of achromatic fluid and D'Ortona segregation
  // calculate interfacial forcing terms and fluid collisions at grid point:
  // uses cascaded LBE scheme with Exact Difference Method forcing term

  int offset;
  double dv[3], meq[lbsy.nq];
  double seg[lbsy.nf*lbsy.nq], lbfac[lbsy.nq], phaseforce[lbsy.nq];
  double cenmoment[lbsy.nq], collide[lbsy.nq], momcorr[lbsy.nq];
  double shift[lbsy.nq*lbsy.nq], invshift[lbsy.nq*lbsy.nq];
  double omegat,omegabulkt,omega3t,omega4t,segcomp,segpiece,forceconst;
  double allmass,invallmass,omegaminus,ex,ey,ez,nx,ny,nz,mxx,myy,mzz;
  double modv,eixeix,eiyeiy,eizeiz,eixux,eiyuy,eizuz,eixdux,eiyduy,eizduz,vxvx,vyvy,vzvz;
  double *pt2 = &startpos[0];
  double *pt3 = &bodyforce[0];
  double *pt4 = &phaseindex[0];
  int numpair = lbsy.nf*(lbsy.nf-1)/2;
  int qdim = lbsy.nf+lbsy.nc+lbsy.nt;

  allmass = 0.0;
  omegat = 0.0;
  omegabulkt = 0.0;
  omega3t = 0.0;
  omega4t = 0.0;

  for(int j=0; j<lbsy.nf; j++) {
    allmass += rho[j];
    omegat += omega[j] * rho[j];
    omegabulkt += omegabulk[j] * rho[j];
    omega3t += omega3[j] * rho[j];
    omega4t += omega4[j] * rho[j];
  }

  invallmass = fReciprocal(allmass);
  omegat *= invallmass;
  omegabulkt *= invallmass;
  omega3t *= invallmass;
  omega4t *= invallmass;

  dv[0] = pt3[0] * invallmass;
  dv[1] = pt3[1] * invallmass;
  dv[2] = pt3[2] * invallmass;
  modv = dv[0]*(2.0*sitespeed[0]+dv[0]) + dv[1]*(2.0*sitespeed[1]+dv[1]) + dv[2]*(2.0*sitespeed[2]+dv[2]);
  vxvx = (sitespeed[0]+dv[0])*(sitespeed[0]+dv[0]);
  vyvy = (sitespeed[1]+dv[1])*(sitespeed[1]+dv[1]);
  vzvz = (sitespeed[2]+dv[2])*(sitespeed[2]+dv[2]);

  fGetCentralMomentEquilibriumF(&meq[0], allmass);
  fGetCentralMomentTransformMatrix(shift, invshift, sitespeed);
  fGetCLBECollide(collide, omegat, omegabulkt, omega3t, omega4t);

  // combine distribution functions to give achromatic distribution functions
  for(int i=0; i<lbsy.nq; i++) {
    lbfac[i] = 0.0;
    phaseforce[i] = 0.0;
    for(int j=0; j<lbsy.nf; i++) {
      lbfac[i] += pt2[i*qdim+j];
      seg[i*lbsy.nf+j] = 0.0;
    }
  }

  // calculate local forcing and segregation terms
  for(int k=0; k<numpair; k++) {
    int i = lbspair[2*k  ];
    int j = lbspair[2*k+1];
    nx = pt4[3*k  ];
    ny = pt4[3*k+1];
    nz = pt4[3*k+2];
    forceconst = lbseg[lbsy.nf*j+i] * lbg[lbsy.nf*j+i] * rho[i] * rho[j];
    segpiece = lbseg[lbsy.nf*j+i] * rho[i] * rho[j] * invallmass * invallmass;
    for(int m=0; m<lbsy.nq; m++) {
      ex = lbvx[m];
      ey = lbvy[m];
      ez = lbvz[m];
      phaseforce[m] += forceconst * ((nx*nx-1.0)*(ex*ex-lbcssq) + (ny*ny-1.0)*(ey*ey-lbcssq) + 2.0*nx*ny*ex*ey
                     + threed*((nz*nz-1.0)*(ez*ez-lbcssq) + 2.0*nz*ez*(nx*ex+ny*ey)));
      segcomp = segpiece * (lbvwx[m]*nx + lbvwy[m]*ny);
      seg[m*lbsy.nf+i] += segcomp;
      seg[m*lbsy.nf+j] -= segcomp;
    }
  }

  // transform distribution functions to central moments
  for(int i=0; i<lbsy.nq; i++) {
    cenmoment[i] = 0.0;
    momcorr[i] = 0.0;
    for(int j=0; j<lbsy.nq; j++) {
      cenmoment[i] += lbfac[j] * shift[i*lbsy.nq+j];
    }
  }
    
  // find antisymmetric corrections required for second-order moments
  offset = 3 + 4 * (lbsy.nd - 2);
  omegaminus = (omegabulkt - omegat) / ((double)lbsy.nd);
  mxx = omegaminus * (meq[offset]   - cenmoment[offset]  );
  myy = omegaminus * (meq[offset+1] - cenmoment[offset+1]);
  mzz = (lbsy.nd>2)?(omegaminus*(meq[offset+2] - cenmoment[offset+2])):0.0;
  momcorr[offset] = myy + mzz;
  momcorr[offset+1] = mxx + mzz;
  momcorr[offset+2] = (lbsy.nd>2)?(mxx+myy):0.0;
    
  // collide central moments (including antisymmetric corrections)
  // and shift back into post-collision distribution functions,
  // applying third-order EDM forcing terms and local forcing terms
    
  for(int i=0; i<lbsy.nq; i++) {
    cenmoment[i] = (1.0 - collide[i]) * cenmoment[i] + collide[i] * meq[i] + momcorr[i];
  }
  forceconst = omegat * invallmass * invallmass * invallmass * lbrcssq * lbrcssq;
  for(int i=0; i<lbsy.nq; i++) {
    eixeix = lbvx[i] * lbvx[i];
    eiyeiy = lbvy[i] * lbvy[i];
    eizeiz = lbvz[i] * lbvz[i];
    eixux =  lbvx[i] * sitespeed[0];
    eiyuy =  lbvy[i] * sitespeed[1];
    eizuz =  lbvz[i] * sitespeed[2];
    eixdux = lbvx[i] * dv[0];
    eiyduy = lbvy[i] * dv[1];
    eizduz = lbvz[i] * dv[2];
    lbfac[i] = lbw[i] * (allmass * (3.0 * (eixdux+eiyduy+eizduz) +
                                    4.5 * (eixdux*(eixdux+2.0*(eixux+eiyuy+eizuz+eiyduy+eizduz)) +
                                           eiyduy*(eiyduy+2.0*(eixux+eiyuy+eizuz+eizduz)) +
                                           eizduz*(eizduz+2.0*(eixux+eiyuy+eizuz)) +
                                          (3.0*eixeix-1.0)*((eiyduy+eizduz)*vxvx+(eiyuy+eizuz)*dv[0]*(2.0+dv[0])) +
                                          (3.0*eiyeiy-1.0)*((eixdux+eizduz)*vyvy+(eixux+eizuz)*dv[1]*(2.0+dv[1])) +
                                          (3.0*eizeiz-1.0)*((eixdux+eiyduy)*vzvz+(eixux+eiyuy)*dv[2]*(2.0+dv[2])) +
                                          6.0*(eixdux*(eiyuy+eiyduy)*(eizuz+eizduz)+eixux*(eiyduy*(eizuz+eizduz)+eiyuy*eizduz))) - 1.5*modv)
                      + forceconst*phaseforce[i]);
    for(int j=0; j<lbsy.nq; j++) {
      lbfac[i] += cenmoment[j] * invshift[i*lbsy.nq+j];
    }
  }

  // segregate fluids back out
  for(int m=0; m<lbsy.nq; m++) {
    for(int i=0; i<lbsy.nf; i++) {
      pt2[m*qdim+i] = rho[i] * lbfac[m] * invallmass + seg[m*lbsy.nf+i];
    }
  }

  pt2 = NULL;
  pt3 = NULL;
  pt4 = NULL;
  return 0;
}


int fSiteFluidCollisionCLBEGuoLishchukLocal(double* startpos, double *sitespeed, double *omega, double *omegabulk, double *omega3, double *omega4, double *rho, double* bodyforce, double *phaseindex, int threed)
{
  
  // CLBE collision of achromatic fluid and D'Ortona segregation
  // calculate interfacial forcing terms and fluid collisions at grid point:
  // uses cascaded LBE scheme with Guo-based forcing terms

  int offset;
  double force[3], speed[3], meq[lbsy.nq];
  double seg[lbsy.nf*lbsy.nq], lbfac[lbsy.nq], phaseforce[lbsy.nq];
  double cenmoment[lbsy.nq], collide[lbsy.nq], source[lbsy.nq], momcorr[lbsy.nq];
  double shift[lbsy.nq*lbsy.nq], invshift[lbsy.nq*lbsy.nq];
  double omegat,omegabulkt,omega3t,omega4t,segcomp,segpiece,forceconst;
  double allmass,invallmass,omegaminus,ex,ey,ez,nx,ny,nz,mxx,myy,mzz;
  double *pt2 = &startpos[0];
  double *pt3 = &bodyforce[0];
  double *pt4 = &phaseindex[0];
  int numpair = lbsy.nf*(lbsy.nf-1)/2;
  int qdim = lbsy.nf+lbsy.nc+lbsy.nt;

  allmass = 0.0;
  omegat = 0.0;
  omegabulkt = 0.0;
  omega3t = 0.0;
  omega4t = 0.0;

  for(int j=0; j<lbsy.nf; j++) {
    allmass += rho[j];
    omegat += omega[j] * rho[j];
    omegabulkt += omegabulk[j] * rho[j];
    omega3t += omega3[j] * rho[j];
    omega4t += omega4[j] * rho[j];
  }

  invallmass = fReciprocal(allmass);
  omegat *= invallmass;
  omegabulkt *= invallmass;
  omega3t *= invallmass;
  omega4t *= invallmass;
    
  force[0] = pt3[0];
  force[1] = pt3[1];
  force[2] = pt3[2];
  speed[0] = sitespeed[0] + 0.5 * force[0] * invallmass;
  speed[1] = sitespeed[1] + 0.5 * force[1] * invallmass;
  speed[2] = sitespeed[2] + 0.5 * force[2] * invallmass;
    
  fGetCentralMomentEquilibriumF(&meq[0], allmass);
  fGetCentralMomentTransformMatrix(shift, invshift, speed);
  fGetCentralMomentForceGuo(source, speed, force);
  fGetCLBECollide(collide, omegat, omegabulkt, omega3t, omega4t);

  // combine distribution functions to give achromatic distribution functions
  for(int i=0; i<lbsy.nq; i++) {
    lbfac[i] = 0.0;
    phaseforce[i] = 0.0;
    for(int j=0; j<lbsy.nf; i++) {
      lbfac[i] += pt2[i*qdim+j];
      seg[i*lbsy.nf+j] = 0.0;
    }
  }

  // calculate local forcing and segregation terms
  for(int k=0; k<numpair; k++) {
    int i = lbspair[2*k  ];
    int j = lbspair[2*k+1];
    nx = pt4[3*k  ];
    ny = pt4[3*k+1];
    nz = pt4[3*k+2];
    forceconst = lbseg[lbsy.nf*j+i] * lbg[lbsy.nf*j+i] * rho[i] * rho[j];
    segpiece = lbseg[lbsy.nf*j+i] * rho[i] * rho[j] * invallmass * invallmass;
    for(int m=0; m<lbsy.nq; m++) {
      ex = lbvx[m];
      ey = lbvy[m];
      ez = lbvz[m];
      phaseforce[m] += forceconst * ((nx*nx-1.0)*(ex*ex-lbcssq) + (ny*ny-1.0)*(ey*ey-lbcssq) + 2.0*nx*ny*ex*ey
                     + threed*((nz*nz-1.0)*(ez*ez-lbcssq) + 2.0*nz*ez*(nx*ex+ny*ey)));
      segcomp = segpiece * (lbvwx[m]*nx + lbvwy[m]*ny);
      seg[m*lbsy.nf+i] += segcomp;
      seg[m*lbsy.nf+j] -= segcomp;
    }
  }

  // transform distribution functions to central moments
  for(int i=0; i<lbsy.nq; i++) {
    cenmoment[i] = 0.0;
    momcorr[i] = 0.0;
    for(int j=0; j<lbsy.nq; j++) {
      cenmoment[i] += lbfac[j] * shift[i*lbsy.nq+j];
    }
  }
    
  // find antisymmetric corrections required for second-order moments
  offset = 3 + 4 * (lbsy.nd - 2);
  omegaminus = (omegabulkt - omegat) / ((double)lbsy.nd);
  mxx = omegaminus * (meq[offset]   - cenmoment[offset]   - 0.5 * source[offset]  );
  myy = omegaminus * (meq[offset+1] - cenmoment[offset+1] - 0.5 * source[offset+1]);
  mzz = (lbsy.nd>2)?(omegaminus*(meq[offset+2]-cenmoment[offset+2] - 0.5*source[offset+2])):0.0;
  momcorr[offset] = myy + mzz;
  momcorr[offset+1] = mxx + mzz;
  momcorr[offset+2] = (lbsy.nd>2)?(mxx+myy):0.0;

  // collide central moments (including antisymmetric corrections
  // and forcing terms) and shift back into post-collision
  // distribution functions, adding local forcing terms
  for(int i=0; i<lbsy.nq; i++) {
    cenmoment[i] = (1.0 - collide[i]) * cenmoment[i] + collide[i] * meq[i] + (1.0 - 0.5 * collide[i]) * source[i] + momcorr[i];
  }
  forceconst = omegat * invallmass * invallmass * invallmass * lbrcssq * lbrcssq;
  for(int i=0; i<lbsy.nq; i++) {
    lbfac[i] = lbw[i]*forceconst*phaseforce[i];
    for(int j=0; j<lbsy.nq; j++) {
      lbfac[i] += cenmoment[j] * invshift[i*lbsy.nq+j];
    }
  }

  // segregate fluids back out
  for(int m=0; m<lbsy.nq; m++) {
    for(int i=0; i<lbsy.nf; i++) {
      pt2[m*qdim+i] = rho[i] * lbfac[m] * invallmass + seg[m*lbsy.nf+i];
    }
  }

  pt2 = NULL;
  pt3 = NULL;
  pt4 = NULL;
  return 0;
}


int fSiteFluidCollisionCLBEHeLishchukLocal(double* startpos, double *sitespeed, double *omega, double *omegabulk, double *omega3, double *omega4, double *rho, double* bodyforce, double *phaseindex, int threed)
{
  
  // CLBE collision of achromatic fluid and D'Ortona segregation
  // calculate interfacial forcing terms and fluid collisions at grid point:
  // uses cascaded LBE scheme with He forcing terms

  int offset;
  double force[3], speed[3], meq[lbsy.nq];
  double seg[lbsy.nf*lbsy.nq], lbfac[lbsy.nq], phaseforce[lbsy.nq];
  double cenmoment[lbsy.nq], collide[lbsy.nq], source[lbsy.nq], momcorr[lbsy.nq];
  double shift[lbsy.nq*lbsy.nq], invshift[lbsy.nq*lbsy.nq];
  double omegat,omegabulkt,omega3t,omega4t,segcomp,segpiece,forceconst;
  double allmass,invallmass,omegaminus,ex,ey,ez,nx,ny,nz,mxx,myy,mzz;
  double *pt2 = &startpos[0];
  double *pt3 = &bodyforce[0];
  double *pt4 = &phaseindex[0];
  int numpair = lbsy.nf*(lbsy.nf-1)/2;
  int qdim = lbsy.nf+lbsy.nc+lbsy.nt;

  allmass = 0.0;
  omegat = 0.0;
  omegabulkt = 0.0;
  omega3t = 0.0;
  omega4t = 0.0;

  for(int j=0; j<lbsy.nf; j++) {
    allmass += rho[j];
    omegat += omega[j] * rho[j];
    omegabulkt += omegabulk[j] * rho[j];
    omega3t += omega3[j] * rho[j];
    omega4t += omega4[j] * rho[j];
  }

  invallmass = fReciprocal(allmass);
  omegat *= invallmass;
  omegabulkt *= invallmass;
  omega3t *= invallmass;
  omega4t *= invallmass;
    
  force[0] = pt3[0];
  force[1] = pt3[1];
  force[2] = pt3[2];
  speed[0] = sitespeed[0] + 0.5 * force[0] * invallmass;
  speed[1] = sitespeed[1] + 0.5 * force[1] * invallmass;
  speed[2] = sitespeed[2] + 0.5 * force[2] * invallmass;
    
  fGetCentralMomentEquilibriumF(&meq[0], allmass);
  fGetCentralMomentTransformMatrix(shift, invshift, speed);
  fGetCentralMomentForceHe(source, force);
  fGetCLBECollide(collide, omegat, omegabulkt, omega3t, omega4t);

  // combine distribution functions to give achromatic distribution functions
  for(int i=0; i<lbsy.nq; i++) {
    lbfac[i] = 0.0;
    phaseforce[i] = 0.0;
    for(int j=0; j<lbsy.nf; i++) {
      lbfac[i] += pt2[i*qdim+j];
      seg[i*lbsy.nf+j] = 0.0;
    }
  }

  // calculate local forcing and segregation terms
  for(int k=0; k<numpair; k++) {
    int i = lbspair[2*k  ];
    int j = lbspair[2*k+1];
    nx = pt4[3*k  ];
    ny = pt4[3*k+1];
    nz = pt4[3*k+2];
    forceconst = lbseg[lbsy.nf*j+i] * lbg[lbsy.nf*j+i] * rho[i] * rho[j];
    segpiece = lbseg[lbsy.nf*j+i] * rho[i] * rho[j] * invallmass * invallmass;
    for(int m=0; m<lbsy.nq; m++) {
      ex = lbvx[m];
      ey = lbvy[m];
      ez = lbvz[m];
      phaseforce[m] += forceconst * ((nx*nx-1.0)*(ex*ex-lbcssq) + (ny*ny-1.0)*(ey*ey-lbcssq) + 2.0*nx*ny*ex*ey
                     + threed*((nz*nz-1.0)*(ez*ez-lbcssq) + 2.0*nz*ez*(nx*ex+ny*ey)));
      segcomp = segpiece * (lbvwx[m]*nx + lbvwy[m]*ny);
      seg[m*lbsy.nf+i] += segcomp;
      seg[m*lbsy.nf+j] -= segcomp;
    }
  }

  // transform distribution functions to central moments
  for(int i=0; i<lbsy.nq; i++) {
    cenmoment[i] = 0.0;
    momcorr[i] = 0.0;
    for(int j=0; j<lbsy.nq; j++) {
      cenmoment[i] += lbfac[j] * shift[i*lbsy.nq+j];
    }
  }
    
  // find antisymmetric corrections required for second-order moments
  offset = 3 + 4 * (lbsy.nd - 2);
  omegaminus = (omegabulkt - omegat) / ((double)lbsy.nd);
  mxx = omegaminus * (meq[offset]   - cenmoment[offset]   - 0.5 * source[offset]  );
  myy = omegaminus * (meq[offset+1] - cenmoment[offset+1] - 0.5 * source[offset+1]);
  mzz = (lbsy.nd>2)?(omegaminus*(meq[offset+2]-cenmoment[offset+2] - 0.5*source[offset+2])):0.0;
  momcorr[offset] = myy + mzz;
  momcorr[offset+1] = mxx + mzz;
  momcorr[offset+2] = (lbsy.nd>2)?(mxx+myy):0.0;

  // collide central moments (including antisymmetric corrections
  // and forcing terms) and shift back into post-collision
  // distribution functions, adding local forcing terms
  for(int i=0; i<lbsy.nq; i++) {
    cenmoment[i] = (1.0 - collide[i]) * cenmoment[i] + collide[i] * meq[i] + (1.0 - 0.5 * collide[i]) * source[i] + momcorr[i];
  }
  forceconst = omegat * invallmass * invallmass * invallmass * lbrcssq * lbrcssq;
  for(int i=0; i<lbsy.nq; i++) {
    lbfac[i] = lbw[i]*forceconst*phaseforce[i];
    for(int j=0; j<lbsy.nq; j++) {
      lbfac[i] += cenmoment[j] * invshift[i*lbsy.nq+j];
    }
  }

  // segregate fluids back out
  for(int m=0; m<lbsy.nq; m++) {
    for(int i=0; i<lbsy.nf; i++) {
      pt2[m*qdim+i] = rho[i] * lbfac[m] * invallmass + seg[m*lbsy.nf+i];
    }
  }

  pt2 = NULL;
  pt3 = NULL;
  pt4 = NULL;
  return 0;
}


// Collision loops over all grid points

int fCollisionCLBE()
{
  long Tmax = lbdm.touter;
  double freq = (lbbdforcetyp==1)*sin(lboscilfreq*(lbcurstep-lbequstep));

  #pragma omp parallel
  {
    double interforce_t[3*lbsy.nf], sitespeed_t[3], rho_t[lbsy.nf];
    double *interforce = &interforce_t[0];
    double *sitespeed = &sitespeed_t[0];
    double *rho = &rho_t[0];
        
    #pragma omp for
    for(long il=0; il<Tmax; il++) {
      if(lbphi[il] != 11) {
        fGetSpeedAllMassSite(sitespeed, rho, &lbf[il*lbsitelength]);
        for(int ll=0; ll<3*lbsy.nf; ll++)
          interforce[ll] = lbinterforce[il*3*lbsy.nf+ll] + lbheatforce[il*3*lbsy.nf+ll] + postequil*(lbbdforce[ll]+lboscilforce[ll]*freq);
        if(lbphi[il] != 12 && lbphi[il] != 13)
          fSiteFluidCollisionCLBE(&lbf[il * lbsitelength], sitespeed, &lbomega[il*lbsy.nf], lbtfbulk, lbtfclb3, lbtfclb4, rho, interforce);
        fSiteSoluteCollisionBGK(&lbf[il*lbsitelength + lbsy.nf], sitespeed);
        fSiteThermalCollisionBGK(&lbf[il*lbsitelength + (lbsy.nf+lbsy.nc)], sitespeed);
      }
    }
  }
  return 0;
}

int fCollisionCLBEEDM()
{
  long Tmax = lbdm.touter;
  double freq = (lbbdforcetyp==1)*sin(lboscilfreq*(lbcurstep-lbequstep));

  #pragma omp parallel
  {
    double interforce_t[3*lbsy.nf], sitespeed_t[3], rho_t[lbsy.nf];
    double *interforce = &interforce_t[0];
    double *sitespeed = &sitespeed_t[0];
    double *rho = &rho_t[0];
        
    #pragma omp for
    for(long il=0; il<Tmax; il++) {
      if(lbphi[il] != 11) {
        fGetSpeedAllMassSite(sitespeed, rho, &lbf[il*lbsitelength]);
        for(int ll=0; ll<3*lbsy.nf; ll++)
          interforce[ll] = lbinterforce[il*3*lbsy.nf+ll] + lbheatforce[il*3*lbsy.nf+ll] + postequil*(lbbdforce[ll]+lboscilforce[ll]*freq);
        if(lbphi[il] != 12 && lbphi[il] != 13)
          fSiteFluidCollisionCLBEEDM(&lbf[il * lbsitelength], sitespeed, &lbomega[il*lbsy.nf], lbtfbulk, lbtfclb3, lbtfclb4, rho, interforce);
        fSiteSoluteCollisionBGK(&lbf[il*lbsitelength + lbsy.nf], sitespeed);
        fSiteThermalCollisionBGK(&lbf[il*lbsitelength + (lbsy.nf+lbsy.nc)], sitespeed);
      }
    }
  }
  return 0;
}

int fCollisionCLBEGuo()
{
  long Tmax = lbdm.touter;
  double freq = (lbbdforcetyp==1)*sin(lboscilfreq*(lbcurstep-lbequstep));

  #pragma omp parallel
  {
    double interforce_t[3*lbsy.nf], sitespeed_t[3], rho_t[lbsy.nf];
    double *interforce = &interforce_t[0];
    double *sitespeed = &sitespeed_t[0];
    double *rho = &rho_t[0];
        
    #pragma omp for
    for(long il=0; il<Tmax; il++) {
      if(lbphi[il] != 11) {
        fGetSpeedAllMassSite(sitespeed, rho, &lbf[il*lbsitelength]);
        for(int ll=0; ll<3*lbsy.nf; ll++)
          interforce[ll] = lbinterforce[il*3*lbsy.nf+ll] + lbheatforce[il*3*lbsy.nf+ll] + postequil*(lbbdforce[ll]+lboscilforce[ll]*freq);
        if(lbphi[il] != 12 && lbphi[il] != 13)
          fSiteFluidCollisionCLBEGuo(&lbf[il * lbsitelength], sitespeed, &lbomega[il*lbsy.nf], lbtfbulk, lbtfclb3, lbtfclb4, rho, interforce);
        fSiteSoluteCollisionBGK(&lbf[il*lbsitelength + lbsy.nf], sitespeed);
        fSiteThermalCollisionBGK(&lbf[il*lbsitelength + (lbsy.nf+lbsy.nc)], sitespeed);
      }
    }
  }
  return 0;
}

int fCollisionCLBEHe()
{
  long Tmax = lbdm.touter;
  double freq = (lbbdforcetyp==1)*sin(lboscilfreq*(lbcurstep-lbequstep));

  #pragma omp parallel
  {
    double interforce_t[3*lbsy.nf], sitespeed_t[3], rho_t[lbsy.nf];
    double *interforce = &interforce_t[0];
    double *sitespeed = &sitespeed_t[0];
    double *rho = &rho_t[0];
      
    #pragma omp for
    for(long il=0; il<Tmax; il++) {
      if(lbphi[il] != 11) {
        fGetSpeedAllMassSite(sitespeed, rho, &lbf[il*lbsitelength]);
        for(int ll=0; ll<3*lbsy.nf; ll++)
          interforce[ll] = lbinterforce[il*3*lbsy.nf+ll] + lbheatforce[il*3*lbsy.nf+ll] + postequil*(lbbdforce[ll]+lboscilforce[ll]*freq);
        if(lbphi[il] != 12 && lbphi[il] != 13)
          fSiteFluidCollisionCLBEHe(&lbf[il * lbsitelength], sitespeed, &lbomega[il*lbsy.nf], lbtfbulk, lbtfclb3, lbtfclb4, rho, interforce);
        fSiteSoluteCollisionBGK(&lbf[il*lbsitelength + lbsy.nf], sitespeed);
        fSiteThermalCollisionBGK(&lbf[il*lbsitelength + (lbsy.nf+lbsy.nc)], sitespeed);
      }
    }
  }
  return 0;
}

int fCollisionCLBEShanChen()
{
  long Tmax = lbdm.touter;
  double freq = (lbbdforcetyp==1)*sin(lboscilfreq*(lbcurstep-lbequstep));

  #pragma omp parallel
  {
    double interforce_t[3*lbsy.nf], sitespeed_t[3], rho_t[lbsy.nf];
    double *interforce = &interforce_t[0];
    double *sitespeed = &sitespeed_t[0];
    double *rho = &rho_t[0];
        
    #pragma omp for
    for(long il=0; il<Tmax; il++) {
      if(lbphi[il] != 11) {
        fGetSpeedShanChenAllMassSite(sitespeed, rho, &lbf[il*lbsitelength], &lbomega[il*lbsy.nf]);
        for(int ll=0; ll<3*lbsy.nf; ll++)
          interforce[ll] = lbinterforce[il*3*lbsy.nf+ll] + lbheatforce[il*3*lbsy.nf+ll] + postequil*(lbbdforce[ll]+lboscilforce[ll]*freq);
        if(lbphi[il] != 12 && lbphi[il] != 13)
          fSiteFluidCollisionCLBE(&lbf[il * lbsitelength], sitespeed, &lbomega[il*lbsy.nf], lbtfbulk, lbtfclb3, lbtfclb4, rho, interforce);
        fSiteSoluteCollisionBGK(&lbf[il*lbsitelength + lbsy.nf], sitespeed);
        fSiteThermalCollisionBGK(&lbf[il*lbsitelength + (lbsy.nf+lbsy.nc)], sitespeed);
      }
    }
  }
  return 0;
}

int fCollisionCLBEEDMShanChen()
{
  long Tmax = lbdm.touter;
  double freq = (lbbdforcetyp==1)*sin(lboscilfreq*(lbcurstep-lbequstep));

  #pragma omp parallel
  {
    double interforce_t[3*lbsy.nf], sitespeed_t[3], rho_t[lbsy.nf];
    double *interforce = &interforce_t[0];
    double *sitespeed = &sitespeed_t[0];
    double *rho = &rho_t[0];
        
    #pragma omp for
    for(long il=0; il<Tmax; il++) {
      if(lbphi[il] != 11) {
        fGetSpeedShanChenAllMassSite(sitespeed, rho, &lbf[il*lbsitelength], &lbomega[il*lbsy.nf]);
        for(int ll=0; ll<3*lbsy.nf; ll++)
          interforce[ll] = lbinterforce[il*3*lbsy.nf+ll] + lbheatforce[il*3*lbsy.nf+ll] + postequil*(lbbdforce[ll]+lboscilforce[ll]*freq);
        if(lbphi[il] != 12 && lbphi[il] != 13)
          fSiteFluidCollisionCLBEEDM(&lbf[il * lbsitelength], sitespeed, &lbomega[il*lbsy.nf], lbtfbulk, lbtfclb3, lbtfclb4, rho, interforce);
        fSiteSoluteCollisionBGK(&lbf[il*lbsitelength + lbsy.nf], sitespeed);
        fSiteThermalCollisionBGK(&lbf[il*lbsitelength + (lbsy.nf+lbsy.nc)], sitespeed);
      }
    }
  }
  return 0;
}

int fCollisionCLBEGuoShanChen()
{
  long Tmax = lbdm.touter;
  double freq = (lbbdforcetyp==1)*sin(lboscilfreq*(lbcurstep-lbequstep));

  #pragma omp parallel
  {
    double interforce_t[3*lbsy.nf], sitespeed_t[3], rho_t[lbsy.nf];
    double *interforce = &interforce_t[0];
    double *sitespeed = &sitespeed_t[0];
    double *rho = &rho_t[0];
        
    #pragma omp for
    for(long il=0; il<Tmax; il++) {
      if(lbphi[il] != 11) {
        fGetSpeedShanChenAllMassSite(sitespeed, rho, &lbf[il*lbsitelength], &lbomega[il*lbsy.nf]);
        for(int ll=0; ll<3*lbsy.nf; ll++)
          interforce[ll] = lbinterforce[il*3*lbsy.nf+ll] + lbheatforce[il*3*lbsy.nf+ll] + postequil*(lbbdforce[ll]+lboscilforce[ll]*freq);
        if(lbphi[il] != 12 && lbphi[il] != 13)
          fSiteFluidCollisionCLBEGuo(&lbf[il * lbsitelength], sitespeed, &lbomega[il*lbsy.nf], lbtfbulk, lbtfclb3, lbtfclb4, rho, interforce);
        fSiteSoluteCollisionBGK(&lbf[il*lbsitelength + lbsy.nf], sitespeed);
        fSiteThermalCollisionBGK(&lbf[il*lbsitelength + (lbsy.nf+lbsy.nc)], sitespeed);
      }
    }
  }
  return 0;
}

int fCollisionCLBEHeShanChen()
{
  long Tmax = lbdm.touter;
  double freq = (lbbdforcetyp==1)*sin(lboscilfreq*(lbcurstep-lbequstep));

  #pragma omp parallel
  {
    double interforce_t[3*lbsy.nf], sitespeed_t[3], rho_t[lbsy.nf];
    double *interforce = &interforce_t[0];
    double *sitespeed = &sitespeed_t[0];
    double *rho = &rho_t[0];
      
    #pragma omp for
    for(long il=0; il<Tmax; il++) {
      if(lbphi[il] != 11) {
        fGetSpeedShanChenAllMassSite(sitespeed, rho, &lbf[il*lbsitelength], &lbomega[il*lbsy.nf]);
        for(int ll=0; ll<3*lbsy.nf; ll++)
          interforce[ll] = lbinterforce[il*3*lbsy.nf+ll] + lbheatforce[il*3*lbsy.nf+ll] + postequil*(lbbdforce[ll]+lboscilforce[ll]*freq);
        if(lbphi[il] != 12 && lbphi[il] != 13)
          fSiteFluidCollisionCLBEHe(&lbf[il * lbsitelength], sitespeed, &lbomega[il*lbsy.nf], lbtfbulk, lbtfclb3, lbtfclb4, rho, interforce);
        fSiteSoluteCollisionBGK(&lbf[il*lbsitelength + lbsy.nf], sitespeed);
        fSiteThermalCollisionBGK(&lbf[il*lbsitelength + (lbsy.nf+lbsy.nc)], sitespeed);
      }
    }
  }
  return 0;
}

int fCollisionCLBELishchuk()
{
  int numpair = 3 * lbsy.nf * (lbsy.nf-1) / 2;
  long Tmax = lbdm.touter;
  double freq = (lbbdforcetyp==1)*sin(lboscilfreq*(lbcurstep-lbequstep));
    
  #pragma omp parallel
  {
    double interforce_t[3*lbsy.nf], sitespeed_t[3], rho_t[lbsy.nf];
    double *interforce = &interforce_t[0];
    double *sitespeed = &sitespeed_t[0];
    double *rho = &rho_t[0];

    #pragma omp for
    for(long il=0; il<Tmax; il++) {
      if(lbphi[il] != 11) {
        fGetSpeedAllMassSite(sitespeed, rho, &lbf[il*lbsitelength]);
        double invallmass = 0.0;
        for(int ll=0; ll<lbsy.nf; ll++)
          invallmass += rho[ll];
        invallmass = fReciprocal(invallmass);
        interforce[0] = lbinterforce[3*il  ]; interforce[1] = lbinterforce[3*il+1]; interforce[2] = lbinterforce[3*il+2];
        for(int ll=0; ll<lbsy.nf; ll++) {
          double frac = rho[ll] * invallmass;
          interforce[0] += frac*(lbheatforce[il*3*lbsy.nf+3*ll  ]+postequil*(lbbdforce[3*ll  ]+lboscilforce[3*ll  ]*freq));
          interforce[1] += frac*(lbheatforce[il*3*lbsy.nf+3*ll+1]+postequil*(lbbdforce[3*ll+1]+lboscilforce[3*ll+1]*freq));
	      interforce[2] += frac*(lbheatforce[il*3*lbsy.nf+3*ll+2]+postequil*(lbbdforce[3*ll+2]+lboscilforce[3*ll+2]*freq));
        }
        if(lbphi[il] != 12 && lbphi[il] != 13)
          fSiteFluidCollisionCLBELishchuk(&lbf[il*lbsitelength], sitespeed, &lbomega[il*lbsy.nf], lbtfbulk, lbtfclb3, lbtfclb4, rho, interforce, &lbft[il*numpair]);
        fSiteSoluteCollisionBGK(&lbf[il*lbsitelength + lbsy.nf], sitespeed);
        fSiteThermalCollisionBGK(&lbf[il*lbsitelength + (lbsy.nf+lbsy.nc)], sitespeed);
      }
    }
  }
  return 0;
}

int fCollisionCLBEEDMLishchuk()
{
  int numpair = 3 * lbsy.nf * (lbsy.nf-1) / 2;
  long Tmax = lbdm.touter;
  double freq = (lbbdforcetyp==1)*sin(lboscilfreq*(lbcurstep-lbequstep));
    
  #pragma omp parallel
  {
    double interforce_t[3*lbsy.nf], sitespeed_t[3], rho_t[lbsy.nf];
    double *interforce = &interforce_t[0];
    double *sitespeed = &sitespeed_t[0];
    double *rho = &rho_t[0];

    #pragma omp for
    for(long il=0; il<Tmax; il++) {
      if(lbphi[il] != 11) {
        fGetSpeedAllMassSite(sitespeed, rho, &lbf[il*lbsitelength]);
        double invallmass = 0.0;
        for(int ll=0; ll<lbsy.nf; ll++)
          invallmass += rho[ll];
        invallmass = fReciprocal(invallmass);
        interforce[0] = lbinterforce[3*il  ]; interforce[1] = lbinterforce[3*il+1]; interforce[2] = lbinterforce[3*il+2];
        for(int ll=0; ll<lbsy.nf; ll++) {
          double frac = rho[ll] * invallmass;
          interforce[0] += frac*(lbheatforce[il*3*lbsy.nf+3*ll  ]+postequil*(lbbdforce[3*ll  ]+lboscilforce[3*ll  ]*freq));
          interforce[1] += frac*(lbheatforce[il*3*lbsy.nf+3*ll+1]+postequil*(lbbdforce[3*ll+1]+lboscilforce[3*ll+1]*freq));
	      interforce[2] += frac*(lbheatforce[il*3*lbsy.nf+3*ll+2]+postequil*(lbbdforce[3*ll+2]+lboscilforce[3*ll+2]*freq));
        }
        if(lbphi[il] != 12 && lbphi[il] != 13)
          fSiteFluidCollisionCLBEEDMLishchuk(&lbf[il*lbsitelength], sitespeed, &lbomega[il*lbsy.nf], lbtfbulk, lbtfclb3, lbtfclb4, rho, interforce, &lbft[il*numpair]);
        fSiteSoluteCollisionBGK(&lbf[il*lbsitelength + lbsy.nf], sitespeed);
        fSiteThermalCollisionBGK(&lbf[il*lbsitelength + (lbsy.nf+lbsy.nc)], sitespeed);
      }
    }
  }
  return 0;
}


int fCollisionCLBEGuoLishchuk()
{
  int numpair = 3 * lbsy.nf * (lbsy.nf-1) / 2;
  long Tmax = lbdm.touter;
  double freq = (lbbdforcetyp==1)*sin(lboscilfreq*(lbcurstep-lbequstep));
    
  #pragma omp parallel
  {
    double interforce_t[3*lbsy.nf], sitespeed_t[3], rho_t[lbsy.nf];
    double *interforce = &interforce_t[0];
    double *sitespeed = &sitespeed_t[0];
    double *rho = &rho_t[0];

    #pragma omp for
    for(long il=0; il<Tmax; il++) {
      if(lbphi[il] != 11) {
        fGetSpeedAllMassSite(sitespeed, rho, &lbf[il*lbsitelength]);
        double invallmass = 0.0;
        for(int ll=0; ll<lbsy.nf; ll++)
          invallmass += rho[ll];
        invallmass = fReciprocal(invallmass);
        interforce[0] = lbinterforce[3*il  ]; interforce[1] = lbinterforce[3*il+1]; interforce[2] = lbinterforce[3*il+2];
        for(int ll=0; ll<lbsy.nf; ll++) {
          double frac = rho[ll] * invallmass;
          interforce[0] += frac*(lbheatforce[il*3*lbsy.nf+3*ll  ]+postequil*(lbbdforce[3*ll  ]+lboscilforce[3*ll  ]*freq));
          interforce[1] += frac*(lbheatforce[il*3*lbsy.nf+3*ll+1]+postequil*(lbbdforce[3*ll+1]+lboscilforce[3*ll+1]*freq));
	      interforce[2] += frac*(lbheatforce[il*3*lbsy.nf+3*ll+2]+postequil*(lbbdforce[3*ll+2]+lboscilforce[3*ll+2]*freq));
        }
        if(lbphi[il] != 12 && lbphi[il] != 13)
          fSiteFluidCollisionCLBEGuoLishchuk(&lbf[il*lbsitelength], sitespeed, &lbomega[il*lbsy.nf], lbtfbulk, lbtfclb3, lbtfclb4, rho, interforce, &lbft[il*numpair]);
        fSiteSoluteCollisionBGK(&lbf[il*lbsitelength + lbsy.nf], sitespeed);
        fSiteThermalCollisionBGK(&lbf[il*lbsitelength + (lbsy.nf+lbsy.nc)], sitespeed);
      }
    }
  }
  return 0;
}


int fCollisionCLBEHeLishchuk()
{
  int numpair = 3 * lbsy.nf * (lbsy.nf-1) / 2;
  long Tmax = lbdm.touter;
  double freq = (lbbdforcetyp==1)*sin(lboscilfreq*(lbcurstep-lbequstep));
    
  #pragma omp parallel
  {
    double interforce_t[3*lbsy.nf], sitespeed_t[3], rho_t[lbsy.nf];
    double *interforce = &interforce_t[0];
    double *sitespeed = &sitespeed_t[0];
    double *rho = &rho_t[0];

    #pragma omp for
    for(long il=0; il<Tmax; il++) {
      if(lbphi[il] != 11) {
        fGetSpeedAllMassSite(sitespeed, rho, &lbf[il*lbsitelength]);
        double invallmass = 0.0;
        for(int ll=0; ll<lbsy.nf; ll++)
          invallmass += rho[ll];
        invallmass = fReciprocal(invallmass);
        interforce[0] = lbinterforce[3*il  ]; interforce[1] = lbinterforce[3*il+1]; interforce[2] = lbinterforce[3*il+2];
        for(int ll=0; ll<lbsy.nf; ll++) {
          double frac = rho[ll] * invallmass;
          interforce[0] += frac*(lbheatforce[il*3*lbsy.nf+3*ll  ]+postequil*(lbbdforce[3*ll  ]+lboscilforce[3*ll  ]*freq));
          interforce[1] += frac*(lbheatforce[il*3*lbsy.nf+3*ll+1]+postequil*(lbbdforce[3*ll+1]+lboscilforce[3*ll+1]*freq));
	      interforce[2] += frac*(lbheatforce[il*3*lbsy.nf+3*ll+2]+postequil*(lbbdforce[3*ll+2]+lboscilforce[3*ll+2]*freq));
        }
        if(lbphi[il] != 12 && lbphi[il] != 13)
          fSiteFluidCollisionCLBEHeLishchuk(&lbf[il*lbsitelength], sitespeed, &lbomega[il*lbsy.nf], lbtfbulk, lbtfclb3, lbtfclb4, rho, interforce, &lbft[il*numpair]);
        fSiteSoluteCollisionBGK(&lbf[il*lbsitelength + lbsy.nf], sitespeed);
        fSiteThermalCollisionBGK(&lbf[il*lbsitelength + (lbsy.nf+lbsy.nc)], sitespeed);
      }
    }
  }
  return 0;
}


int fCollisionCLBELishchukLocal()
{
  int numpair = 3 * lbsy.nf * (lbsy.nf-1) / 2;
  int threed = (lbsy.nd>2);
  long Tmax = lbdm.touter;
  double freq = (lbbdforcetyp==1)*sin(lboscilfreq*(lbcurstep-lbequstep));

  #pragma omp parallel
  {
    double interforce_t[3*lbsy.nf], sitespeed_t[3], rho_t[lbsy.nf];
    double *interforce = &interforce_t[0];
    double *sitespeed = &sitespeed_t[0];
    double *rho = &rho_t[0];

    #pragma omp for
    for(long il=0; il<Tmax; il++) {
      if(lbphi[il] != 11) {
        fGetSpeedAllMassSite(sitespeed, rho, &lbf[il*lbsitelength]);
        double invallmass = 0.0;
        for(int ll=0; ll<lbsy.nf; ll++)
          invallmass += rho[ll];
        invallmass = fReciprocal(invallmass);
        interforce[0] = lbinterforce[3*il  ]; interforce[1] = lbinterforce[3*il+1]; interforce[2] = lbinterforce[3*il+2];
        for(int ll=0; ll<lbsy.nf; ll++) {
          double frac = rho[ll] * invallmass;
          interforce[0] += frac*(lbheatforce[il*3*lbsy.nf+3*ll  ]+postequil*(lbbdforce[3*ll  ]+lboscilforce[3*ll  ]*freq));
          interforce[1] += frac*(lbheatforce[il*3*lbsy.nf+3*ll+1]+postequil*(lbbdforce[3*ll+1]+lboscilforce[3*ll+1]*freq));
	      interforce[2] += frac*(lbheatforce[il*3*lbsy.nf+3*ll+2]+postequil*(lbbdforce[3*ll+2]+lboscilforce[3*ll+2]*freq));
        }
        if(lbphi[il] != 12 && lbphi[il] != 13)
          fSiteFluidCollisionCLBELishchukLocal(&lbf[il*lbsitelength], sitespeed, &lbomega[il*lbsy.nf], lbtfbulk, lbtfclb3, lbtfclb4, rho, interforce, &lbft[il*numpair], threed);
        fSiteSoluteCollisionBGK(&lbf[il*lbsitelength + lbsy.nf], sitespeed);
        fSiteThermalCollisionBGK(&lbf[il*lbsitelength + (lbsy.nf+lbsy.nc)], sitespeed);
      }
    }
  }
  return 0;
}

int fCollisionCLBEEDMLishchukLocal()
{
  int numpair = 3 * lbsy.nf * (lbsy.nf-1) / 2;
  int threed = (lbsy.nd>2);
  long Tmax = lbdm.touter;
  double freq = (lbbdforcetyp==1)*sin(lboscilfreq*(lbcurstep-lbequstep));

  #pragma omp parallel
  {
    double interforce_t[3*lbsy.nf], sitespeed_t[3], rho_t[lbsy.nf];
    double *interforce = &interforce_t[0];
    double *sitespeed = &sitespeed_t[0];
    double *rho = &rho_t[0];

    #pragma omp for
    for(long il=0; il<Tmax; il++) {
      if(lbphi[il] != 11) {
        fGetSpeedAllMassSite(sitespeed, rho, &lbf[il*lbsitelength]);
        double invallmass = 0.0;
        for(int ll=0; ll<lbsy.nf; ll++)
          invallmass += rho[ll];
        invallmass = fReciprocal(invallmass);
        interforce[0] = lbinterforce[3*il  ]; interforce[1] = lbinterforce[3*il+1]; interforce[2] = lbinterforce[3*il+2];
        for(int ll=0; ll<lbsy.nf; ll++) {
          double frac = rho[ll] * invallmass;
          interforce[0] += frac*(lbheatforce[il*3*lbsy.nf+3*ll  ]+postequil*(lbbdforce[3*ll  ]+lboscilforce[3*ll  ]*freq));
          interforce[1] += frac*(lbheatforce[il*3*lbsy.nf+3*ll+1]+postequil*(lbbdforce[3*ll+1]+lboscilforce[3*ll+1]*freq));
	      interforce[2] += frac*(lbheatforce[il*3*lbsy.nf+3*ll+2]+postequil*(lbbdforce[3*ll+2]+lboscilforce[3*ll+2]*freq));
        }
        if(lbphi[il] != 12 && lbphi[il] != 13)
          fSiteFluidCollisionCLBEEDMLishchukLocal(&lbf[il*lbsitelength], sitespeed, &lbomega[il*lbsy.nf], lbtfbulk, lbtfclb3, lbtfclb4, rho, interforce, &lbft[il*numpair], threed);
        fSiteSoluteCollisionBGK(&lbf[il*lbsitelength + lbsy.nf], sitespeed);
        fSiteThermalCollisionBGK(&lbf[il*lbsitelength + (lbsy.nf+lbsy.nc)], sitespeed);
      }
    }
  }
  return 0;
}

int fCollisionCLBEGuoLishchukLocal()
{
  int numpair = 3 * lbsy.nf * (lbsy.nf-1) / 2;
  int threed = (lbsy.nd>2);
  long Tmax = lbdm.touter;
  double freq = (lbbdforcetyp==1)*sin(lboscilfreq*(lbcurstep-lbequstep));

  #pragma omp parallel
  {
    double interforce_t[3*lbsy.nf], sitespeed_t[3], rho_t[lbsy.nf];
    double *interforce = &interforce_t[0];
    double *sitespeed = &sitespeed_t[0];
    double *rho = &rho_t[0];

    #pragma omp for
    for(long il=0; il<Tmax; il++) {
      if(lbphi[il] != 11) {
        fGetSpeedAllMassSite(sitespeed, rho, &lbf[il*lbsitelength]);
        double invallmass = 0.0;
        for(int ll=0; ll<lbsy.nf; ll++)
          invallmass += rho[ll];
        invallmass = fReciprocal(invallmass);
        interforce[0] = lbinterforce[3*il  ]; interforce[1] = lbinterforce[3*il+1]; interforce[2] = lbinterforce[3*il+2];
        for(int ll=0; ll<lbsy.nf; ll++) {
          double frac = rho[ll] * invallmass;
          interforce[0] += frac*(lbheatforce[il*3*lbsy.nf+3*ll  ]+postequil*(lbbdforce[3*ll  ]+lboscilforce[3*ll  ]*freq));
          interforce[1] += frac*(lbheatforce[il*3*lbsy.nf+3*ll+1]+postequil*(lbbdforce[3*ll+1]+lboscilforce[3*ll+1]*freq));
	      interforce[2] += frac*(lbheatforce[il*3*lbsy.nf+3*ll+2]+postequil*(lbbdforce[3*ll+2]+lboscilforce[3*ll+2]*freq));
        }
        if(lbphi[il] != 12 && lbphi[il] != 13)
          fSiteFluidCollisionCLBEGuoLishchukLocal(&lbf[il*lbsitelength], sitespeed, &lbomega[il*lbsy.nf], lbtfbulk, lbtfclb3, lbtfclb4, rho, interforce, &lbft[il*numpair], threed);
        fSiteSoluteCollisionBGK(&lbf[il*lbsitelength + lbsy.nf], sitespeed);
        fSiteThermalCollisionBGK(&lbf[il*lbsitelength + (lbsy.nf+lbsy.nc)], sitespeed);
      }
    }
  }
  return 0;
}

int fCollisionCLBEHeLishchukLocal()
{
  int numpair = 3 * lbsy.nf * (lbsy.nf-1) / 2;
  int threed = (lbsy.nd>2);
  long Tmax = lbdm.touter;
  double freq = (lbbdforcetyp==1)*sin(lboscilfreq*(lbcurstep-lbequstep));

  #pragma omp parallel
  {
    double interforce_t[3*lbsy.nf], sitespeed_t[3], rho_t[lbsy.nf];
    double *interforce = &interforce_t[0];
    double *sitespeed = &sitespeed_t[0];
    double *rho = &rho_t[0];

    #pragma omp for
    for(long il=0; il<Tmax; il++) {
      if(lbphi[il] != 11) {
        fGetSpeedAllMassSite(sitespeed, rho, &lbf[il*lbsitelength]);
        double invallmass = 0.0;
        for(int ll=0; ll<lbsy.nf; ll++)
          invallmass += rho[ll];
        invallmass = fReciprocal(invallmass);
        interforce[0] = lbinterforce[3*il  ]; interforce[1] = lbinterforce[3*il+1]; interforce[2] = lbinterforce[3*il+2];
        for(int ll=0; ll<lbsy.nf; ll++) {
          double frac = rho[ll] * invallmass;
          interforce[0] += frac*(lbheatforce[il*3*lbsy.nf+3*ll  ]+postequil*(lbbdforce[3*ll  ]+lboscilforce[3*ll  ]*freq));
          interforce[1] += frac*(lbheatforce[il*3*lbsy.nf+3*ll+1]+postequil*(lbbdforce[3*ll+1]+lboscilforce[3*ll+1]*freq));
	      interforce[2] += frac*(lbheatforce[il*3*lbsy.nf+3*ll+2]+postequil*(lbbdforce[3*ll+2]+lboscilforce[3*ll+2]*freq));
        }
        if(lbphi[il] != 12 && lbphi[il] != 13)
          fSiteFluidCollisionCLBEHeLishchukLocal(&lbf[il*lbsitelength], sitespeed, &lbomega[il*lbsy.nf], lbtfbulk, lbtfclb3, lbtfclb4, rho, interforce, &lbft[il*numpair], threed);
        fSiteSoluteCollisionBGK(&lbf[il*lbsitelength + lbsy.nf], sitespeed);
        fSiteThermalCollisionBGK(&lbf[il*lbsitelength + (lbsy.nf+lbsy.nc)], sitespeed);
      }
    }
  }
  return 0;
}

