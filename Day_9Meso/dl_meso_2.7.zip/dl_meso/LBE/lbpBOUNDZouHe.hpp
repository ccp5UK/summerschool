int fD2Q9VCEZouHe(double v0, double v1, double *force, double *f0, double *f1, double *f2,
                  double *f3, double *f4, double *f5, double *f6, double *f7, double *f8);
int fD2Q9VCCZouHe(double *p, double v0, double v1, double *force, double *f0, double *f1, double *f2,
                  double *f3, double *f4, double *f5, double *f6, double *f7, double *f8);
int fD2Q9VCECLBEZouHe(double v0, double v1, double *force, double *f0, double *f1, double *f2,
                      double *f3, double *f4, double *f5, double *f6, double *f7, double *f8);
int fD2Q9VCCCLBEZouHe(double *p, double v0, double v1, double *force, double *f0, double *f1, double *f2,
                      double *f3, double *f4, double *f5, double *f6, double *f7, double *f8);
int fD2Q9VCESimpleZouHe(double v0, double v1, double *force, double *f0, double *f1, double *f2,
                        double *f3, double *f4, double *f5, double *f6, double *f7, double *f8);
int fD2Q9VCCSimpleZouHe(double *p, double v0, double v1, double *force, double *f0, double *f1, double *f2,
                        double *f3, double *f4, double *f5, double *f6, double *f7, double *f8);
int fD2Q9VCECLBESimpleZouHe(double v0, double v1, double *force, double *f0, double *f1, double *f2,
                            double *f3, double *f4, double *f5, double *f6, double *f7, double *f8);
int fD2Q9VCCCLBESimpleZouHe(double *p, double v0, double v1, double *force, double *f0, double *f1, double *f2,
                            double *f3, double *f4, double *f5, double *f6, double *f7, double *f8);
int fD2Q9VFZouHe(long tpos, long tpos1, int prop, double *uwall, double dx, double dy);
int fD2Q9VFSimpleZouHe(long tpos, long tpos1, int prop, double *uwall, double dx, double dy);
int fD2Q9PCEZouHe(double *p, double *force, double *f0, double *f1, double *f2, double *f3,
                  double *f4, double *f5, double *f6, double *f7, double *f8, double &vel);
int fD2Q9PCESwiftZouHe(double *p, double *force, double *f0, double *f1, double *f2, double *f3,
                       double *f4, double *f5, double *f6, double *f7, double *f8, double &vel);
int fD2Q9PFZouHe(long tpos, int prop, double *p0, double *uwall);
int fD2Q9PFSimpleZouHe(long tpos, int prop, double *p0, double *uwall);
int fD2Q9CCEZouHe(double *p, double v0, double v1, double *f0, double *f1, double *f2,
                  double *f3, double *f4, double *f5, double *f6, double *f7, double *f8);
int fD2Q9CCCZouHe(double *p, double v0, double v1, double *f0, double *f1, double *f2,
                  double *f3, double *f4, double *f5, double *f6, double *f7, double *f8);
int fD2Q9PCZouHe(long tpos, int prop, double *p0, double *uwall);
int fD2Q9TCEZouHe(double p, double v0, double v1, double *f0, double *f1, double *f2,
                  double *f3, double *f4, double *f5, double *f6, double *f7, double *f8);
int fD2Q9TCCZouHe(double p, double v0, double v1, double *f0, double *f1, double *f2,
                  double *f3, double *f4, double *f5, double *f6, double *f7, double *f8);
int fD2Q9PTZouHe(long tpos, int prop, double p0, double *uwall);

int fD3Q15VPSZouHe(double v0, double v1, double v2, double *force, double *f0, double *f1, double *f2,
                   double *f3, double *f4, double *f5, double *f6, double *f7, double *f8,
                   double *f9, double *f10, double *f11, double *f12, double *f13, double *f14);
int fD3Q15VCEZouHe(double *p, double v0, double v1, double v2, double *force, double *f0, double *f1, double *f2,
                   double *f3, double *f4, double *f5, double *f6, double *f7, double *f8,
                   double *f9, double *f10, double *f11, double *f12, double *f13, double *f14);
int fD3Q15VCCZouHe(double *p, double v0, double v1, double v2, double *force, double *f0, double *f1, double *f2,
                   double *f3, double *f4, double *f5, double *f6, double *f7, double *f8,
                   double *f9, double *f10, double *f11, double *f12, double *f13, double *f14);
int fD3Q15VPSSimpleZouHe(double v0, double v1, double v2, double *force, double *f0, double *f1, double *f2,
                         double *f3, double *f4, double *f5, double *f6, double *f7, double *f8,
                         double *f9, double *f10, double *f11, double *f12, double *f13, double *f14);
int fD3Q15VCESimpleZouHe(double *p, double v0, double v1, double v2, double *force, double *f0, double *f1, double *f2,
                         double *f3, double *f4, double *f5, double *f6, double *f7, double *f8,
                         double *f9, double *f10, double *f11, double *f12, double *f13, double *f14);
int fD3Q15VCCSimpleZouHe(double *p, double v0, double v1, double v2, double *force, double *f0, double *f1, double *f2,
                         double *f3, double *f4, double *f5, double *f6, double *f7, double *f8,
                         double *f9, double *f10, double *f11, double *f12, double *f13, double *f14);
int fD3Q15VFZouHe(long tpos, long rpos, int prop, double *uwall, double dx, double dy, double dz);
int fD3Q15VFSimpleZouHe(long tpos, long rpos, int prop, double *uwall, double dx, double dy, double dz);
int fD3Q15PPSZouHe(double *p, double *force, double *f0, double *f1,
                   double *f2, double *f3, double *f4, double *f5,
                   double *f6, double *f7, double *f8, double *f9,
                   double *f10, double *f11, double *f12, double *f13,
                   double *f14, double &vel);
int fD3Q15PPSSwiftZouHe(double *p, double *force, double *f0, double *f1,
                        double *f2, double *f3, double *f4, double *f5,
                        double *f6, double *f7, double *f8, double *f9,
                        double *f10, double *f11, double *f12, double *f13,
                        double *f14, double &vel);
int fD3Q15PFZouHe(long tpos, int prop, double *p0, double *uwall);
int fD3Q15PFSimpleZouHe(long tpos, int prop, double *p0, double *uwall);
int fD3Q15CPSZouHe(double *p, double v0, double v1, double v2, double *f0, double *f1,
                   double *f2, double *f3, double *f4, double *f5, double *f6,
                   double *f7, double *f8, double *f9, double *f10, double *f11,
                   double *f12, double *f13, double *f14);
int fD3Q15CCEZouHe(double *p, double v0, double v1, double v2, double *f0, double *f1,
                   double *f2, double *f3, double *f4, double *f5, double *f6,
                   double *f7, double *f8, double *f9, double *f10, double *f11,
                   double *f12, double *f13, double *f14);
int fD3Q15CCCZouHe(double *p, double v0, double v1, double v2, double *f0, double *f1,
                   double *f2, double *f3, double *f4, double *f5, double *f6,
                   double *f7, double *f8, double *f9, double *f10, double *f11,
                   double *f12, double *f13, double *f14);
int fD3Q15PCZouHe(long tpos, int prop, double *p0, double *uwall);
int fD3Q15TPSZouHe(double p, double v0, double v1, double v2, double *f0, double *f1,
                   double *f2, double *f3, double *f4, double *f5, double *f6,
                   double *f7, double *f8, double *f9, double *f10, double *f11,
                   double *f12, double *f13, double *f14);
int fD3Q15TCEZouHe(double p, double v0, double v1, double v2, double *f0, double *f1,
                   double *f2, double *f3, double *f4, double *f5, double *f6,
                   double *f7, double *f8, double *f9, double *f10, double *f11,
                   double *f12, double *f13, double *f14);
int fD3Q15TCCZouHe(double p, double v0, double v1, double v2, double *f0, double *f1,
                   double *f2, double *f3, double *f4, double *f5, double *f6,
                   double *f7, double *f8, double *f9, double *f10, double *f11,
                   double *f12, double *f13, double *f14);
int fD3Q15PTZouHe(long tpos, int prop, double p0, double *uwall);

int fD3Q19VPSZouHe(double v0, double v1, double v2, double *force, double *f0, double *f1, double *f2,
                   double *f3, double *f4, double *f5, double *f6, double *f7, double *f8,
                   double *f9, double *f10, double *f11, double *f12, double *f13, double *f14,
                   double *f15, double *f16, double *f17, double *f18);
int fD3Q19VCEZouHe(double *p, double v0, double v1, double v2, double *force, double *f0, double *f1, double *f2,
                   double *f3, double *f4, double *f5, double *f6, double *f7, double *f8,
                   double *f9, double *f10, double *f11, double *f12, double *f13, double *f14,
                   double *f15, double *f16, double *f17, double *f18);
int fD3Q19VCCZouHe(double *p, double v0, double v1, double v2, double *force, double *f0, double *f1, double *f2,
                   double *f3, double *f4, double *f5, double *f6, double *f7, double *f8,
                   double *f9, double *f10, double *f11, double *f12, double *f13, double *f14,
                   double *f15, double *f16, double *f17, double *f18);
int fD3Q19VPSCLBEZouHe(double v0, double v1, double v2, double *force, double *f0, double *f1, double *f2,
                       double *f3, double *f4, double *f5, double *f6, double *f7, double *f8,
                       double *f9, double *f10, double *f11, double *f12, double *f13, double *f14,
                       double *f15, double *f16, double *f17, double *f18);
int fD3Q19VCECLBEZouHe(double *p, double v0, double v1, double v2, double *force, double *f0, double *f1, double *f2,
                       double *f3, double *f4, double *f5, double *f6, double *f7, double *f8,
                       double *f9, double *f10, double *f11, double *f12, double *f13, double *f14,
                       double *f15, double *f16, double *f17, double *f18);
int fD3Q19VCCCLBEZouHe(double *p, double v0, double v1, double v2, double *force, double *f0, double *f1, double *f2,
                       double *f3, double *f4, double *f5, double *f6, double *f7, double *f8,
                       double *f9, double *f10, double *f11, double *f12, double *f13, double *f14,
                       double *f15, double *f16, double *f17, double *f18);
int fD3Q19VPSSimpleZouHe(double v0, double v1, double v2, double *force, double *f0, double *f1, double *f2,
                         double *f3, double *f4, double *f5, double *f6, double *f7, double *f8,
                         double *f9, double *f10, double *f11, double *f12, double *f13, double *f14,
                         double *f15, double *f16, double *f17, double *f18);
int fD3Q19VCESimpleZouHe(double *p, double v0, double v1, double v2, double *force, double *f0, double *f1, double *f2,
                         double *f3, double *f4, double *f5, double *f6, double *f7, double *f8,
                         double *f9, double *f10, double *f11, double *f12, double *f13, double *f14,
                         double *f15, double *f16, double *f17, double *f18);
int fD3Q19VCCSimpleZouHe(double *p, double v0, double v1, double v2, double *force, double *f0, double *f1, double *f2,
                         double *f3, double *f4, double *f5, double *f6, double *f7, double *f8,
                         double *f9, double *f10, double *f11, double *f12, double *f13, double *f14,
                         double *f15, double *f16, double *f17, double *f18);
int fD3Q19VPSCLBESimpleZouHe(double v0, double v1, double v2, double *force, double *f0, double *f1, double *f2,
                             double *f3, double *f4, double *f5, double *f6, double *f7, double *f8,
                             double *f9, double *f10, double *f11, double *f12, double *f13, double *f14,
                             double *f15, double *f16, double *f17, double *f18);
int fD3Q19VCECLBESimpleZouHe(double *p, double v0, double v1, double v2, double *force, double *f0, double *f1, double *f2,
                             double *f3, double *f4, double *f5, double *f6, double *f7, double *f8,
                             double *f9, double *f10, double *f11, double *f12, double *f13, double *f14,
                             double *f15, double *f16, double *f17, double *f18);
int fD3Q19VCCCLBESimpleZouHe(double *p, double v0, double v1, double v2, double *force, double *f0, double *f1, double *f2,
                             double *f3, double *f4, double *f5, double *f6, double *f7, double *f8,
                             double *f9, double *f10, double *f11, double *f12, double *f13, double *f14,
                             double *f15, double *f16, double *f17, double *f18);
int fD3Q19VFZouHe(long tpos, long rpos, int prop, double *uwall, double dx, double dy, double dz);
int fD3Q19VFSimpleZouHe(long tpos, long rpos, int prop, double *uwall, double dx, double dy, double dz);
int fD3Q19PPSZouHe(double *p, double *force, double *f0, double *f1,
                   double *f2, double *f3, double *f4, double *f5,
                   double *f6, double *f7, double *f8, double *f9,
                   double *f10, double *f11, double *f12, double *f13,
                   double *f14, double *f15, double *f16, double *f17,
                   double *f18, double &vel);
int fD3Q19PPSSwiftZouHe(double *p, double *force, double *f0, double *f1,
                        double *f2, double *f3, double *f4, double *f5,
                        double *f6, double *f7, double *f8, double *f9,
                        double *f10, double *f11, double *f12, double *f13,
                        double *f14, double *f15, double *f16, double *f17,
                        double *f18, double &vel);
int fD3Q19PFZouHe(long tpos, int prop, double *p0, double *uwall);
int fD3Q19PFSimpleZouHe(long tpos, int prop, double *p0, double *uwall);
int fD3Q19CPSZouHe(double *p, double v0, double v1, double v2, double *f0, double *f1,
                   double *f2, double *f3, double *f4, double *f5, double *f6,
                   double *f7, double *f8, double *f9, double *f10, double *f11,
                   double *f12, double *f13, double *f14, double *f15, double *f16,
                   double *f17, double *f18);
int fD3Q19CCEZouHe(double *p, double v0, double v1, double v2, double *f0, double *f1,
                   double *f2, double *f3, double *f4, double *f5, double *f6,
                   double *f7, double *f8, double *f9, double *f10, double *f11,
                   double *f12, double *f13, double *f14, double *f15, double *f16,
                   double *f17, double *f18);
int fD3Q19CCCZouHe(double *p, double v0, double v1, double v2, double *f0, double *f1,
                   double *f2, double *f3, double *f4, double *f5, double *f6,
                   double *f7, double *f8, double *f9, double *f10, double *f11,
                   double *f12, double *f13, double *f14, double *f15, double *f16,
                   double *f17, double *f18);
int fD3Q19PCZouHe(long tpos, int prop, double *p0, double *uwall);
int fD3Q19TPSZouHe(double p, double v0, double v1, double v2, double *f0, double *f1,
                   double *f2, double *f3, double *f4, double *f5, double *f6,
                   double *f7, double *f8, double *f9, double *f10, double *f11,
                   double *f12, double *f13, double *f14, double *f15, double *f16,
                   double *f17, double *f18);
int fD3Q19TCEZouHe(double p, double v0, double v1, double v2, double *f0, double *f1,
                   double *f2, double *f3, double *f4, double *f5, double *f6,
                   double *f7, double *f8, double *f9, double *f10, double *f11,
                   double *f12, double *f13, double *f14, double *f15, double *f16,
                   double *f17, double *f18);
int fD3Q19TCCZouHe(double p, double v0, double v1, double v2, double *f0, double *f1,
                   double *f2, double *f3, double *f4, double *f5, double *f6,
                   double *f7, double *f8, double *f9, double *f10, double *f11,
                   double *f12, double *f13, double *f14, double *f15, double *f16,
                   double *f17, double *f18);
int fD3Q19PTZouHe(long tpos, int prop, double p0, double *uwall);

int fD3Q27VPSZouHe(double v0, double v1, double v2, double *force, double *f0, double *f1, double *f2,
                   double *f3, double *f4, double *f5, double *f6, double *f7, double *f8,
                   double *f9, double *f10, double *f11, double *f12, double *f13, double *f14,
                   double *f15, double *f16, double *f17, double *f18, double *f19, double *f20,
                   double *f21, double *f22, double *f23, double *f24, double *f25, double *f26);
int fD3Q27VCEZouHe(double *p, double v0, double v1, double v2, double *force, double *f0, double *f1, double *f2,
                   double *f3, double *f4, double *f5, double *f6, double *f7, double *f8,
                   double *f9, double *f10, double *f11, double *f12, double *f13, double *f14,
                   double *f15, double *f16, double *f17, double *f18, double *f19, double *f20,
                   double *f21, double *f22, double *f23, double *f24, double *f25, double *f26);
int fD3Q27VCCZouHe(double *p, double v0, double v1, double v2, double *force, double *f0, double *f1, double *f2,
                   double *f3, double *f4, double *f5, double *f6, double *f7, double *f8,
                   double *f9, double *f10, double *f11, double *f12, double *f13, double *f14,
                   double *f15, double *f16, double *f17, double *f18, double *f19, double *f20,
                   double *f21, double *f22, double *f23, double *f24, double *f25, double *f26);
int fD3Q27VPSCLBEZouHe(double v0, double v1, double v2, double *force, double *f0, double *f1, double *f2,
                       double *f3, double *f4, double *f5, double *f6, double *f7, double *f8,
                       double *f9, double *f10, double *f11, double *f12, double *f13, double *f14,
                       double *f15, double *f16, double *f17, double *f18, double *f19, double *f20,
                       double *f21, double *f22, double *f23, double *f24, double *f25, double *f26);
int fD3Q27VCECLBEZouHe(double *p, double v0, double v1, double v2, double *force, double *f0, double *f1, double *f2,
                       double *f3, double *f4, double *f5, double *f6, double *f7, double *f8,
                       double *f9, double *f10, double *f11, double *f12, double *f13, double *f14,
                       double *f15, double *f16, double *f17, double *f18, double *f19, double *f20,
                       double *f21, double *f22, double *f23, double *f24, double *f25, double *f26);
int fD3Q27VCCCLBEZouHe(double *p, double v0, double v1, double v2, double *force, double *f0, double *f1, double *f2,
                       double *f3, double *f4, double *f5, double *f6, double *f7, double *f8,
                       double *f9, double *f10, double *f11, double *f12, double *f13, double *f14,
                       double *f15, double *f16, double *f17, double *f18, double *f19, double *f20,
                       double *f21, double *f22, double *f23, double *f24, double *f25, double *f26);
int fD3Q27VPSSimpleZouHe(double v0, double v1, double v2, double *force, double *f0, double *f1, double *f2,
                         double *f3, double *f4, double *f5, double *f6, double *f7, double *f8,
                         double *f9, double *f10, double *f11, double *f12, double *f13, double *f14,
                         double *f15, double *f16, double *f17, double *f18, double *f19, double *f20,
                         double *f21, double *f22, double *f23, double *f24, double *f25, double *f26);
int fD3Q27VCESimpleZouHe(double *p, double v0, double v1, double v2, double *force, double *f0, double *f1, double *f2,
                         double *f3, double *f4, double *f5, double *f6, double *f7, double *f8,
                         double *f9, double *f10, double *f11, double *f12, double *f13, double *f14,
                         double *f15, double *f16, double *f17, double *f18, double *f19, double *f20,
                         double *f21, double *f22, double *f23, double *f24, double *f25, double *f26);
int fD3Q27VCCSimpleZouHe(double *p, double v0, double v1, double v2, double *force, double *f0, double *f1, double *f2,
                         double *f3, double *f4, double *f5, double *f6, double *f7, double *f8,
                         double *f9, double *f10, double *f11, double *f12, double *f13, double *f14,
                         double *f15, double *f16, double *f17, double *f18, double *f19, double *f20,
                         double *f21, double *f22, double *f23, double *f24, double *f25, double *f26);
int fD3Q27VPSCLBESimpleZouHe(double v0, double v1, double v2, double *force, double *f0, double *f1, double *f2,
                             double *f3, double *f4, double *f5, double *f6, double *f7, double *f8,
                             double *f9, double *f10, double *f11, double *f12, double *f13, double *f14,
                             double *f15, double *f16, double *f17, double *f18, double *f19, double *f20,
                             double *f21, double *f22, double *f23, double *f24, double *f25, double *f26);
int fD3Q27VCECLBESimpleZouHe(double *p, double v0, double v1, double v2, double *force, double *f0, double *f1, double *f2,
                             double *f3, double *f4, double *f5, double *f6, double *f7, double *f8,
                             double *f9, double *f10, double *f11, double *f12, double *f13, double *f14,
                             double *f15, double *f16, double *f17, double *f18, double *f19, double *f20,
                             double *f21, double *f22, double *f23, double *f24, double *f25, double *f26);
int fD3Q27VCCCLBESimpleZouHe(double *p, double v0, double v1, double v2, double *force, double *f0, double *f1, double *f2,
                             double *f3, double *f4, double *f5, double *f6, double *f7, double *f8,
                             double *f9, double *f10, double *f11, double *f12, double *f13, double *f14,
                             double *f15, double *f16, double *f17, double *f18, double *f19, double *f20,
                             double *f21, double *f22, double *f23, double *f24, double *f25, double *f26);
int fD3Q27VFZouHe(long tpos, long rpos, int prop, double *uwall);
int fD3Q27VFSimpleZouHe(long tpos, long rpos, int prop, double *uwall);
int fD3Q27PPSZouHe(double *p, double *force, double *f0, double *f1,
                   double *f2, double *f3, double *f4, double *f5,
                   double *f6, double *f7, double *f8, double *f9,
                   double *f10, double *f11, double *f12, double *f13,
                   double *f14, double *f15, double *f16, double *f17,
                   double *f18, double *f19, double *f20, double *f21,
                   double *f22, double *f23, double *f24, double *f25,
                   double *f26, double &vel);
int fD3Q27PFZouHe(long tpos, int prop, double *p0, double *uwall);
int fD3Q27PFSimpleZouHe(long tpos, int prop, double *p0, double *uwall);
int fD3Q27CPSZouHe(double *p, double v0, double v1, double v2, double *f0, double *f1,
                   double *f2, double *f3, double *f4, double *f5, double *f6,
                   double *f7, double *f8, double *f9, double *f10, double *f11,
                   double *f12, double *f13, double *f14, double *f15, double *f16,
                   double *f17, double *f18, double *f19, double *f20, double *f21,
                   double *f22, double *f23, double *f24, double *f25, double *f26);
int fD3Q27CCEZouHe(double *p, double v0, double v1, double v2, double *f0, double *f1,
                   double *f2, double *f3, double *f4, double *f5, double *f6,
                   double *f7, double *f8, double *f9, double *f10, double *f11,
                   double *f12, double *f13, double *f14, double *f15, double *f16,
                   double *f17, double *f18, double *f19, double *f20, double *f21,
                   double *f22, double *f23, double *f24, double *f25, double *f26);
int fD3Q27CCCZouHe(double *p, double v0, double v1, double v2, double *f0, double *f1,
                   double *f2, double *f3, double *f4, double *f5, double *f6,
                   double *f7, double *f8, double *f9, double *f10, double *f11,
                   double *f12, double *f13, double *f14, double *f15, double *f16,
                   double *f17, double *f18, double *f19, double *f20, double *f21,
                   double *f22, double *f23, double *f24, double *f25, double *f26);
int fD3Q27PCZouHe(long tpos, int prop, double *p0, double *uwall);
int fD3Q27TPSZouHe(double p, double v0, double v1, double v2, double *f0, double *f1,
                   double *f2, double *f3, double *f4, double *f5, double *f6,
                   double *f7, double *f8, double *f9, double *f10, double *f11,
                   double *f12, double *f13, double *f14, double *f15, double *f16,
                   double *f17, double *f18, double *f19, double *f20, double *f21,
                   double *f22, double *f23, double *f24, double *f25, double *f26);
int fD3Q27TCEZouHe(double p, double v0, double v1, double v2, double *f0, double *f1,
                   double *f2, double *f3, double *f4, double *f5, double *f6,
                   double *f7, double *f8, double *f9, double *f10, double *f11,
                   double *f12, double *f13, double *f14, double *f15, double *f16,
                   double *f17, double *f18, double *f19, double *f20, double *f21,
                   double *f22, double *f23, double *f24, double *f25, double *f26);
int fD3Q27TCCZouHe(double p, double v0, double v1, double v2, double *f0, double *f1,
                   double *f2, double *f3, double *f4, double *f5, double *f6,
                   double *f7, double *f8, double *f9, double *f10, double *f11,
                   double *f12, double *f13, double *f14, double *f15, double *f16,
                   double *f17, double *f18, double *f19, double *f20, double *f21,
                   double *f22, double *f23, double *f24, double *f25, double *f26);
int fD3Q27PTZouHe(long tpos, int prop, double p0, double *uwall);

