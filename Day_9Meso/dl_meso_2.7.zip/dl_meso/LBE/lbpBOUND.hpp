long fNextStep(int q, int xpos, int ypos, int zpos);
long fNextStep(int q, int xpos, int ypos);
long fNextStep(int dx, int dy, int dz, long tpos);
int fBounceBackF(long tpos);
int fBounceBackC(long tpos);
int fBounceBackT(long tpos);
int fMidBounceBackF(long tpos);
int fMidBounceBackC(long tpos);
int fMidBounceBackT(long tpos);
int fSiteBlankF(long tpos);
int fSiteBlankC(long tpos);
int fSiteBlankT(long tpos);

int fD2CCFracSite(double *frac, long tpos);
double fD2CCSwiftPhi(long tpos, double dx, double dy, double dpdx, double dpdy);
int fD3CECCFracSite(double *frac, long tpos);
double fD3CECCSwiftPhi(long tpos, double dx, double dy, double dz, double dpdx, double dpdy, double dpdz);

int fD2Q9CEFracSite(double *frac, double vy, double *f0, double *f1, double *f2, double *f3, double *f4, double *f5, double *f6, double *f7, double *f8);
double fD2Q9CESwiftPhi(double vy, double g0, double g1, double g2, double g3, double g4, double g5, double g6, double g7, double g8);
int fD2Q9BoundaryForceVelocity(double *force, long tpos, long tpos1, double dx, double dy, double *uwall, int prop);
int fD2Q9BoundaryForceDensity(double *force, long tpos, double *p0, int prop);
int fD2Q9OF1(long tpos, int prop);
int fD2Q9OF2(long tpos, int prop);

int fD3Q15PSFracSite(double *frac, double vy, double *f0, double *f1, double *f2, double *f3, double *f4, double *f5, double *f6, double *f7, double *f8, double *f9, double *f10, double *f11, double *f12, double *f13, double *f14);
double fD3Q15PSSwiftPhi(double vy, double g0, double g1, double g2, double g3, double g4, double g5, double g6, double g7, double g8, double g9, double g10, double g11, double g12, double g13, double g14);
int fD3Q15BoundaryForceVelocity(double *force, long tpos, long tpos1, double dx, double dy, double dz, double *uwall, int prop);
int fD3Q15BoundaryForceDensity(double *force, long tpos, double *p0, int prop);
int fD3Q15OF1(long tpos, int prop);
int fD3Q15OF2(long tpos, int prop);

int fD3Q19PSFracSite(double *frac, double vy, double *f0, double *f1, double *f2, double *f3, double *f4, double *f5, double *f6, double *f7, double *f8, double *f9, double *f10, double *f11, double *f12, double *f13, double *f14, double *f15, double *f16, double *f17, double *f18);
double fD3Q19PSSwiftPhi(double vy, double g0, double g1, double g2, double g3, double g4, double g5, double g6, double g7, double g8, double g9, double g10, double g11, double g12, double g13, double g14, double g15, double g16, double g17, double g18);
int fD3Q19BoundaryForceVelocity(double *force, long tpos, long tpos1, double dx, double dy, double dz, double *uwall, int prop);
int fD3Q19BoundaryForceDensity(double *force, long tpos, double *p0, int prop);
int fD3Q19OF1(long tpos, int prop);
int fD3Q19OF2(long tpos, int prop);

int fD3Q27PSFracSite(double *frac, double vy, double *f0, double *f1, double *f2, double *f3, double *f4, double *f5, double *f6, double *f7, double *f8, double *f9, double *f10, double *f11, double *f12, double *f13, double *f14, double *f15, double *f16, double *f17, double *f18, double *f19, double *f20, double *f21, double *f22, double *f23, double *f24, double *f25, double *f26);
int fD3Q27BoundaryForceVelocity(double *force, long tpos, long tpos1, double *uwall, int prop);
int fD3Q27BoundaryForceDensity(double *force, long tpos, double *p0, int prop);
int fD3Q27OF1(long tpos, int prop);
int fD3Q27OF2(long tpos, int prop);

int fFixedSpeedFluid(int tpos, int prop, int type, double *uwall);
int fFixedDensityFluid(int tpos, int prop, int type, double *uwall);
int fFixedSoluteConcen(int tpos, int prop, double *uwall);
int fFixedTemperature(int tpos, int prop, double *uwall);
int fOutFlow(long tpos, int prop);

int fPostCollBoundary();
int fPostPropBoundary();
int fNeighbourBoundary();
int fsPeriodic();
int fsBoundPeriodic();
int fsForcePeriodic();
int fsIndexPeriodic();
int fsPeriodic2D();
int fsPeriodic3D();
int fsBoundPeriodic2D();
int fsBoundPeriodic3D();
int fsForcePeriodic2D();
int fsForcePeriodic3D();
int fsIndexPeriodic2D();
int fsIndexPeriodic3D();

