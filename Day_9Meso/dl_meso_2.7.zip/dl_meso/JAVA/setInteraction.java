import javax.swing.*;
import java.util.*;
import java.lang.*;
import java.io.*;
import java.awt.*;
import java.awt.event.*;
import java.awt.geom.*;
import java.awt.image.*;
/*
 *     DL_MESO_GUI
 *     author: R. S. Qin, M. A. Seaton
 *     copyright: UKRI STFC Daresbury Laboratory and CCP5
 *     2005, 2018
 */
class setInteraction extends JFrame {

    setdpdInteractEvt interactdpd=new setdpdInteractEvt(this);
    Font font=new Font("Dialog", Font.BOLD, 13);

    JLabel specilabel = new JLabel("species i:", JLabel.RIGHT);
    JLabel specjlabel = new JLabel("species j:", JLabel.RIGHT);
    JLabel interactlabel = new JLabel("interaction type:", JLabel.RIGHT);
    JLabel specsrflabel = new JLabel("species:", JLabel.RIGHT);
    JLabel srfinteractlabel = new JLabel("surface interaction type:", JLabel.RIGHT);
    JLabel wallspeclabel = new JLabel("wall species:", JLabel.RIGHT);

    JLabel alabel = new JLabel("Aij:", JLabel.RIGHT);
    JLabel blabel = new JLabel("Bij:", JLabel.RIGHT);
    JLabel clabel = new JLabel("Cij:", JLabel.RIGHT);
    JLabel dlabel = new JLabel("Dij:", JLabel.RIGHT);
    JLabel elabel = new JLabel("Eij:", JLabel.RIGHT);
    JLabel distlabel = new JLabel("interaction length:", JLabel.RIGHT);
    JLabel gammalabel = new JLabel("dissipative/collision parameter:", JLabel.RIGHT);
    JLabel srfalabel = new JLabel("wall repulsion parameter:", JLabel.RIGHT);
    JLabel srfdistlabel = new JLabel("wall interaction length:", JLabel.RIGHT);
    JLabel walldenslabel = new JLabel("wall density:", JLabel.RIGHT);
    JLabel wallthicklabel = new JLabel("wall thickness:", JLabel.RIGHT);

    JComboBox<String> speci = new JComboBox<String>();
    JComboBox<String> specj = new JComboBox<String>();
    JComboBox<String> specsrf = new JComboBox<String>();
    JComboBox<String> inter = new JComboBox<String>();
    JComboBox<String> intersrf = new JComboBox<String>();
    JComboBox<String> wallspec = new JComboBox<String>();
    JTextField aa = new JTextField("25.0", 6);
    JTextField bb = new JTextField("0.0", 6);
    JTextField cc = new JTextField("0.0", 6);
    JTextField dd = new JTextField("0.0", 6);
    JTextField ee = new JTextField("0.0", 6);
    JTextField dist = new JTextField("1.0", 6);
    JTextField gamma = new JTextField("4.5", 6);
    JTextField srfaa = new JTextField("25.0", 6);
    JTextField srfdist = new JTextField("1.0", 6);
    JTextField walldens = new JTextField("3.0", 6);
    JTextField wallthick = new JTextField("1.0", 6);

    JButton set = new JButton("SET I");
    JButton close = new JButton("CLOSE I");
    
    public setInteraction(int totsp, String[] name, int ktype, double aaparam, double bbparam, double ccparam, double ddparam, double eeparam, double gammaparam, double distparam, int srftyp, int srfktype, double srfaaparam, double srfdistparam, boolean wall, int wallspe, double wallrho, double wallthic) {
	super("DPD interaction properties");
	setBounds(170, 120, 410, 480);
	JPanel pane=new JPanel(new GridBagLayout());

        specilabel.setFont(font);
        specjlabel.setFont(font);
        interactlabel.setFont(font);
        alabel.setFont(font);
        blabel.setFont(font);
        clabel.setFont(font);
        dlabel.setFont(font);
        elabel.setFont(font);
        distlabel.setFont(font);
        gammalabel.setFont(font);
        addItem(pane, specilabel, 0, 0, 1, 1, GridBagConstraints.EAST);
        addItem(pane, specjlabel, 0, 1, 1, 1, GridBagConstraints.EAST);
        addItem(pane, interactlabel, 0, 2, 1, 1, GridBagConstraints.EAST);
        addItem(pane, alabel, 2, 0, 1, 1, GridBagConstraints.EAST);
        addItem(pane, blabel, 2, 1, 1, 1, GridBagConstraints.EAST);
        addItem(pane, clabel, 2, 2, 1, 1, GridBagConstraints.EAST);
        addItem(pane, dlabel, 2, 3, 1, 1, GridBagConstraints.EAST);
        addItem(pane, elabel, 2, 4, 1, 1, GridBagConstraints.EAST);
        addItem(pane, distlabel, 0, 5, 3, 1, GridBagConstraints.EAST);
        addItem(pane, gammalabel, 0, 6, 3, 1, GridBagConstraints.EAST);
        addItem(pane, aa, 3, 0, 1, 1, GridBagConstraints.WEST);
        addItem(pane, bb, 3, 1, 1, 1, GridBagConstraints.WEST);
        addItem(pane, cc, 3, 2, 1, 1, GridBagConstraints.WEST);
        addItem(pane, dd, 3, 3, 1, 1, GridBagConstraints.WEST);
        addItem(pane, ee, 3, 4, 1, 1, GridBagConstraints.WEST);
        addItem(pane, dist, 3, 5, 1, 1, GridBagConstraints.WEST);
        addItem(pane, gamma, 3, 6, 1, 1, GridBagConstraints.WEST);
        if(srftyp>1) {
            JSeparator sep1 = new JSeparator(JSeparator.HORIZONTAL);
            addItemFillSep(pane, sep1, 7, GridBagConstraints.HORIZONTAL);
            specsrflabel.setFont(font);
            srfinteractlabel.setFont(font);
            srfalabel.setFont(font);
            srfdistlabel.setFont(font);
            addItem(pane, specsrflabel, 0, 8, 1, 1, GridBagConstraints.EAST);
            addItem(pane, srfinteractlabel, 0, 9, 1, 1, GridBagConstraints.EAST);
            addItem(pane, srfalabel, 2, 8, 1, 1, GridBagConstraints.EAST);
            addItem(pane, srfdistlabel, 2, 9, 1, 1, GridBagConstraints.EAST);
        }
        if(wall) {
          JSeparator sep2 = new JSeparator(JSeparator.HORIZONTAL);
          addItemFillSep(pane, sep2, 7+((srftyp>1)?3:0), GridBagConstraints.HORIZONTAL);
          wallspeclabel.setFont(font);
          walldenslabel.setFont(font);
          wallthicklabel.setFont(font);
          addItem(pane, wallspeclabel, 0, 8+((srftyp>1)?3:0), 1, 1, GridBagConstraints.EAST);
          addItem(pane, walldenslabel, 0, 9+((srftyp>1)?3:0), 3, 1, GridBagConstraints.EAST);
          addItem(pane, walldens, 3, 9+((srftyp>1)?3:0), 1, 1, GridBagConstraints.WEST);
          addItem(pane, wallthicklabel, 0, 10+((srftyp>1)?3:0), 3, 1, GridBagConstraints.EAST);
          addItem(pane, wallthick, 3, 10+((srftyp>1)?3:0), 1, 1, GridBagConstraints.WEST);
        }

        for(int i=0; i<totsp; i++) {
            speci.addItem(name[i]);
            specj.addItem(name[i]);
            specsrf.addItem(name[i]);
            wallspec.addItem(name[i]);
        }

        inter.addItem("DPD");
        inter.addItem("many-body DPD");
        inter.addItem("Lennard-Jones");
        inter.addItem("WCA");
        
        intersrf.addItem("DPD");
        intersrf.addItem("WCA");
        
        if(ktype==0)
            inter.setSelectedItem("Lennard-Jones");
        else if(ktype==1)
            inter.setSelectedItem("WCA");
        else if(ktype==2)
            inter.setSelectedItem("DPD");
        else if(ktype==3)
            inter.setSelectedItem("many-body DPD");
            
        if(srfktype==0)
            intersrf.setSelectedItem("DPD");
        else if(srfktype==1)
            intersrf.setSelectedItem("WCA");
        
        wallspec.setSelectedIndex(wallspe);

        addItem(pane, speci, 1, 0, 1, 1, GridBagConstraints.WEST);
        addItem(pane, specj, 1, 1, 1, 1, GridBagConstraints.WEST);
        addItem(pane, inter, 1, 2, 1, 1, GridBagConstraints.WEST);
        if(srftyp>1) {
            addItem(pane, specsrf, 1, 8, 1, 1, GridBagConstraints.WEST);
            addItem(pane, intersrf, 1, 9, 1, 1, GridBagConstraints.WEST);
            addItem(pane, srfaa, 3, 8, 1, 1, GridBagConstraints.WEST);
            addItem(pane, srfdist, 3, 9, 1, 1, GridBagConstraints.WEST);
        }
        if(wall) {
            addItem(pane, wallspec, 1, 8+((srftyp>1)?3:0), 1, 1, GridBagConstraints.WEST);
        }
        speci.addItemListener(interactdpd);
        specj.addItemListener(interactdpd);
        inter.addItemListener(interactdpd);
        specsrf.addItemListener(interactdpd);
        wallspec.addItemListener(interactdpd);

        aa.setText(Double.toString(aaparam));
        bb.setText(Double.toString(bbparam));
        cc.setText(Double.toString(ccparam));
        dd.setText(Double.toString(ddparam));
        ee.setText(Double.toString(eeparam));
        dist.setText(Double.toString(distparam));
        gamma.setText(Double.toString(gammaparam));
        
        srfaa.setText(Double.toString(srfaaparam));
        srfdist.setText(Double.toString(srfdistparam));

        walldens.setText(Double.toString(wallrho));
        wallthick.setText(Double.toString(wallthic));
        
        alabel.setEnabled(true);
        blabel.setEnabled(ktype==3);
        clabel.setEnabled(ktype==3);
        dlabel.setEnabled(ktype==3);
        elabel.setEnabled(ktype==3);
        aa.setEnabled(true);
        aa.setEditable(true);
        bb.setEnabled(ktype==3);
        bb.setEditable(ktype==3);
        cc.setEnabled(ktype==3);
        cc.setEditable(ktype==3);
        dd.setEnabled(ktype==3);
        dd.setEditable(ktype==3);
        ee.setEnabled(ktype==3);
        ee.setEditable(ktype==3);

        Box buttonBox = Box.createHorizontalBox();
        set.setFont(font);
        set.addActionListener(interactdpd);
        buttonBox.add(set);
        close.setFont(font);
        close.addActionListener(interactdpd);
        buttonBox.add(close);
        addItem(pane, buttonBox, 0, 14, 3, 1, GridBagConstraints.WEST);

        this.add(pane);
        this.pack();
        setVisible(true);
    }

    private void addItem(JPanel p, JComponent c, int x, int y, int width, int height, int align)
    {
        GridBagConstraints gc = new GridBagConstraints();
        gc.gridx = x;
        gc.gridy = y;
        gc.gridwidth = width;
        gc.gridheight = height;
        gc.weightx = 100.0;
        gc.weighty = 100.0;
        gc.insets = new Insets(5, 5, 5, 5);
        gc.anchor = align;
        gc.fill = GridBagConstraints.NONE;
        p.add(c, gc);
    }

    private void addItemFillSep(JPanel p, JComponent c, int y, int fill)
    {
        GridBagConstraints gc = new GridBagConstraints();
        gc.gridx = 0;
        gc.gridy = y;
        gc.gridwidth = 5;
        gc.gridheight = 1;
        gc.weightx = 1;
        gc.weighty = 1;
        gc.insets = new Insets(5, 5, 5, 5);
        gc.anchor = GridBagConstraints.CENTER;
        gc.fill = fill;
        p.add(c, gc);
    }

    private void addItemFill(JPanel p, JComponent c, int x, int y, int width, int height, int align, int fill)
    {
        GridBagConstraints gc = new GridBagConstraints();
        gc.gridx = x;
        gc.gridy = y;
        gc.gridwidth = width;
        gc.gridheight = height;
        gc.weightx = 100.0;
        gc.weighty = 100.0;
        gc.insets = new Insets(5, 5, 5, 5);
        gc.anchor = align;
        gc.fill = fill;
        p.add(c, gc);
    }

}
