int fGetCentralMomentEquilibriumF(double *meq, double rho);
int fGetCentralMomentTransformMatrix(double *rcsh, double *rcshinv, double *u);
int fGetCentralMomentForceGuo(double *source, double *v, double *force);
int fGetCentralMomentForceHe(double *source, double *force);
int fGetCLBECollide(double *collide, double omegashear, double omegabulk, double omegathree, double omegafour);

int fSiteFluidCollisionCLBE(double* startpos, double *sitespeed, double *omega, double *omegabulk, double *omega3, double *omega4, double *rho, double* bodyforce);
int fSiteFluidCollisionCLBEEDM(double* startpos, double *sitespeed, double *omega, double *omegabulk, double *omega3, double *omega4, double *rho, double* bodyforce);
int fSiteFluidCollisionCLBEGuo(double* startpos, double *sitespeed, double *omega, double *omegabulk, double *omega3, double *omega4, double *rho, double* bodyforce);
int fSiteFluidCollisionCLBEHe(double* startpos, double *sitespeed, double *omega, double *omegabulk, double *omega3, double *omega4, double *rho, double* bodyforce);

int fSiteFluidCollisionCLBELishchuk(double* startpos, double *sitespeed, double *omega, double *omegabulk, double *omega3, double *omega4, double *rho, double* bodyforce, double* phaseindex);
int fSiteFluidCollisionCLBEEDMLishchuk(double* startpos, double *sitespeed, double *omega, double *omegabulk, double *omega3, double *omega4, double *rho, double* bodyforce, double* phaseindex);
int fSiteFluidCollisionCLBEGuoLishchuk(double* startpos, double *sitespeed, double *omega, double *omegabulk, double *omega3, double *omega4, double *rho, double* bodyforce, double* phaseindex);
int fSiteFluidCollisionCLBEHeLishchuk(double* startpos, double *sitespeed, double *omega, double *omegabulk, double *omega3, double *omega4, double *rho, double* bodyforce, double* phaseindex);

int fSiteFluidCollisionCLBELishchukLocal(double* startpos, double *sitespeed, double *omega, double *omegabulk, double *omega3, double *omega4, double *rho, double* bodyforce, double* phaseindex, int threed);
int fSiteFluidCollisionCLBEEDMLishchukLocal(double* startpos, double *sitespeed, double *omega, double *omegabulk, double *omega3, double *omega4, double *rho, double* bodyforce, double* phaseindex, int threed);
int fSiteFluidCollisionCLBEGuoLishchukLocal(double* startpos, double *sitespeed, double *omega, double *omegabulk, double *omega3, double *omega4, double *rho, double* bodyforce, double* phaseindex, int threed);
int fSiteFluidCollisionCLBEHeLishchukLocal(double* startpos, double *sitespeed, double *omega, double *omegabulk, double *omega3, double *omega4, double *rho, double* bodyforce, double* phaseindex, int threed);

int fCollisionCLBE();
int fCollisionCLBEEDM();
int fCollisionCLBEGuo();
int fCollisionCLBEHe();
int fCollisionCLBEShanChen();
int fCollisionCLBEEDMShanChen();
int fCollisionCLBEGuoShanChen();
int fCollisionCLBEHeShanChen();
int fCollisionCLBELishchuk();
int fCollisionCLBEEDMLishchuk();
int fCollisionCLBEGuoLishchuk();
int fCollisionCLBEHeLishchuk();
int fCollisionCLBELishchukLocal();
int fCollisionCLBEEDMLishchukLocal();
int fCollisionCLBEGuoLishchukLocal();
int fCollisionCLBEHeLishchukLocal();

