/***************************************************
 *   DL_MESO       Version 2.7                     *
 *   Authors   :   R. S. Qin, M. A. Seaton         *
 *   Copyright :   UKRI STFC Daresbury Laboratory  *
 *             :   09/12/2018                      *
 ***************************************************/

int fOutputQ(const char* filename="lbout")
{
  char namebuf[80];
  for(int iprop=0; iprop<lbsy.nf; iprop++) {
    sprintf(namebuf, "%s%.2ddens", filename, iprop);
    fOutputQP(namebuf, iprop);
    sprintf(namebuf, "%s%.2dfrac", filename, iprop);
    fOutputQCA(namebuf, iprop);
  }
  for(int iprop=0; iprop<lbsy.nc; iprop++) {
    sprintf(namebuf, "%s%.2dconc", filename, iprop);
    fOutputQCB(namebuf, iprop);
  }
  if(lbsy.nt==1) {
    sprintf(namebuf, "%stemp", filename);
    fOutputQT(namebuf);
  }
  return 0;
}

int fsOutputQ(const char* filename="lbout")
{
  char namebuf[80];
  for(int iprop=0; iprop<lbsy.nf; iprop++) {
    sprintf(namebuf, "%s%.2ddens", filename, iprop);
    fsOutputQP(namebuf, iprop);
    sprintf(namebuf, "%s%.2dfrac", filename, iprop);
    fsOutputQCA(namebuf, iprop);
  }
  for(int iprop=0; iprop<lbsy.nc; iprop++) {
    sprintf(namebuf, "%s%.2dconc", filename, iprop);
    fsOutputQCB(namebuf, iprop);
  }
  if(lbsy.nt==1) {
    sprintf(namebuf, "%stemp", filename);
    fsOutputQT(namebuf);
  }
  return 0;
}

int fOutputGrid(const char* filename="lbout")
{
  char buf[80];
  int numberOfPoints;
  int start[3], end[3], length[3];
  float* scalarBuffer;
  ofstream file;
  string header="",footer="";
  unsigned long headersize=0,footersize=0,startpos;
    
  // find extent and number of points for I/O group
  fGroupPieceRangeLocal(start,end);
  if(!lbmpiio) {
    length[0] = end[0]-start[0];
    length[1] = end[1]-start[1];
    length[2] = end[2]-start[2];
  }
  else {
    length[0] = lbsy.nx;
    length[1] = lbsy.ny;
    length[2] = lbsy.nz;
  }
  numberOfPoints = fGroupPieceDataPoints(length);
    
  // open file if root process for I/O group
  if(lbIOGroup.rank==0) {
    if(lbsy.nd==3) {
      if(!lbmpiio && lbdm.size>lbIOGroup.size)
        sprintf(buf, "%s%.6d.xyz", filename, lbIOGroup.groupId);
      else
        sprintf(buf, "%s.xyz", filename);
    }
    else {
      if(!lbmpiio && lbdm.size>lbIOGroup.size)
        sprintf(buf, "%s%.6d.xy", filename, lbIOGroup.groupId);
      else
        sprintf(buf, "%s.xy", filename);
    }
  }
  fOpenOutputBinaryFile(buf, file);
    
  // write dimensions of grid for I/O group
  startpos = 0;
  fWritePlot3DGridIntegerBinaryData(length, lbsy.nd, startpos, file);
    
  // allocate buffer for collecting data
    
  scalarBuffer = (float*)malloc(numberOfPoints*sizeof(float));
    
  // collect and write grid points

  fGroupGridPointComponent(scalarBuffer, start, end, 0, false);
  fWriteLegacyVTKFloatBinaryData(scalarBuffer, numberOfPoints, startpos, header.c_str(), footer.c_str(), headersize, footersize, file);
    
  fGroupGridPointComponent(scalarBuffer, start, end, 1, false);
  fWriteLegacyVTKFloatBinaryData(scalarBuffer, numberOfPoints, startpos, header.c_str(), footer.c_str(), headersize, footersize, file);

  if(lbsy.nd==3) {
    fGroupGridPointComponent(scalarBuffer, start, end, 2, false);
    fWriteLegacyVTKFloatBinaryData(scalarBuffer, numberOfPoints, startpos, header.c_str(), footer.c_str(), headersize, footersize, file);
  }
    
  // close file and deallocate buffer
    
  fCloseOutputBinaryFile(file);
    
  free(scalarBuffer);
    
  return 0;
}


int fsOutputGrid(const char* filename="lbout")
{
  char buf[80];
  int numberOfPoints;
  int start[3], end[3], length[3];
  float* scalarBuffer;
  ofstream file;
  string header="",footer="";
  unsigned long headersize=0,footersize=0,startpos;
    
  // find extent and number of points for I/O group
  fGroupPieceRangeLocal(start,end);
  if(!lbmpiio) {
    length[0] = end[0]-start[0];
    length[1] = end[1]-start[1];
    length[2] = end[2]-start[2];
  }
  else {
    length[0] = lbsy.nx;
    length[1] = lbsy.ny;
    length[2] = lbsy.nz;
  }
  numberOfPoints = fGroupPieceDataPoints(length);
    
  // open file if root process for I/O group
  if(lbIOGroup.rank==0) {
    if(lbsy.nd==3) {
      if(!lbmpiio && lbdm.size>lbIOGroup.size)
        sprintf(buf, "%s%.6d.xyz", filename, lbIOGroup.groupId);
      else
        sprintf(buf, "%s.xyz", filename);
    }
    else {
      if(!lbmpiio && lbdm.size>lbIOGroup.size)
        sprintf(buf, "%s%.6d.xy", filename, lbIOGroup.groupId);
      else
        sprintf(buf, "%s.xy", filename);
    }
  }
  fOpenOutputANSIFile(buf, file);
    
  // write dimensions of grid for I/O group
  startpos = 0;
  fWritePlot3DGridIntegerANSIData(length, lbsy.nd, startpos, file);
    
  // allocate buffer for collecting data
    
  scalarBuffer = (float*)malloc(numberOfPoints*sizeof(float));
    
  // collect and write grid points

  fGroupGridPointComponent(scalarBuffer, start, end, 0, false);
  fWriteVTKFloatANSIData(scalarBuffer, numberOfPoints, startpos, header.c_str(), footer.c_str(), headersize, footersize, file);
    
  fGroupGridPointComponent(scalarBuffer, start, end, 1, false);
  fWriteVTKFloatANSIData(scalarBuffer, numberOfPoints, startpos, header.c_str(), footer.c_str(), headersize, footersize, file);

  if(lbsy.nd==3) {
    fGroupGridPointComponent(scalarBuffer, start, end, 2, false);
    fWriteVTKFloatANSIData(scalarBuffer, numberOfPoints, startpos, header.c_str(), footer.c_str(), headersize, footersize, file);
  }
    
  // close file and deallocate buffer
    
  fCloseOutputANSIFile(file);
    
  free(scalarBuffer);
    
  return 0;
}


int fOutputQP(const char* filename="lbout", int iprop=0)
{
  
  // output .q file with macroscopic mass density and velocity for fluid iprop

  char buf[80];
  float scale[4];
  int numberOfPoints;
  int start[3], end[3], length[3];
  float* scalarBuffer;
  ofstream file;
  string header="",footer="";
  unsigned long headersize=0,footersize=0,startpos;

  // find extent and number of points for I/O group
  fGroupPieceRangeLocal(start,end);
  if(!lbmpiio) {
    length[0] = end[0]-start[0];
    length[1] = end[1]-start[1];
    length[2] = end[2]-start[2];
  }
  else {
    length[0] = lbsy.nx;
    length[1] = lbsy.ny;
    length[2] = lbsy.nz;
  }
  numberOfPoints = fGroupPieceDataPoints(length);

  // open file if root process for I/O group
  if(lbIOGroup.rank==0) {
    if(!lbmpiio && lbdm.size>lbIOGroup.size)
      sprintf(buf, "%s%.6dat%.6d.q", filename, lbIOGroup.groupId, qVersion);
    else
      sprintf(buf, "%s%.6d.q", filename, qVersion);
  }
  fOpenOutputBinaryFile(buf, file);

  // write dimensions of grid for I/O group
  startpos = 0;
  fWritePlot3DGridIntegerBinaryData(length, lbsy.nd, startpos, file);

  // write velocity scale (speed of sound), freestream
  // angle-of-attack, Reynolds number and time (in time steps)
  scale[0] = float(lbsoundv);
  scale[1] = 1.0;
  scale[2] = lbreynolds;
  scale[3] = float(qVersion*lbsave);
  fWritePlot3DGridFloatBinaryData(scale, 4, startpos, file);

  // allocate buffer for collecting data
    
  scalarBuffer = (float*)malloc(numberOfPoints*sizeof(float));

  // collect and write density
    
  fGroupDensities(scalarBuffer, start, end, iprop, false);
  fWriteLegacyVTKFloatBinaryData(scalarBuffer, numberOfPoints, startpos, header.c_str(), footer.c_str(), headersize, footersize, file);

  // collect and write x-component of velocity
    
  fGroupVelocityComponent(scalarBuffer, start, end, 0, false);
  fWriteLegacyVTKFloatBinaryData(scalarBuffer, numberOfPoints, startpos, header.c_str(), footer.c_str(), headersize, footersize, file);

  // collect and write y-component of velocity
    
  fGroupVelocityComponent(scalarBuffer, start, end, 1, false);
  fWriteLegacyVTKFloatBinaryData(scalarBuffer, numberOfPoints, startpos, header.c_str(), footer.c_str(), headersize, footersize, file);

  // collect and write z-component of velocity (if needed)
    
  if(lbsy.nd==3) {
    fGroupVelocityComponent(scalarBuffer, start, end, 2, false);
    fWriteLegacyVTKFloatBinaryData(scalarBuffer, numberOfPoints, startpos, header.c_str(), footer.c_str(), headersize, footersize, file);
  }
    
  // collect and write phase field/space property
    
  fGroupPhaseFieldFloat(scalarBuffer, start, end, false);
  fWriteLegacyVTKFloatBinaryData(scalarBuffer, numberOfPoints, startpos, header.c_str(), footer.c_str(), headersize, footersize, file);

  // close file and deallocate buffer
    
  fCloseOutputBinaryFile(file);

  free(scalarBuffer);
    
  return 0;
}

int fsOutputQP(const char* filename="lbout", int iprop=0)
{
  char buf[80];
  float scale[4];
  int numberOfPoints;
  int start[3], end[3], length[3];
  float* scalarBuffer;
  ofstream file;
  string header="",footer="";
  unsigned long headersize=0,footersize=0,startpos;

  // find extent and number of points for I/O group
  fGroupPieceRangeLocal(start,end);
  if(!lbmpiio) {
    length[0] = end[0]-start[0];
    length[1] = end[1]-start[1];
    length[2] = end[2]-start[2];
  }
  else {
    length[0] = lbsy.nx;
    length[1] = lbsy.ny;
    length[2] = lbsy.nz;
  }
  numberOfPoints = fGroupPieceDataPoints(length);

  // open file if root process for I/O group
  if(lbIOGroup.rank==0) {
    if(!lbmpiio && lbdm.size>lbIOGroup.size)
      sprintf(buf, "%s%.6dat%.6d.q", filename, lbIOGroup.groupId, qVersion);
    else
      sprintf(buf, "%s%.6d.q", filename, qVersion);
  }
  fOpenOutputANSIFile(buf, file);

  // write dimensions of grid for I/O group
  startpos = 0;
  fWritePlot3DGridIntegerANSIData(length, lbsy.nd, startpos, file);

  // write velocity scale (speed of sound), freestream
  // angle-of-attack, Reynolds number and time (in time steps)
  scale[0] = float(lbsoundv);
  scale[1] = 1.0;
  scale[2] = lbreynolds;
  scale[3] = float(qVersion*lbsave);
  fWritePlot3DGridFloatANSIData(scale, 4, startpos, file);

  // allocate buffer for collecting data

  scalarBuffer = (float*)malloc(numberOfPoints*sizeof(float));

  // collect and write density

  fGroupDensities(scalarBuffer, start, end, iprop, false);
  fWriteVTKFloatANSIData(scalarBuffer, numberOfPoints, startpos, header.c_str(), footer.c_str(), headersize, footersize, file);

  // collect and write x-component of velocity

  fGroupVelocityComponent(scalarBuffer, start, end, 0, false);
  fWriteVTKFloatANSIData(scalarBuffer, numberOfPoints, startpos, header.c_str(), footer.c_str(), headersize, footersize, file);

  // collect and write y-component of velocity

  fGroupVelocityComponent(scalarBuffer, start, end, 1, false);
  fWriteVTKFloatANSIData(scalarBuffer, numberOfPoints, startpos, header.c_str(), footer.c_str(), headersize, footersize, file);

  // collect and write z-component of velocity (if needed)

  if(lbsy.nd==3) {
    fGroupVelocityComponent(scalarBuffer, start, end, 2, false);
    fWriteVTKFloatANSIData(scalarBuffer, numberOfPoints, startpos, header.c_str(), footer.c_str(), headersize, footersize, file);
  }

  // collect and write phase field/space property

  fGroupPhaseFieldFloat(scalarBuffer, start, end, false);
  fWriteVTKFloatANSIData(scalarBuffer, numberOfPoints, startpos, header.c_str(), footer.c_str(), headersize, footersize, file);

  // close file and deallocate buffer

  fCloseOutputANSIFile(file);

  free(scalarBuffer);

  return 0;
}


int fOutputQCA(const char* filename="lbout", int iprop=0)
{

  // output .q file with mass fraction and velocity for fluid iprop

  char buf[80];
  float scale[4];
  int numberOfPoints;
  int start[3], end[3], length[3];
  float* scalarBuffer;
  ofstream file;
  string header="",footer="";
  unsigned long headersize=0,footersize=0,startpos;

  // find extent and number of points for I/O group
  fGroupPieceRangeLocal(start,end);
  if(!lbmpiio) {
    length[0] = end[0]-start[0];
    length[1] = end[1]-start[1];
    length[2] = end[2]-start[2];
  }
  else {
    length[0] = lbsy.nx;
    length[1] = lbsy.ny;
    length[2] = lbsy.nz;
  }
  numberOfPoints = fGroupPieceDataPoints(length);

  // open file if root process for I/O group
  if(lbIOGroup.rank==0) {
    if(!lbmpiio && lbdm.size>lbIOGroup.size)
      sprintf(buf, "%s%.6dat%.6d.q", filename, lbIOGroup.groupId, qVersion);
    else
      sprintf(buf, "%s%.6d.q", filename, qVersion);
  }
  fOpenOutputBinaryFile(buf, file);

  // write dimensions of grid for I/O group
  startpos = 0;
  fWritePlot3DGridIntegerBinaryData(length, lbsy.nd, startpos, file);

  // write velocity scale (speed of sound), freestream
  // angle-of-attack, Reynolds number and time (in time steps)
  scale[0] = float(lbsoundv);
  scale[1] = 1.0;
  scale[2] = lbreynolds;
  scale[3] = float(qVersion*lbsave);
  fWritePlot3DGridFloatBinaryData(scale, 4, startpos, file);

  // allocate buffer for collecting data

  scalarBuffer = (float*)malloc(numberOfPoints*sizeof(float));

  // collect and write mass fraction

  fGroupMassFractions(scalarBuffer, start, end, iprop, false);
  fWriteLegacyVTKFloatBinaryData(scalarBuffer, numberOfPoints, startpos, header.c_str(), footer.c_str(), headersize, footersize, file);

  // collect and write x-component of velocity

  fGroupVelocityComponent(scalarBuffer, start, end, 0, false);
  fWriteLegacyVTKFloatBinaryData(scalarBuffer, numberOfPoints, startpos, header.c_str(), footer.c_str(), headersize, footersize, file);

  // collect and write y-component of velocity

  fGroupVelocityComponent(scalarBuffer, start, end, 1, false);
  fWriteLegacyVTKFloatBinaryData(scalarBuffer, numberOfPoints, startpos, header.c_str(), footer.c_str(), headersize, footersize, file);

  // collect and write z-component of velocity (if needed)

  if(lbsy.nd==3) {
    fGroupVelocityComponent(scalarBuffer, start, end, 2, false);
    fWriteLegacyVTKFloatBinaryData(scalarBuffer, numberOfPoints, startpos, header.c_str(), footer.c_str(), headersize, footersize, file);
  }

  // collect and write phase field/space property

  fGroupPhaseFieldFloat(scalarBuffer, start, end, false);
  fWriteLegacyVTKFloatBinaryData(scalarBuffer, numberOfPoints, startpos, header.c_str(), footer.c_str(), headersize, footersize, file);

  // close file and deallocate buffer

  fCloseOutputBinaryFile(file);

  free(scalarBuffer);

  return 0;
}


int fsOutputQCA(const char* filename="lbout", int iprop=0)
{
  char buf[80];
  float scale[4];
  int numberOfPoints;
  int start[3], end[3], length[3];
  float* scalarBuffer;
  ofstream file;
  string header="",footer="";
  unsigned long headersize=0,footersize=0,startpos;

  // find extent and number of points for I/O group
  fGroupPieceRangeLocal(start,end);
  if(!lbmpiio) {
    length[0] = end[0]-start[0];
    length[1] = end[1]-start[1];
    length[2] = end[2]-start[2];
  }
  else {
    length[0] = lbsy.nx;
    length[1] = lbsy.ny;
    length[2] = lbsy.nz;
  }
  numberOfPoints = fGroupPieceDataPoints(length);

  // open file if root process for I/O group
  if(lbIOGroup.rank==0) {
    if(!lbmpiio && lbdm.size>lbIOGroup.size)
      sprintf(buf, "%s%.6dat%.6d.q", filename, lbIOGroup.groupId, qVersion);
    else
      sprintf(buf, "%s%.6d.q", filename, qVersion);
  }
  fOpenOutputANSIFile(buf, file);

  // write dimensions of grid for I/O group
  startpos = 0;
  fWritePlot3DGridIntegerANSIData(length, lbsy.nd, startpos, file);

  // write velocity scale (speed of sound), freestream
  // angle-of-attack, Reynolds number and time (in time steps)
  scale[0] = float(lbsoundv);
  scale[1] = 1.0;
  scale[2] = lbreynolds;
  scale[3] = float(qVersion*lbsave);
  fWritePlot3DGridFloatANSIData(scale, 4, startpos, file);

  // allocate buffer for collecting data

  scalarBuffer = (float*)malloc(numberOfPoints*sizeof(float));

  // collect and write mass fraction

  fGroupMassFractions(scalarBuffer, start, end, iprop, false);
  fWriteVTKFloatANSIData(scalarBuffer, numberOfPoints, startpos, header.c_str(), footer.c_str(), headersize, footersize, file);

  // collect and write x-component of velocity

  fGroupVelocityComponent(scalarBuffer, start, end, 0, false);
  fWriteVTKFloatANSIData(scalarBuffer, numberOfPoints, startpos, header.c_str(), footer.c_str(), headersize, footersize, file);

  // collect and write y-component of velocity

  fGroupVelocityComponent(scalarBuffer, start, end, 1, false);
  fWriteVTKFloatANSIData(scalarBuffer, numberOfPoints, startpos, header.c_str(), footer.c_str(), headersize, footersize, file);

  // collect and write z-component of velocity (if needed)

  if(lbsy.nd==3) {
    fGroupVelocityComponent(scalarBuffer, start, end, 2, false);
    fWriteVTKFloatANSIData(scalarBuffer, numberOfPoints, startpos, header.c_str(), footer.c_str(), headersize, footersize, file);
  }

  // collect and write phase field/space property

  fGroupPhaseFieldFloat(scalarBuffer, start, end, false);
  fWriteVTKFloatANSIData(scalarBuffer, numberOfPoints, startpos, header.c_str(), footer.c_str(), headersize, footersize, file);

  // close file and deallocate buffer

  fCloseOutputANSIFile(file);

  free(scalarBuffer);

  return 0;
}


int fOutputQCB(const char* filename="lbout", int iprop=0)
{

  // output .q file with concentration and velocity for solute iprop

  char buf[80];
  float scale[4];
  int numberOfPoints;
  int start[3], end[3], length[3];
  float* scalarBuffer;
  ofstream file;
  string header="",footer="";
  unsigned long headersize=0,footersize=0,startpos;

  // find extent and number of points for I/O group
  fGroupPieceRangeLocal(start,end);
  if(!lbmpiio) {
    length[0] = end[0]-start[0];
    length[1] = end[1]-start[1];
    length[2] = end[2]-start[2];
  }
  else {
    length[0] = lbsy.nx;
    length[1] = lbsy.ny;
    length[2] = lbsy.nz;
  }
  numberOfPoints = fGroupPieceDataPoints(length);

  // open file if root process for I/O group
  if(lbIOGroup.rank==0) {
    if(!lbmpiio && lbdm.size>lbIOGroup.size)
      sprintf(buf, "%s%.6dat%.6d.q", filename, lbIOGroup.groupId, qVersion);
    else
      sprintf(buf, "%s%.6d.q", filename, qVersion);
  }
  fOpenOutputBinaryFile(buf, file);

  // write dimensions of grid for I/O group
  startpos = 0;
  fWritePlot3DGridIntegerBinaryData(length, lbsy.nd, startpos, file);

  // write velocity scale (speed of sound), freestream
  // angle-of-attack, Reynolds number and time (in time steps)
  scale[0] = float(lbsoundv);
  scale[1] = 1.0;
  scale[2] = lbreynolds;
  scale[3] = float(qVersion*lbsave);
  fWritePlot3DGridFloatBinaryData(scale, 4, startpos, file);

  // allocate buffer for collecting data

  scalarBuffer = (float*)malloc(numberOfPoints*sizeof(float));

  // collect and write solute concentration

  fGroupSoluteConcentrations(scalarBuffer, start, end, iprop, false);
  fWriteLegacyVTKFloatBinaryData(scalarBuffer, numberOfPoints, startpos, header.c_str(), footer.c_str(), headersize, footersize, file);

  // collect and write x-component of velocity

  fGroupVelocityComponent(scalarBuffer, start, end, 0, false);
  fWriteLegacyVTKFloatBinaryData(scalarBuffer, numberOfPoints, startpos, header.c_str(), footer.c_str(), headersize, footersize, file);

  // collect and write y-component of velocity

  fGroupVelocityComponent(scalarBuffer, start, end, 1, false);
  fWriteLegacyVTKFloatBinaryData(scalarBuffer, numberOfPoints, startpos, header.c_str(), footer.c_str(), headersize, footersize, file);

  // collect and write z-component of velocity (if needed)

  if(lbsy.nd==3) {
    fGroupVelocityComponent(scalarBuffer, start, end, 2, false);
    fWriteLegacyVTKFloatBinaryData(scalarBuffer, numberOfPoints, startpos, header.c_str(), footer.c_str(), headersize, footersize, file);
  }

  // collect and write phase field/space property

  fGroupPhaseFieldFloat(scalarBuffer, start, end, false);
  fWriteLegacyVTKFloatBinaryData(scalarBuffer, numberOfPoints, startpos, header.c_str(), footer.c_str(), headersize, footersize, file);

  // close file and deallocate buffer

  fCloseOutputBinaryFile(file);

  free(scalarBuffer);

  return 0;
}


int fsOutputQCB(const char* filename="lbout", int iprop=0)
{
  char buf[80];
  float scale[4];
  int numberOfPoints;
  int start[3], end[3], length[3];
  float* scalarBuffer;
  ofstream file;
  string header="",footer="";
  unsigned long headersize=0,footersize=0,startpos;

  // find extent and number of points for I/O group
  fGroupPieceRangeLocal(start,end);
  if(!lbmpiio) {
    length[0] = end[0]-start[0];
    length[1] = end[1]-start[1];
    length[2] = end[2]-start[2];
  }
  else {
    length[0] = lbsy.nx;
    length[1] = lbsy.ny;
    length[2] = lbsy.nz;
  }
  numberOfPoints = fGroupPieceDataPoints(length);

  // open file if root process for I/O group
  if(lbIOGroup.rank==0) {
    if(!lbmpiio && lbdm.size>lbIOGroup.size)
      sprintf(buf, "%s%.6dat%.6d.q", filename, lbIOGroup.groupId, qVersion);
    else
      sprintf(buf, "%s%.6d.q", filename, qVersion);
  }
  fOpenOutputANSIFile(buf, file);

  // write dimensions of grid for I/O group
  startpos = 0;
  fWritePlot3DGridIntegerANSIData(length, lbsy.nd, startpos, file);

  // write velocity scale (speed of sound), freestream
  // angle-of-attack, Reynolds number and time (in time steps)
  scale[0] = float(lbsoundv);
  scale[1] = 1.0;
  scale[2] = lbreynolds;
  scale[3] = float(qVersion*lbsave);
  fWritePlot3DGridFloatANSIData(scale, 4, startpos, file);

  // allocate buffer for collecting data

  scalarBuffer = (float*)malloc(numberOfPoints*sizeof(float));

  // collect and write solute concentration
    
  fGroupSoluteConcentrations(scalarBuffer, start, end, iprop, false);
  fWriteVTKFloatANSIData(scalarBuffer, numberOfPoints, startpos, header.c_str(), footer.c_str(), headersize, footersize, file);

  // collect and write x-component of velocity

  fGroupVelocityComponent(scalarBuffer, start, end, 0, false);
  fWriteVTKFloatANSIData(scalarBuffer, numberOfPoints, startpos, header.c_str(), footer.c_str(), headersize, footersize, file);

  // collect and write y-component of velocity

  fGroupVelocityComponent(scalarBuffer, start, end, 1, false);
  fWriteVTKFloatANSIData(scalarBuffer, numberOfPoints, startpos, header.c_str(), footer.c_str(), headersize, footersize, file);

  // collect and write z-component of velocity (if needed)

  if(lbsy.nd==3) {
    fGroupVelocityComponent(scalarBuffer, start, end, 2, false);
    fWriteVTKFloatANSIData(scalarBuffer, numberOfPoints, startpos, header.c_str(), footer.c_str(), headersize, footersize, file);
  }

  // collect and write phase field/space property

  fGroupPhaseFieldFloat(scalarBuffer, start, end, false);
  fWriteVTKFloatANSIData(scalarBuffer, numberOfPoints, startpos, header.c_str(), footer.c_str(), headersize, footersize, file);

  // close file and deallocate buffer

  fCloseOutputANSIFile(file);

  free(scalarBuffer);
    
  return 0;
}


int fOutputQT(const char* filename="lbout")
{

  // output .q file with scalar temperature and velocity

  char buf[80];
  float scale[4];
  int numberOfPoints;
  int start[3], end[3], length[3];
  float* scalarBuffer;
  ofstream file;
  string header="",footer="";
  unsigned long headersize=0,footersize=0,startpos;

  // find extent and number of points for I/O group
  fGroupPieceRangeLocal(start,end);
  if(!lbmpiio) {
    length[0] = end[0]-start[0];
    length[1] = end[1]-start[1];
    length[2] = end[2]-start[2];
  }
  else {
    length[0] = lbsy.nx;
    length[1] = lbsy.ny;
    length[2] = lbsy.nz;
  }
  numberOfPoints = fGroupPieceDataPoints(length);

  // open file if root process for I/O group
  if(lbIOGroup.rank==0) {
    if(!lbmpiio && lbdm.size>lbIOGroup.size)
      sprintf(buf, "%s%.6dat%.6d.q", filename, lbIOGroup.groupId, qVersion);
    else
      sprintf(buf, "%s%.6d.q", filename, qVersion);
  }
  fOpenOutputBinaryFile(buf, file);

  // write dimensions of grid for I/O group
  startpos = 0;
  fWritePlot3DGridIntegerBinaryData(length, lbsy.nd, startpos, file);

  // write velocity scale (speed of sound), freestream
  // angle-of-attack, Reynolds number and time (in time steps)
  scale[0] = float(lbsoundv);
  scale[1] = 1.0;
  scale[2] = lbreynolds;
  scale[3] = float(qVersion*lbsave);
  fWritePlot3DGridFloatBinaryData(scale, 4, startpos, file);

  // allocate buffer for collecting data

  scalarBuffer = (float*)malloc(numberOfPoints*sizeof(float));

  // collect and write temperature

  fGroupTemperatures(scalarBuffer, start, end, false);
  fWriteLegacyVTKFloatBinaryData(scalarBuffer, numberOfPoints, startpos, header.c_str(), footer.c_str(), headersize, footersize, file);

  // collect and write x-component of velocity

  fGroupVelocityComponent(scalarBuffer, start, end, 0, false);
  fWriteLegacyVTKFloatBinaryData(scalarBuffer, numberOfPoints, startpos, header.c_str(), footer.c_str(), headersize, footersize, file);

  // collect and write y-component of velocity

  fGroupVelocityComponent(scalarBuffer, start, end, 1, false);
  fWriteLegacyVTKFloatBinaryData(scalarBuffer, numberOfPoints, startpos, header.c_str(), footer.c_str(), headersize, footersize, file);

  // collect and write z-component of velocity (if needed)

  if(lbsy.nd==3) {
    fGroupVelocityComponent(scalarBuffer, start, end, 2, false);
    fWriteLegacyVTKFloatBinaryData(scalarBuffer, numberOfPoints, startpos, header.c_str(), footer.c_str(), headersize, footersize, file);
  }

  // collect and write phase field/space property

  fGroupPhaseFieldFloat(scalarBuffer, start, end, false);
  fWriteLegacyVTKFloatBinaryData(scalarBuffer, numberOfPoints, startpos, header.c_str(), footer.c_str(), headersize, footersize, file);

  // close file and deallocate buffer

  fCloseOutputBinaryFile(file);

  free(scalarBuffer);

  return 0;
}


int fsOutputQT(const char* filename="lbout")
{
  char buf[80];
  float scale[4];
  int numberOfPoints;
  int start[3], end[3], length[3];
  float* scalarBuffer;
  ofstream file;
  string header="",footer="";
  unsigned long headersize=0,footersize=0,startpos;

  // find extent and number of points for I/O group
  fGroupPieceRangeLocal(start,end);
  if(!lbmpiio) {
    length[0] = end[0]-start[0];
    length[1] = end[1]-start[1];
    length[2] = end[2]-start[2];
  }
  else {
    length[0] = lbsy.nx;
    length[1] = lbsy.ny;
    length[2] = lbsy.nz;
  }
  numberOfPoints = fGroupPieceDataPoints(length);

  // open file if root process for I/O group
  if(lbIOGroup.rank==0) {
    if(!lbmpiio && lbdm.size>lbIOGroup.size)
      sprintf(buf, "%s%.6dat%.6d.q", filename, lbIOGroup.groupId, qVersion);
    else
      sprintf(buf, "%s%.6d.q", filename, qVersion);
  }
  fOpenOutputANSIFile(buf, file);

  // write dimensions of grid for I/O group
  startpos = 0;
  fWritePlot3DGridIntegerANSIData(length, lbsy.nd, startpos, file);

  // write velocity scale (speed of sound), freestream
  // angle-of-attack, Reynolds number and time (in time steps)
  scale[0] = float(lbsoundv);
  scale[1] = 1.0;
  scale[2] = lbreynolds;
  scale[3] = float(qVersion*lbsave);
  fWritePlot3DGridFloatANSIData(scale, 4, startpos, file);

  // allocate buffer for collecting data

  scalarBuffer = (float*)malloc(numberOfPoints*sizeof(float));

  // collect and write temperature
    
  fGroupTemperatures(scalarBuffer, start, end, false);
  fWriteVTKFloatANSIData(scalarBuffer, numberOfPoints, startpos, header.c_str(), footer.c_str(), headersize, footersize, file);

  // collect and write x-component of velocity

  fGroupVelocityComponent(scalarBuffer, start, end, 0, false);
  fWriteVTKFloatANSIData(scalarBuffer, numberOfPoints, startpos, header.c_str(), footer.c_str(), headersize, footersize, file);

  // collect and write y-component of velocity

  fGroupVelocityComponent(scalarBuffer, start, end, 1, false);
  fWriteVTKFloatANSIData(scalarBuffer, numberOfPoints, startpos, header.c_str(), footer.c_str(), headersize, footersize, file);

  // collect and write z-component of velocity (if needed)

  if(lbsy.nd==3) {
    fGroupVelocityComponent(scalarBuffer, start, end, 2, false);
    fWriteVTKFloatANSIData(scalarBuffer, numberOfPoints, startpos, header.c_str(), footer.c_str(), headersize, footersize, file);
  }

  // collect and write phase field/space property

  fGroupPhaseFieldFloat(scalarBuffer, start, end, false);
  fWriteVTKFloatANSIData(scalarBuffer, numberOfPoints, startpos, header.c_str(), footer.c_str(), headersize, footersize, file);

  // close file and deallocate buffer

  fCloseOutputANSIFile(file);

  free(scalarBuffer);

  return 0;
}

