/***************************************************
 *   DL_MESO       Version 2.7                     *
 *   Authors   :   R. S. Qin, M. A. Seaton         *
 *   Copyright :   UKRI STFC Daresbury Laboratory  *
 *             :   09/12/2018                      *
 ***************************************************/

// D2Q9

int fD2Q9VCEZouHe(double v0, double v1, double *force,
                  double *f0, double *f1, double *f2,
	              double *f3, double *f4, double *f5,
                  double *f6, double *f7, double *f8)
{

  // produce fixed velocity at bottom boundary (VCETF) for compressible/incompressible fluids

  double rho, rho0;
  double c1=2.0/3.0,c2=1.0/6.0;
    
  if(!incompress) {
    for(int i=0; i<lbsy.nf; i++) {
      rho = (f0[i]+f2[i]+f6[i]+2.0*(f3[i]+f4[i]+f5[i])-0.5*force[2*i+1])/(1.0-v1);
      f1[i]=f5[i]-0.5*(f2[i]-f6[i])-0.5*rho*v0+rho*v1*c2+0.25*(force[2*i]-force[2*i+1]);
      f7[i]=f3[i]+0.5*(f2[i]-f6[i])+0.5*rho*v0+rho*v1*c2-0.25*(force[2*i]+force[2*i+1]);
      f8[i]=f4[i]+c1*rho*v1;
    }
  }
  else {
    for(int i=0; i<lbsy.nf; i++) {
//     rho = f0+f2+f6+2.0*(f3+f4+f5)+rho0*v1-0.5*force[1];
      rho0 = lbincp[i];
      f1[i]=f5[i]-0.5*(f2[i]-f6[i])-0.5*rho0*v0+rho0*v1*c2+0.25*(force[2*i]-force[2*i+1]);
      f7[i]=f3[i]+0.5*(f2[i]-f6[i])+0.5*rho0*v0+rho0*v1*c2-0.25*(force[2*i]+force[2*i+1]);
      f8[i]=f4[i]+c1*rho0*v1;
    }
  }
  return 0;
}

int fD2Q9VCCZouHe(double *p, double v0, double v1, double *force,
                  double *f0, double *f1, double *f2,
	              double *f3, double *f4, double *f5,
                  double *f6, double *f7, double *f8)
{

  // produce fixed velocity at bottom left boundary (VCCTRF) for compressible/incompressible fluids
  double rho0;
  double c1=2.0/3.0,c2=1.0/6.0,c3=1.0/3.0;

  if(!incompress) {
    for(int i=0; i<lbsy.nf; i++) {
      f1[i]=0.5*(p[i]-f0[i])-f2[i]-f3[i]-f4[i]-p[i]*(0.5*v0+c3*v1)+0.25*force[2*i  ];
      f5[i]=0.5*(p[i]-f0[i])-f2[i]-f3[i]-f4[i]-p[i]*(c3*v0+0.5*v1)+0.25*force[2*i+1];
      f6[i]=f2[i]+c1*p[i]*v0;
      f7[i]=f3[i]+c2*p[i]*(v0+v1)-0.25*(force[2*i]+force[2*i+1]);
      f8[i]=f4[i]+c1*p[i]*v1;
    }
  }
  else {
    for(int i=0; i<lbsy.nf; i++) {
      rho0 = lbincp[i];
      f1[i]=0.5*(p[i]-f0[i])-f2[i]-f3[i]-f4[i]-rho0*(0.5*v0+c3*v1)+0.25*force[2*i  ];
      f5[i]=0.5*(p[i]-f0[i])-f2[i]-f3[i]-f4[i]-rho0*(c3*v0+0.5*v1)+0.25*force[2*i+1];
      f6[i]=f2[i]+c1*rho0*v0;
      f7[i]=f3[i]+c2*rho0*(v0+v1)-0.25*(force[2*i]+force[2*i+1]);
      f8[i]=f4[i]+c1*rho0*v1;
    }
  }
  return 0;
}

int fD2Q9VCECLBEZouHe(double v0, double v1, double *force,
                      double *f0, double *f1, double *f2,
                      double *f3, double *f4, double *f5,
                      double *f6, double *f7, double *f8)
{

  // produce fixed velocity at bottom boundary (VCETF) for compressible fluids
  // with higher-order equilibrium distribution functions for CLBE collisions

  double rho;
  double c1=2.0/3.0,c2=1.0/6.0;
  double v0v0 = v0*v0;
    
  for(int i=0; i<lbsy.nf; i++) {
    rho = (f0[i]+f2[i]+f6[i]+2.0*(f3[i]+f4[i]+f5[i])-0.5*force[2*i+1])/(1.0-v1);
    f1[i]=f5[i]-0.5*(f2[i]-f6[i])-0.5*rho*v0+rho*v1*(c2+0.5*v0v0)+0.25*(force[2*i]-force[2*i+1]);
    f7[i]=f3[i]+0.5*(f2[i]-f6[i])+0.5*rho*v0+rho*v1*(c2+0.5*v0v0)-0.25*(force[2*i]+force[2*i+1]);
    f8[i]=f4[i]+rho*v1*(c1-v0v0);
  }
  return 0;
}

int fD2Q9VCCCLBEZouHe(double *p, double v0, double v1, double *force,
                      double *f0, double *f1, double *f2,
                      double *f3, double *f4, double *f5,
                      double *f6, double *f7, double *f8)
{

  // produce fixed velocity at bottom left boundary (VCCTFR) for compressible fluids
  // with higher-order equilibrium distribution functions for CLBE collisions
    
  double c1=2.0/3.0,c2=1.0/6.0,c3=1.0/3.0;
  double v0v0 = v0*v0;
  double v1v1 = v1*v1;
    
  for(int i=0; i<lbsy.nf; i++) {
      f1[i]=0.5*(p[i]-f0[i])-f2[i]-f3[i]-f4[i]-p[i]*(0.5*v0+c3*v1-0.5*v0v0*v1)+0.25*force[2*i  ];
      f5[i]=0.5*(p[i]-f0[i])-f2[i]-f3[i]-f4[i]-p[i]*(c3*v0+0.5*v1-0.5*v0*v1v1)+0.25*force[2*i+1];
      f6[i]=f2[i]+p[i]*(c1*v0-v0*v1v1);
      f7[i]=f3[i]+p[i]*(c2*(v0+v1)+0.5*(v0v0*v1+v0*v1v1))-0.25*(force[2*i]+force[2*i+1]);
      f8[i]=f4[i]+p[i]*(c1*v1-v0v0*v1);
  }
  return 0;
}

int fD2Q9VCESimpleZouHe(double v0, double v1, double *force,
                        double *f0, double *f1, double *f2,
	                    double *f3, double *f4, double *f5,
                        double *f6, double *f7, double *f8)
{

  // produce fixed velocity at bottom boundary (VCETF) for compressible/incompressible fluids

  double rho, rho0;
  double c1=2.0/3.0,c2=1.0/6.0;

  if(!incompress) {
    for(int i=0; i<lbsy.nf; i++) {
      rho = (f0[i]+f2[i]+f6[i]+2.0*(f3[i]+f4[i]+f5[i])-0.5*force[2*i+1])/(1.0-v1);
      f1[i]=f5[i]-c2*rho*(v0-v1);
      f7[i]=f3[i]+c2*rho*(v0+v1);
      f8[i]=f4[i]+c1*rho*v1;
    }
  }
  else {
    for(int i=0; i<lbsy.nf; i++) {
//     rho = f0+f2+f6+2.0*(f1+f7+f8)-rho0*v1;
      rho0 = lbincp[i];
      f1[i]=f5[i]-c2*rho0*(v0-v1);
      f7[i]=f3[i]+c2*rho0*(v0+v1);
      f8[i]=f4[i]+c1*rho0*v1;
    }
  }
  return 0;
}

int fD2Q9VCCSimpleZouHe(double *p, double v0, double v1, double *force,
                        double *f0, double *f1, double *f2,
	                    double *f3, double *f4, double *f5,
                        double *f6, double *f7, double *f8)
{

  // produce fixed velocity at bottom left boundary (VCCTFR) for compressible/incompressible fluids
  double rho0;
  double c1=2.0/3.0,c2=1.0/6.0,c3=1.0/3.0;

  if(!incompress) {
    for(int i=0; i<lbsy.nf; i++) {
      f1[i]=0.5*(p[i]-f0[i])-f2[i]-f3[i]-f4[i]-p[i]*(0.5*v0+c3*v1)+0.125*(force[2*i  ]-force[2*i+1]);
      f5[i]=0.5*(p[i]-f0[i])-f2[i]-f3[i]-f4[i]-p[i]*(c3*v0+0.5*v1)+0.125*(force[2*i+1]-force[2*i  ]);
      f6[i]=f2[i]+c1*p[i]*v0;
      f7[i]=f3[i]+c2*p[i]*(v0+v1);
      f8[i]=f4[i]+c1*p[i]*v1;
    }
  }
  else {
    for(int i=0; i<lbsy.nf; i++) {
      rho0 = lbincp[i];
      f1[i]=0.5*(p[i]-f0[i])-f2[i]-f3[i]-f4[i]-rho0*(0.5*v0+c3*v1)+0.125*(force[2*i  ]-force[2*i+1]);
      f5[i]=0.5*(p[i]-f0[i])-f2[i]-f3[i]-f4[i]-rho0*(c3*v0+0.5*v1)+0.125*(force[2*i+1]-force[2*i  ]);
      f6[i]=f2[i]+c1*rho0*v0;
      f7[i]=f3[i]+c2*rho0*(v0+v1);
      f8[i]=f4[i]+c1*rho0*v1;
    }
  }
  return 0;
}

int fD2Q9VCECLBESimpleZouHe(double v0, double v1, double *force,
                            double *f0, double *f1, double *f2,
                            double *f3, double *f4, double *f5,
                            double *f6, double *f7, double *f8)
{

  // produce fixed velocity at bottom boundary (VCETF) for compressible fluids
  // with higher-order equilibrium distribution functions for CLBE collisions

  double rho;
  double c1=2.0/3.0,c2=1.0/6.0;
  double v0v0 = v0*v0;
  double v1v1 = v1*v1;

  for(int i=0; i<lbsy.nf; i++) {
    rho = (f0[i]+f2[i]+f6[i]+2.0*(f3[i]+f4[i]+f5[i])-0.5*force[2*i+1])/(1.0-v1);
    f1[i]=f5[i]-c2*rho*(v0-v1)+0.5*rho*(v0v0*v1-v0*v1v1);
    f7[i]=f3[i]+c2*rho*(v0+v1)+0.5*rho*(v0v0*v1+v0*v1v1);
    f8[i]=f4[i]+rho*v1*(c1-v0v0);
  }
  return 0;
}

int fD2Q9VCCCLBESimpleZouHe(double *p, double v0, double v1, double *force,
                            double *f0, double *f1, double *f2,
                            double *f3, double *f4, double *f5,
                            double *f6, double *f7, double *f8)
{

  // produce fixed velocity at bottom left boundary (VCCTFR) for compressible fluids
  // with higher-order equilibrium distribution functions for CLBE collisions

  double c1=2.0/3.0,c2=1.0/6.0,c3=1.0/3.0;
  double v0v0 = v0*v0;
  double v1v1 = v1*v1;

  for(int i=0; i<lbsy.nf; i++) {
      f1[i]=0.5*(p[i]-f0[i])-f2[i]-f3[i]-f4[i]-p[i]*(0.5*v0+c3*v1-0.25*v0v0*v1+0.25*v0*v1v1)+0.125*(force[2*i  ]-force[2*i+1]);
      f5[i]=0.5*(p[i]-f0[i])-f2[i]-f3[i]-f4[i]-p[i]*(c3*v0+0.5*v1+0.25*v0v0*v1-0.25*v0*v1v1)+0.125*(force[2*i+1]-force[2*i  ]);
      f6[i]=f2[i]+p[i]*(c1*v0-v0*v1v1);
      f7[i]=f3[i]+p[i]*(c2*(v0+v1)+0.5*(v0v0*v1+v0*v1v1));
      f8[i]=f4[i]+p[i]*(c1*v1-v0v0*v1);
  }
  return 0;
}

int fD2Q9VFZouHe(long tpos, long tpos1, int prop, double *uwall, double dx, double dy)
{
  long spos = tpos * lbsitelength;
  int qdim = lbsy.nf+lbsy.nc+lbsy.nt;
  double force[2*lbsy.nf], rho[lbsy.nf];
  double drdx,drdy,dpdx,dpdy;

  // sort out forces at grid point
    
  fD2Q9BoundaryForceVelocity(force, tpos, tpos1, dx, dy, uwall, prop);
    
  // apply boundary condition

  if(prop>30 && prop<35) {
    fGetAllMassSite(rho, &lbf[tpos1*lbsitelength]);
    if(interact==20) {
      drdx = lbft[4*lbsy.nf*tpos1  ];
      drdy = lbft[4*lbsy.nf*tpos1+1];
      rho[0] += (dx*drdx+dy*drdy);
      if(lbsy.nf>1) {
        dpdx = lbft[4*lbsy.nf*tpos1+4];
        dpdy = lbft[4*lbsy.nf*tpos1+5];
        rho[1] += (dx*dpdx+dy*dpdy);
      }
    }
  }
    
  if (collide>11) {
    switch (prop) {
      case CETF:
        fD2Q9VCECLBEZouHe(uwall[0], uwall[1], &force[0],
                          &lbf[spos],        &lbf[spos+1*qdim], &lbf[spos+2*qdim],
                          &lbf[spos+3*qdim], &lbf[spos+4*qdim], &lbf[spos+5*qdim],
                          &lbf[spos+6*qdim], &lbf[spos+7*qdim], &lbf[spos+8*qdim]);
        break;
      case CELF:
        fD2Q9VCECLBEZouHe(uwall[1], -uwall[0], &force[0],
                          &lbf[spos],        &lbf[spos+3*qdim], &lbf[spos+4*qdim],
                          &lbf[spos+5*qdim], &lbf[spos+6*qdim], &lbf[spos+7*qdim],
                          &lbf[spos+8*qdim], &lbf[spos+1*qdim], &lbf[spos+2*qdim]);
        break;
      case CEDF:
        fD2Q9VCECLBEZouHe(-uwall[0], -uwall[1], &force[0],
                          &lbf[spos],        &lbf[spos+5*qdim], &lbf[spos+6*qdim],
                          &lbf[spos+7*qdim], &lbf[spos+8*qdim], &lbf[spos+1*qdim],
                          &lbf[spos+2*qdim], &lbf[spos+3*qdim], &lbf[spos+4*qdim]);
        break;
      case CERF:
        fD2Q9VCECLBEZouHe(-uwall[1], uwall[0], &force[0],
                          &lbf[spos],        &lbf[spos+7*qdim], &lbf[spos+8*qdim],
                          &lbf[spos+1*qdim], &lbf[spos+2*qdim], &lbf[spos+3*qdim],
                          &lbf[spos+4*qdim], &lbf[spos+5*qdim], &lbf[spos+6*qdim]);
        break;
      case CCTRF:
        fD2Q9VCCCLBEZouHe(rho, uwall[0], uwall[1], &force[0],
                          &lbf[spos], &lbf[spos+1*qdim], &lbf[spos+2*qdim],
                          &lbf[spos+3*qdim], &lbf[spos+4*qdim], &lbf[spos+5*qdim],
                          &lbf[spos+6*qdim], &lbf[spos+7*qdim], &lbf[spos+8*qdim]);
        break;
      case CCTLF:
        fD2Q9VCCCLBEZouHe(rho, uwall[1], -uwall[0], &force[0],
                          &lbf[spos], &lbf[spos+3*qdim], &lbf[spos+4*qdim],
                          &lbf[spos+5*qdim], &lbf[spos+6*qdim], &lbf[spos+7*qdim],
                          &lbf[spos+8*qdim], &lbf[spos+1*qdim], &lbf[spos+2*qdim]);
        break;
      case CCDLF:
        fD2Q9VCCCLBEZouHe(rho,  -uwall[0], -uwall[1], &force[0],
                          &lbf[spos], &lbf[spos+5*qdim], &lbf[spos+6*qdim],
                          &lbf[spos+7*qdim], &lbf[spos+8*qdim], &lbf[spos+1*qdim],
                          &lbf[spos+2*qdim], &lbf[spos+3*qdim], &lbf[spos+4*qdim]);
        break;
      case CCDRF:
        fD2Q9VCCCLBEZouHe(rho, -uwall[1], uwall[0], &force[0],
                          &lbf[spos], &lbf[spos+7*qdim], &lbf[spos+8*qdim],
                          &lbf[spos+1*qdim], &lbf[spos+2*qdim], &lbf[spos+3*qdim],
                          &lbf[spos+4*qdim], &lbf[spos+5*qdim], &lbf[spos+6*qdim]);
        break;
    }
  }
  else {
    switch (prop) {
      case CETF:
        fD2Q9VCEZouHe(uwall[0], uwall[1], &force[0],
                      &lbf[spos],        &lbf[spos+1*qdim], &lbf[spos+2*qdim],
                      &lbf[spos+3*qdim], &lbf[spos+4*qdim], &lbf[spos+5*qdim],
                      &lbf[spos+6*qdim], &lbf[spos+7*qdim], &lbf[spos+8*qdim]);
        break;
      case CELF:
        fD2Q9VCEZouHe(uwall[1], -uwall[0], &force[0],
                      &lbf[spos],        &lbf[spos+3*qdim], &lbf[spos+4*qdim],
                      &lbf[spos+5*qdim], &lbf[spos+6*qdim], &lbf[spos+7*qdim],
                      &lbf[spos+8*qdim], &lbf[spos+1*qdim], &lbf[spos+2*qdim]);
        break;
      case CEDF:
        fD2Q9VCEZouHe(-uwall[0], -uwall[1], &force[0],
                      &lbf[spos],        &lbf[spos+5*qdim], &lbf[spos+6*qdim],
                      &lbf[spos+7*qdim], &lbf[spos+8*qdim], &lbf[spos+1*qdim],
                      &lbf[spos+2*qdim], &lbf[spos+3*qdim], &lbf[spos+4*qdim]);
        break;
      case CERF:
        fD2Q9VCEZouHe(-uwall[1], uwall[0], &force[0],
                      &lbf[spos],        &lbf[spos+7*qdim], &lbf[spos+8*qdim],
                      &lbf[spos+1*qdim], &lbf[spos+2*qdim], &lbf[spos+3*qdim],
                      &lbf[spos+4*qdim], &lbf[spos+5*qdim], &lbf[spos+6*qdim]);
        break;
      case CCTRF:
        fD2Q9VCCZouHe(rho, uwall[0], uwall[1], &force[0],
                      &lbf[spos], &lbf[spos+1*qdim], &lbf[spos+2*qdim],
                      &lbf[spos+3*qdim], &lbf[spos+4*qdim], &lbf[spos+5*qdim],
                      &lbf[spos+6*qdim], &lbf[spos+7*qdim], &lbf[spos+8*qdim]);
        break;
      case CCTLF:
        fD2Q9VCCZouHe(rho, uwall[1], -uwall[0], &force[0],
                      &lbf[spos], &lbf[spos+3*qdim], &lbf[spos+4*qdim],
                      &lbf[spos+5*qdim], &lbf[spos+6*qdim], &lbf[spos+7*qdim],
                      &lbf[spos+8*qdim], &lbf[spos+1*qdim], &lbf[spos+2*qdim]);
        break;
      case CCDLF:
        fD2Q9VCCZouHe(rho, -uwall[0], -uwall[1], &force[0],
                      &lbf[spos], &lbf[spos+5*qdim], &lbf[spos+6*qdim],
                      &lbf[spos+7*qdim], &lbf[spos+8*qdim], &lbf[spos+1*qdim],
                      &lbf[spos+2*qdim], &lbf[spos+3*qdim], &lbf[spos+4*qdim]);
        break;
      case CCDRF:
        fD2Q9VCCZouHe(rho, -uwall[1], uwall[0], &force[0],
                      &lbf[spos], &lbf[spos+7*qdim], &lbf[spos+8*qdim],
                      &lbf[spos+1*qdim], &lbf[spos+2*qdim], &lbf[spos+3*qdim],
                      &lbf[spos+4*qdim], &lbf[spos+5*qdim], &lbf[spos+6*qdim]);
        break;
    }
  }
  return 0;
}

int fD2Q9VFSimpleZouHe(long tpos, long tpos1, int prop, double *uwall, double dx, double dy)
{
  long spos = tpos * lbsitelength;
  int qdim = lbsy.nf+lbsy.nc+lbsy.nt;
  double force[2*lbsy.nf], rho[lbsy.nf];
  double drdx,drdy,dpdx,dpdy;

  // sort out forces at grid point
    
  fD2Q9BoundaryForceVelocity(force, tpos, tpos1, dx, dy, uwall, prop);
    
  // apply boundary condition
    
  if(prop>30 && prop<35) {
    fGetAllMassSite(rho, &lbf[tpos1*lbsitelength]);
    if(interact==20) {
      drdx = lbft[4*lbsy.nf*tpos1  ];
      drdy = lbft[4*lbsy.nf*tpos1+1];
      rho[0] += (dx*drdx+dy*drdy);
      if(lbsy.nf>1) {
        dpdx = lbft[4*lbsy.nf*tpos1+4];
        dpdy = lbft[4*lbsy.nf*tpos1+5];
        rho[1] += (dx*dpdx+dy*dpdy);
      }
    }
  }
    
  if (collide>11) {
    switch (prop) {
      case CETF:
        fD2Q9VCECLBESimpleZouHe(uwall[0], uwall[1], &force[0],
                                &lbf[spos],        &lbf[spos+1*qdim], &lbf[spos+2*qdim],
                                &lbf[spos+3*qdim], &lbf[spos+4*qdim], &lbf[spos+5*qdim],
                                &lbf[spos+6*qdim], &lbf[spos+7*qdim], &lbf[spos+8*qdim]);
        break;
      case CELF:
        fD2Q9VCECLBESimpleZouHe(uwall[1], -uwall[0], &force[0],
                                &lbf[spos],        &lbf[spos+3*qdim], &lbf[spos+4*qdim],
                                &lbf[spos+5*qdim], &lbf[spos+6*qdim], &lbf[spos+7*qdim],
                                &lbf[spos+8*qdim], &lbf[spos+1*qdim], &lbf[spos+2*qdim]);
        break;
      case CEDF:
        fD2Q9VCECLBESimpleZouHe(-uwall[0], -uwall[1], &force[0],
                                &lbf[spos],        &lbf[spos+5*qdim], &lbf[spos+6*qdim],
                                &lbf[spos+7*qdim], &lbf[spos+8*qdim], &lbf[spos+1*qdim],
                                &lbf[spos+2*qdim], &lbf[spos+3*qdim], &lbf[spos+4*qdim]);
        break;
      case CERF:
        fD2Q9VCECLBESimpleZouHe(-uwall[1], uwall[0], &force[0],
                                &lbf[spos],        &lbf[spos+7*qdim], &lbf[spos+8*qdim],
                                &lbf[spos+1*qdim], &lbf[spos+2*qdim], &lbf[spos+3*qdim],
                                &lbf[spos+4*qdim], &lbf[spos+5*qdim], &lbf[spos+6*qdim]);
        break;
      case CCTRF:
        fD2Q9VCCCLBESimpleZouHe(rho, uwall[0], uwall[1], &force[0],
                                &lbf[spos], &lbf[spos+1*qdim], &lbf[spos+2*qdim],
                                &lbf[spos+3*qdim], &lbf[spos+4*qdim], &lbf[spos+5*qdim],
                                &lbf[spos+6*qdim], &lbf[spos+7*qdim], &lbf[spos+8*qdim]);
        break;
      case CCTLF:
        fD2Q9VCCCLBESimpleZouHe(rho, uwall[1], -uwall[0], &force[0],
                                &lbf[spos], &lbf[spos+3*qdim], &lbf[spos+4*qdim],
                                &lbf[spos+5*qdim], &lbf[spos+6*qdim], &lbf[spos+7*qdim],
                                &lbf[spos+8*qdim], &lbf[spos+1*qdim], &lbf[spos+2*qdim]);
        break;
      case CCDLF:
        fD2Q9VCCCLBESimpleZouHe(rho, -uwall[0], -uwall[1], &force[0],
                                &lbf[spos], &lbf[spos+5*qdim], &lbf[spos+6*qdim],
                                &lbf[spos+7*qdim], &lbf[spos+8*qdim], &lbf[spos+1*qdim],
                                &lbf[spos+2*qdim], &lbf[spos+3*qdim], &lbf[spos+4*qdim]);
        break;
      case CCDRF:
        fD2Q9VCCCLBESimpleZouHe(rho, -uwall[1], uwall[0], &force[0],
                                &lbf[spos], &lbf[spos+7*qdim], &lbf[spos+8*qdim],
                                &lbf[spos+1*qdim], &lbf[spos+2*qdim], &lbf[spos+3*qdim],
                                &lbf[spos+4*qdim], &lbf[spos+5*qdim], &lbf[spos+6*qdim]);
        break;
    }
  }
  else {
    switch (prop) {
      case CETF:
        fD2Q9VCESimpleZouHe(uwall[0], uwall[1], &force[0],
                            &lbf[spos],        &lbf[spos+1*qdim], &lbf[spos+2*qdim],
                            &lbf[spos+3*qdim], &lbf[spos+4*qdim], &lbf[spos+5*qdim],
                            &lbf[spos+6*qdim], &lbf[spos+7*qdim], &lbf[spos+8*qdim]);
        break;
      case CELF:
        fD2Q9VCESimpleZouHe(uwall[1], -uwall[0], &force[0],
                            &lbf[spos],        &lbf[spos+3*qdim], &lbf[spos+4*qdim],
                            &lbf[spos+5*qdim], &lbf[spos+6*qdim], &lbf[spos+7*qdim],
                            &lbf[spos+8*qdim], &lbf[spos+1*qdim], &lbf[spos+2*qdim]);
        break;
      case CEDF:
        fD2Q9VCESimpleZouHe(-uwall[0], -uwall[1], &force[0],
                            &lbf[spos],        &lbf[spos+5*qdim], &lbf[spos+6*qdim],
                            &lbf[spos+7*qdim], &lbf[spos+8*qdim], &lbf[spos+1*qdim],
                            &lbf[spos+2*qdim], &lbf[spos+3*qdim], &lbf[spos+4*qdim]);
        break;
      case CERF:
        fD2Q9VCESimpleZouHe(-uwall[1], uwall[0], &force[0],
                            &lbf[spos],        &lbf[spos+7*qdim], &lbf[spos+8*qdim],
                            &lbf[spos+1*qdim], &lbf[spos+2*qdim], &lbf[spos+3*qdim],
                            &lbf[spos+4*qdim], &lbf[spos+5*qdim], &lbf[spos+6*qdim]);
        break;
      case CCTRF:
        fD2Q9VCCSimpleZouHe(rho, uwall[0], uwall[1], &force[0],
                            &lbf[spos], &lbf[spos+1*qdim], &lbf[spos+2*qdim],
                            &lbf[spos+3*qdim], &lbf[spos+4*qdim], &lbf[spos+5*qdim],
                            &lbf[spos+6*qdim], &lbf[spos+7*qdim], &lbf[spos+8*qdim]);
        break;
      case CCTLF:
        fD2Q9VCCSimpleZouHe(rho, uwall[1], -uwall[0], &force[0],
                            &lbf[spos], &lbf[spos+3*qdim], &lbf[spos+4*qdim],
                            &lbf[spos+5*qdim], &lbf[spos+6*qdim], &lbf[spos+7*qdim],
                            &lbf[spos+8*qdim], &lbf[spos+1*qdim], &lbf[spos+2*qdim]);
        break;
      case CCDLF:
        fD2Q9VCCSimpleZouHe(rho, -uwall[0], -uwall[1], &force[0],
                            &lbf[spos], &lbf[spos+5*qdim], &lbf[spos+6*qdim],
                            &lbf[spos+7*qdim], &lbf[spos+8*qdim], &lbf[spos+1*qdim],
                            &lbf[spos+2*qdim], &lbf[spos+3*qdim], &lbf[spos+4*qdim]);
        break;
      case CCDRF:
        fD2Q9VCCSimpleZouHe(rho, -uwall[1], uwall[0], &force[0],
                            &lbf[spos], &lbf[spos+7*qdim], &lbf[spos+8*qdim],
                            &lbf[spos+1*qdim], &lbf[spos+2*qdim], &lbf[spos+3*qdim],
                            &lbf[spos+4*qdim], &lbf[spos+5*qdim], &lbf[spos+6*qdim]);
        break;
    }
  }
  return 0;
}

int fD2Q9PCEZouHe(double *p, double *force, double *f0, double *f1, double *f2, double *f3,
	              double *f4, double *f5, double *f6, double *f7, double *f8, double &vel)
{

  // produce fixed density/pressure boundary for concave edge pointing upwards (PCETF)

  double c1=2.0/3.0,c2=1.0/6.0;
  double v,mass=0.0;
  vel=0.0;

  if(!incompress) {
    for(int i=0; i<lbsy.nf; i++) {
      v=p[i]-(f0[i]+f2[i]+f6[i]+2.0*(f3[i]+f4[i]+f5[i]))+0.5*force[2*i+1];  // v = p*v1
      vel += v;
      mass += p[i];
      f1[i]=f5[i]-0.5*(f2[i]-f6[i])+v*c2+0.25*(force[2*i]-force[2*i+1]);
      f7[i]=f3[i]+0.5*(f2[i]-f6[i])+v*c2-0.25*(force[2*i]+force[2*i+1]);
      f8[i]=f4[i]+c1*v;
    }
  }
  else {
    for(int i=0; i<lbsy.nf; i++) {
      v=p[i]-(f0[i]+f2[i]+f6[i]+2.0*(f1[i]+f7[i]+f8[i]))+0.5*force[2*i+1];  // v = p*v1
      vel += v;
      mass += lbincp[i];
      f1[i]=f5[i]-0.5*(f2[i]-f6[i])+v*c2+0.25*(force[2*i]-force[2*i+1]);
      f7[i]=f3[i]+0.5*(f2[i]-f6[i])+v*c2-0.25*(force[2*i]+force[2*i+1]);
      f8[i]=f4[i]+c1*v;
    }
  }
  vel *= fReciprocal(mass);
  return 0;
}

int fD2Q9PCESwiftZouHe(double *p, double *force, double *f0, double *f1, double *f2, double *f3,
	                   double *f4, double *f5, double *f6, double *f7, double *f8, double &vel)
{

  // produce fixed density/pressure boundary for concave edge pointing upwards (PCETF)
  // with Swift free-energy interactions

  double c1=2.0/3.0,c2=1.0/6.0;
  double v,mass=0.0;
  vel=0.0;

  v=p[0]-(f0[0]+f2[0]+f6[0]+2.0*(f3[0]+f4[0]+f5[0]))+0.5*force[1];  // v = p*v1
  vel += v;
  mass += p[0];
  f1[0]=f5[0]-0.5*(f2[0]-f6[0])+v*c2+0.25*(force[0]-force[1]);
  f7[0]=f3[0]+0.5*(f2[0]-f6[0])+v*c2-0.25*(force[0]+force[1]);
  f8[0]=f4[0]+c1*v;
  vel *= fReciprocal(mass);
  if(lbsy.nf>1) {
    f1[1]=f5[1]-0.5*(f2[1]-f6[1])+p[1]*vel*c2;
    f7[1]=f3[1]+0.5*(f2[1]-f6[1])+p[1]*vel*c2;
    f8[1]=f4[1]+p[1]*c1*vel;
  }
  return 0;
}

int fD2Q9PFZouHe(long tpos, int prop, double *p0, double *uwall)
{
  double moment;
  long spos = tpos * lbsitelength;
  int qdim = lbsy.nf+lbsy.nc+lbsy.nt;
  double force[2*lbsy.nf];
    
  // sort out forces
    
  fD2Q9BoundaryForceDensity(force, tpos, p0, prop);

  // apply boundary condition
    
  if(interact==20) {
    switch (prop) {
      case CETF:
        fD2Q9PCESwiftZouHe(p0, &force[0],
                           &lbf[spos],        &lbf[spos+1*qdim], &lbf[spos+2*qdim],
                           &lbf[spos+3*qdim], &lbf[spos+4*qdim], &lbf[spos+5*qdim],
                           &lbf[spos+6*qdim], &lbf[spos+7*qdim], &lbf[spos+8*qdim], moment);
        uwall[1] += moment;
        break;
      case CELF:
        fD2Q9PCESwiftZouHe(p0, &force[0],
                           &lbf[spos],        &lbf[spos+3*qdim], &lbf[spos+4*qdim],
                           &lbf[spos+5*qdim], &lbf[spos+6*qdim], &lbf[spos+7*qdim],
                           &lbf[spos+8*qdim], &lbf[spos+1*qdim], &lbf[spos+2*qdim], moment);
        uwall[0] -= moment;
        break;
      case CEDF:
        fD2Q9PCESwiftZouHe(p0, &force[0],
                           &lbf[spos],        &lbf[spos+5*qdim], &lbf[spos+6*qdim],
  	                       &lbf[spos+7*qdim], &lbf[spos+8*qdim], &lbf[spos+1*qdim],
	                       &lbf[spos+2*qdim], &lbf[spos+3*qdim], &lbf[spos+4*qdim], moment);
        uwall[1] -= moment;
        break;
      case CERF:
        fD2Q9PCESwiftZouHe(p0, &force[0],
                           &lbf[spos],        &lbf[spos+7*qdim], &lbf[spos+8*qdim],
                           &lbf[spos+1*qdim], &lbf[spos+2*qdim], &lbf[spos+3*qdim],
                           &lbf[spos+4*qdim], &lbf[spos+5*qdim], &lbf[spos+6*qdim], moment);
        uwall[0] += moment;
        break;
      case CCTRF:
        fD2Q9VCCZouHe(p0, uwall[0], uwall[1], &force[0],
                      &lbf[spos], &lbf[spos+1*qdim], &lbf[spos+2*qdim],
                      &lbf[spos+3*qdim], &lbf[spos+4*qdim], &lbf[spos+5*qdim],
                      &lbf[spos+6*qdim], &lbf[spos+7*qdim], &lbf[spos+8*qdim]);
        break;
      case CCTLF:
        fD2Q9VCCZouHe(p0, uwall[1], -uwall[0], &force[0],
                      &lbf[spos], &lbf[spos+3*qdim], &lbf[spos+4*qdim],
                      &lbf[spos+5*qdim], &lbf[spos+6*qdim], &lbf[spos+7*qdim],
                      &lbf[spos+8*qdim], &lbf[spos+1*qdim], &lbf[spos+2*qdim]);
        break;
      case CCDLF:
        fD2Q9VCCZouHe(p0, -uwall[0], -uwall[1], &force[0],
                      &lbf[spos], &lbf[spos+5*qdim], &lbf[spos+6*qdim],
                      &lbf[spos+7*qdim], &lbf[spos+8*qdim], &lbf[spos+1*qdim],
                      &lbf[spos+2*qdim], &lbf[spos+3*qdim], &lbf[spos+4*qdim]);
        break;
      case CCDRF:
        fD2Q9VCCZouHe(p0, -uwall[1], uwall[0], &force[0],
                      &lbf[spos], &lbf[spos+7*qdim], &lbf[spos+8*qdim],
                      &lbf[spos+1*qdim], &lbf[spos+2*qdim], &lbf[spos+3*qdim],
                      &lbf[spos+4*qdim], &lbf[spos+5*qdim], &lbf[spos+6*qdim]);
        break;
    }
  }
  else if(collide>11) {
    switch (prop) {
      case CETF:
        fD2Q9PCEZouHe(p0, &force[0],
                      &lbf[spos],        &lbf[spos+1*qdim], &lbf[spos+2*qdim],
                      &lbf[spos+3*qdim], &lbf[spos+4*qdim], &lbf[spos+5*qdim],
                      &lbf[spos+6*qdim], &lbf[spos+7*qdim], &lbf[spos+8*qdim], moment);
        uwall[1] += moment;
        break;
      case CELF:
        fD2Q9PCEZouHe(p0, &force[0],
                      &lbf[spos],        &lbf[spos+3*qdim], &lbf[spos+4*qdim],
                      &lbf[spos+5*qdim], &lbf[spos+6*qdim], &lbf[spos+7*qdim],
                      &lbf[spos+8*qdim], &lbf[spos+1*qdim], &lbf[spos+2*qdim], moment);
        uwall[0] -= moment;
        break;
      case CEDF:
        fD2Q9PCEZouHe(p0, &force[0],
                      &lbf[spos],        &lbf[spos+5*qdim], &lbf[spos+6*qdim],
  	                  &lbf[spos+7*qdim], &lbf[spos+8*qdim], &lbf[spos+1*qdim],
	                  &lbf[spos+2*qdim], &lbf[spos+3*qdim], &lbf[spos+4*qdim], moment);
        uwall[1] -= moment;
        break;
      case CERF:
        fD2Q9PCEZouHe(p0, &force[0],
                      &lbf[spos],        &lbf[spos+7*qdim], &lbf[spos+8*qdim],
                      &lbf[spos+1*qdim], &lbf[spos+2*qdim], &lbf[spos+3*qdim],
                      &lbf[spos+4*qdim], &lbf[spos+5*qdim], &lbf[spos+6*qdim], moment);
        uwall[0] += moment;
        break;
      case CCTRF:
        fD2Q9VCCCLBEZouHe(p0, uwall[0], uwall[1], &force[0],
                          &lbf[spos], &lbf[spos+1*qdim], &lbf[spos+2*qdim],
                          &lbf[spos+3*qdim], &lbf[spos+4*qdim], &lbf[spos+5*qdim],
                          &lbf[spos+6*qdim], &lbf[spos+7*qdim], &lbf[spos+8*qdim]);
        break;
      case CCTLF:
        fD2Q9VCCCLBEZouHe(p0, uwall[1], -uwall[0], &force[0],
                          &lbf[spos], &lbf[spos+3*qdim], &lbf[spos+4*qdim],
                          &lbf[spos+5*qdim], &lbf[spos+6*qdim], &lbf[spos+7*qdim],
                          &lbf[spos+8*qdim], &lbf[spos+1*qdim], &lbf[spos+2*qdim]);
        break;
      case CCDLF:
        fD2Q9VCCCLBEZouHe(p0, -uwall[0], -uwall[1], &force[0],
                          &lbf[spos], &lbf[spos+5*qdim], &lbf[spos+6*qdim],
                          &lbf[spos+7*qdim], &lbf[spos+8*qdim], &lbf[spos+1*qdim],
                          &lbf[spos+2*qdim], &lbf[spos+3*qdim], &lbf[spos+4*qdim]);
        break;
      case CCDRF:
        fD2Q9VCCCLBEZouHe(p0, -uwall[1], uwall[0], &force[0],
                          &lbf[spos], &lbf[spos+7*qdim], &lbf[spos+8*qdim],
                          &lbf[spos+1*qdim], &lbf[spos+2*qdim], &lbf[spos+3*qdim],
                          &lbf[spos+4*qdim], &lbf[spos+5*qdim], &lbf[spos+6*qdim]);
        break;
    }
  }
  else {
    switch (prop) {
      case CETF:
        fD2Q9PCEZouHe(p0, &force[0],
                      &lbf[spos],        &lbf[spos+1*qdim], &lbf[spos+2*qdim],
                      &lbf[spos+3*qdim], &lbf[spos+4*qdim], &lbf[spos+5*qdim],
                      &lbf[spos+6*qdim], &lbf[spos+7*qdim], &lbf[spos+8*qdim], moment);
        uwall[1] += moment;
        break;
      case CELF:
        fD2Q9PCEZouHe(p0, &force[0],
                      &lbf[spos],        &lbf[spos+3*qdim], &lbf[spos+4*qdim],
                      &lbf[spos+5*qdim], &lbf[spos+6*qdim], &lbf[spos+7*qdim],
                      &lbf[spos+8*qdim], &lbf[spos+1*qdim], &lbf[spos+2*qdim], moment);
        uwall[0] -= moment;
        break;
      case CEDF:
        fD2Q9PCEZouHe(p0, &force[0],
                      &lbf[spos],        &lbf[spos+5*qdim], &lbf[spos+6*qdim],
  	                  &lbf[spos+7*qdim], &lbf[spos+8*qdim], &lbf[spos+1*qdim],
	                  &lbf[spos+2*qdim], &lbf[spos+3*qdim], &lbf[spos+4*qdim], moment);
        uwall[1] -= moment;
        break;
      case CERF:
        fD2Q9PCEZouHe(p0, &force[0],
                      &lbf[spos],        &lbf[spos+7*qdim], &lbf[spos+8*qdim],
                      &lbf[spos+1*qdim], &lbf[spos+2*qdim], &lbf[spos+3*qdim],
                      &lbf[spos+4*qdim], &lbf[spos+5*qdim], &lbf[spos+6*qdim], moment);
        uwall[0] += moment;
        break;
      case CCTRF:
        fD2Q9VCCZouHe(p0, uwall[0], uwall[1], &force[0],
                      &lbf[spos], &lbf[spos+1*qdim], &lbf[spos+2*qdim],
                      &lbf[spos+3*qdim], &lbf[spos+4*qdim], &lbf[spos+5*qdim],
                      &lbf[spos+6*qdim], &lbf[spos+7*qdim], &lbf[spos+8*qdim]);
        break;
      case CCTLF:
        fD2Q9VCCZouHe(p0, uwall[1], -uwall[0], &force[0],
                      &lbf[spos], &lbf[spos+3*qdim], &lbf[spos+4*qdim],
                      &lbf[spos+5*qdim], &lbf[spos+6*qdim], &lbf[spos+7*qdim],
                      &lbf[spos+8*qdim], &lbf[spos+1*qdim], &lbf[spos+2*qdim]);
        break;
      case CCDLF:
        fD2Q9VCCZouHe(p0, -uwall[0], -uwall[1], &force[0],
                      &lbf[spos], &lbf[spos+5*qdim], &lbf[spos+6*qdim],
                      &lbf[spos+7*qdim], &lbf[spos+8*qdim], &lbf[spos+1*qdim],
                      &lbf[spos+2*qdim], &lbf[spos+3*qdim], &lbf[spos+4*qdim]);
        break;
      case CCDRF:
        fD2Q9VCCZouHe(p0, -uwall[1], uwall[0], &force[0],
                      &lbf[spos], &lbf[spos+7*qdim], &lbf[spos+8*qdim],
                      &lbf[spos+1*qdim], &lbf[spos+2*qdim], &lbf[spos+3*qdim],
                      &lbf[spos+4*qdim], &lbf[spos+5*qdim], &lbf[spos+6*qdim]);
        break;
    }
  }
  return 0;
}


int fD2Q9PFSimpleZouHe(long tpos, int prop, double *p0, double *uwall)
{
  double moment;
  long spos = tpos * lbsitelength;
  int qdim = lbsy.nf+lbsy.nc+lbsy.nt;
  double force[2*lbsy.nf];
    
  // sort out forces
    
  fD2Q9BoundaryForceDensity(force, tpos, p0, prop);

  // apply boundary condition
    
  if(interact==20) {
    switch (prop) {
      case CETF:
        fD2Q9PCESwiftZouHe(p0, &force[0],
                           &lbf[spos],        &lbf[spos+1*qdim], &lbf[spos+2*qdim],
                           &lbf[spos+3*qdim], &lbf[spos+4*qdim], &lbf[spos+5*qdim],
                           &lbf[spos+6*qdim], &lbf[spos+7*qdim], &lbf[spos+8*qdim], moment);
        uwall[1] += moment;
        break;
      case CELF:
        fD2Q9PCESwiftZouHe(p0, &force[0],
                           &lbf[spos],        &lbf[spos+3*qdim], &lbf[spos+4*qdim],
                           &lbf[spos+5*qdim], &lbf[spos+6*qdim], &lbf[spos+7*qdim],
                           &lbf[spos+8*qdim], &lbf[spos+1*qdim], &lbf[spos+2*qdim], moment);
        uwall[0] -= moment;
        break;
      case CEDF:
        fD2Q9PCESwiftZouHe(p0, &force[0],
                           &lbf[spos],        &lbf[spos+5*qdim], &lbf[spos+6*qdim],
                           &lbf[spos+7*qdim], &lbf[spos+8*qdim], &lbf[spos+1*qdim],
	                       &lbf[spos+2*qdim], &lbf[spos+3*qdim], &lbf[spos+4*qdim], moment);
        uwall[1] -= moment;
        break;
      case CERF:
        fD2Q9PCESwiftZouHe(p0, &force[0],
                           &lbf[spos],        &lbf[spos+7*qdim], &lbf[spos+8*qdim],
                           &lbf[spos+1*qdim], &lbf[spos+2*qdim], &lbf[spos+3*qdim],
                           &lbf[spos+4*qdim], &lbf[spos+5*qdim], &lbf[spos+6*qdim], moment);
        uwall[0] += moment;
        break;
      case CCTRF:
        fD2Q9VCCSimpleZouHe(p0, uwall[0], uwall[1], &force[0],
                            &lbf[spos], &lbf[spos+1*qdim], &lbf[spos+2*qdim],
                            &lbf[spos+3*qdim], &lbf[spos+4*qdim], &lbf[spos+5*qdim],
                            &lbf[spos+6*qdim], &lbf[spos+7*qdim], &lbf[spos+8*qdim]);
        break;
      case CCTLF:
        fD2Q9VCCSimpleZouHe(p0, uwall[1], -uwall[0], &force[0],
                            &lbf[spos], &lbf[spos+3*qdim], &lbf[spos+4*qdim],
                            &lbf[spos+5*qdim], &lbf[spos+6*qdim], &lbf[spos+7*qdim],
                            &lbf[spos+8*qdim], &lbf[spos+1*qdim], &lbf[spos+2*qdim]);
        break;
      case CCDLF:
        fD2Q9VCCSimpleZouHe(p0, -uwall[0], -uwall[1], &force[0],
                            &lbf[spos], &lbf[spos+5*qdim], &lbf[spos+6*qdim],
                            &lbf[spos+7*qdim], &lbf[spos+8*qdim], &lbf[spos+1*qdim],
                            &lbf[spos+2*qdim], &lbf[spos+3*qdim], &lbf[spos+4*qdim]);
        break;
      case CCDRF:
        fD2Q9VCCSimpleZouHe(p0, -uwall[1], uwall[0], &force[0],
                            &lbf[spos], &lbf[spos+7*qdim], &lbf[spos+8*qdim],
                            &lbf[spos+1*qdim], &lbf[spos+2*qdim], &lbf[spos+3*qdim],
                            &lbf[spos+4*qdim], &lbf[spos+5*qdim], &lbf[spos+6*qdim]);
        break;
    }
  }
  else if(collide>11) {
    switch (prop) {
      case CETF:
        fD2Q9PCEZouHe(p0, &force[0],
                      &lbf[spos],        &lbf[spos+1*qdim], &lbf[spos+2*qdim],
                      &lbf[spos+3*qdim], &lbf[spos+4*qdim], &lbf[spos+5*qdim],
                      &lbf[spos+6*qdim], &lbf[spos+7*qdim], &lbf[spos+8*qdim], moment);
        uwall[1] += moment;
        break;
      case CELF:
        fD2Q9PCEZouHe(p0, &force[0],
                      &lbf[spos],        &lbf[spos+3*qdim], &lbf[spos+4*qdim],
                      &lbf[spos+5*qdim], &lbf[spos+6*qdim], &lbf[spos+7*qdim],
                      &lbf[spos+8*qdim], &lbf[spos+1*qdim], &lbf[spos+2*qdim], moment);
        uwall[0] -= moment;
        break;
      case CEDF:
        fD2Q9PCEZouHe(p0, &force[0],
                      &lbf[spos],        &lbf[spos+5*qdim], &lbf[spos+6*qdim],
  	                  &lbf[spos+7*qdim], &lbf[spos+8*qdim], &lbf[spos+1*qdim],
	                  &lbf[spos+2*qdim], &lbf[spos+3*qdim], &lbf[spos+4*qdim], moment);
        uwall[1] -= moment;
        break;
      case CERF:
        fD2Q9PCEZouHe(p0, &force[0],
                      &lbf[spos],        &lbf[spos+7*qdim], &lbf[spos+8*qdim],
                      &lbf[spos+1*qdim], &lbf[spos+2*qdim], &lbf[spos+3*qdim],
                      &lbf[spos+4*qdim], &lbf[spos+5*qdim], &lbf[spos+6*qdim], moment);
        uwall[0] += moment;
        break;
      case CCTRF:
        fD2Q9VCCCLBESimpleZouHe(p0, uwall[0], uwall[1], &force[0],
                                &lbf[spos], &lbf[spos+1*qdim], &lbf[spos+2*qdim],
                                &lbf[spos+3*qdim], &lbf[spos+4*qdim], &lbf[spos+5*qdim],
                                &lbf[spos+6*qdim], &lbf[spos+7*qdim], &lbf[spos+8*qdim]);
        break;
      case CCTLF:
        fD2Q9VCCCLBESimpleZouHe(p0, uwall[1], -uwall[0], &force[0],
                                &lbf[spos], &lbf[spos+3*qdim], &lbf[spos+4*qdim],
                                &lbf[spos+5*qdim], &lbf[spos+6*qdim], &lbf[spos+7*qdim],
                                &lbf[spos+8*qdim], &lbf[spos+1*qdim], &lbf[spos+2*qdim]);
        break;
      case CCDLF:
        fD2Q9VCCCLBESimpleZouHe(p0, -uwall[0], -uwall[1], &force[0],
                                &lbf[spos], &lbf[spos+5*qdim], &lbf[spos+6*qdim],
                                &lbf[spos+7*qdim], &lbf[spos+8*qdim], &lbf[spos+1*qdim],
                                &lbf[spos+2*qdim], &lbf[spos+3*qdim], &lbf[spos+4*qdim]);
        break;
      case CCDRF:
        fD2Q9VCCCLBESimpleZouHe(p0, -uwall[1], uwall[0], &force[0],
                                &lbf[spos], &lbf[spos+7*qdim], &lbf[spos+8*qdim],
                                &lbf[spos+1*qdim], &lbf[spos+2*qdim], &lbf[spos+3*qdim],
                                &lbf[spos+4*qdim], &lbf[spos+5*qdim], &lbf[spos+6*qdim]);
        break;
    }
  }
  else {
    switch (prop) {
      case CETF:
        fD2Q9PCEZouHe(p0, &force[0],
                      &lbf[spos],        &lbf[spos+1*qdim], &lbf[spos+2*qdim],
                      &lbf[spos+3*qdim], &lbf[spos+4*qdim], &lbf[spos+5*qdim],
                      &lbf[spos+6*qdim], &lbf[spos+7*qdim], &lbf[spos+8*qdim], moment);
        uwall[1] += moment;
        break;
      case CELF:
        fD2Q9PCEZouHe(p0, &force[0],
                      &lbf[spos],        &lbf[spos+3*qdim], &lbf[spos+4*qdim],
                      &lbf[spos+5*qdim], &lbf[spos+6*qdim], &lbf[spos+7*qdim],
                      &lbf[spos+8*qdim], &lbf[spos+1*qdim], &lbf[spos+2*qdim], moment);
        uwall[0] -= moment;
        break;
      case CEDF:
        fD2Q9PCEZouHe(p0, &force[0],
                      &lbf[spos],        &lbf[spos+5*qdim], &lbf[spos+6*qdim],
  	                  &lbf[spos+7*qdim], &lbf[spos+8*qdim], &lbf[spos+1*qdim],
	                  &lbf[spos+2*qdim], &lbf[spos+3*qdim], &lbf[spos+4*qdim], moment);
        uwall[1] -= moment;
        break;
      case CERF:
        fD2Q9PCEZouHe(p0, &force[0],
                      &lbf[spos],        &lbf[spos+7*qdim], &lbf[spos+8*qdim],
                      &lbf[spos+1*qdim], &lbf[spos+2*qdim], &lbf[spos+3*qdim],
                      &lbf[spos+4*qdim], &lbf[spos+5*qdim], &lbf[spos+6*qdim], moment);
        uwall[0] += moment;
        break;
      case CCTRF:
        fD2Q9VCCSimpleZouHe(p0, uwall[0], uwall[1], &force[0],
                            &lbf[spos], &lbf[spos+1*qdim], &lbf[spos+2*qdim],
                            &lbf[spos+3*qdim], &lbf[spos+4*qdim], &lbf[spos+5*qdim],
                            &lbf[spos+6*qdim], &lbf[spos+7*qdim], &lbf[spos+8*qdim]);
        break;
      case CCTLF:
        fD2Q9VCCSimpleZouHe(p0, uwall[1], -uwall[0], &force[0],
                            &lbf[spos], &lbf[spos+3*qdim], &lbf[spos+4*qdim],
                            &lbf[spos+5*qdim], &lbf[spos+6*qdim], &lbf[spos+7*qdim],
                            &lbf[spos+8*qdim], &lbf[spos+1*qdim], &lbf[spos+2*qdim]);
        break;
      case CCDLF:
        fD2Q9VCCSimpleZouHe(p0, -uwall[0], -uwall[1], &force[0],
                            &lbf[spos], &lbf[spos+5*qdim], &lbf[spos+6*qdim],
                            &lbf[spos+7*qdim], &lbf[spos+8*qdim], &lbf[spos+1*qdim],
                            &lbf[spos+2*qdim], &lbf[spos+3*qdim], &lbf[spos+4*qdim]);
        break;
      case CCDRF:
        fD2Q9VCCSimpleZouHe(p0, -uwall[1], uwall[0], &force[0],
                            &lbf[spos], &lbf[spos+7*qdim], &lbf[spos+8*qdim],
                            &lbf[spos+1*qdim], &lbf[spos+2*qdim], &lbf[spos+3*qdim],
                            &lbf[spos+4*qdim], &lbf[spos+5*qdim], &lbf[spos+6*qdim]);
        break;
    }
  }
  return 0;
}


int fD2Q9CCEZouHe(double *p, double v0, double v1, double *f0, double *f1, double *f2,
                  double *f3, double *f4, double *f5, double *f6, double *f7, double *f8)
{

  // produce fixed concentration boundary for concave edge (CCETF)

  double c1=1.0/3.0,c2=1.0/6.0;
  for(int i=0; i<lbsy.nc; i++) {
    f1[i]=f5[i]-c2*p[i]*(v0-v1);
    f7[i]=f3[i]+c2*p[i]*(v0+v1);
    f8[i]=p[i]*(1-c1*v1)-f0[i]-f2[i]-f4[i]-f6[i]-2.0*(f3[i]+f5[i]);
  }
  return 0;
}

int fD2Q9CCCZouHe(double *p, double v0, double v1, double *f0, double *f1, double *f2,
                  double *f3, double *f4, double *f5, double *f6, double *f7, double *f8)
{

  // produce fixed concentration boundary for concave corner (CCCTFR)

  double c1=1.0/3.0,c2=1.0/6.0,c3=2.0/3.0;
  for(int i=0; i<lbsy.nc; i++) {
    f1[i]=0.5*(p[i]-f0[i])-f2[i]-f3[i]-f4[i]-p[i]*(0.5*v0+c1*v1);
    f5[i]=0.5*(p[i]-f0[i])-f2[i]-f3[i]-f4[i]-p[i]*(c1*v0+0.5*v1);
    f6[i]=f2[i]+c3*p[i]*v0;
    f7[i]=f3[i]+c2*p[i]*(v0+v1);
    f8[i]=f4[i]+c3*p[i]*v1;
  }
  return 0;
}


int fD2Q9PCZouHe(long tpos, int prop, double *p0, double *uwall)
{
  long spos = tpos * lbsitelength + lbsy.nf;
  int qdim=lbsy.nf+lbsy.nc+lbsy.nt;
    
  switch (prop) {
    case CETF:
      fD2Q9CCEZouHe(p0, uwall[0], uwall[1], &lbf[spos], &lbf[spos+1*qdim],
                    &lbf[spos+2*qdim], &lbf[spos+3*qdim], &lbf[spos+4*qdim], &lbf[spos+5*qdim],
                    &lbf[spos+6*qdim], &lbf[spos+7*qdim], &lbf[spos+8*qdim]);
      break;
    case CELF:
      fD2Q9CCEZouHe(p0, uwall[1], -uwall[0], &lbf[spos], &lbf[spos+3*qdim],
                    &lbf[spos+4*qdim], &lbf[spos+5*qdim], &lbf[spos+6*qdim], &lbf[spos+7*qdim],
                    &lbf[spos+8*qdim], &lbf[spos+1*qdim], &lbf[spos+2*qdim]);
      break;
    case CEDF:
      fD2Q9CCEZouHe(p0, -uwall[0], -uwall[1], &lbf[spos], &lbf[spos+5*qdim],
                    &lbf[spos+6*qdim], &lbf[spos+7*qdim], &lbf[spos+8*qdim], &lbf[spos+1*qdim],
                    &lbf[spos+2*qdim], &lbf[spos+3*qdim], &lbf[spos+4*qdim]);
      break;
    case CERF:
      fD2Q9CCEZouHe(p0, -uwall[1], uwall[0], &lbf[spos], &lbf[spos+7*qdim],
                    &lbf[spos+8*qdim], &lbf[spos+1*qdim], &lbf[spos+2*qdim], &lbf[spos+3*qdim],
                    &lbf[spos+4*qdim], &lbf[spos+5*qdim], &lbf[spos+6*qdim]);
      break;
    case CCTRF:
      fD2Q9CCCZouHe(p0, uwall[0], uwall[1],
                    &lbf[spos], &lbf[spos+1*qdim], &lbf[spos+2*qdim],
                    &lbf[spos+3*qdim], &lbf[spos+4*qdim], &lbf[spos+5*qdim],
                    &lbf[spos+6*qdim], &lbf[spos+7*qdim], &lbf[spos+8*qdim]);
      break;
    case CCTLF:
      fD2Q9CCCZouHe(p0, uwall[1], -uwall[0],
                    &lbf[spos], &lbf[spos+3*qdim], &lbf[spos+4*qdim],
                    &lbf[spos+5*qdim], &lbf[spos+6*qdim], &lbf[spos+7*qdim],
                    &lbf[spos+8*qdim], &lbf[spos+1*qdim], &lbf[spos+2*qdim]);
      break;
    case CCDLF:
      fD2Q9CCCZouHe(p0, -uwall[0], -uwall[1],
                    &lbf[spos], &lbf[spos+5*qdim], &lbf[spos+6*qdim],
                    &lbf[spos+7*qdim], &lbf[spos+8*qdim], &lbf[spos+1*qdim],
                    &lbf[spos+2*qdim], &lbf[spos+3*qdim], &lbf[spos+4*qdim]);
      break;
    case CCDRF:
      fD2Q9CCCZouHe(p0, -uwall[1], uwall[0],
                    &lbf[spos], &lbf[spos+7*qdim], &lbf[spos+8*qdim],
                    &lbf[spos+1*qdim], &lbf[spos+2*qdim], &lbf[spos+3*qdim],
                    &lbf[spos+4*qdim], &lbf[spos+5*qdim], &lbf[spos+6*qdim]);
      break;
  }
  return 0;
}


int fD2Q9TCEZouHe(double p, double v0, double v1, double *f0, double *f1, double *f2,
                  double *f3, double *f4, double *f5, double *f6, double *f7, double *f8)
{

  // produce fixed temperature for concave edge (TCETF)

  double c1=1.0/3.0,c2=1.0/6.0;
  f1[0]=f5[0]-c2*p*(v0-v1);
  f7[0]=f3[0]+c2*p*(v0+v1);
  f8[0]=p*(1-c1*v1)-f0[0]-f2[0]-f4[0]-f6[0]-2.0*(f3[0]+f5[0]);
  return 0;
}

int fD2Q9TCCZouHe(double p, double v0, double v1, double *f0, double *f1, double *f2,
                  double *f3, double *f4, double *f5, double *f6, double *f7, double *f8)
{

  // produce fixed temperature for concave corner (TCCTFR)

  double c1=1.0/3.0,c2=1.0/6.0,c3=2.0/3.0;
  f1[0]=0.5*(p-f0[0])-f2[0]-f3[0]-f4[0]-p*(0.5*v0+c1*v1);
  f5[0]=0.5*(p-f0[0])-f2[0]-f3[0]-f4[0]-p*(c1*v0+0.5*v1);
  f6[0]=f2[0]+c3*p*v0;
  f7[0]=f3[0]+c2*p*(v0+v1);
  f8[0]=f4[0]+c3*p*v1;
  return 0;
}


int fD2Q9PTZouHe(long tpos, int prop, double p0, double *uwall)
{
  long spos = tpos * lbsitelength + lbsy.nf + lbsy.nc;
  int qdim=lbsy.nf+lbsy.nc+lbsy.nt;

  switch (prop) {
    case CETF:
      fD2Q9TCEZouHe(p0, uwall[0], uwall[1], &lbf[spos], &lbf[spos+1*qdim],
                    &lbf[spos+2*qdim], &lbf[spos+3*qdim], &lbf[spos+4*qdim], &lbf[spos+5*qdim],
                    &lbf[spos+6*qdim], &lbf[spos+7*qdim], &lbf[spos+8*qdim]);
      break;
    case CELF:
      fD2Q9TCEZouHe(p0, uwall[1], -uwall[0], &lbf[spos], &lbf[spos+3*qdim],
                    &lbf[spos+4*qdim], &lbf[spos+5*qdim], &lbf[spos+6*qdim], &lbf[spos+7*qdim],
                    &lbf[spos+8*qdim], &lbf[spos+1*qdim], &lbf[spos+2*qdim]);
      break;
    case CEDF:
      fD2Q9TCEZouHe(p0, -uwall[0], -uwall[1], &lbf[spos], &lbf[spos+5*qdim],
                    &lbf[spos+6*qdim], &lbf[spos+7*qdim], &lbf[spos+8*qdim], &lbf[spos+1*qdim],
                    &lbf[spos+2*qdim], &lbf[spos+3*qdim], &lbf[spos+4*qdim]);
      break;
    case CERF:
      fD2Q9TCEZouHe(p0, -uwall[1], uwall[0], &lbf[spos], &lbf[spos+7*qdim],
                    &lbf[spos+8*qdim], &lbf[spos+1*qdim], &lbf[spos+2*qdim], &lbf[spos+3*qdim],
                    &lbf[spos+4*qdim], &lbf[spos+5*qdim], &lbf[spos+6*qdim]);
      break;
    case CCTRF:
      fD2Q9TCCZouHe(p0, uwall[0], uwall[1],
                    &lbf[spos], &lbf[spos+1*qdim], &lbf[spos+2*qdim],
                    &lbf[spos+3*qdim], &lbf[spos+4*qdim], &lbf[spos+5*qdim],
                    &lbf[spos+6*qdim], &lbf[spos+7*qdim], &lbf[spos+8*qdim]);
      break;
    case CCTLF:
      fD2Q9TCCZouHe(p0, uwall[1], -uwall[0],
                    &lbf[spos], &lbf[spos+3*qdim], &lbf[spos+4*qdim],
                    &lbf[spos+5*qdim], &lbf[spos+6*qdim], &lbf[spos+7*qdim],
                    &lbf[spos+8*qdim], &lbf[spos+1*qdim], &lbf[spos+2*qdim]);
      break;
    case CCDLF:
      fD2Q9TCCZouHe(p0, -uwall[0], -uwall[1],
                    &lbf[spos], &lbf[spos+5*qdim], &lbf[spos+6*qdim],
                    &lbf[spos+7*qdim], &lbf[spos+8*qdim], &lbf[spos+1*qdim],
                    &lbf[spos+2*qdim], &lbf[spos+3*qdim], &lbf[spos+4*qdim]);
      break;
    case CCDRF:
      fD2Q9TCCZouHe(p0, -uwall[1], uwall[0],
                    &lbf[spos], &lbf[spos+7*qdim], &lbf[spos+8*qdim],
                    &lbf[spos+1*qdim], &lbf[spos+2*qdim], &lbf[spos+3*qdim],
                    &lbf[spos+4*qdim], &lbf[spos+5*qdim], &lbf[spos+6*qdim]);
      break;
  }
  return 0;
}


// D3Q15

int fD3Q15VPSZouHe(double v0, double v1, double v2, double *force,
                   double *f0, double *f1, double *f2, double *f3, double *f4,
                   double *f5, double *f6, double *f7, double *f8, double *f9,
                   double *f10, double *f11, double *f12, double *f13, double *f14)
{

  // produce fixed velocity at planar surface boundary for compressible/incompressible fluids:
  // expressed for bottom wall (VPST)
  
  double rho, n1, n2;
  double c1=2.0/3.0,c2=1.0/12.0,c3=1.0/6.0;

  if(!incompress) {
    for(int i=0; i<lbsy.nf; i++) {
      rho=(f0[i]+f1[i]+f3[i]+f8[i]+f10[i]+2.0*(f2[i]+f4[i]+f5[i]+f13[i]+f14[i])-0.5*force[3*i+1])/(1.0-v1);
      n1=0.25* (f8[i]-f1[i])-c3*rho*v0+0.125*force[3*i  ];
      n2=0.25*(f10[i]-f3[i])-c3*rho*v2+0.125*force[3*i+2];
      f6[i]=f13[i]-c2*rho*(v0-v1+v2)+n1+n2;
      f7[i]=f14[i]-c2*rho*(v0-v1-v2)+n1-n2;
      f9[i]=f2[i]+c1*rho*v1;
      f11[i]=f4[i]+c2*rho*(v0+v1+v2)-n1-n2;
      f12[i]=f5[i]+c2*rho*(v0+v1-v2)-n1+n2;
    }
  }
  else {
    for(int i=0; i<lbsy.nf; i++) {
//     double rho=f0+f1+f3+f8+f10+2.0*(f2+f4+f5+f13+f14)+rho0*v1-0.5*force[1];
      double rho0 = lbincp[i];
      n1=0.25* (f8[i]-f1[i])-c3*rho0*v0+0.125*force[3*i  ];
      n2=0.25*(f10[i]-f3[i])-c3*rho0*v2+0.125*force[3*i+2];
      f6[i]=f13[i]-c2*rho0*(v0-v1+v2)+n1+n2;
      f7[i]=f14[i]-c2*rho0*(v0-v1-v2)+n1-n2;
      f9[i]=f2[i]+c1*rho0*v1;
      f11[i]=f4[i]+c2*rho0*(v0+v1+v2)-n1-n2;
      f12[i]=f5[i]+c2*rho0*(v0+v1-v2)-n1+n2;
    }
  }
  return 0;
}

int fD3Q15VCEZouHe(double *p, double v0, double v1, double v2, double *force,
                   double *f0, double *f1, double *f2, double *f3, double *f4,
                   double *f5, double *f6, double *f7, double *f8, double *f9,
                   double *f10, double *f11, double *f12, double *f13, double *f14)
{

  // produce fixed velocity at concave edge boundary for compressible/incompressible fluids:
  // expressed for bottom left edge (VCETR)
  double q0, qxy, nz;
  double c1=2.0/3.0,c2=1.0/12.0,c3=1.0/24.0,c4=5.0/24.0,c5=1.0/6.0,c6=5.0/36.0;

  if(!incompress) {
    for(int i=0; i<lbsy.nf; i++) {
      q0 = 0.25*(p[i]-f0[i]-f3[i]-f10[i])-0.5*(f1[i]+f2[i]+f4[i]+f5[i])-c4*p[i]*(v0+v1);
      qxy = c3*p[i]*(v0-v1)+0.0625*(force[3*i+1]-force[3*i]);
      nz = c5*(f10[i]-f3[i])-c6*p[i]*v2+c2*force[3*i+2];
      f6[i]=q0-qxy+nz;
      f7[i]=q0-qxy-nz;
      f8[i]=f1[i]+c1*p[i]*v0;
      f9[i]=f2[i]+c1*p[i]*v1;
      f11[i]=f4[i]+c2*p[i]*(v0+v1+v2)-nz;
      f12[i]=f5[i]+c2*p[i]*(v0+v1-v2)+nz;
      f13[i]=q0+qxy-nz;
      f14[i]=q0+qxy+nz;
    }
  }
  else {
    for(int i=0; i<lbsy.nf; i++) {
      double rho0 = lbincp[i];
      q0 = 0.25*(p[i]-f0[i]-f3[i]-f10[i])-0.5*(f1[i]+f2[i]+f4[i]+f5[i])-c4*rho0*(v0+v1);
      qxy = c3*rho0*(v0-v1)+0.0625*(force[3*i+1]-force[3*i]);
      nz = c5*(f10[i]-f3[i])-c6*rho0*v2+c2*force[3*i+2];
      f6[i]=q0-qxy+nz;
      f7[i]=q0-qxy-nz;
      f8[i]=f1[i]+c1*rho0*v0;
      f9[i]=f2[i]+c1*rho0*v1;
      f11[i]=f4[i]+c2*rho0*(v0+v1+v2)-nz;
      f12[i]=f5[i]+c2*rho0*(v0+v1-v2)+nz;
      f13[i]=q0+qxy-nz;
      f14[i]=q0+qxy+nz;
    }
  }
  return 0;
}

int fD3Q15VCCZouHe(double *p, double v0, double v1, double v2, double *force,
                   double *f0, double *f1, double *f2, double *f3, double *f4,
                   double *f5, double *f6, double *f7, double *f8, double *f9,
                   double *f10, double *f11, double *f12, double *f13, double *f14)
{

  // produce fixed velocity at concave corner boundary for compressible/incompressible fluids:
  // expressed for bottom left back corner (VCCTRF)
  double q0, qx, qy, qz;
  double c1=2.0/3.0,c2=1.0/12.0,c3=1.0/24.0,c5=1.0/6.0,c7=1.0/3.0,c8=1.0/48.0;

  if(!incompress) {
    for(int i=0; i<lbsy.nf; i++) {
      q0 = c5*(p[i]-f0[i])-c7*(f1[i]+f2[i]+f4[i]+f5[i])-0.125*p[i]*(v0+v1+v2)+c8*(force[3*i]+force[3*i+1]+force[3*i+2]);
      qx = c3*p[i]*v0-0.0625*force[3*i  ];
      qy = c3*p[i]*v1-0.0625*force[3*i+1];
      qz = c3*p[i]*v2-0.0625*force[3*i+2];
      f5[i]=q0-qx-qy+qz;
      f6[i]=q0-qx+qy-qz;
      f7[i]=q0-qx+qy+qz;
      f8[i]=f1[i]+c1*p[i]*v0;
      f9[i]=f2[i]+c1*p[i]*v1;
      f10[i]=f3[i]+c1*p[i]*v2;
      f11[i]=f4[i]+c2*p[i]*(v0+v1+v2)-0.125*(force[3*i]+force[3*i+1]+force[3*i+2]);
      f12[i]=q0+qx+qy-qz;
      f13[i]=q0+qx-qy+qz;
      f14[i]=q0+qx-qy-qz;
    }
  }
  else {
    for(int i=0; i<lbsy.nf; i++) {
      double rho0 = lbincp[i];
      q0 = c5*(p[i]-f0[i])-c7*(f1[i]+f2[i]+f4[i]+f5[i])-0.125*rho0*(v0+v1+v2)+c8*(force[3*i]+force[3*i+1]+force[3*i+2]);
      qx = c3*rho0*v0-0.0625*force[3*i  ];
      qy = c3*rho0*v1-0.0625*force[3*i+1];
      qz = c3*rho0*v2-0.0625*force[3*i+2];
      f5[i]=q0-qx-qy+qz;
      f6[i]=q0-qx+qy-qz;
      f7[i]=q0-qx+qy+qz;
      f8[i]=f1[i]+c1*rho0*v0;
      f9[i]=f2[i]+c1*rho0*v1;
      f10[i]=f3[i]+c1*rho0*v2;
      f11[i]=f4[i]+c2*rho0*(v0+v1+v2)-0.125*(force[3*i]+force[3*i+1]+force[3*i+2]);
      f12[i]=q0+qx+qy-qz;
      f13[i]=q0+qx-qy+qz;
      f14[i]=q0+qx-qy-qz;
    }
  }
  return 0;
}

int fD3Q15VPSSimpleZouHe(double v0, double v1, double v2, double *force, double *f0, double *f1, double *f2,
                         double *f3, double *f4, double *f5, double *f6, double *f7, double *f8,
                         double *f9, double *f10, double *f11, double *f12, double *f13, double *f14)
{

  // produce fixed velocity at planar surface boundary for compressible/incompressible fluids:
  // expressed for bottom wall (VPST)
  
  double rho;
  double c1=2.0/3.0,c2=1.0/12.0;
    
  if(!incompress) {
    for(int i=0; i<lbsy.nf; i++) {
      rho=(f0[i]+f1[i]+f3[i]+f8[i]+f10[i]+2.0*(f2[i]+f4[i]+f5[i]+f13[i]+f14[i])-0.5*force[3*i+1])/(1.0-v1);
      f6[i]=f13[i]-c2*rho*(v0-v1+v2);
      f7[i]=f14[i]-c2*rho*(v0-v1-v2);
      f9[i]=f2[i]+c1*rho*v1;
      f11[i]=f4[i]+c2*rho*(v0+v1+v2);
      f12[i]=f5[i]+c2*rho*(v0+v1-v2);
    }
  }
  else {
    for(int i=0; i<lbsy.nf; i++) {
//     double rho=f0+f1+f3+f8+f10+2.0*(f2+f4+f5+f13+f14)+rho0*v1-0.5*force;
      double rho0 = lbincp[i];
      f6[i]=f13[i]-c2*rho0*(v0-v1+v2);
      f7[i]=f14[i]-c2*rho0*(v0-v1-v2);
      f9[i]=f2[i]-c1*rho0*v1;
      f11[i]=f4[i]+c2*rho0*(v0+v1+v2);
      f12[i]=f5[i]+c2*rho0*(v0+v1-v2);
    }
  }
  return 0;
}

int fD3Q15VCESimpleZouHe(double *p, double v0, double v1, double v2, double *force,
                         double *f0, double *f1, double *f2, double *f3, double *f4,
                         double *f5, double *f6, double *f7, double *f8, double *f9,
                         double *f10, double *f11, double *f12, double *f13, double *f14)
{

  // produce fixed velocity at concave edge boundary for compressible/incompressible fluids:
  // expressed for bottom left edge (VCETR)
  double q0, qxy, qz;
  double c1=2.0/3.0,c2=1.0/12.0,c3=1.0/24.0,c4=5.0/24.0;

  if(!incompress) {
    for(int i=0; i<lbsy.nf; i++) {
      q0 = 0.25*(p[i]-f0[i]-f3[i]-f10[i])-0.5*(f1[i]+f2[i]+f4[i]+f5[i])-c4*p[i]*(v0+v1);
      qxy = c3*p[i]*(v0-v1)+0.0625*(force[3*i+1]-force[3*i]);
      qz = 0.25*(f10[i]-f3[i])-c4*p[i]*v2-0.125*force[3*i+2];
      f6[i]=q0-qxy-qz;
      f7[i]=q0-qxy+qz;
      f8[i]=f1[i]+c1*p[i]*v0;
      f9[i]=f2[i]+c1*p[i]*v1;
      f11[i]=f4[i]+c2*p[i]*(v0+v1+v2);
      f12[i]=f5[i]+c2*p[i]*(v0+v1-v2);
      f13[i]=q0+qxy+qz;
      f14[i]=q0+qxy-qz;
    }
  }
  else {
    for(int i=0; i<lbsy.nf; i++) {
      double rho0 = lbincp[i];
      q0 = 0.25*(p[i]-f0[i]-f3[i]-f10[i])-0.5*(f1[i]+f2[i]+f4[i]+f5[i])-c4*rho0*(v0+v1);
      qxy = c3*rho0*(v0-v1)+0.0625*(force[3*i+1]-force[3*i]);
      qz = 0.25*(f10[i]-f3[i])-c4*rho0*v2-0.125*force[3*i+2];
      f6[i]=q0-qxy-qz;
      f7[i]=q0-qxy+qz;
      f8[i]=f1[i]+c1*rho0*v0;
      f9[i]=f2[i]+c1*rho0*v1;
      f11[i]=f4[i]+c2*rho0*(v0+v1+v2);
      f12[i]=f5[i]+c2*rho0*(v0+v1-v2);
      f13[i]=q0+qxy+qz;
      f14[i]=q0+qxy-qz;
    }
  }
  return 0;
}

int fD3Q15VCCSimpleZouHe(double *p, double v0, double v1, double v2, double *force,
                         double *f0, double *f1, double *f2, double *f3, double *f4,
                         double *f5, double *f6, double *f7, double *f8, double *f9,
                         double *f10, double *f11, double *f12, double *f13, double *f14)
{

  // produce fixed velocity at concave corner boundary for compressible/incompressible fluids:
  // expressed for bottom left back corner (VCCTRF)
  double q0, qx, qy, qz;
  double c1=2.0/3.0,c2=1.0/12.0,c3=1.0/24.0,c5=1.0/6.0,c7=1.0/3.0,c8=1.0/48.0;

  if(!incompress) {
    for(int i=0; i<lbsy.nf; i++) {
      q0 = c5*(p[i]-f0[i])-c7*(f1[i]+f2[i]+f4[i]+f5[i])-0.125*p[i]*(v0+v1+v2)+c8*(force[3*i]+force[3*i+1]+force[3*i+2]);
      qx = c3*p[i]*v0-0.125*force[3*i  ]-0.0625*(force[3*i+1]+force[3*i+2]);
      qy = c3*p[i]*v1-0.125*force[3*i+1]-0.0625*(force[3*i  ]+force[3*i+2]);
      qz = c3*p[i]*v2-0.125*force[3*i+2]-0.0625*(force[3*i  ]+force[3*i+1]);
      f5[i]=q0-qx-qy+qz;
      f6[i]=q0-qx+qy-qz;
      f7[i]=q0-qx+qy+qz;
      f8[i]=f1[i]+c1*p[i]*v0;
      f9[i]=f2[i]+c1*p[i]*v1;
      f10[i]=f3[i]+c1*p[i]*v2;
      f11[i]=f4[i]+c2*p[i]*(v0+v1+v2);
      f12[i]=q0+qx+qy-qz;
      f13[i]=q0+qx-qy+qz;
      f14[i]=q0+qx-qy-qz;
    }
  }
  else {
    for(int i=0; i<lbsy.nf; i++) {
      double rho0 = lbincp[i];
      q0 = c5*(p[i]-f0[i])-c7*(f1[i]+f2[i]+f4[i]+f5[i])-0.125*rho0*(v0+v1+v2)+c8*(force[3*i]+force[3*i+1]+force[3*i+2]);
      qx = c3*rho0*v0-0.125*force[3*i  ]-0.0625*(force[3*i+1]+force[3*i+2]);
      qy = c3*rho0*v1-0.125*force[3*i+1]-0.0625*(force[3*i  ]+force[3*i+2]);
      qz = c3*rho0*v2-0.125*force[3*i+2]-0.0625*(force[3*i  ]+force[3*i+1]);
      f5[i]=q0-qx-qy+qz;
      f6[i]=q0-qx+qy-qz;
      f7[i]=q0-qx+qy+qz;
      f8[i]=f1[i]+c1*rho0*v0;
      f9[i]=f2[i]+c1*rho0*v1;
      f10[i]=f3[i]+c1*rho0*v2;
      f11[i]=f4[i]+c2*rho0*(v0+v1+v2);
      f12[i]=q0+qx+qy-qz;
      f13[i]=q0+qx-qy+qz;
      f14[i]=q0+qx-qy-qz;
    }
  }
  return 0;
}

int fD3Q15VFZouHe(long tpos, long rpos, int prop, double *uwall, double dx, double dy, double dz)
{
  long spos=tpos * lbsitelength;
  int qdim = lbsy.nf+lbsy.nc+lbsy.nt;
  double force[3*lbsy.nf], rho[lbsy.nf];
  double drdx,drdy,drdz,dpdx,dpdy,dpdz;

  // sort out forces

  fD3Q15BoundaryForceVelocity(force, tpos, rpos, dx, dy, dz, uwall, prop);

  // apply boundary condition

  if(prop>26) {
    fGetAllMassSite(rho, &lbf[rpos*lbsitelength]);
    if(interact==20) {
      drdx = lbft[4*lbsy.nf*rpos  ];
      drdy = lbft[4*lbsy.nf*rpos+1];
      drdz = lbft[4*lbsy.nf*rpos+2];
      rho[0] += (dx*drdx+dy*drdy+dz*drdz);
      if(lbsy.nf>1) {
        dpdx = lbft[4*lbsy.nf*rpos+4];
        dpdy = lbft[4*lbsy.nf*rpos+5];
        dpdz = lbft[4*lbsy.nf*rpos+6];
        rho[1] += (dx*dpdx+dy*dpdy+dz*dpdz);
      }
    }
  }

  switch (prop) {
    case PST:
      fD3Q15VPSZouHe(uwall[0], uwall[1], uwall[2], &force[0], &lbf[spos], &lbf[spos+1*qdim],
                     &lbf[spos+2*qdim], &lbf[spos+3*qdim], &lbf[spos+4*qdim], &lbf[spos+5*qdim],
                     &lbf[spos+6*qdim], &lbf[spos+7*qdim], &lbf[spos+8*qdim], &lbf[spos+9*qdim],
                     &lbf[spos+10*qdim], &lbf[spos+11*qdim], &lbf[spos+12*qdim], &lbf[spos+13*qdim],
                     &lbf[spos+14*qdim]);
      break;
    case PSD:
      fD3Q15VPSZouHe(-uwall[0], -uwall[1], -uwall[2], &force[0], &lbf[spos], &lbf[spos+8*qdim],
                     &lbf[spos+9*qdim], &lbf[spos+10*qdim], &lbf[spos+11*qdim], &lbf[spos+12*qdim],
                     &lbf[spos+13*qdim], &lbf[spos+14*qdim], &lbf[spos+1*qdim], &lbf[spos+2*qdim],
                     &lbf[spos+3*qdim], &lbf[spos+4*qdim], &lbf[spos+5*qdim], &lbf[spos+6*qdim],
                     &lbf[spos+7*qdim]);
      break;
    case PSL:
      fD3Q15VPSZouHe(-uwall[2], -uwall[0], -uwall[1], &force[0], &lbf[spos], &lbf[spos+10*qdim],
                     &lbf[spos+8*qdim], &lbf[spos+9*qdim], &lbf[spos+11*qdim], &lbf[spos+13*qdim],
                     &lbf[spos+7*qdim], &lbf[spos+5*qdim], &lbf[spos+3*qdim], &lbf[spos+1*qdim],
                     &lbf[spos+2*qdim], &lbf[spos+4*qdim], &lbf[spos+6*qdim], &lbf[spos+14*qdim],
                     &lbf[spos+12*qdim]);
      break;
    case PSR:
      fD3Q15VPSZouHe(uwall[2], uwall[0], uwall[1], &force[0], &lbf[spos], &lbf[spos+3*qdim],
                     &lbf[spos+1*qdim], &lbf[spos+2*qdim], &lbf[spos+4*qdim], &lbf[spos+6*qdim],
                     &lbf[spos+14*qdim], &lbf[spos+12*qdim], &lbf[spos+10*qdim], &lbf[spos+8*qdim],
                     &lbf[spos+9*qdim], &lbf[spos+11*qdim], &lbf[spos+13*qdim], &lbf[spos+7*qdim],
                     &lbf[spos+5*qdim]);
      break;
    case PSF:
      fD3Q15VPSZouHe(-uwall[1], -uwall[2], -uwall[0], &force[0], &lbf[spos], &lbf[spos+9*qdim],
                     &lbf[spos+10*qdim], &lbf[spos+8*qdim], &lbf[spos+11*qdim], &lbf[spos+7*qdim],
                     &lbf[spos+12*qdim], &lbf[spos+6*qdim], &lbf[spos+2*qdim], &lbf[spos+3*qdim],
                     &lbf[spos+1*qdim], &lbf[spos+4*qdim], &lbf[spos+14*qdim], &lbf[spos+5*qdim],
                     &lbf[spos+13*qdim]);
      break;
    case PSB:
      fD3Q15VPSZouHe(uwall[1], uwall[2], uwall[0], &force[0], &lbf[spos], &lbf[spos+2*qdim],
                     &lbf[spos+3*qdim], &lbf[spos+1*qdim], &lbf[spos+4*qdim], &lbf[spos+14*qdim],
                     &lbf[spos+5*qdim], &lbf[spos+13*qdim], &lbf[spos+9*qdim], &lbf[spos+10*qdim],
                     &lbf[spos+8*qdim], &lbf[spos+11*qdim], &lbf[spos+7*qdim], &lbf[spos+12*qdim],
                     &lbf[spos+6*qdim]);
      break;
    case CCTRB:
      fD3Q15VCCZouHe(rho, uwall[0], uwall[1], -uwall[2], &force[0], &lbf[spos], &lbf[spos+1*qdim],
                     &lbf[spos+2*qdim], &lbf[spos+10*qdim], &lbf[spos+5*qdim], &lbf[spos+4*qdim],
                     &lbf[spos+7*qdim], &lbf[spos+6*qdim], &lbf[spos+8*qdim], &lbf[spos+9*qdim],
                     &lbf[spos+3*qdim], &lbf[spos+12*qdim], &lbf[spos+11*qdim], &lbf[spos+14*qdim],
                     &lbf[spos+13*qdim]);
      break;
    case CCTLB:
      fD3Q15VCCZouHe(rho, -uwall[0], uwall[1], -uwall[2], &force[0], &lbf[spos], &lbf[spos+8*qdim],
                     &lbf[spos+2*qdim], &lbf[spos+10*qdim], &lbf[spos+13*qdim], &lbf[spos+14*qdim],
                     &lbf[spos+11*qdim], &lbf[spos+12*qdim], &lbf[spos+1*qdim], &lbf[spos+9*qdim],
                     &lbf[spos+3*qdim], &lbf[spos+6*qdim], &lbf[spos+7*qdim], &lbf[spos+4*qdim],
                     &lbf[spos+5*qdim]);
      break;
    case CCDLB:
      fD3Q15VCCZouHe(rho, -uwall[0], -uwall[1], -uwall[2], &force[0], &lbf[spos], &lbf[spos+8*qdim],
                     &lbf[spos+9*qdim], &lbf[spos+10*qdim], &lbf[spos+11*qdim], &lbf[spos+12*qdim],
                     &lbf[spos+13*qdim], &lbf[spos+14*qdim], &lbf[spos+1*qdim], &lbf[spos+2*qdim],
                     &lbf[spos+3*qdim], &lbf[spos+4*qdim], &lbf[spos+5*qdim], &lbf[spos+6*qdim],
                     &lbf[spos+7*qdim]);
      break;
    case CCDRB:
      fD3Q15VCCZouHe(rho, uwall[0], -uwall[1], -uwall[2], &force[0], &lbf[spos], &lbf[spos+1*qdim],
                     &lbf[spos+9*qdim], &lbf[spos+10*qdim], &lbf[spos+7*qdim], &lbf[spos+6*qdim],
                     &lbf[spos+5*qdim], &lbf[spos+4*qdim], &lbf[spos+8*qdim], &lbf[spos+2*qdim],
                     &lbf[spos+3*qdim], &lbf[spos+14*qdim], &lbf[spos+13*qdim], &lbf[spos+12*qdim],
                     &lbf[spos+11*qdim]);
      break;
    case CCTRF:
      fD3Q15VCCZouHe(rho, uwall[0], uwall[1], uwall[2], &force[0], &lbf[spos], &lbf[spos+1*qdim],
                     &lbf[spos+2*qdim], &lbf[spos+3*qdim], &lbf[spos+4*qdim], &lbf[spos+5*qdim],
                     &lbf[spos+6*qdim], &lbf[spos+7*qdim], &lbf[spos+8*qdim], &lbf[spos+9*qdim],
                     &lbf[spos+10*qdim], &lbf[spos+11*qdim], &lbf[spos+12*qdim], &lbf[spos+13*qdim],
                     &lbf[spos+14*qdim]);
      break;
    case CCTLF:
      fD3Q15VCCZouHe(rho, -uwall[0], uwall[1], uwall[2], &force[0], &lbf[spos], &lbf[spos+8*qdim],
                     &lbf[spos+2*qdim], &lbf[spos+3*qdim], &lbf[spos+14*qdim], &lbf[spos+13*qdim],
                     &lbf[spos+12*qdim], &lbf[spos+11*qdim], &lbf[spos+1*qdim], &lbf[spos+9*qdim],
                     &lbf[spos+10*qdim], &lbf[spos+7*qdim], &lbf[spos+6*qdim], &lbf[spos+5*qdim],
                     &lbf[spos+4*qdim]);
      break;
    case CCDLF:
      fD3Q15VCCZouHe(rho, -uwall[0], -uwall[1], uwall[2], &force[0], &lbf[spos], &lbf[spos+8*qdim],
                     &lbf[spos+9*qdim], &lbf[spos+3*qdim], &lbf[spos+12*qdim], &lbf[spos+11*qdim],
                     &lbf[spos+14*qdim], &lbf[spos+13*qdim], &lbf[spos+1*qdim], &lbf[spos+2*qdim],
                     &lbf[spos+10*qdim], &lbf[spos+5*qdim], &lbf[spos+4*qdim], &lbf[spos+7*qdim],
                     &lbf[spos+6*qdim]);
      break;
    case CCDRF:
      fD3Q15VCCZouHe(rho, uwall[0], -uwall[1], uwall[2], &force[0], &lbf[spos], &lbf[spos+1*qdim],
                     &lbf[spos+9*qdim], &lbf[spos+3*qdim], &lbf[spos+6*qdim], &lbf[spos+7*qdim],
                     &lbf[spos+4*qdim], &lbf[spos+5*qdim], &lbf[spos+8*qdim], &lbf[spos+2*qdim],
                     &lbf[spos+10*qdim], &lbf[spos+13*qdim], &lbf[spos+14*qdim], &lbf[spos+11*qdim],
                     &lbf[spos+12*qdim]);
      break;
    case CETR:
      fD3Q15VCEZouHe(rho, uwall[0], uwall[1], uwall[2], &force[0], &lbf[spos], &lbf[spos+1*qdim],
                     &lbf[spos+2*qdim], &lbf[spos+3*qdim], &lbf[spos+4*qdim], &lbf[spos+5*qdim],
                     &lbf[spos+6*qdim], &lbf[spos+7*qdim], &lbf[spos+8*qdim], &lbf[spos+9*qdim],
                     &lbf[spos+10*qdim], &lbf[spos+11*qdim], &lbf[spos+12*qdim], &lbf[spos+13*qdim],
                     &lbf[spos+14*qdim]);
      break;
    case CETL:
      fD3Q15VCEZouHe(rho, uwall[1], -uwall[0], uwall[2], &force[0], &lbf[spos], &lbf[spos+2*qdim],
                     &lbf[spos+8*qdim], &lbf[spos+3*qdim], &lbf[spos+14*qdim], &lbf[spos+13*qdim],
                     &lbf[spos+4*qdim], &lbf[spos+5*qdim], &lbf[spos+9*qdim], &lbf[spos+1*qdim],
                     &lbf[spos+10*qdim], &lbf[spos+7*qdim], &lbf[spos+6*qdim], &lbf[spos+11*qdim],
                     &lbf[spos+12*qdim]);
      break;
    case CEDL:
      fD3Q15VCEZouHe(rho, -uwall[0], -uwall[1], uwall[2], &force[0], &lbf[spos], &lbf[spos+8*qdim],
                     &lbf[spos+9*qdim], &lbf[spos+3*qdim], &lbf[spos+12*qdim], &lbf[spos+11*qdim],
                     &lbf[spos+14*qdim], &lbf[spos+13*qdim], &lbf[spos+1*qdim], &lbf[spos+2*qdim],
                     &lbf[spos+10*qdim], &lbf[spos+5*qdim], &lbf[spos+4*qdim], &lbf[spos+7*qdim],
                     &lbf[spos+6*qdim]);
      break;
    case CEDR:
      fD3Q15VCEZouHe(rho, -uwall[1], uwall[0], uwall[2], &force[0], &lbf[spos], &lbf[spos+9*qdim],
                     &lbf[spos+1*qdim], &lbf[spos+3*qdim], &lbf[spos+6*qdim], &lbf[spos+7*qdim],
                     &lbf[spos+12*qdim], &lbf[spos+11*qdim], &lbf[spos+2*qdim], &lbf[spos+8*qdim],
                     &lbf[spos+10*qdim], &lbf[spos+13*qdim], &lbf[spos+14*qdim], &lbf[spos+5*qdim],
                     &lbf[spos+4*qdim]);
      break;
    case CETF:
      fD3Q15VCEZouHe(rho, uwall[1], uwall[2], uwall[0], &force[0], &lbf[spos], &lbf[spos+2*qdim],
                     &lbf[spos+3*qdim], &lbf[spos+1*qdim], &lbf[spos+4*qdim], &lbf[spos+14*qdim],
                     &lbf[spos+5*qdim], &lbf[spos+13*qdim], &lbf[spos+9*qdim], &lbf[spos+10*qdim],
                     &lbf[spos+8*qdim], &lbf[spos+11*qdim], &lbf[spos+7*qdim], &lbf[spos+12*qdim],
                     &lbf[spos+6*qdim]);
      break;
    case CELF:
      fD3Q15VCEZouHe(rho, -uwall[0], uwall[2], uwall[1], &force[0], &lbf[spos], &lbf[spos+8*qdim],
                     &lbf[spos+3*qdim], &lbf[spos+2*qdim], &lbf[spos+14*qdim], &lbf[spos+12*qdim],
                     &lbf[spos+13*qdim], &lbf[spos+11*qdim], &lbf[spos+1*qdim], &lbf[spos+10*qdim],
                     &lbf[spos+9*qdim], &lbf[spos+7*qdim], &lbf[spos+5*qdim], &lbf[spos+6*qdim],
                     &lbf[spos+4*qdim]);
      break;
    case CEDF:
      fD3Q15VCEZouHe(rho, -uwall[1], uwall[2], uwall[0], &force[0], &lbf[spos], &lbf[spos+9*qdim],
                     &lbf[spos+3*qdim], &lbf[spos+1*qdim], &lbf[spos+6*qdim], &lbf[spos+12*qdim],
                     &lbf[spos+7*qdim], &lbf[spos+11*qdim], &lbf[spos+2*qdim], &lbf[spos+10*qdim],
                     &lbf[spos+8*qdim], &lbf[spos+13*qdim], &lbf[spos+5*qdim], &lbf[spos+14*qdim],
                     &lbf[spos+4*qdim]);
      break;
    case CERF:
      fD3Q15VCEZouHe(rho, uwall[0], uwall[2], uwall[1], &force[0], &lbf[spos], &lbf[spos+1*qdim],
                     &lbf[spos+3*qdim], &lbf[spos+2*qdim], &lbf[spos+4*qdim], &lbf[spos+6*qdim],
                     &lbf[spos+5*qdim], &lbf[spos+7*qdim], &lbf[spos+8*qdim], &lbf[spos+10*qdim],
                     &lbf[spos+9*qdim], &lbf[spos+11*qdim], &lbf[spos+13*qdim], &lbf[spos+12*qdim],
                     &lbf[spos+14*qdim]);
      break;
    case CETB:
      fD3Q15VCEZouHe(rho, uwall[1], -uwall[2], uwall[0], &force[0], &lbf[spos], &lbf[spos+2*qdim],
                     &lbf[spos+10*qdim], &lbf[spos+1*qdim], &lbf[spos+5*qdim], &lbf[spos+13*qdim],
                     &lbf[spos+4*qdim], &lbf[spos+14*qdim], &lbf[spos+9*qdim], &lbf[spos+3*qdim],
                     &lbf[spos+8*qdim], &lbf[spos+12*qdim], &lbf[spos+6*qdim], &lbf[spos+11*qdim],
                     &lbf[spos+7*qdim]);
      break;
    case CELB:
      fD3Q15VCEZouHe(rho, -uwall[0], -uwall[2], uwall[1], &force[0], &lbf[spos], &lbf[spos+8*qdim],
                     &lbf[spos+10*qdim], &lbf[spos+2*qdim], &lbf[spos+13*qdim], &lbf[spos+11*qdim],
                     &lbf[spos+14*qdim], &lbf[spos+12*qdim], &lbf[spos+1*qdim], &lbf[spos+3*qdim],
                     &lbf[spos+9*qdim], &lbf[spos+6*qdim], &lbf[spos+4*qdim], &lbf[spos+7*qdim],
                     &lbf[spos+5*qdim]);
      break;
    case CEDB:
      fD3Q15VCEZouHe(rho, -uwall[1], -uwall[2], uwall[0], &force[0], &lbf[spos], &lbf[spos+9*qdim],
                     &lbf[spos+10*qdim], &lbf[spos+1*qdim], &lbf[spos+7*qdim], &lbf[spos+11*qdim],
                     &lbf[spos+6*qdim], &lbf[spos+12*qdim], &lbf[spos+2*qdim], &lbf[spos+3*qdim],
                     &lbf[spos+8*qdim], &lbf[spos+14*qdim], &lbf[spos+4*qdim], &lbf[spos+13*qdim],
                     &lbf[spos+5*qdim]);
      break;
    case CERB:
      fD3Q15VCEZouHe(rho, uwall[0], -uwall[2], uwall[1], &force[0], &lbf[spos], &lbf[spos+1*qdim],
                     &lbf[spos+10*qdim], &lbf[spos+2*qdim], &lbf[spos+5*qdim], &lbf[spos+7*qdim],
                     &lbf[spos+4*qdim], &lbf[spos+6*qdim], &lbf[spos+8*qdim], &lbf[spos+3*qdim],
                     &lbf[spos+9*qdim], &lbf[spos+12*qdim], &lbf[spos+14*qdim], &lbf[spos+11*qdim],
                     &lbf[spos+13*qdim]);
      break;
  }

  return 0;
  
}

int fD3Q15VFSimpleZouHe(long tpos, long rpos, int prop, double *uwall, double dx, double dy, double dz)
{
  long spos=tpos * lbsitelength;
  int qdim = lbsy.nf+lbsy.nc+lbsy.nt;
  double force[3*lbsy.nf], rho[lbsy.nf];
  double drdx,drdy,drdz,dpdx,dpdy,dpdz;

  // sort out forces
    
  fD3Q15BoundaryForceVelocity(force, tpos, rpos, dx, dy, dz, uwall, prop);
    
  // apply boundary condition
    
  if(prop>26) {
    fGetAllMassSite(rho, &lbf[rpos*lbsitelength]);
    if(interact==20) {
      drdx = lbft[4*lbsy.nf*rpos  ];
      drdy = lbft[4*lbsy.nf*rpos+1];
      drdz = lbft[4*lbsy.nf*rpos+2];
      rho[0] += (dx*drdx+dy*drdy+dz*drdz);
      if(lbsy.nf>1) {
        dpdx = lbft[4*lbsy.nf*rpos+4];
        dpdy = lbft[4*lbsy.nf*rpos+5];
        dpdz = lbft[4*lbsy.nf*rpos+6];
        rho[1] += (dx*dpdx+dy*dpdy+dz*dpdz);
      }
    }
  }

  switch (prop) {
    case PST:
      fD3Q15VPSSimpleZouHe(uwall[0], uwall[1], uwall[2], &force[0], &lbf[spos], &lbf[spos+1*qdim],
                             &lbf[spos+2*qdim], &lbf[spos+3*qdim], &lbf[spos+4*qdim], &lbf[spos+5*qdim],
                             &lbf[spos+6*qdim], &lbf[spos+7*qdim], &lbf[spos+8*qdim], &lbf[spos+9*qdim],
                             &lbf[spos+10*qdim], &lbf[spos+11*qdim], &lbf[spos+12*qdim], &lbf[spos+13*qdim],
                             &lbf[spos+14*qdim]);
      break;
    case PSD:
      fD3Q15VPSSimpleZouHe(-uwall[0], -uwall[1], -uwall[2], &force[0], &lbf[spos], &lbf[spos+8*qdim],
                           &lbf[spos+9*qdim], &lbf[spos+10*qdim], &lbf[spos+11*qdim], &lbf[spos+12*qdim],
                           &lbf[spos+13*qdim], &lbf[spos+14*qdim], &lbf[spos+1*qdim], &lbf[spos+2*qdim],
                           &lbf[spos+3*qdim], &lbf[spos+4*qdim], &lbf[spos+5*qdim], &lbf[spos+6*qdim],
                           &lbf[spos+7*qdim]);
      break;
    case PSL:
      fD3Q15VPSSimpleZouHe(-uwall[2], -uwall[0], -uwall[1], &force[0], &lbf[spos], &lbf[spos+10*qdim],
                           &lbf[spos+8*qdim], &lbf[spos+9*qdim], &lbf[spos+11*qdim], &lbf[spos+13*qdim],
                           &lbf[spos+7*qdim], &lbf[spos+5*qdim], &lbf[spos+3*qdim], &lbf[spos+1*qdim],
                           &lbf[spos+2*qdim], &lbf[spos+4*qdim], &lbf[spos+6*qdim], &lbf[spos+14*qdim],
                           &lbf[spos+12*qdim]);
      break;
    case PSR:
      fD3Q15VPSSimpleZouHe(uwall[2], uwall[0], uwall[1], &force[0], &lbf[spos], &lbf[spos+3*qdim],
                           &lbf[spos+1*qdim], &lbf[spos+2*qdim], &lbf[spos+4*qdim], &lbf[spos+6*qdim],
                           &lbf[spos+14*qdim], &lbf[spos+12*qdim], &lbf[spos+10*qdim], &lbf[spos+8*qdim],
                           &lbf[spos+9*qdim], &lbf[spos+11*qdim], &lbf[spos+13*qdim], &lbf[spos+7*qdim],
                           &lbf[spos+5*qdim]);
      break;
    case PSF:
      fD3Q15VPSSimpleZouHe(-uwall[1], -uwall[2], -uwall[0], &force[0], &lbf[spos], &lbf[spos+9*qdim],
                           &lbf[spos+10*qdim], &lbf[spos+8*qdim], &lbf[spos+11*qdim], &lbf[spos+7*qdim],
                           &lbf[spos+12*qdim], &lbf[spos+6*qdim], &lbf[spos+2*qdim], &lbf[spos+3*qdim],
                           &lbf[spos+1*qdim], &lbf[spos+4*qdim], &lbf[spos+14*qdim], &lbf[spos+5*qdim],
                           &lbf[spos+13*qdim]);
      break;
    case PSB:
      fD3Q15VPSSimpleZouHe(uwall[1], uwall[2], uwall[0], &force[0], &lbf[spos], &lbf[spos+2*qdim],
                           &lbf[spos+3*qdim], &lbf[spos+1*qdim], &lbf[spos+4*qdim], &lbf[spos+14*qdim],
                           &lbf[spos+5*qdim], &lbf[spos+13*qdim], &lbf[spos+9*qdim], &lbf[spos+10*qdim],
                           &lbf[spos+8*qdim], &lbf[spos+11*qdim], &lbf[spos+7*qdim], &lbf[spos+12*qdim],
                           &lbf[spos+6*qdim]);
      break;
    case CCTRB:
      fD3Q15VCCSimpleZouHe(rho, uwall[0], uwall[1], -uwall[2], &force[0], &lbf[spos], &lbf[spos+1*qdim],
                           &lbf[spos+2*qdim], &lbf[spos+10*qdim], &lbf[spos+5*qdim], &lbf[spos+4*qdim],
                           &lbf[spos+7*qdim], &lbf[spos+6*qdim], &lbf[spos+8*qdim], &lbf[spos+9*qdim],
                           &lbf[spos+3*qdim], &lbf[spos+12*qdim], &lbf[spos+11*qdim], &lbf[spos+14*qdim],
                           &lbf[spos+13*qdim]);
      break;
    case CCTLB:
      fD3Q15VCCSimpleZouHe(rho, -uwall[0], uwall[1], -uwall[2], &force[0], &lbf[spos], &lbf[spos+8*qdim],
                           &lbf[spos+2*qdim], &lbf[spos+10*qdim], &lbf[spos+13*qdim], &lbf[spos+14*qdim],
                           &lbf[spos+11*qdim], &lbf[spos+12*qdim], &lbf[spos+1*qdim], &lbf[spos+9*qdim],
                           &lbf[spos+3*qdim], &lbf[spos+6*qdim], &lbf[spos+7*qdim], &lbf[spos+4*qdim],
                           &lbf[spos+5*qdim]);
      break;
    case CCDLB:
      fD3Q15VCCSimpleZouHe(rho, -uwall[0], -uwall[1], -uwall[2], &force[0], &lbf[spos], &lbf[spos+8*qdim],
                           &lbf[spos+9*qdim], &lbf[spos+10*qdim], &lbf[spos+11*qdim], &lbf[spos+12*qdim],
                           &lbf[spos+13*qdim], &lbf[spos+14*qdim], &lbf[spos+1*qdim], &lbf[spos+2*qdim],
                           &lbf[spos+3*qdim], &lbf[spos+4*qdim], &lbf[spos+5*qdim], &lbf[spos+6*qdim],
                           &lbf[spos+7*qdim]);
      break;
    case CCDRB:
      fD3Q15VCCSimpleZouHe(rho, uwall[0], -uwall[1], -uwall[2], &force[0], &lbf[spos], &lbf[spos+1*qdim],
                           &lbf[spos+9*qdim], &lbf[spos+10*qdim], &lbf[spos+7*qdim], &lbf[spos+6*qdim],
                           &lbf[spos+5*qdim], &lbf[spos+4*qdim], &lbf[spos+8*qdim], &lbf[spos+2*qdim],
                           &lbf[spos+3*qdim], &lbf[spos+14*qdim], &lbf[spos+13*qdim], &lbf[spos+12*qdim],
                           &lbf[spos+11*qdim]);
      break;
    case CCTRF:
      fD3Q15VCCSimpleZouHe(rho, uwall[0], uwall[1], uwall[2], &force[0], &lbf[spos], &lbf[spos+1*qdim],
                           &lbf[spos+2*qdim], &lbf[spos+3*qdim], &lbf[spos+4*qdim], &lbf[spos+5*qdim],
                           &lbf[spos+6*qdim], &lbf[spos+7*qdim], &lbf[spos+8*qdim], &lbf[spos+9*qdim],
                           &lbf[spos+10*qdim], &lbf[spos+11*qdim], &lbf[spos+12*qdim], &lbf[spos+13*qdim],
                           &lbf[spos+14*qdim]);
      break;
    case CCTLF:
      fD3Q15VCCSimpleZouHe(rho, -uwall[0], uwall[1], uwall[2], &force[0], &lbf[spos], &lbf[spos+8*qdim],
                           &lbf[spos+2*qdim], &lbf[spos+3*qdim], &lbf[spos+14*qdim], &lbf[spos+13*qdim],
                           &lbf[spos+12*qdim], &lbf[spos+11*qdim], &lbf[spos+1*qdim], &lbf[spos+9*qdim],
                           &lbf[spos+10*qdim], &lbf[spos+7*qdim], &lbf[spos+6*qdim], &lbf[spos+5*qdim],
                           &lbf[spos+4*qdim]);
      break;
    case CCDLF:
      fD3Q15VCCSimpleZouHe(rho, -uwall[0], -uwall[1], uwall[2], &force[0], &lbf[spos], &lbf[spos+8*qdim],
                           &lbf[spos+9*qdim], &lbf[spos+3*qdim], &lbf[spos+12*qdim], &lbf[spos+11*qdim],
                           &lbf[spos+14*qdim], &lbf[spos+13*qdim], &lbf[spos+1*qdim], &lbf[spos+2*qdim],
                           &lbf[spos+10*qdim], &lbf[spos+5*qdim], &lbf[spos+4*qdim], &lbf[spos+7*qdim],
                           &lbf[spos+6*qdim]);
      break;
    case CCDRF:
      fD3Q15VCCSimpleZouHe(rho, uwall[0], -uwall[1], uwall[2], &force[0], &lbf[spos], &lbf[spos+1*qdim],
                           &lbf[spos+9*qdim], &lbf[spos+3*qdim], &lbf[spos+6*qdim], &lbf[spos+7*qdim],
                           &lbf[spos+4*qdim], &lbf[spos+5*qdim], &lbf[spos+8*qdim], &lbf[spos+2*qdim],
                           &lbf[spos+10*qdim], &lbf[spos+13*qdim], &lbf[spos+14*qdim], &lbf[spos+11*qdim],
                           &lbf[spos+12*qdim]);
      break;
    case CETR:
      fD3Q15VCESimpleZouHe(rho, uwall[0], uwall[1], uwall[2], &force[0], &lbf[spos], &lbf[spos+1*qdim],
                           &lbf[spos+2*qdim], &lbf[spos+3*qdim], &lbf[spos+4*qdim], &lbf[spos+5*qdim],
                           &lbf[spos+6*qdim], &lbf[spos+7*qdim], &lbf[spos+8*qdim], &lbf[spos+9*qdim],
                           &lbf[spos+10*qdim], &lbf[spos+11*qdim], &lbf[spos+12*qdim], &lbf[spos+13*qdim],
                           &lbf[spos+14*qdim]);
      break;
    case CETL:
      fD3Q15VCESimpleZouHe(rho, uwall[1], -uwall[0], uwall[2], &force[0], &lbf[spos], &lbf[spos+2*qdim],
                           &lbf[spos+8*qdim], &lbf[spos+3*qdim], &lbf[spos+14*qdim], &lbf[spos+13*qdim],
                           &lbf[spos+4*qdim], &lbf[spos+5*qdim], &lbf[spos+9*qdim], &lbf[spos+1*qdim],
                           &lbf[spos+10*qdim], &lbf[spos+7*qdim], &lbf[spos+6*qdim], &lbf[spos+11*qdim],
                           &lbf[spos+12*qdim]);
      break;
    case CEDL:
      fD3Q15VCESimpleZouHe(rho, -uwall[0], -uwall[1], uwall[2], &force[0], &lbf[spos], &lbf[spos+8*qdim],
                           &lbf[spos+9*qdim], &lbf[spos+3*qdim], &lbf[spos+12*qdim], &lbf[spos+11*qdim],
                           &lbf[spos+14*qdim], &lbf[spos+13*qdim], &lbf[spos+1*qdim], &lbf[spos+2*qdim],
                           &lbf[spos+10*qdim], &lbf[spos+5*qdim], &lbf[spos+4*qdim], &lbf[spos+7*qdim],
                           &lbf[spos+6*qdim]);
      break;
    case CEDR:
      fD3Q15VCESimpleZouHe(rho, -uwall[1], uwall[0], uwall[2], &force[0], &lbf[spos], &lbf[spos+9*qdim],
                           &lbf[spos+1*qdim], &lbf[spos+3*qdim], &lbf[spos+6*qdim], &lbf[spos+7*qdim],
                           &lbf[spos+12*qdim], &lbf[spos+11*qdim], &lbf[spos+2*qdim], &lbf[spos+8*qdim],
                           &lbf[spos+10*qdim], &lbf[spos+13*qdim], &lbf[spos+14*qdim], &lbf[spos+5*qdim],
                           &lbf[spos+4*qdim]);
      break;
    case CETF:
      fD3Q15VCESimpleZouHe(rho, uwall[1], uwall[2], uwall[0], &force[0], &lbf[spos], &lbf[spos+2*qdim],
                           &lbf[spos+3*qdim], &lbf[spos+1*qdim], &lbf[spos+4*qdim], &lbf[spos+14*qdim],
                           &lbf[spos+5*qdim], &lbf[spos+13*qdim], &lbf[spos+9*qdim], &lbf[spos+10*qdim],
                           &lbf[spos+8*qdim], &lbf[spos+11*qdim], &lbf[spos+7*qdim], &lbf[spos+12*qdim],
                           &lbf[spos+6*qdim]);
      break;
    case CELF:
      fD3Q15VCESimpleZouHe(rho, -uwall[0], uwall[2], uwall[1], &force[0], &lbf[spos], &lbf[spos+8*qdim],
                           &lbf[spos+3*qdim], &lbf[spos+2*qdim], &lbf[spos+14*qdim], &lbf[spos+12*qdim],
                           &lbf[spos+13*qdim], &lbf[spos+11*qdim], &lbf[spos+1*qdim], &lbf[spos+10*qdim],
                           &lbf[spos+9*qdim], &lbf[spos+7*qdim], &lbf[spos+5*qdim], &lbf[spos+6*qdim],
                           &lbf[spos+4*qdim]);
      break;
    case CEDF:
      fD3Q15VCESimpleZouHe(rho, -uwall[1], uwall[2], uwall[0], &force[0], &lbf[spos], &lbf[spos+9*qdim],
                           &lbf[spos+3*qdim], &lbf[spos+1*qdim], &lbf[spos+6*qdim], &lbf[spos+12*qdim],
                           &lbf[spos+7*qdim], &lbf[spos+11*qdim], &lbf[spos+2*qdim], &lbf[spos+10*qdim],
                           &lbf[spos+8*qdim], &lbf[spos+13*qdim], &lbf[spos+5*qdim], &lbf[spos+14*qdim],
                           &lbf[spos+4*qdim]);
      break;
    case CERF:
      fD3Q15VCESimpleZouHe(rho, uwall[0], uwall[2], uwall[1], &force[0], &lbf[spos], &lbf[spos+1*qdim],
                           &lbf[spos+3*qdim], &lbf[spos+2*qdim], &lbf[spos+4*qdim], &lbf[spos+6*qdim],
                           &lbf[spos+5*qdim], &lbf[spos+7*qdim], &lbf[spos+8*qdim], &lbf[spos+10*qdim],
                           &lbf[spos+9*qdim], &lbf[spos+11*qdim], &lbf[spos+13*qdim], &lbf[spos+12*qdim],
                           &lbf[spos+14*qdim]);
      break;
    case CETB:
      fD3Q15VCESimpleZouHe(rho, uwall[1], -uwall[2], uwall[0], &force[0], &lbf[spos], &lbf[spos+2*qdim],
                           &lbf[spos+10*qdim], &lbf[spos+1*qdim], &lbf[spos+5*qdim], &lbf[spos+13*qdim],
                           &lbf[spos+4*qdim], &lbf[spos+14*qdim], &lbf[spos+9*qdim], &lbf[spos+3*qdim],
                           &lbf[spos+8*qdim], &lbf[spos+12*qdim], &lbf[spos+6*qdim], &lbf[spos+11*qdim],
                           &lbf[spos+7*qdim]);
      break;
    case CELB:
      fD3Q15VCESimpleZouHe(rho, -uwall[0], -uwall[2], uwall[1], &force[0], &lbf[spos], &lbf[spos+8*qdim],
                           &lbf[spos+10*qdim], &lbf[spos+2*qdim], &lbf[spos+13*qdim], &lbf[spos+11*qdim],
                           &lbf[spos+14*qdim], &lbf[spos+12*qdim], &lbf[spos+1*qdim], &lbf[spos+3*qdim],
                           &lbf[spos+9*qdim], &lbf[spos+6*qdim], &lbf[spos+4*qdim], &lbf[spos+7*qdim],
                           &lbf[spos+5*qdim]);
      break;
    case CEDB:
      fD3Q15VCESimpleZouHe(rho, -uwall[1], -uwall[2], uwall[0], &force[0], &lbf[spos], &lbf[spos+9*qdim],
                           &lbf[spos+10*qdim], &lbf[spos+1*qdim], &lbf[spos+7*qdim], &lbf[spos+11*qdim],
                           &lbf[spos+6*qdim], &lbf[spos+12*qdim], &lbf[spos+2*qdim], &lbf[spos+3*qdim],
                           &lbf[spos+8*qdim], &lbf[spos+14*qdim], &lbf[spos+4*qdim], &lbf[spos+13*qdim],
                           &lbf[spos+5*qdim]);
      break;
    case CERB:
      fD3Q15VCESimpleZouHe(rho, uwall[0], -uwall[2], uwall[1], &force[0], &lbf[spos], &lbf[spos+1*qdim],
                           &lbf[spos+10*qdim], &lbf[spos+2*qdim], &lbf[spos+5*qdim], &lbf[spos+7*qdim],
                           &lbf[spos+4*qdim], &lbf[spos+6*qdim], &lbf[spos+8*qdim], &lbf[spos+3*qdim],
                           &lbf[spos+9*qdim], &lbf[spos+12*qdim], &lbf[spos+14*qdim], &lbf[spos+11*qdim],
                           &lbf[spos+13*qdim]);
      break;
  }
  return 0;
  
}

int fD3Q15PPSZouHe(double *p, double *force, double *f0, double *f1,
	               double *f2, double *f3, double *f4, double *f5,
	               double *f6, double *f7, double *f8, double *f9,
	               double *f10, double *f11, double *f12, double *f13,
	               double *f14, double &vel)
{

  // produce fixed pressure/density at planar surface: expressed for bottom wall

  double rx, rz, v;
  double c1=2.0/3.0,c2=1.0/12.0;
  double mass=0.0;
  vel=0.0;
  if(!incompress) {
    for(int i=0; i<lbsy.nf; i++) {
      v=p[i]-(f0[i]+f1[i]+f3[i]+f8[i]+f10[i]+2.0*(f2[i]+f4[i]+f5[i]+f13[i]+f14[i]))+0.5*force[3*i+1];
      vel += v;
      mass += p[i];
      rx=0.25* (f8[i]-f1[i])+0.125*force[3*i  ];
      rz=0.25*(f10[i]-f3[i])+0.125*force[3*i+2];
      f6[i]=f13[i]+c2*v+rx+rz;
      f7[i]=f14[i]+c2*v+rx-rz;
      f9[i]=f2[i]+c1*v;
      f11[i]=f4[i]+c2*v-rx-rz;
      f12[i]=f5[i]+c2*v-rx+rz;
    }
  }
  else {
    for(int i=0; i<lbsy.nf; i++) {
      v=p[i]-(f0[i]+f1[i]+f3[i]+f8[i]+f10[i]+2.0*(f2[i]+f4[i]+f5[i]+f13[i]+f14[i]))+0.5*force[3*i+1];
      vel += v;
      mass += lbincp[i];
      rx=0.25* (f8[i]-f1[i])+0.125*force[3*i  ];
      rz=0.25*(f10[i]-f3[i])+0.125*force[3*i+2];
      f6[i]=f13[i]+c2*v+rx+rz;
      f7[i]=f14[i]+c2*v+rx-rz;
      f9[i]=f2[i]+c1*v;
      f11[i]=f4[i]+c2*v-rx-rz;
      f12[i]=f5[i]+c2*v-rx+rz;
    }
  }
  vel *= fReciprocal(mass);
    
  return 0;
}

int fD3Q15PPSSwiftZouHe(double *p, double *force, double *f0, double *f1,
	                    double *f2, double *f3, double *f4, double *f5,
	                    double *f6, double *f7, double *f8, double *f9,
	                    double *f10, double *f11, double *f12, double *f13,
	                    double *f14, double &vel)
{

  // produce fixed pressure/density at planar surface: expressed for bottom wall
  // with Swift free-energy interactions

  double rx, rz, v;
  double c1=2.0/3.0,c2=1.0/12.0;
  double mass=0.0;
  vel=0.0;

  v=p[0]-(f0[0]+f1[0]+f3[0]+f8[0]+f10[0]+2.0*(f2[0]+f4[0]+f5[0]+f13[0]+f14[0]))+0.5*force[1];
  vel += v;
  mass += p[0];
  rx=0.25* (f8[0]-f1[0])+0.125*force[0];
  rz=0.25*(f10[0]-f3[0])+0.125*force[2];
  f6[0]=f13[0]+c2*v+rx+rz;
  f7[0]=f14[0]+c2*v+rx-rz;
  f9[0]=f2[0]+c1*v;
  f11[0]=f4[0]+c2*v-rx-rz;
  f12[0]=f5[0]+c2*v-rx+rz;
  vel *= fReciprocal(mass);
  if(lbsy.nf>1) {
    rx=0.25* (f8[1]-f1[1]);
    rz=0.25*(f10[1]-f3[1]);
    f4[1]=f11[1]+c2*p[1]*vel+rx+rz;
    f5[1]=f12[1]+c2*p[1]*vel+rx-rz;
    f9[1]=f2[1]+c1*p[1]*vel;
    f13[1]=f6[1]+c2*p[1]*vel-rx-rz;
    f14[1]=f7[1]+c2*p[1]*vel-rx+rz;
  }
    
  return 0;
}


int fD3Q15PFZouHe(long tpos, int prop, double *p0, double *uwall)
{
  double moment;
  long spos=tpos * lbsitelength;
  int qdim = lbsy.nf+lbsy.nc+lbsy.nt;
  double force[3*lbsy.nf];

  // sort out forces
    
  fD3Q15BoundaryForceDensity(force, tpos, p0, prop);
    
  // apply boundary condition

  if(interact==20) {
    switch (prop) {
      case PST:
        fD3Q15PPSSwiftZouHe(p0, &force[0], &lbf[spos], &lbf[spos+1*qdim],
                            &lbf[spos+2*qdim], &lbf[spos+3*qdim], &lbf[spos+4*qdim], &lbf[spos+5*qdim],
                            &lbf[spos+6*qdim], &lbf[spos+7*qdim], &lbf[spos+8*qdim], &lbf[spos+9*qdim],
                            &lbf[spos+10*qdim], &lbf[spos+11*qdim], &lbf[spos+12*qdim], &lbf[spos+13*qdim],
                            &lbf[spos+14*qdim], moment);
        uwall[1] += moment;
        break;
      case PSD:
        fD3Q15PPSSwiftZouHe(p0, &force[0], &lbf[spos], &lbf[spos+8*qdim],
                            &lbf[spos+9*qdim], &lbf[spos+10*qdim], &lbf[spos+11*qdim], &lbf[spos+12*qdim],
                            &lbf[spos+13*qdim], &lbf[spos+14*qdim], &lbf[spos+1*qdim], &lbf[spos+2*qdim],
                            &lbf[spos+3*qdim], &lbf[spos+4*qdim], &lbf[spos+5*qdim], &lbf[spos+6*qdim],
                            &lbf[spos+7*qdim], moment);
        uwall[1] -= moment;
        break;
      case PSL:
        fD3Q15PPSSwiftZouHe(p0, &force[0], &lbf[spos], &lbf[spos+10*qdim],
                            &lbf[spos+8*qdim], &lbf[spos+9*qdim], &lbf[spos+11*qdim], &lbf[spos+13*qdim],
                            &lbf[spos+7*qdim], &lbf[spos+5*qdim], &lbf[spos+3*qdim], &lbf[spos+1*qdim],
                            &lbf[spos+2*qdim], &lbf[spos+4*qdim], &lbf[spos+6*qdim], &lbf[spos+14*qdim],
                            &lbf[spos+12*qdim], moment);
        uwall[0] -= moment;
        break;
      case PSR:
        fD3Q15PPSSwiftZouHe(p0, &force[0], &lbf[spos], &lbf[spos+3*qdim],
                            &lbf[spos+1*qdim], &lbf[spos+2*qdim], &lbf[spos+4*qdim], &lbf[spos+6*qdim],
                            &lbf[spos+14*qdim], &lbf[spos+12*qdim], &lbf[spos+10*qdim], &lbf[spos+8*qdim],
                            &lbf[spos+9*qdim], &lbf[spos+11*qdim], &lbf[spos+13*qdim], &lbf[spos+7*qdim],
                            &lbf[spos+5*qdim], moment);
        uwall[1] += moment;
        break;
      case PSF:
        fD3Q15PPSSwiftZouHe(p0, &force[0], &lbf[spos], &lbf[spos+9*qdim],
                            &lbf[spos+10*qdim], &lbf[spos+8*qdim], &lbf[spos+11*qdim], &lbf[spos+7*qdim],
                            &lbf[spos+12*qdim], &lbf[spos+6*qdim], &lbf[spos+2*qdim], &lbf[spos+3*qdim],
                            &lbf[spos+1*qdim], &lbf[spos+4*qdim], &lbf[spos+14*qdim], &lbf[spos+5*qdim],
                            &lbf[spos+13*qdim], moment);
        uwall[2] -= moment;
        break;
      case PSB:
        fD3Q15PPSSwiftZouHe(p0, &force[0], &lbf[spos], &lbf[spos+2*qdim],
                            &lbf[spos+3*qdim], &lbf[spos+1*qdim], &lbf[spos+4*qdim], &lbf[spos+14*qdim],
                            &lbf[spos+5*qdim], &lbf[spos+13*qdim], &lbf[spos+9*qdim], &lbf[spos+10*qdim],
                            &lbf[spos+8*qdim], &lbf[spos+11*qdim], &lbf[spos+7*qdim], &lbf[spos+12*qdim],
                            &lbf[spos+6*qdim], moment);
        uwall[2] += moment;
        break;
      case CCTRB:
        fD3Q15VCCZouHe(p0, uwall[0], uwall[1], -uwall[2], &force[0], &lbf[spos], &lbf[spos+1*qdim],
                       &lbf[spos+2*qdim], &lbf[spos+10*qdim], &lbf[spos+5*qdim], &lbf[spos+4*qdim],
                       &lbf[spos+7*qdim], &lbf[spos+6*qdim], &lbf[spos+8*qdim], &lbf[spos+9*qdim],
                       &lbf[spos+3*qdim], &lbf[spos+12*qdim], &lbf[spos+11*qdim], &lbf[spos+14*qdim],
                       &lbf[spos+13*qdim]);
        break;
      case CCTLB:
        fD3Q15VCCZouHe(p0, -uwall[0], uwall[1], -uwall[2], &force[0], &lbf[spos], &lbf[spos+8*qdim],
                       &lbf[spos+2*qdim], &lbf[spos+10*qdim], &lbf[spos+13*qdim], &lbf[spos+14*qdim],
                       &lbf[spos+11*qdim], &lbf[spos+12*qdim], &lbf[spos+1*qdim], &lbf[spos+9*qdim],
                       &lbf[spos+3*qdim], &lbf[spos+6*qdim], &lbf[spos+7*qdim], &lbf[spos+4*qdim],
                       &lbf[spos+5*qdim]);
        break;
      case CCDLB:
        fD3Q15VCCZouHe(p0, -uwall[0], -uwall[1], -uwall[2], &force[0], &lbf[spos], &lbf[spos+8*qdim],
                       &lbf[spos+9*qdim], &lbf[spos+10*qdim], &lbf[spos+11*qdim], &lbf[spos+12*qdim],
                       &lbf[spos+13*qdim], &lbf[spos+14*qdim], &lbf[spos+1*qdim], &lbf[spos+2*qdim],
                       &lbf[spos+3*qdim], &lbf[spos+4*qdim], &lbf[spos+5*qdim], &lbf[spos+6*qdim],
                       &lbf[spos+7*qdim]);
        break;
      case CCDRB:
        fD3Q15VCCZouHe(p0, uwall[0], -uwall[1], -uwall[2], &force[0], &lbf[spos], &lbf[spos+1*qdim],
                       &lbf[spos+9*qdim], &lbf[spos+10*qdim], &lbf[spos+7*qdim], &lbf[spos+6*qdim],
                       &lbf[spos+5*qdim], &lbf[spos+4*qdim], &lbf[spos+8*qdim], &lbf[spos+2*qdim],
                       &lbf[spos+3*qdim], &lbf[spos+14*qdim], &lbf[spos+13*qdim], &lbf[spos+12*qdim],
                       &lbf[spos+11*qdim]);
        break;
      case CCTRF:
        fD3Q15VCCZouHe(p0, uwall[0], uwall[1], uwall[2], &force[0], &lbf[spos], &lbf[spos+1*qdim],
                       &lbf[spos+2*qdim], &lbf[spos+3*qdim], &lbf[spos+4*qdim], &lbf[spos+5*qdim],
                       &lbf[spos+6*qdim], &lbf[spos+7*qdim], &lbf[spos+8*qdim], &lbf[spos+9*qdim],
                       &lbf[spos+10*qdim], &lbf[spos+11*qdim], &lbf[spos+12*qdim], &lbf[spos+13*qdim],
                       &lbf[spos+14*qdim]);
        break;
      case CCTLF:
        fD3Q15VCCZouHe(p0, -uwall[0], uwall[1], uwall[2], &force[0], &lbf[spos], &lbf[spos+8*qdim],
                       &lbf[spos+2*qdim], &lbf[spos+3*qdim], &lbf[spos+14*qdim], &lbf[spos+13*qdim],
                       &lbf[spos+12*qdim], &lbf[spos+11*qdim], &lbf[spos+1*qdim], &lbf[spos+9*qdim],
                       &lbf[spos+10*qdim], &lbf[spos+7*qdim], &lbf[spos+6*qdim], &lbf[spos+5*qdim],
                       &lbf[spos+4*qdim]);
        break;
      case CCDLF:
        fD3Q15VCCZouHe(p0, -uwall[0], -uwall[1], uwall[2], &force[0], &lbf[spos], &lbf[spos+8*qdim],
                       &lbf[spos+9*qdim], &lbf[spos+3*qdim], &lbf[spos+12*qdim], &lbf[spos+11*qdim],
                       &lbf[spos+14*qdim], &lbf[spos+13*qdim], &lbf[spos+1*qdim], &lbf[spos+2*qdim],
                       &lbf[spos+10*qdim], &lbf[spos+5*qdim], &lbf[spos+4*qdim], &lbf[spos+7*qdim],
                       &lbf[spos+6*qdim]);
        break;
      case CCDRF:
        fD3Q15VCCZouHe(p0, uwall[0], -uwall[1], uwall[2], &force[0], &lbf[spos], &lbf[spos+1*qdim],
                       &lbf[spos+9*qdim], &lbf[spos+3*qdim], &lbf[spos+6*qdim], &lbf[spos+7*qdim],
                       &lbf[spos+4*qdim], &lbf[spos+5*qdim], &lbf[spos+8*qdim], &lbf[spos+2*qdim],
                       &lbf[spos+10*qdim], &lbf[spos+13*qdim], &lbf[spos+14*qdim], &lbf[spos+11*qdim],
                       &lbf[spos+12*qdim]);
        break;
      case CETR:
        fD3Q15VCEZouHe(p0, uwall[0], uwall[1], uwall[2], &force[0], &lbf[spos], &lbf[spos+1*qdim],
                       &lbf[spos+2*qdim], &lbf[spos+3*qdim], &lbf[spos+4*qdim], &lbf[spos+5*qdim],
                       &lbf[spos+6*qdim], &lbf[spos+7*qdim], &lbf[spos+8*qdim], &lbf[spos+9*qdim],
                       &lbf[spos+10*qdim], &lbf[spos+11*qdim], &lbf[spos+12*qdim], &lbf[spos+13*qdim],
                       &lbf[spos+14*qdim]);
        break;
      case CETL:
        fD3Q15VCEZouHe(p0, uwall[1], -uwall[0], uwall[2], &force[0], &lbf[spos], &lbf[spos+2*qdim],
                       &lbf[spos+8*qdim], &lbf[spos+3*qdim], &lbf[spos+14*qdim], &lbf[spos+13*qdim],
                       &lbf[spos+4*qdim], &lbf[spos+5*qdim], &lbf[spos+9*qdim], &lbf[spos+1*qdim],
                       &lbf[spos+10*qdim], &lbf[spos+7*qdim], &lbf[spos+6*qdim], &lbf[spos+11*qdim],
                       &lbf[spos+12*qdim]);
        break;
      case CEDL:
        fD3Q15VCEZouHe(p0, -uwall[0], -uwall[1], uwall[2], &force[0], &lbf[spos], &lbf[spos+8*qdim],
                       &lbf[spos+9*qdim], &lbf[spos+3*qdim], &lbf[spos+12*qdim], &lbf[spos+11*qdim],
                       &lbf[spos+14*qdim], &lbf[spos+13*qdim], &lbf[spos+1*qdim], &lbf[spos+2*qdim],
                       &lbf[spos+10*qdim], &lbf[spos+5*qdim], &lbf[spos+4*qdim], &lbf[spos+7*qdim],
                       &lbf[spos+6*qdim]);
        break;
      case CEDR:
        fD3Q15VCEZouHe(p0, -uwall[1], uwall[0], uwall[2], &force[0], &lbf[spos], &lbf[spos+9*qdim],
                       &lbf[spos+1*qdim], &lbf[spos+3*qdim], &lbf[spos+6*qdim], &lbf[spos+7*qdim],
                       &lbf[spos+12*qdim], &lbf[spos+11*qdim], &lbf[spos+2*qdim], &lbf[spos+8*qdim],
                       &lbf[spos+10*qdim], &lbf[spos+13*qdim], &lbf[spos+14*qdim], &lbf[spos+5*qdim],
                       &lbf[spos+4*qdim]);
        break;
      case CETF:
        fD3Q15VCEZouHe(p0, uwall[1], uwall[2], uwall[0], &force[0], &lbf[spos], &lbf[spos+2*qdim],
                       &lbf[spos+3*qdim], &lbf[spos+1*qdim], &lbf[spos+4*qdim], &lbf[spos+14*qdim],
                       &lbf[spos+5*qdim], &lbf[spos+13*qdim], &lbf[spos+9*qdim], &lbf[spos+10*qdim],
                       &lbf[spos+8*qdim], &lbf[spos+11*qdim], &lbf[spos+7*qdim], &lbf[spos+12*qdim],
                       &lbf[spos+6*qdim]);
        break;
      case CELF:
        fD3Q15VCEZouHe(p0, -uwall[0], uwall[2], uwall[1], &force[0], &lbf[spos], &lbf[spos+8*qdim],
                       &lbf[spos+3*qdim], &lbf[spos+2*qdim], &lbf[spos+14*qdim], &lbf[spos+12*qdim],
                       &lbf[spos+13*qdim], &lbf[spos+11*qdim], &lbf[spos+1*qdim], &lbf[spos+10*qdim],
                       &lbf[spos+9*qdim], &lbf[spos+7*qdim], &lbf[spos+5*qdim], &lbf[spos+6*qdim],
                       &lbf[spos+4*qdim]);
        break;
      case CEDF:
        fD3Q15VCEZouHe(p0, -uwall[1], uwall[2], uwall[0], &force[0], &lbf[spos], &lbf[spos+9*qdim],
                       &lbf[spos+3*qdim], &lbf[spos+1*qdim], &lbf[spos+6*qdim], &lbf[spos+12*qdim],
                       &lbf[spos+7*qdim], &lbf[spos+11*qdim], &lbf[spos+2*qdim], &lbf[spos+10*qdim],
                       &lbf[spos+8*qdim], &lbf[spos+13*qdim], &lbf[spos+5*qdim], &lbf[spos+14*qdim],
                       &lbf[spos+4*qdim]);
        break;
      case CERF:
        fD3Q15VCEZouHe(p0, uwall[0], uwall[2], uwall[1], &force[0], &lbf[spos], &lbf[spos+1*qdim],
                       &lbf[spos+3*qdim], &lbf[spos+2*qdim], &lbf[spos+4*qdim], &lbf[spos+6*qdim],
                       &lbf[spos+5*qdim], &lbf[spos+7*qdim], &lbf[spos+8*qdim], &lbf[spos+10*qdim],
                       &lbf[spos+9*qdim], &lbf[spos+11*qdim], &lbf[spos+13*qdim], &lbf[spos+12*qdim],
                       &lbf[spos+14*qdim]);
        break;
      case CETB:
        fD3Q15VCEZouHe(p0, uwall[1], -uwall[2], uwall[0], &force[0], &lbf[spos], &lbf[spos+2*qdim],
                       &lbf[spos+10*qdim], &lbf[spos+1*qdim], &lbf[spos+5*qdim], &lbf[spos+13*qdim],
                       &lbf[spos+4*qdim], &lbf[spos+14*qdim], &lbf[spos+9*qdim], &lbf[spos+3*qdim],
                       &lbf[spos+8*qdim], &lbf[spos+12*qdim], &lbf[spos+6*qdim], &lbf[spos+11*qdim],
                       &lbf[spos+7*qdim]);
        break;
      case CELB:
        fD3Q15VCEZouHe(p0, -uwall[0], -uwall[2], uwall[1], &force[0], &lbf[spos], &lbf[spos+8*qdim],
                       &lbf[spos+10*qdim], &lbf[spos+2*qdim], &lbf[spos+13*qdim], &lbf[spos+11*qdim],
                       &lbf[spos+14*qdim], &lbf[spos+12*qdim], &lbf[spos+1*qdim], &lbf[spos+3*qdim],
                       &lbf[spos+9*qdim], &lbf[spos+6*qdim], &lbf[spos+4*qdim], &lbf[spos+7*qdim],
                       &lbf[spos+5*qdim]);
        break;
      case CEDB:
        fD3Q15VCEZouHe(p0, -uwall[1], -uwall[2], uwall[0], &force[0], &lbf[spos], &lbf[spos+9*qdim],
                       &lbf[spos+10*qdim], &lbf[spos+1*qdim], &lbf[spos+7*qdim], &lbf[spos+11*qdim],
                       &lbf[spos+6*qdim], &lbf[spos+12*qdim], &lbf[spos+2*qdim], &lbf[spos+3*qdim],
                       &lbf[spos+8*qdim], &lbf[spos+14*qdim], &lbf[spos+4*qdim], &lbf[spos+13*qdim],
                       &lbf[spos+5*qdim]);
        break;
      case CERB:
        fD3Q15VCEZouHe(p0, uwall[0], -uwall[2], uwall[1], &force[0], &lbf[spos], &lbf[spos+1*qdim],
                       &lbf[spos+10*qdim], &lbf[spos+2*qdim], &lbf[spos+5*qdim], &lbf[spos+7*qdim],
                       &lbf[spos+4*qdim], &lbf[spos+6*qdim], &lbf[spos+8*qdim], &lbf[spos+3*qdim],
                       &lbf[spos+9*qdim], &lbf[spos+12*qdim], &lbf[spos+14*qdim], &lbf[spos+11*qdim],
                       &lbf[spos+13*qdim]);
        break;
    }
  }
  else {
    switch (prop) {
      case PST:
        fD3Q15PPSZouHe(p0, &force[0], &lbf[spos], &lbf[spos+1*qdim],
                       &lbf[spos+2*qdim], &lbf[spos+3*qdim], &lbf[spos+4*qdim], &lbf[spos+5*qdim],
                       &lbf[spos+6*qdim], &lbf[spos+7*qdim], &lbf[spos+8*qdim], &lbf[spos+9*qdim],
                       &lbf[spos+10*qdim], &lbf[spos+11*qdim], &lbf[spos+12*qdim], &lbf[spos+13*qdim],
                       &lbf[spos+14*qdim], moment);
        uwall[1] += moment;
        break;
      case PSD:
        fD3Q15PPSZouHe(p0, &force[0], &lbf[spos], &lbf[spos+8*qdim],
                       &lbf[spos+9*qdim], &lbf[spos+10*qdim], &lbf[spos+11*qdim], &lbf[spos+12*qdim],
                       &lbf[spos+13*qdim], &lbf[spos+14*qdim], &lbf[spos+1*qdim], &lbf[spos+2*qdim],
                       &lbf[spos+3*qdim], &lbf[spos+4*qdim], &lbf[spos+5*qdim], &lbf[spos+6*qdim],
                       &lbf[spos+7*qdim], moment);
        uwall[1] -= moment;
        break;
      case PSL:
        fD3Q15PPSZouHe(p0, &force[0], &lbf[spos], &lbf[spos+10*qdim],
                       &lbf[spos+8*qdim], &lbf[spos+9*qdim], &lbf[spos+11*qdim], &lbf[spos+13*qdim],
                       &lbf[spos+7*qdim], &lbf[spos+5*qdim], &lbf[spos+3*qdim], &lbf[spos+1*qdim],
                       &lbf[spos+2*qdim], &lbf[spos+4*qdim], &lbf[spos+6*qdim], &lbf[spos+14*qdim],
                       &lbf[spos+12*qdim], moment);
        uwall[0] -= moment;
        break;
      case PSR:
        fD3Q15PPSZouHe(p0, &force[0], &lbf[spos], &lbf[spos+3*qdim],
                       &lbf[spos+1*qdim], &lbf[spos+2*qdim], &lbf[spos+4*qdim], &lbf[spos+6*qdim],
                       &lbf[spos+14*qdim], &lbf[spos+12*qdim], &lbf[spos+10*qdim], &lbf[spos+8*qdim],
                       &lbf[spos+9*qdim], &lbf[spos+11*qdim], &lbf[spos+13*qdim], &lbf[spos+7*qdim],
                       &lbf[spos+5*qdim], moment);
        uwall[1] += moment;
        break;
      case PSF:
        fD3Q15PPSZouHe(p0, &force[0], &lbf[spos], &lbf[spos+9*qdim],
                       &lbf[spos+10*qdim], &lbf[spos+8*qdim], &lbf[spos+11*qdim], &lbf[spos+7*qdim],
                       &lbf[spos+12*qdim], &lbf[spos+6*qdim], &lbf[spos+2*qdim], &lbf[spos+3*qdim],
                       &lbf[spos+1*qdim], &lbf[spos+4*qdim], &lbf[spos+14*qdim], &lbf[spos+5*qdim],
                       &lbf[spos+13*qdim], moment);
        uwall[2] -= moment;
        break;
      case PSB:
        fD3Q15PPSZouHe(p0, &force[0], &lbf[spos], &lbf[spos+2*qdim],
                       &lbf[spos+3*qdim], &lbf[spos+1*qdim], &lbf[spos+4*qdim], &lbf[spos+14*qdim],
                       &lbf[spos+5*qdim], &lbf[spos+13*qdim], &lbf[spos+9*qdim], &lbf[spos+10*qdim],
                       &lbf[spos+8*qdim], &lbf[spos+11*qdim], &lbf[spos+7*qdim], &lbf[spos+12*qdim],
                       &lbf[spos+6*qdim], moment);
        uwall[2] += moment;
        break;
      case CCTRB:
        fD3Q15VCCZouHe(p0, uwall[0], uwall[1], -uwall[2], &force[0], &lbf[spos], &lbf[spos+1*qdim],
                       &lbf[spos+2*qdim], &lbf[spos+10*qdim], &lbf[spos+5*qdim], &lbf[spos+4*qdim],
                       &lbf[spos+7*qdim], &lbf[spos+6*qdim], &lbf[spos+8*qdim], &lbf[spos+9*qdim],
                       &lbf[spos+3*qdim], &lbf[spos+12*qdim], &lbf[spos+11*qdim], &lbf[spos+14*qdim],
                       &lbf[spos+13*qdim]);
        break;
      case CCTLB:
        fD3Q15VCCZouHe(p0, -uwall[0], uwall[1], -uwall[2], &force[0], &lbf[spos], &lbf[spos+8*qdim],
                       &lbf[spos+2*qdim], &lbf[spos+10*qdim], &lbf[spos+13*qdim], &lbf[spos+14*qdim],
                       &lbf[spos+11*qdim], &lbf[spos+12*qdim], &lbf[spos+1*qdim], &lbf[spos+9*qdim],
                       &lbf[spos+3*qdim], &lbf[spos+6*qdim], &lbf[spos+7*qdim], &lbf[spos+4*qdim],
                       &lbf[spos+5*qdim]);
        break;
      case CCDLB:
        fD3Q15VCCZouHe(p0, -uwall[0], -uwall[1], -uwall[2], &force[0], &lbf[spos], &lbf[spos+8*qdim],
                       &lbf[spos+9*qdim], &lbf[spos+10*qdim], &lbf[spos+11*qdim], &lbf[spos+12*qdim],
                       &lbf[spos+13*qdim], &lbf[spos+14*qdim], &lbf[spos+1*qdim], &lbf[spos+2*qdim],
                       &lbf[spos+3*qdim], &lbf[spos+4*qdim], &lbf[spos+5*qdim], &lbf[spos+6*qdim],
                       &lbf[spos+7*qdim]);
        break;
      case CCDRB:
        fD3Q15VCCZouHe(p0, uwall[0], -uwall[1], -uwall[2], &force[0], &lbf[spos], &lbf[spos+1*qdim],
                       &lbf[spos+9*qdim], &lbf[spos+10*qdim], &lbf[spos+7*qdim], &lbf[spos+6*qdim],
                       &lbf[spos+5*qdim], &lbf[spos+4*qdim], &lbf[spos+8*qdim], &lbf[spos+2*qdim],
                       &lbf[spos+3*qdim], &lbf[spos+14*qdim], &lbf[spos+13*qdim], &lbf[spos+12*qdim],
                       &lbf[spos+11*qdim]);
        break;
      case CCTRF:
        fD3Q15VCCZouHe(p0, uwall[0], uwall[1], uwall[2], &force[0], &lbf[spos], &lbf[spos+1*qdim],
                       &lbf[spos+2*qdim], &lbf[spos+3*qdim], &lbf[spos+4*qdim], &lbf[spos+5*qdim],
                       &lbf[spos+6*qdim], &lbf[spos+7*qdim], &lbf[spos+8*qdim], &lbf[spos+9*qdim],
                       &lbf[spos+10*qdim], &lbf[spos+11*qdim], &lbf[spos+12*qdim], &lbf[spos+13*qdim],
                       &lbf[spos+14*qdim]);
        break;
      case CCTLF:
        fD3Q15VCCZouHe(p0, -uwall[0], uwall[1], uwall[2], &force[0], &lbf[spos], &lbf[spos+8*qdim],
                       &lbf[spos+2*qdim], &lbf[spos+3*qdim], &lbf[spos+14*qdim], &lbf[spos+13*qdim],
                       &lbf[spos+12*qdim], &lbf[spos+11*qdim], &lbf[spos+1*qdim], &lbf[spos+9*qdim],
                       &lbf[spos+10*qdim], &lbf[spos+7*qdim], &lbf[spos+6*qdim], &lbf[spos+5*qdim],
                       &lbf[spos+4*qdim]);
        break;
      case CCDLF:
        fD3Q15VCCZouHe(p0, -uwall[0], -uwall[1], uwall[2], &force[0], &lbf[spos], &lbf[spos+8*qdim],
                       &lbf[spos+9*qdim], &lbf[spos+3*qdim], &lbf[spos+12*qdim], &lbf[spos+11*qdim],
                       &lbf[spos+14*qdim], &lbf[spos+13*qdim], &lbf[spos+1*qdim], &lbf[spos+2*qdim],
                       &lbf[spos+10*qdim], &lbf[spos+5*qdim], &lbf[spos+4*qdim], &lbf[spos+7*qdim],
                       &lbf[spos+6*qdim]);
        break;
      case CCDRF:
        fD3Q15VCCZouHe(p0, uwall[0], -uwall[1], uwall[2], &force[0], &lbf[spos], &lbf[spos+1*qdim],
                       &lbf[spos+9*qdim], &lbf[spos+3*qdim], &lbf[spos+6*qdim], &lbf[spos+7*qdim],
                       &lbf[spos+4*qdim], &lbf[spos+5*qdim], &lbf[spos+8*qdim], &lbf[spos+2*qdim],
                       &lbf[spos+10*qdim], &lbf[spos+13*qdim], &lbf[spos+14*qdim], &lbf[spos+11*qdim],
                       &lbf[spos+12*qdim]);
        break;
      case CETR:
        fD3Q15VCEZouHe(p0, uwall[0], uwall[1], uwall[2], &force[0], &lbf[spos], &lbf[spos+1*qdim],
                       &lbf[spos+2*qdim], &lbf[spos+3*qdim], &lbf[spos+4*qdim], &lbf[spos+5*qdim],
                       &lbf[spos+6*qdim], &lbf[spos+7*qdim], &lbf[spos+8*qdim], &lbf[spos+9*qdim],
                       &lbf[spos+10*qdim], &lbf[spos+11*qdim], &lbf[spos+12*qdim], &lbf[spos+13*qdim],
                       &lbf[spos+14*qdim]);
        break;
      case CETL:
        fD3Q15VCEZouHe(p0, uwall[1], -uwall[0], uwall[2], &force[0], &lbf[spos], &lbf[spos+2*qdim],
                       &lbf[spos+8*qdim], &lbf[spos+3*qdim], &lbf[spos+14*qdim], &lbf[spos+13*qdim],
                       &lbf[spos+4*qdim], &lbf[spos+5*qdim], &lbf[spos+9*qdim], &lbf[spos+1*qdim],
                       &lbf[spos+10*qdim], &lbf[spos+7*qdim], &lbf[spos+6*qdim], &lbf[spos+11*qdim],
                       &lbf[spos+12*qdim]);
        break;
      case CEDL:
        fD3Q15VCEZouHe(p0, -uwall[0], -uwall[1], uwall[2], &force[0], &lbf[spos], &lbf[spos+8*qdim],
                       &lbf[spos+9*qdim], &lbf[spos+3*qdim], &lbf[spos+12*qdim], &lbf[spos+11*qdim],
                       &lbf[spos+14*qdim], &lbf[spos+13*qdim], &lbf[spos+1*qdim], &lbf[spos+2*qdim],
                       &lbf[spos+10*qdim], &lbf[spos+5*qdim], &lbf[spos+4*qdim], &lbf[spos+7*qdim],
                       &lbf[spos+6*qdim]);
        break;
      case CEDR:
        fD3Q15VCEZouHe(p0, -uwall[1], uwall[0], uwall[2], &force[0], &lbf[spos], &lbf[spos+9*qdim],
                       &lbf[spos+1*qdim], &lbf[spos+3*qdim], &lbf[spos+6*qdim], &lbf[spos+7*qdim],
                       &lbf[spos+12*qdim], &lbf[spos+11*qdim], &lbf[spos+2*qdim], &lbf[spos+8*qdim],
                       &lbf[spos+10*qdim], &lbf[spos+13*qdim], &lbf[spos+14*qdim], &lbf[spos+5*qdim],
                       &lbf[spos+4*qdim]);
        break;
      case CETF:
        fD3Q15VCEZouHe(p0, uwall[1], uwall[2], uwall[0], &force[0], &lbf[spos], &lbf[spos+2*qdim],
                       &lbf[spos+3*qdim], &lbf[spos+1*qdim], &lbf[spos+4*qdim], &lbf[spos+14*qdim],
                       &lbf[spos+5*qdim], &lbf[spos+13*qdim], &lbf[spos+9*qdim], &lbf[spos+10*qdim],
                       &lbf[spos+8*qdim], &lbf[spos+11*qdim], &lbf[spos+7*qdim], &lbf[spos+12*qdim],
                       &lbf[spos+6*qdim]);
        break;
      case CELF:
        fD3Q15VCEZouHe(p0, -uwall[0], uwall[2], uwall[1], &force[0], &lbf[spos], &lbf[spos+8*qdim],
                       &lbf[spos+3*qdim], &lbf[spos+2*qdim], &lbf[spos+14*qdim], &lbf[spos+12*qdim],
                       &lbf[spos+13*qdim], &lbf[spos+11*qdim], &lbf[spos+1*qdim], &lbf[spos+10*qdim],
                       &lbf[spos+9*qdim], &lbf[spos+7*qdim], &lbf[spos+5*qdim], &lbf[spos+6*qdim],
                       &lbf[spos+4*qdim]);
        break;
      case CEDF:
        fD3Q15VCEZouHe(p0, -uwall[1], uwall[2], uwall[0], &force[0], &lbf[spos], &lbf[spos+9*qdim],
                       &lbf[spos+3*qdim], &lbf[spos+1*qdim], &lbf[spos+6*qdim], &lbf[spos+12*qdim],
                       &lbf[spos+7*qdim], &lbf[spos+11*qdim], &lbf[spos+2*qdim], &lbf[spos+10*qdim],
                       &lbf[spos+8*qdim], &lbf[spos+13*qdim], &lbf[spos+5*qdim], &lbf[spos+14*qdim],
                       &lbf[spos+4*qdim]);
        break;
      case CERF:
        fD3Q15VCEZouHe(p0, uwall[0], uwall[2], uwall[1], &force[0], &lbf[spos], &lbf[spos+1*qdim],
                       &lbf[spos+3*qdim], &lbf[spos+2*qdim], &lbf[spos+4*qdim], &lbf[spos+6*qdim],
                       &lbf[spos+5*qdim], &lbf[spos+7*qdim], &lbf[spos+8*qdim], &lbf[spos+10*qdim],
                       &lbf[spos+9*qdim], &lbf[spos+11*qdim], &lbf[spos+13*qdim], &lbf[spos+12*qdim],
                       &lbf[spos+14*qdim]);
        break;
      case CETB:
        fD3Q15VCEZouHe(p0, uwall[1], -uwall[2], uwall[0], &force[0], &lbf[spos], &lbf[spos+2*qdim],
                       &lbf[spos+10*qdim], &lbf[spos+1*qdim], &lbf[spos+5*qdim], &lbf[spos+13*qdim],
                       &lbf[spos+4*qdim], &lbf[spos+14*qdim], &lbf[spos+9*qdim], &lbf[spos+3*qdim],
                       &lbf[spos+8*qdim], &lbf[spos+12*qdim], &lbf[spos+6*qdim], &lbf[spos+11*qdim],
                       &lbf[spos+7*qdim]);
        break;
      case CELB:
        fD3Q15VCEZouHe(p0, -uwall[0], -uwall[2], uwall[1], &force[0], &lbf[spos], &lbf[spos+8*qdim],
                       &lbf[spos+10*qdim], &lbf[spos+2*qdim], &lbf[spos+13*qdim], &lbf[spos+11*qdim],
                       &lbf[spos+14*qdim], &lbf[spos+12*qdim], &lbf[spos+1*qdim], &lbf[spos+3*qdim],
                       &lbf[spos+9*qdim], &lbf[spos+6*qdim], &lbf[spos+4*qdim], &lbf[spos+7*qdim],
                       &lbf[spos+5*qdim]);
        break;
      case CEDB:
        fD3Q15VCEZouHe(p0, -uwall[1], -uwall[2], uwall[0], &force[0], &lbf[spos], &lbf[spos+9*qdim],
                       &lbf[spos+10*qdim], &lbf[spos+1*qdim], &lbf[spos+7*qdim], &lbf[spos+11*qdim],
                       &lbf[spos+6*qdim], &lbf[spos+12*qdim], &lbf[spos+2*qdim], &lbf[spos+3*qdim],
                       &lbf[spos+8*qdim], &lbf[spos+14*qdim], &lbf[spos+4*qdim], &lbf[spos+13*qdim],
                       &lbf[spos+5*qdim]);
        break;
      case CERB:
        fD3Q15VCEZouHe(p0, uwall[0], -uwall[2], uwall[1], &force[0], &lbf[spos], &lbf[spos+1*qdim],
                       &lbf[spos+10*qdim], &lbf[spos+2*qdim], &lbf[spos+5*qdim], &lbf[spos+7*qdim],
                       &lbf[spos+4*qdim], &lbf[spos+6*qdim], &lbf[spos+8*qdim], &lbf[spos+3*qdim],
                       &lbf[spos+9*qdim], &lbf[spos+12*qdim], &lbf[spos+14*qdim], &lbf[spos+11*qdim],
                       &lbf[spos+13*qdim]);
        break;
    }
  }
  return 0;
}


int fD3Q15PFSimpleZouHe(long tpos, int prop, double *p0, double *uwall)
{
  double moment;
  long spos=tpos * lbsitelength;
  int qdim = lbsy.nf+lbsy.nc+lbsy.nt;
  double force[3*lbsy.nf];

  // sort out forces
    
  fD3Q15BoundaryForceDensity(force, tpos, p0, prop);
    
  // apply boundary condition
  if(interact==20) {
    switch (prop) {
      case PST:
        fD3Q15PPSSwiftZouHe(p0, &force[0], &lbf[spos], &lbf[spos+1*qdim],
                            &lbf[spos+2*qdim], &lbf[spos+3*qdim], &lbf[spos+4*qdim], &lbf[spos+5*qdim],
                            &lbf[spos+6*qdim], &lbf[spos+7*qdim], &lbf[spos+8*qdim], &lbf[spos+9*qdim],
                            &lbf[spos+10*qdim], &lbf[spos+11*qdim], &lbf[spos+12*qdim], &lbf[spos+13*qdim],
                            &lbf[spos+14*qdim], moment);
        uwall[1] += moment;
        break;
      case PSD:
        fD3Q15PPSSwiftZouHe(p0, &force[0], &lbf[spos], &lbf[spos+8*qdim],
                            &lbf[spos+9*qdim], &lbf[spos+10*qdim], &lbf[spos+11*qdim], &lbf[spos+12*qdim],
                            &lbf[spos+13*qdim], &lbf[spos+14*qdim], &lbf[spos+1*qdim], &lbf[spos+2*qdim],
                            &lbf[spos+3*qdim], &lbf[spos+4*qdim], &lbf[spos+5*qdim], &lbf[spos+6*qdim],
                            &lbf[spos+7*qdim], moment);
        uwall[1] -= moment;
        break;
      case PSL:
        fD3Q15PPSSwiftZouHe(p0, &force[0], &lbf[spos], &lbf[spos+10*qdim],
                            &lbf[spos+8*qdim], &lbf[spos+9*qdim], &lbf[spos+11*qdim], &lbf[spos+13*qdim],
                            &lbf[spos+7*qdim], &lbf[spos+5*qdim], &lbf[spos+3*qdim], &lbf[spos+1*qdim],
                            &lbf[spos+2*qdim], &lbf[spos+4*qdim], &lbf[spos+6*qdim], &lbf[spos+14*qdim],
                            &lbf[spos+12*qdim], moment);
        uwall[0] -= moment;
        break;
      case PSR:
        fD3Q15PPSSwiftZouHe(p0, &force[0], &lbf[spos], &lbf[spos+3*qdim],
                            &lbf[spos+1*qdim], &lbf[spos+2*qdim], &lbf[spos+4*qdim], &lbf[spos+6*qdim],
                            &lbf[spos+14*qdim], &lbf[spos+12*qdim], &lbf[spos+10*qdim], &lbf[spos+8*qdim],
                            &lbf[spos+9*qdim], &lbf[spos+11*qdim], &lbf[spos+13*qdim], &lbf[spos+7*qdim],
                            &lbf[spos+5*qdim], moment);
        uwall[1] += moment;
        break;
      case PSF:
        fD3Q15PPSSwiftZouHe(p0, &force[0], &lbf[spos], &lbf[spos+9*qdim],
                            &lbf[spos+10*qdim], &lbf[spos+8*qdim], &lbf[spos+11*qdim], &lbf[spos+7*qdim],
                            &lbf[spos+12*qdim], &lbf[spos+6*qdim], &lbf[spos+2*qdim], &lbf[spos+3*qdim],
                            &lbf[spos+1*qdim], &lbf[spos+4*qdim], &lbf[spos+14*qdim], &lbf[spos+5*qdim],
                            &lbf[spos+13*qdim], moment);
        uwall[2] -= moment;
        break;
      case PSB:
        fD3Q15PPSSwiftZouHe(p0, &force[0], &lbf[spos], &lbf[spos+2*qdim],
                            &lbf[spos+3*qdim], &lbf[spos+1*qdim], &lbf[spos+4*qdim], &lbf[spos+14*qdim],
                            &lbf[spos+5*qdim], &lbf[spos+13*qdim], &lbf[spos+9*qdim], &lbf[spos+10*qdim],
                            &lbf[spos+8*qdim], &lbf[spos+11*qdim], &lbf[spos+7*qdim], &lbf[spos+12*qdim],
                            &lbf[spos+6*qdim], moment);
        uwall[2] += moment;
        break;
      case CCTRB:
        fD3Q15VCCSimpleZouHe(p0, uwall[0], uwall[1], -uwall[2], &force[0], &lbf[spos], &lbf[spos+1*qdim],
                             &lbf[spos+2*qdim], &lbf[spos+10*qdim], &lbf[spos+5*qdim], &lbf[spos+4*qdim],
                             &lbf[spos+7*qdim], &lbf[spos+6*qdim], &lbf[spos+8*qdim], &lbf[spos+9*qdim],
                             &lbf[spos+3*qdim], &lbf[spos+12*qdim], &lbf[spos+11*qdim], &lbf[spos+14*qdim],
                             &lbf[spos+13*qdim]);
        break;
      case CCTLB:
        fD3Q15VCCSimpleZouHe(p0, -uwall[0], uwall[1], -uwall[2], &force[0], &lbf[spos], &lbf[spos+8*qdim],
                             &lbf[spos+2*qdim], &lbf[spos+10*qdim], &lbf[spos+13*qdim], &lbf[spos+14*qdim],
                             &lbf[spos+11*qdim], &lbf[spos+12*qdim], &lbf[spos+1*qdim], &lbf[spos+9*qdim],
                             &lbf[spos+3*qdim], &lbf[spos+6*qdim], &lbf[spos+7*qdim], &lbf[spos+4*qdim],
                             &lbf[spos+5*qdim]);
        break;
      case CCDLB:
        fD3Q15VCCSimpleZouHe(p0, -uwall[0], -uwall[1], -uwall[2], &force[0], &lbf[spos], &lbf[spos+8*qdim],
                             &lbf[spos+9*qdim], &lbf[spos+10*qdim], &lbf[spos+11*qdim], &lbf[spos+12*qdim],
                             &lbf[spos+13*qdim], &lbf[spos+14*qdim], &lbf[spos+1*qdim], &lbf[spos+2*qdim],
                             &lbf[spos+3*qdim], &lbf[spos+4*qdim], &lbf[spos+5*qdim], &lbf[spos+6*qdim],
                             &lbf[spos+7*qdim]);
        break;
      case CCDRB:
        fD3Q15VCCSimpleZouHe(p0, uwall[0], -uwall[1], -uwall[2], &force[0], &lbf[spos], &lbf[spos+1*qdim],
                             &lbf[spos+9*qdim], &lbf[spos+10*qdim], &lbf[spos+7*qdim], &lbf[spos+6*qdim],
                             &lbf[spos+5*qdim], &lbf[spos+4*qdim], &lbf[spos+8*qdim], &lbf[spos+2*qdim],
                             &lbf[spos+3*qdim], &lbf[spos+14*qdim], &lbf[spos+13*qdim], &lbf[spos+12*qdim],
                             &lbf[spos+11*qdim]);
        break;
      case CCTRF:
        fD3Q15VCCSimpleZouHe(p0, uwall[0], uwall[1], uwall[2], &force[0], &lbf[spos], &lbf[spos+1*qdim],
                             &lbf[spos+2*qdim], &lbf[spos+3*qdim], &lbf[spos+4*qdim], &lbf[spos+5*qdim],
                             &lbf[spos+6*qdim], &lbf[spos+7*qdim], &lbf[spos+8*qdim], &lbf[spos+9*qdim],
                             &lbf[spos+10*qdim], &lbf[spos+11*qdim], &lbf[spos+12*qdim], &lbf[spos+13*qdim],
                             &lbf[spos+14*qdim]);
        break;
      case CCTLF:
        fD3Q15VCCSimpleZouHe(p0, -uwall[0], uwall[1], uwall[2], &force[0], &lbf[spos], &lbf[spos+8*qdim],
                             &lbf[spos+2*qdim], &lbf[spos+3*qdim], &lbf[spos+14*qdim], &lbf[spos+13*qdim],
                             &lbf[spos+12*qdim], &lbf[spos+11*qdim], &lbf[spos+1*qdim], &lbf[spos+9*qdim],
                             &lbf[spos+10*qdim], &lbf[spos+7*qdim], &lbf[spos+6*qdim], &lbf[spos+5*qdim],
                             &lbf[spos+4*qdim]);
        break;
      case CCDLF:
        fD3Q15VCCSimpleZouHe(p0, -uwall[0], -uwall[1], uwall[2], &force[0], &lbf[spos], &lbf[spos+8*qdim],
                             &lbf[spos+9*qdim], &lbf[spos+3*qdim], &lbf[spos+12*qdim], &lbf[spos+11*qdim],
                             &lbf[spos+14*qdim], &lbf[spos+13*qdim], &lbf[spos+1*qdim], &lbf[spos+2*qdim],
                             &lbf[spos+10*qdim], &lbf[spos+5*qdim], &lbf[spos+4*qdim], &lbf[spos+7*qdim],
                             &lbf[spos+6*qdim]);
        break;
      case CCDRF:
        fD3Q15VCCSimpleZouHe(p0, uwall[0], -uwall[1], uwall[2], &force[0], &lbf[spos], &lbf[spos+1*qdim],
                             &lbf[spos+9*qdim], &lbf[spos+3*qdim], &lbf[spos+6*qdim], &lbf[spos+7*qdim],
                             &lbf[spos+4*qdim], &lbf[spos+5*qdim], &lbf[spos+8*qdim], &lbf[spos+2*qdim],
                             &lbf[spos+10*qdim], &lbf[spos+13*qdim], &lbf[spos+14*qdim], &lbf[spos+11*qdim],
                             &lbf[spos+12*qdim]);
        break;
      case CETR:
        fD3Q15VCESimpleZouHe(p0, uwall[0], uwall[1], uwall[2], &force[0], &lbf[spos], &lbf[spos+1*qdim],
                             &lbf[spos+2*qdim], &lbf[spos+3*qdim], &lbf[spos+4*qdim], &lbf[spos+5*qdim],
                             &lbf[spos+6*qdim], &lbf[spos+7*qdim], &lbf[spos+8*qdim], &lbf[spos+9*qdim],
                             &lbf[spos+10*qdim], &lbf[spos+11*qdim], &lbf[spos+12*qdim], &lbf[spos+13*qdim],
                             &lbf[spos+14*qdim]);
        break;
      case CETL:
        fD3Q15VCESimpleZouHe(p0, uwall[1], -uwall[0], uwall[2], &force[0], &lbf[spos], &lbf[spos+2*qdim],
                             &lbf[spos+8*qdim], &lbf[spos+3*qdim], &lbf[spos+14*qdim], &lbf[spos+13*qdim],
                             &lbf[spos+4*qdim], &lbf[spos+5*qdim], &lbf[spos+9*qdim], &lbf[spos+1*qdim],
                             &lbf[spos+10*qdim], &lbf[spos+7*qdim], &lbf[spos+6*qdim], &lbf[spos+11*qdim],
                             &lbf[spos+12*qdim]);
        break;
      case CEDL:
        fD3Q15VCESimpleZouHe(p0, -uwall[0], -uwall[1], uwall[2], &force[0], &lbf[spos], &lbf[spos+8*qdim],
                             &lbf[spos+9*qdim], &lbf[spos+3*qdim], &lbf[spos+12*qdim], &lbf[spos+11*qdim],
                             &lbf[spos+14*qdim], &lbf[spos+13*qdim], &lbf[spos+1*qdim], &lbf[spos+2*qdim],
                             &lbf[spos+10*qdim], &lbf[spos+5*qdim], &lbf[spos+4*qdim], &lbf[spos+7*qdim],
                             &lbf[spos+6*qdim]);
        break;
      case CEDR:
        fD3Q15VCESimpleZouHe(p0, -uwall[1], uwall[0], uwall[2], &force[0], &lbf[spos], &lbf[spos+9*qdim],
                             &lbf[spos+1*qdim], &lbf[spos+3*qdim], &lbf[spos+6*qdim], &lbf[spos+7*qdim],
                             &lbf[spos+12*qdim], &lbf[spos+11*qdim], &lbf[spos+2*qdim], &lbf[spos+8*qdim],
                             &lbf[spos+10*qdim], &lbf[spos+13*qdim], &lbf[spos+14*qdim], &lbf[spos+5*qdim],
                             &lbf[spos+4*qdim]);
        break;
      case CETF:
        fD3Q15VCESimpleZouHe(p0, uwall[1], uwall[2], uwall[0], &force[0], &lbf[spos], &lbf[spos+2*qdim],
                             &lbf[spos+3*qdim], &lbf[spos+1*qdim], &lbf[spos+4*qdim], &lbf[spos+14*qdim],
                             &lbf[spos+5*qdim], &lbf[spos+13*qdim], &lbf[spos+9*qdim], &lbf[spos+10*qdim],
                             &lbf[spos+8*qdim], &lbf[spos+11*qdim], &lbf[spos+7*qdim], &lbf[spos+12*qdim],
                             &lbf[spos+6*qdim]);
        break;
      case CELF:
        fD3Q15VCESimpleZouHe(p0, -uwall[0], uwall[2], uwall[1], &force[0], &lbf[spos], &lbf[spos+8*qdim],
                             &lbf[spos+3*qdim], &lbf[spos+2*qdim], &lbf[spos+14*qdim], &lbf[spos+12*qdim],
                             &lbf[spos+13*qdim], &lbf[spos+11*qdim], &lbf[spos+1*qdim], &lbf[spos+10*qdim],
                             &lbf[spos+9*qdim], &lbf[spos+7*qdim], &lbf[spos+5*qdim], &lbf[spos+6*qdim],
                             &lbf[spos+4*qdim]);
        break;
      case CEDF:
        fD3Q15VCESimpleZouHe(p0, -uwall[1], uwall[2], uwall[0], &force[0], &lbf[spos], &lbf[spos+9*qdim],
                             &lbf[spos+3*qdim], &lbf[spos+1*qdim], &lbf[spos+6*qdim], &lbf[spos+12*qdim],
                             &lbf[spos+7*qdim], &lbf[spos+11*qdim], &lbf[spos+2*qdim], &lbf[spos+10*qdim],
                             &lbf[spos+8*qdim], &lbf[spos+13*qdim], &lbf[spos+5*qdim], &lbf[spos+14*qdim],
                             &lbf[spos+4*qdim]);
        break;
      case CERF:
        fD3Q15VCESimpleZouHe(p0, uwall[0], uwall[2], uwall[1], &force[0], &lbf[spos], &lbf[spos+1*qdim],
                             &lbf[spos+3*qdim], &lbf[spos+2*qdim], &lbf[spos+4*qdim], &lbf[spos+6*qdim],
                             &lbf[spos+5*qdim], &lbf[spos+7*qdim], &lbf[spos+8*qdim], &lbf[spos+10*qdim],
                             &lbf[spos+9*qdim], &lbf[spos+11*qdim], &lbf[spos+13*qdim], &lbf[spos+12*qdim],
                             &lbf[spos+14*qdim]);
        break;
      case CETB:
        fD3Q15VCESimpleZouHe(p0, uwall[1], -uwall[2], uwall[0], &force[0], &lbf[spos], &lbf[spos+2*qdim],
                             &lbf[spos+10*qdim], &lbf[spos+1*qdim], &lbf[spos+5*qdim], &lbf[spos+13*qdim],
                             &lbf[spos+4*qdim], &lbf[spos+14*qdim], &lbf[spos+9*qdim], &lbf[spos+3*qdim],
                             &lbf[spos+8*qdim], &lbf[spos+12*qdim], &lbf[spos+6*qdim], &lbf[spos+11*qdim],
                             &lbf[spos+7*qdim]);
        break;
      case CELB:
        fD3Q15VCESimpleZouHe(p0, -uwall[0], -uwall[2], uwall[1], &force[0], &lbf[spos], &lbf[spos+8*qdim],
                             &lbf[spos+10*qdim], &lbf[spos+2*qdim], &lbf[spos+13*qdim], &lbf[spos+11*qdim],
                             &lbf[spos+14*qdim], &lbf[spos+12*qdim], &lbf[spos+1*qdim], &lbf[spos+3*qdim],
                             &lbf[spos+9*qdim], &lbf[spos+6*qdim], &lbf[spos+4*qdim], &lbf[spos+7*qdim],
                             &lbf[spos+5*qdim]);
        break;
      case CEDB:
        fD3Q15VCESimpleZouHe(p0, -uwall[1], -uwall[2], uwall[0], &force[0], &lbf[spos], &lbf[spos+9*qdim],
                             &lbf[spos+10*qdim], &lbf[spos+1*qdim], &lbf[spos+7*qdim], &lbf[spos+11*qdim],
                             &lbf[spos+6*qdim], &lbf[spos+12*qdim], &lbf[spos+2*qdim], &lbf[spos+3*qdim],
                             &lbf[spos+8*qdim], &lbf[spos+14*qdim], &lbf[spos+4*qdim], &lbf[spos+13*qdim],
                             &lbf[spos+5*qdim]);
        break;
      case CERB:
        fD3Q15VCESimpleZouHe(p0, uwall[0], -uwall[2], uwall[1], &force[0], &lbf[spos], &lbf[spos+1*qdim],
                             &lbf[spos+10*qdim], &lbf[spos+2*qdim], &lbf[spos+5*qdim], &lbf[spos+7*qdim],
                             &lbf[spos+4*qdim], &lbf[spos+6*qdim], &lbf[spos+8*qdim], &lbf[spos+3*qdim],
                             &lbf[spos+9*qdim], &lbf[spos+12*qdim], &lbf[spos+14*qdim], &lbf[spos+11*qdim],
                             &lbf[spos+13*qdim]);
        break;
    }
  }
  else {
    switch (prop) {
      case PST:
        fD3Q15PPSZouHe(p0, &force[0], &lbf[spos], &lbf[spos+1*qdim],
                       &lbf[spos+2*qdim], &lbf[spos+3*qdim], &lbf[spos+4*qdim], &lbf[spos+5*qdim],
                       &lbf[spos+6*qdim], &lbf[spos+7*qdim], &lbf[spos+8*qdim], &lbf[spos+9*qdim],
                       &lbf[spos+10*qdim], &lbf[spos+11*qdim], &lbf[spos+12*qdim], &lbf[spos+13*qdim],
                       &lbf[spos+14*qdim], moment);
        uwall[1] += moment;
        break;
      case PSD:
        fD3Q15PPSZouHe(p0, &force[0], &lbf[spos], &lbf[spos+8*qdim],
                       &lbf[spos+9*qdim], &lbf[spos+10*qdim], &lbf[spos+11*qdim], &lbf[spos+12*qdim],
                       &lbf[spos+13*qdim], &lbf[spos+14*qdim], &lbf[spos+1*qdim], &lbf[spos+2*qdim],
                       &lbf[spos+3*qdim], &lbf[spos+4*qdim], &lbf[spos+5*qdim], &lbf[spos+6*qdim],
                       &lbf[spos+7*qdim], moment);
        uwall[1] -= moment;
        break;
      case PSL:
        fD3Q15PPSZouHe(p0, &force[0], &lbf[spos], &lbf[spos+10*qdim],
                       &lbf[spos+8*qdim], &lbf[spos+9*qdim], &lbf[spos+11*qdim], &lbf[spos+13*qdim],
                       &lbf[spos+7*qdim], &lbf[spos+5*qdim], &lbf[spos+3*qdim], &lbf[spos+1*qdim],
                       &lbf[spos+2*qdim], &lbf[spos+4*qdim], &lbf[spos+6*qdim], &lbf[spos+14*qdim],
                       &lbf[spos+12*qdim], moment);
        uwall[0] -= moment;
        break;
      case PSR:
        fD3Q15PPSZouHe(p0, &force[0], &lbf[spos], &lbf[spos+3*qdim],
                       &lbf[spos+1*qdim], &lbf[spos+2*qdim], &lbf[spos+4*qdim], &lbf[spos+6*qdim],
                       &lbf[spos+14*qdim], &lbf[spos+12*qdim], &lbf[spos+10*qdim], &lbf[spos+8*qdim],
                       &lbf[spos+9*qdim], &lbf[spos+11*qdim], &lbf[spos+13*qdim], &lbf[spos+7*qdim],
                       &lbf[spos+5*qdim], moment);
        uwall[1] += moment;
        break;
      case PSF:
        fD3Q15PPSZouHe(p0, &force[0], &lbf[spos], &lbf[spos+9*qdim],
                       &lbf[spos+10*qdim], &lbf[spos+8*qdim], &lbf[spos+11*qdim], &lbf[spos+7*qdim],
                       &lbf[spos+12*qdim], &lbf[spos+6*qdim], &lbf[spos+2*qdim], &lbf[spos+3*qdim],
                       &lbf[spos+1*qdim], &lbf[spos+4*qdim], &lbf[spos+14*qdim], &lbf[spos+5*qdim],
                       &lbf[spos+13*qdim], moment);
        uwall[2] -= moment;
        break;
      case PSB:
        fD3Q15PPSZouHe(p0, &force[0], &lbf[spos], &lbf[spos+2*qdim],
                       &lbf[spos+3*qdim], &lbf[spos+1*qdim], &lbf[spos+4*qdim], &lbf[spos+14*qdim],
                       &lbf[spos+5*qdim], &lbf[spos+13*qdim], &lbf[spos+9*qdim], &lbf[spos+10*qdim],
                       &lbf[spos+8*qdim], &lbf[spos+11*qdim], &lbf[spos+7*qdim], &lbf[spos+12*qdim],
                       &lbf[spos+6*qdim], moment);
        uwall[2] += moment;
        break;
      case CCTRB:
        fD3Q15VCCSimpleZouHe(p0, uwall[0], uwall[1], -uwall[2], &force[0], &lbf[spos], &lbf[spos+1*qdim],
                             &lbf[spos+2*qdim], &lbf[spos+10*qdim], &lbf[spos+5*qdim], &lbf[spos+4*qdim],
                             &lbf[spos+7*qdim], &lbf[spos+6*qdim], &lbf[spos+8*qdim], &lbf[spos+9*qdim],
                             &lbf[spos+3*qdim], &lbf[spos+12*qdim], &lbf[spos+11*qdim], &lbf[spos+14*qdim],
                             &lbf[spos+13*qdim]);
        break;
      case CCTLB:
        fD3Q15VCCSimpleZouHe(p0, -uwall[0], uwall[1], -uwall[2], &force[0], &lbf[spos], &lbf[spos+8*qdim],
                             &lbf[spos+2*qdim], &lbf[spos+10*qdim], &lbf[spos+13*qdim], &lbf[spos+14*qdim],
                             &lbf[spos+11*qdim], &lbf[spos+12*qdim], &lbf[spos+1*qdim], &lbf[spos+9*qdim],
                             &lbf[spos+3*qdim], &lbf[spos+6*qdim], &lbf[spos+7*qdim], &lbf[spos+4*qdim],
                             &lbf[spos+5*qdim]);
        break;
      case CCDLB:
        fD3Q15VCCSimpleZouHe(p0, -uwall[0], -uwall[1], -uwall[2], &force[0], &lbf[spos], &lbf[spos+8*qdim],
                             &lbf[spos+9*qdim], &lbf[spos+10*qdim], &lbf[spos+11*qdim], &lbf[spos+12*qdim],
                             &lbf[spos+13*qdim], &lbf[spos+14*qdim], &lbf[spos+1*qdim], &lbf[spos+2*qdim],
                             &lbf[spos+3*qdim], &lbf[spos+4*qdim], &lbf[spos+5*qdim], &lbf[spos+6*qdim],
                             &lbf[spos+7*qdim]);
        break;
      case CCDRB:
        fD3Q15VCCSimpleZouHe(p0, uwall[0], -uwall[1], -uwall[2], &force[0], &lbf[spos], &lbf[spos+1*qdim],
                             &lbf[spos+9*qdim], &lbf[spos+10*qdim], &lbf[spos+7*qdim], &lbf[spos+6*qdim],
                             &lbf[spos+5*qdim], &lbf[spos+4*qdim], &lbf[spos+8*qdim], &lbf[spos+2*qdim],
                             &lbf[spos+3*qdim], &lbf[spos+14*qdim], &lbf[spos+13*qdim], &lbf[spos+12*qdim],
                             &lbf[spos+11*qdim]);
        break;
      case CCTRF:
        fD3Q15VCCSimpleZouHe(p0, uwall[0], uwall[1], uwall[2], &force[0], &lbf[spos], &lbf[spos+1*qdim],
                             &lbf[spos+2*qdim], &lbf[spos+3*qdim], &lbf[spos+4*qdim], &lbf[spos+5*qdim],
                             &lbf[spos+6*qdim], &lbf[spos+7*qdim], &lbf[spos+8*qdim], &lbf[spos+9*qdim],
                             &lbf[spos+10*qdim], &lbf[spos+11*qdim], &lbf[spos+12*qdim], &lbf[spos+13*qdim],
                             &lbf[spos+14*qdim]);
        break;
      case CCTLF:
        fD3Q15VCCSimpleZouHe(p0, -uwall[0], uwall[1], uwall[2], &force[0], &lbf[spos], &lbf[spos+8*qdim],
                             &lbf[spos+2*qdim], &lbf[spos+3*qdim], &lbf[spos+14*qdim], &lbf[spos+13*qdim],
                             &lbf[spos+12*qdim], &lbf[spos+11*qdim], &lbf[spos+1*qdim], &lbf[spos+9*qdim],
                             &lbf[spos+10*qdim], &lbf[spos+7*qdim], &lbf[spos+6*qdim], &lbf[spos+5*qdim],
                             &lbf[spos+4*qdim]);
        break;
      case CCDLF:
        fD3Q15VCCSimpleZouHe(p0, -uwall[0], -uwall[1], uwall[2], &force[0], &lbf[spos], &lbf[spos+8*qdim],
                             &lbf[spos+9*qdim], &lbf[spos+3*qdim], &lbf[spos+12*qdim], &lbf[spos+11*qdim],
                             &lbf[spos+14*qdim], &lbf[spos+13*qdim], &lbf[spos+1*qdim], &lbf[spos+2*qdim],
                             &lbf[spos+10*qdim], &lbf[spos+5*qdim], &lbf[spos+4*qdim], &lbf[spos+7*qdim],
                             &lbf[spos+6*qdim]);
        break;
      case CCDRF:
        fD3Q15VCCSimpleZouHe(p0, uwall[0], -uwall[1], uwall[2], &force[0], &lbf[spos], &lbf[spos+1*qdim],
                             &lbf[spos+9*qdim], &lbf[spos+3*qdim], &lbf[spos+6*qdim], &lbf[spos+7*qdim],
                             &lbf[spos+4*qdim], &lbf[spos+5*qdim], &lbf[spos+8*qdim], &lbf[spos+2*qdim],
                             &lbf[spos+10*qdim], &lbf[spos+13*qdim], &lbf[spos+14*qdim], &lbf[spos+11*qdim],
                             &lbf[spos+12*qdim]);
        break;
      case CETR:
        fD3Q15VCESimpleZouHe(p0, uwall[0], uwall[1], uwall[2], &force[0], &lbf[spos], &lbf[spos+1*qdim],
                             &lbf[spos+2*qdim], &lbf[spos+3*qdim], &lbf[spos+4*qdim], &lbf[spos+5*qdim],
                             &lbf[spos+6*qdim], &lbf[spos+7*qdim], &lbf[spos+8*qdim], &lbf[spos+9*qdim],
                             &lbf[spos+10*qdim], &lbf[spos+11*qdim], &lbf[spos+12*qdim], &lbf[spos+13*qdim],
                             &lbf[spos+14*qdim]);
        break;
      case CETL:
        fD3Q15VCESimpleZouHe(p0, uwall[1], -uwall[0], uwall[2], &force[0], &lbf[spos], &lbf[spos+2*qdim],
                             &lbf[spos+8*qdim], &lbf[spos+3*qdim], &lbf[spos+14*qdim], &lbf[spos+13*qdim],
                             &lbf[spos+4*qdim], &lbf[spos+5*qdim], &lbf[spos+9*qdim], &lbf[spos+1*qdim],
                             &lbf[spos+10*qdim], &lbf[spos+7*qdim], &lbf[spos+6*qdim], &lbf[spos+11*qdim],
                             &lbf[spos+12*qdim]);
        break;
      case CEDL:
        fD3Q15VCESimpleZouHe(p0, -uwall[0], -uwall[1], uwall[2], &force[0], &lbf[spos], &lbf[spos+8*qdim],
                             &lbf[spos+9*qdim], &lbf[spos+3*qdim], &lbf[spos+12*qdim], &lbf[spos+11*qdim],
                             &lbf[spos+14*qdim], &lbf[spos+13*qdim], &lbf[spos+1*qdim], &lbf[spos+2*qdim],
                             &lbf[spos+10*qdim], &lbf[spos+5*qdim], &lbf[spos+4*qdim], &lbf[spos+7*qdim],
                             &lbf[spos+6*qdim]);
        break;
      case CEDR:
        fD3Q15VCESimpleZouHe(p0, -uwall[1], uwall[0], uwall[2], &force[0], &lbf[spos], &lbf[spos+9*qdim],
                             &lbf[spos+1*qdim], &lbf[spos+3*qdim], &lbf[spos+6*qdim], &lbf[spos+7*qdim],
                             &lbf[spos+12*qdim], &lbf[spos+11*qdim], &lbf[spos+2*qdim], &lbf[spos+8*qdim],
                             &lbf[spos+10*qdim], &lbf[spos+13*qdim], &lbf[spos+14*qdim], &lbf[spos+5*qdim],
                             &lbf[spos+4*qdim]);
        break;
      case CETF:
        fD3Q15VCESimpleZouHe(p0, uwall[1], uwall[2], uwall[0], &force[0], &lbf[spos], &lbf[spos+2*qdim],
                             &lbf[spos+3*qdim], &lbf[spos+1*qdim], &lbf[spos+4*qdim], &lbf[spos+14*qdim],
                             &lbf[spos+5*qdim], &lbf[spos+13*qdim], &lbf[spos+9*qdim], &lbf[spos+10*qdim],
                             &lbf[spos+8*qdim], &lbf[spos+11*qdim], &lbf[spos+7*qdim], &lbf[spos+12*qdim],
                             &lbf[spos+6*qdim]);
        break;
      case CELF:
        fD3Q15VCESimpleZouHe(p0, -uwall[0], uwall[2], uwall[1], &force[0], &lbf[spos], &lbf[spos+8*qdim],
                             &lbf[spos+3*qdim], &lbf[spos+2*qdim], &lbf[spos+14*qdim], &lbf[spos+12*qdim],
                             &lbf[spos+13*qdim], &lbf[spos+11*qdim], &lbf[spos+1*qdim], &lbf[spos+10*qdim],
                             &lbf[spos+9*qdim], &lbf[spos+7*qdim], &lbf[spos+5*qdim], &lbf[spos+6*qdim],
                             &lbf[spos+4*qdim]);
        break;
      case CEDF:
        fD3Q15VCESimpleZouHe(p0, -uwall[1], uwall[2], uwall[0], &force[0], &lbf[spos], &lbf[spos+9*qdim],
                             &lbf[spos+3*qdim], &lbf[spos+1*qdim], &lbf[spos+6*qdim], &lbf[spos+12*qdim],
                             &lbf[spos+7*qdim], &lbf[spos+11*qdim], &lbf[spos+2*qdim], &lbf[spos+10*qdim],
                             &lbf[spos+8*qdim], &lbf[spos+13*qdim], &lbf[spos+5*qdim], &lbf[spos+14*qdim],
                             &lbf[spos+4*qdim]);
        break;
      case CERF:
        fD3Q15VCESimpleZouHe(p0, uwall[0], uwall[2], uwall[1], &force[0], &lbf[spos], &lbf[spos+1*qdim],
                             &lbf[spos+3*qdim], &lbf[spos+2*qdim], &lbf[spos+4*qdim], &lbf[spos+6*qdim],
                             &lbf[spos+5*qdim], &lbf[spos+7*qdim], &lbf[spos+8*qdim], &lbf[spos+10*qdim],
                             &lbf[spos+9*qdim], &lbf[spos+11*qdim], &lbf[spos+13*qdim], &lbf[spos+12*qdim],
                             &lbf[spos+14*qdim]);
        break;
      case CETB:
        fD3Q15VCESimpleZouHe(p0, uwall[1], -uwall[2], uwall[0], &force[0], &lbf[spos], &lbf[spos+2*qdim],
                             &lbf[spos+10*qdim], &lbf[spos+1*qdim], &lbf[spos+5*qdim], &lbf[spos+13*qdim],
                             &lbf[spos+4*qdim], &lbf[spos+14*qdim], &lbf[spos+9*qdim], &lbf[spos+3*qdim],
                             &lbf[spos+8*qdim], &lbf[spos+12*qdim], &lbf[spos+6*qdim], &lbf[spos+11*qdim],
                             &lbf[spos+7*qdim]);
        break;
      case CELB:
        fD3Q15VCESimpleZouHe(p0, -uwall[0], -uwall[2], uwall[1], &force[0], &lbf[spos], &lbf[spos+8*qdim],
                             &lbf[spos+10*qdim], &lbf[spos+2*qdim], &lbf[spos+13*qdim], &lbf[spos+11*qdim],
                             &lbf[spos+14*qdim], &lbf[spos+12*qdim], &lbf[spos+1*qdim], &lbf[spos+3*qdim],
                             &lbf[spos+9*qdim], &lbf[spos+6*qdim], &lbf[spos+4*qdim], &lbf[spos+7*qdim],
                             &lbf[spos+5*qdim]);
        break;
      case CEDB:
        fD3Q15VCESimpleZouHe(p0, -uwall[1], -uwall[2], uwall[0], &force[0], &lbf[spos], &lbf[spos+9*qdim],
                             &lbf[spos+10*qdim], &lbf[spos+1*qdim], &lbf[spos+7*qdim], &lbf[spos+11*qdim],
                             &lbf[spos+6*qdim], &lbf[spos+12*qdim], &lbf[spos+2*qdim], &lbf[spos+3*qdim],
                             &lbf[spos+8*qdim], &lbf[spos+14*qdim], &lbf[spos+4*qdim], &lbf[spos+13*qdim],
                             &lbf[spos+5*qdim]);
        break;
      case CERB:
        fD3Q15VCESimpleZouHe(p0, uwall[0], -uwall[2], uwall[1], &force[0], &lbf[spos], &lbf[spos+1*qdim],
                             &lbf[spos+10*qdim], &lbf[spos+2*qdim], &lbf[spos+5*qdim], &lbf[spos+7*qdim],
                             &lbf[spos+4*qdim], &lbf[spos+6*qdim], &lbf[spos+8*qdim], &lbf[spos+3*qdim],
                             &lbf[spos+9*qdim], &lbf[spos+12*qdim], &lbf[spos+14*qdim], &lbf[spos+11*qdim],
                             &lbf[spos+13*qdim]);
        break;
    }
  }
  return 0;
}


int fD3Q15CPSZouHe(double *p, double v0, double v1, double v2, double *f0, double *f1,
	               double *f2, double *f3, double *f4, double *f5, double *f6,
                   double *f7, double *f8, double *f9, double *f10, double *f11,
                   double *f12, double *f13, double *f14)
{

  // produce fixed concentration at planar surface: expressed for bottom wall (CPST)

  double c1=1.0/3.0,c2=1.0/12.0;

  for(int i=0; i<lbsy.nc; i++) {
    f6[i]=f13[i]-c2*p[i]*(v0-v1+v2);
    f7[i]=f14[i]-c2*p[i]*(v0-v1-v2);
    f9[i]=p[i]*(1.0-c1*v1)-f0[i]-f1[i]-f2[i]-f3[i]-f7[i]-f8[i]-f10[i]-2.0*(f4[i]+f5[i]+f13[i]+f14[i]);
    f11[i]=f4[i]+c2*p[i]*(v0+v1+v2);
    f12[i]=f5[i]+c2*p[i]*(v0+v1-v2);
  }
  
  return 0;
}

int fD3Q15CCEZouHe(double *p, double v0, double v1, double v2, double *f0, double *f1,
	               double *f2, double *f3, double *f4, double *f5, double *f6,
                   double *f7, double *f8, double *f9, double *f10, double *f11,
                   double *f12, double *f13, double *f14)
{

  // produce fixed concentration at concave edge: expressed for bottom left edge (CCETR)

  double q0, qxy, nz;
  double c1=2.0/3.0,c2=1.0/12.0,c3=1.0/24.0,c4=5.0/24.0,c5=1.0/6.0,c6=5.0/36.0;

  for(int i=0; i<lbsy.nc; i++) {
    q0 = 0.25*(p[i]-f0[i]-f3[i]-f10[i])-0.5*(f1[i]+f2[i]+f4[i]+f5[i])-c4*p[i]*(v0+v1);
    qxy = c3*p[i]*(v0-v1);
    nz = c5*(f10[i]-f3[i])-c6*p[i]*v2;
    f6[i]=q0-qxy+nz;
    f7[i]=q0-qxy-nz;
    f8[i]=f1[i]+c1*p[i]*v0;
    f9[i]=f2[i]+c1*p[i]*v1;
    f11[i]=f4[i]+c2*p[i]*(v0+v1+v2)-nz;
    f12[i]=f5[i]+c2*p[i]*(v0+v1-v2)+nz;
    f13[i]=q0+qxy-nz;
    f14[i]=q0+qxy+nz;
  }
  
  return 0;
}

int fD3Q15CCCZouHe(double *p, double v0, double v1, double v2, double *f0, double *f1,
	               double *f2, double *f3, double *f4, double *f5, double *f6,
                   double *f7, double *f8, double *f9, double *f10, double *f11,
                   double *f12, double *f13, double *f14)
{

  // produce fixed concentration at concave corner: expressed for bottom left back corner (CCCTRF)

  double q0, qx, qy, qz;
  double c1=2.0/3.0,c2=1.0/12.0,c3=1.0/24.0,c5=1.0/6.0,c7=1.0/3.0;

  for(int i=0; i<lbsy.nc; i++) {
    q0 = c5*(p[i]-f0[i])-c7*(f1[i]+f2[i]+f4[i]+f5[i])-0.125*p[i]*(v0+v1+v2);
    qx = c3*p[i]*v0;
    qy = c3*p[i]*v1;
    qz = c3*p[i]*v2;
    f5[i]=q0-qx-qy+qz;
    f6[i]=q0-qx+qy-qz;
    f7[i]=q0-qx+qy+qz;
    f8[i]=f1[i]+c1*p[i]*v0;
    f9[i]=f2[i]+c1*p[i]*v1;
    f10[i]=f3[i]+c1*p[i]*v2;
    f11[i]=f4[i]+c2*p[i]*(v0+v1+v2);
    f12[i]=q0+qx+qy-qz;
    f13[i]=q0+qx-qy+qz;
    f14[i]=q0+qx-qy-qz;
  }
  
  return 0;
}


int fD3Q15PCZouHe(long tpos, int prop, double *p0, double *uwall)
{
  long spos=tpos * lbsitelength + lbsy.nf;
  int qdim=lbsy.nf+lbsy.nc+lbsy.nt;
    
  switch (prop) {
    case PST:
      fD3Q15CPSZouHe(p0, uwall[0], uwall[1], uwall[2], &lbf[spos], &lbf[spos+1*qdim],
                     &lbf[spos+2*qdim], &lbf[spos+3*qdim], &lbf[spos+4*qdim], &lbf[spos+5*qdim], &lbf[spos+6*qdim],
                     &lbf[spos+7*qdim], &lbf[spos+8*qdim], &lbf[spos+9*qdim], &lbf[spos+10*qdim], &lbf[spos+11*qdim],
                     &lbf[spos+12*qdim], &lbf[spos+13*qdim], &lbf[spos+14*qdim]);
      break;
    case PSD:
      fD3Q15CPSZouHe(p0, -uwall[0], -uwall[1], -uwall[2], &lbf[spos], &lbf[spos+8*qdim],
                     &lbf[spos+9*qdim], &lbf[spos+10*qdim], &lbf[spos+11*qdim], &lbf[spos+12*qdim], &lbf[spos+13*qdim],
                     &lbf[spos+14*qdim], &lbf[spos+1*qdim], &lbf[spos+2*qdim], &lbf[spos+3*qdim], &lbf[spos+4*qdim],
                     &lbf[spos+5*qdim], &lbf[spos+6*qdim], &lbf[spos+7*qdim]);
      break;
    case PSL:
      fD3Q15CPSZouHe(p0, -uwall[2], -uwall[0], -uwall[1], &lbf[spos], &lbf[spos+10*qdim],
                     &lbf[spos+8*qdim], &lbf[spos+9*qdim], &lbf[spos+11*qdim], &lbf[spos+13*qdim], &lbf[spos+7*qdim],
                     &lbf[spos+5*qdim], &lbf[spos+3*qdim], &lbf[spos+1*qdim], &lbf[spos+2*qdim], &lbf[spos+4*qdim],
                     &lbf[spos+6*qdim], &lbf[spos+14*qdim], &lbf[spos+12*qdim]);
      break;
    case PSR:
      fD3Q15CPSZouHe(p0, uwall[2], uwall[0], uwall[1], &lbf[spos], &lbf[spos+10*qdim],
		             &lbf[spos+8*qdim], &lbf[spos+9*qdim], &lbf[spos+11*qdim], &lbf[spos+13*qdim], &lbf[spos+7*qdim],
                     &lbf[spos+5*qdim], &lbf[spos+3*qdim], &lbf[spos+1*qdim], &lbf[spos+2*qdim], &lbf[spos+4*qdim],
                     &lbf[spos+6*qdim], &lbf[spos+14*qdim], &lbf[spos+12*qdim]);
      break;
    case PSF:
      fD3Q15CPSZouHe(p0, -uwall[1], -uwall[2], -uwall[0], &lbf[spos], &lbf[spos+9*qdim],
		             &lbf[spos+10*qdim], &lbf[spos+8*qdim], &lbf[spos+11*qdim], &lbf[spos+7*qdim], &lbf[spos+12*qdim],
                     &lbf[spos+6*qdim], &lbf[spos+2*qdim], &lbf[spos+3*qdim], &lbf[spos+1*qdim], &lbf[spos+4*qdim],
                     &lbf[spos+14*qdim], &lbf[spos+5*qdim], &lbf[spos+13*qdim]);
      break;
    case PSB:
      fD3Q15CPSZouHe(p0, uwall[1], uwall[2], uwall[0], &lbf[spos], &lbf[spos+2*qdim],
		             &lbf[spos+3*qdim], &lbf[spos+1*qdim], &lbf[spos+4*qdim], &lbf[spos+14*qdim], &lbf[spos+5*qdim],
                     &lbf[spos+13*qdim], &lbf[spos+9*qdim], &lbf[spos+10*qdim], &lbf[spos+8*qdim], &lbf[spos+11*qdim],
                     &lbf[spos+7*qdim], &lbf[spos+12*qdim], &lbf[spos+6*qdim]);
      break;
    case CCTRB:
      fD3Q15CCCZouHe(p0, uwall[0], uwall[1], -uwall[2], &lbf[spos], &lbf[spos+1*qdim],
                     &lbf[spos+2*qdim], &lbf[spos+10*qdim], &lbf[spos+5*qdim], &lbf[spos+4*qdim],
                     &lbf[spos+7*qdim], &lbf[spos+6*qdim], &lbf[spos+8*qdim], &lbf[spos+9*qdim],
                     &lbf[spos+3*qdim], &lbf[spos+12*qdim], &lbf[spos+11*qdim], &lbf[spos+14*qdim],
                     &lbf[spos+13*qdim]);
      break;
    case CCTLB:
      fD3Q15CCCZouHe(p0, -uwall[0], uwall[1], -uwall[2], &lbf[spos], &lbf[spos+8*qdim],
                     &lbf[spos+2*qdim], &lbf[spos+10*qdim], &lbf[spos+13*qdim], &lbf[spos+14*qdim],
                     &lbf[spos+11*qdim], &lbf[spos+12*qdim], &lbf[spos+1*qdim], &lbf[spos+9*qdim],
                     &lbf[spos+3*qdim], &lbf[spos+6*qdim], &lbf[spos+7*qdim], &lbf[spos+4*qdim],
                     &lbf[spos+5*qdim]);
      break;
    case CCDLB:
      fD3Q15CCCZouHe(p0, -uwall[0], -uwall[1], -uwall[2], &lbf[spos], &lbf[spos+8*qdim],
                     &lbf[spos+9*qdim], &lbf[spos+10*qdim], &lbf[spos+11*qdim], &lbf[spos+12*qdim],
                     &lbf[spos+13*qdim], &lbf[spos+14*qdim], &lbf[spos+1*qdim], &lbf[spos+2*qdim],
                     &lbf[spos+3*qdim], &lbf[spos+4*qdim], &lbf[spos+5*qdim], &lbf[spos+6*qdim],
                     &lbf[spos+7*qdim]);
      break;
    case CCDRB:
      fD3Q15CCCZouHe(p0, uwall[0], -uwall[1], -uwall[2], &lbf[spos], &lbf[spos+1*qdim],
                     &lbf[spos+9*qdim], &lbf[spos+10*qdim], &lbf[spos+7*qdim], &lbf[spos+6*qdim],
                     &lbf[spos+5*qdim], &lbf[spos+4*qdim], &lbf[spos+8*qdim], &lbf[spos+2*qdim],
                     &lbf[spos+3*qdim], &lbf[spos+14*qdim], &lbf[spos+13*qdim], &lbf[spos+12*qdim],
                     &lbf[spos+11*qdim]);
      break;
    case CCTRF:
      fD3Q15CCCZouHe(p0, uwall[0], uwall[1], uwall[2], &lbf[spos], &lbf[spos+1*qdim],
                     &lbf[spos+2*qdim], &lbf[spos+3*qdim], &lbf[spos+4*qdim], &lbf[spos+5*qdim],
                     &lbf[spos+6*qdim], &lbf[spos+7*qdim], &lbf[spos+8*qdim], &lbf[spos+9*qdim],
                     &lbf[spos+10*qdim], &lbf[spos+11*qdim], &lbf[spos+12*qdim], &lbf[spos+13*qdim],
                     &lbf[spos+14*qdim]);
      break;
    case CCTLF:
      fD3Q15CCCZouHe(p0, -uwall[0], uwall[1], uwall[2], &lbf[spos], &lbf[spos+8*qdim],
                     &lbf[spos+2*qdim], &lbf[spos+3*qdim], &lbf[spos+14*qdim], &lbf[spos+13*qdim],
                     &lbf[spos+12*qdim], &lbf[spos+11*qdim], &lbf[spos+1*qdim], &lbf[spos+9*qdim],
                     &lbf[spos+10*qdim], &lbf[spos+7*qdim], &lbf[spos+6*qdim], &lbf[spos+5*qdim],
                     &lbf[spos+4*qdim]);
      break;
    case CCDLF:
      fD3Q15CCCZouHe(p0, -uwall[0], -uwall[1], uwall[2], &lbf[spos], &lbf[spos+8*qdim],
                     &lbf[spos+9*qdim], &lbf[spos+3*qdim], &lbf[spos+12*qdim], &lbf[spos+11*qdim],
                     &lbf[spos+14*qdim], &lbf[spos+13*qdim], &lbf[spos+1*qdim], &lbf[spos+2*qdim],
                     &lbf[spos+10*qdim], &lbf[spos+5*qdim], &lbf[spos+4*qdim], &lbf[spos+7*qdim],
                     &lbf[spos+6*qdim]);
      break;
    case CCDRF:
      fD3Q15CCCZouHe(p0, uwall[0], -uwall[1], uwall[2], &lbf[spos], &lbf[spos+1*qdim],
                     &lbf[spos+9*qdim], &lbf[spos+3*qdim], &lbf[spos+6*qdim], &lbf[spos+7*qdim],
                     &lbf[spos+4*qdim], &lbf[spos+5*qdim], &lbf[spos+8*qdim], &lbf[spos+2*qdim],
                     &lbf[spos+10*qdim], &lbf[spos+13*qdim], &lbf[spos+14*qdim], &lbf[spos+11*qdim],
                     &lbf[spos+12*qdim]);
      break;
    case CETR:
      fD3Q15CCEZouHe(p0, uwall[0], uwall[1], uwall[2], &lbf[spos], &lbf[spos+1*qdim],
                     &lbf[spos+2*qdim], &lbf[spos+3*qdim], &lbf[spos+4*qdim], &lbf[spos+5*qdim],
                     &lbf[spos+6*qdim], &lbf[spos+7*qdim], &lbf[spos+8*qdim], &lbf[spos+9*qdim],
                     &lbf[spos+10*qdim], &lbf[spos+11*qdim], &lbf[spos+12*qdim], &lbf[spos+13*qdim],
                     &lbf[spos+14*qdim]);
      break;
    case CETL:
      fD3Q15CCEZouHe(p0, uwall[1], -uwall[0], uwall[2], &lbf[spos], &lbf[spos+2*qdim],
                     &lbf[spos+8*qdim], &lbf[spos+3*qdim], &lbf[spos+14*qdim], &lbf[spos+13*qdim],
                     &lbf[spos+4*qdim], &lbf[spos+5*qdim], &lbf[spos+9*qdim], &lbf[spos+1*qdim],
                     &lbf[spos+10*qdim], &lbf[spos+7*qdim], &lbf[spos+6*qdim], &lbf[spos+11*qdim],
                     &lbf[spos+12*qdim]);
      break;
    case CEDL:
      fD3Q15CCEZouHe(p0, -uwall[0], -uwall[1], uwall[2], &lbf[spos], &lbf[spos+8*qdim],
                     &lbf[spos+9*qdim], &lbf[spos+3*qdim], &lbf[spos+12*qdim], &lbf[spos+11*qdim],
                     &lbf[spos+14*qdim], &lbf[spos+13*qdim], &lbf[spos+1*qdim], &lbf[spos+2*qdim],
                     &lbf[spos+10*qdim], &lbf[spos+5*qdim], &lbf[spos+4*qdim], &lbf[spos+7*qdim],
                     &lbf[spos+6*qdim]);
      break;
    case CEDR:
      fD3Q15CCEZouHe(p0, -uwall[1], uwall[0], uwall[2], &lbf[spos], &lbf[spos+9*qdim],
                     &lbf[spos+1*qdim], &lbf[spos+3*qdim], &lbf[spos+6*qdim], &lbf[spos+7*qdim],
                     &lbf[spos+12*qdim], &lbf[spos+11*qdim], &lbf[spos+2*qdim], &lbf[spos+8*qdim],
                     &lbf[spos+10*qdim], &lbf[spos+13*qdim], &lbf[spos+14*qdim], &lbf[spos+5*qdim],
                     &lbf[spos+4*qdim]);
      break;
    case CETF:
      fD3Q15CCEZouHe(p0, uwall[1], uwall[2], uwall[0], &lbf[spos], &lbf[spos+2*qdim],
                     &lbf[spos+3*qdim], &lbf[spos+1*qdim], &lbf[spos+4*qdim], &lbf[spos+14*qdim],
                     &lbf[spos+5*qdim], &lbf[spos+13*qdim], &lbf[spos+9*qdim], &lbf[spos+10*qdim],
                     &lbf[spos+8*qdim], &lbf[spos+11*qdim], &lbf[spos+7*qdim], &lbf[spos+12*qdim],
                     &lbf[spos+6*qdim]);
      break;
    case CELF:
      fD3Q15CCEZouHe(p0, -uwall[0], uwall[2], uwall[1], &lbf[spos], &lbf[spos+8*qdim],
                     &lbf[spos+3*qdim], &lbf[spos+2*qdim], &lbf[spos+14*qdim], &lbf[spos+12*qdim],
                     &lbf[spos+13*qdim], &lbf[spos+11*qdim], &lbf[spos+1*qdim], &lbf[spos+10*qdim],
                     &lbf[spos+9*qdim], &lbf[spos+7*qdim], &lbf[spos+5*qdim], &lbf[spos+6*qdim],
                     &lbf[spos+4*qdim]);
      break;
    case CEDF:
      fD3Q15CCEZouHe(p0, -uwall[1], uwall[2], uwall[0], &lbf[spos], &lbf[spos+9*qdim],
                     &lbf[spos+3*qdim], &lbf[spos+1*qdim], &lbf[spos+6*qdim], &lbf[spos+12*qdim],
                     &lbf[spos+7*qdim], &lbf[spos+11*qdim], &lbf[spos+2*qdim], &lbf[spos+10*qdim],
                     &lbf[spos+8*qdim], &lbf[spos+13*qdim], &lbf[spos+5*qdim], &lbf[spos+14*qdim],
                     &lbf[spos+4*qdim]);
      break;
    case CERF:
      fD3Q15CCEZouHe(p0, uwall[0], uwall[2], uwall[1], &lbf[spos], &lbf[spos+1*qdim],
                     &lbf[spos+3*qdim], &lbf[spos+2*qdim], &lbf[spos+4*qdim], &lbf[spos+6*qdim],
                     &lbf[spos+5*qdim], &lbf[spos+7*qdim], &lbf[spos+8*qdim], &lbf[spos+10*qdim],
                     &lbf[spos+9*qdim], &lbf[spos+11*qdim], &lbf[spos+13*qdim], &lbf[spos+12*qdim],
                     &lbf[spos+14*qdim]);
      break;
    case CETB:
      fD3Q15CCEZouHe(p0, uwall[1], -uwall[2], uwall[0], &lbf[spos], &lbf[spos+2*qdim],
                     &lbf[spos+10*qdim], &lbf[spos+1*qdim], &lbf[spos+5*qdim], &lbf[spos+13*qdim],
                     &lbf[spos+4*qdim], &lbf[spos+14*qdim], &lbf[spos+9*qdim], &lbf[spos+3*qdim],
                     &lbf[spos+8*qdim], &lbf[spos+12*qdim], &lbf[spos+6*qdim], &lbf[spos+11*qdim],
                     &lbf[spos+7*qdim]);
      break;
    case CELB:
      fD3Q15CCEZouHe(p0, -uwall[0], -uwall[2], uwall[1], &lbf[spos], &lbf[spos+8*qdim],
                     &lbf[spos+10*qdim], &lbf[spos+2*qdim], &lbf[spos+13*qdim], &lbf[spos+11*qdim],
                     &lbf[spos+14*qdim], &lbf[spos+12*qdim], &lbf[spos+1*qdim], &lbf[spos+3*qdim],
                     &lbf[spos+9*qdim], &lbf[spos+6*qdim], &lbf[spos+4*qdim], &lbf[spos+7*qdim],
                     &lbf[spos+5*qdim]);
      break;
    case CEDB:
      fD3Q15CCEZouHe(p0, -uwall[1], -uwall[2], uwall[0], &lbf[spos], &lbf[spos+9*qdim],
                     &lbf[spos+10*qdim], &lbf[spos+1*qdim], &lbf[spos+7*qdim], &lbf[spos+11*qdim],
                     &lbf[spos+6*qdim], &lbf[spos+12*qdim], &lbf[spos+2*qdim], &lbf[spos+3*qdim],
                     &lbf[spos+8*qdim], &lbf[spos+14*qdim], &lbf[spos+4*qdim], &lbf[spos+13*qdim],
                     &lbf[spos+5*qdim]);
      break;
    case CERB:
      fD3Q15CCEZouHe(p0, uwall[0], -uwall[2], uwall[1], &lbf[spos], &lbf[spos+1*qdim],
                     &lbf[spos+10*qdim], &lbf[spos+2*qdim], &lbf[spos+5*qdim], &lbf[spos+7*qdim],
                     &lbf[spos+4*qdim], &lbf[spos+6*qdim], &lbf[spos+8*qdim], &lbf[spos+3*qdim],
                     &lbf[spos+9*qdim], &lbf[spos+12*qdim], &lbf[spos+14*qdim], &lbf[spos+11*qdim],
                     &lbf[spos+13*qdim]);
      break;
  }
  return 0;  
}


int fD3Q15TPSZouHe(double p, double v0, double v1, double v2, double *f0, double *f1,
	               double *f2, double *f3, double *f4, double *f5, double *f6,
                   double *f7, double *f8, double *f9, double *f10, double *f11,
                   double *f12, double *f13, double *f14)
{

  // produce fixed temperature at planar surface: expressed for bottom wall

  double c1=1.0/3.0,c2=1.0/12.0;

  f6[0]=f13[0]-c2*p*(v0-v1+v2);
  f7[0]=f14[0]-c2*p*(v0-v1-v2);
  f9[0]=p*(1.0-c1*v1)-f0[0]-f1[0]-f2[0]-f3[0]-f7[0]-f8[0]-f10[0]-2.0*(f4[0]+f5[0]+f13[0]+f14[0]);
  f11[0]=f4[0]+c2*p*(v0+v1+v2);
  f12[0]=f5[0]+c2*p*(v0+v1-v2);
  
  return 0;
}

int fD3Q15TCEZouHe(double p, double v0, double v1, double v2, double *f0, double *f1,
	               double *f2, double *f3, double *f4, double *f5, double *f6,
                   double *f7, double *f8, double *f9, double *f10, double *f11,
                   double *f12, double *f13, double *f14)
{

  // produce fixed temperature at concave edge: expressed for bottom left edge (TCETR)

  double q0, qxy, nz;
  double c1=2.0/3.0,c2=1.0/12.0,c3=1.0/24.0,c4=5.0/24.0,c5=1.0/6.0,c6=5.0/36.0;

  q0 = 0.25*(p-f0[0]-f3[0]-f10[0])-0.5*(f1[0]+f2[0]+f4[0]+f5[0])-c4*p*(v0+v1);
  qxy = c3*p*(v0-v1);
  nz = c5*(f10[0]-f3[0])-c6*p*v2;
  f6[0]=q0-qxy+nz;
  f7[0]=q0-qxy-nz;
  f8[0]=f1[0]+c1*p*v0;
  f9[0]=f2[0]+c1*p*v1;
  f11[0]=f4[0]+c2*p*(v0+v1+v2)-nz;
  f12[0]=f5[0]+c2*p*(v0+v1-v2)+nz;
  f13[0]=q0+qxy-nz;
  f14[0]=q0+qxy+nz;
  
  return 0;
}

int fD3Q15TCCZouHe(double p, double v0, double v1, double v2, double *f0, double *f1,
	               double *f2, double *f3, double *f4, double *f5, double *f6,
                   double *f7, double *f8, double *f9, double *f10, double *f11,
                   double *f12, double *f13, double *f14)
{

  // produce fixed temperature at concave corner: expressed for bottom left back corner (TCCTRF)

  double q0, qx, qy, qz;
  double c1=2.0/3.0,c2=1.0/12.0,c3=1.0/24.0,c5=1.0/6.0,c7=1.0/3.0;

  q0 = c5*(p-f0[0])-c7*(f1[0]+f2[0]+f4[0]+f5[0])-0.125*p*(v0+v1+v2);
  qx = c3*p*v0;
  qy = c3*p*v1;
  qz = c3*p*v2;
  f5[0]=q0-qx-qy+qz;
  f6[0]=q0-qx+qy-qz;
  f7[0]=q0-qx+qy+qz;
  f8[0]=f1[0]+c1*p*v0;
  f9[0]=f2[0]+c1*p*v1;
  f10[0]=f3[0]+c1*p*v2;
  f11[0]=f4[0]+c2*p*(v0+v1+v2);
  f12[0]=q0+qx+qy-qz;
  f13[0]=q0+qx-qy+qz;
  f14[0]=q0+qx-qy-qz;
  
  return 0;
}


int fD3Q15PTZouHe(long tpos, int prop, double p0, double *uwall)
{
  long spos=tpos * lbsitelength + lbsy.nf + lbsy.nc;
  int qdim = lbsy.nf+lbsy.nc+lbsy.nt;
    
  switch (prop) {
    case PST:
      fD3Q15TPSZouHe(p0, uwall[0], uwall[1], uwall[2], &lbf[spos], &lbf[spos+1*qdim],
                     &lbf[spos+2*qdim], &lbf[spos+3*qdim], &lbf[spos+4*qdim], &lbf[spos+5*qdim], &lbf[spos+6*qdim],
                     &lbf[spos+7*qdim], &lbf[spos+8*qdim], &lbf[spos+9*qdim], &lbf[spos+10*qdim], &lbf[spos+11*qdim],
                     &lbf[spos+12*qdim], &lbf[spos+13*qdim], &lbf[spos+14*qdim]);
      break;
    case PSD:
      fD3Q15TPSZouHe(p0, -uwall[0], -uwall[1], -uwall[2], &lbf[spos], &lbf[spos+8*qdim],
  	  	             &lbf[spos+9*qdim], &lbf[spos+10*qdim], &lbf[spos+11*qdim], &lbf[spos+12*qdim], &lbf[spos+13*qdim],
                     &lbf[spos+14*qdim], &lbf[spos+1*qdim], &lbf[spos+2*qdim], &lbf[spos+3*qdim], &lbf[spos+4*qdim],
                     &lbf[spos+5*qdim], &lbf[spos+6*qdim], &lbf[spos+7*qdim]);
      break;
    case PSL:
      fD3Q15TPSZouHe(p0, -uwall[2], -uwall[0], -uwall[1], &lbf[spos], &lbf[spos+10*qdim],
		             &lbf[spos+8*qdim], &lbf[spos+9*qdim], &lbf[spos+11*qdim], &lbf[spos+13*qdim], &lbf[spos+7*qdim],
                     &lbf[spos+5*qdim], &lbf[spos+3*qdim], &lbf[spos+1*qdim], &lbf[spos+2*qdim], &lbf[spos+4*qdim],
                     &lbf[spos+6*qdim], &lbf[spos+14*qdim], &lbf[spos+12*qdim]);
      break;
    case PSR:
      fD3Q15TPSZouHe(p0, uwall[2], uwall[0], uwall[1], &lbf[spos], &lbf[spos+10*qdim],
		             &lbf[spos+8*qdim], &lbf[spos+9*qdim], &lbf[spos+11*qdim], &lbf[spos+13*qdim], &lbf[spos+7*qdim],
                     &lbf[spos+5*qdim], &lbf[spos+3*qdim], &lbf[spos+1*qdim], &lbf[spos+2*qdim], &lbf[spos+4*qdim],
                     &lbf[spos+6*qdim], &lbf[spos+14*qdim], &lbf[spos+12*qdim]);
      break;
    case PSF:
      fD3Q15TPSZouHe(p0, -uwall[1], -uwall[2], -uwall[0], &lbf[spos], &lbf[spos+9*qdim],
	                 &lbf[spos+10*qdim], &lbf[spos+8*qdim], &lbf[spos+11*qdim], &lbf[spos+7*qdim], &lbf[spos+12*qdim],
                     &lbf[spos+6*qdim], &lbf[spos+2*qdim], &lbf[spos+3*qdim], &lbf[spos+1*qdim], &lbf[spos+4*qdim],
                     &lbf[spos+14*qdim], &lbf[spos+5*qdim], &lbf[spos+13*qdim]);
      break;
    case PSB:
      fD3Q15TPSZouHe(p0, uwall[1], uwall[2], uwall[0], &lbf[spos], &lbf[spos+2*qdim],
		             &lbf[spos+3*qdim], &lbf[spos+1*qdim], &lbf[spos+4*qdim], &lbf[spos+14*qdim], &lbf[spos+5*qdim],
                     &lbf[spos+13*qdim], &lbf[spos+9*qdim], &lbf[spos+10*qdim], &lbf[spos+8*qdim], &lbf[spos+11*qdim],
                     &lbf[spos+7*qdim], &lbf[spos+12*qdim], &lbf[spos+6*qdim]);
      break;
    case CCTRB:
      fD3Q15TCCZouHe(p0, uwall[0], uwall[1], -uwall[2], &lbf[spos], &lbf[spos+1*qdim],
                     &lbf[spos+2*qdim], &lbf[spos+10*qdim], &lbf[spos+5*qdim], &lbf[spos+4*qdim],
                     &lbf[spos+7*qdim], &lbf[spos+6*qdim], &lbf[spos+8*qdim], &lbf[spos+9*qdim],
                     &lbf[spos+3*qdim], &lbf[spos+12*qdim], &lbf[spos+11*qdim], &lbf[spos+14*qdim],
                     &lbf[spos+13*qdim]);
      break;
    case CCTLB:
      fD3Q15TCCZouHe(p0, -uwall[0], uwall[1], -uwall[2], &lbf[spos], &lbf[spos+8*qdim],
                     &lbf[spos+2*qdim], &lbf[spos+10*qdim], &lbf[spos+13*qdim], &lbf[spos+14*qdim],
                     &lbf[spos+11*qdim], &lbf[spos+12*qdim], &lbf[spos+1*qdim], &lbf[spos+9*qdim],
                     &lbf[spos+3*qdim], &lbf[spos+6*qdim], &lbf[spos+7*qdim], &lbf[spos+4*qdim],
                     &lbf[spos+5*qdim]);
      break;
    case CCDLB:
      fD3Q15TCCZouHe(p0, -uwall[0], -uwall[1], -uwall[2], &lbf[spos], &lbf[spos+8*qdim],
                     &lbf[spos+9*qdim], &lbf[spos+10*qdim], &lbf[spos+11*qdim], &lbf[spos+12*qdim],
                     &lbf[spos+13*qdim], &lbf[spos+14*qdim], &lbf[spos+1*qdim], &lbf[spos+2*qdim],
                     &lbf[spos+3*qdim], &lbf[spos+4*qdim], &lbf[spos+5*qdim], &lbf[spos+6*qdim],
                     &lbf[spos+7*qdim]);
      break;
    case CCDRB:
      fD3Q15TCCZouHe(p0, uwall[0], -uwall[1], -uwall[2], &lbf[spos], &lbf[spos+1*qdim],
                     &lbf[spos+9*qdim], &lbf[spos+10*qdim], &lbf[spos+7*qdim], &lbf[spos+6*qdim],
                     &lbf[spos+5*qdim], &lbf[spos+4*qdim], &lbf[spos+8*qdim], &lbf[spos+2*qdim],
                     &lbf[spos+3*qdim], &lbf[spos+14*qdim], &lbf[spos+13*qdim], &lbf[spos+12*qdim],
                     &lbf[spos+11*qdim]);
      break;
    case CCTRF:
      fD3Q15TCCZouHe(p0, uwall[0], uwall[1], uwall[2], &lbf[spos], &lbf[spos+1*qdim],
                     &lbf[spos+2*qdim], &lbf[spos+3*qdim], &lbf[spos+4*qdim], &lbf[spos+5*qdim],
                     &lbf[spos+6*qdim], &lbf[spos+7*qdim], &lbf[spos+8*qdim], &lbf[spos+9*qdim],
                     &lbf[spos+10*qdim], &lbf[spos+11*qdim], &lbf[spos+12*qdim], &lbf[spos+13*qdim],
                     &lbf[spos+14*qdim]);
      break;
    case CCTLF:
      fD3Q15TCCZouHe(p0, -uwall[0], uwall[1], uwall[2], &lbf[spos], &lbf[spos+8*qdim],
                     &lbf[spos+2*qdim], &lbf[spos+3*qdim], &lbf[spos+14*qdim], &lbf[spos+13*qdim],
                     &lbf[spos+12*qdim], &lbf[spos+11*qdim], &lbf[spos+1*qdim], &lbf[spos+9*qdim],
                     &lbf[spos+10*qdim], &lbf[spos+7*qdim], &lbf[spos+6*qdim], &lbf[spos+5*qdim],
                     &lbf[spos+4*qdim]);
      break;
    case CCDLF:
      fD3Q15TCCZouHe(p0, -uwall[0], -uwall[1], uwall[2], &lbf[spos], &lbf[spos+8*qdim],
                     &lbf[spos+9*qdim], &lbf[spos+3*qdim], &lbf[spos+12*qdim], &lbf[spos+11*qdim],
                     &lbf[spos+14*qdim], &lbf[spos+13*qdim], &lbf[spos+1*qdim], &lbf[spos+2*qdim],
                     &lbf[spos+10*qdim], &lbf[spos+5*qdim], &lbf[spos+4*qdim], &lbf[spos+7*qdim],
                     &lbf[spos+6*qdim]);
      break;
    case CCDRF:
      fD3Q15TCCZouHe(p0, uwall[0], -uwall[1], uwall[2], &lbf[spos], &lbf[spos+1*qdim],
                     &lbf[spos+9*qdim], &lbf[spos+3*qdim], &lbf[spos+6*qdim], &lbf[spos+7*qdim],
                     &lbf[spos+4*qdim], &lbf[spos+5*qdim], &lbf[spos+8*qdim], &lbf[spos+2*qdim],
                     &lbf[spos+10*qdim], &lbf[spos+13*qdim], &lbf[spos+14*qdim], &lbf[spos+11*qdim],
                     &lbf[spos+12*qdim]);
      break;
    case CETR:
      fD3Q15TCEZouHe(p0, uwall[0], uwall[1], uwall[2], &lbf[spos], &lbf[spos+1*qdim],
                     &lbf[spos+2*qdim], &lbf[spos+3*qdim], &lbf[spos+4*qdim], &lbf[spos+5*qdim],
                     &lbf[spos+6*qdim], &lbf[spos+7*qdim], &lbf[spos+8*qdim], &lbf[spos+9*qdim],
                     &lbf[spos+10*qdim], &lbf[spos+11*qdim], &lbf[spos+12*qdim], &lbf[spos+13*qdim],
                     &lbf[spos+14*qdim]);
      break;
    case CETL:
      fD3Q15TCEZouHe(p0, uwall[1], -uwall[0], uwall[2], &lbf[spos], &lbf[spos+2*qdim],
                     &lbf[spos+8*qdim], &lbf[spos+3*qdim], &lbf[spos+14*qdim], &lbf[spos+13*qdim],
                     &lbf[spos+4*qdim], &lbf[spos+5*qdim], &lbf[spos+9*qdim], &lbf[spos+1*qdim],
                     &lbf[spos+10*qdim], &lbf[spos+7*qdim], &lbf[spos+6*qdim], &lbf[spos+11*qdim],
                     &lbf[spos+12*qdim]);
      break;
    case CEDL:
      fD3Q15TCEZouHe(p0, -uwall[0], -uwall[1], uwall[2], &lbf[spos], &lbf[spos+8*qdim],
                     &lbf[spos+9*qdim], &lbf[spos+3*qdim], &lbf[spos+12*qdim], &lbf[spos+11*qdim],
                     &lbf[spos+14*qdim], &lbf[spos+13*qdim], &lbf[spos+1*qdim], &lbf[spos+2*qdim],
                     &lbf[spos+10*qdim], &lbf[spos+5*qdim], &lbf[spos+4*qdim], &lbf[spos+7*qdim],
                     &lbf[spos+6*qdim]);
      break;
    case CEDR:
      fD3Q15TCEZouHe(p0, -uwall[1], uwall[0], uwall[2], &lbf[spos], &lbf[spos+9*qdim],
                     &lbf[spos+1*qdim], &lbf[spos+3*qdim], &lbf[spos+6*qdim], &lbf[spos+7*qdim],
                     &lbf[spos+12*qdim], &lbf[spos+11*qdim], &lbf[spos+2*qdim], &lbf[spos+8*qdim],
                     &lbf[spos+10*qdim], &lbf[spos+13*qdim], &lbf[spos+14*qdim], &lbf[spos+5*qdim],
                     &lbf[spos+4*qdim]);
      break;
    case CETF:
      fD3Q15TCEZouHe(p0, uwall[1], uwall[2], uwall[0], &lbf[spos], &lbf[spos+2*qdim],
                     &lbf[spos+3*qdim], &lbf[spos+1*qdim], &lbf[spos+4*qdim], &lbf[spos+14*qdim],
                     &lbf[spos+5*qdim], &lbf[spos+13*qdim], &lbf[spos+9*qdim], &lbf[spos+10*qdim],
                     &lbf[spos+8*qdim], &lbf[spos+11*qdim], &lbf[spos+7*qdim], &lbf[spos+12*qdim],
                     &lbf[spos+6*qdim]);
      break;
    case CELF:
      fD3Q15TCEZouHe(p0, -uwall[0], uwall[2], uwall[1], &lbf[spos], &lbf[spos+8*qdim],
                     &lbf[spos+3*qdim], &lbf[spos+2*qdim], &lbf[spos+14*qdim], &lbf[spos+12*qdim],
                     &lbf[spos+13*qdim], &lbf[spos+11*qdim], &lbf[spos+1*qdim], &lbf[spos+10*qdim],
                     &lbf[spos+9*qdim], &lbf[spos+7*qdim], &lbf[spos+5*qdim], &lbf[spos+6*qdim],
                     &lbf[spos+4*qdim]);
      break;
    case CEDF:
      fD3Q15TCEZouHe(p0, -uwall[1], uwall[2], uwall[0], &lbf[spos], &lbf[spos+9*qdim],
                     &lbf[spos+3*qdim], &lbf[spos+1*qdim], &lbf[spos+6*qdim], &lbf[spos+12*qdim],
                     &lbf[spos+7*qdim], &lbf[spos+11*qdim], &lbf[spos+2*qdim], &lbf[spos+10*qdim],
                     &lbf[spos+8*qdim], &lbf[spos+13*qdim], &lbf[spos+5*qdim], &lbf[spos+14*qdim],
                     &lbf[spos+4*qdim]);
      break;
    case CERF:
      fD3Q15TCEZouHe(p0, uwall[0], uwall[2], uwall[1], &lbf[spos], &lbf[spos+1*qdim],
                     &lbf[spos+3*qdim], &lbf[spos+2*qdim], &lbf[spos+4*qdim], &lbf[spos+6*qdim],
                     &lbf[spos+5*qdim], &lbf[spos+7*qdim], &lbf[spos+8*qdim], &lbf[spos+10*qdim],
                     &lbf[spos+9*qdim], &lbf[spos+11*qdim], &lbf[spos+13*qdim], &lbf[spos+12*qdim],
                     &lbf[spos+14*qdim]);
      break;
    case CETB:
      fD3Q15TCEZouHe(p0, uwall[1], -uwall[2], uwall[0], &lbf[spos], &lbf[spos+2*qdim],
                     &lbf[spos+10*qdim], &lbf[spos+1*qdim], &lbf[spos+5*qdim], &lbf[spos+13*qdim],
                     &lbf[spos+4*qdim], &lbf[spos+14*qdim], &lbf[spos+9*qdim], &lbf[spos+3*qdim],
                     &lbf[spos+8*qdim], &lbf[spos+12*qdim], &lbf[spos+6*qdim], &lbf[spos+11*qdim],
                     &lbf[spos+7*qdim]);
      break;
    case CELB:
      fD3Q15TCEZouHe(p0, -uwall[0], -uwall[2], uwall[1], &lbf[spos], &lbf[spos+8*qdim],
                     &lbf[spos+10*qdim], &lbf[spos+2*qdim], &lbf[spos+13*qdim], &lbf[spos+11*qdim],
                     &lbf[spos+14*qdim], &lbf[spos+12*qdim], &lbf[spos+1*qdim], &lbf[spos+3*qdim],
                     &lbf[spos+9*qdim], &lbf[spos+6*qdim], &lbf[spos+4*qdim], &lbf[spos+7*qdim],
                     &lbf[spos+5*qdim]);
      break;
    case CEDB:
      fD3Q15TCEZouHe(p0, -uwall[1], -uwall[2], uwall[0], &lbf[spos], &lbf[spos+9*qdim],
                     &lbf[spos+10*qdim], &lbf[spos+1*qdim], &lbf[spos+7*qdim], &lbf[spos+11*qdim],
                     &lbf[spos+6*qdim], &lbf[spos+12*qdim], &lbf[spos+2*qdim], &lbf[spos+3*qdim],
                     &lbf[spos+8*qdim], &lbf[spos+14*qdim], &lbf[spos+4*qdim], &lbf[spos+13*qdim],
                     &lbf[spos+5*qdim]);
      break;
    case CERB:
      fD3Q15TCEZouHe(p0, uwall[0], -uwall[2], uwall[1], &lbf[spos], &lbf[spos+1*qdim],
                     &lbf[spos+10*qdim], &lbf[spos+2*qdim], &lbf[spos+5*qdim], &lbf[spos+7*qdim],
                     &lbf[spos+4*qdim], &lbf[spos+6*qdim], &lbf[spos+8*qdim], &lbf[spos+3*qdim],
                     &lbf[spos+9*qdim], &lbf[spos+12*qdim], &lbf[spos+14*qdim], &lbf[spos+11*qdim],
                     &lbf[spos+13*qdim]);
      break;
  }
  return 0;
}


// D3Q19

int fD3Q19VPSZouHe(double v0, double v1, double v2, double *force,
                   double *f0, double *f1, double *f2, double *f3, double *f4,
                   double *f5, double *f6, double *f7, double *f8, double *f9,
                   double *f10, double *f11, double *f12, double *f13, double *f14,
                   double *f15, double *f16, double *f17, double *f18)
{

  // produce fixed velocity for compressible/incompressible fluids at planar surface boundary:
  // expressed for bottom wall (VPST)
  
  double rho, n1, n2;
  double c1=1.0/3.0, c2=1.0/6.0;

  if(!incompress) {
    for(int i=0; i<lbsy.nf; i++) {
      rho=(f0[i]+f1[i]+f3[i]+f6[i]+f7[i]+f10[i]+f12[i]+f15[i]+f16[i]+2.0*(f2[i]+f4[i]+f8[i]+f9[i]+f14[i])-0.5*force[3*i+1])/(1.0-v1);
      n1=0.5*(f10[i]-f1[i]-f6[i]-f7[i]+f15[i]+f16[i])-c1*rho*v0+0.25*force[3*i  ];
      n2=0.5*(f12[i]-f3[i]-f6[i]+f7[i]+f15[i]-f16[i])-c1*rho*v2+0.25*force[3*i+2];
      f5[i]=f14[i]-c2*rho*(v0-v1)+n1;
      f11[i]=f2[i]+c1*rho*v1;
      f13[i]=f4[i]+c2*rho*(v0+v1)-n1;
      f17[i]=f8[i]+c2*rho*(v1+v2)-n2;
      f18[i]=f9[i]+c2*rho*(v1-v2)+n2;
    }
  }
  else {
    for(int i=0; i<lbsy.nf; i++) {
//     double rho=f0+f1+f3+f6+f7+f10+f12+f15+f16+2.0*(f2+f4+f8+f9+f14)+rho0*v1-0.5*force[1];
      double rho0=lbincp[i];
      n1=0.5*(f10[i]-f1[i]-f6[i]-f7[i]+f15[i]+f16[i])-c1*rho0*v0+0.25*force[3*i  ];
      n2=0.5*(f12[i]-f3[i]-f6[i]+f7[i]+f15[i]-f16[i])-c1*rho0*v2+0.25*force[3*i+2];
      f5[i]=f14[i]-c2*rho0*(v0-v1)+n1;
      f11[i]=f2[i]+c1*rho0*v1;
      f13[i]=f4[i]+c2*rho0*(v0+v1)-n1;
      f17[i]=f8[i]+c2*rho0*(v1+v2)-n2;
      f18[i]=f9[i]+c2*rho0*(v1-v2)+n2;
    }
  }
  return 0;
}

int fD3Q19VCEZouHe(double *p, double v0, double v1, double v2, double *force,
                   double *f0, double *f1, double *f2, double *f3, double *f4,
                   double *f5, double *f6, double *f7, double *f8, double *f9,
                   double *f10, double *f11, double *f12, double *f13, double *f14,
                   double *f15, double *f16, double *f17, double *f18)
{

  // produce fixed velocity for compressible/incompressible fluids at concave edge boundary:
  // expressed for bottom left edge (VCETR)
  
  double nz;
  double c1=1.0/3.0, c2=1.0/6.0, c4=1.0/12.0;

  if(!incompress) {
    for(int i=0; i<lbsy.nf; i++) {
      nz=0.25*(f12[i]-f3[i])-c4*p[i]*v2+0.125*force[3*i+2];
      f5[i]=0.5*(p[i]-f0[i]-f3[i]-f12[i])-f1[i]-f2[i]-f4[i]-f6[i]-f7[i]-f8[i]-f9[i]-p[i]*(0.5*v0+c1*v1)+0.25*force[3*i  ];
      f10[i]=f1[i]+c1*p[i]*v0;
      f11[i]=f2[i]+c1*p[i]*v1;
      f13[i]=f4[i]+c2*p[i]*(v0+v1)-0.25*(force[3*i]+force[3*i+1]);
      f14[i]=0.5*(p[i]-f0[i]-f3[i]-f12[i])-f1[i]-f2[i]-f4[i]-f6[i]-f7[i]-f8[i]-f9[i]-p[i]*(c1*v0+0.5*v1)+0.25*force[3*i+1];
      f15[i]=f6[i]+c2*p[i]*(v0+v2)-nz;
      f16[i]=f7[i]+c2*p[i]*(v0-v2)+nz;
      f17[i]=f8[i]+c2*p[i]*(v1+v2)-nz;
      f18[i]=f9[i]+c2*p[i]*(v1-v2)+nz;
    }
  }
  else {
    for(int i=0; i<lbsy.nf; i++) {
      double rho0=lbincp[i];
      nz=0.25*(f12[i]-f3[i])-c4*rho0*v2+0.125*force[3*i+2];
      f5[i]=0.5*(p[i]-f0[i]-f3[i]-f12[i])-f1[i]-f2[i]-f4[i]-f6[i]-f7[i]-f8[i]-f9[i]-rho0*(0.5*v0+c1*v1)+0.25*force[3*i  ];
      f10[i]=f1[i]+c1*rho0*v0;
      f11[i]=f2[i]+c1*rho0*v1;
      f13[i]=f4[i]+c2*rho0*(v0+v1)-0.25*(force[3*i]+force[3*i+1]);
      f14[i]=0.5*(p[i]-f0[i]-f3[i]-f12[i])-f1[i]-f2[i]-f4[i]-f6[i]-f7[i]-f8[i]-f9[i]-rho0*(c1*v0+0.5*v1)+0.25*force[3*i+1];
      f15[i]=f6[i]+c2*rho0*(v0+v2)-nz;
      f16[i]=f7[i]+c2*rho0*(v0-v2)+nz;
      f17[i]=f8[i]+c2*rho0*(v1+v2)-nz;
      f18[i]=f9[i]+c2*rho0*(v1-v2)+nz;
    }
  }
  return 0;
}

int fD3Q19VCCZouHe(double *p, double v0, double v1, double v2, double *force,
                   double *f0, double *f1, double *f2, double *f3, double *f4,
                   double *f5, double *f6, double *f7, double *f8, double *f9,
                   double *f10, double *f11, double *f12, double *f13, double *f14,
                   double *f15, double *f16, double *f17, double *f18)
{

  // produce fixed velocity for compressible/incompressible fluids at concave corner boundary:
  // expressed for bottom left back corner (VCCTRF)
  
  double q0, qx, qy, qz;
  double c1=1.0/3.0, c2=1.0/6.0, c3=1.0/9.0, c4=1.0/12.0, c5=1.0/24.0;

  if(!incompress) {
    for(int i=0; i<lbsy.nf; i++) {
      q0 = c2*(p[i]-f0[i])-c1*(f1[i]+f2[i]+f3[i]+f4[i]+f6[i]+f8[i])-c3*p[i]*(v0+v1+v2)+c5*(force[3*i]+force[3*i+1]+force[3*i+2]);
      qx = c4*p[i]*v0-0.0625*force[3*i  ];
      qy = c4*p[i]*v1-0.0625*force[3*i+1];
      qz = c4*p[i]*v2-0.0625*force[3*i+2];
      f5[i]=q0-qx+qy;
      f7[i]=q0-qx+qz;
      f9[i]=q0-qy+qz;
      f10[i]=f1[i]+c1*p[i]*v0;
      f11[i]=f2[i]+c1*p[i]*v1;
      f12[i]=f3[i]+c1*p[i]*v2;
      f13[i]=f4[i]+c2*p[i]*(v0+v1)-0.125*(force[3*i  ]+force[3*i+1]);
      f14[i]=q0+qx-qy;
      f15[i]=f6[i]+c2*p[i]*(v0+v2)-0.125*(force[3*i  ]+force[3*i+2]);
      f16[i]=q0+qx-qz;
      f17[i]=f8[i]+c2*p[i]*(v1+v2)-0.125*(force[3*i+1]+force[3*i+2]);
      f18[i]=q0+qy-qz;
    }
  }
  else {
    for(int i=0; i<lbsy.nf; i++) {
      double rho0=lbincp[i];
      q0 = c2*(p[i]-f0[i])-c1*(f1[i]+f2[i]+f3[i]+f4[i]+f6[i]+f8[i])-c3*rho0*(v0+v1+v2)+c5*(force[3*i]+force[3*i+1]+force[3*i+2]);
      qx = c4*rho0*v0-0.0625*force[3*i  ];
      qy = c4*rho0*v1-0.0625*force[3*i+1];
      qz = c4*rho0*v2-0.0625*force[3*i+2];
      f5[i]=q0-qx+qy;
      f7[i]=q0-qx+qz;
      f9[i]=q0-qy+qz;
      f10[i]=f1[i]+c1*rho0*v0;
      f11[i]=f2[i]+c1*rho0*v1;
      f12[i]=f3[i]+c1*rho0*v2;
      f13[i]=f4[i]+c2*rho0*(v0+v1)-0.125*(force[3*i  ]+force[3*i+1]);
      f14[i]=q0+qx-qy;
      f15[i]=f6[i]+c2*rho0*(v0+v2)-0.125*(force[3*i  ]+force[3*i+2]);
      f16[i]=q0+qx-qz;
      f17[i]=f8[i]+c2*rho0*(v1+v2)-0.125*(force[3*i+1]+force[3*i+2]);
      f18[i]=q0+qy-qz;
    }
  }
  return 0;
}

int fD3Q19VPSCLBEZouHe(double v0, double v1, double v2, double *force,
                       double *f0, double *f1, double *f2, double *f3, double *f4,
                       double *f5, double *f6, double *f7, double *f8, double *f9,
                       double *f10, double *f11, double *f12, double *f13, double *f14,
                       double *f15, double *f16, double *f17, double *f18)
{

  // produce fixed velocity for compressible fluids at planar surface boundary:
  // expressed for bottom wall (VPST) using higher-order equilibrium distribution
  // functions for CLBE collisions
  
  double rho, n1, n2;
  double c1=1.0/3.0, c2=1.0/6.0;
  double v0v0 = v0*v0;
  double v1v1 = v1*v1;
  double v2v2 = v2*v2;

  for(int i=0; i<lbsy.nf; i++) {
    rho=(f0[i]+f1[i]+f3[i]+f6[i]+f7[i]+f10[i]+f12[i]+f15[i]+f16[i]+2.0*(f2[i]+f4[i]+f8[i]+f9[i]+f14[i])-0.5*force[3*i+1])/(1.0-v1);
    n1=0.5*(f10[i]-f1[i]-f6[i]-f7[i]+f15[i]+f16[i])-rho*v0*(c1-0.5*v1v1)+0.25*force[3*i  ];
    n2=0.5*(f12[i]-f3[i]-f6[i]+f7[i]+f15[i]-f16[i])-rho*v2*(c1-0.5*v1v1)+0.25*force[3*i+2];
    f5[i]=f14[i]-rho*(c2*(v0-v1)-0.5*(v0v0*v1-v0*v1v1))+n1;
    f11[i]=f2[i]+rho*v1*(c1-v0v0-v2v2);
    f13[i]=f4[i]+rho*(c2*(v0+v1)+0.5*(v0v0*v1+v0*v1v1))-n1;
    f17[i]=f8[i]+rho*(c2*(v1+v2)+0.5*(v1v1*v2+v1*v2v2))-n2;
    f18[i]=f9[i]+rho*(c2*(v1-v2)-0.5*(v1v1*v2-v1*v2v2))+n2;
  }
  return 0;
}

int fD3Q19VCECLBEZouHe(double *p, double v0, double v1, double v2, double *force,
                       double *f0, double *f1, double *f2, double *f3, double *f4,
                       double *f5, double *f6, double *f7, double *f8, double *f9,
                       double *f10, double *f11, double *f12, double *f13, double *f14,
                       double *f15, double *f16, double *f17, double *f18)
{

  // produce fixed velocity for compressible fluids at concave edge boundary:
  // expressed for bottom left edge (VCETR) using higher-order
  // equilibrium distribution functions for CLBE collisions
  
  double nz;
  double c1=1.0/3.0, c2=1.0/6.0, c4=1.0/12.0;

  double v0v0 = v0*v0;
  double v1v1 = v1*v1;
  double v2v2 = v2*v2;

  for(int i=0; i<lbsy.nf; i++) {
    nz=0.25*(f12[i]-f3[i])-p[i]*(c4*v2-0.25*v2*(v0v0+v1v1))+0.125*force[3*i+2];
    f5[i]=0.5*(p[i]-f0[i]-f3[i]-f12[i])-f1[i]-f2[i]-f4[i]-f6[i]-f7[i]-f8[i]-f9[i]-p[i]*(0.5*v0*(1.0-v2v2)+c1*v1)+0.25*force[3*i  ];
    f10[i]=f1[i]+p[i]*(c1*v0-v0*(v1v1+v2v2));
    f11[i]=f2[i]+p[i]*(c1*v1-v1*(v0v0+v2v2));
    f13[i]=f4[i]+p[i]*(c2*(v0+v1)-0.5*v2v2*(v0+v1))-0.25*(force[3*i]+force[3*i+1]);
    f14[i]=0.5*(p[i]-f0[i]-f3[i]-f12[i])-f1[i]-f2[i]-f4[i]-f6[i]-f7[i]-f8[i]-f9[i]-p[i]*(c1*v0+0.5*v1*(1.0-v2v2))+0.25*force[3*i+1];
    f15[i]=f6[i]+p[i]*(c2*(v0+v2)+0.5*(v0v0*v2+v0*v2v2))-nz;
    f16[i]=f7[i]+p[i]*(c2*(v0-v2)-0.5*(v0v0*v2-v0*v2v2))+nz;
    f17[i]=f8[i]+p[i]*(c2*(v1+v2)+0.5*(v1v1*v2+v1*v2v2))-nz;
    f18[i]=f9[i]+p[i]*(c2*(v1-v2)-0.5*(v1v1*v2-v1*v2v2))+nz;
  }
  return 0;
}

int fD3Q19VCCCLBEZouHe(double *p, double v0, double v1, double v2, double *force,
                       double *f0, double *f1, double *f2, double *f3, double *f4,
                       double *f5, double *f6, double *f7, double *f8, double *f9,
                       double *f10, double *f11, double *f12, double *f13, double *f14,
                       double *f15, double *f16, double *f17, double *f18)
{

  // produce fixed velocity for compressible fluids at concave corner boundary:
  // expressed for bottom left back corner (VCCTRF) using higher-order
  // equilibrium distribution functions for CLBE collisions
  
  double q0, qx, qy, qz;
  double c1=1.0/3.0, c2=1.0/6.0, c3=1.0/9.0, c4=1.0/12.0, c5=1.0/24.0;

  double v0v0 = v0*v0;
  double v1v1 = v1*v1;
  double v2v2 = v2*v2;

  for(int i=0; i<lbsy.nf; i++) {
    q0 = c2*(p[i]-f0[i])-c1*(f1[i]+f2[i]+f3[i]+f4[i]+f6[i]+f8[i])-c3*p[i]*(v0+v1+v2)+c5*(force[3*i]+force[3*i+1]+force[3*i+2]);
    qx = p[i]*(c4*v0+0.125*v0*(v1v1+v2v2)-c5*(v1*(v0v0-v2v2)+v2*(v0v0-v1v1)))-0.0625*force[3*i  ];
    qy = p[i]*(c4*v1+0.125*v1*(v0v0+v2v2)-c5*(v0*(v1v1-v2v2)-v2*(v0v0-v1v1)))-0.0625*force[3*i+1];
    qz = p[i]*(c4*v2+0.125*v2*(v0v0+v1v1)+c5*(v0*(v1v1-v2v2)+v1*(v0v0-v1v1)))-0.0625*force[3*i+2];
    f5[i]=q0-qx+qy;
    f7[i]=q0-qx+qz;
    f9[i]=q0-qy+qz;
    f10[i]=f1[i]+p[i]*(c1*v0-v0*(v1v1+v2v2));
    f11[i]=f2[i]+p[i]*(c1*v1-v1*(v0v0+v2v2));
    f12[i]=f3[i]+p[i]*(c1*v2-v2*(v0v0+v1v1));
    f13[i]=f4[i]+p[i]*(c2*(v0+v1)+0.5*(v0v0*v1+v0*v1v1))-0.125*(force[3*i  ]+force[3*i+1]);
    f14[i]=q0+qx-qy;
    f15[i]=f6[i]+p[i]*(c2*(v0+v2)+0.5*(v0v0*v2+v0*v2v2))-0.125*(force[3*i  ]+force[3*i+2]);
    f16[i]=q0+qx-qz;
    f17[i]=f8[i]+p[i]*(c2*(v1+v2)+0.5*(v1v1*v2+v1*v2v2))-0.125*(force[3*i+1]+force[3*i+2]);
    f18[i]=q0+qy-qz;
  }
  return 0;
}

int fD3Q19VPSSimpleZouHe(double v0, double v1, double v2, double *force, double *f0, double *f1, double *f2,
                         double *f3, double *f4, double *f5, double *f6, double *f7, double *f8,
                         double *f9, double *f10, double *f11, double *f12, double *f13, double *f14,
                         double *f15, double *f16, double *f17, double *f18)
{

  // produce fixed velocity for compressible/incompressible fluids at planar surface boundary:
  // expressed for bottom wall
  
  double rho;
  double c1=1.0/3.0, c2=1.0/6.0;

  if(!incompress) {
    for(int i=0; i<lbsy.nf; i++) {
      rho=(f0[i]+f1[i]+f3[i]+f6[i]+f7[i]+f10[i]+f12[i]+f15[i]+f16[i]+2.0*(f2[i]+f4[i]+f8[i]+f9[i]+f14[i])-0.5*force[3*i+1])/(1.0-v1);
      f5[i]=f14[i]-c2*rho*(v0-v1);
      f11[i]=f2[i]+c1*rho*v1;
      f13[i]=f4[i]+c2*rho*(v0+v1);
      f17[i]=f8[i]+c2*rho*(v1+v2);
      f18[i]=f9[i]+c2*rho*(v1-v2);
    }
  }
  else {
    for(int i=0; i<lbsy.nf; i++) {
//     double rho=f0+f1+f3+f6+f7+f10+f12+f15+f16+2.0*(f2+f4+f8+f9+f14)+rho0*v1-0.5*force;
      double rho0=lbincp[i];
      f5[i]=f14[i]-c2*rho0*(v0-v1);
      f11[i]=f2[i]+c1*rho0*v1;
      f13[i]=f4[i]+c2*rho0*(v0+v1);
      f17[i]=f8[i]+c2*rho0*(v1+v2);
      f18[i]=f9[i]+c2*rho0*(v1-v2);
    }
  }
  return 0;
}

int fD3Q19VCESimpleZouHe(double *p, double v0, double v1, double v2, double *force,
                         double *f0, double *f1, double *f2, double *f3, double *f4,
                         double *f5, double *f6, double *f7, double *f8, double *f9,
                         double *f10, double *f11, double *f12, double *f13, double *f14,
                         double *f15, double *f16, double *f17, double *f18)
{

  // produce fixed velocity for compressible/incompressible fluids at concave edge boundary:
  // expressed for bottom left edge (VCETR)
  
  double c1=1.0/3.0, c2=1.0/6.0;

  if(!incompress) {
    for(int i=0; i<lbsy.nf; i++) {
      f5[i]=0.5*(p[i]-f0[i]-f3[i]-f12[i])-f1[i]-f2[i]-f4[i]-f6[i]-f7[i]-f8[i]-f9[i]-p[i]*(0.5*v0+c1*v1)+0.125*(force[3*i  ]-force[3*i+1]);
      f10[i]=f1[i]+c1*p[i]*v0;
      f11[i]=f2[i]+c1*p[i]*v1;
      f13[i]=0.5*(p[i]-f0[i]-f3[i]-f12[i])-f1[i]-f2[i]-f4[i]-f6[i]-f7[i]-f8[i]-f9[i]-p[i]*(c1*v0+0.5*v1)+0.125*(force[3*i+1]-force[3*i  ]);
      f15[i]=f6[i]+c2*p[i]*(v0+v2);
      f16[i]=f7[i]+c2*p[i]*(v0-v2);
      f17[i]=f8[i]+c2*p[i]*(v1+v2);
      f18[i]=f9[i]+c2*p[i]*(v1-v2);
    }
  }
  else {
    for(int i=0; i<lbsy.nf; i++) {
      double rho0=lbincp[i];
      f5[i]=0.5*(p[i]-f0[i]-f3[i]-f12[i])-f1[i]-f2[i]-f4[i]-f6[i]-f7[i]-f8[i]-f9[i]-rho0*(0.5*v0+c1*v1)+0.125*(force[3*i  ]-force[3*i+1]);
      f10[i]=f1[i]+c1*rho0*v0;
      f11[i]=f2[i]+c1*rho0*v1;
      f13[i]=0.5*(p[i]-f0[i]-f3[i]-f12[i])-f1[i]-f2[i]-f4[i]-f6[i]-f7[i]-f8[i]-f9[i]-rho0*(c1*v0+0.5*v1)+0.125*(force[3*i+1]-force[3*i  ]);
      f15[i]=f6[i]+c2*rho0*(v0+v2);
      f16[i]=f7[i]+c2*rho0*(v0-v2);
      f17[i]=f8[i]+c2*rho0*(v1+v2);
      f18[i]=f9[i]+c2*rho0*(v1-v2);
    }
  }
  return 0;
}

int fD3Q19VCCSimpleZouHe(double *p, double v0, double v1, double v2, double *force,
                         double *f0, double *f1, double *f2, double *f3, double *f4,
                         double *f5, double *f6, double *f7, double *f8, double *f9,
                         double *f10, double *f11, double *f12, double *f13, double *f14,
                         double *f15, double *f16, double *f17, double *f18)
{

  // produce fixed velocity for compressible/incompressible fluids at concave corner boundary:
  // expressed for bottom left back corner (VCCTRF)
  
  double q0, qxy, qxz, qyz;
  double c1=1.0/3.0, c2=1.0/6.0, c3=1.0/9.0, c4=1.0/12.0, c5=1.0/24.0;

  if(!incompress) {
    for(int i=0; i<lbsy.nf; i++) {
      q0 = c2*(p[i]-f0[i])-c1*(f1[i]+f2[i]+f3[i]+f4[i]+f6[i]+f8[i])-c3*p[i]*(v0+v1+v2)+c4*p[i]*(v0*v0*(v1+v2)+v1*v1*(v0+v2)+v2*v2*(v0+v1));
      qxy = c4*p[i]*(v0-v1)-c4*(force[3*i  ]+force[3*i+1]);
      qxz = c4*p[i]*(v0-v2)-c4*(force[3*i  ]+force[3*i+2]);
      qyz = c4*p[i]*(v1-v2)-c4*(force[3*i+1]+force[3*i+2]);
      f5[i]=q0-qxy;
      f7[i]=q0-qxz;
      f9[i]=q0-qyz;
      f10[i]=f1[i]+c1*p[i]*v0;
      f11[i]=f2[i]+c1*p[i]*v1;
      f12[i]=f3[i]+c1*p[i]*v2;
      f13[i]=f4[i]+c2*p[i]*(v0+v1);
      f14[i]=q0+qxy;
      f15[i]=f6[i]+c2*p[i]*(v0+v2);
      f16[i]=q0+qxz;
      f17[i]=f8[i]+c2*p[i]*(v1+v2);
      f18[i]=q0+qyz;
    }
  }
  else {
    for(int i=0; i<lbsy.nf; i++) {
      double rho0=lbincp[i];
      q0 = c2*(p[i]-f0[i])-c1*(f1[i]+f2[i]+f3[i]+f4[i]+f6[i]+f8[i])-c3*rho0*(v0+v1+v2)+c5*(force[3*i]+force[3*i+1]+force[3*i+2]);
      qxy = c4*rho0*(v0-v1)-c4*(force[3*i  ]+force[3*i+1]);
      qxz = c4*rho0*(v0-v2)-c4*(force[3*i  ]+force[3*i+2]);
      qyz = c4*rho0*(v1-v2)-c4*(force[3*i+1]+force[3*i+2]);
      f5[i]=q0-qxy;
      f7[i]=q0-qxz;
      f9[i]=q0-qyz;
      f10[i]=f1[i]+c1*rho0*v0;
      f11[i]=f2[i]+c1*rho0*v1;
      f12[i]=f3[i]+c1*rho0*v2;
      f13[i]=f4[i]+c2*rho0*(v0+v1);
      f14[i]=q0+qxy;
      f15[i]=f6[i]+c2*rho0*(v0+v2);
      f16[i]=q0+qxz;
      f17[i]=f8[i]+c2*rho0*(v1+v2);
      f18[i]=q0+qyz;
    }
  }
  return 0;
}

int fD3Q19VPSCLBESimpleZouHe(double v0, double v1, double v2, double *force, double *f0, double *f1, double *f2,
                             double *f3, double *f4, double *f5, double *f6, double *f7, double *f8,
                             double *f9, double *f10, double *f11, double *f12, double *f13, double *f14,
                             double *f15, double *f16, double *f17, double *f18)
{

  // produce fixed velocity for compressible fluids at planar surface boundary:
  // expressed for bottom wall using higher-order equilibrium distribution functions for CLBE collisions
  
  double rho;
  double c1=1.0/3.0, c2=1.0/6.0;
  double v0v0 = v0*v0;
  double v1v1 = v1*v1;
  double v2v2 = v2*v2;

  for(int i=0; i<lbsy.nf; i++) {
    rho=(f0[i]+f1[i]+f3[i]+f6[i]+f7[i]+f10[i]+f12[i]+f15[i]+f16[i]+2.0*(f2[i]+f4[i]+f8[i]+f9[i]+f14[i])-0.5*force[3*i+1])/(1.0-v1);
    f5[i]=f14[i]-rho*(c2*(v0-v1)-0.5*(v0v0*v1-v0*v1v1));
    f11[i]=f2[i]+rho*v1*(c1-v0v0-v2v2);
    f13[i]=f4[i]+rho*(c2*(v0+v1)+0.5*(v0v0*v1+v0*v1v1));
    f17[i]=f8[i]+rho*(c2*(v1+v2)+0.5*(v1v1*v2+v1*v2v2));
    f18[i]=f9[i]+rho*(c2*(v1-v2)-0.5*(v1v1*v2-v1*v2v2));
  }
  return 0;
}

int fD3Q19VCECLBESimpleZouHe(double *p, double v0, double v1, double v2, double *force,
                             double *f0, double *f1, double *f2, double *f3, double *f4,
                             double *f5, double *f6, double *f7, double *f8, double *f9,
                             double *f10, double *f11, double *f12, double *f13, double *f14,
                             double *f15, double *f16, double *f17, double *f18)
{

  // produce fixed velocity for compressible fluids at concave edge boundary:
  // expressed for bottom left edge (VCETR) using higher-order
  // equilibrium distribution functions for CLBE collisions
  
  double c1=1.0/3.0, c2=1.0/6.0;

  double v0v0 = v0*v0;
  double v1v1 = v1*v1;
  double v2v2 = v2*v2;

  for(int i=0; i<lbsy.nf; i++) {
    f5[i]=0.5*(p[i]-f0[i]-f3[i]-f12[i])-f1[i]-f2[i]-f4[i]-f6[i]-f7[i]-f8[i]-f9[i]-p[i]*(0.5*v0*(1.0-v2v2)+c1*v1)+0.125*(force[3*i  ]-force[3*i+1]);
    f10[i]=f1[i]+p[i]*(c1*v0-v0*(v1v1+v2v2));
    f11[i]=f2[i]+p[i]*(c1*v1-v1*(v0v0+v2v2));
    f13[i]=f4[i]+p[i]*(c2*(v0+v1)-0.5*v2v2*(v0+v1));
    f14[i]=0.5*(p[i]-f0[i]-f3[i]-f12[i])-f1[i]-f2[i]-f4[i]-f6[i]-f7[i]-f8[i]-f9[i]-p[i]*(c1*v0+0.5*v1*(1.0-v2v2))+0.125*(force[3*i+1]-force[3*i  ]);
    f15[i]=f6[i]+p[i]*(c2*(v0+v2)+0.5*(v0v0*v2+v0*v2v2));
    f16[i]=f7[i]+p[i]*(c2*(v0-v2)-0.5*(v0v0*v2-v0*v2v2));
    f17[i]=f8[i]+p[i]*(c2*(v1+v2)+0.5*(v1v1*v2+v1*v2v2));
    f18[i]=f9[i]+p[i]*(c2*(v1-v2)-0.5*(v1v1*v2-v1*v2v2));
  }
  return 0;
}

int fD3Q19VCCCLBESimpleZouHe(double *p, double v0, double v1, double v2, double *force,
                             double *f0, double *f1, double *f2, double *f3, double *f4,
                             double *f5, double *f6, double *f7, double *f8, double *f9,
                             double *f10, double *f11, double *f12, double *f13, double *f14,
                             double *f15, double *f16, double *f17, double *f18)
{

  // produce fixed velocity for compressible fluids at concave corner boundary:
  // expressed for bottom left back corner (VCCTRF) using higher-order
  // equilibrium distribution functions for CLBE collisions
  
  double q0, qxy, qxz, qyz;
  double c1=1.0/3.0, c2=1.0/6.0, c3=1.0/9.0, c4=1.0/12.0;

  double v0v0 = v0*v0;
  double v1v1 = v1*v1;
  double v2v2 = v2*v2;

  for(int i=0; i<lbsy.nf; i++) {
    q0 = c2*(p[i]-f0[i])-c1*(f1[i]+f2[i]+f3[i]+f4[i]+f6[i]+f8[i])-c3*p[i]*(v0+v1+v2)+c4*p[i]*(v0v0*(v1+v2)+v1v1*(v0+v2)+v2v2*(v0+v1));
    qxy = p[i]*(c4*(v0-v1)+v0*v1v1-v0v0*v1+0.5*(v0*v2v2-v0v0*v2+v1v1*v2-v1*v2v2))-c4*(force[3*i  ]+force[3*i+1]);
    qxz = p[i]*(c4*(v0-v2)+v0*v2v2-v0v0*v2+0.5*(v0*v1v1-v0v0*v1+v1*v2v2-v1v1*v2))-c4*(force[3*i  ]+force[3*i+2]);
    qyz = p[i]*(c4*(v1-v2)+v1*v2v2-v1v1*v2+0.5*(v0*v2v2-v0v0*v2+v0v0*v1-v0*v1v1))-c4*(force[3*i+1]+force[3*i+2]);
    f5[i]=q0-qxy;
    f7[i]=q0-qxz;
    f9[i]=q0-qyz;
    f10[i]=f1[i]+p[i]*(c1*v0-v0*(v1v1+v2v2));
    f11[i]=f2[i]+p[i]*(c1*v1-v1*(v0v0+v2v2));
    f12[i]=f3[i]+p[i]*(c1*v2-v2*(v0v0+v1v1));
    f13[i]=f4[i]+p[i]*(c2*(v0+v1)+0.5*(v0v0*v1+v0*v1v1));
    f14[i]=q0+qxy;
    f15[i]=f6[i]+p[i]*(c2*(v0+v2)+0.5*(v0v0*v2+v0*v2v2));
    f16[i]=q0+qxz;
    f17[i]=f8[i]+p[i]*(c2*(v1+v2)+0.5*(v1v1*v2+v1*v2v2));
    f18[i]=q0+qyz;
  }
  return 0;
}

int fD3Q19VFZouHe(long tpos, long rpos, int prop, double *uwall, double dx, double dy, double dz)
{
  long spos=tpos * lbsitelength;
  int qdim=lbsy.nf+lbsy.nc+lbsy.nt;
  double force[3*lbsy.nf], rho[lbsy.nf];
  double drdx, drdy, drdz, dpdx, dpdy, dpdz;

  // sort out forces
  
  fD3Q19BoundaryForceVelocity(force, tpos, rpos, dx, dy, dz, uwall, prop);

  // apply boundary condition
    
  if(prop>26) {
    fGetAllMassSite(rho, &lbf[rpos*lbsitelength]);
    if(interact==20) {
      drdx = lbft[4*lbsy.nf*rpos  ];
      drdy = lbft[4*lbsy.nf*rpos+1];
      drdz = lbft[4*lbsy.nf*rpos+2];
      rho[0] += (dx*drdx+dy*drdy+dz*drdz);
      if(lbsy.nf>1) {
        dpdx = lbft[4*lbsy.nf*rpos+4];
        dpdy = lbft[4*lbsy.nf*rpos+5];
        dpdz = lbft[4*lbsy.nf*rpos+6];
        rho[1] += (dx*dpdx+dy*dpdy+dz*dpdz);
      }
    }
  }
    
  if(collide>11) {
    switch (prop) {
      case PST:
        fD3Q19VPSCLBEZouHe(uwall[0], uwall[1], uwall[2], &force[0], &lbf[spos], &lbf[spos+1*qdim],
                           &lbf[spos+2*qdim], &lbf[spos+3*qdim], &lbf[spos+4*qdim], &lbf[spos+5*qdim],
                           &lbf[spos+6*qdim], &lbf[spos+7*qdim], &lbf[spos+8*qdim], &lbf[spos+9*qdim],
                           &lbf[spos+10*qdim], &lbf[spos+11*qdim], &lbf[spos+12*qdim], &lbf[spos+13*qdim],
                           &lbf[spos+14*qdim], &lbf[spos+15*qdim], &lbf[spos+16*qdim], &lbf[spos+17*qdim],
                           &lbf[spos+18*qdim]);
        break;
      case PSD:
        fD3Q19VPSCLBEZouHe(-uwall[0], -uwall[1], -uwall[2], &force[0], &lbf[spos], &lbf[spos+10*qdim],
                           &lbf[spos+11*qdim], &lbf[spos+12*qdim], &lbf[spos+13*qdim], &lbf[spos+14*qdim],
                           &lbf[spos+15*qdim], &lbf[spos+16*qdim], &lbf[spos+17*qdim], &lbf[spos+18*qdim],
                           &lbf[spos+1*qdim], &lbf[spos+2*qdim], &lbf[spos+3*qdim], &lbf[spos+4*qdim],
                           &lbf[spos+5*qdim], &lbf[spos+6*qdim], &lbf[spos+7*qdim], &lbf[spos+8*qdim],
                           &lbf[spos+9*qdim]);
        break;
      case PSL:
        fD3Q19VPSCLBEZouHe(-uwall[2], -uwall[0], -uwall[1], &force[0], &lbf[spos], &lbf[spos+12*qdim],
                           &lbf[spos+10*qdim], &lbf[spos+11*qdim], &lbf[spos+15*qdim], &lbf[spos+7*qdim],
                           &lbf[spos+17*qdim], &lbf[spos+9*qdim], &lbf[spos+13*qdim], &lbf[spos+14*qdim],
                           &lbf[spos+3*qdim], &lbf[spos+1*qdim], &lbf[spos+2*qdim], &lbf[spos+6*qdim],
                           &lbf[spos+16*qdim], &lbf[spos+8*qdim], &lbf[spos+18*qdim], &lbf[spos+4*qdim],
                           &lbf[spos+5*qdim]);
        break;
      case PSR:
        fD3Q19VPSCLBEZouHe(uwall[2], uwall[0], uwall[1], &force[0], &lbf[spos], &lbf[spos+3*qdim],
                           &lbf[spos+1*qdim], &lbf[spos+2*qdim], &lbf[spos+6*qdim], &lbf[spos+16*qdim],
                           &lbf[spos+8*qdim], &lbf[spos+18*qdim], &lbf[spos+4*qdim], &lbf[spos+5*qdim],
                           &lbf[spos+12*qdim], &lbf[spos+10*qdim], &lbf[spos+11*qdim], &lbf[spos+15*qdim],
                           &lbf[spos+7*qdim], &lbf[spos+17*qdim], &lbf[spos+9*qdim], &lbf[spos+13*qdim],
                           &lbf[spos+14*qdim]);
        break;
      case PSF:
        fD3Q19VPSCLBEZouHe(-uwall[1], -uwall[2], -uwall[0], &force[0], &lbf[spos], &lbf[spos+11*qdim],
                           &lbf[spos+12*qdim], &lbf[spos+10*qdim], &lbf[spos+17*qdim], &lbf[spos+18*qdim],
                           &lbf[spos+13*qdim], &lbf[spos+5*qdim], &lbf[spos+15*qdim], &lbf[spos+7*qdim],
                           &lbf[spos+2*qdim], &lbf[spos+3*qdim], &lbf[spos+1*qdim], &lbf[spos+8*qdim],
                           &lbf[spos+9*qdim], &lbf[spos+4*qdim], &lbf[spos+14*qdim], &lbf[spos+6*qdim],
                           &lbf[spos+16*qdim]);
        break;
      case PSB:
        fD3Q19VPSCLBEZouHe(uwall[1], uwall[2], uwall[0], &force[0], &lbf[spos], &lbf[spos+2*qdim],
                           &lbf[spos+3*qdim], &lbf[spos+1*qdim], &lbf[spos+8*qdim], &lbf[spos+9*qdim],
                           &lbf[spos+4*qdim], &lbf[spos+14*qdim], &lbf[spos+6*qdim], &lbf[spos+16*qdim],
                           &lbf[spos+11*qdim], &lbf[spos+12*qdim], &lbf[spos+10*qdim], &lbf[spos+17*qdim],
                           &lbf[spos+18*qdim], &lbf[spos+13*qdim], &lbf[spos+5*qdim], &lbf[spos+15*qdim],
                           &lbf[spos+7*qdim]);
        break;
      case CCTRB:
        fD3Q19VCCCLBEZouHe(rho, uwall[0], uwall[1], -uwall[2], &force[0], &lbf[spos], &lbf[spos+1*qdim],
                           &lbf[spos+2*qdim], &lbf[spos+12*qdim], &lbf[spos+4*qdim], &lbf[spos+5*qdim],
                           &lbf[spos+7*qdim], &lbf[spos+6*qdim], &lbf[spos+9*qdim], &lbf[spos+8*qdim],
                           &lbf[spos+10*qdim], &lbf[spos+11*qdim], &lbf[spos+3*qdim], &lbf[spos+13*qdim],
                           &lbf[spos+14*qdim], &lbf[spos+16*qdim], &lbf[spos+15*qdim], &lbf[spos+18*qdim],
                           &lbf[spos+17*qdim]);
        break;
      case CCTLB:
        fD3Q19VCCCLBEZouHe(rho, -uwall[0], uwall[1], -uwall[2], &force[0], &lbf[spos], &lbf[spos+10*qdim],
                           &lbf[spos+2*qdim], &lbf[spos+12*qdim], &lbf[spos+14*qdim], &lbf[spos+13*qdim],
                           &lbf[spos+15*qdim], &lbf[spos+16*qdim], &lbf[spos+9*qdim], &lbf[spos+8*qdim],
                           &lbf[spos+1*qdim], &lbf[spos+11*qdim], &lbf[spos+3*qdim], &lbf[spos+5*qdim],
                           &lbf[spos+4*qdim], &lbf[spos+6*qdim], &lbf[spos+7*qdim], &lbf[spos+18*qdim],
                           &lbf[spos+17*qdim]);
        break;
      case CCDLB:
        fD3Q19VCCCLBEZouHe(rho, -uwall[0], -uwall[1], -uwall[2], &force[0], &lbf[spos], &lbf[spos+10*qdim],
                           &lbf[spos+11*qdim], &lbf[spos+12*qdim], &lbf[spos+13*qdim], &lbf[spos+14*qdim],
                           &lbf[spos+15*qdim], &lbf[spos+16*qdim], &lbf[spos+17*qdim], &lbf[spos+18*qdim],
                           &lbf[spos+1*qdim], &lbf[spos+2*qdim], &lbf[spos+3*qdim], &lbf[spos+4*qdim],
                           &lbf[spos+5*qdim], &lbf[spos+6*qdim], &lbf[spos+7*qdim], &lbf[spos+8*qdim],
                           &lbf[spos+9*qdim]);
        break;
      case CCDRB:
        fD3Q19VCCCLBEZouHe(rho, uwall[0], -uwall[1], -uwall[2], &force[0], &lbf[spos], &lbf[spos+1*qdim],
                           &lbf[spos+11*qdim], &lbf[spos+12*qdim], &lbf[spos+5*qdim], &lbf[spos+4*qdim],
                           &lbf[spos+7*qdim], &lbf[spos+6*qdim], &lbf[spos+17*qdim], &lbf[spos+18*qdim],
                           &lbf[spos+10*qdim], &lbf[spos+2*qdim], &lbf[spos+3*qdim], &lbf[spos+14*qdim],
                           &lbf[spos+13*qdim], &lbf[spos+16*qdim], &lbf[spos+15*qdim], &lbf[spos+8*qdim],
                           &lbf[spos+9*qdim]);
        break;
      case CCTRF:
        fD3Q19VCCCLBEZouHe(rho, uwall[0], uwall[1], uwall[2], &force[0], &lbf[spos], &lbf[spos+1*qdim],
                           &lbf[spos+2*qdim], &lbf[spos+3*qdim], &lbf[spos+4*qdim], &lbf[spos+5*qdim],
                           &lbf[spos+6*qdim], &lbf[spos+7*qdim], &lbf[spos+8*qdim], &lbf[spos+9*qdim],
                           &lbf[spos+10*qdim], &lbf[spos+11*qdim], &lbf[spos+12*qdim], &lbf[spos+13*qdim],
                           &lbf[spos+14*qdim], &lbf[spos+15*qdim], &lbf[spos+16*qdim], &lbf[spos+17*qdim],
                           &lbf[spos+18*qdim]);
        break;
      case CCTLF:
        fD3Q19VCCCLBEZouHe(rho, -uwall[0], uwall[1], uwall[2], &force[0], &lbf[spos], &lbf[spos+10*qdim],
                           &lbf[spos+2*qdim], &lbf[spos+3*qdim], &lbf[spos+14*qdim], &lbf[spos+13*qdim],
                           &lbf[spos+16*qdim], &lbf[spos+15*qdim], &lbf[spos+8*qdim], &lbf[spos+9*qdim],
                           &lbf[spos+1*qdim], &lbf[spos+11*qdim], &lbf[spos+12*qdim], &lbf[spos+5*qdim],
                           &lbf[spos+4*qdim], &lbf[spos+7*qdim], &lbf[spos+6*qdim], &lbf[spos+17*qdim],
                           &lbf[spos+18*qdim]);
        break;
      case CCDLF:
        fD3Q19VCCCLBEZouHe(rho, -uwall[0], -uwall[1], uwall[2], &force[0], &lbf[spos], &lbf[spos+10*qdim],
                           &lbf[spos+11*qdim], &lbf[spos+3*qdim], &lbf[spos+13*qdim], &lbf[spos+14*qdim],
                           &lbf[spos+16*qdim], &lbf[spos+15*qdim], &lbf[spos+18*qdim], &lbf[spos+17*qdim],
                           &lbf[spos+1*qdim], &lbf[spos+2*qdim], &lbf[spos+12*qdim], &lbf[spos+4*qdim],
                           &lbf[spos+5*qdim], &lbf[spos+7*qdim], &lbf[spos+6*qdim], &lbf[spos+9*qdim],
                           &lbf[spos+8*qdim]);
        break;
      case CCDRF:
        fD3Q19VCCCLBEZouHe(rho, uwall[0], -uwall[1], uwall[2], &force[0], &lbf[spos], &lbf[spos+1*qdim],
                           &lbf[spos+11*qdim], &lbf[spos+3*qdim], &lbf[spos+5*qdim], &lbf[spos+4*qdim],
                           &lbf[spos+6*qdim], &lbf[spos+7*qdim], &lbf[spos+18*qdim], &lbf[spos+17*qdim],
                           &lbf[spos+10*qdim], &lbf[spos+2*qdim], &lbf[spos+12*qdim], &lbf[spos+14*qdim],
                           &lbf[spos+13*qdim], &lbf[spos+15*qdim], &lbf[spos+16*qdim], &lbf[spos+9*qdim],
                           &lbf[spos+8*qdim]);
        break;
      case CETR:
        fD3Q19VCECLBEZouHe(rho, uwall[0], uwall[1], uwall[2], &force[0], &lbf[spos], &lbf[spos+1*qdim],
                           &lbf[spos+2*qdim], &lbf[spos+3*qdim], &lbf[spos+4*qdim], &lbf[spos+5*qdim],
                           &lbf[spos+6*qdim], &lbf[spos+7*qdim], &lbf[spos+8*qdim], &lbf[spos+9*qdim],
                           &lbf[spos+10*qdim], &lbf[spos+11*qdim], &lbf[spos+12*qdim], &lbf[spos+13*qdim],
                           &lbf[spos+14*qdim], &lbf[spos+15*qdim], &lbf[spos+16*qdim], &lbf[spos+17*qdim],
                           &lbf[spos+18*qdim]);
        break;
      case CETL:
        fD3Q19VCECLBEZouHe(rho, uwall[1], -uwall[0], uwall[2], &force[0], &lbf[spos], &lbf[spos+2*qdim],
                           &lbf[spos+10*qdim], &lbf[spos+3*qdim], &lbf[spos+14*qdim], &lbf[spos+4*qdim],
                           &lbf[spos+8*qdim], &lbf[spos+9*qdim], &lbf[spos+16*qdim], &lbf[spos+15*qdim],
                           &lbf[spos+11*qdim], &lbf[spos+1*qdim], &lbf[spos+12*qdim], &lbf[spos+5*qdim],
                           &lbf[spos+13*qdim], &lbf[spos+17*qdim], &lbf[spos+18*qdim], &lbf[spos+7*qdim],
                           &lbf[spos+6*qdim]);
        break;
      case CEDL:
        fD3Q19VCECLBEZouHe(rho, -uwall[0], -uwall[1], uwall[2], &force[0], &lbf[spos], &lbf[spos+10*qdim],
                           &lbf[spos+11*qdim], &lbf[spos+3*qdim], &lbf[spos+13*qdim], &lbf[spos+14*qdim],
                           &lbf[spos+16*qdim], &lbf[spos+15*qdim], &lbf[spos+18*qdim], &lbf[spos+17*qdim],
                           &lbf[spos+1*qdim], &lbf[spos+2*qdim], &lbf[spos+12*qdim], &lbf[spos+4*qdim],
                           &lbf[spos+5*qdim], &lbf[spos+7*qdim], &lbf[spos+6*qdim], &lbf[spos+9*qdim],
                           &lbf[spos+8*qdim]);
        break;
      case CEDR:
        fD3Q19VCECLBEZouHe(rho, -uwall[1], uwall[0], uwall[2], &force[0], &lbf[spos], &lbf[spos+11*qdim],
                           &lbf[spos+1*qdim], &lbf[spos+3*qdim], &lbf[spos+5*qdim], &lbf[spos+13*qdim],
                           &lbf[spos+18*qdim], &lbf[spos+17*qdim], &lbf[spos+6*qdim], &lbf[spos+7*qdim],
                           &lbf[spos+2*qdim], &lbf[spos+10*qdim], &lbf[spos+12*qdim], &lbf[spos+14*qdim],
                           &lbf[spos+4*qdim], &lbf[spos+9*qdim], &lbf[spos+8*qdim], &lbf[spos+15*qdim],
                           &lbf[spos+16*qdim]);
        break;
      case CETF:
        fD3Q19VCECLBEZouHe(rho, uwall[1], uwall[2], uwall[0], &force[0], &lbf[spos], &lbf[spos+2*qdim],
                           &lbf[spos+3*qdim], &lbf[spos+1*qdim], &lbf[spos+8*qdim], &lbf[spos+9*qdim],
                           &lbf[spos+4*qdim], &lbf[spos+14*qdim], &lbf[spos+6*qdim], &lbf[spos+16*qdim],
                           &lbf[spos+11*qdim], &lbf[spos+12*qdim], &lbf[spos+10*qdim], &lbf[spos+17*qdim],
                           &lbf[spos+18*qdim], &lbf[spos+13*qdim], &lbf[spos+5*qdim], &lbf[spos+15*qdim],
                           &lbf[spos+7*qdim]);
        break;
      case CELF:
        fD3Q19VCECLBEZouHe(rho, -uwall[0], uwall[2], uwall[1], &force[0], &lbf[spos], &lbf[spos+10*qdim],
                           &lbf[spos+3*qdim], &lbf[spos+2*qdim], &lbf[spos+16*qdim], &lbf[spos+15*qdim],
                           &lbf[spos+14*qdim], &lbf[spos+13*qdim], &lbf[spos+8*qdim], &lbf[spos+18*qdim],
                           &lbf[spos+1*qdim], &lbf[spos+12*qdim], &lbf[spos+11*qdim], &lbf[spos+7*qdim],
                           &lbf[spos+6*qdim], &lbf[spos+5*qdim], &lbf[spos+4*qdim], &lbf[spos+17*qdim],
                           &lbf[spos+9*qdim]);
        break;
      case CEDF:
        fD3Q19VCECLBEZouHe(rho, -uwall[1], uwall[2], uwall[0], &force[0], &lbf[spos], &lbf[spos+11*qdim],
                           &lbf[spos+3*qdim], &lbf[spos+1*qdim], &lbf[spos+18*qdim], &lbf[spos+17*qdim],
                           &lbf[spos+5*qdim], &lbf[spos+13*qdim], &lbf[spos+6*qdim], &lbf[spos+16*qdim],
                           &lbf[spos+2*qdim], &lbf[spos+12*qdim], &lbf[spos+10*qdim], &lbf[spos+9*qdim],
                           &lbf[spos+8*qdim], &lbf[spos+14*qdim], &lbf[spos+4*qdim], &lbf[spos+15*qdim],
                           &lbf[spos+7*qdim]);
        break;
      case CERF:
        fD3Q19VCECLBEZouHe(rho, uwall[0], uwall[2], uwall[1], &force[0], &lbf[spos], &lbf[spos+1*qdim],
                           &lbf[spos+3*qdim], &lbf[spos+2*qdim], &lbf[spos+6*qdim], &lbf[spos+7*qdim],
                           &lbf[spos+4*qdim], &lbf[spos+5*qdim], &lbf[spos+8*qdim], &lbf[spos+18*qdim],
                           &lbf[spos+10*qdim], &lbf[spos+12*qdim], &lbf[spos+11*qdim], &lbf[spos+15*qdim],
                           &lbf[spos+16*qdim], &lbf[spos+13*qdim], &lbf[spos+14*qdim], &lbf[spos+17*qdim],
                           &lbf[spos+9*qdim]);
        break;
      case CETB:
        fD3Q19VCECLBEZouHe(rho, uwall[1], -uwall[2], uwall[0], &force[0], &lbf[spos], &lbf[spos+2*qdim],
                           &lbf[spos+12*qdim], &lbf[spos+1*qdim], &lbf[spos+9*qdim], &lbf[spos+8*qdim],
                           &lbf[spos+4*qdim], &lbf[spos+14*qdim], &lbf[spos+7*qdim], &lbf[spos+15*qdim],
                           &lbf[spos+11*qdim], &lbf[spos+3*qdim], &lbf[spos+10*qdim], &lbf[spos+18*qdim],
                           &lbf[spos+17*qdim], &lbf[spos+13*qdim], &lbf[spos+5*qdim], &lbf[spos+16*qdim],
                           &lbf[spos+6*qdim]);
        break;
      case CELB:
        fD3Q19VCECLBEZouHe(rho, -uwall[0], -uwall[2], uwall[1], &force[0], &lbf[spos], &lbf[spos+10*qdim],
                           &lbf[spos+12*qdim], &lbf[spos+2*qdim], &lbf[spos+15*qdim], &lbf[spos+16*qdim],
                           &lbf[spos+14*qdim], &lbf[spos+13*qdim], &lbf[spos+9*qdim], &lbf[spos+17*qdim],
                           &lbf[spos+1*qdim], &lbf[spos+3*qdim], &lbf[spos+11*qdim], &lbf[spos+6*qdim],
                           &lbf[spos+7*qdim], &lbf[spos+5*qdim], &lbf[spos+4*qdim], &lbf[spos+18*qdim],
                           &lbf[spos+8*qdim]);
        break;
      case CEDB:
        fD3Q19VCECLBEZouHe(rho, -uwall[1], -uwall[2], uwall[0], &force[0], &lbf[spos], &lbf[spos+11*qdim],
                           &lbf[spos+12*qdim], &lbf[spos+1*qdim], &lbf[spos+17*qdim], &lbf[spos+18*qdim],
                           &lbf[spos+5*qdim], &lbf[spos+13*qdim], &lbf[spos+7*qdim], &lbf[spos+15*qdim],
                           &lbf[spos+2*qdim], &lbf[spos+3*qdim], &lbf[spos+10*qdim], &lbf[spos+8*qdim],
                           &lbf[spos+9*qdim], &lbf[spos+14*qdim], &lbf[spos+4*qdim], &lbf[spos+16*qdim],
                           &lbf[spos+6*qdim]);
        break;
      case CERB:
        fD3Q19VCECLBEZouHe(rho, uwall[0], -uwall[2], uwall[1], &force[0], &lbf[spos], &lbf[spos+1*qdim],
                           &lbf[spos+12*qdim], &lbf[spos+2*qdim], &lbf[spos+7*qdim], &lbf[spos+6*qdim],
                           &lbf[spos+4*qdim], &lbf[spos+5*qdim], &lbf[spos+9*qdim], &lbf[spos+17*qdim],
                           &lbf[spos+10*qdim], &lbf[spos+3*qdim], &lbf[spos+11*qdim], &lbf[spos+16*qdim],
                           &lbf[spos+15*qdim], &lbf[spos+13*qdim], &lbf[spos+14*qdim], &lbf[spos+18*qdim],
                           &lbf[spos+8*qdim]);
        break;
    }
  }
  else {
    switch (prop) {
      case PST:
        fD3Q19VPSZouHe(uwall[0], uwall[1], uwall[2], &force[0], &lbf[spos], &lbf[spos+1*qdim],
                       &lbf[spos+2*qdim], &lbf[spos+3*qdim], &lbf[spos+4*qdim], &lbf[spos+5*qdim],
                       &lbf[spos+6*qdim], &lbf[spos+7*qdim], &lbf[spos+8*qdim], &lbf[spos+9*qdim],
                       &lbf[spos+10*qdim], &lbf[spos+11*qdim], &lbf[spos+12*qdim], &lbf[spos+13*qdim],
                       &lbf[spos+14*qdim], &lbf[spos+15*qdim], &lbf[spos+16*qdim], &lbf[spos+17*qdim],
                       &lbf[spos+18*qdim]);
        break;
      case PSD:
        fD3Q19VPSZouHe(-uwall[0], -uwall[1], -uwall[2], &force[0], &lbf[spos], &lbf[spos+10*qdim],
                       &lbf[spos+11*qdim], &lbf[spos+12*qdim], &lbf[spos+13*qdim], &lbf[spos+14*qdim],
                       &lbf[spos+15*qdim], &lbf[spos+16*qdim], &lbf[spos+17*qdim], &lbf[spos+18*qdim],
                       &lbf[spos+1*qdim], &lbf[spos+2*qdim], &lbf[spos+3*qdim], &lbf[spos+4*qdim],
                       &lbf[spos+5*qdim], &lbf[spos+6*qdim], &lbf[spos+7*qdim], &lbf[spos+8*qdim],
                       &lbf[spos+9*qdim]);
        break;
      case PSL:
        fD3Q19VPSZouHe(-uwall[2], -uwall[0], -uwall[1], &force[0], &lbf[spos], &lbf[spos+12*qdim],
                       &lbf[spos+10*qdim], &lbf[spos+11*qdim], &lbf[spos+15*qdim], &lbf[spos+7*qdim],
                       &lbf[spos+17*qdim], &lbf[spos+9*qdim], &lbf[spos+13*qdim], &lbf[spos+14*qdim],
                       &lbf[spos+3*qdim], &lbf[spos+1*qdim], &lbf[spos+2*qdim], &lbf[spos+6*qdim],
                       &lbf[spos+16*qdim], &lbf[spos+8*qdim], &lbf[spos+18*qdim], &lbf[spos+4*qdim],
                       &lbf[spos+5*qdim]);
        break;
      case PSR:
        fD3Q19VPSZouHe(uwall[2], uwall[0], uwall[1], &force[0], &lbf[spos], &lbf[spos+3*qdim],
                       &lbf[spos+1*qdim], &lbf[spos+2*qdim], &lbf[spos+6*qdim], &lbf[spos+16*qdim],
                       &lbf[spos+8*qdim], &lbf[spos+18*qdim], &lbf[spos+4*qdim], &lbf[spos+5*qdim],
                       &lbf[spos+12*qdim], &lbf[spos+10*qdim], &lbf[spos+11*qdim], &lbf[spos+15*qdim],
                       &lbf[spos+7*qdim], &lbf[spos+17*qdim], &lbf[spos+9*qdim], &lbf[spos+13*qdim],
                       &lbf[spos+14*qdim]);
        break;
      case PSF:
        fD3Q19VPSZouHe(-uwall[1], -uwall[2], -uwall[0], &force[0], &lbf[spos], &lbf[spos+11*qdim],
                       &lbf[spos+12*qdim], &lbf[spos+10*qdim], &lbf[spos+17*qdim], &lbf[spos+18*qdim],
                       &lbf[spos+13*qdim], &lbf[spos+5*qdim], &lbf[spos+15*qdim], &lbf[spos+7*qdim],
                       &lbf[spos+2*qdim], &lbf[spos+3*qdim], &lbf[spos+1*qdim], &lbf[spos+8*qdim],
                       &lbf[spos+9*qdim], &lbf[spos+4*qdim], &lbf[spos+14*qdim], &lbf[spos+6*qdim],
                       &lbf[spos+16*qdim]);
        break;
      case PSB:
        fD3Q19VPSZouHe(uwall[1], uwall[2], uwall[0], &force[0], &lbf[spos], &lbf[spos+2*qdim],
                       &lbf[spos+3*qdim], &lbf[spos+1*qdim], &lbf[spos+8*qdim], &lbf[spos+9*qdim],
                       &lbf[spos+4*qdim], &lbf[spos+14*qdim], &lbf[spos+6*qdim], &lbf[spos+16*qdim],
                       &lbf[spos+11*qdim], &lbf[spos+12*qdim], &lbf[spos+10*qdim], &lbf[spos+17*qdim],
                       &lbf[spos+18*qdim], &lbf[spos+13*qdim], &lbf[spos+5*qdim], &lbf[spos+15*qdim],
                       &lbf[spos+7*qdim]);
        break;
      case CCTRB:
        fD3Q19VCCZouHe(rho, uwall[0], uwall[1], -uwall[2], &force[0], &lbf[spos], &lbf[spos+1*qdim],
                       &lbf[spos+2*qdim], &lbf[spos+12*qdim], &lbf[spos+4*qdim], &lbf[spos+5*qdim],
                       &lbf[spos+7*qdim], &lbf[spos+6*qdim], &lbf[spos+9*qdim], &lbf[spos+8*qdim],
                       &lbf[spos+10*qdim], &lbf[spos+11*qdim], &lbf[spos+3*qdim], &lbf[spos+13*qdim],
                       &lbf[spos+14*qdim], &lbf[spos+16*qdim], &lbf[spos+15*qdim], &lbf[spos+18*qdim],
                       &lbf[spos+17*qdim]);
        break;
      case CCTLB:
        fD3Q19VCCZouHe(rho, -uwall[0], uwall[1], -uwall[2], &force[0], &lbf[spos], &lbf[spos+10*qdim],
                       &lbf[spos+2*qdim], &lbf[spos+12*qdim], &lbf[spos+14*qdim], &lbf[spos+13*qdim],
                       &lbf[spos+15*qdim], &lbf[spos+16*qdim], &lbf[spos+9*qdim], &lbf[spos+8*qdim],
                       &lbf[spos+1*qdim], &lbf[spos+11*qdim], &lbf[spos+3*qdim], &lbf[spos+5*qdim],
                       &lbf[spos+4*qdim], &lbf[spos+6*qdim], &lbf[spos+7*qdim], &lbf[spos+18*qdim],
                       &lbf[spos+17*qdim]);
        break;
      case CCDLB:
        fD3Q19VCCZouHe(rho, -uwall[0], -uwall[1], -uwall[2], &force[0], &lbf[spos], &lbf[spos+10*qdim],
                       &lbf[spos+11*qdim], &lbf[spos+12*qdim], &lbf[spos+13*qdim], &lbf[spos+14*qdim],
                       &lbf[spos+15*qdim], &lbf[spos+16*qdim], &lbf[spos+17*qdim], &lbf[spos+18*qdim],
                       &lbf[spos+1*qdim], &lbf[spos+2*qdim], &lbf[spos+3*qdim], &lbf[spos+4*qdim],
                       &lbf[spos+5*qdim], &lbf[spos+6*qdim], &lbf[spos+7*qdim], &lbf[spos+8*qdim],
                       &lbf[spos+9*qdim]);
        break;
      case CCDRB:
        fD3Q19VCCZouHe(rho, uwall[0], -uwall[1], -uwall[2], &force[0], &lbf[spos], &lbf[spos+1*qdim],
                       &lbf[spos+11*qdim], &lbf[spos+12*qdim], &lbf[spos+5*qdim], &lbf[spos+4*qdim],
                       &lbf[spos+7*qdim], &lbf[spos+6*qdim], &lbf[spos+17*qdim], &lbf[spos+18*qdim],
                       &lbf[spos+10*qdim], &lbf[spos+2*qdim], &lbf[spos+3*qdim], &lbf[spos+14*qdim],
                       &lbf[spos+13*qdim], &lbf[spos+16*qdim], &lbf[spos+15*qdim], &lbf[spos+8*qdim],
                       &lbf[spos+9*qdim]);
        break;
      case CCTRF:
        fD3Q19VCCZouHe(rho, uwall[0], uwall[1], uwall[2], &force[0], &lbf[spos], &lbf[spos+1*qdim],
                       &lbf[spos+2*qdim], &lbf[spos+3*qdim], &lbf[spos+4*qdim], &lbf[spos+5*qdim],
                       &lbf[spos+6*qdim], &lbf[spos+7*qdim], &lbf[spos+8*qdim], &lbf[spos+9*qdim],
                       &lbf[spos+10*qdim], &lbf[spos+11*qdim], &lbf[spos+12*qdim], &lbf[spos+13*qdim],
                       &lbf[spos+14*qdim], &lbf[spos+15*qdim], &lbf[spos+16*qdim], &lbf[spos+17*qdim],
                       &lbf[spos+18*qdim]);
        break;
      case CCTLF:
        fD3Q19VCCZouHe(rho, -uwall[0], uwall[1], uwall[2], &force[0], &lbf[spos], &lbf[spos+10*qdim],
                       &lbf[spos+2*qdim], &lbf[spos+3*qdim], &lbf[spos+14*qdim], &lbf[spos+13*qdim],
                       &lbf[spos+16*qdim], &lbf[spos+15*qdim], &lbf[spos+8*qdim], &lbf[spos+9*qdim],
                       &lbf[spos+1*qdim], &lbf[spos+11*qdim], &lbf[spos+12*qdim], &lbf[spos+5*qdim],
                       &lbf[spos+4*qdim], &lbf[spos+7*qdim], &lbf[spos+6*qdim], &lbf[spos+17*qdim],
                       &lbf[spos+18*qdim]);
        break;
      case CCDLF:
        fD3Q19VCCZouHe(rho, -uwall[0], -uwall[1], uwall[2], &force[0], &lbf[spos], &lbf[spos+10*qdim],
                       &lbf[spos+11*qdim], &lbf[spos+3*qdim], &lbf[spos+13*qdim], &lbf[spos+14*qdim],
                       &lbf[spos+16*qdim], &lbf[spos+15*qdim], &lbf[spos+18*qdim], &lbf[spos+17*qdim],
                       &lbf[spos+1*qdim], &lbf[spos+2*qdim], &lbf[spos+12*qdim], &lbf[spos+4*qdim],
                       &lbf[spos+5*qdim], &lbf[spos+7*qdim], &lbf[spos+6*qdim], &lbf[spos+9*qdim],
                       &lbf[spos+8*qdim]);
        break;
      case CCDRF:
        fD3Q19VCCZouHe(rho, uwall[0], -uwall[1], uwall[2], &force[0], &lbf[spos], &lbf[spos+1*qdim],
                       &lbf[spos+11*qdim], &lbf[spos+3*qdim], &lbf[spos+5*qdim], &lbf[spos+4*qdim],
                       &lbf[spos+6*qdim], &lbf[spos+7*qdim], &lbf[spos+18*qdim], &lbf[spos+17*qdim],
                       &lbf[spos+10*qdim], &lbf[spos+2*qdim], &lbf[spos+12*qdim], &lbf[spos+14*qdim],
                       &lbf[spos+13*qdim], &lbf[spos+15*qdim], &lbf[spos+16*qdim], &lbf[spos+9*qdim],
                       &lbf[spos+8*qdim]);
        break;
      case CETR:
        fD3Q19VCEZouHe(rho, uwall[0], uwall[1], uwall[2], &force[0], &lbf[spos], &lbf[spos+1*qdim],
                       &lbf[spos+2*qdim], &lbf[spos+3*qdim], &lbf[spos+4*qdim], &lbf[spos+5*qdim],
                       &lbf[spos+6*qdim], &lbf[spos+7*qdim], &lbf[spos+8*qdim], &lbf[spos+9*qdim],
                       &lbf[spos+10*qdim], &lbf[spos+11*qdim], &lbf[spos+12*qdim], &lbf[spos+13*qdim],
                       &lbf[spos+14*qdim], &lbf[spos+15*qdim], &lbf[spos+16*qdim], &lbf[spos+17*qdim],
                       &lbf[spos+18*qdim]);
        break;
      case CETL:
        fD3Q19VCEZouHe(rho, uwall[1], -uwall[0], uwall[2], &force[0], &lbf[spos], &lbf[spos+2*qdim],
                       &lbf[spos+10*qdim], &lbf[spos+3*qdim], &lbf[spos+14*qdim], &lbf[spos+4*qdim],
                       &lbf[spos+8*qdim], &lbf[spos+9*qdim], &lbf[spos+16*qdim], &lbf[spos+15*qdim],
                       &lbf[spos+11*qdim], &lbf[spos+1*qdim], &lbf[spos+12*qdim], &lbf[spos+5*qdim],
                       &lbf[spos+13*qdim], &lbf[spos+17*qdim], &lbf[spos+18*qdim], &lbf[spos+7*qdim],
                       &lbf[spos+6*qdim]);
        break;
      case CEDL:
        fD3Q19VCEZouHe(rho, -uwall[0], -uwall[1], uwall[2], &force[0], &lbf[spos], &lbf[spos+10*qdim],
                       &lbf[spos+11*qdim], &lbf[spos+3*qdim], &lbf[spos+13*qdim], &lbf[spos+14*qdim],
                       &lbf[spos+16*qdim], &lbf[spos+15*qdim], &lbf[spos+18*qdim], &lbf[spos+17*qdim],
                       &lbf[spos+1*qdim], &lbf[spos+2*qdim], &lbf[spos+12*qdim], &lbf[spos+4*qdim],
                       &lbf[spos+5*qdim], &lbf[spos+7*qdim], &lbf[spos+6*qdim], &lbf[spos+9*qdim],
                       &lbf[spos+8*qdim]);
        break;
      case CEDR:
        fD3Q19VCEZouHe(rho, -uwall[1], uwall[0], uwall[2], &force[0], &lbf[spos], &lbf[spos+11*qdim],
                       &lbf[spos+1*qdim], &lbf[spos+3*qdim], &lbf[spos+5*qdim], &lbf[spos+13*qdim],
                       &lbf[spos+18*qdim], &lbf[spos+17*qdim], &lbf[spos+6*qdim], &lbf[spos+7*qdim],
                       &lbf[spos+2*qdim], &lbf[spos+10*qdim], &lbf[spos+12*qdim], &lbf[spos+14*qdim],
                       &lbf[spos+4*qdim], &lbf[spos+9*qdim], &lbf[spos+8*qdim], &lbf[spos+15*qdim],
                       &lbf[spos+16*qdim]);
        break;
      case CETF:
        fD3Q19VCEZouHe(rho, uwall[1], uwall[2], uwall[0], &force[0], &lbf[spos], &lbf[spos+2*qdim],
                       &lbf[spos+3*qdim], &lbf[spos+1*qdim], &lbf[spos+8*qdim], &lbf[spos+9*qdim],
                       &lbf[spos+4*qdim], &lbf[spos+14*qdim], &lbf[spos+6*qdim], &lbf[spos+16*qdim],
                       &lbf[spos+11*qdim], &lbf[spos+12*qdim], &lbf[spos+10*qdim], &lbf[spos+17*qdim],
                       &lbf[spos+18*qdim], &lbf[spos+13*qdim], &lbf[spos+5*qdim], &lbf[spos+15*qdim],
                       &lbf[spos+7*qdim]);
        break;
      case CELF:
        fD3Q19VCEZouHe(rho, -uwall[0], uwall[2], uwall[1], &force[0], &lbf[spos], &lbf[spos+10*qdim],
                       &lbf[spos+3*qdim], &lbf[spos+2*qdim], &lbf[spos+16*qdim], &lbf[spos+15*qdim],
                       &lbf[spos+14*qdim], &lbf[spos+13*qdim], &lbf[spos+8*qdim], &lbf[spos+18*qdim],
                       &lbf[spos+1*qdim], &lbf[spos+12*qdim], &lbf[spos+11*qdim], &lbf[spos+7*qdim],
                       &lbf[spos+6*qdim], &lbf[spos+5*qdim], &lbf[spos+4*qdim], &lbf[spos+17*qdim],
                       &lbf[spos+9*qdim]);
        break;
      case CEDF:
        fD3Q19VCEZouHe(rho, -uwall[1], uwall[2], uwall[0], &force[0], &lbf[spos], &lbf[spos+11*qdim],
                       &lbf[spos+3*qdim], &lbf[spos+1*qdim], &lbf[spos+18*qdim], &lbf[spos+17*qdim],
                       &lbf[spos+5*qdim], &lbf[spos+13*qdim], &lbf[spos+6*qdim], &lbf[spos+16*qdim],
                       &lbf[spos+2*qdim], &lbf[spos+12*qdim], &lbf[spos+10*qdim], &lbf[spos+9*qdim],
                       &lbf[spos+8*qdim], &lbf[spos+14*qdim], &lbf[spos+4*qdim], &lbf[spos+15*qdim],
                       &lbf[spos+7*qdim]);
        break;
      case CERF:
        fD3Q19VCEZouHe(rho, uwall[0], uwall[2], uwall[1], &force[0], &lbf[spos], &lbf[spos+1*qdim],
                       &lbf[spos+3*qdim], &lbf[spos+2*qdim], &lbf[spos+6*qdim], &lbf[spos+7*qdim],
                       &lbf[spos+4*qdim], &lbf[spos+5*qdim], &lbf[spos+8*qdim], &lbf[spos+18*qdim],
                       &lbf[spos+10*qdim], &lbf[spos+12*qdim], &lbf[spos+11*qdim], &lbf[spos+15*qdim],
                       &lbf[spos+16*qdim], &lbf[spos+13*qdim], &lbf[spos+14*qdim], &lbf[spos+17*qdim],
                       &lbf[spos+9*qdim]);
        break;
      case CETB:
        fD3Q19VCEZouHe(rho, uwall[1], -uwall[2], uwall[0], &force[0], &lbf[spos], &lbf[spos+2*qdim],
                       &lbf[spos+12*qdim], &lbf[spos+1*qdim], &lbf[spos+9*qdim], &lbf[spos+8*qdim],
                       &lbf[spos+4*qdim], &lbf[spos+14*qdim], &lbf[spos+7*qdim], &lbf[spos+15*qdim],
                       &lbf[spos+11*qdim], &lbf[spos+3*qdim], &lbf[spos+10*qdim], &lbf[spos+18*qdim],
                       &lbf[spos+17*qdim], &lbf[spos+13*qdim], &lbf[spos+5*qdim], &lbf[spos+16*qdim],
                       &lbf[spos+6*qdim]);
        break;
      case CELB:
        fD3Q19VCEZouHe(rho, -uwall[0], -uwall[2], uwall[1], &force[0], &lbf[spos], &lbf[spos+10*qdim],
                       &lbf[spos+12*qdim], &lbf[spos+2*qdim], &lbf[spos+15*qdim], &lbf[spos+16*qdim],
                       &lbf[spos+14*qdim], &lbf[spos+13*qdim], &lbf[spos+9*qdim], &lbf[spos+17*qdim],
                       &lbf[spos+1*qdim], &lbf[spos+3*qdim], &lbf[spos+11*qdim], &lbf[spos+6*qdim],
                       &lbf[spos+7*qdim], &lbf[spos+5*qdim], &lbf[spos+4*qdim], &lbf[spos+18*qdim],
                       &lbf[spos+8*qdim]);
        break;
      case CEDB:
        fD3Q19VCEZouHe(rho, -uwall[1], -uwall[2], uwall[0], &force[0], &lbf[spos], &lbf[spos+11*qdim],
                       &lbf[spos+12*qdim], &lbf[spos+1*qdim], &lbf[spos+17*qdim], &lbf[spos+18*qdim],
                       &lbf[spos+5*qdim], &lbf[spos+13*qdim], &lbf[spos+7*qdim], &lbf[spos+15*qdim],
                       &lbf[spos+2*qdim], &lbf[spos+3*qdim], &lbf[spos+10*qdim], &lbf[spos+8*qdim],
                       &lbf[spos+9*qdim], &lbf[spos+14*qdim], &lbf[spos+4*qdim], &lbf[spos+16*qdim],
                       &lbf[spos+6*qdim]);
        break;
      case CERB:
        fD3Q19VCEZouHe(rho, uwall[0], -uwall[2], uwall[1], &force[0], &lbf[spos], &lbf[spos+1*qdim],
                       &lbf[spos+12*qdim], &lbf[spos+2*qdim], &lbf[spos+7*qdim], &lbf[spos+6*qdim],
                       &lbf[spos+4*qdim], &lbf[spos+5*qdim], &lbf[spos+9*qdim], &lbf[spos+17*qdim],
                       &lbf[spos+10*qdim], &lbf[spos+3*qdim], &lbf[spos+11*qdim], &lbf[spos+16*qdim],
                       &lbf[spos+15*qdim], &lbf[spos+13*qdim], &lbf[spos+14*qdim], &lbf[spos+18*qdim],
                       &lbf[spos+8*qdim]);
        break;
    }
  }
  
  return 0;
  
}

int fD3Q19VFSimpleZouHe(long tpos, long rpos, int prop, double *uwall, double dx, double dy, double dz)
{
  long spos=tpos * lbsitelength;
  int qdim=lbsy.nf+lbsy.nc+lbsy.nt;
  double force[3*lbsy.nf], rho[lbsy.nf];
  double drdx, drdy, drdz, dpdx, dpdy, dpdz;

  // sort out forces
  
  fD3Q19BoundaryForceVelocity(force, tpos, rpos, dx, dy, dz, uwall, prop);

  // apply boundary condition
    
  if(prop>26) {
    fGetAllMassSite(rho, &lbf[rpos*lbsitelength]);
    if(interact==20) {
      drdx = lbft[4*lbsy.nf*rpos  ];
      drdy = lbft[4*lbsy.nf*rpos+1];
      drdz = lbft[4*lbsy.nf*rpos+2];
      rho[0] += (dx*drdx+dy*drdy+dz*drdz);
      if(lbsy.nf>1) {
        dpdx = lbft[4*lbsy.nf*rpos+4];
        dpdy = lbft[4*lbsy.nf*rpos+5];
        dpdz = lbft[4*lbsy.nf*rpos+6];
        rho[1] += (dx*dpdx+dy*dpdy+dz*dpdz);
      }
    }
  }
    
  if(collide>11) {
    switch (prop) {
      case PST:
        fD3Q19VPSCLBESimpleZouHe(uwall[0], uwall[1], uwall[2], &force[0], &lbf[spos], &lbf[spos+1*qdim],
                                 &lbf[spos+2*qdim], &lbf[spos+3*qdim], &lbf[spos+4*qdim], &lbf[spos+5*qdim],
                                 &lbf[spos+6*qdim], &lbf[spos+7*qdim], &lbf[spos+8*qdim], &lbf[spos+9*qdim],
                                 &lbf[spos+10*qdim], &lbf[spos+11*qdim], &lbf[spos+12*qdim], &lbf[spos+13*qdim],
                                 &lbf[spos+14*qdim], &lbf[spos+15*qdim], &lbf[spos+16*qdim], &lbf[spos+17*qdim],
                                 &lbf[spos+18*qdim]);
        break;
      case PSD:
        fD3Q19VPSCLBESimpleZouHe(-uwall[0], -uwall[1], -uwall[2], &force[0], &lbf[spos], &lbf[spos+10*qdim],
                                 &lbf[spos+11*qdim], &lbf[spos+12*qdim], &lbf[spos+13*qdim], &lbf[spos+14*qdim],
                                 &lbf[spos+15*qdim], &lbf[spos+16*qdim], &lbf[spos+17*qdim], &lbf[spos+18*qdim],
                                 &lbf[spos+1*qdim], &lbf[spos+2*qdim], &lbf[spos+3*qdim], &lbf[spos+4*qdim],
                                 &lbf[spos+5*qdim], &lbf[spos+6*qdim], &lbf[spos+7*qdim], &lbf[spos+8*qdim],
                                 &lbf[spos+9*qdim]);
        break;
      case PSL:
        fD3Q19VPSCLBESimpleZouHe(-uwall[2], -uwall[0], -uwall[1], &force[0], &lbf[spos], &lbf[spos+12*qdim],
                                 &lbf[spos+10*qdim], &lbf[spos+11*qdim], &lbf[spos+15*qdim], &lbf[spos+7*qdim],
                                 &lbf[spos+17*qdim], &lbf[spos+9*qdim], &lbf[spos+13*qdim], &lbf[spos+14*qdim],
                                 &lbf[spos+3*qdim], &lbf[spos+1*qdim], &lbf[spos+2*qdim], &lbf[spos+6*qdim],
                                 &lbf[spos+16*qdim], &lbf[spos+8*qdim], &lbf[spos+18*qdim], &lbf[spos+4*qdim],
                                 &lbf[spos+5*qdim]);
        break;
      case PSR:
        fD3Q19VPSCLBESimpleZouHe(uwall[2], uwall[0], uwall[1], &force[0], &lbf[spos], &lbf[spos+3*qdim],
                                 &lbf[spos+1*qdim], &lbf[spos+2*qdim], &lbf[spos+6*qdim], &lbf[spos+16*qdim],
                                 &lbf[spos+8*qdim], &lbf[spos+18*qdim], &lbf[spos+4*qdim], &lbf[spos+5*qdim],
                                 &lbf[spos+12*qdim], &lbf[spos+10*qdim], &lbf[spos+11*qdim], &lbf[spos+15*qdim],
                                 &lbf[spos+7*qdim], &lbf[spos+17*qdim], &lbf[spos+9*qdim], &lbf[spos+13*qdim],
                                 &lbf[spos+14*qdim]);
        break;
      case PSF:
        fD3Q19VPSCLBESimpleZouHe(-uwall[1], -uwall[2], -uwall[0], &force[0], &lbf[spos], &lbf[spos+11*qdim],
                                 &lbf[spos+12*qdim], &lbf[spos+10*qdim], &lbf[spos+17*qdim], &lbf[spos+18*qdim],
                                 &lbf[spos+13*qdim], &lbf[spos+5*qdim], &lbf[spos+15*qdim], &lbf[spos+7*qdim],
                                 &lbf[spos+2*qdim], &lbf[spos+3*qdim], &lbf[spos+1*qdim], &lbf[spos+8*qdim],
                                 &lbf[spos+9*qdim], &lbf[spos+4*qdim], &lbf[spos+14*qdim], &lbf[spos+6*qdim],
                                 &lbf[spos+16*qdim]);
        break;
      case PSB:
        fD3Q19VPSCLBESimpleZouHe(uwall[1], uwall[2], uwall[0], &force[0], &lbf[spos], &lbf[spos+2*qdim],
                                 &lbf[spos+3*qdim], &lbf[spos+1*qdim], &lbf[spos+8*qdim], &lbf[spos+9*qdim],
                                 &lbf[spos+4*qdim], &lbf[spos+14*qdim], &lbf[spos+6*qdim], &lbf[spos+16*qdim],
                                 &lbf[spos+11*qdim], &lbf[spos+12*qdim], &lbf[spos+10*qdim], &lbf[spos+17*qdim],
                                 &lbf[spos+18*qdim], &lbf[spos+13*qdim], &lbf[spos+5*qdim], &lbf[spos+15*qdim],
                                 &lbf[spos+7*qdim]);
        break;
      case CCTRB:
        fD3Q19VCCCLBESimpleZouHe(rho, uwall[0], uwall[1], -uwall[2], &force[0], &lbf[spos], &lbf[spos+1*qdim],
                                 &lbf[spos+2*qdim], &lbf[spos+12*qdim], &lbf[spos+4*qdim], &lbf[spos+5*qdim],
                                 &lbf[spos+7*qdim], &lbf[spos+6*qdim], &lbf[spos+9*qdim], &lbf[spos+8*qdim],
                                 &lbf[spos+10*qdim], &lbf[spos+11*qdim], &lbf[spos+3*qdim], &lbf[spos+13*qdim],
                                 &lbf[spos+14*qdim], &lbf[spos+16*qdim], &lbf[spos+15*qdim], &lbf[spos+18*qdim],
                                 &lbf[spos+17*qdim]);
        break;
      case CCTLB:
        fD3Q19VCCCLBESimpleZouHe(rho, -uwall[0], uwall[1], -uwall[2], &force[0], &lbf[spos], &lbf[spos+10*qdim],
                                 &lbf[spos+2*qdim], &lbf[spos+12*qdim], &lbf[spos+14*qdim], &lbf[spos+13*qdim],
                                 &lbf[spos+15*qdim], &lbf[spos+16*qdim], &lbf[spos+9*qdim], &lbf[spos+8*qdim],
                                 &lbf[spos+1*qdim], &lbf[spos+11*qdim], &lbf[spos+3*qdim], &lbf[spos+5*qdim],
                                 &lbf[spos+4*qdim], &lbf[spos+6*qdim], &lbf[spos+7*qdim], &lbf[spos+18*qdim],
                                 &lbf[spos+17*qdim]);
        break;
      case CCDLB:
        fD3Q19VCCCLBESimpleZouHe(rho, -uwall[0], -uwall[1], -uwall[2], &force[0], &lbf[spos], &lbf[spos+10*qdim],
                                 &lbf[spos+11*qdim], &lbf[spos+12*qdim], &lbf[spos+13*qdim], &lbf[spos+14*qdim],
                                 &lbf[spos+15*qdim], &lbf[spos+16*qdim], &lbf[spos+17*qdim], &lbf[spos+18*qdim],
                                 &lbf[spos+1*qdim], &lbf[spos+2*qdim], &lbf[spos+3*qdim], &lbf[spos+4*qdim],
                                 &lbf[spos+5*qdim], &lbf[spos+6*qdim], &lbf[spos+7*qdim], &lbf[spos+8*qdim],
                                 &lbf[spos+9*qdim]);
        break;
      case CCDRB:
        fD3Q19VCCCLBESimpleZouHe(rho, uwall[0], -uwall[1], -uwall[2], &force[0], &lbf[spos], &lbf[spos+1*qdim],
                                 &lbf[spos+11*qdim], &lbf[spos+12*qdim], &lbf[spos+5*qdim], &lbf[spos+4*qdim],
                                 &lbf[spos+7*qdim], &lbf[spos+6*qdim], &lbf[spos+17*qdim], &lbf[spos+18*qdim],
                                 &lbf[spos+10*qdim], &lbf[spos+2*qdim], &lbf[spos+3*qdim], &lbf[spos+14*qdim],
                                 &lbf[spos+13*qdim], &lbf[spos+16*qdim], &lbf[spos+15*qdim], &lbf[spos+8*qdim],
                                 &lbf[spos+9*qdim]);
        break;
      case CCTRF:
        fD3Q19VCCCLBESimpleZouHe(rho, uwall[0], uwall[1], uwall[2], &force[0], &lbf[spos], &lbf[spos+1*qdim],
                                 &lbf[spos+2*qdim], &lbf[spos+3*qdim], &lbf[spos+4*qdim], &lbf[spos+5*qdim],
                                 &lbf[spos+6*qdim], &lbf[spos+7*qdim], &lbf[spos+8*qdim], &lbf[spos+9*qdim],
                                 &lbf[spos+10*qdim], &lbf[spos+11*qdim], &lbf[spos+12*qdim], &lbf[spos+13*qdim],
                                 &lbf[spos+14*qdim], &lbf[spos+15*qdim], &lbf[spos+16*qdim], &lbf[spos+17*qdim],
                                 &lbf[spos+18*qdim]);
        break;
      case CCTLF:
        fD3Q19VCCCLBESimpleZouHe(rho, -uwall[0], uwall[1], uwall[2], &force[0], &lbf[spos], &lbf[spos+10*qdim],
                                 &lbf[spos+2*qdim], &lbf[spos+3*qdim], &lbf[spos+14*qdim], &lbf[spos+13*qdim],
                                 &lbf[spos+16*qdim], &lbf[spos+15*qdim], &lbf[spos+8*qdim], &lbf[spos+9*qdim],
                                 &lbf[spos+1*qdim], &lbf[spos+11*qdim], &lbf[spos+12*qdim], &lbf[spos+5*qdim],
                                 &lbf[spos+4*qdim], &lbf[spos+7*qdim], &lbf[spos+6*qdim], &lbf[spos+17*qdim],
                                 &lbf[spos+18*qdim]);
        break;
      case CCDLF:
        fD3Q19VCCCLBESimpleZouHe(rho, -uwall[0], -uwall[1], uwall[2], &force[0], &lbf[spos], &lbf[spos+10*qdim],
                                 &lbf[spos+11*qdim], &lbf[spos+3*qdim], &lbf[spos+13*qdim], &lbf[spos+14*qdim],
                                 &lbf[spos+16*qdim], &lbf[spos+15*qdim], &lbf[spos+18*qdim], &lbf[spos+17*qdim],
                                 &lbf[spos+1*qdim], &lbf[spos+2*qdim], &lbf[spos+12*qdim], &lbf[spos+4*qdim],
                                 &lbf[spos+5*qdim], &lbf[spos+7*qdim], &lbf[spos+6*qdim], &lbf[spos+9*qdim],
                                 &lbf[spos+8*qdim]);
        break;
      case CCDRF:
        fD3Q19VCCCLBESimpleZouHe(rho, uwall[0], -uwall[1], uwall[2], &force[0], &lbf[spos], &lbf[spos+1*qdim],
                                 &lbf[spos+11*qdim], &lbf[spos+3*qdim], &lbf[spos+5*qdim], &lbf[spos+4*qdim],
                                 &lbf[spos+6*qdim], &lbf[spos+7*qdim], &lbf[spos+18*qdim], &lbf[spos+17*qdim],
                                 &lbf[spos+10*qdim], &lbf[spos+2*qdim], &lbf[spos+12*qdim], &lbf[spos+14*qdim],
                                 &lbf[spos+13*qdim], &lbf[spos+15*qdim], &lbf[spos+16*qdim], &lbf[spos+9*qdim],
                                 &lbf[spos+8*qdim]);
        break;
      case CETR:
        fD3Q19VCECLBESimpleZouHe(rho, uwall[0], uwall[1], uwall[2], &force[0], &lbf[spos], &lbf[spos+1*qdim],
                                 &lbf[spos+2*qdim], &lbf[spos+3*qdim], &lbf[spos+4*qdim], &lbf[spos+5*qdim],
                                 &lbf[spos+6*qdim], &lbf[spos+7*qdim], &lbf[spos+8*qdim], &lbf[spos+9*qdim],
                                 &lbf[spos+10*qdim], &lbf[spos+11*qdim], &lbf[spos+12*qdim], &lbf[spos+13*qdim],
                                 &lbf[spos+14*qdim], &lbf[spos+15*qdim], &lbf[spos+16*qdim], &lbf[spos+17*qdim],
                                 &lbf[spos+18*qdim]);
        break;
      case CETL:
        fD3Q19VCECLBESimpleZouHe(rho, uwall[1], -uwall[0], uwall[2], &force[0], &lbf[spos], &lbf[spos+2*qdim],
                                 &lbf[spos+10*qdim], &lbf[spos+3*qdim], &lbf[spos+14*qdim], &lbf[spos+4*qdim],
                                 &lbf[spos+8*qdim], &lbf[spos+9*qdim], &lbf[spos+16*qdim], &lbf[spos+15*qdim],
                                 &lbf[spos+11*qdim], &lbf[spos+1*qdim], &lbf[spos+12*qdim], &lbf[spos+5*qdim],
                                 &lbf[spos+13*qdim], &lbf[spos+17*qdim], &lbf[spos+18*qdim], &lbf[spos+7*qdim],
                                 &lbf[spos+6*qdim]);
        break;
      case CEDL:
        fD3Q19VCECLBESimpleZouHe(rho, -uwall[0], -uwall[1], uwall[2], &force[0], &lbf[spos], &lbf[spos+10*qdim],
                                 &lbf[spos+11*qdim], &lbf[spos+3*qdim], &lbf[spos+13*qdim], &lbf[spos+14*qdim],
                                 &lbf[spos+16*qdim], &lbf[spos+15*qdim], &lbf[spos+18*qdim], &lbf[spos+17*qdim],
                                 &lbf[spos+1*qdim], &lbf[spos+2*qdim], &lbf[spos+12*qdim], &lbf[spos+4*qdim],
                                 &lbf[spos+5*qdim], &lbf[spos+7*qdim], &lbf[spos+6*qdim], &lbf[spos+9*qdim],
                                 &lbf[spos+8*qdim]);
        break;
      case CEDR:
        fD3Q19VCECLBESimpleZouHe(rho, -uwall[1], uwall[0], uwall[2], &force[0], &lbf[spos], &lbf[spos+11*qdim],
                                 &lbf[spos+1*qdim], &lbf[spos+3*qdim], &lbf[spos+5*qdim], &lbf[spos+13*qdim],
                                 &lbf[spos+18*qdim], &lbf[spos+17*qdim], &lbf[spos+6*qdim], &lbf[spos+7*qdim],
                                 &lbf[spos+2*qdim], &lbf[spos+10*qdim], &lbf[spos+12*qdim], &lbf[spos+14*qdim],
                                 &lbf[spos+4*qdim], &lbf[spos+9*qdim], &lbf[spos+8*qdim], &lbf[spos+15*qdim],
                                 &lbf[spos+16*qdim]);
        break;
      case CETF:
        fD3Q19VCECLBESimpleZouHe(rho, uwall[1], uwall[2], uwall[0], &force[0], &lbf[spos], &lbf[spos+2*qdim],
                                 &lbf[spos+3*qdim], &lbf[spos+1*qdim], &lbf[spos+8*qdim], &lbf[spos+9*qdim],
                                 &lbf[spos+4*qdim], &lbf[spos+14*qdim], &lbf[spos+6*qdim], &lbf[spos+16*qdim],
                                 &lbf[spos+11*qdim], &lbf[spos+12*qdim], &lbf[spos+10*qdim], &lbf[spos+17*qdim],
                                 &lbf[spos+18*qdim], &lbf[spos+13*qdim], &lbf[spos+5*qdim], &lbf[spos+15*qdim],
                                 &lbf[spos+7*qdim]);
        break;
      case CELF:
        fD3Q19VCECLBESimpleZouHe(rho, -uwall[0], uwall[2], uwall[1], &force[0], &lbf[spos], &lbf[spos+10*qdim],
                                 &lbf[spos+3*qdim], &lbf[spos+2*qdim], &lbf[spos+16*qdim], &lbf[spos+15*qdim],
                                 &lbf[spos+14*qdim], &lbf[spos+13*qdim], &lbf[spos+8*qdim], &lbf[spos+18*qdim],
                                 &lbf[spos+1*qdim], &lbf[spos+12*qdim], &lbf[spos+11*qdim], &lbf[spos+7*qdim],
                                 &lbf[spos+6*qdim], &lbf[spos+5*qdim], &lbf[spos+4*qdim], &lbf[spos+17*qdim],
                                 &lbf[spos+9*qdim]);
        break;
      case CEDF:
        fD3Q19VCECLBESimpleZouHe(rho, -uwall[1], uwall[2], uwall[0], &force[0], &lbf[spos], &lbf[spos+11*qdim],
                                 &lbf[spos+3*qdim], &lbf[spos+1*qdim], &lbf[spos+18*qdim], &lbf[spos+17*qdim],
                                 &lbf[spos+5*qdim], &lbf[spos+13*qdim], &lbf[spos+6*qdim], &lbf[spos+16*qdim],
                                 &lbf[spos+2*qdim], &lbf[spos+12*qdim], &lbf[spos+10*qdim], &lbf[spos+9*qdim],
                                 &lbf[spos+8*qdim], &lbf[spos+14*qdim], &lbf[spos+4*qdim], &lbf[spos+15*qdim],
                                 &lbf[spos+7*qdim]);
        break;
      case CERF:
        fD3Q19VCECLBESimpleZouHe(rho, uwall[0], uwall[2], uwall[1], &force[0], &lbf[spos], &lbf[spos+1*qdim],
                                 &lbf[spos+3*qdim], &lbf[spos+2*qdim], &lbf[spos+6*qdim], &lbf[spos+7*qdim],
                                 &lbf[spos+4*qdim], &lbf[spos+5*qdim], &lbf[spos+8*qdim], &lbf[spos+18*qdim],
                                 &lbf[spos+10*qdim], &lbf[spos+12*qdim], &lbf[spos+11*qdim], &lbf[spos+15*qdim],
                                 &lbf[spos+16*qdim], &lbf[spos+13*qdim], &lbf[spos+14*qdim], &lbf[spos+17*qdim],
                                 &lbf[spos+9*qdim]);
        break;
      case CETB:
        fD3Q19VCECLBESimpleZouHe(rho, uwall[1], -uwall[2], uwall[0], &force[0], &lbf[spos], &lbf[spos+2*qdim],
                                 &lbf[spos+12*qdim], &lbf[spos+1*qdim], &lbf[spos+9*qdim], &lbf[spos+8*qdim],
                                 &lbf[spos+4*qdim], &lbf[spos+14*qdim], &lbf[spos+7*qdim], &lbf[spos+15*qdim],
                                 &lbf[spos+11*qdim], &lbf[spos+3*qdim], &lbf[spos+10*qdim], &lbf[spos+18*qdim],
                                 &lbf[spos+17*qdim], &lbf[spos+13*qdim], &lbf[spos+5*qdim], &lbf[spos+16*qdim],
                                 &lbf[spos+6*qdim]);
        break;
      case CELB:
        fD3Q19VCECLBESimpleZouHe(rho, -uwall[0], -uwall[2], uwall[1], &force[0], &lbf[spos], &lbf[spos+10*qdim],
                                 &lbf[spos+12*qdim], &lbf[spos+2*qdim], &lbf[spos+15*qdim], &lbf[spos+16*qdim],
                                 &lbf[spos+14*qdim], &lbf[spos+13*qdim], &lbf[spos+9*qdim], &lbf[spos+17*qdim],
                                 &lbf[spos+1*qdim], &lbf[spos+3*qdim], &lbf[spos+11*qdim], &lbf[spos+6*qdim],
                                 &lbf[spos+7*qdim], &lbf[spos+5*qdim], &lbf[spos+4*qdim], &lbf[spos+18*qdim],
                                 &lbf[spos+8*qdim]);
        break;
      case CEDB:
        fD3Q19VCECLBESimpleZouHe(rho, -uwall[1], -uwall[2], uwall[0], &force[0], &lbf[spos], &lbf[spos+11*qdim],
                                 &lbf[spos+12*qdim], &lbf[spos+1*qdim], &lbf[spos+17*qdim], &lbf[spos+18*qdim],
                                 &lbf[spos+5*qdim], &lbf[spos+13*qdim], &lbf[spos+7*qdim], &lbf[spos+15*qdim],
                                 &lbf[spos+2*qdim], &lbf[spos+3*qdim], &lbf[spos+10*qdim], &lbf[spos+8*qdim],
                                 &lbf[spos+9*qdim], &lbf[spos+14*qdim], &lbf[spos+4*qdim], &lbf[spos+16*qdim],
                                 &lbf[spos+6*qdim]);
        break;
      case CERB:
        fD3Q19VCECLBESimpleZouHe(rho, uwall[0], -uwall[2], uwall[1], &force[0], &lbf[spos], &lbf[spos+1*qdim],
                                 &lbf[spos+12*qdim], &lbf[spos+2*qdim], &lbf[spos+7*qdim], &lbf[spos+6*qdim],
                                 &lbf[spos+4*qdim], &lbf[spos+5*qdim], &lbf[spos+9*qdim], &lbf[spos+17*qdim],
                                 &lbf[spos+10*qdim], &lbf[spos+3*qdim], &lbf[spos+11*qdim], &lbf[spos+16*qdim],
                                 &lbf[spos+15*qdim], &lbf[spos+13*qdim], &lbf[spos+14*qdim], &lbf[spos+18*qdim],
                                 &lbf[spos+8*qdim]);
        break;
    }
  }
  else {
    switch (prop) {
      case PST:
        fD3Q19VPSSimpleZouHe(uwall[0], uwall[1], uwall[2], &force[0], &lbf[spos], &lbf[spos+1*qdim],
                             &lbf[spos+2*qdim], &lbf[spos+3*qdim], &lbf[spos+4*qdim], &lbf[spos+5*qdim],
                             &lbf[spos+6*qdim], &lbf[spos+7*qdim], &lbf[spos+8*qdim], &lbf[spos+9*qdim],
                             &lbf[spos+10*qdim], &lbf[spos+11*qdim], &lbf[spos+12*qdim], &lbf[spos+13*qdim],
                             &lbf[spos+14*qdim], &lbf[spos+15*qdim], &lbf[spos+16*qdim], &lbf[spos+17*qdim],
                             &lbf[spos+18*qdim]);
        break;
      case PSD:
        fD3Q19VPSSimpleZouHe(-uwall[0], -uwall[1], -uwall[2], &force[0], &lbf[spos], &lbf[spos+10*qdim],
                             &lbf[spos+11*qdim], &lbf[spos+12*qdim], &lbf[spos+13*qdim], &lbf[spos+14*qdim],
                             &lbf[spos+15*qdim], &lbf[spos+16*qdim], &lbf[spos+17*qdim], &lbf[spos+18*qdim],
                             &lbf[spos+1*qdim], &lbf[spos+2*qdim], &lbf[spos+3*qdim], &lbf[spos+4*qdim],
                             &lbf[spos+5*qdim], &lbf[spos+6*qdim], &lbf[spos+7*qdim], &lbf[spos+8*qdim],
                             &lbf[spos+9*qdim]);
        break;
      case PSL:
        fD3Q19VPSSimpleZouHe(-uwall[2], -uwall[0], -uwall[1], &force[0], &lbf[spos], &lbf[spos+12*qdim],
                             &lbf[spos+10*qdim], &lbf[spos+11*qdim], &lbf[spos+15*qdim], &lbf[spos+7*qdim],
                             &lbf[spos+17*qdim], &lbf[spos+9*qdim], &lbf[spos+13*qdim], &lbf[spos+14*qdim],
                             &lbf[spos+3*qdim], &lbf[spos+1*qdim], &lbf[spos+2*qdim], &lbf[spos+6*qdim],
                             &lbf[spos+16*qdim], &lbf[spos+8*qdim], &lbf[spos+18*qdim], &lbf[spos+4*qdim],
                             &lbf[spos+5*qdim]);
        break;
      case PSR:
        fD3Q19VPSSimpleZouHe(uwall[2], uwall[0], uwall[1], &force[0], &lbf[spos], &lbf[spos+3*qdim],
                             &lbf[spos+1*qdim], &lbf[spos+2*qdim], &lbf[spos+6*qdim], &lbf[spos+16*qdim],
                             &lbf[spos+8*qdim], &lbf[spos+18*qdim], &lbf[spos+4*qdim], &lbf[spos+5*qdim],
                             &lbf[spos+12*qdim], &lbf[spos+10*qdim], &lbf[spos+11*qdim], &lbf[spos+15*qdim],
                             &lbf[spos+7*qdim], &lbf[spos+17*qdim], &lbf[spos+9*qdim], &lbf[spos+13*qdim],
                             &lbf[spos+14*qdim]);
        break;
      case PSF:
        fD3Q19VPSSimpleZouHe(-uwall[1], -uwall[2], -uwall[0], &force[0], &lbf[spos], &lbf[spos+11*qdim],
                             &lbf[spos+12*qdim], &lbf[spos+10*qdim], &lbf[spos+17*qdim], &lbf[spos+18*qdim],
                             &lbf[spos+13*qdim], &lbf[spos+5*qdim], &lbf[spos+15*qdim], &lbf[spos+7*qdim],
                             &lbf[spos+2*qdim], &lbf[spos+3*qdim], &lbf[spos+1*qdim], &lbf[spos+8*qdim],
                             &lbf[spos+9*qdim], &lbf[spos+4*qdim], &lbf[spos+14*qdim], &lbf[spos+6*qdim],
                             &lbf[spos+16*qdim]);
        break;
      case PSB:
        fD3Q19VPSSimpleZouHe(uwall[1], uwall[2], uwall[0], &force[0], &lbf[spos], &lbf[spos+2*qdim],
                             &lbf[spos+3*qdim], &lbf[spos+1*qdim], &lbf[spos+8*qdim], &lbf[spos+9*qdim],
                             &lbf[spos+4*qdim], &lbf[spos+14*qdim], &lbf[spos+6*qdim], &lbf[spos+16*qdim],
                             &lbf[spos+11*qdim], &lbf[spos+12*qdim], &lbf[spos+10*qdim], &lbf[spos+17*qdim],
                             &lbf[spos+18*qdim], &lbf[spos+13*qdim], &lbf[spos+5*qdim], &lbf[spos+15*qdim],
                             &lbf[spos+7*qdim]);
        break;
      case CCTRB:
        fD3Q19VCCSimpleZouHe(rho, uwall[0], uwall[1], -uwall[2], &force[0], &lbf[spos], &lbf[spos+1*qdim],
                             &lbf[spos+2*qdim], &lbf[spos+12*qdim], &lbf[spos+4*qdim], &lbf[spos+5*qdim],
                             &lbf[spos+7*qdim], &lbf[spos+6*qdim], &lbf[spos+9*qdim], &lbf[spos+8*qdim],
                             &lbf[spos+10*qdim], &lbf[spos+11*qdim], &lbf[spos+3*qdim], &lbf[spos+13*qdim],
                             &lbf[spos+14*qdim], &lbf[spos+16*qdim], &lbf[spos+15*qdim], &lbf[spos+18*qdim],
                             &lbf[spos+17*qdim]);
        break;
      case CCTLB:
        fD3Q19VCCSimpleZouHe(rho, -uwall[0], uwall[1], -uwall[2], &force[0], &lbf[spos], &lbf[spos+10*qdim],
                             &lbf[spos+2*qdim], &lbf[spos+12*qdim], &lbf[spos+14*qdim], &lbf[spos+13*qdim],
                             &lbf[spos+15*qdim], &lbf[spos+16*qdim], &lbf[spos+9*qdim], &lbf[spos+8*qdim],
                             &lbf[spos+1*qdim], &lbf[spos+11*qdim], &lbf[spos+3*qdim], &lbf[spos+5*qdim],
                             &lbf[spos+4*qdim], &lbf[spos+6*qdim], &lbf[spos+7*qdim], &lbf[spos+18*qdim],
                             &lbf[spos+17*qdim]);
        break;
      case CCDLB:
        fD3Q19VCCSimpleZouHe(rho, -uwall[0], -uwall[1], -uwall[2], &force[0], &lbf[spos], &lbf[spos+10*qdim],
                             &lbf[spos+11*qdim], &lbf[spos+12*qdim], &lbf[spos+13*qdim], &lbf[spos+14*qdim],
                             &lbf[spos+15*qdim], &lbf[spos+16*qdim], &lbf[spos+17*qdim], &lbf[spos+18*qdim],
                             &lbf[spos+1*qdim], &lbf[spos+2*qdim], &lbf[spos+3*qdim], &lbf[spos+4*qdim],
                             &lbf[spos+5*qdim], &lbf[spos+6*qdim], &lbf[spos+7*qdim], &lbf[spos+8*qdim],
                             &lbf[spos+9*qdim]);
        break;
      case CCDRB:
        fD3Q19VCCSimpleZouHe(rho, uwall[0], -uwall[1], -uwall[2], &force[0], &lbf[spos], &lbf[spos+1*qdim],
                             &lbf[spos+11*qdim], &lbf[spos+12*qdim], &lbf[spos+5*qdim], &lbf[spos+4*qdim],
                             &lbf[spos+7*qdim], &lbf[spos+6*qdim], &lbf[spos+17*qdim], &lbf[spos+18*qdim],
                             &lbf[spos+10*qdim], &lbf[spos+2*qdim], &lbf[spos+3*qdim], &lbf[spos+14*qdim],
                             &lbf[spos+13*qdim], &lbf[spos+16*qdim], &lbf[spos+15*qdim], &lbf[spos+8*qdim],
                             &lbf[spos+9*qdim]);
        break;
      case CCTRF:
        fD3Q19VCCSimpleZouHe(rho, uwall[0], uwall[1], uwall[2], &force[0], &lbf[spos], &lbf[spos+1*qdim],
                       &lbf[spos+2*qdim], &lbf[spos+3*qdim], &lbf[spos+4*qdim], &lbf[spos+5*qdim],
                       &lbf[spos+6*qdim], &lbf[spos+7*qdim], &lbf[spos+8*qdim], &lbf[spos+9*qdim],
                       &lbf[spos+10*qdim], &lbf[spos+11*qdim], &lbf[spos+12*qdim], &lbf[spos+13*qdim],
                       &lbf[spos+14*qdim], &lbf[spos+15*qdim], &lbf[spos+16*qdim], &lbf[spos+17*qdim],
                       &lbf[spos+18*qdim]);
        break;
      case CCTLF:
        fD3Q19VCCSimpleZouHe(rho, -uwall[0], uwall[1], uwall[2], &force[0], &lbf[spos], &lbf[spos+10*qdim],
                             &lbf[spos+2*qdim], &lbf[spos+3*qdim], &lbf[spos+14*qdim], &lbf[spos+13*qdim],
                             &lbf[spos+16*qdim], &lbf[spos+15*qdim], &lbf[spos+8*qdim], &lbf[spos+9*qdim],
                             &lbf[spos+1*qdim], &lbf[spos+11*qdim], &lbf[spos+12*qdim], &lbf[spos+5*qdim],
                             &lbf[spos+4*qdim], &lbf[spos+7*qdim], &lbf[spos+6*qdim], &lbf[spos+17*qdim],
                             &lbf[spos+18*qdim]);
        break;
      case CCDLF:
        fD3Q19VCCSimpleZouHe(rho, -uwall[0], -uwall[1], uwall[2], &force[0], &lbf[spos], &lbf[spos+10*qdim],
                             &lbf[spos+11*qdim], &lbf[spos+3*qdim], &lbf[spos+13*qdim], &lbf[spos+14*qdim],
                             &lbf[spos+16*qdim], &lbf[spos+15*qdim], &lbf[spos+18*qdim], &lbf[spos+17*qdim],
                             &lbf[spos+1*qdim], &lbf[spos+2*qdim], &lbf[spos+12*qdim], &lbf[spos+4*qdim],
                             &lbf[spos+5*qdim], &lbf[spos+7*qdim], &lbf[spos+6*qdim], &lbf[spos+9*qdim],
                             &lbf[spos+8*qdim]);
        break;
      case CCDRF:
        fD3Q19VCCSimpleZouHe(rho, uwall[0], -uwall[1], uwall[2], &force[0], &lbf[spos], &lbf[spos+1*qdim],
                             &lbf[spos+11*qdim], &lbf[spos+3*qdim], &lbf[spos+5*qdim], &lbf[spos+4*qdim],
                             &lbf[spos+6*qdim], &lbf[spos+7*qdim], &lbf[spos+18*qdim], &lbf[spos+17*qdim],
                             &lbf[spos+10*qdim], &lbf[spos+2*qdim], &lbf[spos+12*qdim], &lbf[spos+14*qdim],
                             &lbf[spos+13*qdim], &lbf[spos+15*qdim], &lbf[spos+16*qdim], &lbf[spos+9*qdim],
                             &lbf[spos+8*qdim]);
        break;
      case CETR:
        fD3Q19VCESimpleZouHe(rho, uwall[0], uwall[1], uwall[2], &force[0], &lbf[spos], &lbf[spos+1*qdim],
                             &lbf[spos+2*qdim], &lbf[spos+3*qdim], &lbf[spos+4*qdim], &lbf[spos+5*qdim],
                             &lbf[spos+6*qdim], &lbf[spos+7*qdim], &lbf[spos+8*qdim], &lbf[spos+9*qdim],
                             &lbf[spos+10*qdim], &lbf[spos+11*qdim], &lbf[spos+12*qdim], &lbf[spos+13*qdim],
                             &lbf[spos+14*qdim], &lbf[spos+15*qdim], &lbf[spos+16*qdim], &lbf[spos+17*qdim],
                             &lbf[spos+18*qdim]);
        break;
      case CETL:
        fD3Q19VCESimpleZouHe(rho, uwall[1], -uwall[0], uwall[2], &force[0], &lbf[spos], &lbf[spos+2*qdim],
                             &lbf[spos+10*qdim], &lbf[spos+3*qdim], &lbf[spos+14*qdim], &lbf[spos+4*qdim],
                             &lbf[spos+8*qdim], &lbf[spos+9*qdim], &lbf[spos+16*qdim], &lbf[spos+15*qdim],
                             &lbf[spos+11*qdim], &lbf[spos+1*qdim], &lbf[spos+12*qdim], &lbf[spos+5*qdim],
                             &lbf[spos+13*qdim], &lbf[spos+17*qdim], &lbf[spos+18*qdim], &lbf[spos+7*qdim],
                             &lbf[spos+6*qdim]);
        break;
      case CEDL:
        fD3Q19VCESimpleZouHe(rho, -uwall[0], -uwall[1], uwall[2], &force[0], &lbf[spos], &lbf[spos+10*qdim],
                             &lbf[spos+11*qdim], &lbf[spos+3*qdim], &lbf[spos+13*qdim], &lbf[spos+14*qdim],
                             &lbf[spos+16*qdim], &lbf[spos+15*qdim], &lbf[spos+18*qdim], &lbf[spos+17*qdim],
                             &lbf[spos+1*qdim], &lbf[spos+2*qdim], &lbf[spos+12*qdim], &lbf[spos+4*qdim],
                             &lbf[spos+5*qdim], &lbf[spos+7*qdim], &lbf[spos+6*qdim], &lbf[spos+9*qdim],
                             &lbf[spos+8*qdim]);
        break;
      case CEDR:
        fD3Q19VCESimpleZouHe(rho, -uwall[1], uwall[0], uwall[2], &force[0], &lbf[spos], &lbf[spos+11*qdim],
                             &lbf[spos+1*qdim], &lbf[spos+3*qdim], &lbf[spos+5*qdim], &lbf[spos+13*qdim],
                             &lbf[spos+18*qdim], &lbf[spos+17*qdim], &lbf[spos+6*qdim], &lbf[spos+7*qdim],
                             &lbf[spos+2*qdim], &lbf[spos+10*qdim], &lbf[spos+12*qdim], &lbf[spos+14*qdim],
                             &lbf[spos+4*qdim], &lbf[spos+9*qdim], &lbf[spos+8*qdim], &lbf[spos+15*qdim],
                             &lbf[spos+16*qdim]);
        break;
      case CETF:
        fD3Q19VCESimpleZouHe(rho, uwall[1], uwall[2], uwall[0], &force[0], &lbf[spos], &lbf[spos+2*qdim],
                             &lbf[spos+3*qdim], &lbf[spos+1*qdim], &lbf[spos+8*qdim], &lbf[spos+9*qdim],
                             &lbf[spos+4*qdim], &lbf[spos+14*qdim], &lbf[spos+6*qdim], &lbf[spos+16*qdim],
                             &lbf[spos+11*qdim], &lbf[spos+12*qdim], &lbf[spos+10*qdim], &lbf[spos+17*qdim],
                             &lbf[spos+18*qdim], &lbf[spos+13*qdim], &lbf[spos+5*qdim], &lbf[spos+15*qdim],
                             &lbf[spos+7*qdim]);
        break;
      case CELF:
        fD3Q19VCESimpleZouHe(rho, -uwall[0], uwall[2], uwall[1], &force[0], &lbf[spos], &lbf[spos+10*qdim],
                             &lbf[spos+3*qdim], &lbf[spos+2*qdim], &lbf[spos+16*qdim], &lbf[spos+15*qdim],
                             &lbf[spos+14*qdim], &lbf[spos+13*qdim], &lbf[spos+8*qdim], &lbf[spos+18*qdim],
                             &lbf[spos+1*qdim], &lbf[spos+12*qdim], &lbf[spos+11*qdim], &lbf[spos+7*qdim],
                             &lbf[spos+6*qdim], &lbf[spos+5*qdim], &lbf[spos+4*qdim], &lbf[spos+17*qdim],
                             &lbf[spos+9*qdim]);
        break;
      case CEDF:
        fD3Q19VCESimpleZouHe(rho, -uwall[1], uwall[2], uwall[0], &force[0], &lbf[spos], &lbf[spos+11*qdim],
                             &lbf[spos+3*qdim], &lbf[spos+1*qdim], &lbf[spos+18*qdim], &lbf[spos+17*qdim],
                             &lbf[spos+5*qdim], &lbf[spos+13*qdim], &lbf[spos+6*qdim], &lbf[spos+16*qdim],
                             &lbf[spos+2*qdim], &lbf[spos+12*qdim], &lbf[spos+10*qdim], &lbf[spos+9*qdim],
                             &lbf[spos+8*qdim], &lbf[spos+14*qdim], &lbf[spos+4*qdim], &lbf[spos+15*qdim],
                             &lbf[spos+7*qdim]);
        break;
      case CERF:
        fD3Q19VCESimpleZouHe(rho, uwall[0], uwall[2], uwall[1], &force[0], &lbf[spos], &lbf[spos+1*qdim],
                             &lbf[spos+3*qdim], &lbf[spos+2*qdim], &lbf[spos+6*qdim], &lbf[spos+7*qdim],
                             &lbf[spos+4*qdim], &lbf[spos+5*qdim], &lbf[spos+8*qdim], &lbf[spos+18*qdim],
                             &lbf[spos+10*qdim], &lbf[spos+12*qdim], &lbf[spos+11*qdim], &lbf[spos+15*qdim],
                             &lbf[spos+16*qdim], &lbf[spos+13*qdim], &lbf[spos+14*qdim], &lbf[spos+17*qdim],
                             &lbf[spos+9*qdim]);
        break;
      case CETB:
        fD3Q19VCESimpleZouHe(rho, uwall[1], -uwall[2], uwall[0], &force[0], &lbf[spos], &lbf[spos+2*qdim],
                             &lbf[spos+12*qdim], &lbf[spos+1*qdim], &lbf[spos+9*qdim], &lbf[spos+8*qdim],
                             &lbf[spos+4*qdim], &lbf[spos+14*qdim], &lbf[spos+7*qdim], &lbf[spos+15*qdim],
                             &lbf[spos+11*qdim], &lbf[spos+3*qdim], &lbf[spos+10*qdim], &lbf[spos+18*qdim],
                             &lbf[spos+17*qdim], &lbf[spos+13*qdim], &lbf[spos+5*qdim], &lbf[spos+16*qdim],
                             &lbf[spos+6*qdim]);
        break;
      case CELB:
        fD3Q19VCESimpleZouHe(rho, -uwall[0], -uwall[2], uwall[1], &force[0], &lbf[spos], &lbf[spos+10*qdim],
                             &lbf[spos+12*qdim], &lbf[spos+2*qdim], &lbf[spos+15*qdim], &lbf[spos+16*qdim],
                             &lbf[spos+14*qdim], &lbf[spos+13*qdim], &lbf[spos+9*qdim], &lbf[spos+17*qdim],
                             &lbf[spos+1*qdim], &lbf[spos+3*qdim], &lbf[spos+11*qdim], &lbf[spos+6*qdim],
                             &lbf[spos+7*qdim], &lbf[spos+5*qdim], &lbf[spos+4*qdim], &lbf[spos+18*qdim],
                             &lbf[spos+8*qdim]);
        break;
      case CEDB:
        fD3Q19VCESimpleZouHe(rho, -uwall[1], -uwall[2], uwall[0], &force[0], &lbf[spos], &lbf[spos+11*qdim],
                             &lbf[spos+12*qdim], &lbf[spos+1*qdim], &lbf[spos+17*qdim], &lbf[spos+18*qdim],
                             &lbf[spos+5*qdim], &lbf[spos+13*qdim], &lbf[spos+7*qdim], &lbf[spos+15*qdim],
                             &lbf[spos+2*qdim], &lbf[spos+3*qdim], &lbf[spos+10*qdim], &lbf[spos+8*qdim],
                             &lbf[spos+9*qdim], &lbf[spos+14*qdim], &lbf[spos+4*qdim], &lbf[spos+16*qdim],
                             &lbf[spos+6*qdim]);
        break;
      case CERB:
        fD3Q19VCESimpleZouHe(rho, uwall[0], -uwall[2], uwall[1], &force[0], &lbf[spos], &lbf[spos+1*qdim],
                             &lbf[spos+12*qdim], &lbf[spos+2*qdim], &lbf[spos+7*qdim], &lbf[spos+6*qdim],
                             &lbf[spos+4*qdim], &lbf[spos+5*qdim], &lbf[spos+9*qdim], &lbf[spos+17*qdim],
                             &lbf[spos+10*qdim], &lbf[spos+3*qdim], &lbf[spos+11*qdim], &lbf[spos+16*qdim],
                             &lbf[spos+15*qdim], &lbf[spos+13*qdim], &lbf[spos+14*qdim], &lbf[spos+18*qdim],
                             &lbf[spos+8*qdim]);
        break;
    }
  }
  
  return 0;
  
}


int fD3Q19PPSZouHe(double *p, double *force, double *f0, double *f1,
	               double *f2, double *f3, double *f4, double *f5,
	               double *f6, double *f7, double *f8, double *f9,
	               double *f10, double *f11, double *f12, double *f13,
	               double *f14, double *f15, double *f16, double *f17,
	               double *f18, double &vel)
{

  // produce fixed pressure/density at planar surface: expressed for bottom wall

  double rx, rz, v;
  double c1=1.0/3.0,c2=1.0/6.0;
  double mass=0.0;
  vel=0.0;
  if(!incompress) {
    for(int i=0; i<lbsy.nf; i++) {
      v=p[i]-(f0[i]+f1[i]+f3[i]+f6[i]+f7[i]+f10[i]+f12[i]+f15[i]+f16[i]+2.0*(f2[i]+f4[i]+f8[i]+f9[i]+f14[i]))+0.5*force[3*i+1];
      vel += v;
      mass += p[i];
      rx=0.5*(f10[i]-f1[i]-f6[i]-f7[i]+f15[i]+f16[i])+0.25*force[3*i  ];
      rz=0.5*(f12[i]-f3[i]-f6[i]+f7[i]+f15[i]-f16[i])+0.25*force[3*i+2];
      f5[i]=f14[i]+c2*v+rx;
      f11[i]=f2[i]+c1*v;
      f13[i]=f4[i]+c2*v-rx;
      f17[i]=f8[i]+c2*v-rz;
      f18[i]=f9[i]+c2*v+rz;
    }
  }
  else {
    for(int i=0; i<lbsy.nf; i++) {
      v=p[i]-(f0[i]+f1[i]+f3[i]+f6[i]+f7[i]+f10[i]+f12[i]+f15[i]+f16[i]+2.0*(f2[i]+f4[i]+f8[i]+f9[i]+f14[i]))+0.5*force[3*i+1];
      vel += v;
      mass += lbincp[i];
      rx=0.5*(f10[i]-f1[i]-f6[i]-f7[i]+f15[i]+f16[i])+0.25*force[3*i  ];
      rz=0.5*(f12[i]-f3[i]-f6[i]+f7[i]+f15[i]-f16[i])+0.25*force[3*i+2];
      f5[i]=f14[i]+c2*v+rx;
      f11[i]=f2[i]+c1*v;
      f13[i]=f4[i]+c2*v-rx;
      f17[i]=f8[i]+c2*v-rz;
      f18[i]=f9[i]+c2*v+rz;
    }
  }
  vel *= fReciprocal(mass);
  return 0;
}


int fD3Q19PPSSwiftZouHe(double *p, double *force, double *f0, double *f1,
	                    double *f2, double *f3, double *f4, double *f5,
	                    double *f6, double *f7, double *f8, double *f9,
	                    double *f10, double *f11, double *f12, double *f13,
	                    double *f14, double *f15, double *f16, double *f17,
	                    double *f18, double &vel)
{

  // produce fixed pressure/density at planar surface: expressed for bottom wall
  // with Swift free-energy interactions

  double rx, rz, v;
  double c1=1.0/3.0,c2=1.0/6.0,c3=2.0/3.0;
  double mass=0.0;
  vel=0.0;

  v=p[0]-(f0[0]+f1[0]+f3[0]+f6[0]+f7[0]+f10[0]+f12[0]+f15[0]+f16[0]+2.0*(f2[0]+f4[0]+f8[0]+f9[0]+f14[0]))+0.5*force[1];
  vel += v;
  mass += p[0];
  rx=0.5*(f10[0]-f1[0]-f6[0]-f7[0]+f15[0]+f16[0])+0.25*force[0];
  rz=0.5*(f12[0]-f3[0]-f6[0]+f7[0]+f15[0]-f16[0])+0.25*force[2];
  f5[0]=f14[0]+c2*v+rx;
  f11[0]=f2[0]+c1*v;
  f13[0]=f4[0]+c2*v-rx;
  f17[0]=f8[0]+c2*v-rz;
  f18[0]=f9[0]+c2*v+rz;
  vel *= fReciprocal(mass);
  if(lbsy.nf>1) {
    f5[1]=f14[1]+c2*p[1]*vel;
    f11[1]=p[1]*(1.0-c3*vel)-f0[1]-f1[1]-f2[1]-f3[1]-f6[1]-f7[1]-f10[1]-f12[1]-f15[1]-f16[1]-2.0*(f4[1]+f8[1]+f9[1]+f14[1]);
    f13[1]=f4[1]+c2*p[1]*vel;
    f17[1]=f8[1]+c2*p[1]*vel;
    f18[1]=f9[1]+c2*p[1]*vel;
  }

  return 0;
}


int fD3Q19PFZouHe(long tpos, int prop, double *p0, double *uwall)
{
  double moment;
  long spos=tpos * lbsitelength;
  int qdim = lbsy.nf+lbsy.nc+lbsy.nt;
  double force[3*lbsy.nf];

  // sort out forces

  fD3Q19BoundaryForceDensity(force, tpos, p0, prop);
    
  // apply boundary condition
    
  if(interact==20) {
    switch (prop) {
      case PST:
        fD3Q19PPSSwiftZouHe(p0, &force[0], &lbf[spos], &lbf[spos+1*qdim],
                            &lbf[spos+2*qdim], &lbf[spos+3*qdim], &lbf[spos+4*qdim], &lbf[spos+5*qdim],
                            &lbf[spos+6*qdim], &lbf[spos+7*qdim], &lbf[spos+8*qdim], &lbf[spos+9*qdim],
                            &lbf[spos+10*qdim], &lbf[spos+11*qdim], &lbf[spos+12*qdim], &lbf[spos+13*qdim],
                            &lbf[spos+14*qdim], &lbf[spos+15*qdim], &lbf[spos+16*qdim], &lbf[spos+17*qdim],
                            &lbf[spos+18*qdim], moment);
        uwall[1] += moment;
        break;
      case PSD:
        fD3Q19PPSSwiftZouHe(p0, &force[0], &lbf[spos], &lbf[spos+10*qdim],
                            &lbf[spos+11*qdim], &lbf[spos+12*qdim], &lbf[spos+13*qdim], &lbf[spos+14*qdim],
                            &lbf[spos+15*qdim], &lbf[spos+16*qdim], &lbf[spos+17*qdim], &lbf[spos+18*qdim],
                            &lbf[spos+1*qdim], &lbf[spos+2*qdim], &lbf[spos+3*qdim], &lbf[spos+4*qdim],
                            &lbf[spos+5*qdim], &lbf[spos+6*qdim], &lbf[spos+7*qdim], &lbf[spos+8*qdim],
                            &lbf[spos+9*qdim], moment);
        uwall[1] -= moment;
        break;
      case PSL:
        fD3Q19PPSSwiftZouHe(p0, &force[0], &lbf[spos], &lbf[spos+12*qdim],
                            &lbf[spos+10*qdim], &lbf[spos+11*qdim], &lbf[spos+15*qdim], &lbf[spos+7*qdim],
                            &lbf[spos+17*qdim], &lbf[spos+9*qdim], &lbf[spos+13*qdim], &lbf[spos+14*qdim],
                            &lbf[spos+3*qdim], &lbf[spos+1*qdim], &lbf[spos+2*qdim], &lbf[spos+6*qdim],
                            &lbf[spos+16*qdim], &lbf[spos+8*qdim], &lbf[spos+18*qdim], &lbf[spos+4*qdim],
                            &lbf[spos+5*qdim], moment);
        uwall[0] -= moment;
        break;
      case PSR:
        fD3Q19PPSSwiftZouHe(p0, &force[0], &lbf[spos], &lbf[spos+3*qdim],
                            &lbf[spos+1*qdim], &lbf[spos+2*qdim], &lbf[spos+6*qdim], &lbf[spos+16*qdim],
                            &lbf[spos+8*qdim], &lbf[spos+18*qdim], &lbf[spos+4*qdim], &lbf[spos+5*qdim],
                            &lbf[spos+12*qdim], &lbf[spos+10*qdim], &lbf[spos+11*qdim], &lbf[spos+15*qdim],
                            &lbf[spos+7*qdim], &lbf[spos+17*qdim], &lbf[spos+9*qdim], &lbf[spos+13*qdim],
                            &lbf[spos+14*qdim], moment);
        uwall[0] += moment;
        break;
      case PSF:
        fD3Q19PPSSwiftZouHe(p0, &force[0], &lbf[spos], &lbf[spos+11*qdim],
                            &lbf[spos+12*qdim], &lbf[spos+10*qdim], &lbf[spos+17*qdim], &lbf[spos+18*qdim],
                            &lbf[spos+13*qdim], &lbf[spos+5*qdim], &lbf[spos+15*qdim], &lbf[spos+7*qdim],
                            &lbf[spos+2*qdim], &lbf[spos+3*qdim], &lbf[spos+1*qdim], &lbf[spos+8*qdim],
                            &lbf[spos+9*qdim], &lbf[spos+4*qdim], &lbf[spos+14*qdim], &lbf[spos+6*qdim],
                            &lbf[spos+16*qdim], moment);
        uwall[2] -= moment;
        break;
      case PSB:
        fD3Q19PPSSwiftZouHe(p0, &force[0], &lbf[spos], &lbf[spos+2*qdim],
                            &lbf[spos+3*qdim], &lbf[spos+1*qdim], &lbf[spos+8*qdim], &lbf[spos+9*qdim],
                            &lbf[spos+4*qdim], &lbf[spos+14*qdim], &lbf[spos+6*qdim], &lbf[spos+16*qdim],
                            &lbf[spos+11*qdim], &lbf[spos+12*qdim], &lbf[spos+10*qdim], &lbf[spos+17*qdim],
                            &lbf[spos+18*qdim], &lbf[spos+13*qdim], &lbf[spos+5*qdim], &lbf[spos+15*qdim],
                            &lbf[spos+7*qdim], moment);
        uwall[2] += moment;
        break;
      case CCTRB:
        fD3Q19VCCZouHe(p0, uwall[0], uwall[1], -uwall[2], &force[0], &lbf[spos], &lbf[spos+1*qdim],
                       &lbf[spos+2*qdim], &lbf[spos+12*qdim], &lbf[spos+4*qdim], &lbf[spos+5*qdim],
                       &lbf[spos+7*qdim], &lbf[spos+6*qdim], &lbf[spos+9*qdim], &lbf[spos+8*qdim],
                       &lbf[spos+10*qdim], &lbf[spos+11*qdim], &lbf[spos+3*qdim], &lbf[spos+13*qdim],
                       &lbf[spos+14*qdim], &lbf[spos+16*qdim], &lbf[spos+15*qdim], &lbf[spos+18*qdim],
                       &lbf[spos+17*qdim]);
        break;
      case CCTLB:
        fD3Q19VCCZouHe(p0, -uwall[0], uwall[1], -uwall[2], &force[0], &lbf[spos], &lbf[spos+10*qdim],
                       &lbf[spos+2*qdim], &lbf[spos+12*qdim], &lbf[spos+14*qdim], &lbf[spos+13*qdim],
                       &lbf[spos+15*qdim], &lbf[spos+16*qdim], &lbf[spos+9*qdim], &lbf[spos+8*qdim],
                       &lbf[spos+1*qdim], &lbf[spos+11*qdim], &lbf[spos+3*qdim], &lbf[spos+5*qdim],
                       &lbf[spos+4*qdim], &lbf[spos+6*qdim], &lbf[spos+7*qdim], &lbf[spos+18*qdim],
                       &lbf[spos+17*qdim]);
        break;
      case CCDLB:
        fD3Q19VCCZouHe(p0, -uwall[0], -uwall[1], -uwall[2], &force[0], &lbf[spos], &lbf[spos+10*qdim],
                       &lbf[spos+11*qdim], &lbf[spos+12*qdim], &lbf[spos+13*qdim], &lbf[spos+14*qdim],
                       &lbf[spos+15*qdim], &lbf[spos+16*qdim], &lbf[spos+17*qdim], &lbf[spos+18*qdim],
                       &lbf[spos+1*qdim], &lbf[spos+2*qdim], &lbf[spos+3*qdim], &lbf[spos+4*qdim],
                       &lbf[spos+5*qdim], &lbf[spos+6*qdim], &lbf[spos+7*qdim], &lbf[spos+8*qdim],
                       &lbf[spos+9*qdim]);
        break;
      case CCDRB:
        fD3Q19VCCZouHe(p0, uwall[0], -uwall[1], -uwall[2], &force[0], &lbf[spos], &lbf[spos+1*qdim],
                       &lbf[spos+11*qdim], &lbf[spos+12*qdim], &lbf[spos+5*qdim], &lbf[spos+4*qdim],
                       &lbf[spos+7*qdim], &lbf[spos+6*qdim], &lbf[spos+17*qdim], &lbf[spos+18*qdim],
                       &lbf[spos+10*qdim], &lbf[spos+2*qdim], &lbf[spos+3*qdim], &lbf[spos+14*qdim],
                       &lbf[spos+13*qdim], &lbf[spos+16*qdim], &lbf[spos+15*qdim], &lbf[spos+8*qdim],
                       &lbf[spos+9*qdim]);
        break;
      case CCTRF:
        fD3Q19VCCZouHe(p0, uwall[0], uwall[1], uwall[2], &force[0], &lbf[spos], &lbf[spos+1*qdim],
                       &lbf[spos+2*qdim], &lbf[spos+3*qdim], &lbf[spos+4*qdim], &lbf[spos+5*qdim],
                       &lbf[spos+6*qdim], &lbf[spos+7*qdim], &lbf[spos+8*qdim], &lbf[spos+9*qdim],
                       &lbf[spos+10*qdim], &lbf[spos+11*qdim], &lbf[spos+12*qdim], &lbf[spos+13*qdim],
                       &lbf[spos+14*qdim], &lbf[spos+15*qdim], &lbf[spos+16*qdim], &lbf[spos+17*qdim],
                       &lbf[spos+18*qdim]);
        break;
      case CCTLF:
        fD3Q19VCCZouHe(p0, -uwall[0], uwall[1], uwall[2], &force[0], &lbf[spos], &lbf[spos+10*qdim],
                       &lbf[spos+2*qdim], &lbf[spos+3*qdim], &lbf[spos+14*qdim], &lbf[spos+13*qdim],
                       &lbf[spos+16*qdim], &lbf[spos+15*qdim], &lbf[spos+8*qdim], &lbf[spos+9*qdim],
                       &lbf[spos+1*qdim], &lbf[spos+11*qdim], &lbf[spos+12*qdim], &lbf[spos+5*qdim],
                       &lbf[spos+4*qdim], &lbf[spos+7*qdim], &lbf[spos+6*qdim], &lbf[spos+17*qdim],
                       &lbf[spos+18*qdim]);
        break;
      case CCDLF:
        fD3Q19VCCZouHe(p0, -uwall[0], -uwall[1], uwall[2], &force[0], &lbf[spos], &lbf[spos+10*qdim],
                       &lbf[spos+11*qdim], &lbf[spos+3*qdim], &lbf[spos+13*qdim], &lbf[spos+14*qdim],
                       &lbf[spos+16*qdim], &lbf[spos+15*qdim], &lbf[spos+18*qdim], &lbf[spos+17*qdim],
                       &lbf[spos+1*qdim], &lbf[spos+2*qdim], &lbf[spos+12*qdim], &lbf[spos+4*qdim],
                       &lbf[spos+5*qdim], &lbf[spos+7*qdim], &lbf[spos+6*qdim], &lbf[spos+9*qdim],
                       &lbf[spos+8*qdim]);
        break;
      case CCDRF:
        fD3Q19VCCZouHe(p0, uwall[0], -uwall[1], uwall[2], &force[0], &lbf[spos], &lbf[spos+1*qdim],
                       &lbf[spos+11*qdim], &lbf[spos+3*qdim], &lbf[spos+5*qdim], &lbf[spos+4*qdim],
                       &lbf[spos+6*qdim], &lbf[spos+7*qdim], &lbf[spos+18*qdim], &lbf[spos+17*qdim],
                       &lbf[spos+10*qdim], &lbf[spos+2*qdim], &lbf[spos+12*qdim], &lbf[spos+14*qdim],
                       &lbf[spos+13*qdim], &lbf[spos+15*qdim], &lbf[spos+16*qdim], &lbf[spos+9*qdim],
                       &lbf[spos+8*qdim]);
        break;
      case CETR:
        fD3Q19VCEZouHe(p0, uwall[0], uwall[1], uwall[2], &force[0], &lbf[spos], &lbf[spos+1*qdim],
                       &lbf[spos+2*qdim], &lbf[spos+3*qdim], &lbf[spos+4*qdim], &lbf[spos+5*qdim],
                       &lbf[spos+6*qdim], &lbf[spos+7*qdim], &lbf[spos+8*qdim], &lbf[spos+9*qdim],
                       &lbf[spos+10*qdim], &lbf[spos+11*qdim], &lbf[spos+12*qdim], &lbf[spos+13*qdim],
                       &lbf[spos+14*qdim], &lbf[spos+15*qdim], &lbf[spos+16*qdim], &lbf[spos+17*qdim],
                       &lbf[spos+18*qdim]);
        break;
      case CETL:
        fD3Q19VCEZouHe(p0, uwall[1], -uwall[0], uwall[2], &force[0], &lbf[spos], &lbf[spos+2*qdim],
                       &lbf[spos+10*qdim], &lbf[spos+3*qdim], &lbf[spos+14*qdim], &lbf[spos+4*qdim],
                       &lbf[spos+8*qdim], &lbf[spos+9*qdim], &lbf[spos+16*qdim], &lbf[spos+15*qdim],
                       &lbf[spos+11*qdim], &lbf[spos+1*qdim], &lbf[spos+12*qdim], &lbf[spos+5*qdim],
                       &lbf[spos+13*qdim], &lbf[spos+17*qdim], &lbf[spos+18*qdim], &lbf[spos+7*qdim],
                       &lbf[spos+6*qdim]);
        break;
      case CEDL:
        fD3Q19VCEZouHe(p0, -uwall[0], -uwall[1], uwall[2], &force[0], &lbf[spos], &lbf[spos+10*qdim],
                       &lbf[spos+11*qdim], &lbf[spos+3*qdim], &lbf[spos+13*qdim], &lbf[spos+14*qdim],
                       &lbf[spos+16*qdim], &lbf[spos+15*qdim], &lbf[spos+18*qdim], &lbf[spos+17*qdim],
                       &lbf[spos+1*qdim], &lbf[spos+2*qdim], &lbf[spos+12*qdim], &lbf[spos+4*qdim],
                       &lbf[spos+5*qdim], &lbf[spos+7*qdim], &lbf[spos+6*qdim], &lbf[spos+9*qdim],
                       &lbf[spos+8*qdim]);
        break;
      case CEDR:
        fD3Q19VCEZouHe(p0, -uwall[1], uwall[0], uwall[2], &force[0], &lbf[spos], &lbf[spos+11*qdim],
                       &lbf[spos+1*qdim], &lbf[spos+3*qdim], &lbf[spos+5*qdim], &lbf[spos+13*qdim],
                       &lbf[spos+18*qdim], &lbf[spos+17*qdim], &lbf[spos+6*qdim], &lbf[spos+7*qdim],
                       &lbf[spos+2*qdim], &lbf[spos+10*qdim], &lbf[spos+12*qdim], &lbf[spos+14*qdim],
                       &lbf[spos+4*qdim], &lbf[spos+9*qdim], &lbf[spos+8*qdim], &lbf[spos+15*qdim],
                       &lbf[spos+16*qdim]);
        break;
      case CETF:
        fD3Q19VCEZouHe(p0, uwall[1], uwall[2], uwall[0], &force[0], &lbf[spos], &lbf[spos+2*qdim],
                       &lbf[spos+3*qdim], &lbf[spos+1*qdim], &lbf[spos+8*qdim], &lbf[spos+9*qdim],
                       &lbf[spos+4*qdim], &lbf[spos+14*qdim], &lbf[spos+6*qdim], &lbf[spos+16*qdim],
                       &lbf[spos+11*qdim], &lbf[spos+12*qdim], &lbf[spos+10*qdim], &lbf[spos+17*qdim],
                       &lbf[spos+18*qdim], &lbf[spos+13*qdim], &lbf[spos+5*qdim], &lbf[spos+15*qdim],
                       &lbf[spos+7*qdim]);
        break;
      case CELF:
        fD3Q19VCEZouHe(p0, -uwall[0], uwall[2], uwall[1], &force[0], &lbf[spos], &lbf[spos+10*qdim],
                       &lbf[spos+3*qdim], &lbf[spos+2*qdim], &lbf[spos+16*qdim], &lbf[spos+15*qdim],
                       &lbf[spos+14*qdim], &lbf[spos+13*qdim], &lbf[spos+8*qdim], &lbf[spos+18*qdim],
                       &lbf[spos+1*qdim], &lbf[spos+12*qdim], &lbf[spos+11*qdim], &lbf[spos+7*qdim],
                       &lbf[spos+6*qdim], &lbf[spos+5*qdim], &lbf[spos+4*qdim], &lbf[spos+17*qdim],
                       &lbf[spos+9*qdim]);
        break;
      case CEDF:
        fD3Q19VCEZouHe(p0, -uwall[1], uwall[2], uwall[0], &force[0], &lbf[spos], &lbf[spos+11*qdim],
                       &lbf[spos+3*qdim], &lbf[spos+1*qdim], &lbf[spos+18*qdim], &lbf[spos+17*qdim],
                       &lbf[spos+5*qdim], &lbf[spos+13*qdim], &lbf[spos+6*qdim], &lbf[spos+16*qdim],
                       &lbf[spos+2*qdim], &lbf[spos+12*qdim], &lbf[spos+10*qdim], &lbf[spos+9*qdim],
                       &lbf[spos+8*qdim], &lbf[spos+14*qdim], &lbf[spos+4*qdim], &lbf[spos+15*qdim],
                       &lbf[spos+7*qdim]);
        break;
      case CERF:
        fD3Q19VCEZouHe(p0, uwall[0], uwall[2], uwall[1], &force[0], &lbf[spos], &lbf[spos+1*qdim],
                       &lbf[spos+3*qdim], &lbf[spos+2*qdim], &lbf[spos+6*qdim], &lbf[spos+7*qdim],
                       &lbf[spos+4*qdim], &lbf[spos+5*qdim], &lbf[spos+8*qdim], &lbf[spos+18*qdim],
                       &lbf[spos+10*qdim], &lbf[spos+12*qdim], &lbf[spos+11*qdim], &lbf[spos+15*qdim],
                       &lbf[spos+16*qdim], &lbf[spos+13*qdim], &lbf[spos+14*qdim], &lbf[spos+17*qdim],
                       &lbf[spos+9*qdim]);
        break;
      case CETB:
        fD3Q19VCEZouHe(p0, uwall[1], -uwall[2], uwall[0], &force[0], &lbf[spos], &lbf[spos+2*qdim],
                       &lbf[spos+12*qdim], &lbf[spos+1*qdim], &lbf[spos+9*qdim], &lbf[spos+8*qdim],
                       &lbf[spos+4*qdim], &lbf[spos+14*qdim], &lbf[spos+7*qdim], &lbf[spos+15*qdim],
                       &lbf[spos+11*qdim], &lbf[spos+3*qdim], &lbf[spos+10*qdim], &lbf[spos+18*qdim],
                       &lbf[spos+17*qdim], &lbf[spos+13*qdim], &lbf[spos+5*qdim], &lbf[spos+16*qdim],
                       &lbf[spos+6*qdim]);
        break;
      case CELB:
        fD3Q19VCEZouHe(p0, -uwall[0], -uwall[2], uwall[1], &force[0], &lbf[spos], &lbf[spos+10*qdim],
                       &lbf[spos+12*qdim], &lbf[spos+2*qdim], &lbf[spos+15*qdim], &lbf[spos+16*qdim],
                       &lbf[spos+14*qdim], &lbf[spos+13*qdim], &lbf[spos+9*qdim], &lbf[spos+17*qdim],
                       &lbf[spos+1*qdim], &lbf[spos+3*qdim], &lbf[spos+11*qdim], &lbf[spos+6*qdim],
                       &lbf[spos+7*qdim], &lbf[spos+5*qdim], &lbf[spos+4*qdim], &lbf[spos+18*qdim],
                       &lbf[spos+8*qdim]);
        break;
      case CEDB:
        fD3Q19VCEZouHe(p0, -uwall[1], -uwall[2], uwall[0], &force[0], &lbf[spos], &lbf[spos+11*qdim],
                       &lbf[spos+12*qdim], &lbf[spos+1*qdim], &lbf[spos+17*qdim], &lbf[spos+18*qdim],
                       &lbf[spos+5*qdim], &lbf[spos+13*qdim], &lbf[spos+7*qdim], &lbf[spos+15*qdim],
                       &lbf[spos+2*qdim], &lbf[spos+3*qdim], &lbf[spos+10*qdim], &lbf[spos+8*qdim],
                       &lbf[spos+9*qdim], &lbf[spos+14*qdim], &lbf[spos+4*qdim], &lbf[spos+16*qdim],
                       &lbf[spos+6*qdim]);
        break;
      case CERB:
        fD3Q19VCEZouHe(p0, uwall[0], -uwall[2], uwall[1], &force[0], &lbf[spos], &lbf[spos+1*qdim],
                       &lbf[spos+12*qdim], &lbf[spos+2*qdim], &lbf[spos+7*qdim], &lbf[spos+6*qdim],
                       &lbf[spos+4*qdim], &lbf[spos+5*qdim], &lbf[spos+9*qdim], &lbf[spos+17*qdim],
                       &lbf[spos+10*qdim], &lbf[spos+3*qdim], &lbf[spos+11*qdim], &lbf[spos+16*qdim],
                       &lbf[spos+15*qdim], &lbf[spos+13*qdim], &lbf[spos+14*qdim], &lbf[spos+18*qdim],
                       &lbf[spos+8*qdim]);
        break;
    }
  }
  else if(collide>11) {
    switch (prop) {
      case PST:
        fD3Q19PPSZouHe(p0, &force[0], &lbf[spos], &lbf[spos+1*qdim],
                       &lbf[spos+2*qdim], &lbf[spos+3*qdim], &lbf[spos+4*qdim], &lbf[spos+5*qdim],
                       &lbf[spos+6*qdim], &lbf[spos+7*qdim], &lbf[spos+8*qdim], &lbf[spos+9*qdim],
                       &lbf[spos+10*qdim], &lbf[spos+11*qdim], &lbf[spos+12*qdim], &lbf[spos+13*qdim],
                       &lbf[spos+14*qdim], &lbf[spos+15*qdim], &lbf[spos+16*qdim], &lbf[spos+17*qdim],
                       &lbf[spos+18*qdim], moment);
        uwall[1] += moment;
        break;
      case PSD:
        fD3Q19PPSZouHe(p0, &force[0], &lbf[spos], &lbf[spos+10*qdim],
                       &lbf[spos+11*qdim], &lbf[spos+12*qdim], &lbf[spos+13*qdim], &lbf[spos+14*qdim],
                       &lbf[spos+15*qdim], &lbf[spos+16*qdim], &lbf[spos+17*qdim], &lbf[spos+18*qdim],
                       &lbf[spos+1*qdim], &lbf[spos+2*qdim], &lbf[spos+3*qdim], &lbf[spos+4*qdim],
                       &lbf[spos+5*qdim], &lbf[spos+6*qdim], &lbf[spos+7*qdim], &lbf[spos+8*qdim],
                       &lbf[spos+9*qdim], moment);
        uwall[1] -= moment;
        break;
      case PSL:
        fD3Q19PPSZouHe(p0, &force[0], &lbf[spos], &lbf[spos+12*qdim],
                       &lbf[spos+10*qdim], &lbf[spos+11*qdim], &lbf[spos+15*qdim], &lbf[spos+7*qdim],
                       &lbf[spos+17*qdim], &lbf[spos+9*qdim], &lbf[spos+13*qdim], &lbf[spos+14*qdim],
                       &lbf[spos+3*qdim], &lbf[spos+1*qdim], &lbf[spos+2*qdim], &lbf[spos+6*qdim],
                       &lbf[spos+16*qdim], &lbf[spos+8*qdim], &lbf[spos+18*qdim], &lbf[spos+4*qdim],
                       &lbf[spos+5*qdim], moment);
        uwall[0] -= moment;
        break;
      case PSR:
        fD3Q19PPSZouHe(p0, &force[0], &lbf[spos], &lbf[spos+3*qdim],
                       &lbf[spos+1*qdim], &lbf[spos+2*qdim], &lbf[spos+6*qdim], &lbf[spos+16*qdim],
                       &lbf[spos+8*qdim], &lbf[spos+18*qdim], &lbf[spos+4*qdim], &lbf[spos+5*qdim],
                       &lbf[spos+12*qdim], &lbf[spos+10*qdim], &lbf[spos+11*qdim], &lbf[spos+15*qdim],
                       &lbf[spos+7*qdim], &lbf[spos+17*qdim], &lbf[spos+9*qdim], &lbf[spos+13*qdim],
                       &lbf[spos+14*qdim], moment);
        uwall[0] += moment;
        break;
      case PSF:
        fD3Q19PPSZouHe(p0, &force[0], &lbf[spos], &lbf[spos+11*qdim],
                       &lbf[spos+12*qdim], &lbf[spos+10*qdim], &lbf[spos+17*qdim], &lbf[spos+18*qdim],
                       &lbf[spos+13*qdim], &lbf[spos+5*qdim], &lbf[spos+15*qdim], &lbf[spos+7*qdim],
                       &lbf[spos+2*qdim], &lbf[spos+3*qdim], &lbf[spos+1*qdim], &lbf[spos+8*qdim],
                       &lbf[spos+9*qdim], &lbf[spos+4*qdim], &lbf[spos+14*qdim], &lbf[spos+6*qdim],
                       &lbf[spos+16*qdim], moment);
        uwall[2] -= moment;
        break;
      case PSB:
        fD3Q19PPSZouHe(p0, &force[0], &lbf[spos], &lbf[spos+2*qdim],
                       &lbf[spos+3*qdim], &lbf[spos+1*qdim], &lbf[spos+8*qdim], &lbf[spos+9*qdim],
                       &lbf[spos+4*qdim], &lbf[spos+14*qdim], &lbf[spos+6*qdim], &lbf[spos+16*qdim],
                       &lbf[spos+11*qdim], &lbf[spos+12*qdim], &lbf[spos+10*qdim], &lbf[spos+17*qdim],
                       &lbf[spos+18*qdim], &lbf[spos+13*qdim], &lbf[spos+5*qdim], &lbf[spos+15*qdim],
                       &lbf[spos+7*qdim], moment);
        uwall[2] += moment;
        break;
      case CCTRB:
        fD3Q19VCCCLBEZouHe(p0, uwall[0], uwall[1], -uwall[2], &force[0], &lbf[spos], &lbf[spos+1*qdim],
                           &lbf[spos+2*qdim], &lbf[spos+12*qdim], &lbf[spos+4*qdim], &lbf[spos+5*qdim],
                           &lbf[spos+7*qdim], &lbf[spos+6*qdim], &lbf[spos+9*qdim], &lbf[spos+8*qdim],
                           &lbf[spos+10*qdim], &lbf[spos+11*qdim], &lbf[spos+3*qdim], &lbf[spos+13*qdim],
                           &lbf[spos+14*qdim], &lbf[spos+16*qdim], &lbf[spos+15*qdim], &lbf[spos+18*qdim],
                           &lbf[spos+17*qdim]);
        break;
      case CCTLB:
        fD3Q19VCCCLBEZouHe(p0, -uwall[0], uwall[1], -uwall[2], &force[0], &lbf[spos], &lbf[spos+10*qdim],
                           &lbf[spos+2*qdim], &lbf[spos+12*qdim], &lbf[spos+14*qdim], &lbf[spos+13*qdim],
                           &lbf[spos+15*qdim], &lbf[spos+16*qdim], &lbf[spos+9*qdim], &lbf[spos+8*qdim],
                           &lbf[spos+1*qdim], &lbf[spos+11*qdim], &lbf[spos+3*qdim], &lbf[spos+5*qdim],
                           &lbf[spos+4*qdim], &lbf[spos+6*qdim], &lbf[spos+7*qdim], &lbf[spos+18*qdim],
                           &lbf[spos+17*qdim]);
        break;
      case CCDLB:
        fD3Q19VCCCLBEZouHe(p0, -uwall[0], -uwall[1], -uwall[2], &force[0], &lbf[spos], &lbf[spos+10*qdim],
                           &lbf[spos+11*qdim], &lbf[spos+12*qdim], &lbf[spos+13*qdim], &lbf[spos+14*qdim],
                           &lbf[spos+15*qdim], &lbf[spos+16*qdim], &lbf[spos+17*qdim], &lbf[spos+18*qdim],
                           &lbf[spos+1*qdim], &lbf[spos+2*qdim], &lbf[spos+3*qdim], &lbf[spos+4*qdim],
                           &lbf[spos+5*qdim], &lbf[spos+6*qdim], &lbf[spos+7*qdim], &lbf[spos+8*qdim],
                           &lbf[spos+9*qdim]);
        break;
      case CCDRB:
        fD3Q19VCCCLBEZouHe(p0, uwall[0], -uwall[1], -uwall[2], &force[0], &lbf[spos], &lbf[spos+1*qdim],
                           &lbf[spos+11*qdim], &lbf[spos+12*qdim], &lbf[spos+5*qdim], &lbf[spos+4*qdim],
                           &lbf[spos+7*qdim], &lbf[spos+6*qdim], &lbf[spos+17*qdim], &lbf[spos+18*qdim],
                           &lbf[spos+10*qdim], &lbf[spos+2*qdim], &lbf[spos+3*qdim], &lbf[spos+14*qdim],
                           &lbf[spos+13*qdim], &lbf[spos+16*qdim], &lbf[spos+15*qdim], &lbf[spos+8*qdim],
                           &lbf[spos+9*qdim]);
        break;
      case CCTRF:
        fD3Q19VCCCLBEZouHe(p0, uwall[0], uwall[1], uwall[2], &force[0], &lbf[spos], &lbf[spos+1*qdim],
                           &lbf[spos+2*qdim], &lbf[spos+3*qdim], &lbf[spos+4*qdim], &lbf[spos+5*qdim],
                           &lbf[spos+6*qdim], &lbf[spos+7*qdim], &lbf[spos+8*qdim], &lbf[spos+9*qdim],
                           &lbf[spos+10*qdim], &lbf[spos+11*qdim], &lbf[spos+12*qdim], &lbf[spos+13*qdim],
                           &lbf[spos+14*qdim], &lbf[spos+15*qdim], &lbf[spos+16*qdim], &lbf[spos+17*qdim],
                           &lbf[spos+18*qdim]);
        break;
      case CCTLF:
        fD3Q19VCCCLBEZouHe(p0, -uwall[0], uwall[1], uwall[2], &force[0], &lbf[spos], &lbf[spos+10*qdim],
                           &lbf[spos+2*qdim], &lbf[spos+3*qdim], &lbf[spos+14*qdim], &lbf[spos+13*qdim],
                           &lbf[spos+16*qdim], &lbf[spos+15*qdim], &lbf[spos+8*qdim], &lbf[spos+9*qdim],
                           &lbf[spos+1*qdim], &lbf[spos+11*qdim], &lbf[spos+12*qdim], &lbf[spos+5*qdim],
                           &lbf[spos+4*qdim], &lbf[spos+7*qdim], &lbf[spos+6*qdim], &lbf[spos+17*qdim],
                           &lbf[spos+18*qdim]);
        break;
      case CCDLF:
        fD3Q19VCCCLBEZouHe(p0, -uwall[0], -uwall[1], uwall[2], &force[0], &lbf[spos], &lbf[spos+10*qdim],
                           &lbf[spos+11*qdim], &lbf[spos+3*qdim], &lbf[spos+13*qdim], &lbf[spos+14*qdim],
                           &lbf[spos+16*qdim], &lbf[spos+15*qdim], &lbf[spos+18*qdim], &lbf[spos+17*qdim],
                           &lbf[spos+1*qdim], &lbf[spos+2*qdim], &lbf[spos+12*qdim], &lbf[spos+4*qdim],
                           &lbf[spos+5*qdim], &lbf[spos+7*qdim], &lbf[spos+6*qdim], &lbf[spos+9*qdim],
                           &lbf[spos+8*qdim]);
        break;
      case CCDRF:
        fD3Q19VCCCLBEZouHe(p0, uwall[0], -uwall[1], uwall[2], &force[0], &lbf[spos], &lbf[spos+1*qdim],
                           &lbf[spos+11*qdim], &lbf[spos+3*qdim], &lbf[spos+5*qdim], &lbf[spos+4*qdim],
                           &lbf[spos+6*qdim], &lbf[spos+7*qdim], &lbf[spos+18*qdim], &lbf[spos+17*qdim],
                           &lbf[spos+10*qdim], &lbf[spos+2*qdim], &lbf[spos+12*qdim], &lbf[spos+14*qdim],
                           &lbf[spos+13*qdim], &lbf[spos+15*qdim], &lbf[spos+16*qdim], &lbf[spos+9*qdim],
                           &lbf[spos+8*qdim]);
        break;
      case CETR:
        fD3Q19VCECLBEZouHe(p0, uwall[0], uwall[1], uwall[2], &force[0], &lbf[spos], &lbf[spos+1*qdim],
                           &lbf[spos+2*qdim], &lbf[spos+3*qdim], &lbf[spos+4*qdim], &lbf[spos+5*qdim],
                           &lbf[spos+6*qdim], &lbf[spos+7*qdim], &lbf[spos+8*qdim], &lbf[spos+9*qdim],
                           &lbf[spos+10*qdim], &lbf[spos+11*qdim], &lbf[spos+12*qdim], &lbf[spos+13*qdim],
                           &lbf[spos+14*qdim], &lbf[spos+15*qdim], &lbf[spos+16*qdim], &lbf[spos+17*qdim],
                           &lbf[spos+18*qdim]);
        break;
      case CETL:
        fD3Q19VCECLBEZouHe(p0, uwall[1], -uwall[0], uwall[2], &force[0], &lbf[spos], &lbf[spos+2*qdim],
                           &lbf[spos+10*qdim], &lbf[spos+3*qdim], &lbf[spos+14*qdim], &lbf[spos+4*qdim],
                           &lbf[spos+8*qdim], &lbf[spos+9*qdim], &lbf[spos+16*qdim], &lbf[spos+15*qdim],
                           &lbf[spos+11*qdim], &lbf[spos+1*qdim], &lbf[spos+12*qdim], &lbf[spos+5*qdim],
                           &lbf[spos+13*qdim], &lbf[spos+17*qdim], &lbf[spos+18*qdim], &lbf[spos+7*qdim],
                           &lbf[spos+6*qdim]);
        break;
      case CEDL:
        fD3Q19VCECLBEZouHe(p0, -uwall[0], -uwall[1], uwall[2], &force[0], &lbf[spos], &lbf[spos+10*qdim],
                           &lbf[spos+11*qdim], &lbf[spos+3*qdim], &lbf[spos+13*qdim], &lbf[spos+14*qdim],
                           &lbf[spos+16*qdim], &lbf[spos+15*qdim], &lbf[spos+18*qdim], &lbf[spos+17*qdim],
                           &lbf[spos+1*qdim], &lbf[spos+2*qdim], &lbf[spos+12*qdim], &lbf[spos+4*qdim],
                           &lbf[spos+5*qdim], &lbf[spos+7*qdim], &lbf[spos+6*qdim], &lbf[spos+9*qdim],
                           &lbf[spos+8*qdim]);
        break;
      case CEDR:
        fD3Q19VCECLBEZouHe(p0, -uwall[1], uwall[0], uwall[2], &force[0], &lbf[spos], &lbf[spos+11*qdim],
                           &lbf[spos+1*qdim], &lbf[spos+3*qdim], &lbf[spos+5*qdim], &lbf[spos+13*qdim],
                           &lbf[spos+18*qdim], &lbf[spos+17*qdim], &lbf[spos+6*qdim], &lbf[spos+7*qdim],
                           &lbf[spos+2*qdim], &lbf[spos+10*qdim], &lbf[spos+12*qdim], &lbf[spos+14*qdim],
                           &lbf[spos+4*qdim], &lbf[spos+9*qdim], &lbf[spos+8*qdim], &lbf[spos+15*qdim],
                           &lbf[spos+16*qdim]);
        break;
      case CETF:
        fD3Q19VCECLBEZouHe(p0, uwall[1], uwall[2], uwall[0], &force[0], &lbf[spos], &lbf[spos+2*qdim],
                           &lbf[spos+3*qdim], &lbf[spos+1*qdim], &lbf[spos+8*qdim], &lbf[spos+9*qdim],
                           &lbf[spos+4*qdim], &lbf[spos+14*qdim], &lbf[spos+6*qdim], &lbf[spos+16*qdim],
                           &lbf[spos+11*qdim], &lbf[spos+12*qdim], &lbf[spos+10*qdim], &lbf[spos+17*qdim],
                           &lbf[spos+18*qdim], &lbf[spos+13*qdim], &lbf[spos+5*qdim], &lbf[spos+15*qdim],
                           &lbf[spos+7*qdim]);
        break;
      case CELF:
        fD3Q19VCECLBEZouHe(p0, -uwall[0], uwall[2], uwall[1], &force[0], &lbf[spos], &lbf[spos+10*qdim],
                           &lbf[spos+3*qdim], &lbf[spos+2*qdim], &lbf[spos+16*qdim], &lbf[spos+15*qdim],
                           &lbf[spos+14*qdim], &lbf[spos+13*qdim], &lbf[spos+8*qdim], &lbf[spos+18*qdim],
                           &lbf[spos+1*qdim], &lbf[spos+12*qdim], &lbf[spos+11*qdim], &lbf[spos+7*qdim],
                           &lbf[spos+6*qdim], &lbf[spos+5*qdim], &lbf[spos+4*qdim], &lbf[spos+17*qdim],
                           &lbf[spos+9*qdim]);
        break;
      case CEDF:
        fD3Q19VCECLBEZouHe(p0, -uwall[1], uwall[2], uwall[0], &force[0], &lbf[spos], &lbf[spos+11*qdim],
                           &lbf[spos+3*qdim], &lbf[spos+1*qdim], &lbf[spos+18*qdim], &lbf[spos+17*qdim],
                           &lbf[spos+5*qdim], &lbf[spos+13*qdim], &lbf[spos+6*qdim], &lbf[spos+16*qdim],
                           &lbf[spos+2*qdim], &lbf[spos+12*qdim], &lbf[spos+10*qdim], &lbf[spos+9*qdim],
                           &lbf[spos+8*qdim], &lbf[spos+14*qdim], &lbf[spos+4*qdim], &lbf[spos+15*qdim],
                           &lbf[spos+7*qdim]);
        break;
      case CERF:
        fD3Q19VCECLBEZouHe(p0, uwall[0], uwall[2], uwall[1], &force[0], &lbf[spos], &lbf[spos+1*qdim],
                           &lbf[spos+3*qdim], &lbf[spos+2*qdim], &lbf[spos+6*qdim], &lbf[spos+7*qdim],
                           &lbf[spos+4*qdim], &lbf[spos+5*qdim], &lbf[spos+8*qdim], &lbf[spos+18*qdim],
                           &lbf[spos+10*qdim], &lbf[spos+12*qdim], &lbf[spos+11*qdim], &lbf[spos+15*qdim],
                           &lbf[spos+16*qdim], &lbf[spos+13*qdim], &lbf[spos+14*qdim], &lbf[spos+17*qdim],
                           &lbf[spos+9*qdim]);
        break;
      case CETB:
        fD3Q19VCECLBEZouHe(p0, uwall[1], -uwall[2], uwall[0], &force[0], &lbf[spos], &lbf[spos+2*qdim],
                           &lbf[spos+12*qdim], &lbf[spos+1*qdim], &lbf[spos+9*qdim], &lbf[spos+8*qdim],
                           &lbf[spos+4*qdim], &lbf[spos+14*qdim], &lbf[spos+7*qdim], &lbf[spos+15*qdim],
                           &lbf[spos+11*qdim], &lbf[spos+3*qdim], &lbf[spos+10*qdim], &lbf[spos+18*qdim],
                           &lbf[spos+17*qdim], &lbf[spos+13*qdim], &lbf[spos+5*qdim], &lbf[spos+16*qdim],
                           &lbf[spos+6*qdim]);
        break;
      case CELB:
        fD3Q19VCECLBEZouHe(p0, -uwall[0], -uwall[2], uwall[1], &force[0], &lbf[spos], &lbf[spos+10*qdim],
                           &lbf[spos+12*qdim], &lbf[spos+2*qdim], &lbf[spos+15*qdim], &lbf[spos+16*qdim],
                           &lbf[spos+14*qdim], &lbf[spos+13*qdim], &lbf[spos+9*qdim], &lbf[spos+17*qdim],
                           &lbf[spos+1*qdim], &lbf[spos+3*qdim], &lbf[spos+11*qdim], &lbf[spos+6*qdim],
                           &lbf[spos+7*qdim], &lbf[spos+5*qdim], &lbf[spos+4*qdim], &lbf[spos+18*qdim],
                           &lbf[spos+8*qdim]);
        break;
      case CEDB:
        fD3Q19VCECLBEZouHe(p0, -uwall[1], -uwall[2], uwall[0], &force[0], &lbf[spos], &lbf[spos+11*qdim],
                           &lbf[spos+12*qdim], &lbf[spos+1*qdim], &lbf[spos+17*qdim], &lbf[spos+18*qdim],
                           &lbf[spos+5*qdim], &lbf[spos+13*qdim], &lbf[spos+7*qdim], &lbf[spos+15*qdim],
                           &lbf[spos+2*qdim], &lbf[spos+3*qdim], &lbf[spos+10*qdim], &lbf[spos+8*qdim],
                           &lbf[spos+9*qdim], &lbf[spos+14*qdim], &lbf[spos+4*qdim], &lbf[spos+16*qdim],
                           &lbf[spos+6*qdim]);
        break;
      case CERB:
        fD3Q19VCECLBEZouHe(p0, uwall[0], -uwall[2], uwall[1], &force[0], &lbf[spos], &lbf[spos+1*qdim],
                           &lbf[spos+12*qdim], &lbf[spos+2*qdim], &lbf[spos+7*qdim], &lbf[spos+6*qdim],
                           &lbf[spos+4*qdim], &lbf[spos+5*qdim], &lbf[spos+9*qdim], &lbf[spos+17*qdim],
                           &lbf[spos+10*qdim], &lbf[spos+3*qdim], &lbf[spos+11*qdim], &lbf[spos+16*qdim],
                           &lbf[spos+15*qdim], &lbf[spos+13*qdim], &lbf[spos+14*qdim], &lbf[spos+18*qdim],
                           &lbf[spos+8*qdim]);
        break;
    }
  }
  else {
    switch (prop) {
      case PST:
        fD3Q19PPSZouHe(p0, &force[0], &lbf[spos], &lbf[spos+1*qdim],
                       &lbf[spos+2*qdim], &lbf[spos+3*qdim], &lbf[spos+4*qdim], &lbf[spos+5*qdim],
                       &lbf[spos+6*qdim], &lbf[spos+7*qdim], &lbf[spos+8*qdim], &lbf[spos+9*qdim],
                       &lbf[spos+10*qdim], &lbf[spos+11*qdim], &lbf[spos+12*qdim], &lbf[spos+13*qdim],
                       &lbf[spos+14*qdim], &lbf[spos+15*qdim], &lbf[spos+16*qdim], &lbf[spos+17*qdim],
                       &lbf[spos+18*qdim], moment);
        uwall[1] += moment;
        break;
      case PSD:
        fD3Q19PPSZouHe(p0, &force[0], &lbf[spos], &lbf[spos+10*qdim],
                       &lbf[spos+11*qdim], &lbf[spos+12*qdim], &lbf[spos+13*qdim], &lbf[spos+14*qdim],
                       &lbf[spos+15*qdim], &lbf[spos+16*qdim], &lbf[spos+17*qdim], &lbf[spos+18*qdim],
                       &lbf[spos+1*qdim], &lbf[spos+2*qdim], &lbf[spos+3*qdim], &lbf[spos+4*qdim],
                       &lbf[spos+5*qdim], &lbf[spos+6*qdim], &lbf[spos+7*qdim], &lbf[spos+8*qdim],
                       &lbf[spos+9*qdim], moment);
        uwall[1] -= moment;
        break;
      case PSL:
        fD3Q19PPSZouHe(p0, &force[0], &lbf[spos], &lbf[spos+12*qdim],
                       &lbf[spos+10*qdim], &lbf[spos+11*qdim], &lbf[spos+15*qdim], &lbf[spos+7*qdim],
                       &lbf[spos+17*qdim], &lbf[spos+9*qdim], &lbf[spos+13*qdim], &lbf[spos+14*qdim],
                       &lbf[spos+3*qdim], &lbf[spos+1*qdim], &lbf[spos+2*qdim], &lbf[spos+6*qdim],
                       &lbf[spos+16*qdim], &lbf[spos+8*qdim], &lbf[spos+18*qdim], &lbf[spos+4*qdim],
                       &lbf[spos+5*qdim], moment);
        uwall[0] -= moment;
        break;
      case PSR:
        fD3Q19PPSZouHe(p0, &force[0], &lbf[spos], &lbf[spos+3*qdim],
                       &lbf[spos+1*qdim], &lbf[spos+2*qdim], &lbf[spos+6*qdim], &lbf[spos+16*qdim],
                       &lbf[spos+8*qdim], &lbf[spos+18*qdim], &lbf[spos+4*qdim], &lbf[spos+5*qdim],
                       &lbf[spos+12*qdim], &lbf[spos+10*qdim], &lbf[spos+11*qdim], &lbf[spos+15*qdim],
                       &lbf[spos+7*qdim], &lbf[spos+17*qdim], &lbf[spos+9*qdim], &lbf[spos+13*qdim],
                       &lbf[spos+14*qdim], moment);
        uwall[0] += moment;
        break;
      case PSF:
        fD3Q19PPSZouHe(p0, &force[0], &lbf[spos], &lbf[spos+11*qdim],
                       &lbf[spos+12*qdim], &lbf[spos+10*qdim], &lbf[spos+17*qdim], &lbf[spos+18*qdim],
                       &lbf[spos+13*qdim], &lbf[spos+5*qdim], &lbf[spos+15*qdim], &lbf[spos+7*qdim],
                       &lbf[spos+2*qdim], &lbf[spos+3*qdim], &lbf[spos+1*qdim], &lbf[spos+8*qdim],
                       &lbf[spos+9*qdim], &lbf[spos+4*qdim], &lbf[spos+14*qdim], &lbf[spos+6*qdim],
                       &lbf[spos+16*qdim], moment);
        uwall[2] -= moment;
        break;
      case PSB:
        fD3Q19PPSZouHe(p0, &force[0], &lbf[spos], &lbf[spos+2*qdim],
                       &lbf[spos+3*qdim], &lbf[spos+1*qdim], &lbf[spos+8*qdim], &lbf[spos+9*qdim],
                       &lbf[spos+4*qdim], &lbf[spos+14*qdim], &lbf[spos+6*qdim], &lbf[spos+16*qdim],
                       &lbf[spos+11*qdim], &lbf[spos+12*qdim], &lbf[spos+10*qdim], &lbf[spos+17*qdim],
                       &lbf[spos+18*qdim], &lbf[spos+13*qdim], &lbf[spos+5*qdim], &lbf[spos+15*qdim],
                       &lbf[spos+7*qdim], moment);
        uwall[2] += moment;
        break;
      case CCTRB:
        fD3Q19VCCZouHe(p0, uwall[0], uwall[1], -uwall[2], &force[0], &lbf[spos], &lbf[spos+1*qdim],
                       &lbf[spos+2*qdim], &lbf[spos+12*qdim], &lbf[spos+4*qdim], &lbf[spos+5*qdim],
                       &lbf[spos+7*qdim], &lbf[spos+6*qdim], &lbf[spos+9*qdim], &lbf[spos+8*qdim],
                       &lbf[spos+10*qdim], &lbf[spos+11*qdim], &lbf[spos+3*qdim], &lbf[spos+13*qdim],
                       &lbf[spos+14*qdim], &lbf[spos+16*qdim], &lbf[spos+15*qdim], &lbf[spos+18*qdim],
                       &lbf[spos+17*qdim]);
        break;
      case CCTLB:
        fD3Q19VCCZouHe(p0, -uwall[0], uwall[1], -uwall[2], &force[0], &lbf[spos], &lbf[spos+10*qdim],
                       &lbf[spos+2*qdim], &lbf[spos+12*qdim], &lbf[spos+14*qdim], &lbf[spos+13*qdim],
                       &lbf[spos+15*qdim], &lbf[spos+16*qdim], &lbf[spos+9*qdim], &lbf[spos+8*qdim],
                       &lbf[spos+1*qdim], &lbf[spos+11*qdim], &lbf[spos+3*qdim], &lbf[spos+5*qdim],
                       &lbf[spos+4*qdim], &lbf[spos+6*qdim], &lbf[spos+7*qdim], &lbf[spos+18*qdim],
                       &lbf[spos+17*qdim]);
        break;
      case CCDLB:
        fD3Q19VCCZouHe(p0, -uwall[0], -uwall[1], -uwall[2], &force[0], &lbf[spos], &lbf[spos+10*qdim],
                       &lbf[spos+11*qdim], &lbf[spos+12*qdim], &lbf[spos+13*qdim], &lbf[spos+14*qdim],
                       &lbf[spos+15*qdim], &lbf[spos+16*qdim], &lbf[spos+17*qdim], &lbf[spos+18*qdim],
                       &lbf[spos+1*qdim], &lbf[spos+2*qdim], &lbf[spos+3*qdim], &lbf[spos+4*qdim],
                       &lbf[spos+5*qdim], &lbf[spos+6*qdim], &lbf[spos+7*qdim], &lbf[spos+8*qdim],
                       &lbf[spos+9*qdim]);
        break;
      case CCDRB:
        fD3Q19VCCZouHe(p0, uwall[0], -uwall[1], -uwall[2], &force[0], &lbf[spos], &lbf[spos+1*qdim],
                       &lbf[spos+11*qdim], &lbf[spos+12*qdim], &lbf[spos+5*qdim], &lbf[spos+4*qdim],
                       &lbf[spos+7*qdim], &lbf[spos+6*qdim], &lbf[spos+17*qdim], &lbf[spos+18*qdim],
                       &lbf[spos+10*qdim], &lbf[spos+2*qdim], &lbf[spos+3*qdim], &lbf[spos+14*qdim],
                       &lbf[spos+13*qdim], &lbf[spos+16*qdim], &lbf[spos+15*qdim], &lbf[spos+8*qdim],
                       &lbf[spos+9*qdim]);
        break;
      case CCTRF:
        fD3Q19VCCZouHe(p0, uwall[0], uwall[1], uwall[2], &force[0], &lbf[spos], &lbf[spos+1*qdim],
                       &lbf[spos+2*qdim], &lbf[spos+3*qdim], &lbf[spos+4*qdim], &lbf[spos+5*qdim],
                       &lbf[spos+6*qdim], &lbf[spos+7*qdim], &lbf[spos+8*qdim], &lbf[spos+9*qdim],
                       &lbf[spos+10*qdim], &lbf[spos+11*qdim], &lbf[spos+12*qdim], &lbf[spos+13*qdim],
                       &lbf[spos+14*qdim], &lbf[spos+15*qdim], &lbf[spos+16*qdim], &lbf[spos+17*qdim],
                       &lbf[spos+18*qdim]);
        break;
      case CCTLF:
        fD3Q19VCCZouHe(p0, -uwall[0], uwall[1], uwall[2], &force[0], &lbf[spos], &lbf[spos+10*qdim],
                       &lbf[spos+2*qdim], &lbf[spos+3*qdim], &lbf[spos+14*qdim], &lbf[spos+13*qdim],
                       &lbf[spos+16*qdim], &lbf[spos+15*qdim], &lbf[spos+8*qdim], &lbf[spos+9*qdim],
                       &lbf[spos+1*qdim], &lbf[spos+11*qdim], &lbf[spos+12*qdim], &lbf[spos+5*qdim],
                       &lbf[spos+4*qdim], &lbf[spos+7*qdim], &lbf[spos+6*qdim], &lbf[spos+17*qdim],
                       &lbf[spos+18*qdim]);
        break;
      case CCDLF:
        fD3Q19VCCZouHe(p0, -uwall[0], -uwall[1], uwall[2], &force[0], &lbf[spos], &lbf[spos+10*qdim],
                       &lbf[spos+11*qdim], &lbf[spos+3*qdim], &lbf[spos+13*qdim], &lbf[spos+14*qdim],
                       &lbf[spos+16*qdim], &lbf[spos+15*qdim], &lbf[spos+18*qdim], &lbf[spos+17*qdim],
                       &lbf[spos+1*qdim], &lbf[spos+2*qdim], &lbf[spos+12*qdim], &lbf[spos+4*qdim],
                       &lbf[spos+5*qdim], &lbf[spos+7*qdim], &lbf[spos+6*qdim], &lbf[spos+9*qdim],
                       &lbf[spos+8*qdim]);
        break;
      case CCDRF:
        fD3Q19VCCZouHe(p0, uwall[0], -uwall[1], uwall[2], &force[0], &lbf[spos], &lbf[spos+1*qdim],
                       &lbf[spos+11*qdim], &lbf[spos+3*qdim], &lbf[spos+5*qdim], &lbf[spos+4*qdim],
                       &lbf[spos+6*qdim], &lbf[spos+7*qdim], &lbf[spos+18*qdim], &lbf[spos+17*qdim],
                       &lbf[spos+10*qdim], &lbf[spos+2*qdim], &lbf[spos+12*qdim], &lbf[spos+14*qdim],
                       &lbf[spos+13*qdim], &lbf[spos+15*qdim], &lbf[spos+16*qdim], &lbf[spos+9*qdim],
                       &lbf[spos+8*qdim]);
        break;
      case CETR:
        fD3Q19VCEZouHe(p0, uwall[0], uwall[1], uwall[2], &force[0], &lbf[spos], &lbf[spos+1*qdim],
                       &lbf[spos+2*qdim], &lbf[spos+3*qdim], &lbf[spos+4*qdim], &lbf[spos+5*qdim],
                       &lbf[spos+6*qdim], &lbf[spos+7*qdim], &lbf[spos+8*qdim], &lbf[spos+9*qdim],
                       &lbf[spos+10*qdim], &lbf[spos+11*qdim], &lbf[spos+12*qdim], &lbf[spos+13*qdim],
                       &lbf[spos+14*qdim], &lbf[spos+15*qdim], &lbf[spos+16*qdim], &lbf[spos+17*qdim],
                       &lbf[spos+18*qdim]);
        break;
      case CETL:
        fD3Q19VCEZouHe(p0, uwall[1], -uwall[0], uwall[2], &force[0], &lbf[spos], &lbf[spos+2*qdim],
                       &lbf[spos+10*qdim], &lbf[spos+3*qdim], &lbf[spos+14*qdim], &lbf[spos+4*qdim],
                       &lbf[spos+8*qdim], &lbf[spos+9*qdim], &lbf[spos+16*qdim], &lbf[spos+15*qdim],
                       &lbf[spos+11*qdim], &lbf[spos+1*qdim], &lbf[spos+12*qdim], &lbf[spos+5*qdim],
                       &lbf[spos+13*qdim], &lbf[spos+17*qdim], &lbf[spos+18*qdim], &lbf[spos+7*qdim],
                       &lbf[spos+6*qdim]);
        break;
      case CEDL:
        fD3Q19VCEZouHe(p0, -uwall[0], -uwall[1], uwall[2], &force[0], &lbf[spos], &lbf[spos+10*qdim],
                       &lbf[spos+11*qdim], &lbf[spos+3*qdim], &lbf[spos+13*qdim], &lbf[spos+14*qdim],
                       &lbf[spos+16*qdim], &lbf[spos+15*qdim], &lbf[spos+18*qdim], &lbf[spos+17*qdim],
                       &lbf[spos+1*qdim], &lbf[spos+2*qdim], &lbf[spos+12*qdim], &lbf[spos+4*qdim],
                       &lbf[spos+5*qdim], &lbf[spos+7*qdim], &lbf[spos+6*qdim], &lbf[spos+9*qdim],
                       &lbf[spos+8*qdim]);
        break;
      case CEDR:
        fD3Q19VCEZouHe(p0, -uwall[1], uwall[0], uwall[2], &force[0], &lbf[spos], &lbf[spos+11*qdim],
                       &lbf[spos+1*qdim], &lbf[spos+3*qdim], &lbf[spos+5*qdim], &lbf[spos+13*qdim],
                       &lbf[spos+18*qdim], &lbf[spos+17*qdim], &lbf[spos+6*qdim], &lbf[spos+7*qdim],
                       &lbf[spos+2*qdim], &lbf[spos+10*qdim], &lbf[spos+12*qdim], &lbf[spos+14*qdim],
                       &lbf[spos+4*qdim], &lbf[spos+9*qdim], &lbf[spos+8*qdim], &lbf[spos+15*qdim],
                       &lbf[spos+16*qdim]);
        break;
      case CETF:
        fD3Q19VCEZouHe(p0, uwall[1], uwall[2], uwall[0], &force[0], &lbf[spos], &lbf[spos+2*qdim],
                       &lbf[spos+3*qdim], &lbf[spos+1*qdim], &lbf[spos+8*qdim], &lbf[spos+9*qdim],
                       &lbf[spos+4*qdim], &lbf[spos+14*qdim], &lbf[spos+6*qdim], &lbf[spos+16*qdim],
                       &lbf[spos+11*qdim], &lbf[spos+12*qdim], &lbf[spos+10*qdim], &lbf[spos+17*qdim],
                       &lbf[spos+18*qdim], &lbf[spos+13*qdim], &lbf[spos+5*qdim], &lbf[spos+15*qdim],
                       &lbf[spos+7*qdim]);
        break;
      case CELF:
        fD3Q19VCEZouHe(p0, -uwall[0], uwall[2], uwall[1], &force[0], &lbf[spos], &lbf[spos+10*qdim],
                       &lbf[spos+3*qdim], &lbf[spos+2*qdim], &lbf[spos+16*qdim], &lbf[spos+15*qdim],
                       &lbf[spos+14*qdim], &lbf[spos+13*qdim], &lbf[spos+8*qdim], &lbf[spos+18*qdim],
                       &lbf[spos+1*qdim], &lbf[spos+12*qdim], &lbf[spos+11*qdim], &lbf[spos+7*qdim],
                       &lbf[spos+6*qdim], &lbf[spos+5*qdim], &lbf[spos+4*qdim], &lbf[spos+17*qdim],
                       &lbf[spos+9*qdim]);
        break;
      case CEDF:
        fD3Q19VCEZouHe(p0, -uwall[1], uwall[2], uwall[0], &force[0], &lbf[spos], &lbf[spos+11*qdim],
                       &lbf[spos+3*qdim], &lbf[spos+1*qdim], &lbf[spos+18*qdim], &lbf[spos+17*qdim],
                       &lbf[spos+5*qdim], &lbf[spos+13*qdim], &lbf[spos+6*qdim], &lbf[spos+16*qdim],
                       &lbf[spos+2*qdim], &lbf[spos+12*qdim], &lbf[spos+10*qdim], &lbf[spos+9*qdim],
                       &lbf[spos+8*qdim], &lbf[spos+14*qdim], &lbf[spos+4*qdim], &lbf[spos+15*qdim],
                       &lbf[spos+7*qdim]);
        break;
      case CERF:
        fD3Q19VCEZouHe(p0, uwall[0], uwall[2], uwall[1], &force[0], &lbf[spos], &lbf[spos+1*qdim],
                       &lbf[spos+3*qdim], &lbf[spos+2*qdim], &lbf[spos+6*qdim], &lbf[spos+7*qdim],
                       &lbf[spos+4*qdim], &lbf[spos+5*qdim], &lbf[spos+8*qdim], &lbf[spos+18*qdim],
                       &lbf[spos+10*qdim], &lbf[spos+12*qdim], &lbf[spos+11*qdim], &lbf[spos+15*qdim],
                       &lbf[spos+16*qdim], &lbf[spos+13*qdim], &lbf[spos+14*qdim], &lbf[spos+17*qdim],
                       &lbf[spos+9*qdim]);
        break;
      case CETB:
        fD3Q19VCEZouHe(p0, uwall[1], -uwall[2], uwall[0], &force[0], &lbf[spos], &lbf[spos+2*qdim],
                       &lbf[spos+12*qdim], &lbf[spos+1*qdim], &lbf[spos+9*qdim], &lbf[spos+8*qdim],
                       &lbf[spos+4*qdim], &lbf[spos+14*qdim], &lbf[spos+7*qdim], &lbf[spos+15*qdim],
                       &lbf[spos+11*qdim], &lbf[spos+3*qdim], &lbf[spos+10*qdim], &lbf[spos+18*qdim],
                       &lbf[spos+17*qdim], &lbf[spos+13*qdim], &lbf[spos+5*qdim], &lbf[spos+16*qdim],
                       &lbf[spos+6*qdim]);
        break;
      case CELB:
        fD3Q19VCEZouHe(p0, -uwall[0], -uwall[2], uwall[1], &force[0], &lbf[spos], &lbf[spos+10*qdim],
                       &lbf[spos+12*qdim], &lbf[spos+2*qdim], &lbf[spos+15*qdim], &lbf[spos+16*qdim],
                       &lbf[spos+14*qdim], &lbf[spos+13*qdim], &lbf[spos+9*qdim], &lbf[spos+17*qdim],
                       &lbf[spos+1*qdim], &lbf[spos+3*qdim], &lbf[spos+11*qdim], &lbf[spos+6*qdim],
                       &lbf[spos+7*qdim], &lbf[spos+5*qdim], &lbf[spos+4*qdim], &lbf[spos+18*qdim],
                       &lbf[spos+8*qdim]);
        break;
      case CEDB:
        fD3Q19VCEZouHe(p0, -uwall[1], -uwall[2], uwall[0], &force[0], &lbf[spos], &lbf[spos+11*qdim],
                       &lbf[spos+12*qdim], &lbf[spos+1*qdim], &lbf[spos+17*qdim], &lbf[spos+18*qdim],
                       &lbf[spos+5*qdim], &lbf[spos+13*qdim], &lbf[spos+7*qdim], &lbf[spos+15*qdim],
                       &lbf[spos+2*qdim], &lbf[spos+3*qdim], &lbf[spos+10*qdim], &lbf[spos+8*qdim],
                       &lbf[spos+9*qdim], &lbf[spos+14*qdim], &lbf[spos+4*qdim], &lbf[spos+16*qdim],
                       &lbf[spos+6*qdim]);
        break;
      case CERB:
        fD3Q19VCEZouHe(p0, uwall[0], -uwall[2], uwall[1], &force[0], &lbf[spos], &lbf[spos+1*qdim],
                       &lbf[spos+12*qdim], &lbf[spos+2*qdim], &lbf[spos+7*qdim], &lbf[spos+6*qdim],
                       &lbf[spos+4*qdim], &lbf[spos+5*qdim], &lbf[spos+9*qdim], &lbf[spos+17*qdim],
                       &lbf[spos+10*qdim], &lbf[spos+3*qdim], &lbf[spos+11*qdim], &lbf[spos+16*qdim],
                       &lbf[spos+15*qdim], &lbf[spos+13*qdim], &lbf[spos+14*qdim], &lbf[spos+18*qdim],
                       &lbf[spos+8*qdim]);
        break;
    }
  }
  return 0;
}


int fD3Q19PFSimpleZouHe(long tpos, int prop, double *p0, double *uwall)
{
  double moment;
  long spos=tpos * lbsitelength;
  int qdim = lbsy.nf+lbsy.nc+lbsy.nt;
  double force[3*lbsy.nf];

  // sort out forces

  fD3Q19BoundaryForceDensity(force, tpos, p0, prop);
    
  // apply boundary condition
    
  if(interact==20) {
    switch (prop) {
      case PST:
        fD3Q19PPSSwiftZouHe(p0, &force[0], &lbf[spos], &lbf[spos+1*qdim],
                            &lbf[spos+2*qdim], &lbf[spos+3*qdim], &lbf[spos+4*qdim], &lbf[spos+5*qdim],
                            &lbf[spos+6*qdim], &lbf[spos+7*qdim], &lbf[spos+8*qdim], &lbf[spos+9*qdim],
                            &lbf[spos+10*qdim], &lbf[spos+11*qdim], &lbf[spos+12*qdim], &lbf[spos+13*qdim],
                            &lbf[spos+14*qdim], &lbf[spos+15*qdim], &lbf[spos+16*qdim], &lbf[spos+17*qdim],
                            &lbf[spos+18*qdim], moment);
        uwall[1] += moment;
        break;
      case PSD:
        fD3Q19PPSSwiftZouHe(p0, &force[0], &lbf[spos], &lbf[spos+10*qdim],
                            &lbf[spos+11*qdim], &lbf[spos+12*qdim], &lbf[spos+13*qdim], &lbf[spos+14*qdim],
                            &lbf[spos+15*qdim], &lbf[spos+16*qdim], &lbf[spos+17*qdim], &lbf[spos+18*qdim],
                            &lbf[spos+1*qdim], &lbf[spos+2*qdim], &lbf[spos+3*qdim], &lbf[spos+4*qdim],
                            &lbf[spos+5*qdim], &lbf[spos+6*qdim], &lbf[spos+7*qdim], &lbf[spos+8*qdim],
                            &lbf[spos+9*qdim], moment);
        uwall[1] -= moment;
        break;
      case PSL:
        fD3Q19PPSSwiftZouHe(p0, &force[0], &lbf[spos], &lbf[spos+12*qdim],
                            &lbf[spos+10*qdim], &lbf[spos+11*qdim], &lbf[spos+15*qdim], &lbf[spos+7*qdim],
                            &lbf[spos+17*qdim], &lbf[spos+9*qdim], &lbf[spos+13*qdim], &lbf[spos+14*qdim],
                            &lbf[spos+3*qdim], &lbf[spos+1*qdim], &lbf[spos+2*qdim], &lbf[spos+6*qdim],
                            &lbf[spos+16*qdim], &lbf[spos+8*qdim], &lbf[spos+18*qdim], &lbf[spos+4*qdim],
                            &lbf[spos+5*qdim], moment);
        uwall[0] -= moment;
        break;
      case PSR:
        fD3Q19PPSSwiftZouHe(p0, &force[0], &lbf[spos], &lbf[spos+3*qdim],
                            &lbf[spos+1*qdim], &lbf[spos+2*qdim], &lbf[spos+6*qdim], &lbf[spos+16*qdim],
                            &lbf[spos+8*qdim], &lbf[spos+18*qdim], &lbf[spos+4*qdim], &lbf[spos+5*qdim],
                            &lbf[spos+12*qdim], &lbf[spos+10*qdim], &lbf[spos+11*qdim], &lbf[spos+15*qdim],
                            &lbf[spos+7*qdim], &lbf[spos+17*qdim], &lbf[spos+9*qdim], &lbf[spos+13*qdim],
                            &lbf[spos+14*qdim], moment);
        uwall[0] += moment;
        break;
      case PSF:
        fD3Q19PPSSwiftZouHe(p0, &force[0], &lbf[spos], &lbf[spos+11*qdim],
                            &lbf[spos+12*qdim], &lbf[spos+10*qdim], &lbf[spos+17*qdim], &lbf[spos+18*qdim],
                            &lbf[spos+13*qdim], &lbf[spos+5*qdim], &lbf[spos+15*qdim], &lbf[spos+7*qdim],
                            &lbf[spos+2*qdim], &lbf[spos+3*qdim], &lbf[spos+1*qdim], &lbf[spos+8*qdim],
                            &lbf[spos+9*qdim], &lbf[spos+4*qdim], &lbf[spos+14*qdim], &lbf[spos+6*qdim],
                            &lbf[spos+16*qdim], moment);
        uwall[2] -= moment;
        break;
      case PSB:
        fD3Q19PPSSwiftZouHe(p0, &force[0], &lbf[spos], &lbf[spos+2*qdim],
                            &lbf[spos+3*qdim], &lbf[spos+1*qdim], &lbf[spos+8*qdim], &lbf[spos+9*qdim],
                            &lbf[spos+4*qdim], &lbf[spos+14*qdim], &lbf[spos+6*qdim], &lbf[spos+16*qdim],
                            &lbf[spos+11*qdim], &lbf[spos+12*qdim], &lbf[spos+10*qdim], &lbf[spos+17*qdim],
                            &lbf[spos+18*qdim], &lbf[spos+13*qdim], &lbf[spos+5*qdim], &lbf[spos+15*qdim],
                            &lbf[spos+7*qdim], moment);
        uwall[2] += moment;
        break;
      case CCTRB:
        fD3Q19VCCSimpleZouHe(p0, uwall[0], uwall[1], -uwall[2], &force[0], &lbf[spos], &lbf[spos+1*qdim],
                             &lbf[spos+2*qdim], &lbf[spos+12*qdim], &lbf[spos+4*qdim], &lbf[spos+5*qdim],
                             &lbf[spos+7*qdim], &lbf[spos+6*qdim], &lbf[spos+9*qdim], &lbf[spos+8*qdim],
                             &lbf[spos+10*qdim], &lbf[spos+11*qdim], &lbf[spos+3*qdim], &lbf[spos+13*qdim],
                             &lbf[spos+14*qdim], &lbf[spos+16*qdim], &lbf[spos+15*qdim], &lbf[spos+18*qdim],
                             &lbf[spos+17*qdim]);
        break;
      case CCTLB:
        fD3Q19VCCSimpleZouHe(p0, -uwall[0], uwall[1], -uwall[2], &force[0], &lbf[spos], &lbf[spos+10*qdim],
                             &lbf[spos+2*qdim], &lbf[spos+12*qdim], &lbf[spos+14*qdim], &lbf[spos+13*qdim],
                             &lbf[spos+15*qdim], &lbf[spos+16*qdim], &lbf[spos+9*qdim], &lbf[spos+8*qdim],
                             &lbf[spos+1*qdim], &lbf[spos+11*qdim], &lbf[spos+3*qdim], &lbf[spos+5*qdim],
                             &lbf[spos+4*qdim], &lbf[spos+6*qdim], &lbf[spos+7*qdim], &lbf[spos+18*qdim],
                             &lbf[spos+17*qdim]);
        break;
      case CCDLB:
        fD3Q19VCCSimpleZouHe(p0, -uwall[0], -uwall[1], -uwall[2], &force[0], &lbf[spos], &lbf[spos+10*qdim],
                             &lbf[spos+11*qdim], &lbf[spos+12*qdim], &lbf[spos+13*qdim], &lbf[spos+14*qdim],
                             &lbf[spos+15*qdim], &lbf[spos+16*qdim], &lbf[spos+17*qdim], &lbf[spos+18*qdim],
                             &lbf[spos+1*qdim], &lbf[spos+2*qdim], &lbf[spos+3*qdim], &lbf[spos+4*qdim],
                             &lbf[spos+5*qdim], &lbf[spos+6*qdim], &lbf[spos+7*qdim], &lbf[spos+8*qdim],
                             &lbf[spos+9*qdim]);
        break;
      case CCDRB:
        fD3Q19VCCSimpleZouHe(p0, uwall[0], -uwall[1], -uwall[2], &force[0], &lbf[spos], &lbf[spos+1*qdim],
                             &lbf[spos+11*qdim], &lbf[spos+12*qdim], &lbf[spos+5*qdim], &lbf[spos+4*qdim],
                             &lbf[spos+7*qdim], &lbf[spos+6*qdim], &lbf[spos+17*qdim], &lbf[spos+18*qdim],
                             &lbf[spos+10*qdim], &lbf[spos+2*qdim], &lbf[spos+3*qdim], &lbf[spos+14*qdim],
                             &lbf[spos+13*qdim], &lbf[spos+16*qdim], &lbf[spos+15*qdim], &lbf[spos+8*qdim],
                             &lbf[spos+9*qdim]);
        break;
      case CCTRF:
        fD3Q19VCCSimpleZouHe(p0, uwall[0], uwall[1], uwall[2], &force[0], &lbf[spos], &lbf[spos+1*qdim],
                             &lbf[spos+2*qdim], &lbf[spos+3*qdim], &lbf[spos+4*qdim], &lbf[spos+5*qdim],
                             &lbf[spos+6*qdim], &lbf[spos+7*qdim], &lbf[spos+8*qdim], &lbf[spos+9*qdim],
                             &lbf[spos+10*qdim], &lbf[spos+11*qdim], &lbf[spos+12*qdim], &lbf[spos+13*qdim],
                             &lbf[spos+14*qdim], &lbf[spos+15*qdim], &lbf[spos+16*qdim], &lbf[spos+17*qdim],
                             &lbf[spos+18*qdim]);
        break;
      case CCTLF:
        fD3Q19VCCSimpleZouHe(p0, -uwall[0], uwall[1], uwall[2], &force[0], &lbf[spos], &lbf[spos+10*qdim],
                             &lbf[spos+2*qdim], &lbf[spos+3*qdim], &lbf[spos+14*qdim], &lbf[spos+13*qdim],
                             &lbf[spos+16*qdim], &lbf[spos+15*qdim], &lbf[spos+8*qdim], &lbf[spos+9*qdim],
                             &lbf[spos+1*qdim], &lbf[spos+11*qdim], &lbf[spos+12*qdim], &lbf[spos+5*qdim],
                             &lbf[spos+4*qdim], &lbf[spos+7*qdim], &lbf[spos+6*qdim], &lbf[spos+17*qdim],
                             &lbf[spos+18*qdim]);
        break;
      case CCDLF:
        fD3Q19VCCSimpleZouHe(p0, -uwall[0], -uwall[1], uwall[2], &force[0], &lbf[spos], &lbf[spos+10*qdim],
                             &lbf[spos+11*qdim], &lbf[spos+3*qdim], &lbf[spos+13*qdim], &lbf[spos+14*qdim],
                             &lbf[spos+16*qdim], &lbf[spos+15*qdim], &lbf[spos+18*qdim], &lbf[spos+17*qdim],
                             &lbf[spos+1*qdim], &lbf[spos+2*qdim], &lbf[spos+12*qdim], &lbf[spos+4*qdim],
                             &lbf[spos+5*qdim], &lbf[spos+7*qdim], &lbf[spos+6*qdim], &lbf[spos+9*qdim],
                             &lbf[spos+8*qdim]);
        break;
      case CCDRF:
        fD3Q19VCCSimpleZouHe(p0, uwall[0], -uwall[1], uwall[2], &force[0], &lbf[spos], &lbf[spos+1*qdim],
                             &lbf[spos+11*qdim], &lbf[spos+3*qdim], &lbf[spos+5*qdim], &lbf[spos+4*qdim],
                             &lbf[spos+6*qdim], &lbf[spos+7*qdim], &lbf[spos+18*qdim], &lbf[spos+17*qdim],
                             &lbf[spos+10*qdim], &lbf[spos+2*qdim], &lbf[spos+12*qdim], &lbf[spos+14*qdim],
                             &lbf[spos+13*qdim], &lbf[spos+15*qdim], &lbf[spos+16*qdim], &lbf[spos+9*qdim],
                             &lbf[spos+8*qdim]);
        break;
      case CETR:
        fD3Q19VCESimpleZouHe(p0, uwall[0], uwall[1], uwall[2], &force[0], &lbf[spos], &lbf[spos+1*qdim],
                             &lbf[spos+2*qdim], &lbf[spos+3*qdim], &lbf[spos+4*qdim], &lbf[spos+5*qdim],
                             &lbf[spos+6*qdim], &lbf[spos+7*qdim], &lbf[spos+8*qdim], &lbf[spos+9*qdim],
                             &lbf[spos+10*qdim], &lbf[spos+11*qdim], &lbf[spos+12*qdim], &lbf[spos+13*qdim],
                             &lbf[spos+14*qdim], &lbf[spos+15*qdim], &lbf[spos+16*qdim], &lbf[spos+17*qdim],
                             &lbf[spos+18*qdim]);
        break;
      case CETL:
        fD3Q19VCESimpleZouHe(p0, uwall[1], -uwall[0], uwall[2], &force[0], &lbf[spos], &lbf[spos+2*qdim],
                             &lbf[spos+10*qdim], &lbf[spos+3*qdim], &lbf[spos+14*qdim], &lbf[spos+4*qdim],
                             &lbf[spos+8*qdim], &lbf[spos+9*qdim], &lbf[spos+16*qdim], &lbf[spos+15*qdim],
                             &lbf[spos+11*qdim], &lbf[spos+1*qdim], &lbf[spos+12*qdim], &lbf[spos+5*qdim],
                             &lbf[spos+13*qdim], &lbf[spos+17*qdim], &lbf[spos+18*qdim], &lbf[spos+7*qdim],
                             &lbf[spos+6*qdim]);
        break;
      case CEDL:
        fD3Q19VCESimpleZouHe(p0, -uwall[0], -uwall[1], uwall[2], &force[0], &lbf[spos], &lbf[spos+10*qdim],
                             &lbf[spos+11*qdim], &lbf[spos+3*qdim], &lbf[spos+13*qdim], &lbf[spos+14*qdim],
                             &lbf[spos+16*qdim], &lbf[spos+15*qdim], &lbf[spos+18*qdim], &lbf[spos+17*qdim],
                             &lbf[spos+1*qdim], &lbf[spos+2*qdim], &lbf[spos+12*qdim], &lbf[spos+4*qdim],
                             &lbf[spos+5*qdim], &lbf[spos+7*qdim], &lbf[spos+6*qdim], &lbf[spos+9*qdim],
                             &lbf[spos+8*qdim]);
        break;
      case CEDR:
        fD3Q19VCESimpleZouHe(p0, -uwall[1], uwall[0], uwall[2], &force[0], &lbf[spos], &lbf[spos+11*qdim],
                             &lbf[spos+1*qdim], &lbf[spos+3*qdim], &lbf[spos+5*qdim], &lbf[spos+13*qdim],
                             &lbf[spos+18*qdim], &lbf[spos+17*qdim], &lbf[spos+6*qdim], &lbf[spos+7*qdim],
                             &lbf[spos+2*qdim], &lbf[spos+10*qdim], &lbf[spos+12*qdim], &lbf[spos+14*qdim],
                             &lbf[spos+4*qdim], &lbf[spos+9*qdim], &lbf[spos+8*qdim], &lbf[spos+15*qdim],
                             &lbf[spos+16*qdim]);
        break;
      case CETF:
        fD3Q19VCESimpleZouHe(p0, uwall[1], uwall[2], uwall[0], &force[0], &lbf[spos], &lbf[spos+2*qdim],
                             &lbf[spos+3*qdim], &lbf[spos+1*qdim], &lbf[spos+8*qdim], &lbf[spos+9*qdim],
                             &lbf[spos+4*qdim], &lbf[spos+14*qdim], &lbf[spos+6*qdim], &lbf[spos+16*qdim],
                             &lbf[spos+11*qdim], &lbf[spos+12*qdim], &lbf[spos+10*qdim], &lbf[spos+17*qdim],
                             &lbf[spos+18*qdim], &lbf[spos+13*qdim], &lbf[spos+5*qdim], &lbf[spos+15*qdim],
                             &lbf[spos+7*qdim]);
        break;
      case CELF:
        fD3Q19VCESimpleZouHe(p0, -uwall[0], uwall[2], uwall[1], &force[0], &lbf[spos], &lbf[spos+10*qdim],
                             &lbf[spos+3*qdim], &lbf[spos+2*qdim], &lbf[spos+16*qdim], &lbf[spos+15*qdim],
                             &lbf[spos+14*qdim], &lbf[spos+13*qdim], &lbf[spos+8*qdim], &lbf[spos+18*qdim],
                             &lbf[spos+1*qdim], &lbf[spos+12*qdim], &lbf[spos+11*qdim], &lbf[spos+7*qdim],
                             &lbf[spos+6*qdim], &lbf[spos+5*qdim], &lbf[spos+4*qdim], &lbf[spos+17*qdim],
                             &lbf[spos+9*qdim]);
        break;
      case CEDF:
        fD3Q19VCESimpleZouHe(p0, -uwall[1], uwall[2], uwall[0], &force[0], &lbf[spos], &lbf[spos+11*qdim],
                             &lbf[spos+3*qdim], &lbf[spos+1*qdim], &lbf[spos+18*qdim], &lbf[spos+17*qdim],
                             &lbf[spos+5*qdim], &lbf[spos+13*qdim], &lbf[spos+6*qdim], &lbf[spos+16*qdim],
                             &lbf[spos+2*qdim], &lbf[spos+12*qdim], &lbf[spos+10*qdim], &lbf[spos+9*qdim],
                             &lbf[spos+8*qdim], &lbf[spos+14*qdim], &lbf[spos+4*qdim], &lbf[spos+15*qdim],
                             &lbf[spos+7*qdim]);
        break;
      case CERF:
        fD3Q19VCESimpleZouHe(p0, uwall[0], uwall[2], uwall[1], &force[0], &lbf[spos], &lbf[spos+1*qdim],
                             &lbf[spos+3*qdim], &lbf[spos+2*qdim], &lbf[spos+6*qdim], &lbf[spos+7*qdim],
                             &lbf[spos+4*qdim], &lbf[spos+5*qdim], &lbf[spos+8*qdim], &lbf[spos+18*qdim],
                             &lbf[spos+10*qdim], &lbf[spos+12*qdim], &lbf[spos+11*qdim], &lbf[spos+15*qdim],
                             &lbf[spos+16*qdim], &lbf[spos+13*qdim], &lbf[spos+14*qdim], &lbf[spos+17*qdim],
                             &lbf[spos+9*qdim]);
        break;
      case CETB:
        fD3Q19VCESimpleZouHe(p0, uwall[1], -uwall[2], uwall[0], &force[0], &lbf[spos], &lbf[spos+2*qdim],
                             &lbf[spos+12*qdim], &lbf[spos+1*qdim], &lbf[spos+9*qdim], &lbf[spos+8*qdim],
                             &lbf[spos+4*qdim], &lbf[spos+14*qdim], &lbf[spos+7*qdim], &lbf[spos+15*qdim],
                             &lbf[spos+11*qdim], &lbf[spos+3*qdim], &lbf[spos+10*qdim], &lbf[spos+18*qdim],
                             &lbf[spos+17*qdim], &lbf[spos+13*qdim], &lbf[spos+5*qdim], &lbf[spos+16*qdim],
                             &lbf[spos+6*qdim]);
        break;
      case CELB:
        fD3Q19VCESimpleZouHe(p0, -uwall[0], -uwall[2], uwall[1], &force[0], &lbf[spos], &lbf[spos+10*qdim],
                             &lbf[spos+12*qdim], &lbf[spos+2*qdim], &lbf[spos+15*qdim], &lbf[spos+16*qdim],
                             &lbf[spos+14*qdim], &lbf[spos+13*qdim], &lbf[spos+9*qdim], &lbf[spos+17*qdim],
                             &lbf[spos+1*qdim], &lbf[spos+3*qdim], &lbf[spos+11*qdim], &lbf[spos+6*qdim],
                             &lbf[spos+7*qdim], &lbf[spos+5*qdim], &lbf[spos+4*qdim], &lbf[spos+18*qdim],
                             &lbf[spos+8*qdim]);
        break;
      case CEDB:
        fD3Q19VCESimpleZouHe(p0, -uwall[1], -uwall[2], uwall[0], &force[0], &lbf[spos], &lbf[spos+11*qdim],
                             &lbf[spos+12*qdim], &lbf[spos+1*qdim], &lbf[spos+17*qdim], &lbf[spos+18*qdim],
                             &lbf[spos+5*qdim], &lbf[spos+13*qdim], &lbf[spos+7*qdim], &lbf[spos+15*qdim],
                             &lbf[spos+2*qdim], &lbf[spos+3*qdim], &lbf[spos+10*qdim], &lbf[spos+8*qdim],
                             &lbf[spos+9*qdim], &lbf[spos+14*qdim], &lbf[spos+4*qdim], &lbf[spos+16*qdim],
                             &lbf[spos+6*qdim]);
        break;
      case CERB:
        fD3Q19VCESimpleZouHe(p0, uwall[0], -uwall[2], uwall[1], &force[0], &lbf[spos], &lbf[spos+1*qdim],
                             &lbf[spos+12*qdim], &lbf[spos+2*qdim], &lbf[spos+7*qdim], &lbf[spos+6*qdim],
                             &lbf[spos+4*qdim], &lbf[spos+5*qdim], &lbf[spos+9*qdim], &lbf[spos+17*qdim],
                             &lbf[spos+10*qdim], &lbf[spos+3*qdim], &lbf[spos+11*qdim], &lbf[spos+16*qdim],
                             &lbf[spos+15*qdim], &lbf[spos+13*qdim], &lbf[spos+14*qdim], &lbf[spos+18*qdim],
                             &lbf[spos+8*qdim]);
        break;
    }
  }
  else if(collide>11) {
    switch (prop) {
      case PST:
        fD3Q19PPSZouHe(p0, &force[0], &lbf[spos], &lbf[spos+1*qdim],
                       &lbf[spos+2*qdim], &lbf[spos+3*qdim], &lbf[spos+4*qdim], &lbf[spos+5*qdim],
                       &lbf[spos+6*qdim], &lbf[spos+7*qdim], &lbf[spos+8*qdim], &lbf[spos+9*qdim],
                       &lbf[spos+10*qdim], &lbf[spos+11*qdim], &lbf[spos+12*qdim], &lbf[spos+13*qdim],
                       &lbf[spos+14*qdim], &lbf[spos+15*qdim], &lbf[spos+16*qdim], &lbf[spos+17*qdim],
                       &lbf[spos+18*qdim], moment);
        uwall[1] += moment;
        break;
      case PSD:
        fD3Q19PPSZouHe(p0, &force[0], &lbf[spos], &lbf[spos+10*qdim],
                       &lbf[spos+11*qdim], &lbf[spos+12*qdim], &lbf[spos+13*qdim], &lbf[spos+14*qdim],
                       &lbf[spos+15*qdim], &lbf[spos+16*qdim], &lbf[spos+17*qdim], &lbf[spos+18*qdim],
                       &lbf[spos+1*qdim], &lbf[spos+2*qdim], &lbf[spos+3*qdim], &lbf[spos+4*qdim],
                       &lbf[spos+5*qdim], &lbf[spos+6*qdim], &lbf[spos+7*qdim], &lbf[spos+8*qdim],
                       &lbf[spos+9*qdim], moment);
        uwall[1] -= moment;
        break;
      case PSL:
        fD3Q19PPSZouHe(p0, &force[0], &lbf[spos], &lbf[spos+12*qdim],
                       &lbf[spos+10*qdim], &lbf[spos+11*qdim], &lbf[spos+15*qdim], &lbf[spos+7*qdim],
                       &lbf[spos+17*qdim], &lbf[spos+9*qdim], &lbf[spos+13*qdim], &lbf[spos+14*qdim],
                       &lbf[spos+3*qdim], &lbf[spos+1*qdim], &lbf[spos+2*qdim], &lbf[spos+6*qdim],
                       &lbf[spos+16*qdim], &lbf[spos+8*qdim], &lbf[spos+18*qdim], &lbf[spos+4*qdim],
                       &lbf[spos+5*qdim], moment);
        uwall[0] -= moment;
        break;
      case PSR:
        fD3Q19PPSZouHe(p0, &force[0], &lbf[spos], &lbf[spos+3*qdim],
                       &lbf[spos+1*qdim], &lbf[spos+2*qdim], &lbf[spos+6*qdim], &lbf[spos+16*qdim],
                       &lbf[spos+8*qdim], &lbf[spos+18*qdim], &lbf[spos+4*qdim], &lbf[spos+5*qdim],
                       &lbf[spos+12*qdim], &lbf[spos+10*qdim], &lbf[spos+11*qdim], &lbf[spos+15*qdim],
                       &lbf[spos+7*qdim], &lbf[spos+17*qdim], &lbf[spos+9*qdim], &lbf[spos+13*qdim],
                       &lbf[spos+14*qdim], moment);
        uwall[0] += moment;
        break;
      case PSF:
        fD3Q19PPSZouHe(p0, &force[0], &lbf[spos], &lbf[spos+11*qdim],
                       &lbf[spos+12*qdim], &lbf[spos+10*qdim], &lbf[spos+17*qdim], &lbf[spos+18*qdim],
                       &lbf[spos+13*qdim], &lbf[spos+5*qdim], &lbf[spos+15*qdim], &lbf[spos+7*qdim],
                       &lbf[spos+2*qdim], &lbf[spos+3*qdim], &lbf[spos+1*qdim], &lbf[spos+8*qdim],
                       &lbf[spos+9*qdim], &lbf[spos+4*qdim], &lbf[spos+14*qdim], &lbf[spos+6*qdim],
                       &lbf[spos+16*qdim], moment);
        uwall[2] -= moment;
        break;
      case PSB:
        fD3Q19PPSZouHe(p0, &force[0], &lbf[spos], &lbf[spos+2*qdim],
                       &lbf[spos+3*qdim], &lbf[spos+1*qdim], &lbf[spos+8*qdim], &lbf[spos+9*qdim],
                       &lbf[spos+4*qdim], &lbf[spos+14*qdim], &lbf[spos+6*qdim], &lbf[spos+16*qdim],
                       &lbf[spos+11*qdim], &lbf[spos+12*qdim], &lbf[spos+10*qdim], &lbf[spos+17*qdim],
                       &lbf[spos+18*qdim], &lbf[spos+13*qdim], &lbf[spos+5*qdim], &lbf[spos+15*qdim],
                       &lbf[spos+7*qdim], moment);
        uwall[2] += moment;
        break;
      case CCTRB:
        fD3Q19VCCCLBESimpleZouHe(p0, uwall[0], uwall[1], -uwall[2], &force[0], &lbf[spos], &lbf[spos+1*qdim],
                                 &lbf[spos+2*qdim], &lbf[spos+12*qdim], &lbf[spos+4*qdim], &lbf[spos+5*qdim],
                                 &lbf[spos+7*qdim], &lbf[spos+6*qdim], &lbf[spos+9*qdim], &lbf[spos+8*qdim],
                                 &lbf[spos+10*qdim], &lbf[spos+11*qdim], &lbf[spos+3*qdim], &lbf[spos+13*qdim],
                                 &lbf[spos+14*qdim], &lbf[spos+16*qdim], &lbf[spos+15*qdim], &lbf[spos+18*qdim],
                                 &lbf[spos+17*qdim]);
        break;
      case CCTLB:
        fD3Q19VCCCLBESimpleZouHe(p0, -uwall[0], uwall[1], -uwall[2], &force[0], &lbf[spos], &lbf[spos+10*qdim],
                                 &lbf[spos+2*qdim], &lbf[spos+12*qdim], &lbf[spos+14*qdim], &lbf[spos+13*qdim],
                                 &lbf[spos+15*qdim], &lbf[spos+16*qdim], &lbf[spos+9*qdim], &lbf[spos+8*qdim],
                                 &lbf[spos+1*qdim], &lbf[spos+11*qdim], &lbf[spos+3*qdim], &lbf[spos+5*qdim],
                                 &lbf[spos+4*qdim], &lbf[spos+6*qdim], &lbf[spos+7*qdim], &lbf[spos+18*qdim],
                                 &lbf[spos+17*qdim]);
        break;
      case CCDLB:
        fD3Q19VCCCLBESimpleZouHe(p0, -uwall[0], -uwall[1], -uwall[2], &force[0], &lbf[spos], &lbf[spos+10*qdim],
                                 &lbf[spos+11*qdim], &lbf[spos+12*qdim], &lbf[spos+13*qdim], &lbf[spos+14*qdim],
                                 &lbf[spos+15*qdim], &lbf[spos+16*qdim], &lbf[spos+17*qdim], &lbf[spos+18*qdim],
                                 &lbf[spos+1*qdim], &lbf[spos+2*qdim], &lbf[spos+3*qdim], &lbf[spos+4*qdim],
                                 &lbf[spos+5*qdim], &lbf[spos+6*qdim], &lbf[spos+7*qdim], &lbf[spos+8*qdim],
                                 &lbf[spos+9*qdim]);
        break;
      case CCDRB:
        fD3Q19VCCCLBESimpleZouHe(p0, uwall[0], -uwall[1], -uwall[2], &force[0], &lbf[spos], &lbf[spos+1*qdim],
                                 &lbf[spos+11*qdim], &lbf[spos+12*qdim], &lbf[spos+5*qdim], &lbf[spos+4*qdim],
                                 &lbf[spos+7*qdim], &lbf[spos+6*qdim], &lbf[spos+17*qdim], &lbf[spos+18*qdim],
                                 &lbf[spos+10*qdim], &lbf[spos+2*qdim], &lbf[spos+3*qdim], &lbf[spos+14*qdim],
                                 &lbf[spos+13*qdim], &lbf[spos+16*qdim], &lbf[spos+15*qdim], &lbf[spos+8*qdim],
                                 &lbf[spos+9*qdim]);
        break;
      case CCTRF:
        fD3Q19VCCCLBESimpleZouHe(p0, uwall[0], uwall[1], uwall[2], &force[0], &lbf[spos], &lbf[spos+1*qdim],
                                 &lbf[spos+2*qdim], &lbf[spos+3*qdim], &lbf[spos+4*qdim], &lbf[spos+5*qdim],
                                 &lbf[spos+6*qdim], &lbf[spos+7*qdim], &lbf[spos+8*qdim], &lbf[spos+9*qdim],
                                 &lbf[spos+10*qdim], &lbf[spos+11*qdim], &lbf[spos+12*qdim], &lbf[spos+13*qdim],
                                 &lbf[spos+14*qdim], &lbf[spos+15*qdim], &lbf[spos+16*qdim], &lbf[spos+17*qdim],
                                 &lbf[spos+18*qdim]);
        break;
      case CCTLF:
        fD3Q19VCCCLBESimpleZouHe(p0, -uwall[0], uwall[1], uwall[2], &force[0], &lbf[spos], &lbf[spos+10*qdim],
                                 &lbf[spos+2*qdim], &lbf[spos+3*qdim], &lbf[spos+14*qdim], &lbf[spos+13*qdim],
                                 &lbf[spos+16*qdim], &lbf[spos+15*qdim], &lbf[spos+8*qdim], &lbf[spos+9*qdim],
                                 &lbf[spos+1*qdim], &lbf[spos+11*qdim], &lbf[spos+12*qdim], &lbf[spos+5*qdim],
                                 &lbf[spos+4*qdim], &lbf[spos+7*qdim], &lbf[spos+6*qdim], &lbf[spos+17*qdim],
                                 &lbf[spos+18*qdim]);
        break;
      case CCDLF:
        fD3Q19VCCCLBESimpleZouHe(p0, -uwall[0], -uwall[1], uwall[2], &force[0], &lbf[spos], &lbf[spos+10*qdim],
                                 &lbf[spos+11*qdim], &lbf[spos+3*qdim], &lbf[spos+13*qdim], &lbf[spos+14*qdim],
                                 &lbf[spos+16*qdim], &lbf[spos+15*qdim], &lbf[spos+18*qdim], &lbf[spos+17*qdim],
                                 &lbf[spos+1*qdim], &lbf[spos+2*qdim], &lbf[spos+12*qdim], &lbf[spos+4*qdim],
                                 &lbf[spos+5*qdim], &lbf[spos+7*qdim], &lbf[spos+6*qdim], &lbf[spos+9*qdim],
                                 &lbf[spos+8*qdim]);
        break;
      case CCDRF:
        fD3Q19VCCCLBESimpleZouHe(p0, uwall[0], -uwall[1], uwall[2], &force[0], &lbf[spos], &lbf[spos+1*qdim],
                                 &lbf[spos+11*qdim], &lbf[spos+3*qdim], &lbf[spos+5*qdim], &lbf[spos+4*qdim],
                                 &lbf[spos+6*qdim], &lbf[spos+7*qdim], &lbf[spos+18*qdim], &lbf[spos+17*qdim],
                                 &lbf[spos+10*qdim], &lbf[spos+2*qdim], &lbf[spos+12*qdim], &lbf[spos+14*qdim],
                                 &lbf[spos+13*qdim], &lbf[spos+15*qdim], &lbf[spos+16*qdim], &lbf[spos+9*qdim],
                                 &lbf[spos+8*qdim]);
        break;
      case CETR:
        fD3Q19VCECLBESimpleZouHe(p0, uwall[0], uwall[1], uwall[2], &force[0], &lbf[spos], &lbf[spos+1*qdim],
                                 &lbf[spos+2*qdim], &lbf[spos+3*qdim], &lbf[spos+4*qdim], &lbf[spos+5*qdim],
                                 &lbf[spos+6*qdim], &lbf[spos+7*qdim], &lbf[spos+8*qdim], &lbf[spos+9*qdim],
                                 &lbf[spos+10*qdim], &lbf[spos+11*qdim], &lbf[spos+12*qdim], &lbf[spos+13*qdim],
                                 &lbf[spos+14*qdim], &lbf[spos+15*qdim], &lbf[spos+16*qdim], &lbf[spos+17*qdim],
                                 &lbf[spos+18*qdim]);
        break;
      case CETL:
        fD3Q19VCECLBESimpleZouHe(p0, uwall[1], -uwall[0], uwall[2], &force[0], &lbf[spos], &lbf[spos+2*qdim],
                                 &lbf[spos+10*qdim], &lbf[spos+3*qdim], &lbf[spos+14*qdim], &lbf[spos+4*qdim],
                                 &lbf[spos+8*qdim], &lbf[spos+9*qdim], &lbf[spos+16*qdim], &lbf[spos+15*qdim],
                                 &lbf[spos+11*qdim], &lbf[spos+1*qdim], &lbf[spos+12*qdim], &lbf[spos+5*qdim],
                                 &lbf[spos+13*qdim], &lbf[spos+17*qdim], &lbf[spos+18*qdim], &lbf[spos+7*qdim],
                                 &lbf[spos+6*qdim]);
        break;
      case CEDL:
        fD3Q19VCECLBESimpleZouHe(p0, -uwall[0], -uwall[1], uwall[2], &force[0], &lbf[spos], &lbf[spos+10*qdim],
                                 &lbf[spos+11*qdim], &lbf[spos+3*qdim], &lbf[spos+13*qdim], &lbf[spos+14*qdim],
                                 &lbf[spos+16*qdim], &lbf[spos+15*qdim], &lbf[spos+18*qdim], &lbf[spos+17*qdim],
                                 &lbf[spos+1*qdim], &lbf[spos+2*qdim], &lbf[spos+12*qdim], &lbf[spos+4*qdim],
                                 &lbf[spos+5*qdim], &lbf[spos+7*qdim], &lbf[spos+6*qdim], &lbf[spos+9*qdim],
                                 &lbf[spos+8*qdim]);
        break;
      case CEDR:
        fD3Q19VCECLBESimpleZouHe(p0, -uwall[1], uwall[0], uwall[2], &force[0], &lbf[spos], &lbf[spos+11*qdim],
                                 &lbf[spos+1*qdim], &lbf[spos+3*qdim], &lbf[spos+5*qdim], &lbf[spos+13*qdim],
                                 &lbf[spos+18*qdim], &lbf[spos+17*qdim], &lbf[spos+6*qdim], &lbf[spos+7*qdim],
                                 &lbf[spos+2*qdim], &lbf[spos+10*qdim], &lbf[spos+12*qdim], &lbf[spos+14*qdim],
                                 &lbf[spos+4*qdim], &lbf[spos+9*qdim], &lbf[spos+8*qdim], &lbf[spos+15*qdim],
                                 &lbf[spos+16*qdim]);
        break;
      case CETF:
        fD3Q19VCECLBESimpleZouHe(p0, uwall[1], uwall[2], uwall[0], &force[0], &lbf[spos], &lbf[spos+2*qdim],
                                 &lbf[spos+3*qdim], &lbf[spos+1*qdim], &lbf[spos+8*qdim], &lbf[spos+9*qdim],
                                 &lbf[spos+4*qdim], &lbf[spos+14*qdim], &lbf[spos+6*qdim], &lbf[spos+16*qdim],
                                 &lbf[spos+11*qdim], &lbf[spos+12*qdim], &lbf[spos+10*qdim], &lbf[spos+17*qdim],
                                 &lbf[spos+18*qdim], &lbf[spos+13*qdim], &lbf[spos+5*qdim], &lbf[spos+15*qdim],
                                 &lbf[spos+7*qdim]);
        break;
      case CELF:
        fD3Q19VCECLBESimpleZouHe(p0, -uwall[0], uwall[2], uwall[1], &force[0], &lbf[spos], &lbf[spos+10*qdim],
                                 &lbf[spos+3*qdim], &lbf[spos+2*qdim], &lbf[spos+16*qdim], &lbf[spos+15*qdim],
                                 &lbf[spos+14*qdim], &lbf[spos+13*qdim], &lbf[spos+8*qdim], &lbf[spos+18*qdim],
                                 &lbf[spos+1*qdim], &lbf[spos+12*qdim], &lbf[spos+11*qdim], &lbf[spos+7*qdim],
                                 &lbf[spos+6*qdim], &lbf[spos+5*qdim], &lbf[spos+4*qdim], &lbf[spos+17*qdim],
                                 &lbf[spos+9*qdim]);
        break;
      case CEDF:
        fD3Q19VCECLBESimpleZouHe(p0, -uwall[1], uwall[2], uwall[0], &force[0], &lbf[spos], &lbf[spos+11*qdim],
                                 &lbf[spos+3*qdim], &lbf[spos+1*qdim], &lbf[spos+18*qdim], &lbf[spos+17*qdim],
                                 &lbf[spos+5*qdim], &lbf[spos+13*qdim], &lbf[spos+6*qdim], &lbf[spos+16*qdim],
                                 &lbf[spos+2*qdim], &lbf[spos+12*qdim], &lbf[spos+10*qdim], &lbf[spos+9*qdim],
                                 &lbf[spos+8*qdim], &lbf[spos+14*qdim], &lbf[spos+4*qdim], &lbf[spos+15*qdim],
                                 &lbf[spos+7*qdim]);
        break;
      case CERF:
        fD3Q19VCECLBESimpleZouHe(p0, uwall[0], uwall[2], uwall[1], &force[0], &lbf[spos], &lbf[spos+1*qdim],
                                 &lbf[spos+3*qdim], &lbf[spos+2*qdim], &lbf[spos+6*qdim], &lbf[spos+7*qdim],
                                 &lbf[spos+4*qdim], &lbf[spos+5*qdim], &lbf[spos+8*qdim], &lbf[spos+18*qdim],
                                 &lbf[spos+10*qdim], &lbf[spos+12*qdim], &lbf[spos+11*qdim], &lbf[spos+15*qdim],
                                 &lbf[spos+16*qdim], &lbf[spos+13*qdim], &lbf[spos+14*qdim], &lbf[spos+17*qdim],
                                 &lbf[spos+9*qdim]);
        break;
      case CETB:
        fD3Q19VCECLBESimpleZouHe(p0, uwall[1], -uwall[2], uwall[0], &force[0], &lbf[spos], &lbf[spos+2*qdim],
                                 &lbf[spos+12*qdim], &lbf[spos+1*qdim], &lbf[spos+9*qdim], &lbf[spos+8*qdim],
                                 &lbf[spos+4*qdim], &lbf[spos+14*qdim], &lbf[spos+7*qdim], &lbf[spos+15*qdim],
                                 &lbf[spos+11*qdim], &lbf[spos+3*qdim], &lbf[spos+10*qdim], &lbf[spos+18*qdim],
                                 &lbf[spos+17*qdim], &lbf[spos+13*qdim], &lbf[spos+5*qdim], &lbf[spos+16*qdim],
                                 &lbf[spos+6*qdim]);
        break;
      case CELB:
        fD3Q19VCECLBESimpleZouHe(p0, -uwall[0], -uwall[2], uwall[1], &force[0], &lbf[spos], &lbf[spos+10*qdim],
                                 &lbf[spos+12*qdim], &lbf[spos+2*qdim], &lbf[spos+15*qdim], &lbf[spos+16*qdim],
                                 &lbf[spos+14*qdim], &lbf[spos+13*qdim], &lbf[spos+9*qdim], &lbf[spos+17*qdim],
                                 &lbf[spos+1*qdim], &lbf[spos+3*qdim], &lbf[spos+11*qdim], &lbf[spos+6*qdim],
                                 &lbf[spos+7*qdim], &lbf[spos+5*qdim], &lbf[spos+4*qdim], &lbf[spos+18*qdim],
                                 &lbf[spos+8*qdim]);
        break;
      case CEDB:
        fD3Q19VCECLBESimpleZouHe(p0, -uwall[1], -uwall[2], uwall[0], &force[0], &lbf[spos], &lbf[spos+11*qdim],
                                 &lbf[spos+12*qdim], &lbf[spos+1*qdim], &lbf[spos+17*qdim], &lbf[spos+18*qdim],
                                 &lbf[spos+5*qdim], &lbf[spos+13*qdim], &lbf[spos+7*qdim], &lbf[spos+15*qdim],
                                 &lbf[spos+2*qdim], &lbf[spos+3*qdim], &lbf[spos+10*qdim], &lbf[spos+8*qdim],
                                 &lbf[spos+9*qdim], &lbf[spos+14*qdim], &lbf[spos+4*qdim], &lbf[spos+16*qdim],
                                 &lbf[spos+6*qdim]);
        break;
      case CERB:
        fD3Q19VCECLBESimpleZouHe(p0, uwall[0], -uwall[2], uwall[1], &force[0], &lbf[spos], &lbf[spos+1*qdim],
                                 &lbf[spos+12*qdim], &lbf[spos+2*qdim], &lbf[spos+7*qdim], &lbf[spos+6*qdim],
                                 &lbf[spos+4*qdim], &lbf[spos+5*qdim], &lbf[spos+9*qdim], &lbf[spos+17*qdim],
                                 &lbf[spos+10*qdim], &lbf[spos+3*qdim], &lbf[spos+11*qdim], &lbf[spos+16*qdim],
                                 &lbf[spos+15*qdim], &lbf[spos+13*qdim], &lbf[spos+14*qdim], &lbf[spos+18*qdim],
                                 &lbf[spos+8*qdim]);
        break;
    }
  }
  else {
    switch (prop) {
      case PST:
        fD3Q19PPSZouHe(p0, &force[0], &lbf[spos], &lbf[spos+1*qdim],
                       &lbf[spos+2*qdim], &lbf[spos+3*qdim], &lbf[spos+4*qdim], &lbf[spos+5*qdim],
                       &lbf[spos+6*qdim], &lbf[spos+7*qdim], &lbf[spos+8*qdim], &lbf[spos+9*qdim],
                       &lbf[spos+10*qdim], &lbf[spos+11*qdim], &lbf[spos+12*qdim], &lbf[spos+13*qdim],
                       &lbf[spos+14*qdim], &lbf[spos+15*qdim], &lbf[spos+16*qdim], &lbf[spos+17*qdim],
                       &lbf[spos+18*qdim], moment);
        uwall[1] += moment;
        break;
      case PSD:
        fD3Q19PPSZouHe(p0, &force[0], &lbf[spos], &lbf[spos+10*qdim],
                       &lbf[spos+11*qdim], &lbf[spos+12*qdim], &lbf[spos+13*qdim], &lbf[spos+14*qdim],
                       &lbf[spos+15*qdim], &lbf[spos+16*qdim], &lbf[spos+17*qdim], &lbf[spos+18*qdim],
                       &lbf[spos+1*qdim], &lbf[spos+2*qdim], &lbf[spos+3*qdim], &lbf[spos+4*qdim],
                       &lbf[spos+5*qdim], &lbf[spos+6*qdim], &lbf[spos+7*qdim], &lbf[spos+8*qdim],
                       &lbf[spos+9*qdim], moment);
        uwall[1] -= moment;
        break;
      case PSL:
        fD3Q19PPSZouHe(p0, &force[0], &lbf[spos], &lbf[spos+12*qdim],
                       &lbf[spos+10*qdim], &lbf[spos+11*qdim], &lbf[spos+15*qdim], &lbf[spos+7*qdim],
                       &lbf[spos+17*qdim], &lbf[spos+9*qdim], &lbf[spos+13*qdim], &lbf[spos+14*qdim],
                       &lbf[spos+3*qdim], &lbf[spos+1*qdim], &lbf[spos+2*qdim], &lbf[spos+6*qdim],
                       &lbf[spos+16*qdim], &lbf[spos+8*qdim], &lbf[spos+18*qdim], &lbf[spos+4*qdim],
                       &lbf[spos+5*qdim], moment);
        uwall[0] -= moment;
        break;
      case PSR:
        fD3Q19PPSZouHe(p0, &force[0], &lbf[spos], &lbf[spos+3*qdim],
                       &lbf[spos+1*qdim], &lbf[spos+2*qdim], &lbf[spos+6*qdim], &lbf[spos+16*qdim],
                       &lbf[spos+8*qdim], &lbf[spos+18*qdim], &lbf[spos+4*qdim], &lbf[spos+5*qdim],
                       &lbf[spos+12*qdim], &lbf[spos+10*qdim], &lbf[spos+11*qdim], &lbf[spos+15*qdim],
                       &lbf[spos+7*qdim], &lbf[spos+17*qdim], &lbf[spos+9*qdim], &lbf[spos+13*qdim],
                       &lbf[spos+14*qdim], moment);
        uwall[0] += moment;
        break;
      case PSF:
        fD3Q19PPSZouHe(p0, &force[0], &lbf[spos], &lbf[spos+11*qdim],
                       &lbf[spos+12*qdim], &lbf[spos+10*qdim], &lbf[spos+17*qdim], &lbf[spos+18*qdim],
                       &lbf[spos+13*qdim], &lbf[spos+5*qdim], &lbf[spos+15*qdim], &lbf[spos+7*qdim],
                       &lbf[spos+2*qdim], &lbf[spos+3*qdim], &lbf[spos+1*qdim], &lbf[spos+8*qdim],
                       &lbf[spos+9*qdim], &lbf[spos+4*qdim], &lbf[spos+14*qdim], &lbf[spos+6*qdim],
                       &lbf[spos+16*qdim], moment);
        uwall[2] -= moment;
        break;
      case PSB:
        fD3Q19PPSZouHe(p0, &force[0], &lbf[spos], &lbf[spos+2*qdim],
                       &lbf[spos+3*qdim], &lbf[spos+1*qdim], &lbf[spos+8*qdim], &lbf[spos+9*qdim],
                       &lbf[spos+4*qdim], &lbf[spos+14*qdim], &lbf[spos+6*qdim], &lbf[spos+16*qdim],
                       &lbf[spos+11*qdim], &lbf[spos+12*qdim], &lbf[spos+10*qdim], &lbf[spos+17*qdim],
                       &lbf[spos+18*qdim], &lbf[spos+13*qdim], &lbf[spos+5*qdim], &lbf[spos+15*qdim],
                       &lbf[spos+7*qdim], moment);
        uwall[2] += moment;
        break;
      case CCTRB:
        fD3Q19VCCSimpleZouHe(p0, uwall[0], uwall[1], -uwall[2], &force[0], &lbf[spos], &lbf[spos+1*qdim],
                             &lbf[spos+2*qdim], &lbf[spos+12*qdim], &lbf[spos+4*qdim], &lbf[spos+5*qdim],
                             &lbf[spos+7*qdim], &lbf[spos+6*qdim], &lbf[spos+9*qdim], &lbf[spos+8*qdim],
                             &lbf[spos+10*qdim], &lbf[spos+11*qdim], &lbf[spos+3*qdim], &lbf[spos+13*qdim],
                             &lbf[spos+14*qdim], &lbf[spos+16*qdim], &lbf[spos+15*qdim], &lbf[spos+18*qdim],
                             &lbf[spos+17*qdim]);
        break;
      case CCTLB:
        fD3Q19VCCSimpleZouHe(p0, -uwall[0], uwall[1], -uwall[2], &force[0], &lbf[spos], &lbf[spos+10*qdim],
                             &lbf[spos+2*qdim], &lbf[spos+12*qdim], &lbf[spos+14*qdim], &lbf[spos+13*qdim],
                             &lbf[spos+15*qdim], &lbf[spos+16*qdim], &lbf[spos+9*qdim], &lbf[spos+8*qdim],
                             &lbf[spos+1*qdim], &lbf[spos+11*qdim], &lbf[spos+3*qdim], &lbf[spos+5*qdim],
                             &lbf[spos+4*qdim], &lbf[spos+6*qdim], &lbf[spos+7*qdim], &lbf[spos+18*qdim],
                             &lbf[spos+17*qdim]);
        break;
      case CCDLB:
        fD3Q19VCCSimpleZouHe(p0, -uwall[0], -uwall[1], -uwall[2], &force[0], &lbf[spos], &lbf[spos+10*qdim],
                             &lbf[spos+11*qdim], &lbf[spos+12*qdim], &lbf[spos+13*qdim], &lbf[spos+14*qdim],
                             &lbf[spos+15*qdim], &lbf[spos+16*qdim], &lbf[spos+17*qdim], &lbf[spos+18*qdim],
                             &lbf[spos+1*qdim], &lbf[spos+2*qdim], &lbf[spos+3*qdim], &lbf[spos+4*qdim],
                             &lbf[spos+5*qdim], &lbf[spos+6*qdim], &lbf[spos+7*qdim], &lbf[spos+8*qdim],
                             &lbf[spos+9*qdim]);
        break;
      case CCDRB:
        fD3Q19VCCSimpleZouHe(p0, uwall[0], -uwall[1], -uwall[2], &force[0], &lbf[spos], &lbf[spos+1*qdim],
                             &lbf[spos+11*qdim], &lbf[spos+12*qdim], &lbf[spos+5*qdim], &lbf[spos+4*qdim],
                             &lbf[spos+7*qdim], &lbf[spos+6*qdim], &lbf[spos+17*qdim], &lbf[spos+18*qdim],
                             &lbf[spos+10*qdim], &lbf[spos+2*qdim], &lbf[spos+3*qdim], &lbf[spos+14*qdim],
                             &lbf[spos+13*qdim], &lbf[spos+16*qdim], &lbf[spos+15*qdim], &lbf[spos+8*qdim],
                             &lbf[spos+9*qdim]);
        break;
      case CCTRF:
        fD3Q19VCCSimpleZouHe(p0, uwall[0], uwall[1], uwall[2], &force[0], &lbf[spos], &lbf[spos+1*qdim],
                             &lbf[spos+2*qdim], &lbf[spos+3*qdim], &lbf[spos+4*qdim], &lbf[spos+5*qdim],
                             &lbf[spos+6*qdim], &lbf[spos+7*qdim], &lbf[spos+8*qdim], &lbf[spos+9*qdim],
                             &lbf[spos+10*qdim], &lbf[spos+11*qdim], &lbf[spos+12*qdim], &lbf[spos+13*qdim],
                             &lbf[spos+14*qdim], &lbf[spos+15*qdim], &lbf[spos+16*qdim], &lbf[spos+17*qdim],
                             &lbf[spos+18*qdim]);
        break;
      case CCTLF:
        fD3Q19VCCSimpleZouHe(p0, -uwall[0], uwall[1], uwall[2], &force[0], &lbf[spos], &lbf[spos+10*qdim],
                             &lbf[spos+2*qdim], &lbf[spos+3*qdim], &lbf[spos+14*qdim], &lbf[spos+13*qdim],
                             &lbf[spos+16*qdim], &lbf[spos+15*qdim], &lbf[spos+8*qdim], &lbf[spos+9*qdim],
                             &lbf[spos+1*qdim], &lbf[spos+11*qdim], &lbf[spos+12*qdim], &lbf[spos+5*qdim],
                             &lbf[spos+4*qdim], &lbf[spos+7*qdim], &lbf[spos+6*qdim], &lbf[spos+17*qdim],
                             &lbf[spos+18*qdim]);
        break;
      case CCDLF:
        fD3Q19VCCSimpleZouHe(p0, -uwall[0], -uwall[1], uwall[2], &force[0], &lbf[spos], &lbf[spos+10*qdim],
                             &lbf[spos+11*qdim], &lbf[spos+3*qdim], &lbf[spos+13*qdim], &lbf[spos+14*qdim],
                             &lbf[spos+16*qdim], &lbf[spos+15*qdim], &lbf[spos+18*qdim], &lbf[spos+17*qdim],
                             &lbf[spos+1*qdim], &lbf[spos+2*qdim], &lbf[spos+12*qdim], &lbf[spos+4*qdim],
                             &lbf[spos+5*qdim], &lbf[spos+7*qdim], &lbf[spos+6*qdim], &lbf[spos+9*qdim],
                             &lbf[spos+8*qdim]);
        break;
      case CCDRF:
        fD3Q19VCCSimpleZouHe(p0, uwall[0], -uwall[1], uwall[2], &force[0], &lbf[spos], &lbf[spos+1*qdim],
                             &lbf[spos+11*qdim], &lbf[spos+3*qdim], &lbf[spos+5*qdim], &lbf[spos+4*qdim],
                             &lbf[spos+6*qdim], &lbf[spos+7*qdim], &lbf[spos+18*qdim], &lbf[spos+17*qdim],
                             &lbf[spos+10*qdim], &lbf[spos+2*qdim], &lbf[spos+12*qdim], &lbf[spos+14*qdim],
                             &lbf[spos+13*qdim], &lbf[spos+15*qdim], &lbf[spos+16*qdim], &lbf[spos+9*qdim],
                             &lbf[spos+8*qdim]);
        break;
      case CETR:
        fD3Q19VCESimpleZouHe(p0, uwall[0], uwall[1], uwall[2], &force[0], &lbf[spos], &lbf[spos+1*qdim],
                             &lbf[spos+2*qdim], &lbf[spos+3*qdim], &lbf[spos+4*qdim], &lbf[spos+5*qdim],
                             &lbf[spos+6*qdim], &lbf[spos+7*qdim], &lbf[spos+8*qdim], &lbf[spos+9*qdim],
                             &lbf[spos+10*qdim], &lbf[spos+11*qdim], &lbf[spos+12*qdim], &lbf[spos+13*qdim],
                             &lbf[spos+14*qdim], &lbf[spos+15*qdim], &lbf[spos+16*qdim], &lbf[spos+17*qdim],
                             &lbf[spos+18*qdim]);
        break;
      case CETL:
        fD3Q19VCESimpleZouHe(p0, uwall[1], -uwall[0], uwall[2], &force[0], &lbf[spos], &lbf[spos+2*qdim],
                             &lbf[spos+10*qdim], &lbf[spos+3*qdim], &lbf[spos+14*qdim], &lbf[spos+4*qdim],
                             &lbf[spos+8*qdim], &lbf[spos+9*qdim], &lbf[spos+16*qdim], &lbf[spos+15*qdim],
                             &lbf[spos+11*qdim], &lbf[spos+1*qdim], &lbf[spos+12*qdim], &lbf[spos+5*qdim],
                             &lbf[spos+13*qdim], &lbf[spos+17*qdim], &lbf[spos+18*qdim], &lbf[spos+7*qdim],
                             &lbf[spos+6*qdim]);
        break;
      case CEDL:
        fD3Q19VCESimpleZouHe(p0, -uwall[0], -uwall[1], uwall[2], &force[0], &lbf[spos], &lbf[spos+10*qdim],
                             &lbf[spos+11*qdim], &lbf[spos+3*qdim], &lbf[spos+13*qdim], &lbf[spos+14*qdim],
                             &lbf[spos+16*qdim], &lbf[spos+15*qdim], &lbf[spos+18*qdim], &lbf[spos+17*qdim],
                             &lbf[spos+1*qdim], &lbf[spos+2*qdim], &lbf[spos+12*qdim], &lbf[spos+4*qdim],
                             &lbf[spos+5*qdim], &lbf[spos+7*qdim], &lbf[spos+6*qdim], &lbf[spos+9*qdim],
                             &lbf[spos+8*qdim]);
        break;
      case CEDR:
        fD3Q19VCESimpleZouHe(p0, -uwall[1], uwall[0], uwall[2], &force[0], &lbf[spos], &lbf[spos+11*qdim],
                             &lbf[spos+1*qdim], &lbf[spos+3*qdim], &lbf[spos+5*qdim], &lbf[spos+13*qdim],
                             &lbf[spos+18*qdim], &lbf[spos+17*qdim], &lbf[spos+6*qdim], &lbf[spos+7*qdim],
                             &lbf[spos+2*qdim], &lbf[spos+10*qdim], &lbf[spos+12*qdim], &lbf[spos+14*qdim],
                             &lbf[spos+4*qdim], &lbf[spos+9*qdim], &lbf[spos+8*qdim], &lbf[spos+15*qdim],
                             &lbf[spos+16*qdim]);
        break;
      case CETF:
        fD3Q19VCESimpleZouHe(p0, uwall[1], uwall[2], uwall[0], &force[0], &lbf[spos], &lbf[spos+2*qdim],
                             &lbf[spos+3*qdim], &lbf[spos+1*qdim], &lbf[spos+8*qdim], &lbf[spos+9*qdim],
                             &lbf[spos+4*qdim], &lbf[spos+14*qdim], &lbf[spos+6*qdim], &lbf[spos+16*qdim],
                             &lbf[spos+11*qdim], &lbf[spos+12*qdim], &lbf[spos+10*qdim], &lbf[spos+17*qdim],
                             &lbf[spos+18*qdim], &lbf[spos+13*qdim], &lbf[spos+5*qdim], &lbf[spos+15*qdim],
                             &lbf[spos+7*qdim]);
        break;
      case CELF:
        fD3Q19VCESimpleZouHe(p0, -uwall[0], uwall[2], uwall[1], &force[0], &lbf[spos], &lbf[spos+10*qdim],
                             &lbf[spos+3*qdim], &lbf[spos+2*qdim], &lbf[spos+16*qdim], &lbf[spos+15*qdim],
                             &lbf[spos+14*qdim], &lbf[spos+13*qdim], &lbf[spos+8*qdim], &lbf[spos+18*qdim],
                             &lbf[spos+1*qdim], &lbf[spos+12*qdim], &lbf[spos+11*qdim], &lbf[spos+7*qdim],
                             &lbf[spos+6*qdim], &lbf[spos+5*qdim], &lbf[spos+4*qdim], &lbf[spos+17*qdim],
                             &lbf[spos+9*qdim]);
        break;
      case CEDF:
        fD3Q19VCESimpleZouHe(p0, -uwall[1], uwall[2], uwall[0], &force[0], &lbf[spos], &lbf[spos+11*qdim],
                             &lbf[spos+3*qdim], &lbf[spos+1*qdim], &lbf[spos+18*qdim], &lbf[spos+17*qdim],
                             &lbf[spos+5*qdim], &lbf[spos+13*qdim], &lbf[spos+6*qdim], &lbf[spos+16*qdim],
                             &lbf[spos+2*qdim], &lbf[spos+12*qdim], &lbf[spos+10*qdim], &lbf[spos+9*qdim],
                             &lbf[spos+8*qdim], &lbf[spos+14*qdim], &lbf[spos+4*qdim], &lbf[spos+15*qdim],
                             &lbf[spos+7*qdim]);
        break;
      case CERF:
        fD3Q19VCESimpleZouHe(p0, uwall[0], uwall[2], uwall[1], &force[0], &lbf[spos], &lbf[spos+1*qdim],
                             &lbf[spos+3*qdim], &lbf[spos+2*qdim], &lbf[spos+6*qdim], &lbf[spos+7*qdim],
                             &lbf[spos+4*qdim], &lbf[spos+5*qdim], &lbf[spos+8*qdim], &lbf[spos+18*qdim],
                             &lbf[spos+10*qdim], &lbf[spos+12*qdim], &lbf[spos+11*qdim], &lbf[spos+15*qdim],
                             &lbf[spos+16*qdim], &lbf[spos+13*qdim], &lbf[spos+14*qdim], &lbf[spos+17*qdim],
                             &lbf[spos+9*qdim]);
        break;
      case CETB:
        fD3Q19VCESimpleZouHe(p0, uwall[1], -uwall[2], uwall[0], &force[0], &lbf[spos], &lbf[spos+2*qdim],
                             &lbf[spos+12*qdim], &lbf[spos+1*qdim], &lbf[spos+9*qdim], &lbf[spos+8*qdim],
                             &lbf[spos+4*qdim], &lbf[spos+14*qdim], &lbf[spos+7*qdim], &lbf[spos+15*qdim],
                             &lbf[spos+11*qdim], &lbf[spos+3*qdim], &lbf[spos+10*qdim], &lbf[spos+18*qdim],
                             &lbf[spos+17*qdim], &lbf[spos+13*qdim], &lbf[spos+5*qdim], &lbf[spos+16*qdim],
                             &lbf[spos+6*qdim]);
        break;
      case CELB:
        fD3Q19VCESimpleZouHe(p0, -uwall[0], -uwall[2], uwall[1], &force[0], &lbf[spos], &lbf[spos+10*qdim],
                             &lbf[spos+12*qdim], &lbf[spos+2*qdim], &lbf[spos+15*qdim], &lbf[spos+16*qdim],
                             &lbf[spos+14*qdim], &lbf[spos+13*qdim], &lbf[spos+9*qdim], &lbf[spos+17*qdim],
                             &lbf[spos+1*qdim], &lbf[spos+3*qdim], &lbf[spos+11*qdim], &lbf[spos+6*qdim],
                             &lbf[spos+7*qdim], &lbf[spos+5*qdim], &lbf[spos+4*qdim], &lbf[spos+18*qdim],
                             &lbf[spos+8*qdim]);
        break;
      case CEDB:
        fD3Q19VCESimpleZouHe(p0, -uwall[1], -uwall[2], uwall[0], &force[0], &lbf[spos], &lbf[spos+11*qdim],
                             &lbf[spos+12*qdim], &lbf[spos+1*qdim], &lbf[spos+17*qdim], &lbf[spos+18*qdim],
                             &lbf[spos+5*qdim], &lbf[spos+13*qdim], &lbf[spos+7*qdim], &lbf[spos+15*qdim],
                             &lbf[spos+2*qdim], &lbf[spos+3*qdim], &lbf[spos+10*qdim], &lbf[spos+8*qdim],
                             &lbf[spos+9*qdim], &lbf[spos+14*qdim], &lbf[spos+4*qdim], &lbf[spos+16*qdim],
                             &lbf[spos+6*qdim]);
        break;
      case CERB:
        fD3Q19VCESimpleZouHe(p0, uwall[0], -uwall[2], uwall[1], &force[0], &lbf[spos], &lbf[spos+1*qdim],
                             &lbf[spos+12*qdim], &lbf[spos+2*qdim], &lbf[spos+7*qdim], &lbf[spos+6*qdim],
                             &lbf[spos+4*qdim], &lbf[spos+5*qdim], &lbf[spos+9*qdim], &lbf[spos+17*qdim],
                             &lbf[spos+10*qdim], &lbf[spos+3*qdim], &lbf[spos+11*qdim], &lbf[spos+16*qdim],
                             &lbf[spos+15*qdim], &lbf[spos+13*qdim], &lbf[spos+14*qdim], &lbf[spos+18*qdim],
                             &lbf[spos+8*qdim]);
        break;
    }
  }
  return 0;
}


int fD3Q19CPSZouHe(double *p, double v0, double v1, double v2, double *f0, double *f1,
	               double *f2, double *f3, double *f4, double *f5, double *f6,
                   double *f7, double *f8, double *f9, double *f10, double *f11,
                   double *f12, double *f13, double *f14, double *f15, double *f16,
                   double *f17, double *f18)
{

  // produce fixed concentration at planar surface: expressed for bottom wall (CPST)

  double c1=2.0/3.0,c2=1.0/6.0;
  for(int i=0; i<lbsy.nc; i++) {
    f5[i]=f14[i]-c2*p[i]*(v0-v1);
    f11[i]=p[i]*(1.0-c1*v1)-f0[i]-f1[i]-f2[i]-f3[i]-f6[i]-f7[i]-f10[i]-f12[i]-f15[i]-f16[i]-2.0*(f4[i]+f8[i]+f9[i]+f14[i]);
    f13[i]=f4[i]+c2*p[i]*(v0+v1);
    f17[i]=f8[i]+c2*p[i]*(v1+v2);
    f18[i]=f9[i]+c2*p[i]*(v1-v2);
  }
  return 0;
}

int fD3Q19CCEZouHe(double *p, double v0, double v1, double v2, double *f0, double *f1,
	               double *f2, double *f3, double *f4, double *f5, double *f6,
                   double *f7, double *f8, double *f9, double *f10, double *f11,
                   double *f12, double *f13, double *f14, double *f15, double *f16,
                   double *f17, double *f18)
{

  // produce fixed concentration at concave edge: expressed for bottom left edge (CCETR)

  double nz;
  double c1=1.0/3.0, c2=1.0/6.0, c4=1.0/12.0;
  for(int i=0; i<lbsy.nc; i++) {
    nz=0.25*(f12[i]-f3[i])-c4*p[i]*v2;
    f5[i]=0.5*(p[i]-f0[i]-f3[i]-f12[i])-f1[i]-f2[i]-f4[i]-f6[i]-f7[i]-f8[i]-f9[i]-p[i]*(0.5*v0+c1*v1);
    f10[i]=f1[i]+c1*p[i]*v0;
    f11[i]=f2[i]+c1*p[i]*v1;
    f13[i]=f4[i]+c2*p[i]*(v0+v1);
    f14[i]=0.5*(p[i]-f0[i]-f3[i]-f12[i])-f1[i]-f2[i]-f4[i]-f6[i]-f7[i]-f8[i]-f9[i]-p[i]*(c1*v0+0.5*v1);
    f15[i]=f6[i]+c2*p[i]*(v0+v2)-nz;
    f16[i]=f7[i]+c2*p[i]*(v0-v2)+nz;
    f17[i]=f8[i]+c2*p[i]*(v1+v2)-nz;
    f18[i]=f9[i]+c2*p[i]*(v1-v2)+nz;
  }
  return 0;
}

int fD3Q19CCCZouHe(double *p, double v0, double v1, double v2, double *f0, double *f1,
	               double *f2, double *f3, double *f4, double *f5, double *f6,
                   double *f7, double *f8, double *f9, double *f10, double *f11,
                   double *f12, double *f13, double *f14, double *f15, double *f16,
                   double *f17, double *f18)
{

  // produce fixed concentration at concave corner: expressed for bottom left back corner (CCCTRF)

  double q0,qx,qy,qz;
  double c1=1.0/3.0, c2=1.0/6.0, c3=1.0/9.0, c4=1.0/12.0;
  for(int i=0; i<lbsy.nc; i++) {
    q0 = c2*(p[i]-f0[i])-c1*(f1[i]+f2[i]+f3[i]+f4[i]+f6[i]+f8[i])-c3*p[i]*(v0+v1+v2);
    qx = c4*p[i]*v0;
    qy = c4*p[i]*v1;
    qz = c4*p[i]*v2;
    f5[i]=q0-qx+qy;
    f7[i]=q0-qx+qz;
    f9[i]=q0-qy+qz;
    f10[i]=f1[i]+c1*p[i]*v0;
    f11[i]=f2[i]+c1*p[i]*v1;
    f12[i]=f3[i]+c1*p[i]*v2;
    f13[i]=f4[i]+c2*p[i]*(v0+v1);
    f14[i]=q0+qx-qy;
    f15[i]=f6[i]+c2*p[i]*(v0+v2);
    f16[i]=q0+qx-qz;
    f17[i]=f8[i]+c2*p[i]*(v1+v2);
    f18[i]=q0+qy-qz;
  }
  return 0;
}


int fD3Q19PCZouHe(long tpos, int prop, double *p0, double *uwall)
{
  long spos=tpos * lbsitelength + lbsy.nf;
  int qdim=lbsy.nf+lbsy.nc+lbsy.nt;
    
  switch (prop) {
    case PST:
      fD3Q19CPSZouHe(p0, uwall[0], uwall[1], uwall[2], &lbf[spos], &lbf[spos+1*qdim],
                     &lbf[spos+2*qdim], &lbf[spos+3*qdim], &lbf[spos+4*qdim], &lbf[spos+5*qdim], &lbf[spos+6*qdim],
                     &lbf[spos+7*qdim], &lbf[spos+8*qdim], &lbf[spos+9*qdim], &lbf[spos+10*qdim], &lbf[spos+11*qdim],
                     &lbf[spos+12*qdim], &lbf[spos+13*qdim], &lbf[spos+14*qdim], &lbf[spos+15*qdim], &lbf[spos+16*qdim],
                     &lbf[spos+17*qdim], &lbf[spos+18*qdim]);
      break;
    case PSD:
      fD3Q19CPSZouHe(p0, -uwall[0], -uwall[1], -uwall[2], &lbf[spos], &lbf[spos+10*qdim],
                     &lbf[spos+11*qdim], &lbf[spos+12*qdim], &lbf[spos+13*qdim], &lbf[spos+14*qdim], &lbf[spos+15*qdim],
                     &lbf[spos+16*qdim], &lbf[spos+17*qdim], &lbf[spos+18*qdim], &lbf[spos+1*qdim], &lbf[spos+2*qdim],
                     &lbf[spos+3*qdim], &lbf[spos+4*qdim], &lbf[spos+5*qdim], &lbf[spos+6*qdim], &lbf[spos+7*qdim],
                     &lbf[spos+8*qdim], &lbf[spos+9*qdim]);
      break;
    case PSL:
      fD3Q19CPSZouHe(p0, -uwall[2], -uwall[0], -uwall[1], &lbf[spos], &lbf[spos+12*qdim],
                     &lbf[spos+10*qdim], &lbf[spos+11*qdim], &lbf[spos+15*qdim], &lbf[spos+7*qdim], &lbf[spos+17*qdim],
                     &lbf[spos+9*qdim], &lbf[spos+13*qdim], &lbf[spos+14*qdim], &lbf[spos+3*qdim], &lbf[spos+1*qdim],
                     &lbf[spos+2*qdim], &lbf[spos+6*qdim], &lbf[spos+16*qdim], &lbf[spos+8*qdim], &lbf[spos+18*qdim],
                     &lbf[spos+4*qdim], &lbf[spos+5*qdim]);
      break;
    case PSR:
      fD3Q19CPSZouHe(p0, uwall[2], uwall[0], uwall[1], &lbf[spos], &lbf[spos+3*qdim],
                     &lbf[spos+1*qdim], &lbf[spos+2*qdim], &lbf[spos+6*qdim], &lbf[spos+16*qdim], &lbf[spos+8*qdim],
                     &lbf[spos+18*qdim], &lbf[spos+4*qdim], &lbf[spos+5*qdim], &lbf[spos+12*qdim], &lbf[spos+10*qdim],
                     &lbf[spos+11*qdim], &lbf[spos+15*qdim], &lbf[spos+7*qdim], &lbf[spos+17*qdim], &lbf[spos+9*qdim],
                     &lbf[spos+13*qdim], &lbf[spos+14*qdim]);
      break;
    case PSF:
      fD3Q19CPSZouHe(p0, -uwall[1], -uwall[2], -uwall[0], &lbf[spos], &lbf[spos+11*qdim],
                     &lbf[spos+12*qdim], &lbf[spos+10*qdim], &lbf[spos+17*qdim], &lbf[spos+18*qdim], &lbf[spos+13*qdim],
                     &lbf[spos+5*qdim], &lbf[spos+15*qdim], &lbf[spos+7*qdim], &lbf[spos+2*qdim], &lbf[spos+3*qdim],
                     &lbf[spos+1*qdim], &lbf[spos+8*qdim], &lbf[spos+9*qdim], &lbf[spos+4*qdim], &lbf[spos+14*qdim],
                     &lbf[spos+6*qdim], &lbf[spos+15*qdim]);
      break;
    case PSB:
      fD3Q19CPSZouHe(p0, uwall[1], uwall[2], uwall[0], &lbf[spos], &lbf[spos+2*qdim],
                     &lbf[spos+3*qdim], &lbf[spos+1*qdim], &lbf[spos+8*qdim], &lbf[spos+9*qdim], &lbf[spos+4*qdim],
                     &lbf[spos+14*qdim], &lbf[spos+6*qdim], &lbf[spos+16*qdim], &lbf[spos+11*qdim], &lbf[spos+12*qdim],
                     &lbf[spos+10*qdim], &lbf[spos+17*qdim], &lbf[spos+18*qdim], &lbf[spos+13*qdim], &lbf[spos+5*qdim],
                     &lbf[spos+15*qdim], &lbf[spos+7*qdim]);
      break;
    case CCTRB:
      fD3Q19CCCZouHe(p0, uwall[0], uwall[1], -uwall[2], &lbf[spos], &lbf[spos+1*qdim],
                     &lbf[spos+2*qdim], &lbf[spos+12*qdim], &lbf[spos+4*qdim], &lbf[spos+5*qdim],
                     &lbf[spos+7*qdim], &lbf[spos+6*qdim], &lbf[spos+9*qdim], &lbf[spos+8*qdim],
                     &lbf[spos+10*qdim], &lbf[spos+11*qdim], &lbf[spos+3*qdim], &lbf[spos+13*qdim],
                     &lbf[spos+14*qdim], &lbf[spos+16*qdim], &lbf[spos+15*qdim], &lbf[spos+18*qdim],
                     &lbf[spos+17*qdim]);
      break;
    case CCTLB:
      fD3Q19CCCZouHe(p0, -uwall[0], uwall[1], -uwall[2], &lbf[spos], &lbf[spos+10*qdim],
                     &lbf[spos+2*qdim], &lbf[spos+12*qdim], &lbf[spos+14*qdim], &lbf[spos+13*qdim],
                     &lbf[spos+15*qdim], &lbf[spos+16*qdim], &lbf[spos+9*qdim], &lbf[spos+8*qdim],
                     &lbf[spos+1*qdim], &lbf[spos+11*qdim], &lbf[spos+3*qdim], &lbf[spos+5*qdim],
                     &lbf[spos+4*qdim], &lbf[spos+6*qdim], &lbf[spos+7*qdim], &lbf[spos+18*qdim],
                     &lbf[spos+17*qdim]);
      break;
    case CCDLB:
      fD3Q19CCCZouHe(p0, -uwall[0], -uwall[1], -uwall[2], &lbf[spos], &lbf[spos+10*qdim],
                     &lbf[spos+11*qdim], &lbf[spos+12*qdim], &lbf[spos+13*qdim], &lbf[spos+14*qdim],
                     &lbf[spos+15*qdim], &lbf[spos+16*qdim], &lbf[spos+17*qdim], &lbf[spos+18*qdim],
                     &lbf[spos+1*qdim], &lbf[spos+2*qdim], &lbf[spos+3*qdim], &lbf[spos+4*qdim],
                     &lbf[spos+5*qdim], &lbf[spos+6*qdim], &lbf[spos+7*qdim], &lbf[spos+8*qdim],
                     &lbf[spos+9*qdim]);
      break;
    case CCDRB:
      fD3Q19CCCZouHe(p0, uwall[0], -uwall[1], -uwall[2], &lbf[spos], &lbf[spos+1*qdim],
                     &lbf[spos+11*qdim], &lbf[spos+12*qdim], &lbf[spos+5*qdim], &lbf[spos+4*qdim],
                     &lbf[spos+7*qdim], &lbf[spos+6*qdim], &lbf[spos+17*qdim], &lbf[spos+18*qdim],
                     &lbf[spos+10*qdim], &lbf[spos+2*qdim], &lbf[spos+3*qdim], &lbf[spos+14*qdim],
                     &lbf[spos+13*qdim], &lbf[spos+16*qdim], &lbf[spos+15*qdim], &lbf[spos+8*qdim],
                     &lbf[spos+9*qdim]);
      break;
    case CCTRF:
      fD3Q19CCCZouHe(p0, uwall[0], uwall[1], uwall[2], &lbf[spos], &lbf[spos+1*qdim],
                     &lbf[spos+2*qdim], &lbf[spos+3*qdim], &lbf[spos+4*qdim], &lbf[spos+5*qdim],
                     &lbf[spos+6*qdim], &lbf[spos+7*qdim], &lbf[spos+8*qdim], &lbf[spos+9*qdim],
                     &lbf[spos+10*qdim], &lbf[spos+11*qdim], &lbf[spos+12*qdim], &lbf[spos+13*qdim],
                     &lbf[spos+14*qdim], &lbf[spos+15*qdim], &lbf[spos+16*qdim], &lbf[spos+17*qdim],
                     &lbf[spos+18*qdim]);
      break;
    case CCTLF:
      fD3Q19CCCZouHe(p0, -uwall[0], uwall[1], uwall[2], &lbf[spos], &lbf[spos+10*qdim],
                     &lbf[spos+2*qdim], &lbf[spos+3*qdim], &lbf[spos+14*qdim], &lbf[spos+13*qdim],
                     &lbf[spos+16*qdim], &lbf[spos+15*qdim], &lbf[spos+8*qdim], &lbf[spos+9*qdim],
                     &lbf[spos+1*qdim], &lbf[spos+11*qdim], &lbf[spos+12*qdim], &lbf[spos+5*qdim],
                     &lbf[spos+4*qdim], &lbf[spos+7*qdim], &lbf[spos+6*qdim], &lbf[spos+17*qdim],
                     &lbf[spos+18*qdim]);
      break;
    case CCDLF:
      fD3Q19CCCZouHe(p0, -uwall[0], -uwall[1], uwall[2], &lbf[spos], &lbf[spos+10*qdim],
                     &lbf[spos+11*qdim], &lbf[spos+3*qdim], &lbf[spos+13*qdim], &lbf[spos+14*qdim],
                     &lbf[spos+16*qdim], &lbf[spos+15*qdim], &lbf[spos+18*qdim], &lbf[spos+17*qdim],
                     &lbf[spos+1*qdim], &lbf[spos+2*qdim], &lbf[spos+12*qdim], &lbf[spos+4*qdim],
                     &lbf[spos+5*qdim], &lbf[spos+7*qdim], &lbf[spos+6*qdim], &lbf[spos+9*qdim],
                     &lbf[spos+8*qdim]);
      break;
    case CCDRF:
      fD3Q19CCCZouHe(p0, uwall[0], -uwall[1], uwall[2], &lbf[spos], &lbf[spos+1*qdim],
                     &lbf[spos+11*qdim], &lbf[spos+3*qdim], &lbf[spos+5*qdim], &lbf[spos+4*qdim],
                     &lbf[spos+6*qdim], &lbf[spos+7*qdim], &lbf[spos+18*qdim], &lbf[spos+17*qdim],
                     &lbf[spos+10*qdim], &lbf[spos+2*qdim], &lbf[spos+12*qdim], &lbf[spos+14*qdim],
                     &lbf[spos+13*qdim], &lbf[spos+15*qdim], &lbf[spos+16*qdim], &lbf[spos+9*qdim],
                     &lbf[spos+8*qdim]);
      break;
    case CETR:
      fD3Q19CCEZouHe(p0, uwall[0], uwall[1], uwall[2], &lbf[spos], &lbf[spos+1*qdim],
                     &lbf[spos+2*qdim], &lbf[spos+3*qdim], &lbf[spos+4*qdim], &lbf[spos+5*qdim],
                     &lbf[spos+6*qdim], &lbf[spos+7*qdim], &lbf[spos+8*qdim], &lbf[spos+9*qdim],
                     &lbf[spos+10*qdim], &lbf[spos+11*qdim], &lbf[spos+12*qdim], &lbf[spos+13*qdim],
                     &lbf[spos+14*qdim], &lbf[spos+15*qdim], &lbf[spos+16*qdim], &lbf[spos+17*qdim],
                     &lbf[spos+18*qdim]);
      break;
    case CETL:
      fD3Q19CCEZouHe(p0, uwall[1], -uwall[0], uwall[2], &lbf[spos], &lbf[spos+2*qdim],
                     &lbf[spos+10*qdim], &lbf[spos+3*qdim], &lbf[spos+14*qdim], &lbf[spos+4*qdim],
                     &lbf[spos+8*qdim], &lbf[spos+9*qdim], &lbf[spos+16*qdim], &lbf[spos+15*qdim],
                     &lbf[spos+11*qdim], &lbf[spos+1*qdim], &lbf[spos+12*qdim], &lbf[spos+5*qdim],
                     &lbf[spos+13*qdim], &lbf[spos+17*qdim], &lbf[spos+18*qdim], &lbf[spos+7*qdim],
                     &lbf[spos+6*qdim]);
      break;
    case CEDL:
      fD3Q19CCEZouHe(p0, -uwall[0], -uwall[1], uwall[2], &lbf[spos], &lbf[spos+10*qdim],
                     &lbf[spos+11*qdim], &lbf[spos+3*qdim], &lbf[spos+13*qdim], &lbf[spos+14*qdim],
                     &lbf[spos+16*qdim], &lbf[spos+15*qdim], &lbf[spos+18*qdim], &lbf[spos+17*qdim],
                     &lbf[spos+1*qdim], &lbf[spos+2*qdim], &lbf[spos+12*qdim], &lbf[spos+4*qdim],
                     &lbf[spos+5*qdim], &lbf[spos+7*qdim], &lbf[spos+6*qdim], &lbf[spos+9*qdim],
                     &lbf[spos+8*qdim]);
      break;
    case CEDR:
      fD3Q19CCEZouHe(p0, -uwall[1], uwall[0], uwall[2], &lbf[spos], &lbf[spos+11*qdim],
                     &lbf[spos+1*qdim], &lbf[spos+3*qdim], &lbf[spos+5*qdim], &lbf[spos+13*qdim],
                     &lbf[spos+18*qdim], &lbf[spos+17*qdim], &lbf[spos+6*qdim], &lbf[spos+7*qdim],
                     &lbf[spos+2*qdim], &lbf[spos+10*qdim], &lbf[spos+12*qdim], &lbf[spos+14*qdim],
                     &lbf[spos+4*qdim], &lbf[spos+9*qdim], &lbf[spos+8*qdim], &lbf[spos+15*qdim],
                     &lbf[spos+16*qdim]);
      break;
    case CETF:
      fD3Q19CCEZouHe(p0, uwall[1], uwall[2], uwall[0], &lbf[spos], &lbf[spos+2*qdim],
                     &lbf[spos+3*qdim], &lbf[spos+1*qdim], &lbf[spos+8*qdim], &lbf[spos+9*qdim],
                     &lbf[spos+4*qdim], &lbf[spos+14*qdim], &lbf[spos+6*qdim], &lbf[spos+16*qdim],
                     &lbf[spos+11*qdim], &lbf[spos+12*qdim], &lbf[spos+10*qdim], &lbf[spos+17*qdim],
                     &lbf[spos+18*qdim], &lbf[spos+13*qdim], &lbf[spos+5*qdim], &lbf[spos+15*qdim],
                     &lbf[spos+7*qdim]);
      break;
    case CELF:
      fD3Q19CCEZouHe(p0, -uwall[0], uwall[2], uwall[1], &lbf[spos], &lbf[spos+10*qdim],
                     &lbf[spos+3*qdim], &lbf[spos+2*qdim], &lbf[spos+16*qdim], &lbf[spos+15*qdim],
                     &lbf[spos+14*qdim], &lbf[spos+13*qdim], &lbf[spos+8*qdim], &lbf[spos+18*qdim],
                     &lbf[spos+1*qdim], &lbf[spos+12*qdim], &lbf[spos+11*qdim], &lbf[spos+7*qdim],
                     &lbf[spos+6*qdim], &lbf[spos+5*qdim], &lbf[spos+4*qdim], &lbf[spos+17*qdim],
                     &lbf[spos+9*qdim]);
      break;
    case CEDF:
      fD3Q19CCEZouHe(p0, -uwall[1], uwall[2], uwall[0], &lbf[spos], &lbf[spos+11*qdim],
                     &lbf[spos+3*qdim], &lbf[spos+1*qdim], &lbf[spos+18*qdim], &lbf[spos+17*qdim],
                     &lbf[spos+5*qdim], &lbf[spos+13*qdim], &lbf[spos+6*qdim], &lbf[spos+16*qdim],
                     &lbf[spos+2*qdim], &lbf[spos+12*qdim], &lbf[spos+10*qdim], &lbf[spos+9*qdim],
                     &lbf[spos+8*qdim], &lbf[spos+14*qdim], &lbf[spos+4*qdim], &lbf[spos+15*qdim],
                     &lbf[spos+7*qdim]);
      break;
    case CERF:
      fD3Q19CCEZouHe(p0, uwall[0], uwall[2], uwall[1], &lbf[spos], &lbf[spos+1*qdim],
                     &lbf[spos+3*qdim], &lbf[spos+2*qdim], &lbf[spos+6*qdim], &lbf[spos+7*qdim],
                     &lbf[spos+4*qdim], &lbf[spos+5*qdim], &lbf[spos+8*qdim], &lbf[spos+18*qdim],
                     &lbf[spos+10*qdim], &lbf[spos+12*qdim], &lbf[spos+11*qdim], &lbf[spos+15*qdim],
                     &lbf[spos+16*qdim], &lbf[spos+13*qdim], &lbf[spos+14*qdim], &lbf[spos+17*qdim],
                     &lbf[spos+9*qdim]);
      break;
    case CETB:
      fD3Q19CCEZouHe(p0, uwall[1], -uwall[2], uwall[0], &lbf[spos], &lbf[spos+2*qdim],
                     &lbf[spos+12*qdim], &lbf[spos+1*qdim], &lbf[spos+9*qdim], &lbf[spos+8*qdim],
                     &lbf[spos+4*qdim], &lbf[spos+14*qdim], &lbf[spos+7*qdim], &lbf[spos+15*qdim],
                     &lbf[spos+11*qdim], &lbf[spos+3*qdim], &lbf[spos+10*qdim], &lbf[spos+18*qdim],
                     &lbf[spos+17*qdim], &lbf[spos+13*qdim], &lbf[spos+5*qdim], &lbf[spos+16*qdim],
                     &lbf[spos+6*qdim]);
      break;
    case CELB:
      fD3Q19CCEZouHe(p0, -uwall[0], -uwall[2], uwall[1], &lbf[spos], &lbf[spos+10*qdim],
                     &lbf[spos+12*qdim], &lbf[spos+2*qdim], &lbf[spos+15*qdim], &lbf[spos+16*qdim],
                     &lbf[spos+14*qdim], &lbf[spos+13*qdim], &lbf[spos+9*qdim], &lbf[spos+17*qdim],
                     &lbf[spos+1*qdim], &lbf[spos+3*qdim], &lbf[spos+11*qdim], &lbf[spos+6*qdim],
                     &lbf[spos+7*qdim], &lbf[spos+5*qdim], &lbf[spos+4*qdim], &lbf[spos+18*qdim],
                     &lbf[spos+8*qdim]);
      break;
    case CEDB:
      fD3Q19CCEZouHe(p0, -uwall[1], -uwall[2], uwall[0], &lbf[spos], &lbf[spos+11*qdim],
                     &lbf[spos+12*qdim], &lbf[spos+1*qdim], &lbf[spos+17*qdim], &lbf[spos+18*qdim],
                     &lbf[spos+5*qdim], &lbf[spos+13*qdim], &lbf[spos+7*qdim], &lbf[spos+15*qdim],
                     &lbf[spos+2*qdim], &lbf[spos+3*qdim], &lbf[spos+10*qdim], &lbf[spos+8*qdim],
                     &lbf[spos+9*qdim], &lbf[spos+14*qdim], &lbf[spos+4*qdim], &lbf[spos+16*qdim],
                     &lbf[spos+6*qdim]);
      break;
    case CERB:
      fD3Q19CCEZouHe(p0, uwall[0], -uwall[2], uwall[1], &lbf[spos], &lbf[spos+1*qdim],
                     &lbf[spos+12*qdim], &lbf[spos+2*qdim], &lbf[spos+7*qdim], &lbf[spos+6*qdim],
                     &lbf[spos+4*qdim], &lbf[spos+5*qdim], &lbf[spos+9*qdim], &lbf[spos+17*qdim],
                     &lbf[spos+10*qdim], &lbf[spos+3*qdim], &lbf[spos+11*qdim], &lbf[spos+16*qdim],
                     &lbf[spos+15*qdim], &lbf[spos+13*qdim], &lbf[spos+14*qdim], &lbf[spos+18*qdim],
                     &lbf[spos+8*qdim]);
      break;
  }
  return 0;
}

int fD3Q19TPSZouHe(double p, double v0, double v1, double v2, double *f0, double *f1,
	               double *f2, double *f3, double *f4, double *f5, double *f6,
                   double *f7, double *f8, double *f9, double *f10, double *f11,
                   double *f12, double *f13, double *f14, double *f15, double *f16,
                   double *f17, double *f18)
{

  // produce fixed temperature at planar surface: expressed for bottom wall

  double c1=2.0/3.0,c2=1.0/6.0;
  f5[0]=f14[0]-c2*p*(v0-v1);
  f11[0]=p*(1.0-c1*v1)-f0[0]-f1[0]-f2[0]-f3[0]-f6[0]-f7[0]-f10[0]-f12[0]-f15[0]-f16[0]-2.0*(f4[0]+f8[0]+f9[0]+f14[0]);
  f13[0]=f4[0]+c2*p*(v0+v1);
  f17[0]=f8[0]+c2*p*(v1+v2);
  f18[0]=f9[0]+c2*p*(v1-v2);
  return 0;
}

int fD3Q19TCEZouHe(double p, double v0, double v1, double v2, double *f0, double *f1,
	               double *f2, double *f3, double *f4, double *f5, double *f6,
                   double *f7, double *f8, double *f9, double *f10, double *f11,
                   double *f12, double *f13, double *f14, double *f15, double *f16,
                   double *f17, double *f18)
{

  // produce fixed temperature at concave edge: expressed for bottom left edge (TCETR)

  double nz;
  double c1=1.0/3.0, c2=1.0/6.0, c4=1.0/12.0;
  nz=0.25*(f12[0]-f3[0])-c4*p*v2;
  f5[0]=0.5*(p-f0[0]-f3[0]-f12[0])-f1[0]-f2[0]-f4[0]-f6[0]-f7[0]-f8[0]-f9[0]-p*(0.5*v0+c1*v1);
  f10[0]=f1[0]+c1*p*v0;
  f11[0]=f2[0]+c1*p*v1;
  f13[0]=f4[0]+c2*p*(v0+v1);
  f14[0]=0.5*(p-f0[0]-f3[0]-f12[0])-f1[0]-f2[0]-f4[0]-f6[0]-f7[0]-f8[0]-f9[0]-p*(c1*v0+0.5*v1);
  f15[0]=f6[0]+c2*p*(v0+v2)-nz;
  f16[0]=f7[0]+c2*p*(v0-v2)+nz;
  f17[0]=f8[0]+c2*p*(v1+v2)-nz;
  f18[0]=f9[0]+c2*p*(v1-v2)+nz;
  return 0;
}

int fD3Q19TCCZouHe(double p, double v0, double v1, double v2, double *f0, double *f1,
	               double *f2, double *f3, double *f4, double *f5, double *f6,
                   double *f7, double *f8, double *f9, double *f10, double *f11,
                   double *f12, double *f13, double *f14, double *f15, double *f16,
                   double *f17, double *f18)
{

  // produce fixed temperature at concave corner: expressed for bottom left back corner (TCCTRF)

  double q0,qx,qy,qz;
  double c1=1.0/3.0, c2=1.0/6.0, c3=1.0/9.0, c4=1.0/12.0;
  q0 = c2*(p-f0[0])-c1*(f1[0]+f2[0]+f3[0]+f4[0]+f6[0]+f8[0])-c3*p*(v0+v1+v2);
  qx = c4*p*v0;
  qy = c4*p*v1;
  qz = c4*p*v2;
  f5[0]=q0-qx+qy;
  f7[0]=q0-qx+qz;
  f9[0]=q0-qy+qz;
  f10[0]=f1[0]+c1*p*v0;
  f11[0]=f2[0]+c1*p*v1;
  f12[0]=f3[0]+c1*p*v2;
  f13[0]=f4[0]+c2*p*(v0+v1);
  f14[0]=q0+qx-qy;
  f15[0]=f6[0]+c2*p*(v0+v2);
  f16[0]=q0+qx-qz;
  f17[0]=f8[0]+c2*p*(v1+v2);
  f18[0]=q0+qy-qz;
  return 0;
}


int fD3Q19PTZouHe(long tpos, int prop, double p0, double *uwall)
{
  long spos=tpos * lbsitelength + (lbsy.nf + lbsy.nc);
  int qdim=lbsy.nf+lbsy.nc+lbsy.nt;
    
  switch (prop) {
    case PST:
      fD3Q19TPSZouHe(p0, uwall[0], uwall[1], uwall[2], &lbf[spos], &lbf[spos+1*qdim],
                     &lbf[spos+2*qdim], &lbf[spos+3*qdim], &lbf[spos+4*qdim], &lbf[spos+5*qdim], &lbf[spos+6*qdim],
                     &lbf[spos+7*qdim], &lbf[spos+8*qdim], &lbf[spos+9*qdim], &lbf[spos+10*qdim], &lbf[spos+11*qdim],
                     &lbf[spos+12*qdim], &lbf[spos+13*qdim], &lbf[spos+14*qdim], &lbf[spos+15*qdim], &lbf[spos+16*qdim],
                     &lbf[spos+17*qdim], &lbf[spos+18*qdim]);
      break;
    case PSD:
      fD3Q19TPSZouHe(p0, -uwall[0], -uwall[1], -uwall[2], &lbf[spos], &lbf[spos+10*qdim],
                     &lbf[spos+11*qdim], &lbf[spos+12*qdim], &lbf[spos+13*qdim], &lbf[spos+14*qdim], &lbf[spos+15*qdim],
                     &lbf[spos+16*qdim], &lbf[spos+17*qdim], &lbf[spos+18*qdim], &lbf[spos+1*qdim], &lbf[spos+2*qdim],
                     &lbf[spos+3*qdim], &lbf[spos+4*qdim], &lbf[spos+5*qdim], &lbf[spos+6*qdim], &lbf[spos+7*qdim],
                     &lbf[spos+8*qdim], &lbf[spos+9*qdim]);
      break;
    case PSL:
      fD3Q19TPSZouHe(p0, -uwall[2], -uwall[0], -uwall[1], &lbf[spos], &lbf[spos+12*qdim],
                     &lbf[spos+10*qdim], &lbf[spos+11*qdim], &lbf[spos+15*qdim], &lbf[spos+7*qdim], &lbf[spos+17*qdim],
                     &lbf[spos+9*qdim], &lbf[spos+13*qdim], &lbf[spos+14*qdim], &lbf[spos+3*qdim], &lbf[spos+1*qdim],
                     &lbf[spos+2*qdim], &lbf[spos+6*qdim], &lbf[spos+16*qdim], &lbf[spos+8*qdim], &lbf[spos+18*qdim],
                     &lbf[spos+4*qdim], &lbf[spos+5*qdim]);
      break;
    case PSR:
      fD3Q19TPSZouHe(p0, uwall[2], uwall[0], uwall[1], &lbf[spos], &lbf[spos+3*qdim],
                     &lbf[spos+1*qdim], &lbf[spos+2*qdim], &lbf[spos+6*qdim], &lbf[spos+16*qdim], &lbf[spos+8*qdim],
                     &lbf[spos+18*qdim], &lbf[spos+4*qdim], &lbf[spos+5*qdim], &lbf[spos+12*qdim], &lbf[spos+10*qdim],
                     &lbf[spos+11*qdim], &lbf[spos+15*qdim], &lbf[spos+7*qdim], &lbf[spos+17*qdim], &lbf[spos+9*qdim],
                     &lbf[spos+13*qdim], &lbf[spos+14*qdim]);
      break;
    case PSF:
      fD3Q19TPSZouHe(p0, -uwall[1], -uwall[2], -uwall[0], &lbf[spos], &lbf[spos+11*qdim],
                     &lbf[spos+12*qdim], &lbf[spos+10*qdim], &lbf[spos+17*qdim], &lbf[spos+18*qdim], &lbf[spos+13*qdim],
                     &lbf[spos+5*qdim], &lbf[spos+15*qdim], &lbf[spos+7*qdim], &lbf[spos+2*qdim], &lbf[spos+3*qdim],
                     &lbf[spos+1*qdim], &lbf[spos+8*qdim], &lbf[spos+9*qdim], &lbf[spos+4*qdim], &lbf[spos+14*qdim],
                     &lbf[spos+6*qdim], &lbf[spos+15*qdim]);
      break;
    case PSB:
      fD3Q19TPSZouHe(p0, uwall[1], uwall[2], uwall[0], &lbf[spos], &lbf[spos+2*qdim],
                     &lbf[spos+3*qdim], &lbf[spos+1*qdim], &lbf[spos+8*qdim], &lbf[spos+9*qdim], &lbf[spos+4*qdim],
                     &lbf[spos+14*qdim], &lbf[spos+6*qdim], &lbf[spos+16*qdim], &lbf[spos+11*qdim], &lbf[spos+12*qdim],
                     &lbf[spos+10*qdim], &lbf[spos+17*qdim], &lbf[spos+18*qdim], &lbf[spos+13*qdim], &lbf[spos+5*qdim],
                     &lbf[spos+15*qdim], &lbf[spos+7*qdim]);
      break;
    case CCTRB:
      fD3Q19TCCZouHe(p0, uwall[0], uwall[1], -uwall[2], &lbf[spos], &lbf[spos+1*qdim],
                     &lbf[spos+2*qdim], &lbf[spos+12*qdim], &lbf[spos+4*qdim], &lbf[spos+5*qdim],
                     &lbf[spos+7*qdim], &lbf[spos+6*qdim], &lbf[spos+9*qdim], &lbf[spos+8*qdim],
                     &lbf[spos+10*qdim], &lbf[spos+11*qdim], &lbf[spos+3*qdim], &lbf[spos+13*qdim],
                     &lbf[spos+14*qdim], &lbf[spos+16*qdim], &lbf[spos+15*qdim], &lbf[spos+18*qdim],
                     &lbf[spos+17*qdim]);
      break;
    case CCTLB:
      fD3Q19TCCZouHe(p0, -uwall[0], uwall[1], -uwall[2], &lbf[spos], &lbf[spos+10*qdim],
                     &lbf[spos+2*qdim], &lbf[spos+12*qdim], &lbf[spos+14*qdim], &lbf[spos+13*qdim],
                     &lbf[spos+15*qdim], &lbf[spos+16*qdim], &lbf[spos+9*qdim], &lbf[spos+8*qdim],
                     &lbf[spos+1*qdim], &lbf[spos+11*qdim], &lbf[spos+3*qdim], &lbf[spos+5*qdim],
                     &lbf[spos+4*qdim], &lbf[spos+6*qdim], &lbf[spos+7*qdim], &lbf[spos+18*qdim],
                     &lbf[spos+17*qdim]);
      break;
    case CCDLB:
      fD3Q19TCCZouHe(p0, -uwall[0], -uwall[1], -uwall[2], &lbf[spos], &lbf[spos+10*qdim],
                     &lbf[spos+11*qdim], &lbf[spos+12*qdim], &lbf[spos+13*qdim], &lbf[spos+14*qdim],
                     &lbf[spos+15*qdim], &lbf[spos+16*qdim], &lbf[spos+17*qdim], &lbf[spos+18*qdim],
                     &lbf[spos+1*qdim], &lbf[spos+2*qdim], &lbf[spos+3*qdim], &lbf[spos+4*qdim],
                     &lbf[spos+5*qdim], &lbf[spos+6*qdim], &lbf[spos+7*qdim], &lbf[spos+8*qdim],
                     &lbf[spos+9*qdim]);
      break;
    case CCDRB:
      fD3Q19TCCZouHe(p0, uwall[0], -uwall[1], -uwall[2], &lbf[spos], &lbf[spos+1*qdim],
                     &lbf[spos+11*qdim], &lbf[spos+12*qdim], &lbf[spos+5*qdim], &lbf[spos+4*qdim],
                     &lbf[spos+7*qdim], &lbf[spos+6*qdim], &lbf[spos+17*qdim], &lbf[spos+18*qdim],
                     &lbf[spos+10*qdim], &lbf[spos+2*qdim], &lbf[spos+3*qdim], &lbf[spos+14*qdim],
                     &lbf[spos+13*qdim], &lbf[spos+16*qdim], &lbf[spos+15*qdim], &lbf[spos+8*qdim],
                     &lbf[spos+9*qdim]);
      break;
    case CCTRF:
      fD3Q19TCCZouHe(p0, uwall[0], uwall[1], uwall[2], &lbf[spos], &lbf[spos+1*qdim],
                     &lbf[spos+2*qdim], &lbf[spos+3*qdim], &lbf[spos+4*qdim], &lbf[spos+5*qdim],
                     &lbf[spos+6*qdim], &lbf[spos+7*qdim], &lbf[spos+8*qdim], &lbf[spos+9*qdim],
                     &lbf[spos+10*qdim], &lbf[spos+11*qdim], &lbf[spos+12*qdim], &lbf[spos+13*qdim],
                     &lbf[spos+14*qdim], &lbf[spos+15*qdim], &lbf[spos+16*qdim], &lbf[spos+17*qdim],
                     &lbf[spos+18*qdim]);
      break;
    case CCTLF:
      fD3Q19TCCZouHe(p0, -uwall[0], uwall[1], uwall[2], &lbf[spos], &lbf[spos+10*qdim],
                     &lbf[spos+2*qdim], &lbf[spos+3*qdim], &lbf[spos+14*qdim], &lbf[spos+13*qdim],
                     &lbf[spos+16*qdim], &lbf[spos+15*qdim], &lbf[spos+8*qdim], &lbf[spos+9*qdim],
                     &lbf[spos+1*qdim], &lbf[spos+11*qdim], &lbf[spos+12*qdim], &lbf[spos+5*qdim],
                     &lbf[spos+4*qdim], &lbf[spos+7*qdim], &lbf[spos+6*qdim], &lbf[spos+17*qdim],
                     &lbf[spos+18*qdim]);
      break;
    case CCDLF:
      fD3Q19TCCZouHe(p0, -uwall[0], -uwall[1], uwall[2], &lbf[spos], &lbf[spos+10*qdim],
                     &lbf[spos+11*qdim], &lbf[spos+3*qdim], &lbf[spos+13*qdim], &lbf[spos+14*qdim],
                     &lbf[spos+16*qdim], &lbf[spos+15*qdim], &lbf[spos+18*qdim], &lbf[spos+17*qdim],
                     &lbf[spos+1*qdim], &lbf[spos+2*qdim], &lbf[spos+12*qdim], &lbf[spos+4*qdim],
                     &lbf[spos+5*qdim], &lbf[spos+7*qdim], &lbf[spos+6*qdim], &lbf[spos+9*qdim],
                     &lbf[spos+8*qdim]);
      break;
    case CCDRF:
      fD3Q19TCCZouHe(p0, uwall[0], -uwall[1], uwall[2], &lbf[spos], &lbf[spos+1*qdim],
                     &lbf[spos+11*qdim], &lbf[spos+3*qdim], &lbf[spos+5*qdim], &lbf[spos+4*qdim],
                     &lbf[spos+6*qdim], &lbf[spos+7*qdim], &lbf[spos+18*qdim], &lbf[spos+17*qdim],
                     &lbf[spos+10*qdim], &lbf[spos+2*qdim], &lbf[spos+12*qdim], &lbf[spos+14*qdim],
                     &lbf[spos+13*qdim], &lbf[spos+15*qdim], &lbf[spos+16*qdim], &lbf[spos+9*qdim],
                     &lbf[spos+8*qdim]);
      break;
    case CETR:
      fD3Q19TCEZouHe(p0, uwall[0], uwall[1], uwall[2], &lbf[spos], &lbf[spos+1*qdim],
                     &lbf[spos+2*qdim], &lbf[spos+3*qdim], &lbf[spos+4*qdim], &lbf[spos+5*qdim],
                     &lbf[spos+6*qdim], &lbf[spos+7*qdim], &lbf[spos+8*qdim], &lbf[spos+9*qdim],
                     &lbf[spos+10*qdim], &lbf[spos+11*qdim], &lbf[spos+12*qdim], &lbf[spos+13*qdim],
                     &lbf[spos+14*qdim], &lbf[spos+15*qdim], &lbf[spos+16*qdim], &lbf[spos+17*qdim],
                     &lbf[spos+18*qdim]);
      break;
    case CETL:
      fD3Q19TCEZouHe(p0, uwall[1], -uwall[0], uwall[2], &lbf[spos], &lbf[spos+2*qdim],
                     &lbf[spos+10*qdim], &lbf[spos+3*qdim], &lbf[spos+14*qdim], &lbf[spos+4*qdim],
                     &lbf[spos+8*qdim], &lbf[spos+9*qdim], &lbf[spos+16*qdim], &lbf[spos+15*qdim],
                     &lbf[spos+11*qdim], &lbf[spos+1*qdim], &lbf[spos+12*qdim], &lbf[spos+5*qdim],
                     &lbf[spos+13*qdim], &lbf[spos+17*qdim], &lbf[spos+18*qdim], &lbf[spos+7*qdim],
                     &lbf[spos+6*qdim]);
      break;
    case CEDL:
      fD3Q19TCEZouHe(p0, -uwall[0], -uwall[1], uwall[2], &lbf[spos], &lbf[spos+10*qdim],
                     &lbf[spos+11*qdim], &lbf[spos+3*qdim], &lbf[spos+13*qdim], &lbf[spos+14*qdim],
                     &lbf[spos+16*qdim], &lbf[spos+15*qdim], &lbf[spos+18*qdim], &lbf[spos+17*qdim],
                     &lbf[spos+1*qdim], &lbf[spos+2*qdim], &lbf[spos+12*qdim], &lbf[spos+4*qdim],
                     &lbf[spos+5*qdim], &lbf[spos+7*qdim], &lbf[spos+6*qdim], &lbf[spos+9*qdim],
                     &lbf[spos+8*qdim]);
      break;
    case CEDR:
      fD3Q19TCEZouHe(p0, -uwall[1], uwall[0], uwall[2], &lbf[spos], &lbf[spos+11*qdim],
                     &lbf[spos+1*qdim], &lbf[spos+3*qdim], &lbf[spos+5*qdim], &lbf[spos+13*qdim],
                     &lbf[spos+18*qdim], &lbf[spos+17*qdim], &lbf[spos+6*qdim], &lbf[spos+7*qdim],
                     &lbf[spos+2*qdim], &lbf[spos+10*qdim], &lbf[spos+12*qdim], &lbf[spos+14*qdim],
                     &lbf[spos+4*qdim], &lbf[spos+9*qdim], &lbf[spos+8*qdim], &lbf[spos+15*qdim],
                     &lbf[spos+16*qdim]);
      break;
    case CETF:
      fD3Q19TCEZouHe(p0, uwall[1], uwall[2], uwall[0], &lbf[spos], &lbf[spos+2*qdim],
                     &lbf[spos+3*qdim], &lbf[spos+1*qdim], &lbf[spos+8*qdim], &lbf[spos+9*qdim],
                     &lbf[spos+4*qdim], &lbf[spos+14*qdim], &lbf[spos+6*qdim], &lbf[spos+16*qdim],
                     &lbf[spos+11*qdim], &lbf[spos+12*qdim], &lbf[spos+10*qdim], &lbf[spos+17*qdim],
                     &lbf[spos+18*qdim], &lbf[spos+13*qdim], &lbf[spos+5*qdim], &lbf[spos+15*qdim],
                     &lbf[spos+7*qdim]);
      break;
    case CELF:
      fD3Q19TCEZouHe(p0, -uwall[0], uwall[2], uwall[1], &lbf[spos], &lbf[spos+10*qdim],
                     &lbf[spos+3*qdim], &lbf[spos+2*qdim], &lbf[spos+16*qdim], &lbf[spos+15*qdim],
                     &lbf[spos+14*qdim], &lbf[spos+13*qdim], &lbf[spos+8*qdim], &lbf[spos+18*qdim],
                     &lbf[spos+1*qdim], &lbf[spos+12*qdim], &lbf[spos+11*qdim], &lbf[spos+7*qdim],
                     &lbf[spos+6*qdim], &lbf[spos+5*qdim], &lbf[spos+4*qdim], &lbf[spos+17*qdim],
                     &lbf[spos+9*qdim]);
      break;
    case CEDF:
      fD3Q19TCEZouHe(p0, -uwall[1], uwall[2], uwall[0], &lbf[spos], &lbf[spos+11*qdim],
                     &lbf[spos+3*qdim], &lbf[spos+1*qdim], &lbf[spos+18*qdim], &lbf[spos+17*qdim],
                     &lbf[spos+5*qdim], &lbf[spos+13*qdim], &lbf[spos+6*qdim], &lbf[spos+16*qdim],
                     &lbf[spos+2*qdim], &lbf[spos+12*qdim], &lbf[spos+10*qdim], &lbf[spos+9*qdim],
                     &lbf[spos+8*qdim], &lbf[spos+14*qdim], &lbf[spos+4*qdim], &lbf[spos+15*qdim],
                     &lbf[spos+7*qdim]);
      break;
    case CERF:
      fD3Q19TCEZouHe(p0, uwall[0], uwall[2], uwall[1], &lbf[spos], &lbf[spos+1*qdim],
                     &lbf[spos+3*qdim], &lbf[spos+2*qdim], &lbf[spos+6*qdim], &lbf[spos+7*qdim],
                     &lbf[spos+4*qdim], &lbf[spos+5*qdim], &lbf[spos+8*qdim], &lbf[spos+18*qdim],
                     &lbf[spos+10*qdim], &lbf[spos+12*qdim], &lbf[spos+11*qdim], &lbf[spos+15*qdim],
                     &lbf[spos+16*qdim], &lbf[spos+13*qdim], &lbf[spos+14*qdim], &lbf[spos+17*qdim],
                     &lbf[spos+9*qdim]);
      break;
    case CETB:
      fD3Q19TCEZouHe(p0, uwall[1], -uwall[2], uwall[0], &lbf[spos], &lbf[spos+2*qdim],
                     &lbf[spos+12*qdim], &lbf[spos+1*qdim], &lbf[spos+9*qdim], &lbf[spos+8*qdim],
                     &lbf[spos+4*qdim], &lbf[spos+14*qdim], &lbf[spos+7*qdim], &lbf[spos+15*qdim],
                     &lbf[spos+11*qdim], &lbf[spos+3*qdim], &lbf[spos+10*qdim], &lbf[spos+18*qdim],
                     &lbf[spos+17*qdim], &lbf[spos+13*qdim], &lbf[spos+5*qdim], &lbf[spos+16*qdim],
                     &lbf[spos+6*qdim]);
      break;
    case CELB:
      fD3Q19TCEZouHe(p0, -uwall[0], -uwall[2], uwall[1], &lbf[spos], &lbf[spos+10*qdim],
                     &lbf[spos+12*qdim], &lbf[spos+2*qdim], &lbf[spos+15*qdim], &lbf[spos+16*qdim],
                     &lbf[spos+14*qdim], &lbf[spos+13*qdim], &lbf[spos+9*qdim], &lbf[spos+17*qdim],
                     &lbf[spos+1*qdim], &lbf[spos+3*qdim], &lbf[spos+11*qdim], &lbf[spos+6*qdim],
                     &lbf[spos+7*qdim], &lbf[spos+5*qdim], &lbf[spos+4*qdim], &lbf[spos+18*qdim],
                     &lbf[spos+8*qdim]);
      break;
    case CEDB:
      fD3Q19TCEZouHe(p0, -uwall[1], -uwall[2], uwall[0], &lbf[spos], &lbf[spos+11*qdim],
                     &lbf[spos+12*qdim], &lbf[spos+1*qdim], &lbf[spos+17*qdim], &lbf[spos+18*qdim],
                     &lbf[spos+5*qdim], &lbf[spos+13*qdim], &lbf[spos+7*qdim], &lbf[spos+15*qdim],
                     &lbf[spos+2*qdim], &lbf[spos+3*qdim], &lbf[spos+10*qdim], &lbf[spos+8*qdim],
                     &lbf[spos+9*qdim], &lbf[spos+14*qdim], &lbf[spos+4*qdim], &lbf[spos+16*qdim],
                     &lbf[spos+6*qdim]);
      break;
    case CERB:
      fD3Q19TCEZouHe(p0, uwall[0], -uwall[2], uwall[1], &lbf[spos], &lbf[spos+1*qdim],
                     &lbf[spos+12*qdim], &lbf[spos+2*qdim], &lbf[spos+7*qdim], &lbf[spos+6*qdim],
                     &lbf[spos+4*qdim], &lbf[spos+5*qdim], &lbf[spos+9*qdim], &lbf[spos+17*qdim],
                     &lbf[spos+10*qdim], &lbf[spos+3*qdim], &lbf[spos+11*qdim], &lbf[spos+16*qdim],
                     &lbf[spos+15*qdim], &lbf[spos+13*qdim], &lbf[spos+14*qdim], &lbf[spos+18*qdim],
                     &lbf[spos+8*qdim]);
      break;
  }
  return 0;
}


// D3Q27

int fD3Q27VPSZouHe(double v0, double v1, double v2, double *force,
                   double *f0, double *f1, double *f2, double *f3, double *f4,
                   double *f5, double *f6, double *f7, double *f8, double *f9,
                   double *f10, double *f11, double *f12, double *f13, double *f14,
                   double *f15, double *f16, double *f17, double *f18, double *f19,
                   double *f20, double *f21, double *f22, double *f23, double *f24,
                   double *f25, double *f26)
{

  // produce fixed velocity for compressible/incompressible fluids at planar surface boundary:
  // expressed for bottom wall (VPST)
  
  double rho, rho0, n1, n2;
  double c1=4.0/9.0,c2=1.0/9.0,c3=1.0/36.0,c4=1.0/12.0,c5=1.0/18.0,c6=1.0/24.0;

  if(!incompress) {
    for(int i=0; i<lbsy.nf; i++) {
      rho=(f0[i]+f1[i]+f3[i]+f6[i]+f7[i]+f14[i]+f16[i]+f19[i]+f20[i]+2.0*(f2[i]+f4[i]+f8[i]+f9[i]+f10[i]+f11[i]+f18[i]+f25[i]+f26[i])-0.5*force[3*i+1])/(1.0-v1);
      n1=c4*(f14[i]-f1[i]-f6[i]-f7[i]+f19[i]+f20[i])-c5*rho*v0+c6*force[3*i  ];
      n2=c4*(f16[i]-f3[i]-f6[i]+f7[i]+f19[i]-f20[i])-c5*rho*v2+c6*force[3*i+2];
      f5[i]=f18[i]-c2*rho*(v0-v1)+4.0*n1;
      f12[i]=f25[i]-c3*rho*(v0-v1+v2)+n1+n2;
      f13[i]=f26[i]-c3*rho*(v0-v1-v2)+n1-n2;
      f15[i]=f2[i]+c1*rho*v1;
      f17[i]=f4[i]+c2*rho*(v0+v1)-4.0*n1;
      f21[i]=f8[i]+c2*rho*(v1+v2)-4.0*n2;
      f22[i]=f9[i]+c2*rho*(v1-v2)+4.0*n2;
      f23[i]=f10[i]+c3*rho*(v0+v1+v2)-n1-n2;
      f24[i]=f11[i]+c3*rho*(v0+v1-v2)-n1+n2;
    }
  }
  else {
    for(int i=0; i<lbsy.nf; i++) {
//     rho=f0+f1+f3+f6+f7+f14+f16+f19+f20+2.0*(f2+f4+f8+f9+f10+f11+f18+f25+f26)+rho0*v1-0.5*force[1];
      rho0=lbincp[i];
      n1=c4*(f14[i]-f1[i]-f6[i]-f7[i]+f19[i]+f20[i])-c5*rho0*v0+c6*force[3*i  ];
      n2=c4*(f16[i]-f3[i]-f6[i]+f7[i]+f19[i]-f20[i])-c5*rho0*v2+c6*force[3*i+2];
      f5[i]=f18[i]-c2*rho0*(v0-v1)+4.0*n1;
      f12[i]=f25[i]-c3*rho0*(v0-v1+v2)+n1+n2;
      f13[i]=f26[i]-c3*rho0*(v0-v1-v2)+n1-n2;
      f15[i]=f2[i]+c1*rho0*v1;
      f17[i]=f4[i]+c2*rho0*(v0+v1)-4.0*n1;
      f21[i]=f8[i]+c2*rho0*(v1+v2)-4.0*n2;
      f22[i]=f9[i]+c2*rho0*(v1-v2)+4.0*n2;
      f23[i]=f10[i]+c3*rho0*(v0+v1+v2)-n1-n2;
      f24[i]=f11[i]+c3*rho0*(v0+v1-v2)-n1+n2;
    }
  }
    
  return 0;
}

int fD3Q27VCEZouHe(double *p, double v0, double v1, double v2, double *force,
                   double *f0, double *f1, double *f2, double *f3, double *f4,
                   double *f5, double *f6, double *f7, double *f8, double *f9,
                   double *f10, double *f11, double *f12, double *f13, double *f14,
                   double *f15, double *f16, double *f17, double *f18, double *f19,
                   double *f20, double *f21, double *f22, double *f23, double *f24,
                   double *f25, double *f26)
{

  // produce fixed velocity for compressible/incompressible fluids at concave edge boundary:
  // expressed for bottom left edge (VCETR)
  
  double rho0, q0, qxy, nz;
  double c1=4.0/9.0,c2=1.0/9.0,c3=1.0/36.0,c4=1.0/12.0,c5=1.0/72.0,c7=1.0/6.0,c8=5.0/72.0,c9=1.0/48.0,c10=1.0/22.0,c11=1.0/44.0;

  if(!incompress) {
    for(int i=0; i<lbsy.nf; i++) {
      q0 = c4*(p[i]-f0[i]-f3[i]-f16[i])-c7*(f1[i]+f2[i]+f4[i]+f6[i]+f7[i]+f8[i]+f9[i]+f10[i]+f11[i])-c8*p[i]*(v0+v1)+c9*(force[3*i]+force[3*i+1]);
      qxy = c5*p[i]*(v0-v1)+c9*(force[3*i+1]-force[3*i]);
      nz = c10*(f16[i]-f3[i])-c11*p[i]*v2+c11*force[3*i+2];
      f5[i]=4.0*(q0-qxy);
      f12[i]=q0-qxy+nz;
      f13[i]=q0-qxy-nz;
      f14[i]=f1[i]+c1*p[i]*v0;
      f15[i]=f2[i]+c1*p[i]*v1;
      f17[i]=f4[i]+c2*p[i]*(v0+v1)-0.25*(force[3*i]+force[3*i+1]);
      f18[i]=4.0*(q0+qxy);
      f19[i]=f6[i]+c2*p[i]*(v0+v2)-4.0*nz;
      f20[i]=f7[i]+c2*p[i]*(v0-v2)+4.0*nz;
      f21[i]=f8[i]+c2*p[i]*(v1+v2)-4.0*nz;
      f22[i]=f9[i]+c2*p[i]*(v1-v2)+4.0*nz;
      f23[i]=f10[i]+c3*p[i]*(v0+v1+v2)-nz;
      f24[i]=f11[i]+c3*p[i]*(v0+v1-v2)+nz;
      f25[i]=q0+qxy-nz;
      f26[i]=q0+qxy+nz;
    }
  }
  else {
    for(int i=0; i<lbsy.nf; i++) {
      rho0=lbincp[i];
      q0 = c4*(p[i]-f0[i]-f3[i]-f16[i])-c7*(f1[i]+f2[i]+f4[i]+f6[i]+f7[i]+f8[i]+f9[i]+f10[i]+f11[i])-c8*rho0*(v0+v1)+c9*(force[3*i]+force[3*i+1]);
      qxy = c5*rho0*(v0-v1)+c9*(force[3*i+1]-force[3*i]);
      nz = c10*(f16[i]-f3[i])-c11*rho0*v2+c11*force[3*i+2];
      f5[i]=4.0*(q0-qxy);
      f12[i]=q0-qxy+nz;
      f13[i]=q0-qxy-nz;
      f14[i]=f1[i]+c1*rho0*v0;
      f15[i]=f2[i]+c1*rho0*v1;
      f17[i]=f4[i]+c2*rho0*(v0+v1)-0.25*(force[3*i]+force[3*i+1]);
      f18[i]=4.0*(q0+qxy);
      f19[i]=f6[i]+c2*rho0*(v0+v2)-4.0*nz;
      f20[i]=f7[i]+c2*rho0*(v0-v2)+4.0*nz;
      f21[i]=f8[i]+c2*rho0*(v1+v2)-4.0*nz;
      f22[i]=f9[i]+c2*rho0*(v1-v2)+4.0*nz;
      f23[i]=f10[i]+c3*rho0*(v0+v1+v2)-nz;
      f24[i]=f11[i]+c3*rho0*(v0+v1-v2)+nz;
      f25[i]=q0+qxy-nz;
      f26[i]=q0+qxy+nz;
    }
  }
    
  return 0;
}

int fD3Q27VCCZouHe(double *p, double v0, double v1, double v2, double *force,
                   double *f0, double *f1, double *f2, double *f3, double *f4,
                   double *f5, double *f6, double *f7, double *f8, double *f9,
                   double *f10, double *f11, double *f12, double *f13, double *f14,
                   double *f15, double *f16, double *f17, double *f18, double *f19,
                   double *f20, double *f21, double *f22, double *f23, double *f24,
                   double *f25, double *f26)
{

  // produce fixed velocity for compressible/incompressible fluids at concave corner boundary:
  // expressed for bottom left back corner (VCCTRF)
  
  double rho0, q0, qx, qy, qz;
  double c1=4.0/9.0,c2=1.0/9.0,c3=1.0/36.0,c4=1.0/30.0,c5=1.0/72.0,c7=1.0/15.0,c8=5.0/216.0;

  if(!incompress) {
    for(int i=0; i<lbsy.nf; i++) {
      q0 = c4*(p[i]-f0[i])-c7*(f1[i]+f2[i]+f3[i]+f4[i]+f6[i]+f8[i]+f10[i])-c8*p[i]*(v0+v1+v2)+0.0075*(force[3*i]+force[3*i+1]+force[3*i+2]);
      qx = c5*p[i]*v0-0.0125*force[3*i  ];
      qy = c5*p[i]*v1-0.0125*force[3*i+1];
      qz = c5*p[i]*v2-0.0125*force[3*i+2];
      f5[i]=4.0*(q0-qx+qy);
      f7[i]=4.0*(q0-qx+qz);
      f9[i]=4.0*(q0-qy+qz);
      f11[i]=q0-qx-qy+qz;
      f12[i]=q0-qx+qy-qz;
      f13[i]=q0-qx+qy+qz;
      f14[i]=f1[i]+c1*p[i]*v0;
      f15[i]=f2[i]+c1*p[i]*v1;
      f16[i]=f3[i]+c1*p[i]*v2;
      f17[i]=f4[i]+c2*p[i]*(v0+v1)-0.1*(force[3*i  ]+force[3*i+1]);
      f18[i]=4.0*(q0+qx-qy);
      f19[i]=f6[i]+c2*p[i]*(v0+v2)-0.1*(force[3*i  ]+force[3*i+2]);
      f20[i]=4.0*(q0+qx-qz);
      f21[i]=f8[i]+c2*p[i]*(v1+v2)-0.1*(force[3*i+1]+force[3*i+2]);
      f22[i]=4.0*(q0+qy-qz);
      f23[i]=f10[i]+c3*p[i]*(v0+v1+v2)-0.025*(force[3*i]+force[3*i+1]+force[3*i+2]);
      f24[i]=q0+qx+qx-qz;
      f25[i]=q0+qx-qy+qz;
      f26[i]=q0+qx-qy-qz;
    }
  }
  else {
    for(int i=0; i<lbsy.nf; i++) {
      rho0=lbincp[i];
      q0 = c4*(p[i]-f0[i])-c7*(f1[i]+f2[i]+f3[i]+f4[i]+f6[i]+f8[i]+f10[i])-c8*rho0*(v0+v1+v2)+0.0075*(force[3*i]+force[3*i+1]+force[3*i+2]);
      qx = c5*rho0*v0-0.0125*force[3*i  ];
      qy = c5*rho0*v1-0.0125*force[3*i+1];
      qz = c5*rho0*v2-0.0125*force[3*i+2];
      f5[i]=4.0*(q0-qx+qy);
      f7[i]=4.0*(q0-qx+qz);
      f9[i]=4.0*(q0-qy+qz);
      f11[i]=q0-qx-qy+qz;
      f12[i]=q0-qx+qy-qz;
      f13[i]=q0-qx+qy+qz;
      f14[i]=f1[i]+c1*rho0*v0;
      f15[i]=f2[i]+c1*rho0*v1;
      f16[i]=f3[i]+c1*rho0*v2;
      f17[i]=f4[i]+c2*rho0*(v0+v1)-0.1*(force[3*i  ]+force[3*i+1]);
      f18[i]=4.0*(q0+qx-qy);
      f19[i]=f6[i]+c2*rho0*(v0+v2)-0.1*(force[3*i  ]+force[3*i+2]);
      f20[i]=4.0*(q0+qx-qz);
      f21[i]=f8[i]+c2*rho0*(v1+v2)-0.1*(force[3*i+1]+force[3*i+2]);
      f22[i]=4.0*(q0+qy-qz);
      f23[i]=f10[i]+c3*rho0*(v0+v1+v2)-0.025*(force[3*i]+force[3*i+1]+force[3*i+2]);
      f24[i]=q0+qx+qx-qz;
      f25[i]=q0+qx-qy+qz;
      f26[i]=q0+qx-qy-qz;
    }
  }
    
  return 0;
}

int fD3Q27VPSCLBEZouHe(double v0, double v1, double v2, double *force, double *f0, double *f1, double *f2,
                       double *f3, double *f4, double *f5, double *f6, double *f7, double *f8,
                       double *f9, double *f10, double *f11, double *f12, double *f13, double *f14,
                       double *f15, double *f16, double *f17, double *f18, double *f19, double *f20,
                       double *f21, double *f22, double *f23, double *f24, double *f25, double *f26)
{

  // produce fixed velocity for compressible fluids at planar surface boundary:
  // expressed for bottom wall (VPST) with higher-order equilibrium distribution
  // functions for CLBE collisions
  
  double rho, n1, n2;
  double c1=4.0/9.0,c2=1.0/9.0,c3=1.0/36.0,c4=1.0/6.0,c5=2.0/3.0,c6=1.0/3.0,c7=1.0/12.0,c8=1.0/18.0,c9=1.0/24.0;

  double v0v0 = v0*v0;
  double v1v1 = v1*v1;
  double v2v2 = v2*v2;
  double v0v1v2 = v0*v1*v2;
    
  for(int i=0; i<lbsy.nf; i++) {
    rho=(f0[i]+f1[i]+f3[i]+f6[i]+f7[i]+f14[i]+f16[i]+f19[i]+f20[i]+2.0*(f2[i]+f4[i]+f8[i]+f9[i]+f10[i]+f11[i]+f18[i]+f25[i]+f26[i])-0.5*force[3*i+1])/(1.0-v1);
    n1=c7*(f14[i]-f1[i]-f6[i]-f7[i]+f19[i]+f20[i])+rho*v1*(c7*v0v0-c8)+c9*force[3*i  ];
    n2=c7*(f16[i]-f3[i]-f6[i]+f7[i]+f19[i]-f20[i])+rho*v1*(c7*v2v2-c8)+c9*force[3*i+2];
    f5[i]=f18[i]+rho*((c2-c4*v2v2)*(v1-v0)+(c6-0.5*v2v2)*(v0v0*v1-v0*v1v1))+4.0*n1;
    f12[i]=f25[i]+rho*(c3*(-v0+v1-v2)+c7*(v0v0*(v1-v2)-v1v1*(v0+v2)-v2v2*(v0-v1))+0.25*v0v1v2*(1.0-v0*v1+v0*v2-v1*v2))+n1+n2;
    f13[i]=f26[i]+rho*(c3*(-v0+v1+v2)+c7*(v0v0*(v1+v2)-v1v1*(v0-v2)-v2v2*(v0-v1))-0.25*v0v1v2*(1.0-v0*v1-v0*v2+v1*v2))+n1-n2;
    f15[i]=f2[i]+rho*v1*(c1-c5*(v0v0+v2v2)+v0v0*v2v2);
    f17[i]=f4[i]+rho*((c2-c4*v2v2)*(v0+v1)+(c6-0.5*v2v2)*(v0v0*v1+v0*v1v1))-4.0*n1;
    f21[i]=f8[i]+rho*((c2-c4*v0v0)*(v1+v2)+(c6-0.5*v0v0)*(v1v1*v2+v1*v2v2))-4.0*n2;
    f22[i]=f9[i]+rho*((c2-c4*v0v0)*(v1-v2)-(c6-0.5*v0v0)*(v1v1*v2-v1*v2v2))+4.0*n2;
    f23[i]=f10[i]+rho*(c3*(v0+v1+v2)+c7*(v0v0*(v1+v2)+v1v1*(v0+v2)+v2v2*(v0+v1))+0.25*v0v1v2*(1.0+v0*v1+v0*v2+v1*v2))-n1-n2;
    f24[i]=f11[i]+rho*(c3*(v0+v1-v2)+c7*(v0v0*(v1-v2)+v1v1*(v0-v2)+v2v2*(v0+v1))-0.25*v0v1v2*(1.0+v0*v1-v0*v2-v1*v2))-n1+n2;
  }
  return 0;
}

int fD3Q27VCECLBEZouHe(double *p, double v0, double v1, double v2, double *force, double *f0, double *f1, double *f2,
                       double *f3, double *f4, double *f5, double *f6, double *f7, double *f8,
                       double *f9, double *f10, double *f11, double *f12, double *f13, double *f14,
                       double *f15, double *f16, double *f17, double *f18, double *f19, double *f20,
                       double *f21, double *f22, double *f23, double *f24, double *f25, double *f26)
{

  // produce fixed velocity for compressible fluids at concave edge boundary:
  // expressed for bottom left edge (VCETR) with higher-order equilibrium
  // distribution functions for CLBE collisions
  
  double q0, qxy, nz;
  double c0=1.0/3.0,c1=4.0/9.0,c2=1.0/9.0,c3=1.0/36.0,c4=1.0/12.0,c5=1.0/72.0,c6=1.0/24.0,c7=1.0/6.0,c8=5.0/72.0,c9=1.0/48.0,c10=1.0/22.0,c11=1.0/44.0,c12=2.0/3.0;
    
  double v0v0 = v0*v0;
  double v1v1 = v1*v1;
  double v2v2 = v2*v2;
  double v0v1v2 = v0*v1*v2;
    
  for(int i=0; i<lbsy.nf; i++) {
    q0 = c4*(p[i]-f0[i]-f3[i]-f16[i])-c7*(f1[i]+f2[i]+f4[i]+f6[i]+f7[i]+f8[i]+f9[i]+f10[i]+f11[i])-p[i]*(c8*(v0+v1)+c3*(v0v0*v1+v1v1*v0)-c5*v2v2*(v0+v1)-c6*v2v2*(v0v0*v1+v1v1*v0))+c9*(force[3*i]+force[3*i+1]);
    qxy = p[i]*(v0-v1)*(c5-c6*v0*v1)+c9*(force[3*i+1]-force[3*i]);
    nz = c10*(f16[i]-f3[i])-c11*p[i]*v2*(1.0-v0v0-v1v1-v0*v1+3.0*v0v0*v1v1)+c11*force[3*i+2];
    f5[i]=4.0*(q0-qxy);
    f12[i]=q0-qxy+nz;
    f13[i]=q0-qxy-nz;
    f14[i]=f1[i]+p[i]*v0*(c1-c12*(v1v1+v2v2)+v1v1*v2v2);
    f15[i]=f2[i]+p[i]*v1*(c1-c12*(v0v0+v2v2)+v0v0*v2v2);
    f17[i]=f4[i]+p[i]*(v0*(c2+c0*v1v1-c7*v2v2-0.5*v1v1*v2v2)+v1*(c2+c0*v0v0-c7*v2v2-0.5*v0v0*v2v2))-0.25*(force[3*i]+force[3*i+1]);
    f18[i]=4.0*(q0+qxy);
    f19[i]=f6[i]+p[i]*(v0*(c2+c0*v2v2-c7*v1v1-0.5*v1v1*v2v2)+v2*(c2+c0*v0v0-c7*v1v1-0.5*v0v0*v1v1))-4.0*nz;
    f20[i]=f7[i]+p[i]*(v0*(c2+c0*v2v2-c7*v1v1-0.5*v1v1*v2v2)-v2*(c2+c0*v0v0-c7*v1v1-0.5*v0v0*v1v1))+4.0*nz;
    f21[i]=f8[i]+p[i]*(v1*(c2+c0*v2v2-c7*v0v0-0.5*v0v0*v2v2)+v2*(c2+c0*v1v1-c7*v0v0-0.5*v0v0*v1v1))-4.0*nz;
    f22[i]=f9[i]+p[i]*(v1*(c2+c0*v2v2-c7*v0v0-0.5*v0v0*v2v2)-v2*(c2+c0*v1v1-c7*v0v0-0.5*v0v0*v1v1))+4.0*nz;
    f23[i]=f10[i]+p[i]*(v0*(c3+c4*(v1v1+v2v2)+0.25*v1v1*v2v2)+v1*(c3+c4*(v0v0+v2v2)+0.25*v0v0*v2v2)+v2*(c3+c4*(v0v0+v1v1)+0.25*v0v0*v1v1)+0.25*v0v1v2)-nz;
    f24[i]=f11[i]+p[i]*(v0*(c3+c4*(v1v1+v2v2)+0.25*v1v1*v2v2)+v1*(c3+c4*(v0v0+v2v2)+0.25*v0v0*v2v2)-v2*(c3+c4*(v0v0+v1v1)+0.25*v0v0*v1v1)-0.25*v0v1v2)+nz;
    f25[i]=q0+qxy-nz;
    f26[i]=q0+qxy+nz;
  }
  return 0;
}

int fD3Q27VCCCLBEZouHe(double *p, double v0, double v1, double v2, double *force, double *f0, double *f1, double *f2,
                       double *f3, double *f4, double *f5, double *f6, double *f7, double *f8,
                       double *f9, double *f10, double *f11, double *f12, double *f13, double *f14,
                       double *f15, double *f16, double *f17, double *f18, double *f19, double *f20,
                       double *f21, double *f22, double *f23, double *f24, double *f25, double *f26)
{

  // produce fixed velocity for compressible fluids at concave corner boundary:
  // expressed for bottom left back corner (VCCTRF) with higher-order equilibrium
  // distribution functions for CLBE collisions

  double q0, qx, qy, qz;
  double c0=1.0/3.0,c1=4.0/9.0,c2=1.0/9.0,c3=1.0/36.0,c4=1.0/30.0,c5=1.0/72.0,c6=1.0/120.0,c7=1.0/15.0,c8=5.0/216.0,c9=1.0/48.0,c10=5.0/192.0,c11=1.0/6.0,c12=2.0/3.0;

  double v0v0 = v0*v0;
  double v1v1 = v1*v1;
  double v2v2 = v2*v2;
  double v0v1v2 = v0*v1*v2;

  for(int i=0; i<lbsy.nf; i++) {
    q0 = c4*(p[i]-f0[i])-c7*(f1[i]+f2[i]+f3[i]+f4[i]+f6[i]+f8[i]+f10[i])-p[i]*(v0*(c8-c5*(v1v1+v2v2)+c6*v1v1*v2v2)+v1*(c8-c5*(v0v0+v2v2)+c6*v0v0*v2v2)+v2*(c8-c5*(v0v0+v1v1)+c6*v0v0*v1v1)+c6*v0v1v2)+c9*(force[3*i]+force[3*i+1]);
    qx = p[i]*v0*(c5+c10*(v1v1+v2v2)-0.03125*v1v1*v2v2)+p[i]*(v1+v2)*(0.015625*v1*v2+0.046875*v0v0*v1*v2)-0.125*p[i]*v0v1v2-0.0125*force[3*i  ];
    qy = p[i]*v1*(c5+c10*(v0v0+v2v2)-0.03125*v0v0*v2v2)+p[i]*(v0+v2)*(0.015625*v0*v2+0.046875*v0*v1v1*v2)-0.125*p[i]*v0v1v2-0.0125*force[3*i+1];
    qz = p[i]*v2*(c5+c10*(v0v0+v1v1)-0.03125*v0v0*v1v1)+p[i]*(v0+v1)*(0.015625*v0*v1+0.046875*v0*v1*v2v2)-0.125*p[i]*v0v1v2-0.0125*force[3*i+1];
    f5[i]=4.0*(q0-qx+qy);
    f7[i]=4.0*(q0-qx+qz);
    f9[i]=4.0*(q0-qy+qz);
    f11[i]=q0-qx-qy+qz;
    f12[i]=q0-qx+qy-qz;
    f13[i]=q0-qx+qy+qz;
    f14[i]=f1[i]+p[i]*v0*(c1-c12*(v1v1+v2v2)+v1v1*v2v2);
    f15[i]=f2[i]+p[i]*v1*(c1-c12*(v0v0+v2v2)+v0v0*v2v2);
    f16[i]=f3[i]+p[i]*v2*(c1-c12*(v0v0+v1v1)+v0v0*v1v1);
    f17[i]=f4[i]+p[i]*(v0*(c2+c0*v1v1-c11*v2v2-0.5*v1v1*v2v2)+v1*(c2+c0*v0v0-c7*v2v2-0.5*v0v0*v2v2))-0.1*(force[3*i  ]+force[3*i+1]);
    f18[i]=4.0*(q0+qx-qy);
    f19[i]=f6[i]+p[i]*(v0*(c2+c0*v2v2-c11*v1v1-0.5*v1v1*v2v2)+v2*(c2+c0*v0v0-c7*v1v1-0.5*v0v0*v1v1))-0.1*(force[3*i  ]+force[3*i+2]);
    f20[i]=4.0*(q0+qx-qz);
    f21[i]=f8[i]+p[i]*(v1*(c2+c0*v2v2-c11*v0v0-0.5*v0v0*v2v2)+v2*(c2+c0*v1v1-c7*v0v0-0.5*v0v0*v1v1))-0.1*(force[3*i+1]+force[3*i+2]);
    f22[i]=4.0*(q0+qy-qz);
    f23[i]=f10[i]+p[i]*(v0*(c3+c4*(v1v1+v2v2)+0.25*v1v1*v2v2)+v1*(c3+c4*(v0v0+v2v2)+0.25*v0v0*v2v2)+v2*(c3+c4*(v0v0+v1v1)+0.25*v0v0*v1v1)+0.25*v0v1v2)-0.025*(force[3*i]+force[3*i+1]+force[3*i+2]);
    f24[i]=q0+qx+qx-qz;
    f25[i]=q0+qx-qy+qz;
    f26[i]=q0+qx-qy-qz;
  }
  return 0;
}

int fD3Q27VPSSimpleZouHe(double v0, double v1, double v2, double *force, double *f0, double *f1, double *f2,
                         double *f3, double *f4, double *f5, double *f6, double *f7, double *f8,
                         double *f9, double *f10, double *f11, double *f12, double *f13, double *f14,
                         double *f15, double *f16, double *f17, double *f18, double *f19, double *f20,
                         double *f21, double *f22, double *f23, double *f24, double *f25, double *f26)
{

  // produce fixed velocity for compressible/incompressible fluids at planar surface boundary:
  // expressed for bottom wall (VPST)
  
  double rho, rho0;
  double c1=4.0/9.0,c2=1.0/9.0,c3=1.0/36.0;
  if(!incompress) {
    for(int i=0; i<lbsy.nf; i++) {
      rho=(f0[i]+f1[i]+f3[i]+f6[i]+f7[i]+f14[i]+f16[i]+f19[i]+f20[i]+2.0*(f2[i]+f4[i]+f8[i]+f9[i]+f10[i]+f11[i]+f18[i]+f25[i]+f26[i])-0.5*force[3*i+1])/(1.0-v1);
      f5[i]=f18[i]-c2*rho*(v0-v1);
      f12[i]=f25[i]-c3*rho*(v0-v1+v2);
      f13[i]=f26[i]-c3*rho*(v0-v1-v2);
      f15[i]=f2[i]+c1*rho*v1;
      f17[i]=f4[i]+c2*rho*(v0+v1);
      f21[i]=f8[i]+c2*rho*(v1+v2);
      f22[i]=f9[i]+c2*rho*(v1-v2);
      f23[i]=f10[i]+c3*rho*(v0+v1+v2);
      f24[i]=f11[i]+c3*rho*(v0+v1-v2);
    }
  }
  else {
    for(int i=0; i<lbsy.nf; i++) {
//     rho=f0+f1+f3+f6+f7+f14+f16+f19+f20+2.0*(f2+f4+f8+f9+f10+f11+f18+f25+f26)+rho0*v1-0.5*force;
      rho0=lbincp[i];
      f5[i]=f18[i]-c2*rho0*(v0-v1);
      f12[i]=f25[i]-c3*rho0*(v0-v1+v2);
      f13[i]=f26[i]-c3*rho0*(v0-v1-v2);
      f15[i]=f2[i]+c1*rho0*v1;
      f17[i]=f4[i]+c2*rho0*(v0+v1);
      f21[i]=f8[i]+c2*rho0*(v1+v2);
      f22[i]=f9[i]+c2*rho0*(v1-v2);
      f23[i]=f10[i]+c3*rho0*(v0+v1+v2);
      f24[i]=f11[i]+c3*rho0*(v0+v1-v2);
    }
  }
  return 0;
}

int fD3Q27VCESimpleZouHe(double *p, double v0, double v1, double v2, double *force,
                         double *f0, double *f1, double *f2, double *f3, double *f4,
                         double *f5, double *f6, double *f7, double *f8, double *f9,
                         double *f10, double *f11, double *f12, double *f13, double *f14,
                         double *f15, double *f16, double *f17, double *f18, double *f19,
                         double *f20, double *f21, double *f22, double *f23, double *f24,
                         double *f25, double *f26)
{

  // produce fixed velocity for compressible/incompressible fluids at concave edge boundary:
  // expressed for bottom left edge (VCETR)
  
  double rho0, q0, qxy, qz;
  double c1=4.0/9.0,c2=1.0/9.0,c3=1.0/36.0,c4=1.0/12.0,c5=1.0/72.0,c7=1.0/6.0,c8=5.0/72.0,c9=1.0/48.0;

  if(!incompress) {
    for(int i=0; i<lbsy.nf; i++) {
      q0 = c4*(p[i]-f0[i]-f3[i]-f16[i])-c7*(f1[i]+f2[i]+f4[i]+f6[i]+f7[i]+f8[i]+f9[i]+f10[i]+f11[i])-c8*p[i]*(v0+v1);
      qxy = c5*p[i]*(v0-v1)+c9*(force[3*i+1]-force[3*i]);
      qz = 0.25*(f3[i]-f16[i])+0.125*p[i]*v2-0.125*force[3*i+2];
      f5[i]=4.0*(q0-qxy);
      f12[i]=q0-qxy-qz;
      f13[i]=q0-qxy+qz;
      f14[i]=f1[i]+c1*p[i]*v0;
      f15[i]=f2[i]+c1*p[i]*v1;
      f17[i]=f4[i]+c2*p[i]*(v0+v1);
      f18[i]=4.0*(q0+qxy);
      f19[i]=f6[i]+c2*p[i]*(v0+v2);
      f20[i]=f7[i]+c2*p[i]*(v0-v2);
      f21[i]=f8[i]+c2*p[i]*(v1+v2);
      f22[i]=f9[i]+c2*p[i]*(v1-v2);
      f23[i]=f10[i]+c3*p[i]*(v0+v1+v2);
      f24[i]=f11[i]+c3*p[i]*(v0+v1-v2);
      f25[i]=q0+qxy+qz;
      f26[i]=q0+qxy-qz;
    }
  }
  else {
    for(int i=0; i<lbsy.nf; i++) {
      rho0=lbincp[i];
      q0 = c4*(p[i]-f0[i]-f3[i]-f16[i])-c7*(f1[i]+f2[i]+f4[i]+f6[i]+f7[i]+f8[i]+f9[i]+f10[i]+f11[i])-c8*rho0*(v0+v1);
      qxy = c5*rho0*(v0-v1)+c9*(force[3*i+1]-force[3*i]);
      qz = 0.25*(f3[i]-f16[i])+0.125*rho0*v2-0.125*force[3*i+2];
      f5[i]=4.0*(q0-qxy);
      f12[i]=q0-qxy-qz;
      f13[i]=q0-qxy+qz;
      f14[i]=f1[i]+c1*rho0*v0;
      f15[i]=f2[i]+c1*rho0*v1;
      f17[i]=f4[i]+c2*rho0*(v0+v1);
      f18[i]=4.0*(q0+qxy);
      f19[i]=f6[i]+c2*rho0*(v0+v2);
      f20[i]=f7[i]+c2*rho0*(v0-v2);
      f21[i]=f8[i]+c2*rho0*(v1+v2);
      f22[i]=f9[i]+c2*rho0*(v1-v2);
      f23[i]=f10[i]+c3*rho0*(v0+v1+v2);
      f24[i]=f11[i]+c3*rho0*(v0+v1-v2);
      f25[i]=q0+qxy+qz;
      f26[i]=q0+qxy-qz;
    }
  }
    
  return 0;
}

int fD3Q27VCCSimpleZouHe(double *p, double v0, double v1, double v2, double *force,
                         double *f0, double *f1, double *f2, double *f3, double *f4,
                         double *f5, double *f6, double *f7, double *f8, double *f9,
                         double *f10, double *f11, double *f12, double *f13, double *f14,
                         double *f15, double *f16, double *f17, double *f18, double *f19,
                         double *f20, double *f21, double *f22, double *f23, double *f24,
                         double *f25, double *f26)
{

  // produce fixed velocity for compressible/incompressible fluids at concave corner boundary:
  // expressed for bottom left back corner (VCCTRF)
  
  double rho0, q0, qx, qy, qz;
  double c1=4.0/9.0,c2=1.0/9.0,c3=1.0/36.0,c4=1.0/30.0,c5=1.0/72.0,c7=1.0/15.0,c8=5.0/216.0;

  if(!incompress) {
    for(int i=0; i<lbsy.nf; i++) {
      q0 = c4*(p[i]-f0[i])-c7*(f1[i]+f2[i]+f4[i]+f6[i]+f7[i]+f8[i]+f9[i]+f10[i]+f11[i])-c8*p[i]*(v0+v1+v2);
      qx = c5*p[i]*v0-0.09375*force[3*i  ]-0.078125*(force[3*i+1]+force[3*i+2]);
      qy = c5*p[i]*v1-0.09375*force[3*i+1]-0.078125*(force[3*i  ]+force[3*i+2]);
      qz = c5*p[i]*v2-0.09375*force[3*i+2]-0.078125*(force[3*i  ]+force[3*i+1]);
      f5[i]=4.0*(q0-qx+qy);
      f7[i]=4.0*(q0-qx+qz);
      f9[i]=4.0*(q0-qy+qz);
      f11[i]=q0-qx-qy+qz;
      f12[i]=q0-qx+qy-qz;
      f13[i]=q0-qx+qy+qz;
      f14[i]=f1[i]+c1*p[i]*v0;
      f15[i]=f2[i]+c1*p[i]*v1;
      f16[i]=f3[i]+c1*p[i]*v2;
      f17[i]=f4[i]+c2*p[i]*(v0+v1);
      f18[i]=4.0*(q0+qx-qy);
      f19[i]=f6[i]+c2*p[i]*(v0+v2);
      f20[i]=4.0*(q0+qx-qz);
      f21[i]=f8[i]+c2*p[i]*(v1+v2);
      f22[i]=4.0*(q0+qy-qz);
      f23[i]=f10[i]+c3*p[i]*(v0+v1+v2);
      f24[i]=q0+qx+qx-qz;
      f25[i]=q0+qx-qy+qz;
      f26[i]=q0+qx-qy-qz;
    }
  }
  else {
    for(int i=0; i<lbsy.nf; i++) {
      rho0=lbincp[i];
      q0 = c4*(p[i]-f0[i])-c7*(f1[i]+f2[i]+f3[i]+f4[i]+f6[i]+f8[i]+f10[i])-c8*rho0*(v0+v1+v2);
      qx = c5*rho0*v0-0.09375*force[3*i  ]-0.078125*(force[3*i+1]+force[3*i+2]);
      qy = c5*rho0*v1-0.09375*force[3*i+1]-0.078125*(force[3*i  ]+force[3*i+2]);
      qz = c5*rho0*v2-0.09375*force[3*i+2]-0.078125*(force[3*i  ]+force[3*i+1]);
      f5[i]=4.0*(q0-qx+qy);
      f7[i]=4.0*(q0-qx+qz);
      f9[i]=4.0*(q0-qy+qz);
      f11[i]=q0-qx-qy+qz;
      f12[i]=q0-qx+qy-qz;
      f13[i]=q0-qx+qy+qz;
      f14[i]=f1[i]+c1*rho0*v0;
      f15[i]=f2[i]+c1*rho0*v1;
      f16[i]=f3[i]+c1*rho0*v2;
      f17[i]=f4[i]+c2*rho0*(v0+v1);
      f18[i]=4.0*(q0+qx-qy);
      f19[i]=f6[i]+c2*rho0*(v0+v2);
      f20[i]=4.0*(q0+qx-qz);
      f21[i]=f8[i]+c2*rho0*(v1+v2);
      f22[i]=4.0*(q0+qy-qz);
      f23[i]=f10[i]+c3*rho0*(v0+v1+v2);
      f24[i]=q0+qx+qx-qz;
      f25[i]=q0+qx-qy+qz;
      f26[i]=q0+qx-qy-qz;
    }
  }
    
  return 0;
}


int fD3Q27VPSCLBESimpleZouHe(double v0, double v1, double v2, double *force, double *f0, double *f1, double *f2,
                             double *f3, double *f4, double *f5, double *f6, double *f7, double *f8,
                             double *f9, double *f10, double *f11, double *f12, double *f13, double *f14,
                             double *f15, double *f16, double *f17, double *f18, double *f19, double *f20,
                             double *f21, double *f22, double *f23, double *f24, double *f25, double *f26)
{

  // produce fixed velocity for compressible fluids at planar surface boundary:
  // expressed for bottom wall (VPST) with higher-order equilibrium distribution
  // functions for CLBE collisions
  
  double rho;
  double c1=4.0/9.0,c2=1.0/9.0,c3=1.0/36.0,c4=1.0/6.0,c5=2.0/3.0,c6=1.0/3.0,c7=1.0/12.0;

  double v0v0 = v0*v0;
  double v1v1 = v1*v1;
  double v2v2 = v2*v2;
  double v0v1v2 = v0*v1*v2;
    
  for(int i=0; i<lbsy.nf; i++) {
    rho=(f0[i]+f1[i]+f3[i]+f6[i]+f7[i]+f14[i]+f16[i]+f19[i]+f20[i]+2.0*(f2[i]+f4[i]+f8[i]+f9[i]+f10[i]+f11[i]+f18[i]+f25[i]+f26[i])-0.5*force[3*i+1])/(1.0-v1);
    f5[i]=f18[i]+rho*((c2-c4*v2v2)*(v1-v0)+(c6-0.5*v2v2)*(v0v0*v1-v0*v1v1));
    f12[i]=f25[i]+rho*(c3*(-v0+v1-v2)+c7*(v0v0*(v1-v2)-v1v1*(v0+v2)-v2v2*(v0-v1))+0.25*v0v1v2*(1.0-v0*v1+v0*v2-v1*v2));
    f13[i]=f26[i]+rho*(c3*(-v0+v1+v2)+c7*(v0v0*(v1+v2)-v1v1*(v0-v2)-v2v2*(v0-v1))-0.25*v0v1v2*(1.0-v0*v1-v0*v2+v1*v2));
    f15[i]=f2[i]+rho*v1*(c1-c5*(v0v0+v2v2)+v0v0*v2v2);
    f17[i]=f4[i]+rho*((c2-c4*v2v2)*(v0+v1)+(c6-0.5*v2v2)*(v0v0*v1+v0*v1v1));
    f21[i]=f8[i]+rho*((c2-c4*v0v0)*(v1+v2)+(c6-0.5*v0v0)*(v1v1*v2+v1*v2v2));
    f22[i]=f9[i]+rho*((c2-c4*v0v0)*(v1-v2)-(c6-0.5*v0v0)*(v1v1*v2-v1*v2v2));
    f23[i]=f10[i]+rho*(c3*(v0+v1+v2)+c7*(v0v0*(v1+v2)+v1v1*(v0+v2)+v2v2*(v0+v1))+0.25*v0v1v2*(1.0+v0*v1+v0*v2+v1*v2));
    f24[i]=f11[i]+rho*(c3*(v0+v1-v2)+c7*(v0v0*(v1-v2)+v1v1*(v0-v2)+v2v2*(v0+v1))-0.25*v0v1v2*(1.0+v0*v1-v0*v2-v1*v2));
  }
  return 0;
}

int fD3Q27VCECLBESimpleZouHe(double *p, double v0, double v1, double v2, double *force, double *f0, double *f1, double *f2,
                             double *f3, double *f4, double *f5, double *f6, double *f7, double *f8,
                             double *f9, double *f10, double *f11, double *f12, double *f13, double *f14,
                             double *f15, double *f16, double *f17, double *f18, double *f19, double *f20,
                             double *f21, double *f22, double *f23, double *f24, double *f25, double *f26)
{

  // produce fixed velocity for compressible fluids at concave edge boundary:
  // expressed for bottom left edge (VCETR) with higher-order equilibrium
  // distribution functions for CLBE collisions
  
  double q0, qxy, qz;
  double c0=1.0/3.0,c1=4.0/9.0,c2=1.0/9.0,c3=1.0/36.0,c4=1.0/12.0,c5=1.0/72.0,c6=1.0/24.0,c7=1.0/6.0,c8=5.0/72.0,c9=1.0/48.0,c12=2.0/3.0;
    
  double v0v0 = v0*v0;
  double v1v1 = v1*v1;
  double v2v2 = v2*v2;
  double v0v1v2 = v0*v1*v2;
    
  for(int i=0; i<lbsy.nf; i++) {
    q0 = c4*(p[i]-f0[i]-f3[i]-f16[i])-c7*(f1[i]+f2[i]+f4[i]+f6[i]+f7[i]+f8[i]+f9[i]+f10[i]+f11[i])-p[i]*(c8*(v0+v1)+c3*(v0v0*v1+v1v1*v0)-c5*v2v2*(v0+v1)-c6*v2v2*(v0v0*v1+v1v1*v0));
    qxy = p[i]*(v0-v1)*(c5-c6*v0*v1)+c9*(force[3*i+1]-force[3*i]);
    qz = 0.25*(f3[i]-f16[i])+0.125*p[i]*v2*(1.0-v0v0-v1v1-v0*v1+3.0*v0v0*v1v1)-0.125*force[3*i+2];
    f5[i]=4.0*(q0-qxy);
    f12[i]=q0-qxy-qz;
    f13[i]=q0-qxy+qz;
    f14[i]=f1[i]+p[i]*v0*(c1-c12*(v1v1+v2v2)+v1v1*v2v2);
    f15[i]=f2[i]+p[i]*v1*(c1-c12*(v0v0+v2v2)+v0v0*v2v2);
    f17[i]=f4[i]+p[i]*(v0*(c2+c0*v1v1-c7*v2v2-0.5*v1v1*v2v2)+v1*(c2+c0*v0v0-c7*v2v2-0.5*v0v0*v2v2));
    f18[i]=4.0*(q0+qxy);
    f19[i]=f6[i]+p[i]*(v0*(c2+c0*v2v2-c7*v1v1-0.5*v1v1*v2v2)+v2*(c2+c0*v0v0-c7*v1v1-0.5*v0v0*v1v1));
    f20[i]=f7[i]+p[i]*(v0*(c2+c0*v2v2-c7*v1v1-0.5*v1v1*v2v2)-v2*(c2+c0*v0v0-c7*v1v1-0.5*v0v0*v1v1));
    f21[i]=f8[i]+p[i]*(v1*(c2+c0*v2v2-c7*v0v0-0.5*v0v0*v2v2)+v2*(c2+c0*v1v1-c7*v0v0-0.5*v0v0*v1v1));
    f22[i]=f9[i]+p[i]*(v1*(c2+c0*v2v2-c7*v0v0-0.5*v0v0*v2v2)-v2*(c2+c0*v1v1-c7*v0v0-0.5*v0v0*v1v1));
    f23[i]=f10[i]+p[i]*(v0*(c3+c4*(v1v1+v2v2)+0.25*v1v1*v2v2)+v1*(c3+c4*(v0v0+v2v2)+0.25*v0v0*v2v2)+v2*(c3+c4*(v0v0+v1v1)+0.25*v0v0*v1v1)+0.25*v0v1v2);
    f24[i]=f11[i]+p[i]*(v0*(c3+c4*(v1v1+v2v2)+0.25*v1v1*v2v2)+v1*(c3+c4*(v0v0+v2v2)+0.25*v0v0*v2v2)-v2*(c3+c4*(v0v0+v1v1)+0.25*v0v0*v1v1)-0.25*v0v1v2);
    f25[i]=q0+qxy+qz;
    f26[i]=q0+qxy-qz;
  }
  return 0;
}

int fD3Q27VCCCLBESimpleZouHe(double *p, double v0, double v1, double v2, double *force, double *f0, double *f1, double *f2,
                             double *f3, double *f4, double *f5, double *f6, double *f7, double *f8,
                             double *f9, double *f10, double *f11, double *f12, double *f13, double *f14,
                             double *f15, double *f16, double *f17, double *f18, double *f19, double *f20,
                             double *f21, double *f22, double *f23, double *f24, double *f25, double *f26)
{

  // produce fixed velocity for compressible fluids at concave corner boundary:
  // expressed for bottom left back corner (VCCTRF) with higher-order equilibrium
  // distribution functions for CLBE collisions

  double q0, qx, qy, qz;
  double c0=1.0/3.0,c1=4.0/9.0,c2=1.0/9.0,c3=1.0/36.0,c4=1.0/30.0,c5=1.0/72.0,c6=1.0/120.0,c7=1.0/15.0,c8=5.0/216.0,c10=5.0/192.0,c11=1.0/6.0,c12=2.0/3.0;

  double v0v0 = v0*v0;
  double v1v1 = v1*v1;
  double v2v2 = v2*v2;
  double v0v1v2 = v0*v1*v2;

  for(int i=0; i<lbsy.nf; i++) {
    q0 = c4*(p[i]-f0[i])-c7*(f1[i]+f2[i]+f3[i]+f4[i]+f6[i]+f8[i]+f10[i])-p[i]*(v0*(c8-c5*(v1v1+v2v2)+c6*v1v1*v2v2)+v1*(c8-c5*(v0v0+v2v2)+c6*v0v0*v2v2)+v2*(c8-c5*(v0v0+v1v1)+c6*v0v0*v1v1)+c6*v0v1v2);
    qx = p[i]*v0*(c5+c10*(v1v1+v2v2)-0.03125*v1v1*v2v2)+p[i]*(v1+v2)*(0.015625*v1*v2+0.046875*v0v0*v1*v2)-0.125*p[i]*v0v1v2-0.09375*force[3*i  ]-0.078125*(force[3*i+1]+force[3*i+2]);
    qy = p[i]*v1*(c5+c10*(v0v0+v2v2)-0.03125*v0v0*v2v2)+p[i]*(v0+v2)*(0.015625*v0*v2+0.046875*v0*v1v1*v2)-0.125*p[i]*v0v1v2-0.09375*force[3*i+1]-0.078125*(force[3*i  ]+force[3*i+2]);
    qz = p[i]*v2*(c5+c10*(v0v0+v1v1)-0.03125*v0v0*v1v1)+p[i]*(v0+v1)*(0.015625*v0*v1+0.046875*v0*v1*v2v2)-0.125*p[i]*v0v1v2-0.09375*force[3*i+2]-0.078125*(force[3*i  ]+force[3*i+1]);
    f5[i]=4.0*(q0-qx+qy);
    f7[i]=4.0*(q0-qx+qz);
    f9[i]=4.0*(q0-qy+qz);
    f11[i]=q0-qx-qy+qz;
    f12[i]=q0-qx+qy-qz;
    f13[i]=q0-qx+qy+qz;
    f14[i]=f1[i]+p[i]*v0*(c1-c12*(v1v1+v2v2)+v1v1*v2v2);
    f15[i]=f2[i]+p[i]*v1*(c1-c12*(v0v0+v2v2)+v0v0*v2v2);
    f16[i]=f3[i]+p[i]*v2*(c1-c12*(v0v0+v1v1)+v0v0*v1v1);
    f17[i]=f4[i]+p[i]*(v0*(c2+c0*v1v1-c11*v2v2-0.5*v1v1*v2v2)+v1*(c2+c0*v0v0-c7*v2v2-0.5*v0v0*v2v2));
    f18[i]=4.0*(q0+qx-qy);
    f19[i]=f6[i]+p[i]*(v0*(c2+c0*v2v2-c11*v1v1-0.5*v1v1*v2v2)+v2*(c2+c0*v0v0-c7*v1v1-0.5*v0v0*v1v1));
    f20[i]=4.0*(q0+qx-qz);
    f21[i]=f8[i]+p[i]*(v1*(c2+c0*v2v2-c11*v0v0-0.5*v0v0*v2v2)+v2*(c2+c0*v1v1-c7*v0v0-0.5*v0v0*v1v1));
    f22[i]=4.0*(q0+qy-qz);
    f23[i]=f10[i]+p[i]*(v0*(c3+c4*(v1v1+v2v2)+0.25*v1v1*v2v2)+v1*(c3+c4*(v0v0+v2v2)+0.25*v0v0*v2v2)+v2*(c3+c4*(v0v0+v1v1)+0.25*v0v0*v1v1)+0.25*v0v1v2);
    f24[i]=q0+qx+qx-qz;
    f25[i]=q0+qx-qy+qz;
    f26[i]=q0+qx-qy-qz;
  }
  return 0;
}

int fD3Q27VFZouHe(long tpos, long rpos, int prop, double *uwall)
{
  long spos=tpos * lbsitelength;
  int qdim=lbsy.nf+lbsy.nc+lbsy.nt;
  double force[3*lbsy.nf], rho[lbsy.nf];

  // sort out forces
    
  fD3Q27BoundaryForceVelocity(force, tpos, rpos, uwall, prop);
    
  // apply boundary condition

  if(prop>26)
    fGetAllMassSite(rho, &lbf[rpos*lbsitelength]);

  if (collide>11) {
    switch (prop) {
      case PST:
        fD3Q27VPSCLBEZouHe(uwall[0], uwall[1], uwall[2], &force[0], &lbf[spos], &lbf[spos+1*qdim],
                           &lbf[spos+2*qdim], &lbf[spos+3*qdim], &lbf[spos+4*qdim], &lbf[spos+5*qdim],
                           &lbf[spos+6*qdim], &lbf[spos+7*qdim], &lbf[spos+8*qdim], &lbf[spos+9*qdim],
                           &lbf[spos+10*qdim], &lbf[spos+11*qdim], &lbf[spos+12*qdim], &lbf[spos+13*qdim],
                           &lbf[spos+14*qdim], &lbf[spos+15*qdim], &lbf[spos+16*qdim], &lbf[spos+17*qdim],
                           &lbf[spos+18*qdim], &lbf[spos+19*qdim], &lbf[spos+20*qdim], &lbf[spos+21*qdim],
                           &lbf[spos+22*qdim], &lbf[spos+23*qdim], &lbf[spos+24*qdim], &lbf[spos+25*qdim],
                           &lbf[spos+26*qdim]);
        break;
      case PSD:
        fD3Q27VPSCLBEZouHe(-uwall[0], -uwall[1], -uwall[2], &force[0], &lbf[spos], &lbf[spos+14*qdim],
                           &lbf[spos+15*qdim], &lbf[spos+16*qdim], &lbf[spos+17*qdim], &lbf[spos+18*qdim],
                           &lbf[spos+19*qdim], &lbf[spos+20*qdim], &lbf[spos+21*qdim], &lbf[spos+22*qdim],
                           &lbf[spos+23*qdim], &lbf[spos+24*qdim], &lbf[spos+25*qdim], &lbf[spos+26*qdim],
                           &lbf[spos+1*qdim], &lbf[spos+2*qdim], &lbf[spos+3*qdim], &lbf[spos+4*qdim],
                           &lbf[spos+5*qdim], &lbf[spos+6*qdim], &lbf[spos+7*qdim], &lbf[spos+8*qdim],
                           &lbf[spos+9*qdim], &lbf[spos+10*qdim], &lbf[spos+11*qdim], &lbf[spos+12*qdim],
                           &lbf[spos+13*qdim]);
        break;
      case PSL:
        fD3Q27VPSCLBEZouHe(-uwall[2], -uwall[0], -uwall[1], &force[0], &lbf[spos], &lbf[spos+16*qdim],
                           &lbf[spos+14*qdim], &lbf[spos+15*qdim], &lbf[spos+19*qdim], &lbf[spos+7*qdim],
                           &lbf[spos+21*qdim], &lbf[spos+9*qdim], &lbf[spos+17*qdim], &lbf[spos+18*qdim],
                           &lbf[spos+23*qdim], &lbf[spos+25*qdim], &lbf[spos+13*qdim], &lbf[spos+11*qdim],
                           &lbf[spos+3*qdim], &lbf[spos+1*qdim], &lbf[spos+2*qdim], &lbf[spos+6*qdim],
                           &lbf[spos+20*qdim], &lbf[spos+8*qdim], &lbf[spos+22*qdim], &lbf[spos+4*qdim],
                           &lbf[spos+5*qdim], &lbf[spos+10*qdim], &lbf[spos+12*qdim], &lbf[spos+26*qdim],
                           &lbf[spos+24*qdim]);
        break;
      case PSR:
        fD3Q27VPSCLBEZouHe(uwall[2], uwall[0], uwall[1], &force[0], &lbf[spos], &lbf[spos+3*qdim],
                           &lbf[spos+1*qdim], &lbf[spos+2*qdim], &lbf[spos+6*qdim], &lbf[spos+20*qdim],
                           &lbf[spos+8*qdim], &lbf[spos+22*qdim], &lbf[spos+4*qdim], &lbf[spos+5*qdim],
                           &lbf[spos+10*qdim], &lbf[spos+12*qdim], &lbf[spos+26*qdim], &lbf[spos+24*qdim],
                           &lbf[spos+16*qdim], &lbf[spos+14*qdim], &lbf[spos+15*qdim], &lbf[spos+19*qdim],
                           &lbf[spos+7*qdim], &lbf[spos+21*qdim], &lbf[spos+9*qdim], &lbf[spos+17*qdim],
                           &lbf[spos+18*qdim], &lbf[spos+23*qdim], &lbf[spos+25*qdim], &lbf[spos+13*qdim],
                           &lbf[spos+11*qdim]);
        break;
      case PSF:
        fD3Q27VPSCLBEZouHe(-uwall[1], -uwall[2], -uwall[0], &force[0], &lbf[spos], &lbf[spos+15*qdim],
                           &lbf[spos+16*qdim], &lbf[spos+14*qdim], &lbf[spos+21*qdim], &lbf[spos+22*qdim],
                           &lbf[spos+17*qdim], &lbf[spos+5*qdim], &lbf[spos+19*qdim], &lbf[spos+7*qdim],
                           &lbf[spos+23*qdim], &lbf[spos+13*qdim], &lbf[spos+24*qdim], &lbf[spos+12*qdim],
                           &lbf[spos+2*qdim], &lbf[spos+3*qdim], &lbf[spos+1*qdim], &lbf[spos+8*qdim],
                           &lbf[spos+9*qdim], &lbf[spos+4*qdim], &lbf[spos+18*qdim], &lbf[spos+6*qdim],
                           &lbf[spos+20*qdim], &lbf[spos+10*qdim], &lbf[spos+26*qdim], &lbf[spos+11*qdim],
                           &lbf[spos+25*qdim]);
        break;
      case PSB:
        fD3Q27VPSCLBEZouHe(uwall[1], uwall[2], uwall[0], &force[0], &lbf[spos], &lbf[spos+2*qdim],
                           &lbf[spos+3*qdim], &lbf[spos+1*qdim], &lbf[spos+8*qdim], &lbf[spos+9*qdim],
                           &lbf[spos+4*qdim], &lbf[spos+18*qdim], &lbf[spos+6*qdim], &lbf[spos+20*qdim],
                           &lbf[spos+10*qdim], &lbf[spos+26*qdim], &lbf[spos+11*qdim], &lbf[spos+25*qdim],
                           &lbf[spos+15*qdim], &lbf[spos+16*qdim], &lbf[spos+14*qdim], &lbf[spos+21*qdim],
                           &lbf[spos+22*qdim], &lbf[spos+17*qdim], &lbf[spos+5*qdim], &lbf[spos+19*qdim],
                           &lbf[spos+7*qdim], &lbf[spos+23*qdim], &lbf[spos+13*qdim], &lbf[spos+24*qdim],
                           &lbf[spos+12*qdim]);
        break;
      case CCTRB:
        fD3Q27VCCCLBEZouHe(rho, uwall[0], uwall[1], -uwall[2], &force[0], &lbf[spos], &lbf[spos+1*qdim],
                           &lbf[spos+2*qdim], &lbf[spos+16*qdim], &lbf[spos+4*qdim], &lbf[spos+5*qdim],
                           &lbf[spos+7*qdim], &lbf[spos+6*qdim], &lbf[spos+9*qdim], &lbf[spos+8*qdim],
                           &lbf[spos+11*qdim], &lbf[spos+10*qdim], &lbf[spos+13*qdim], &lbf[spos+12*qdim],
                           &lbf[spos+14*qdim], &lbf[spos+15*qdim], &lbf[spos+3*qdim], &lbf[spos+17*qdim],
                           &lbf[spos+18*qdim], &lbf[spos+20*qdim], &lbf[spos+19*qdim], &lbf[spos+22*qdim],
                           &lbf[spos+21*qdim], &lbf[spos+24*qdim], &lbf[spos+23*qdim], &lbf[spos+26*qdim],
                           &lbf[spos+25*qdim]);
        break;
      case CCTLB:
        fD3Q27VCCCLBEZouHe(rho, -uwall[0], uwall[1], -uwall[2], &force[0], &lbf[spos], &lbf[spos+14*qdim],
                           &lbf[spos+2*qdim], &lbf[spos+16*qdim], &lbf[spos+18*qdim], &lbf[spos+17*qdim],
                           &lbf[spos+19*qdim], &lbf[spos+20*qdim], &lbf[spos+9*qdim], &lbf[spos+8*qdim],
                           &lbf[spos+25*qdim], &lbf[spos+26*qdim], &lbf[spos+23*qdim], &lbf[spos+24*qdim],
                           &lbf[spos+1*qdim], &lbf[spos+15*qdim], &lbf[spos+3*qdim], &lbf[spos+5*qdim],
                           &lbf[spos+4*qdim], &lbf[spos+6*qdim], &lbf[spos+7*qdim], &lbf[spos+22*qdim],
                           &lbf[spos+21*qdim], &lbf[spos+12*qdim], &lbf[spos+13*qdim], &lbf[spos+10*qdim],
                           &lbf[spos+11*qdim]);
        break;
      case CCDLB:
        fD3Q27VCCCLBEZouHe(rho, -uwall[0], -uwall[1], -uwall[2], &force[0], &lbf[spos], &lbf[spos+14*qdim],
                           &lbf[spos+15*qdim], &lbf[spos+16*qdim], &lbf[spos+17*qdim], &lbf[spos+18*qdim],
                           &lbf[spos+19*qdim], &lbf[spos+20*qdim], &lbf[spos+21*qdim], &lbf[spos+22*qdim],
                           &lbf[spos+23*qdim], &lbf[spos+24*qdim], &lbf[spos+25*qdim], &lbf[spos+26*qdim],
                           &lbf[spos+1*qdim], &lbf[spos+2*qdim], &lbf[spos+3*qdim], &lbf[spos+4*qdim],
                           &lbf[spos+5*qdim], &lbf[spos+6*qdim], &lbf[spos+7*qdim], &lbf[spos+8*qdim],
                           &lbf[spos+9*qdim], &lbf[spos+10*qdim], &lbf[spos+11*qdim], &lbf[spos+12*qdim],
                           &lbf[spos+13*qdim]);
        break;
      case CCDRB:
        fD3Q27VCCCLBEZouHe(rho, uwall[0], -uwall[1], -uwall[2], &force[0], &lbf[spos], &lbf[spos+1*qdim],
                           &lbf[spos+15*qdim], &lbf[spos+16*qdim], &lbf[spos+5*qdim], &lbf[spos+4*qdim],
                           &lbf[spos+7*qdim], &lbf[spos+6*qdim], &lbf[spos+21*qdim], &lbf[spos+22*qdim],
                           &lbf[spos+13*qdim], &lbf[spos+12*qdim], &lbf[spos+11*qdim], &lbf[spos+10*qdim],
                           &lbf[spos+14*qdim], &lbf[spos+2*qdim], &lbf[spos+3*qdim], &lbf[spos+18*qdim],
                           &lbf[spos+17*qdim], &lbf[spos+20*qdim], &lbf[spos+19*qdim], &lbf[spos+8*qdim],
                           &lbf[spos+9*qdim], &lbf[spos+26*qdim], &lbf[spos+25*qdim], &lbf[spos+24*qdim],
                           &lbf[spos+23*qdim]);
        break;
      case CCTRF:
        fD3Q27VCCCLBEZouHe(rho, uwall[0], uwall[1], uwall[2], &force[0], &lbf[spos], &lbf[spos+1*qdim],
                           &lbf[spos+2*qdim], &lbf[spos+3*qdim], &lbf[spos+4*qdim], &lbf[spos+5*qdim],
                           &lbf[spos+6*qdim], &lbf[spos+7*qdim], &lbf[spos+8*qdim], &lbf[spos+9*qdim],
                           &lbf[spos+10*qdim], &lbf[spos+11*qdim], &lbf[spos+12*qdim], &lbf[spos+13*qdim],
                           &lbf[spos+14*qdim], &lbf[spos+15*qdim], &lbf[spos+16*qdim], &lbf[spos+17*qdim],
                           &lbf[spos+18*qdim], &lbf[spos+19*qdim], &lbf[spos+20*qdim], &lbf[spos+21*qdim],
                           &lbf[spos+22*qdim], &lbf[spos+23*qdim], &lbf[spos+24*qdim], &lbf[spos+25*qdim],
                           &lbf[spos+26*qdim]);
        break;
      case CCTLF:
        fD3Q27VCCCLBEZouHe(rho, -uwall[0], uwall[1], uwall[2], &force[0], &lbf[spos], &lbf[spos+14*qdim],
                           &lbf[spos+2*qdim], &lbf[spos+3*qdim], &lbf[spos+18*qdim], &lbf[spos+17*qdim],
                           &lbf[spos+20*qdim], &lbf[spos+19*qdim], &lbf[spos+8*qdim], &lbf[spos+9*qdim],
                           &lbf[spos+26*qdim], &lbf[spos+25*qdim], &lbf[spos+24*qdim], &lbf[spos+23*qdim],
                           &lbf[spos+1*qdim], &lbf[spos+15*qdim], &lbf[spos+16*qdim], &lbf[spos+5*qdim],
                           &lbf[spos+4*qdim], &lbf[spos+7*qdim], &lbf[spos+6*qdim], &lbf[spos+21*qdim],
                           &lbf[spos+22*qdim], &lbf[spos+13*qdim], &lbf[spos+12*qdim], &lbf[spos+11*qdim],
                           &lbf[spos+10*qdim]);
        break;
      case CCDLF:
        fD3Q27VCCCLBEZouHe(rho, -uwall[0], -uwall[1], uwall[2], &force[0], &lbf[spos], &lbf[spos+14*qdim],
                           &lbf[spos+15*qdim], &lbf[spos+3*qdim], &lbf[spos+17*qdim], &lbf[spos+18*qdim],
                           &lbf[spos+20*qdim], &lbf[spos+19*qdim], &lbf[spos+22*qdim], &lbf[spos+21*qdim],
                           &lbf[spos+24*qdim], &lbf[spos+23*qdim], &lbf[spos+26*qdim], &lbf[spos+25*qdim],
                           &lbf[spos+1*qdim], &lbf[spos+2*qdim], &lbf[spos+16*qdim], &lbf[spos+4*qdim],
                           &lbf[spos+5*qdim], &lbf[spos+7*qdim], &lbf[spos+6*qdim], &lbf[spos+9*qdim],
                           &lbf[spos+8*qdim], &lbf[spos+11*qdim], &lbf[spos+10*qdim], &lbf[spos+13*qdim],
                           &lbf[spos+12*qdim]);
        break;
      case CCDRF:
        fD3Q27VCCCLBEZouHe(rho, uwall[0], -uwall[1], uwall[2], &force[0], &lbf[spos], &lbf[spos+1*qdim],
                           &lbf[spos+15*qdim], &lbf[spos+3*qdim], &lbf[spos+5*qdim], &lbf[spos+4*qdim],
                           &lbf[spos+6*qdim], &lbf[spos+7*qdim], &lbf[spos+22*qdim], &lbf[spos+21*qdim],
                           &lbf[spos+12*qdim], &lbf[spos+13*qdim], &lbf[spos+10*qdim], &lbf[spos+11*qdim],
                           &lbf[spos+14*qdim], &lbf[spos+2*qdim], &lbf[spos+16*qdim], &lbf[spos+18*qdim],
                           &lbf[spos+17*qdim], &lbf[spos+19*qdim], &lbf[spos+20*qdim], &lbf[spos+9*qdim],
                           &lbf[spos+8*qdim], &lbf[spos+25*qdim], &lbf[spos+26*qdim], &lbf[spos+23*qdim],
                           &lbf[spos+24*qdim]);
        break;
      case CETR:
        fD3Q27VCECLBEZouHe(rho, uwall[0], uwall[1], uwall[2], &force[0], &lbf[spos], &lbf[spos+1*qdim],
                           &lbf[spos+2*qdim], &lbf[spos+3*qdim], &lbf[spos+4*qdim], &lbf[spos+5*qdim],
                           &lbf[spos+6*qdim], &lbf[spos+7*qdim], &lbf[spos+8*qdim], &lbf[spos+9*qdim],
                           &lbf[spos+10*qdim], &lbf[spos+11*qdim], &lbf[spos+12*qdim], &lbf[spos+13*qdim],
                           &lbf[spos+14*qdim], &lbf[spos+15*qdim], &lbf[spos+16*qdim], &lbf[spos+17*qdim],
                           &lbf[spos+18*qdim], &lbf[spos+19*qdim], &lbf[spos+20*qdim], &lbf[spos+21*qdim],
                           &lbf[spos+22*qdim], &lbf[spos+23*qdim], &lbf[spos+24*qdim], &lbf[spos+25*qdim],
                           &lbf[spos+26*qdim]);
        break;
      case CETL:
        fD3Q27VCECLBEZouHe(rho, uwall[1], -uwall[0], uwall[2], &force[0], &lbf[spos], &lbf[spos+2*qdim],
                           &lbf[spos+14*qdim], &lbf[spos+3*qdim], &lbf[spos+18*qdim], &lbf[spos+4*qdim],
                           &lbf[spos+8*qdim], &lbf[spos+9*qdim], &lbf[spos+20*qdim], &lbf[spos+19*qdim],
                           &lbf[spos+26*qdim], &lbf[spos+25*qdim], &lbf[spos+10*qdim], &lbf[spos+11*qdim],
                           &lbf[spos+15*qdim], &lbf[spos+1*qdim], &lbf[spos+16*qdim], &lbf[spos+5*qdim],
                           &lbf[spos+17*qdim], &lbf[spos+21*qdim], &lbf[spos+22*qdim], &lbf[spos+7*qdim],
                           &lbf[spos+6*qdim], &lbf[spos+13*qdim], &lbf[spos+12*qdim], &lbf[spos+23*qdim],
                           &lbf[spos+24*qdim]);
        break;
      case CEDL:
        fD3Q27VCECLBEZouHe(rho, -uwall[0], -uwall[1], uwall[2], &force[0], &lbf[spos], &lbf[spos+14*qdim],
                           &lbf[spos+15*qdim], &lbf[spos+3*qdim], &lbf[spos+17*qdim], &lbf[spos+18*qdim],
                           &lbf[spos+20*qdim], &lbf[spos+19*qdim], &lbf[spos+22*qdim], &lbf[spos+21*qdim],
                           &lbf[spos+24*qdim], &lbf[spos+23*qdim], &lbf[spos+26*qdim], &lbf[spos+25*qdim],
                           &lbf[spos+1*qdim], &lbf[spos+2*qdim], &lbf[spos+16*qdim], &lbf[spos+4*qdim],
                           &lbf[spos+5*qdim], &lbf[spos+7*qdim], &lbf[spos+6*qdim], &lbf[spos+9*qdim],
                           &lbf[spos+8*qdim], &lbf[spos+11*qdim], &lbf[spos+10*qdim], &lbf[spos+13*qdim],
                           &lbf[spos+12*qdim]);
        break;
      case CEDR:
        fD3Q27VCECLBEZouHe(rho, -uwall[1], uwall[0], uwall[2], &force[0], &lbf[spos], &lbf[spos+15*qdim],
                           &lbf[spos+1*qdim], &lbf[spos+3*qdim], &lbf[spos+5*qdim], &lbf[spos+17*qdim],
                           &lbf[spos+22*qdim], &lbf[spos+21*qdim], &lbf[spos+6*qdim], &lbf[spos+7*qdim],
                           &lbf[spos+12*qdim], &lbf[spos+13*qdim], &lbf[spos+24*qdim], &lbf[spos+23*qdim],
                           &lbf[spos+2*qdim], &lbf[spos+14*qdim], &lbf[spos+16*qdim], &lbf[spos+18*qdim],
                           &lbf[spos+4*qdim], &lbf[spos+9*qdim], &lbf[spos+8*qdim], &lbf[spos+19*qdim],
                           &lbf[spos+20*qdim], &lbf[spos+25*qdim], &lbf[spos+26*qdim], &lbf[spos+11*qdim],
                           &lbf[spos+10*qdim]);
        break;
      case CETF:
        fD3Q27VCECLBEZouHe(rho, uwall[1], uwall[2], uwall[0], &force[0], &lbf[spos], &lbf[spos+2*qdim],
                           &lbf[spos+3*qdim], &lbf[spos+1*qdim], &lbf[spos+8*qdim], &lbf[spos+9*qdim],
                           &lbf[spos+4*qdim], &lbf[spos+18*qdim], &lbf[spos+6*qdim], &lbf[spos+20*qdim],
                           &lbf[spos+10*qdim], &lbf[spos+26*qdim], &lbf[spos+11*qdim], &lbf[spos+25*qdim],
                           &lbf[spos+15*qdim], &lbf[spos+16*qdim], &lbf[spos+14*qdim], &lbf[spos+21*qdim],
                           &lbf[spos+22*qdim], &lbf[spos+17*qdim], &lbf[spos+5*qdim], &lbf[spos+19*qdim],
                           &lbf[spos+7*qdim], &lbf[spos+23*qdim], &lbf[spos+13*qdim], &lbf[spos+24*qdim],
                           &lbf[spos+12*qdim]);
        break;
      case CELF:
        fD3Q27VCECLBEZouHe(rho, -uwall[0], uwall[1], uwall[2], &force[0], &lbf[spos], &lbf[spos+14*qdim],
                           &lbf[spos+3*qdim], &lbf[spos+2*qdim], &lbf[spos+20*qdim], &lbf[spos+19*qdim],
                           &lbf[spos+18*qdim], &lbf[spos+17*qdim], &lbf[spos+8*qdim], &lbf[spos+22*qdim],
                           &lbf[spos+26*qdim], &lbf[spos+24*qdim], &lbf[spos+25*qdim], &lbf[spos+23*qdim],
                           &lbf[spos+1*qdim], &lbf[spos+16*qdim], &lbf[spos+15*qdim], &lbf[spos+7*qdim],
                           &lbf[spos+6*qdim], &lbf[spos+5*qdim], &lbf[spos+4*qdim], &lbf[spos+21*qdim],
                           &lbf[spos+9*qdim], &lbf[spos+13*qdim], &lbf[spos+11*qdim], &lbf[spos+12*qdim],
                           &lbf[spos+10*qdim]);
        break;
      case CEDF:
        fD3Q27VCECLBEZouHe(rho, -uwall[1], uwall[2], uwall[0], &force[0], &lbf[spos], &lbf[spos+15*qdim],
                           &lbf[spos+3*qdim], &lbf[spos+1*qdim], &lbf[spos+22*qdim], &lbf[spos+21*qdim],
                           &lbf[spos+5*qdim], &lbf[spos+17*qdim], &lbf[spos+6*qdim], &lbf[spos+20*qdim],
                           &lbf[spos+12*qdim], &lbf[spos+24*qdim], &lbf[spos+13*qdim], &lbf[spos+23*qdim],
                           &lbf[spos+2*qdim], &lbf[spos+16*qdim], &lbf[spos+14*qdim], &lbf[spos+9*qdim],
                           &lbf[spos+8*qdim], &lbf[spos+18*qdim], &lbf[spos+4*qdim], &lbf[spos+19*qdim],
                           &lbf[spos+7*qdim], &lbf[spos+25*qdim], &lbf[spos+11*qdim], &lbf[spos+26*qdim],
                           &lbf[spos+10*qdim]);
        break;
      case CERF:
        fD3Q27VCECLBEZouHe(rho, uwall[0], uwall[2], uwall[2], &force[0], &lbf[spos], &lbf[spos+1*qdim],
                           &lbf[spos+3*qdim], &lbf[spos+2*qdim], &lbf[spos+6*qdim], &lbf[spos+7*qdim],
                           &lbf[spos+4*qdim], &lbf[spos+5*qdim], &lbf[spos+8*qdim], &lbf[spos+22*qdim],
                           &lbf[spos+10*qdim], &lbf[spos+12*qdim], &lbf[spos+11*qdim], &lbf[spos+13*qdim],
                           &lbf[spos+14*qdim], &lbf[spos+16*qdim], &lbf[spos+15*qdim], &lbf[spos+19*qdim],
                           &lbf[spos+20*qdim], &lbf[spos+17*qdim], &lbf[spos+18*qdim], &lbf[spos+21*qdim],
                           &lbf[spos+9*qdim], &lbf[spos+23*qdim], &lbf[spos+25*qdim], &lbf[spos+24*qdim],
                           &lbf[spos+26*qdim]);
        break;
      case CETB:
        fD3Q27VCECLBEZouHe(rho, uwall[1], -uwall[2], uwall[0], &force[0], &lbf[spos], &lbf[spos+2*qdim],
                           &lbf[spos+16*qdim], &lbf[spos+1*qdim], &lbf[spos+9*qdim], &lbf[spos+8*qdim],
                           &lbf[spos+4*qdim], &lbf[spos+18*qdim], &lbf[spos+7*qdim], &lbf[spos+19*qdim],
                           &lbf[spos+11*qdim], &lbf[spos+25*qdim], &lbf[spos+10*qdim], &lbf[spos+26*qdim],
                           &lbf[spos+15*qdim], &lbf[spos+3*qdim], &lbf[spos+14*qdim], &lbf[spos+22*qdim],
                           &lbf[spos+21*qdim], &lbf[spos+17*qdim], &lbf[spos+5*qdim], &lbf[spos+20*qdim],
                           &lbf[spos+6*qdim], &lbf[spos+24*qdim], &lbf[spos+12*qdim], &lbf[spos+23*qdim],
                           &lbf[spos+13*qdim]);
        break;
      case CELB:
        fD3Q27VCECLBEZouHe(rho, -uwall[0], -uwall[2], uwall[1], &force[0], &lbf[spos], &lbf[spos+14*qdim],
                           &lbf[spos+16*qdim], &lbf[spos+2*qdim], &lbf[spos+19*qdim], &lbf[spos+20*qdim],
                           &lbf[spos+18*qdim], &lbf[spos+17*qdim], &lbf[spos+9*qdim], &lbf[spos+21*qdim],
                           &lbf[spos+25*qdim], &lbf[spos+23*qdim], &lbf[spos+26*qdim], &lbf[spos+24*qdim],
                           &lbf[spos+1*qdim], &lbf[spos+3*qdim], &lbf[spos+15*qdim], &lbf[spos+6*qdim],
                           &lbf[spos+7*qdim], &lbf[spos+5*qdim], &lbf[spos+4*qdim], &lbf[spos+22*qdim],
                           &lbf[spos+8*qdim], &lbf[spos+12*qdim], &lbf[spos+10*qdim], &lbf[spos+13*qdim],
                           &lbf[spos+11*qdim]);
        break;
      case CEDB:
        fD3Q27VCECLBEZouHe(rho, -uwall[1], -uwall[2], uwall[0], &force[0], &lbf[spos], &lbf[spos+15*qdim],
                           &lbf[spos+16*qdim], &lbf[spos+1*qdim], &lbf[spos+21*qdim], &lbf[spos+22*qdim],
                           &lbf[spos+5*qdim], &lbf[spos+17*qdim], &lbf[spos+7*qdim], &lbf[spos+19*qdim],
                           &lbf[spos+13*qdim], &lbf[spos+23*qdim], &lbf[spos+12*qdim], &lbf[spos+24*qdim],
                           &lbf[spos+2*qdim], &lbf[spos+3*qdim], &lbf[spos+14*qdim], &lbf[spos+8*qdim],
                           &lbf[spos+9*qdim], &lbf[spos+18*qdim], &lbf[spos+4*qdim], &lbf[spos+20*qdim],
                           &lbf[spos+6*qdim], &lbf[spos+26*qdim], &lbf[spos+10*qdim], &lbf[spos+25*qdim],
                           &lbf[spos+11*qdim]);
        break;
      case CERB:
        fD3Q27VCECLBEZouHe(rho, uwall[0], -uwall[2], uwall[1], &force[0], &lbf[spos], &lbf[spos+1*qdim],
                           &lbf[spos+16*qdim], &lbf[spos+2*qdim], &lbf[spos+7*qdim], &lbf[spos+6*qdim],
                           &lbf[spos+4*qdim], &lbf[spos+5*qdim], &lbf[spos+9*qdim], &lbf[spos+21*qdim],
                           &lbf[spos+11*qdim], &lbf[spos+13*qdim], &lbf[spos+10*qdim], &lbf[spos+12*qdim],
                           &lbf[spos+14*qdim], &lbf[spos+3*qdim], &lbf[spos+15*qdim], &lbf[spos+20*qdim],
                           &lbf[spos+19*qdim], &lbf[spos+17*qdim], &lbf[spos+18*qdim], &lbf[spos+22*qdim],
                           &lbf[spos+8*qdim], &lbf[spos+24*qdim], &lbf[spos+26*qdim], &lbf[spos+23*qdim],
                           &lbf[spos+25*qdim]);
        break;
    }
  }
  else {
    switch (prop) {
      case PST:
        fD3Q27VPSZouHe(uwall[0], uwall[1], uwall[2], &force[0], &lbf[spos], &lbf[spos+1*qdim],
                       &lbf[spos+2*qdim], &lbf[spos+3*qdim], &lbf[spos+4*qdim], &lbf[spos+5*qdim],
                       &lbf[spos+6*qdim], &lbf[spos+7*qdim], &lbf[spos+8*qdim], &lbf[spos+9*qdim],
                       &lbf[spos+10*qdim], &lbf[spos+11*qdim], &lbf[spos+12*qdim], &lbf[spos+13*qdim],
                       &lbf[spos+14*qdim], &lbf[spos+15*qdim], &lbf[spos+16*qdim], &lbf[spos+17*qdim],
                       &lbf[spos+18*qdim], &lbf[spos+19*qdim], &lbf[spos+20*qdim], &lbf[spos+21*qdim],
                       &lbf[spos+22*qdim], &lbf[spos+23*qdim], &lbf[spos+24*qdim], &lbf[spos+25*qdim],
                       &lbf[spos+26*qdim]);
        break;
      case PSD:
        fD3Q27VPSZouHe(-uwall[0], -uwall[1], -uwall[2], &force[0], &lbf[spos], &lbf[spos+14*qdim],
                       &lbf[spos+15*qdim], &lbf[spos+16*qdim], &lbf[spos+17*qdim], &lbf[spos+18*qdim],
                       &lbf[spos+19*qdim], &lbf[spos+20*qdim], &lbf[spos+21*qdim], &lbf[spos+22*qdim],
                       &lbf[spos+23*qdim], &lbf[spos+24*qdim], &lbf[spos+25*qdim], &lbf[spos+26*qdim],
                       &lbf[spos+1*qdim], &lbf[spos+2*qdim], &lbf[spos+3*qdim], &lbf[spos+4*qdim],
                       &lbf[spos+5*qdim], &lbf[spos+6*qdim], &lbf[spos+7*qdim], &lbf[spos+8*qdim],
                       &lbf[spos+9*qdim], &lbf[spos+10*qdim], &lbf[spos+11*qdim], &lbf[spos+12*qdim],
                       &lbf[spos+13*qdim]);
        break;
      case PSL:
        fD3Q27VPSZouHe(-uwall[2], -uwall[0], -uwall[1], &force[0], &lbf[spos], &lbf[spos+16*qdim],
                       &lbf[spos+14*qdim], &lbf[spos+15*qdim], &lbf[spos+19*qdim], &lbf[spos+7*qdim],
                       &lbf[spos+21*qdim], &lbf[spos+9*qdim], &lbf[spos+17*qdim], &lbf[spos+18*qdim],
                       &lbf[spos+23*qdim], &lbf[spos+25*qdim], &lbf[spos+13*qdim], &lbf[spos+11*qdim],
                       &lbf[spos+3*qdim], &lbf[spos+1*qdim], &lbf[spos+2*qdim], &lbf[spos+6*qdim],
                       &lbf[spos+20*qdim], &lbf[spos+8*qdim], &lbf[spos+22*qdim], &lbf[spos+4*qdim],
                       &lbf[spos+5*qdim], &lbf[spos+10*qdim], &lbf[spos+12*qdim], &lbf[spos+26*qdim],
                       &lbf[spos+24*qdim]);
        break;
      case PSR:
        fD3Q27VPSZouHe(uwall[2], uwall[0], uwall[1], &force[0], &lbf[spos], &lbf[spos+3*qdim],
                       &lbf[spos+1*qdim], &lbf[spos+2*qdim], &lbf[spos+6*qdim], &lbf[spos+20*qdim],
                       &lbf[spos+8*qdim], &lbf[spos+22*qdim], &lbf[spos+4*qdim], &lbf[spos+5*qdim],
                       &lbf[spos+10*qdim], &lbf[spos+12*qdim], &lbf[spos+26*qdim], &lbf[spos+24*qdim],
                       &lbf[spos+16*qdim], &lbf[spos+14*qdim], &lbf[spos+15*qdim], &lbf[spos+19*qdim],
                       &lbf[spos+7*qdim], &lbf[spos+21*qdim], &lbf[spos+9*qdim], &lbf[spos+17*qdim],
                       &lbf[spos+18*qdim], &lbf[spos+23*qdim], &lbf[spos+25*qdim], &lbf[spos+13*qdim],
                       &lbf[spos+11*qdim]);
        break;
      case PSF:
        fD3Q27VPSZouHe(-uwall[1], -uwall[2], -uwall[0], &force[0], &lbf[spos], &lbf[spos+15*qdim],
                       &lbf[spos+16*qdim], &lbf[spos+14*qdim], &lbf[spos+21*qdim], &lbf[spos+22*qdim],
                       &lbf[spos+17*qdim], &lbf[spos+5*qdim], &lbf[spos+19*qdim], &lbf[spos+7*qdim],
                       &lbf[spos+23*qdim], &lbf[spos+13*qdim], &lbf[spos+24*qdim], &lbf[spos+12*qdim],
                       &lbf[spos+2*qdim], &lbf[spos+3*qdim], &lbf[spos+1*qdim], &lbf[spos+8*qdim],
                       &lbf[spos+9*qdim], &lbf[spos+4*qdim], &lbf[spos+18*qdim], &lbf[spos+6*qdim],
                       &lbf[spos+20*qdim], &lbf[spos+10*qdim], &lbf[spos+26*qdim], &lbf[spos+11*qdim],
                       &lbf[spos+25*qdim]);
        break;
      case PSB:
        fD3Q27VPSZouHe(uwall[1], uwall[2], uwall[0], &force[0], &lbf[spos], &lbf[spos+2*qdim],
                       &lbf[spos+3*qdim], &lbf[spos+1*qdim], &lbf[spos+8*qdim], &lbf[spos+9*qdim],
                       &lbf[spos+4*qdim], &lbf[spos+18*qdim], &lbf[spos+6*qdim], &lbf[spos+20*qdim],
                       &lbf[spos+10*qdim], &lbf[spos+26*qdim], &lbf[spos+11*qdim], &lbf[spos+25*qdim],
                       &lbf[spos+15*qdim], &lbf[spos+16*qdim], &lbf[spos+14*qdim], &lbf[spos+21*qdim],
                       &lbf[spos+22*qdim], &lbf[spos+17*qdim], &lbf[spos+5*qdim], &lbf[spos+19*qdim],
                       &lbf[spos+7*qdim], &lbf[spos+23*qdim], &lbf[spos+13*qdim], &lbf[spos+24*qdim],
                       &lbf[spos+12*qdim]);
        break;
      case CCTRB:
        fD3Q27VCCZouHe(rho, uwall[0], uwall[1], -uwall[2], &force[0], &lbf[spos], &lbf[spos+1*qdim],
                       &lbf[spos+2*qdim], &lbf[spos+16*qdim], &lbf[spos+4*qdim], &lbf[spos+5*qdim],
                       &lbf[spos+7*qdim], &lbf[spos+6*qdim], &lbf[spos+9*qdim], &lbf[spos+8*qdim],
                       &lbf[spos+11*qdim], &lbf[spos+10*qdim], &lbf[spos+13*qdim], &lbf[spos+12*qdim],
                       &lbf[spos+14*qdim], &lbf[spos+15*qdim], &lbf[spos+3*qdim], &lbf[spos+17*qdim],
                       &lbf[spos+18*qdim], &lbf[spos+20*qdim], &lbf[spos+19*qdim], &lbf[spos+22*qdim],
                       &lbf[spos+21*qdim], &lbf[spos+24*qdim], &lbf[spos+23*qdim], &lbf[spos+26*qdim],
                       &lbf[spos+25*qdim]);
        break;
      case CCTLB:
        fD3Q27VCCZouHe(rho, -uwall[0], uwall[1], -uwall[2], &force[0], &lbf[spos], &lbf[spos+14*qdim],
                       &lbf[spos+2*qdim], &lbf[spos+16*qdim], &lbf[spos+18*qdim], &lbf[spos+17*qdim],
                       &lbf[spos+19*qdim], &lbf[spos+20*qdim], &lbf[spos+9*qdim], &lbf[spos+8*qdim],
                       &lbf[spos+25*qdim], &lbf[spos+26*qdim], &lbf[spos+23*qdim], &lbf[spos+24*qdim],
                       &lbf[spos+1*qdim], &lbf[spos+15*qdim], &lbf[spos+3*qdim], &lbf[spos+5*qdim],
                       &lbf[spos+4*qdim], &lbf[spos+6*qdim], &lbf[spos+7*qdim], &lbf[spos+22*qdim],
                       &lbf[spos+21*qdim], &lbf[spos+12*qdim], &lbf[spos+13*qdim], &lbf[spos+10*qdim],
                       &lbf[spos+11*qdim]);
        break;
      case CCDLB:
        fD3Q27VCCZouHe(rho, -uwall[0], -uwall[1], -uwall[2], &force[0], &lbf[spos], &lbf[spos+14*qdim],
                       &lbf[spos+15*qdim], &lbf[spos+16*qdim], &lbf[spos+17*qdim], &lbf[spos+18*qdim],
                       &lbf[spos+19*qdim], &lbf[spos+20*qdim], &lbf[spos+21*qdim], &lbf[spos+22*qdim],
                       &lbf[spos+23*qdim], &lbf[spos+24*qdim], &lbf[spos+25*qdim], &lbf[spos+26*qdim],
                       &lbf[spos+1*qdim], &lbf[spos+2*qdim], &lbf[spos+3*qdim], &lbf[spos+4*qdim],
                       &lbf[spos+5*qdim], &lbf[spos+6*qdim], &lbf[spos+7*qdim], &lbf[spos+8*qdim],
                       &lbf[spos+9*qdim], &lbf[spos+10*qdim], &lbf[spos+11*qdim], &lbf[spos+12*qdim],
                       &lbf[spos+13*qdim]);
        break;
      case CCDRB:
        fD3Q27VCCZouHe(rho, uwall[0], -uwall[1], -uwall[2], &force[0], &lbf[spos], &lbf[spos+1*qdim],
                       &lbf[spos+15*qdim], &lbf[spos+16*qdim], &lbf[spos+5*qdim], &lbf[spos+4*qdim],
                       &lbf[spos+7*qdim], &lbf[spos+6*qdim], &lbf[spos+21*qdim], &lbf[spos+22*qdim],
                       &lbf[spos+13*qdim], &lbf[spos+12*qdim], &lbf[spos+11*qdim], &lbf[spos+10*qdim],
                       &lbf[spos+14*qdim], &lbf[spos+2*qdim], &lbf[spos+3*qdim], &lbf[spos+18*qdim],
                       &lbf[spos+17*qdim], &lbf[spos+20*qdim], &lbf[spos+19*qdim], &lbf[spos+8*qdim],
                       &lbf[spos+9*qdim], &lbf[spos+26*qdim], &lbf[spos+25*qdim], &lbf[spos+24*qdim],
                       &lbf[spos+23*qdim]);
        break;
      case CCTRF:
        fD3Q27VCCZouHe(rho, uwall[0], uwall[1], uwall[2], &force[0], &lbf[spos], &lbf[spos+1*qdim],
                       &lbf[spos+2*qdim], &lbf[spos+3*qdim], &lbf[spos+4*qdim], &lbf[spos+5*qdim],
                       &lbf[spos+6*qdim], &lbf[spos+7*qdim], &lbf[spos+8*qdim], &lbf[spos+9*qdim],
                       &lbf[spos+10*qdim], &lbf[spos+11*qdim], &lbf[spos+12*qdim], &lbf[spos+13*qdim],
                       &lbf[spos+14*qdim], &lbf[spos+15*qdim], &lbf[spos+16*qdim], &lbf[spos+17*qdim],
                       &lbf[spos+18*qdim], &lbf[spos+19*qdim], &lbf[spos+20*qdim], &lbf[spos+21*qdim],
                       &lbf[spos+22*qdim], &lbf[spos+23*qdim], &lbf[spos+24*qdim], &lbf[spos+25*qdim],
                       &lbf[spos+26*qdim]);
        break;
      case CCTLF:
        fD3Q27VCCZouHe(rho, -uwall[0], uwall[1], uwall[2], &force[0], &lbf[spos], &lbf[spos+14*qdim],
                       &lbf[spos+2*qdim], &lbf[spos+3*qdim], &lbf[spos+18*qdim], &lbf[spos+17*qdim],
                       &lbf[spos+20*qdim], &lbf[spos+19*qdim], &lbf[spos+8*qdim], &lbf[spos+9*qdim],
                       &lbf[spos+26*qdim], &lbf[spos+25*qdim], &lbf[spos+24*qdim], &lbf[spos+23*qdim],
                       &lbf[spos+1*qdim], &lbf[spos+15*qdim], &lbf[spos+16*qdim], &lbf[spos+5*qdim],
                       &lbf[spos+4*qdim], &lbf[spos+7*qdim], &lbf[spos+6*qdim], &lbf[spos+21*qdim],
                       &lbf[spos+22*qdim], &lbf[spos+13*qdim], &lbf[spos+12*qdim], &lbf[spos+11*qdim],
                       &lbf[spos+10*qdim]);
        break;
      case CCDLF:
        fD3Q27VCCZouHe(rho, -uwall[0], -uwall[1], uwall[2], &force[0], &lbf[spos], &lbf[spos+14*qdim],
                       &lbf[spos+15*qdim], &lbf[spos+3*qdim], &lbf[spos+17*qdim], &lbf[spos+18*qdim],
                       &lbf[spos+20*qdim], &lbf[spos+19*qdim], &lbf[spos+22*qdim], &lbf[spos+21*qdim],
                       &lbf[spos+24*qdim], &lbf[spos+23*qdim], &lbf[spos+26*qdim], &lbf[spos+25*qdim],
                       &lbf[spos+1*qdim], &lbf[spos+2*qdim], &lbf[spos+16*qdim], &lbf[spos+4*qdim],
                       &lbf[spos+5*qdim], &lbf[spos+7*qdim], &lbf[spos+6*qdim], &lbf[spos+9*qdim],
                       &lbf[spos+8*qdim], &lbf[spos+11*qdim], &lbf[spos+10*qdim], &lbf[spos+13*qdim],
                       &lbf[spos+12*qdim]);
        break;
      case CCDRF:
        fD3Q27VCCZouHe(rho, uwall[0], -uwall[1], uwall[2], &force[0], &lbf[spos], &lbf[spos+1*qdim],
                       &lbf[spos+15*qdim], &lbf[spos+3*qdim], &lbf[spos+5*qdim], &lbf[spos+4*qdim],
                       &lbf[spos+6*qdim], &lbf[spos+7*qdim], &lbf[spos+22*qdim], &lbf[spos+21*qdim],
                       &lbf[spos+12*qdim], &lbf[spos+13*qdim], &lbf[spos+10*qdim], &lbf[spos+11*qdim],
                       &lbf[spos+14*qdim], &lbf[spos+2*qdim], &lbf[spos+16*qdim], &lbf[spos+18*qdim],
                       &lbf[spos+17*qdim], &lbf[spos+19*qdim], &lbf[spos+20*qdim], &lbf[spos+9*qdim],
                       &lbf[spos+8*qdim], &lbf[spos+25*qdim], &lbf[spos+26*qdim], &lbf[spos+23*qdim],
                       &lbf[spos+24*qdim]);
        break;
      case CETR:
        fD3Q27VCEZouHe(rho, uwall[0], uwall[1], uwall[2], &force[0], &lbf[spos], &lbf[spos+1*qdim],
                       &lbf[spos+2*qdim], &lbf[spos+3*qdim], &lbf[spos+4*qdim], &lbf[spos+5*qdim],
                       &lbf[spos+6*qdim], &lbf[spos+7*qdim], &lbf[spos+8*qdim], &lbf[spos+9*qdim],
                       &lbf[spos+10*qdim], &lbf[spos+11*qdim], &lbf[spos+12*qdim], &lbf[spos+13*qdim],
                       &lbf[spos+14*qdim], &lbf[spos+15*qdim], &lbf[spos+16*qdim], &lbf[spos+17*qdim],
                       &lbf[spos+18*qdim], &lbf[spos+19*qdim], &lbf[spos+20*qdim], &lbf[spos+21*qdim],
                       &lbf[spos+22*qdim], &lbf[spos+23*qdim], &lbf[spos+24*qdim], &lbf[spos+25*qdim],
                       &lbf[spos+26*qdim]);
        break;
      case CETL:
        fD3Q27VCEZouHe(rho, uwall[1], -uwall[0], uwall[2], &force[0], &lbf[spos], &lbf[spos+2*qdim],
                       &lbf[spos+14*qdim], &lbf[spos+3*qdim], &lbf[spos+18*qdim], &lbf[spos+4*qdim],
                       &lbf[spos+8*qdim], &lbf[spos+9*qdim], &lbf[spos+20*qdim], &lbf[spos+19*qdim],
                       &lbf[spos+26*qdim], &lbf[spos+25*qdim], &lbf[spos+10*qdim], &lbf[spos+11*qdim],
                       &lbf[spos+15*qdim], &lbf[spos+1*qdim], &lbf[spos+16*qdim], &lbf[spos+5*qdim],
                       &lbf[spos+17*qdim], &lbf[spos+21*qdim], &lbf[spos+22*qdim], &lbf[spos+7*qdim],
                       &lbf[spos+6*qdim], &lbf[spos+13*qdim], &lbf[spos+12*qdim], &lbf[spos+23*qdim],
                       &lbf[spos+24*qdim]);
        break;
      case CEDL:
        fD3Q27VCEZouHe(rho, -uwall[0], -uwall[1], uwall[2], &force[0], &lbf[spos], &lbf[spos+14*qdim],
                       &lbf[spos+15*qdim], &lbf[spos+3*qdim], &lbf[spos+17*qdim], &lbf[spos+18*qdim],
                       &lbf[spos+20*qdim], &lbf[spos+19*qdim], &lbf[spos+22*qdim], &lbf[spos+21*qdim],
                       &lbf[spos+24*qdim], &lbf[spos+23*qdim], &lbf[spos+26*qdim], &lbf[spos+25*qdim],
                       &lbf[spos+1*qdim], &lbf[spos+2*qdim], &lbf[spos+16*qdim], &lbf[spos+4*qdim],
                       &lbf[spos+5*qdim], &lbf[spos+7*qdim], &lbf[spos+6*qdim], &lbf[spos+9*qdim],
                       &lbf[spos+8*qdim], &lbf[spos+11*qdim], &lbf[spos+10*qdim], &lbf[spos+13*qdim],
                       &lbf[spos+12*qdim]);
        break;
      case CEDR:
        fD3Q27VCEZouHe(rho, -uwall[1], uwall[0], uwall[2], &force[0], &lbf[spos], &lbf[spos+15*qdim],
                       &lbf[spos+1*qdim], &lbf[spos+3*qdim], &lbf[spos+5*qdim], &lbf[spos+17*qdim],
                       &lbf[spos+22*qdim], &lbf[spos+21*qdim], &lbf[spos+6*qdim], &lbf[spos+7*qdim],
                       &lbf[spos+12*qdim], &lbf[spos+13*qdim], &lbf[spos+24*qdim], &lbf[spos+23*qdim],
                       &lbf[spos+2*qdim], &lbf[spos+14*qdim], &lbf[spos+16*qdim], &lbf[spos+18*qdim],
                       &lbf[spos+4*qdim], &lbf[spos+9*qdim], &lbf[spos+8*qdim], &lbf[spos+19*qdim],
                       &lbf[spos+20*qdim], &lbf[spos+25*qdim], &lbf[spos+26*qdim], &lbf[spos+11*qdim],
                       &lbf[spos+10*qdim]);
        break;
      case CETF:
        fD3Q27VCEZouHe(rho, uwall[1], uwall[2], uwall[0], &force[0], &lbf[spos], &lbf[spos+2*qdim],
                       &lbf[spos+3*qdim], &lbf[spos+1*qdim], &lbf[spos+8*qdim], &lbf[spos+9*qdim],
                       &lbf[spos+4*qdim], &lbf[spos+18*qdim], &lbf[spos+6*qdim], &lbf[spos+20*qdim],
                       &lbf[spos+10*qdim], &lbf[spos+26*qdim], &lbf[spos+11*qdim], &lbf[spos+25*qdim],
                       &lbf[spos+15*qdim], &lbf[spos+16*qdim], &lbf[spos+14*qdim], &lbf[spos+21*qdim],
                       &lbf[spos+22*qdim], &lbf[spos+17*qdim], &lbf[spos+5*qdim], &lbf[spos+19*qdim],
                       &lbf[spos+7*qdim], &lbf[spos+23*qdim], &lbf[spos+13*qdim], &lbf[spos+24*qdim],
                       &lbf[spos+12*qdim]);
        break;
      case CELF:
        fD3Q27VCEZouHe(rho, -uwall[0], uwall[1], uwall[2], &force[0], &lbf[spos], &lbf[spos+14*qdim],
                       &lbf[spos+3*qdim], &lbf[spos+2*qdim], &lbf[spos+20*qdim], &lbf[spos+19*qdim],
                       &lbf[spos+18*qdim], &lbf[spos+17*qdim], &lbf[spos+8*qdim], &lbf[spos+22*qdim],
                       &lbf[spos+26*qdim], &lbf[spos+24*qdim], &lbf[spos+25*qdim], &lbf[spos+23*qdim],
                       &lbf[spos+1*qdim], &lbf[spos+16*qdim], &lbf[spos+15*qdim], &lbf[spos+7*qdim],
                       &lbf[spos+6*qdim], &lbf[spos+5*qdim], &lbf[spos+4*qdim], &lbf[spos+21*qdim],
                       &lbf[spos+9*qdim], &lbf[spos+13*qdim], &lbf[spos+11*qdim], &lbf[spos+12*qdim],
                       &lbf[spos+10*qdim]);
        break;
      case CEDF:
        fD3Q27VCEZouHe(rho, -uwall[1], uwall[2], uwall[0], &force[0], &lbf[spos], &lbf[spos+15*qdim],
                       &lbf[spos+3*qdim], &lbf[spos+1*qdim], &lbf[spos+22*qdim], &lbf[spos+21*qdim],
                       &lbf[spos+5*qdim], &lbf[spos+17*qdim], &lbf[spos+6*qdim], &lbf[spos+20*qdim],
                       &lbf[spos+12*qdim], &lbf[spos+24*qdim], &lbf[spos+13*qdim], &lbf[spos+23*qdim],
                       &lbf[spos+2*qdim], &lbf[spos+16*qdim], &lbf[spos+14*qdim], &lbf[spos+9*qdim],
                       &lbf[spos+8*qdim], &lbf[spos+18*qdim], &lbf[spos+4*qdim], &lbf[spos+19*qdim],
                       &lbf[spos+7*qdim], &lbf[spos+25*qdim], &lbf[spos+11*qdim], &lbf[spos+26*qdim],
                       &lbf[spos+10*qdim]);
        break;
      case CERF:
        fD3Q27VCEZouHe(rho, uwall[0], uwall[2], uwall[2], &force[0], &lbf[spos], &lbf[spos+1*qdim],
                       &lbf[spos+3*qdim], &lbf[spos+2*qdim], &lbf[spos+6*qdim], &lbf[spos+7*qdim],
                       &lbf[spos+4*qdim], &lbf[spos+5*qdim], &lbf[spos+8*qdim], &lbf[spos+22*qdim],
                       &lbf[spos+10*qdim], &lbf[spos+12*qdim], &lbf[spos+11*qdim], &lbf[spos+13*qdim],
                       &lbf[spos+14*qdim], &lbf[spos+16*qdim], &lbf[spos+15*qdim], &lbf[spos+19*qdim],
                       &lbf[spos+20*qdim], &lbf[spos+17*qdim], &lbf[spos+18*qdim], &lbf[spos+21*qdim],
                       &lbf[spos+9*qdim], &lbf[spos+23*qdim], &lbf[spos+25*qdim], &lbf[spos+24*qdim],
                       &lbf[spos+26*qdim]);
        break;
      case CETB:
        fD3Q27VCEZouHe(rho, uwall[1], -uwall[2], uwall[0], &force[0], &lbf[spos], &lbf[spos+2*qdim],
                       &lbf[spos+16*qdim], &lbf[spos+1*qdim], &lbf[spos+9*qdim], &lbf[spos+8*qdim],
                       &lbf[spos+4*qdim], &lbf[spos+18*qdim], &lbf[spos+7*qdim], &lbf[spos+19*qdim],
                       &lbf[spos+11*qdim], &lbf[spos+25*qdim], &lbf[spos+10*qdim], &lbf[spos+26*qdim],
                       &lbf[spos+15*qdim], &lbf[spos+3*qdim], &lbf[spos+14*qdim], &lbf[spos+22*qdim],
                       &lbf[spos+21*qdim], &lbf[spos+17*qdim], &lbf[spos+5*qdim], &lbf[spos+20*qdim],
                       &lbf[spos+6*qdim], &lbf[spos+24*qdim], &lbf[spos+12*qdim], &lbf[spos+23*qdim],
                       &lbf[spos+13*qdim]);
        break;
      case CELB:
        fD3Q27VCEZouHe(rho, -uwall[0], -uwall[2], uwall[1], &force[0], &lbf[spos], &lbf[spos+14*qdim],
                       &lbf[spos+16*qdim], &lbf[spos+2*qdim], &lbf[spos+19*qdim], &lbf[spos+20*qdim],
                       &lbf[spos+18*qdim], &lbf[spos+17*qdim], &lbf[spos+9*qdim], &lbf[spos+21*qdim],
                       &lbf[spos+25*qdim], &lbf[spos+23*qdim], &lbf[spos+26*qdim], &lbf[spos+24*qdim],
                       &lbf[spos+1*qdim], &lbf[spos+3*qdim], &lbf[spos+15*qdim], &lbf[spos+6*qdim],
                       &lbf[spos+7*qdim], &lbf[spos+5*qdim], &lbf[spos+4*qdim], &lbf[spos+22*qdim],
                       &lbf[spos+8*qdim], &lbf[spos+12*qdim], &lbf[spos+10*qdim], &lbf[spos+13*qdim],
                       &lbf[spos+11*qdim]);
        break;
      case CEDB:
        fD3Q27VCEZouHe(rho, -uwall[1], -uwall[2], uwall[0], &force[0], &lbf[spos], &lbf[spos+15*qdim],
                       &lbf[spos+16*qdim], &lbf[spos+1*qdim], &lbf[spos+21*qdim], &lbf[spos+22*qdim],
                       &lbf[spos+5*qdim], &lbf[spos+17*qdim], &lbf[spos+7*qdim], &lbf[spos+19*qdim],
                       &lbf[spos+13*qdim], &lbf[spos+23*qdim], &lbf[spos+12*qdim], &lbf[spos+24*qdim],
                       &lbf[spos+2*qdim], &lbf[spos+3*qdim], &lbf[spos+14*qdim], &lbf[spos+8*qdim],
                       &lbf[spos+9*qdim], &lbf[spos+18*qdim], &lbf[spos+4*qdim], &lbf[spos+20*qdim],
                       &lbf[spos+6*qdim], &lbf[spos+26*qdim], &lbf[spos+10*qdim], &lbf[spos+25*qdim],
                       &lbf[spos+11*qdim]);
        break;
      case CERB:
        fD3Q27VCEZouHe(rho, uwall[0], -uwall[2], uwall[1], &force[0], &lbf[spos], &lbf[spos+1*qdim],
                       &lbf[spos+16*qdim], &lbf[spos+2*qdim], &lbf[spos+7*qdim], &lbf[spos+6*qdim],
                       &lbf[spos+4*qdim], &lbf[spos+5*qdim], &lbf[spos+9*qdim], &lbf[spos+21*qdim],
                       &lbf[spos+11*qdim], &lbf[spos+13*qdim], &lbf[spos+10*qdim], &lbf[spos+12*qdim],
                       &lbf[spos+14*qdim], &lbf[spos+3*qdim], &lbf[spos+15*qdim], &lbf[spos+20*qdim],
                       &lbf[spos+19*qdim], &lbf[spos+17*qdim], &lbf[spos+18*qdim], &lbf[spos+22*qdim],
                       &lbf[spos+8*qdim], &lbf[spos+24*qdim], &lbf[spos+26*qdim], &lbf[spos+23*qdim],
                       &lbf[spos+25*qdim]);
        break;
    }
  }

  return 0;
  
}

int fD3Q27VFSimpleZouHe(long tpos, long rpos, int prop, double *uwall)
{
  long spos=tpos * lbsitelength;
  int qdim=lbsy.nf+lbsy.nc+lbsy.nt;
  double force[3*lbsy.nf], rho[lbsy.nf];

  // sort out forces
    
  fD3Q27BoundaryForceVelocity(force, tpos, rpos, uwall, prop);

  // apply boundary condition

  if(prop>26)
    fGetAllMassSite(rho, &lbf[rpos*lbsitelength]);

  if (collide>11) {
    switch (prop) {
      case PST:
        fD3Q27VPSCLBESimpleZouHe(uwall[0], uwall[1], uwall[2], &force[0], &lbf[spos], &lbf[spos+1*qdim],
                                 &lbf[spos+2*qdim], &lbf[spos+3*qdim], &lbf[spos+4*qdim], &lbf[spos+5*qdim],
                                 &lbf[spos+6*qdim], &lbf[spos+7*qdim], &lbf[spos+8*qdim], &lbf[spos+9*qdim],
                                 &lbf[spos+10*qdim], &lbf[spos+11*qdim], &lbf[spos+12*qdim], &lbf[spos+13*qdim],
                                 &lbf[spos+14*qdim], &lbf[spos+15*qdim], &lbf[spos+16*qdim], &lbf[spos+17*qdim],
                                 &lbf[spos+18*qdim], &lbf[spos+19*qdim], &lbf[spos+20*qdim], &lbf[spos+21*qdim],
                                 &lbf[spos+22*qdim], &lbf[spos+23*qdim], &lbf[spos+24*qdim], &lbf[spos+25*qdim],
                                 &lbf[spos+26*qdim]);
        break;
      case PSD:
        fD3Q27VPSCLBESimpleZouHe(-uwall[0], -uwall[1], -uwall[2], &force[0], &lbf[spos], &lbf[spos+14*qdim],
                                 &lbf[spos+15*qdim], &lbf[spos+16*qdim], &lbf[spos+17*qdim], &lbf[spos+18*qdim],
                                 &lbf[spos+19*qdim], &lbf[spos+20*qdim], &lbf[spos+21*qdim], &lbf[spos+22*qdim],
                                 &lbf[spos+23*qdim], &lbf[spos+24*qdim], &lbf[spos+25*qdim], &lbf[spos+26*qdim],
                                 &lbf[spos+1*qdim], &lbf[spos+2*qdim], &lbf[spos+3*qdim], &lbf[spos+4*qdim],
                                 &lbf[spos+5*qdim], &lbf[spos+6*qdim], &lbf[spos+7*qdim], &lbf[spos+8*qdim],
                                 &lbf[spos+9*qdim], &lbf[spos+10*qdim], &lbf[spos+11*qdim], &lbf[spos+12*qdim],
                                 &lbf[spos+13*qdim]);
        break;
      case PSL:
        fD3Q27VPSCLBESimpleZouHe(-uwall[2], -uwall[0], -uwall[1], &force[0], &lbf[spos], &lbf[spos+16*qdim],
                                 &lbf[spos+14*qdim], &lbf[spos+15*qdim], &lbf[spos+19*qdim], &lbf[spos+7*qdim],
                                 &lbf[spos+21*qdim], &lbf[spos+9*qdim], &lbf[spos+17*qdim], &lbf[spos+18*qdim],
                                 &lbf[spos+23*qdim], &lbf[spos+25*qdim], &lbf[spos+13*qdim], &lbf[spos+11*qdim],
                                 &lbf[spos+3*qdim], &lbf[spos+1*qdim], &lbf[spos+2*qdim], &lbf[spos+6*qdim],
                                 &lbf[spos+20*qdim], &lbf[spos+8*qdim], &lbf[spos+22*qdim], &lbf[spos+4*qdim],
                                 &lbf[spos+5*qdim], &lbf[spos+10*qdim], &lbf[spos+12*qdim], &lbf[spos+26*qdim],
                                 &lbf[spos+24*qdim]);
        break;
      case PSR:
        fD3Q27VPSCLBESimpleZouHe(uwall[2], uwall[0], uwall[1], &force[0], &lbf[spos], &lbf[spos+3*qdim],
                                 &lbf[spos+1*qdim], &lbf[spos+2*qdim], &lbf[spos+6*qdim], &lbf[spos+20*qdim],
                                 &lbf[spos+8*qdim], &lbf[spos+22*qdim], &lbf[spos+4*qdim], &lbf[spos+5*qdim],
                                 &lbf[spos+10*qdim], &lbf[spos+12*qdim], &lbf[spos+26*qdim], &lbf[spos+24*qdim],
                                 &lbf[spos+16*qdim], &lbf[spos+14*qdim], &lbf[spos+15*qdim], &lbf[spos+19*qdim],
                                 &lbf[spos+7*qdim], &lbf[spos+21*qdim], &lbf[spos+9*qdim], &lbf[spos+17*qdim],
                                 &lbf[spos+18*qdim], &lbf[spos+23*qdim], &lbf[spos+25*qdim], &lbf[spos+13*qdim],
                                 &lbf[spos+11*qdim]);
        break;
      case PSF:
        fD3Q27VPSCLBESimpleZouHe(-uwall[1], -uwall[2], -uwall[0], &force[0], &lbf[spos], &lbf[spos+15*qdim],
                                 &lbf[spos+16*qdim], &lbf[spos+14*qdim], &lbf[spos+21*qdim], &lbf[spos+22*qdim],
                                 &lbf[spos+17*qdim], &lbf[spos+5*qdim], &lbf[spos+19*qdim], &lbf[spos+7*qdim],
                                 &lbf[spos+23*qdim], &lbf[spos+13*qdim], &lbf[spos+24*qdim], &lbf[spos+12*qdim],
                                 &lbf[spos+2*qdim], &lbf[spos+3*qdim], &lbf[spos+1*qdim], &lbf[spos+8*qdim],
                                 &lbf[spos+9*qdim], &lbf[spos+4*qdim], &lbf[spos+18*qdim], &lbf[spos+6*qdim],
                                 &lbf[spos+20*qdim], &lbf[spos+10*qdim], &lbf[spos+26*qdim], &lbf[spos+11*qdim],
                                 &lbf[spos+25*qdim]);
        break;
      case PSB:
        fD3Q27VPSCLBESimpleZouHe(uwall[1], uwall[2], uwall[0], &force[0], &lbf[spos], &lbf[spos+2*qdim],
                                 &lbf[spos+3*qdim], &lbf[spos+1*qdim], &lbf[spos+8*qdim], &lbf[spos+9*qdim],
                                 &lbf[spos+4*qdim], &lbf[spos+18*qdim], &lbf[spos+6*qdim], &lbf[spos+20*qdim],
                                 &lbf[spos+10*qdim], &lbf[spos+26*qdim], &lbf[spos+11*qdim], &lbf[spos+25*qdim],
                                 &lbf[spos+15*qdim], &lbf[spos+16*qdim], &lbf[spos+14*qdim], &lbf[spos+21*qdim],
                                 &lbf[spos+22*qdim], &lbf[spos+17*qdim], &lbf[spos+5*qdim], &lbf[spos+19*qdim],
                                 &lbf[spos+7*qdim], &lbf[spos+23*qdim], &lbf[spos+13*qdim], &lbf[spos+24*qdim],
                                 &lbf[spos+12*qdim]);
        break;
      case CCTRB:
        fD3Q27VCCCLBESimpleZouHe(rho, uwall[0], uwall[1], -uwall[2], &force[0], &lbf[spos], &lbf[spos+1*qdim],
                                 &lbf[spos+2*qdim], &lbf[spos+16*qdim], &lbf[spos+4*qdim], &lbf[spos+5*qdim],
                                 &lbf[spos+7*qdim], &lbf[spos+6*qdim], &lbf[spos+9*qdim], &lbf[spos+8*qdim],
                                 &lbf[spos+11*qdim], &lbf[spos+10*qdim], &lbf[spos+13*qdim], &lbf[spos+12*qdim],
                                 &lbf[spos+14*qdim], &lbf[spos+15*qdim], &lbf[spos+3*qdim], &lbf[spos+17*qdim],
                                 &lbf[spos+18*qdim], &lbf[spos+20*qdim], &lbf[spos+19*qdim], &lbf[spos+22*qdim],
                                 &lbf[spos+21*qdim], &lbf[spos+24*qdim], &lbf[spos+23*qdim], &lbf[spos+26*qdim],
                                 &lbf[spos+25*qdim]);
        break;
      case CCTLB:
        fD3Q27VCCCLBESimpleZouHe(rho, -uwall[0], uwall[1], -uwall[2], &force[0], &lbf[spos], &lbf[spos+14*qdim],
                                 &lbf[spos+2*qdim], &lbf[spos+16*qdim], &lbf[spos+18*qdim], &lbf[spos+17*qdim],
                                 &lbf[spos+19*qdim], &lbf[spos+20*qdim], &lbf[spos+9*qdim], &lbf[spos+8*qdim],
                                 &lbf[spos+25*qdim], &lbf[spos+26*qdim], &lbf[spos+23*qdim], &lbf[spos+24*qdim],
                                 &lbf[spos+1*qdim], &lbf[spos+15*qdim], &lbf[spos+3*qdim], &lbf[spos+5*qdim],
                                 &lbf[spos+4*qdim], &lbf[spos+6*qdim], &lbf[spos+7*qdim], &lbf[spos+22*qdim],
                                 &lbf[spos+21*qdim], &lbf[spos+12*qdim], &lbf[spos+13*qdim], &lbf[spos+10*qdim],
                                 &lbf[spos+11*qdim]);
        break;
      case CCDLB:
        fD3Q27VCCCLBESimpleZouHe(rho, -uwall[0], -uwall[1], -uwall[2], &force[0], &lbf[spos], &lbf[spos+14*qdim],
                                 &lbf[spos+15*qdim], &lbf[spos+16*qdim], &lbf[spos+17*qdim], &lbf[spos+18*qdim],
                                 &lbf[spos+19*qdim], &lbf[spos+20*qdim], &lbf[spos+21*qdim], &lbf[spos+22*qdim],
                                 &lbf[spos+23*qdim], &lbf[spos+24*qdim], &lbf[spos+25*qdim], &lbf[spos+26*qdim],
                                 &lbf[spos+1*qdim], &lbf[spos+2*qdim], &lbf[spos+3*qdim], &lbf[spos+4*qdim],
                                 &lbf[spos+5*qdim], &lbf[spos+6*qdim], &lbf[spos+7*qdim], &lbf[spos+8*qdim],
                                 &lbf[spos+9*qdim], &lbf[spos+10*qdim], &lbf[spos+11*qdim], &lbf[spos+12*qdim],
                                 &lbf[spos+13*qdim]);
        break;
      case CCDRB:
        fD3Q27VCCCLBESimpleZouHe(rho, uwall[0], -uwall[1], -uwall[2], &force[0], &lbf[spos], &lbf[spos+1*qdim],
                                 &lbf[spos+15*qdim], &lbf[spos+16*qdim], &lbf[spos+5*qdim], &lbf[spos+4*qdim],
                                 &lbf[spos+7*qdim], &lbf[spos+6*qdim], &lbf[spos+21*qdim], &lbf[spos+22*qdim],
                                 &lbf[spos+13*qdim], &lbf[spos+12*qdim], &lbf[spos+11*qdim], &lbf[spos+10*qdim],
                                 &lbf[spos+14*qdim], &lbf[spos+2*qdim], &lbf[spos+3*qdim], &lbf[spos+18*qdim],
                                 &lbf[spos+17*qdim], &lbf[spos+20*qdim], &lbf[spos+19*qdim], &lbf[spos+8*qdim],
                                 &lbf[spos+9*qdim], &lbf[spos+26*qdim], &lbf[spos+25*qdim], &lbf[spos+24*qdim],
                                 &lbf[spos+23*qdim]);
        break;
      case CCTRF:
        fD3Q27VCCCLBESimpleZouHe(rho, uwall[0], uwall[1], uwall[2], &force[0], &lbf[spos], &lbf[spos+1*qdim],
                                 &lbf[spos+2*qdim], &lbf[spos+3*qdim], &lbf[spos+4*qdim], &lbf[spos+5*qdim],
                                 &lbf[spos+6*qdim], &lbf[spos+7*qdim], &lbf[spos+8*qdim], &lbf[spos+9*qdim],
                                 &lbf[spos+10*qdim], &lbf[spos+11*qdim], &lbf[spos+12*qdim], &lbf[spos+13*qdim],
                                 &lbf[spos+14*qdim], &lbf[spos+15*qdim], &lbf[spos+16*qdim], &lbf[spos+17*qdim],
                                 &lbf[spos+18*qdim], &lbf[spos+19*qdim], &lbf[spos+20*qdim], &lbf[spos+21*qdim],
                                 &lbf[spos+22*qdim], &lbf[spos+23*qdim], &lbf[spos+24*qdim], &lbf[spos+25*qdim],
                                 &lbf[spos+26*qdim]);
        break;
      case CCTLF:
        fD3Q27VCCCLBESimpleZouHe(rho, -uwall[0], uwall[1], uwall[2], &force[0], &lbf[spos], &lbf[spos+14*qdim],
                                 &lbf[spos+2*qdim], &lbf[spos+3*qdim], &lbf[spos+18*qdim], &lbf[spos+17*qdim],
                                 &lbf[spos+20*qdim], &lbf[spos+19*qdim], &lbf[spos+8*qdim], &lbf[spos+9*qdim],
                                 &lbf[spos+26*qdim], &lbf[spos+25*qdim], &lbf[spos+24*qdim], &lbf[spos+23*qdim],
                                 &lbf[spos+1*qdim], &lbf[spos+15*qdim], &lbf[spos+16*qdim], &lbf[spos+5*qdim],
                                 &lbf[spos+4*qdim], &lbf[spos+7*qdim], &lbf[spos+6*qdim], &lbf[spos+21*qdim],
                                 &lbf[spos+22*qdim], &lbf[spos+13*qdim], &lbf[spos+12*qdim], &lbf[spos+11*qdim],
                                 &lbf[spos+10*qdim]);
        break;
      case CCDLF:
        fD3Q27VCCCLBESimpleZouHe(rho, -uwall[0], -uwall[1], uwall[2], &force[0], &lbf[spos], &lbf[spos+14*qdim],
                                 &lbf[spos+15*qdim], &lbf[spos+3*qdim], &lbf[spos+17*qdim], &lbf[spos+18*qdim],
                                 &lbf[spos+20*qdim], &lbf[spos+19*qdim], &lbf[spos+22*qdim], &lbf[spos+21*qdim],
                                 &lbf[spos+24*qdim], &lbf[spos+23*qdim], &lbf[spos+26*qdim], &lbf[spos+25*qdim],
                                 &lbf[spos+1*qdim], &lbf[spos+2*qdim], &lbf[spos+16*qdim], &lbf[spos+4*qdim],
                                 &lbf[spos+5*qdim], &lbf[spos+7*qdim], &lbf[spos+6*qdim], &lbf[spos+9*qdim],
                                 &lbf[spos+8*qdim], &lbf[spos+11*qdim], &lbf[spos+10*qdim], &lbf[spos+13*qdim],
                                 &lbf[spos+12*qdim]);
        break;
      case CCDRF:
        fD3Q27VCCCLBESimpleZouHe(rho, uwall[0], -uwall[1], uwall[2], &force[0], &lbf[spos], &lbf[spos+1*qdim],
                                 &lbf[spos+15*qdim], &lbf[spos+3*qdim], &lbf[spos+5*qdim], &lbf[spos+4*qdim],
                                 &lbf[spos+6*qdim], &lbf[spos+7*qdim], &lbf[spos+22*qdim], &lbf[spos+21*qdim],
                                 &lbf[spos+12*qdim], &lbf[spos+13*qdim], &lbf[spos+10*qdim], &lbf[spos+11*qdim],
                                 &lbf[spos+14*qdim], &lbf[spos+2*qdim], &lbf[spos+16*qdim], &lbf[spos+18*qdim],
                                 &lbf[spos+17*qdim], &lbf[spos+19*qdim], &lbf[spos+20*qdim], &lbf[spos+9*qdim],
                                 &lbf[spos+8*qdim], &lbf[spos+25*qdim], &lbf[spos+26*qdim], &lbf[spos+23*qdim],
                                 &lbf[spos+24*qdim]);
        break;
      case CETR:
        fD3Q27VCECLBESimpleZouHe(rho, uwall[0], uwall[1], uwall[2], &force[0], &lbf[spos], &lbf[spos+1*qdim],
                                 &lbf[spos+2*qdim], &lbf[spos+3*qdim], &lbf[spos+4*qdim], &lbf[spos+5*qdim],
                                 &lbf[spos+6*qdim], &lbf[spos+7*qdim], &lbf[spos+8*qdim], &lbf[spos+9*qdim],
                                 &lbf[spos+10*qdim], &lbf[spos+11*qdim], &lbf[spos+12*qdim], &lbf[spos+13*qdim],
                                 &lbf[spos+14*qdim], &lbf[spos+15*qdim], &lbf[spos+16*qdim], &lbf[spos+17*qdim],
                                 &lbf[spos+18*qdim], &lbf[spos+19*qdim], &lbf[spos+20*qdim], &lbf[spos+21*qdim],
                                 &lbf[spos+22*qdim], &lbf[spos+23*qdim], &lbf[spos+24*qdim], &lbf[spos+25*qdim],
                                 &lbf[spos+26*qdim]);
        break;
      case CETL:
        fD3Q27VCECLBESimpleZouHe(rho, uwall[1], -uwall[0], uwall[2], &force[0], &lbf[spos], &lbf[spos+2*qdim],
                                 &lbf[spos+14*qdim], &lbf[spos+3*qdim], &lbf[spos+18*qdim], &lbf[spos+4*qdim],
                                 &lbf[spos+8*qdim], &lbf[spos+9*qdim], &lbf[spos+20*qdim], &lbf[spos+19*qdim],
                                 &lbf[spos+26*qdim], &lbf[spos+25*qdim], &lbf[spos+10*qdim], &lbf[spos+11*qdim],
                                 &lbf[spos+15*qdim], &lbf[spos+1*qdim], &lbf[spos+16*qdim], &lbf[spos+5*qdim],
                                 &lbf[spos+17*qdim], &lbf[spos+21*qdim], &lbf[spos+22*qdim], &lbf[spos+7*qdim],
                                 &lbf[spos+6*qdim], &lbf[spos+13*qdim], &lbf[spos+12*qdim], &lbf[spos+23*qdim],
                                 &lbf[spos+24*qdim]);
        break;
      case CEDL:
        fD3Q27VCECLBESimpleZouHe(rho, -uwall[0], -uwall[1], uwall[2], &force[0], &lbf[spos], &lbf[spos+14*qdim],
                                 &lbf[spos+15*qdim], &lbf[spos+3*qdim], &lbf[spos+17*qdim], &lbf[spos+18*qdim],
                                 &lbf[spos+20*qdim], &lbf[spos+19*qdim], &lbf[spos+22*qdim], &lbf[spos+21*qdim],
                                 &lbf[spos+24*qdim], &lbf[spos+23*qdim], &lbf[spos+26*qdim], &lbf[spos+25*qdim],
                                 &lbf[spos+1*qdim], &lbf[spos+2*qdim], &lbf[spos+16*qdim], &lbf[spos+4*qdim],
                                 &lbf[spos+5*qdim], &lbf[spos+7*qdim], &lbf[spos+6*qdim], &lbf[spos+9*qdim],
                                 &lbf[spos+8*qdim], &lbf[spos+11*qdim], &lbf[spos+10*qdim], &lbf[spos+13*qdim],
                                 &lbf[spos+12*qdim]);
        break;
      case CEDR:
        fD3Q27VCECLBESimpleZouHe(rho, -uwall[1], uwall[0], uwall[2], &force[0], &lbf[spos], &lbf[spos+15*qdim],
                                 &lbf[spos+1*qdim], &lbf[spos+3*qdim], &lbf[spos+5*qdim], &lbf[spos+17*qdim],
                                 &lbf[spos+22*qdim], &lbf[spos+21*qdim], &lbf[spos+6*qdim], &lbf[spos+7*qdim],
                                 &lbf[spos+12*qdim], &lbf[spos+13*qdim], &lbf[spos+24*qdim], &lbf[spos+23*qdim],
                                 &lbf[spos+2*qdim], &lbf[spos+14*qdim], &lbf[spos+16*qdim], &lbf[spos+18*qdim],
                                 &lbf[spos+4*qdim], &lbf[spos+9*qdim], &lbf[spos+8*qdim], &lbf[spos+19*qdim],
                                 &lbf[spos+20*qdim], &lbf[spos+25*qdim], &lbf[spos+26*qdim], &lbf[spos+11*qdim],
                                 &lbf[spos+10*qdim]);
        break;
      case CETF:
        fD3Q27VCECLBESimpleZouHe(rho, uwall[1], uwall[2], uwall[0], &force[0], &lbf[spos], &lbf[spos+2*qdim],
                                 &lbf[spos+3*qdim], &lbf[spos+1*qdim], &lbf[spos+8*qdim], &lbf[spos+9*qdim],
                                 &lbf[spos+4*qdim], &lbf[spos+18*qdim], &lbf[spos+6*qdim], &lbf[spos+20*qdim],
                                 &lbf[spos+10*qdim], &lbf[spos+26*qdim], &lbf[spos+11*qdim], &lbf[spos+25*qdim],
                                 &lbf[spos+15*qdim], &lbf[spos+16*qdim], &lbf[spos+14*qdim], &lbf[spos+21*qdim],
                                 &lbf[spos+22*qdim], &lbf[spos+17*qdim], &lbf[spos+5*qdim], &lbf[spos+19*qdim],
                                 &lbf[spos+7*qdim], &lbf[spos+23*qdim], &lbf[spos+13*qdim], &lbf[spos+24*qdim],
                                 &lbf[spos+12*qdim]);
        break;
      case CELF:
        fD3Q27VCECLBESimpleZouHe(rho, -uwall[0], uwall[1], uwall[2], &force[0], &lbf[spos], &lbf[spos+14*qdim],
                                 &lbf[spos+3*qdim], &lbf[spos+2*qdim], &lbf[spos+20*qdim], &lbf[spos+19*qdim],
                                 &lbf[spos+18*qdim], &lbf[spos+17*qdim], &lbf[spos+8*qdim], &lbf[spos+22*qdim],
                                 &lbf[spos+26*qdim], &lbf[spos+24*qdim], &lbf[spos+25*qdim], &lbf[spos+23*qdim],
                                 &lbf[spos+1*qdim], &lbf[spos+16*qdim], &lbf[spos+15*qdim], &lbf[spos+7*qdim],
                                 &lbf[spos+6*qdim], &lbf[spos+5*qdim], &lbf[spos+4*qdim], &lbf[spos+21*qdim],
                                 &lbf[spos+9*qdim], &lbf[spos+13*qdim], &lbf[spos+11*qdim], &lbf[spos+12*qdim],
                                 &lbf[spos+10*qdim]);
        break;
      case CEDF:
        fD3Q27VCECLBESimpleZouHe(rho, -uwall[1], uwall[2], uwall[0], &force[0], &lbf[spos], &lbf[spos+15*qdim],
                                 &lbf[spos+3*qdim], &lbf[spos+1*qdim], &lbf[spos+22*qdim], &lbf[spos+21*qdim],
                                 &lbf[spos+5*qdim], &lbf[spos+17*qdim], &lbf[spos+6*qdim], &lbf[spos+20*qdim],
                                 &lbf[spos+12*qdim], &lbf[spos+24*qdim], &lbf[spos+13*qdim], &lbf[spos+23*qdim],
                                 &lbf[spos+2*qdim], &lbf[spos+16*qdim], &lbf[spos+14*qdim], &lbf[spos+9*qdim],
                                 &lbf[spos+8*qdim], &lbf[spos+18*qdim], &lbf[spos+4*qdim], &lbf[spos+19*qdim],
                                 &lbf[spos+7*qdim], &lbf[spos+25*qdim], &lbf[spos+11*qdim], &lbf[spos+26*qdim],
                                 &lbf[spos+10*qdim]);
        break;
      case CERF:
        fD3Q27VCECLBESimpleZouHe(rho, uwall[0], uwall[2], uwall[2], &force[0], &lbf[spos], &lbf[spos+1*qdim],
                                 &lbf[spos+3*qdim], &lbf[spos+2*qdim], &lbf[spos+6*qdim], &lbf[spos+7*qdim],
                                 &lbf[spos+4*qdim], &lbf[spos+5*qdim], &lbf[spos+8*qdim], &lbf[spos+22*qdim],
                                 &lbf[spos+10*qdim], &lbf[spos+12*qdim], &lbf[spos+11*qdim], &lbf[spos+13*qdim],
                                 &lbf[spos+14*qdim], &lbf[spos+16*qdim], &lbf[spos+15*qdim], &lbf[spos+19*qdim],
                                 &lbf[spos+20*qdim], &lbf[spos+17*qdim], &lbf[spos+18*qdim], &lbf[spos+21*qdim],
                                 &lbf[spos+9*qdim], &lbf[spos+23*qdim], &lbf[spos+25*qdim], &lbf[spos+24*qdim],
                                 &lbf[spos+26*qdim]);
        break;
      case CETB:
        fD3Q27VCECLBESimpleZouHe(rho, uwall[1], -uwall[2], uwall[0], &force[0], &lbf[spos], &lbf[spos+2*qdim],
                                 &lbf[spos+16*qdim], &lbf[spos+1*qdim], &lbf[spos+9*qdim], &lbf[spos+8*qdim],
                                 &lbf[spos+4*qdim], &lbf[spos+18*qdim], &lbf[spos+7*qdim], &lbf[spos+19*qdim],
                                 &lbf[spos+11*qdim], &lbf[spos+25*qdim], &lbf[spos+10*qdim], &lbf[spos+26*qdim],
                                 &lbf[spos+15*qdim], &lbf[spos+3*qdim], &lbf[spos+14*qdim], &lbf[spos+22*qdim],
                                 &lbf[spos+21*qdim], &lbf[spos+17*qdim], &lbf[spos+5*qdim], &lbf[spos+20*qdim],
                                 &lbf[spos+6*qdim], &lbf[spos+24*qdim], &lbf[spos+12*qdim], &lbf[spos+23*qdim],
                                 &lbf[spos+13*qdim]);
        break;
      case CELB:
        fD3Q27VCECLBESimpleZouHe(rho, -uwall[0], -uwall[2], uwall[1], &force[0], &lbf[spos], &lbf[spos+14*qdim],
                                 &lbf[spos+16*qdim], &lbf[spos+2*qdim], &lbf[spos+19*qdim], &lbf[spos+20*qdim],
                                 &lbf[spos+18*qdim], &lbf[spos+17*qdim], &lbf[spos+9*qdim], &lbf[spos+21*qdim],
                                 &lbf[spos+25*qdim], &lbf[spos+23*qdim], &lbf[spos+26*qdim], &lbf[spos+24*qdim],
                                 &lbf[spos+1*qdim], &lbf[spos+3*qdim], &lbf[spos+15*qdim], &lbf[spos+6*qdim],
                                 &lbf[spos+7*qdim], &lbf[spos+5*qdim], &lbf[spos+4*qdim], &lbf[spos+22*qdim],
                                 &lbf[spos+8*qdim], &lbf[spos+12*qdim], &lbf[spos+10*qdim], &lbf[spos+13*qdim],
                                 &lbf[spos+11*qdim]);
        break;
      case CEDB:
        fD3Q27VCECLBESimpleZouHe(rho, -uwall[1], -uwall[2], uwall[0], &force[0], &lbf[spos], &lbf[spos+15*qdim],
                                 &lbf[spos+16*qdim], &lbf[spos+1*qdim], &lbf[spos+21*qdim], &lbf[spos+22*qdim],
                                 &lbf[spos+5*qdim], &lbf[spos+17*qdim], &lbf[spos+7*qdim], &lbf[spos+19*qdim],
                                 &lbf[spos+13*qdim], &lbf[spos+23*qdim], &lbf[spos+12*qdim], &lbf[spos+24*qdim],
                                 &lbf[spos+2*qdim], &lbf[spos+3*qdim], &lbf[spos+14*qdim], &lbf[spos+8*qdim],
                                 &lbf[spos+9*qdim], &lbf[spos+18*qdim], &lbf[spos+4*qdim], &lbf[spos+20*qdim],
                                 &lbf[spos+6*qdim], &lbf[spos+26*qdim], &lbf[spos+10*qdim], &lbf[spos+25*qdim],
                                 &lbf[spos+11*qdim]);
        break;
      case CERB:
        fD3Q27VCECLBESimpleZouHe(rho, uwall[0], -uwall[2], uwall[1], &force[0], &lbf[spos], &lbf[spos+1*qdim],
                                 &lbf[spos+16*qdim], &lbf[spos+2*qdim], &lbf[spos+7*qdim], &lbf[spos+6*qdim],
                                 &lbf[spos+4*qdim], &lbf[spos+5*qdim], &lbf[spos+9*qdim], &lbf[spos+21*qdim],
                                 &lbf[spos+11*qdim], &lbf[spos+13*qdim], &lbf[spos+10*qdim], &lbf[spos+12*qdim],
                                 &lbf[spos+14*qdim], &lbf[spos+3*qdim], &lbf[spos+15*qdim], &lbf[spos+20*qdim],
                                 &lbf[spos+19*qdim], &lbf[spos+17*qdim], &lbf[spos+18*qdim], &lbf[spos+22*qdim],
                                 &lbf[spos+8*qdim], &lbf[spos+24*qdim], &lbf[spos+26*qdim], &lbf[spos+23*qdim],
                                 &lbf[spos+25*qdim]);
        break;
    }
  }
  else {
    switch (prop) {
      case PST:
        fD3Q27VPSSimpleZouHe(uwall[0], uwall[1], uwall[2], &force[0], &lbf[spos], &lbf[spos+1*qdim],
                             &lbf[spos+2*qdim], &lbf[spos+3*qdim], &lbf[spos+4*qdim], &lbf[spos+5*qdim],
                             &lbf[spos+6*qdim], &lbf[spos+7*qdim], &lbf[spos+8*qdim], &lbf[spos+9*qdim],
                             &lbf[spos+10*qdim], &lbf[spos+11*qdim], &lbf[spos+12*qdim], &lbf[spos+13*qdim],
                             &lbf[spos+14*qdim], &lbf[spos+15*qdim], &lbf[spos+16*qdim], &lbf[spos+17*qdim],
                             &lbf[spos+18*qdim], &lbf[spos+19*qdim], &lbf[spos+20*qdim], &lbf[spos+21*qdim],
                             &lbf[spos+22*qdim], &lbf[spos+23*qdim], &lbf[spos+24*qdim], &lbf[spos+25*qdim],
                             &lbf[spos+26*qdim]);
        break;
      case PSD:
        fD3Q27VPSSimpleZouHe(-uwall[0], -uwall[1], -uwall[2], &force[0], &lbf[spos], &lbf[spos+14*qdim],
                             &lbf[spos+15*qdim], &lbf[spos+16*qdim], &lbf[spos+17*qdim], &lbf[spos+18*qdim],
                             &lbf[spos+19*qdim], &lbf[spos+20*qdim], &lbf[spos+21*qdim], &lbf[spos+22*qdim],
                             &lbf[spos+23*qdim], &lbf[spos+24*qdim], &lbf[spos+25*qdim], &lbf[spos+26*qdim],
                             &lbf[spos+1*qdim], &lbf[spos+2*qdim], &lbf[spos+3*qdim], &lbf[spos+4*qdim],
                             &lbf[spos+5*qdim], &lbf[spos+6*qdim], &lbf[spos+7*qdim], &lbf[spos+8*qdim],
                             &lbf[spos+9*qdim], &lbf[spos+10*qdim], &lbf[spos+11*qdim], &lbf[spos+12*qdim],
                             &lbf[spos+13*qdim]);
        break;
      case PSL:
        fD3Q27VPSSimpleZouHe(-uwall[2], -uwall[0], -uwall[1], &force[0], &lbf[spos], &lbf[spos+16*qdim],
                             &lbf[spos+14*qdim], &lbf[spos+15*qdim], &lbf[spos+19*qdim], &lbf[spos+7*qdim],
                             &lbf[spos+21*qdim], &lbf[spos+9*qdim], &lbf[spos+17*qdim], &lbf[spos+18*qdim],
                             &lbf[spos+23*qdim], &lbf[spos+25*qdim], &lbf[spos+13*qdim], &lbf[spos+11*qdim],
                             &lbf[spos+3*qdim], &lbf[spos+1*qdim], &lbf[spos+2*qdim], &lbf[spos+6*qdim],
                             &lbf[spos+20*qdim], &lbf[spos+8*qdim], &lbf[spos+22*qdim], &lbf[spos+4*qdim],
                             &lbf[spos+5*qdim], &lbf[spos+10*qdim], &lbf[spos+12*qdim], &lbf[spos+26*qdim],
                             &lbf[spos+24*qdim]);
        break;
      case PSR:
        fD3Q27VPSSimpleZouHe(uwall[2], uwall[0], uwall[1], &force[0], &lbf[spos], &lbf[spos+3*qdim],
                             &lbf[spos+1*qdim], &lbf[spos+2*qdim], &lbf[spos+6*qdim], &lbf[spos+20*qdim],
                             &lbf[spos+8*qdim], &lbf[spos+22*qdim], &lbf[spos+4*qdim], &lbf[spos+5*qdim],
                             &lbf[spos+10*qdim], &lbf[spos+12*qdim], &lbf[spos+26*qdim], &lbf[spos+24*qdim],
                             &lbf[spos+16*qdim], &lbf[spos+14*qdim], &lbf[spos+15*qdim], &lbf[spos+19*qdim],
                             &lbf[spos+7*qdim], &lbf[spos+21*qdim], &lbf[spos+9*qdim], &lbf[spos+17*qdim],
                             &lbf[spos+18*qdim], &lbf[spos+23*qdim], &lbf[spos+25*qdim], &lbf[spos+13*qdim],
                             &lbf[spos+11*qdim]);
        break;
      case PSF:
        fD3Q27VPSSimpleZouHe(-uwall[1], -uwall[2], -uwall[0], &force[0], &lbf[spos], &lbf[spos+15*qdim],
                             &lbf[spos+16*qdim], &lbf[spos+14*qdim], &lbf[spos+21*qdim], &lbf[spos+22*qdim],
                             &lbf[spos+17*qdim], &lbf[spos+5*qdim], &lbf[spos+19*qdim], &lbf[spos+7*qdim],
                             &lbf[spos+23*qdim], &lbf[spos+13*qdim], &lbf[spos+24*qdim], &lbf[spos+12*qdim],
                             &lbf[spos+2*qdim], &lbf[spos+3*qdim], &lbf[spos+1*qdim], &lbf[spos+8*qdim],
                             &lbf[spos+9*qdim], &lbf[spos+4*qdim], &lbf[spos+18*qdim], &lbf[spos+6*qdim],
                             &lbf[spos+20*qdim], &lbf[spos+10*qdim], &lbf[spos+26*qdim], &lbf[spos+11*qdim],
                             &lbf[spos+25*qdim]);
        break;
      case PSB:
        fD3Q27VPSSimpleZouHe(uwall[1], uwall[2], uwall[0], &force[0], &lbf[spos], &lbf[spos+2*qdim],
                             &lbf[spos+3*qdim], &lbf[spos+1*qdim], &lbf[spos+8*qdim], &lbf[spos+9*qdim],
                             &lbf[spos+4*qdim], &lbf[spos+18*qdim], &lbf[spos+6*qdim], &lbf[spos+20*qdim],
                             &lbf[spos+10*qdim], &lbf[spos+26*qdim], &lbf[spos+11*qdim], &lbf[spos+25*qdim],
                             &lbf[spos+15*qdim], &lbf[spos+16*qdim], &lbf[spos+14*qdim], &lbf[spos+21*qdim],
                             &lbf[spos+22*qdim], &lbf[spos+17*qdim], &lbf[spos+5*qdim], &lbf[spos+19*qdim],
                             &lbf[spos+7*qdim], &lbf[spos+23*qdim], &lbf[spos+13*qdim], &lbf[spos+24*qdim],
                             &lbf[spos+12*qdim]);
        break;
      case CCTRB:
        fD3Q27VCCSimpleZouHe(rho, uwall[0], uwall[1], -uwall[2], &force[0], &lbf[spos], &lbf[spos+1*qdim],
                             &lbf[spos+2*qdim], &lbf[spos+16*qdim], &lbf[spos+4*qdim], &lbf[spos+5*qdim],
                             &lbf[spos+7*qdim], &lbf[spos+6*qdim], &lbf[spos+9*qdim], &lbf[spos+8*qdim],
                             &lbf[spos+11*qdim], &lbf[spos+10*qdim], &lbf[spos+13*qdim], &lbf[spos+12*qdim],
                             &lbf[spos+14*qdim], &lbf[spos+15*qdim], &lbf[spos+3*qdim], &lbf[spos+17*qdim],
                             &lbf[spos+18*qdim], &lbf[spos+20*qdim], &lbf[spos+19*qdim], &lbf[spos+22*qdim],
                             &lbf[spos+21*qdim], &lbf[spos+24*qdim], &lbf[spos+23*qdim], &lbf[spos+26*qdim],
                             &lbf[spos+25*qdim]);
        break;
      case CCTLB:
        fD3Q27VCCSimpleZouHe(rho, -uwall[0], uwall[1], -uwall[2], &force[0], &lbf[spos], &lbf[spos+14*qdim],
                             &lbf[spos+2*qdim], &lbf[spos+16*qdim], &lbf[spos+18*qdim], &lbf[spos+17*qdim],
                             &lbf[spos+19*qdim], &lbf[spos+20*qdim], &lbf[spos+9*qdim], &lbf[spos+8*qdim],
                             &lbf[spos+25*qdim], &lbf[spos+26*qdim], &lbf[spos+23*qdim], &lbf[spos+24*qdim],
                             &lbf[spos+1*qdim], &lbf[spos+15*qdim], &lbf[spos+3*qdim], &lbf[spos+5*qdim],
                             &lbf[spos+4*qdim], &lbf[spos+6*qdim], &lbf[spos+7*qdim], &lbf[spos+22*qdim],
                             &lbf[spos+21*qdim], &lbf[spos+12*qdim], &lbf[spos+13*qdim], &lbf[spos+10*qdim],
                             &lbf[spos+11*qdim]);
        break;
      case CCDLB:
        fD3Q27VCCSimpleZouHe(rho, -uwall[0], -uwall[1], -uwall[2], &force[0], &lbf[spos], &lbf[spos+14*qdim],
                             &lbf[spos+15*qdim], &lbf[spos+16*qdim], &lbf[spos+17*qdim], &lbf[spos+18*qdim],
                             &lbf[spos+19*qdim], &lbf[spos+20*qdim], &lbf[spos+21*qdim], &lbf[spos+22*qdim],
                             &lbf[spos+23*qdim], &lbf[spos+24*qdim], &lbf[spos+25*qdim], &lbf[spos+26*qdim],
                             &lbf[spos+1*qdim], &lbf[spos+2*qdim], &lbf[spos+3*qdim], &lbf[spos+4*qdim],
                             &lbf[spos+5*qdim], &lbf[spos+6*qdim], &lbf[spos+7*qdim], &lbf[spos+8*qdim],
                             &lbf[spos+9*qdim], &lbf[spos+10*qdim], &lbf[spos+11*qdim], &lbf[spos+12*qdim],
                             &lbf[spos+13*qdim]);
        break;
      case CCDRB:
        fD3Q27VCCSimpleZouHe(rho, uwall[0], -uwall[1], -uwall[2], &force[0], &lbf[spos], &lbf[spos+1*qdim],
                             &lbf[spos+15*qdim], &lbf[spos+16*qdim], &lbf[spos+5*qdim], &lbf[spos+4*qdim],
                             &lbf[spos+7*qdim], &lbf[spos+6*qdim], &lbf[spos+21*qdim], &lbf[spos+22*qdim],
                             &lbf[spos+13*qdim], &lbf[spos+12*qdim], &lbf[spos+11*qdim], &lbf[spos+10*qdim],
                             &lbf[spos+14*qdim], &lbf[spos+2*qdim], &lbf[spos+3*qdim], &lbf[spos+18*qdim],
                             &lbf[spos+17*qdim], &lbf[spos+20*qdim], &lbf[spos+19*qdim], &lbf[spos+8*qdim],
                             &lbf[spos+9*qdim], &lbf[spos+26*qdim], &lbf[spos+25*qdim], &lbf[spos+24*qdim],
                             &lbf[spos+23*qdim]);
        break;
      case CCTRF:
        fD3Q27VCCSimpleZouHe(rho, uwall[0], uwall[1], uwall[2], &force[0], &lbf[spos], &lbf[spos+1*qdim],
                             &lbf[spos+2*qdim], &lbf[spos+3*qdim], &lbf[spos+4*qdim], &lbf[spos+5*qdim],
                             &lbf[spos+6*qdim], &lbf[spos+7*qdim], &lbf[spos+8*qdim], &lbf[spos+9*qdim],
                             &lbf[spos+10*qdim], &lbf[spos+11*qdim], &lbf[spos+12*qdim], &lbf[spos+13*qdim],
                             &lbf[spos+14*qdim], &lbf[spos+15*qdim], &lbf[spos+16*qdim], &lbf[spos+17*qdim],
                             &lbf[spos+18*qdim], &lbf[spos+19*qdim], &lbf[spos+20*qdim], &lbf[spos+21*qdim],
                             &lbf[spos+22*qdim], &lbf[spos+23*qdim], &lbf[spos+24*qdim], &lbf[spos+25*qdim],
                             &lbf[spos+26*qdim]);
        break;
      case CCTLF:
        fD3Q27VCCSimpleZouHe(rho, -uwall[0], uwall[1], uwall[2], &force[0], &lbf[spos], &lbf[spos+14*qdim],
                             &lbf[spos+2*qdim], &lbf[spos+3*qdim], &lbf[spos+18*qdim], &lbf[spos+17*qdim],
                             &lbf[spos+20*qdim], &lbf[spos+19*qdim], &lbf[spos+8*qdim], &lbf[spos+9*qdim],
                             &lbf[spos+26*qdim], &lbf[spos+25*qdim], &lbf[spos+24*qdim], &lbf[spos+23*qdim],
                             &lbf[spos+1*qdim], &lbf[spos+15*qdim], &lbf[spos+16*qdim], &lbf[spos+5*qdim],
                             &lbf[spos+4*qdim], &lbf[spos+7*qdim], &lbf[spos+6*qdim], &lbf[spos+21*qdim],
                             &lbf[spos+22*qdim], &lbf[spos+13*qdim], &lbf[spos+12*qdim], &lbf[spos+11*qdim],
                             &lbf[spos+10*qdim]);
        break;
      case CCDLF:
        fD3Q27VCCSimpleZouHe(rho, -uwall[0], -uwall[1], uwall[2], &force[0], &lbf[spos], &lbf[spos+14*qdim],
                             &lbf[spos+15*qdim], &lbf[spos+3*qdim], &lbf[spos+17*qdim], &lbf[spos+18*qdim],
                             &lbf[spos+20*qdim], &lbf[spos+19*qdim], &lbf[spos+22*qdim], &lbf[spos+21*qdim],
                             &lbf[spos+24*qdim], &lbf[spos+23*qdim], &lbf[spos+26*qdim], &lbf[spos+25*qdim],
                             &lbf[spos+1*qdim], &lbf[spos+2*qdim], &lbf[spos+16*qdim], &lbf[spos+4*qdim],
                             &lbf[spos+5*qdim], &lbf[spos+7*qdim], &lbf[spos+6*qdim], &lbf[spos+9*qdim],
                             &lbf[spos+8*qdim], &lbf[spos+11*qdim], &lbf[spos+10*qdim], &lbf[spos+13*qdim],
                             &lbf[spos+12*qdim]);
        break;
      case CCDRF:
        fD3Q27VCCSimpleZouHe(rho, uwall[0], -uwall[1], uwall[2], &force[0], &lbf[spos], &lbf[spos+1*qdim],
                             &lbf[spos+15*qdim], &lbf[spos+3*qdim], &lbf[spos+5*qdim], &lbf[spos+4*qdim],
                             &lbf[spos+6*qdim], &lbf[spos+7*qdim], &lbf[spos+22*qdim], &lbf[spos+21*qdim],
                             &lbf[spos+12*qdim], &lbf[spos+13*qdim], &lbf[spos+10*qdim], &lbf[spos+11*qdim],
                             &lbf[spos+14*qdim], &lbf[spos+2*qdim], &lbf[spos+16*qdim], &lbf[spos+18*qdim],
                             &lbf[spos+17*qdim], &lbf[spos+19*qdim], &lbf[spos+20*qdim], &lbf[spos+9*qdim],
                             &lbf[spos+8*qdim], &lbf[spos+25*qdim], &lbf[spos+26*qdim], &lbf[spos+23*qdim],
                             &lbf[spos+24*qdim]);
        break;
      case CETR:
        fD3Q27VCESimpleZouHe(rho, uwall[0], uwall[1], uwall[2], &force[0], &lbf[spos], &lbf[spos+1*qdim],
                             &lbf[spos+2*qdim], &lbf[spos+3*qdim], &lbf[spos+4*qdim], &lbf[spos+5*qdim],
                             &lbf[spos+6*qdim], &lbf[spos+7*qdim], &lbf[spos+8*qdim], &lbf[spos+9*qdim],
                             &lbf[spos+10*qdim], &lbf[spos+11*qdim], &lbf[spos+12*qdim], &lbf[spos+13*qdim],
                             &lbf[spos+14*qdim], &lbf[spos+15*qdim], &lbf[spos+16*qdim], &lbf[spos+17*qdim],
                             &lbf[spos+18*qdim], &lbf[spos+19*qdim], &lbf[spos+20*qdim], &lbf[spos+21*qdim],
                             &lbf[spos+22*qdim], &lbf[spos+23*qdim], &lbf[spos+24*qdim], &lbf[spos+25*qdim],
                             &lbf[spos+26*qdim]);
        break;
      case CETL:
        fD3Q27VCESimpleZouHe(rho, uwall[1], -uwall[0], uwall[2], &force[0], &lbf[spos], &lbf[spos+2*qdim],
                             &lbf[spos+14*qdim], &lbf[spos+3*qdim], &lbf[spos+18*qdim], &lbf[spos+4*qdim],
                             &lbf[spos+8*qdim], &lbf[spos+9*qdim], &lbf[spos+20*qdim], &lbf[spos+19*qdim],
                             &lbf[spos+26*qdim], &lbf[spos+25*qdim], &lbf[spos+10*qdim], &lbf[spos+11*qdim],
                             &lbf[spos+15*qdim], &lbf[spos+1*qdim], &lbf[spos+16*qdim], &lbf[spos+5*qdim],
                             &lbf[spos+17*qdim], &lbf[spos+21*qdim], &lbf[spos+22*qdim], &lbf[spos+7*qdim],
                             &lbf[spos+6*qdim], &lbf[spos+13*qdim], &lbf[spos+12*qdim], &lbf[spos+23*qdim],
                             &lbf[spos+24*qdim]);
        break;
      case CEDL:
        fD3Q27VCESimpleZouHe(rho, -uwall[0], -uwall[1], uwall[2], &force[0], &lbf[spos], &lbf[spos+14*qdim],
                             &lbf[spos+15*qdim], &lbf[spos+3*qdim], &lbf[spos+17*qdim], &lbf[spos+18*qdim],
                             &lbf[spos+20*qdim], &lbf[spos+19*qdim], &lbf[spos+22*qdim], &lbf[spos+21*qdim],
                             &lbf[spos+24*qdim], &lbf[spos+23*qdim], &lbf[spos+26*qdim], &lbf[spos+25*qdim],
                             &lbf[spos+1*qdim], &lbf[spos+2*qdim], &lbf[spos+16*qdim], &lbf[spos+4*qdim],
                             &lbf[spos+5*qdim], &lbf[spos+7*qdim], &lbf[spos+6*qdim], &lbf[spos+9*qdim],
                             &lbf[spos+8*qdim], &lbf[spos+11*qdim], &lbf[spos+10*qdim], &lbf[spos+13*qdim],
                             &lbf[spos+12*qdim]);
        break;
      case CEDR:
        fD3Q27VCESimpleZouHe(rho, -uwall[1], uwall[0], uwall[2], &force[0], &lbf[spos], &lbf[spos+15*qdim],
                             &lbf[spos+1*qdim], &lbf[spos+3*qdim], &lbf[spos+5*qdim], &lbf[spos+17*qdim],
                             &lbf[spos+22*qdim], &lbf[spos+21*qdim], &lbf[spos+6*qdim], &lbf[spos+7*qdim],
                             &lbf[spos+12*qdim], &lbf[spos+13*qdim], &lbf[spos+24*qdim], &lbf[spos+23*qdim],
                             &lbf[spos+2*qdim], &lbf[spos+14*qdim], &lbf[spos+16*qdim], &lbf[spos+18*qdim],
                             &lbf[spos+4*qdim], &lbf[spos+9*qdim], &lbf[spos+8*qdim], &lbf[spos+19*qdim],
                             &lbf[spos+20*qdim], &lbf[spos+25*qdim], &lbf[spos+26*qdim], &lbf[spos+11*qdim],
                             &lbf[spos+10*qdim]);
        break;
      case CETF:
        fD3Q27VCESimpleZouHe(rho, uwall[1], uwall[2], uwall[0], &force[0], &lbf[spos], &lbf[spos+2*qdim],
                             &lbf[spos+3*qdim], &lbf[spos+1*qdim], &lbf[spos+8*qdim], &lbf[spos+9*qdim],
                             &lbf[spos+4*qdim], &lbf[spos+18*qdim], &lbf[spos+6*qdim], &lbf[spos+20*qdim],
                             &lbf[spos+10*qdim], &lbf[spos+26*qdim], &lbf[spos+11*qdim], &lbf[spos+25*qdim],
                             &lbf[spos+15*qdim], &lbf[spos+16*qdim], &lbf[spos+14*qdim], &lbf[spos+21*qdim],
                             &lbf[spos+22*qdim], &lbf[spos+17*qdim], &lbf[spos+5*qdim], &lbf[spos+19*qdim],
                             &lbf[spos+7*qdim], &lbf[spos+23*qdim], &lbf[spos+13*qdim], &lbf[spos+24*qdim],
                             &lbf[spos+12*qdim]);
        break;
      case CELF:
        fD3Q27VCESimpleZouHe(rho, -uwall[0], uwall[1], uwall[2], &force[0], &lbf[spos], &lbf[spos+14*qdim],
                             &lbf[spos+3*qdim], &lbf[spos+2*qdim], &lbf[spos+20*qdim], &lbf[spos+19*qdim],
                             &lbf[spos+18*qdim], &lbf[spos+17*qdim], &lbf[spos+8*qdim], &lbf[spos+22*qdim],
                             &lbf[spos+26*qdim], &lbf[spos+24*qdim], &lbf[spos+25*qdim], &lbf[spos+23*qdim],
                             &lbf[spos+1*qdim], &lbf[spos+16*qdim], &lbf[spos+15*qdim], &lbf[spos+7*qdim],
                             &lbf[spos+6*qdim], &lbf[spos+5*qdim], &lbf[spos+4*qdim], &lbf[spos+21*qdim],
                             &lbf[spos+9*qdim], &lbf[spos+13*qdim], &lbf[spos+11*qdim], &lbf[spos+12*qdim],
                             &lbf[spos+10*qdim]);
        break;
      case CEDF:
        fD3Q27VCESimpleZouHe(rho, -uwall[1], uwall[2], uwall[0], &force[0], &lbf[spos], &lbf[spos+15*qdim],
                             &lbf[spos+3*qdim], &lbf[spos+1*qdim], &lbf[spos+22*qdim], &lbf[spos+21*qdim],
                             &lbf[spos+5*qdim], &lbf[spos+17*qdim], &lbf[spos+6*qdim], &lbf[spos+20*qdim],
                             &lbf[spos+12*qdim], &lbf[spos+24*qdim], &lbf[spos+13*qdim], &lbf[spos+23*qdim],
                             &lbf[spos+2*qdim], &lbf[spos+16*qdim], &lbf[spos+14*qdim], &lbf[spos+9*qdim],
                             &lbf[spos+8*qdim], &lbf[spos+18*qdim], &lbf[spos+4*qdim], &lbf[spos+19*qdim],
                             &lbf[spos+7*qdim], &lbf[spos+25*qdim], &lbf[spos+11*qdim], &lbf[spos+26*qdim],
                             &lbf[spos+10*qdim]);
        break;
      case CERF:
        fD3Q27VCESimpleZouHe(rho, uwall[0], uwall[2], uwall[2], &force[0], &lbf[spos], &lbf[spos+1*qdim],
                             &lbf[spos+3*qdim], &lbf[spos+2*qdim], &lbf[spos+6*qdim], &lbf[spos+7*qdim],
                             &lbf[spos+4*qdim], &lbf[spos+5*qdim], &lbf[spos+8*qdim], &lbf[spos+22*qdim],
                             &lbf[spos+10*qdim], &lbf[spos+12*qdim], &lbf[spos+11*qdim], &lbf[spos+13*qdim],
                             &lbf[spos+14*qdim], &lbf[spos+16*qdim], &lbf[spos+15*qdim], &lbf[spos+19*qdim],
                             &lbf[spos+20*qdim], &lbf[spos+17*qdim], &lbf[spos+18*qdim], &lbf[spos+21*qdim],
                             &lbf[spos+9*qdim], &lbf[spos+23*qdim], &lbf[spos+25*qdim], &lbf[spos+24*qdim],
                             &lbf[spos+26*qdim]);
        break;
      case CETB:
        fD3Q27VCESimpleZouHe(rho, uwall[1], -uwall[2], uwall[0], &force[0], &lbf[spos], &lbf[spos+2*qdim],
                             &lbf[spos+16*qdim], &lbf[spos+1*qdim], &lbf[spos+9*qdim], &lbf[spos+8*qdim],
                             &lbf[spos+4*qdim], &lbf[spos+18*qdim], &lbf[spos+7*qdim], &lbf[spos+19*qdim],
                             &lbf[spos+11*qdim], &lbf[spos+25*qdim], &lbf[spos+10*qdim], &lbf[spos+26*qdim],
                             &lbf[spos+15*qdim], &lbf[spos+3*qdim], &lbf[spos+14*qdim], &lbf[spos+22*qdim],
                             &lbf[spos+21*qdim], &lbf[spos+17*qdim], &lbf[spos+5*qdim], &lbf[spos+20*qdim],
                             &lbf[spos+6*qdim], &lbf[spos+24*qdim], &lbf[spos+12*qdim], &lbf[spos+23*qdim],
                             &lbf[spos+13*qdim]);
        break;
      case CELB:
        fD3Q27VCESimpleZouHe(rho, -uwall[0], -uwall[2], uwall[1], &force[0], &lbf[spos], &lbf[spos+14*qdim],
                             &lbf[spos+16*qdim], &lbf[spos+2*qdim], &lbf[spos+19*qdim], &lbf[spos+20*qdim],
                             &lbf[spos+18*qdim], &lbf[spos+17*qdim], &lbf[spos+9*qdim], &lbf[spos+21*qdim],
                             &lbf[spos+25*qdim], &lbf[spos+23*qdim], &lbf[spos+26*qdim], &lbf[spos+24*qdim],
                             &lbf[spos+1*qdim], &lbf[spos+3*qdim], &lbf[spos+15*qdim], &lbf[spos+6*qdim],
                             &lbf[spos+7*qdim], &lbf[spos+5*qdim], &lbf[spos+4*qdim], &lbf[spos+22*qdim],
                             &lbf[spos+8*qdim], &lbf[spos+12*qdim], &lbf[spos+10*qdim], &lbf[spos+13*qdim],
                             &lbf[spos+11*qdim]);
        break;
      case CEDB:
        fD3Q27VCESimpleZouHe(rho, -uwall[1], -uwall[2], uwall[0], &force[0], &lbf[spos], &lbf[spos+15*qdim],
                             &lbf[spos+16*qdim], &lbf[spos+1*qdim], &lbf[spos+21*qdim], &lbf[spos+22*qdim],
                             &lbf[spos+5*qdim], &lbf[spos+17*qdim], &lbf[spos+7*qdim], &lbf[spos+19*qdim],
                             &lbf[spos+13*qdim], &lbf[spos+23*qdim], &lbf[spos+12*qdim], &lbf[spos+24*qdim],
                             &lbf[spos+2*qdim], &lbf[spos+3*qdim], &lbf[spos+14*qdim], &lbf[spos+8*qdim],
                             &lbf[spos+9*qdim], &lbf[spos+18*qdim], &lbf[spos+4*qdim], &lbf[spos+20*qdim],
                             &lbf[spos+6*qdim], &lbf[spos+26*qdim], &lbf[spos+10*qdim], &lbf[spos+25*qdim],
                             &lbf[spos+11*qdim]);
        break;
      case CERB:
        fD3Q27VCESimpleZouHe(rho, uwall[0], -uwall[2], uwall[1], &force[0], &lbf[spos], &lbf[spos+1*qdim],
                             &lbf[spos+16*qdim], &lbf[spos+2*qdim], &lbf[spos+7*qdim], &lbf[spos+6*qdim],
                             &lbf[spos+4*qdim], &lbf[spos+5*qdim], &lbf[spos+9*qdim], &lbf[spos+21*qdim],
                             &lbf[spos+11*qdim], &lbf[spos+13*qdim], &lbf[spos+10*qdim], &lbf[spos+12*qdim],
                             &lbf[spos+14*qdim], &lbf[spos+3*qdim], &lbf[spos+15*qdim], &lbf[spos+20*qdim],
                             &lbf[spos+19*qdim], &lbf[spos+17*qdim], &lbf[spos+18*qdim], &lbf[spos+22*qdim],
                             &lbf[spos+8*qdim], &lbf[spos+24*qdim], &lbf[spos+26*qdim], &lbf[spos+23*qdim],
                             &lbf[spos+25*qdim]);
        break;
    }
  }
  return 0;
}


int fD3Q27PPSZouHe(double *p, double *force, double *f0, double *f1,
                   double *f2, double *f3, double *f4, double *f5,
                   double *f6, double *f7, double *f8, double *f9,
                   double *f10, double *f11, double *f12, double *f13,
                   double *f14, double *f15, double *f16, double *f17,
                   double *f18, double *f19, double *f20, double *f21,
                   double *f22, double *f23, double *f24, double *f25,
                   double *f26, double &vel)
{

  // produce fixed pressure/density at planar surface: expressed for bottom wall

  double rx, rz, v, mass=0.0;
  double c1=4.0/9.0,c2=1.0/9.0,c3=1.0/36.0,c4=1.0/6.0,c5=1.0/12.0;
  vel=0.0;
  if(!incompress) {
    for(int i=0; i<lbsy.nf; i++) {
      v=p[i]-(f0[i]+f1[i]+f3[i]+f6[i]+f7[i]+f14[i]+f16[i]+f19[i]+f20[i]+2.0*(f2[i]+f4[i]+f8[i]+f9[i]+f10[i]+f11[i]+f18[i]+f25[i]+f26[i]))+0.5*force[3*i+1];
      vel += v;
      mass += p[i];
      rx=c4*(f14[i]-f1[i]-f6[i]-f7[i]+f19[i]+f20[i])+c5*force[3*i  ];
      rz=c4*(f16[i]-f3[i]-f6[i]+f7[i]+f19[i]-f20[i])+c5*force[3*i+2];
      f5[i]=f18[i]+c2*v+rx;
      f12[i]=f25[i]+c3*v+rx+rz;
      f13[i]=f26[i]+c3*v+rx-rz;
      f15[i]=f2[i]+c1*v;
      f17[i]=f4[i]+c2*v-rx;
      f21[i]=f8[i]+c2*v-rz;
      f22[i]=f9[i]+c2*v+rz;
      f23[i]=f10[i]+c3*v-rx-rz;
      f24[i]=f11[i]+c3*v-rx+rz;
    }
  }
  else {
    for(int i=0; i<lbsy.nf; i++) {
      v=p[i]-(f0[i]+f1[i]+f3[i]+f6[i]+f7[i]+f14[i]+f16[i]+f19[i]+f20[i]+2.0*(f2[i]+f4[i]+f8[i]+f9[i]+f10[i]+f11[i]+f18[i]+f25[i]+f26[i]))+0.5*force[3*i+1];
      vel += v;
      mass += lbincp[i];
      rx=c4*(f14[i]-f1[i]-f6[i]-f7[i]+f19[i]+f20[i])+c5*force[3*i  ];
      rz=c4*(f16[i]-f3[i]-f6[i]+f7[i]+f19[i]-f20[i])+c5*force[3*i+2];
      f5[i]=f18[i]+c2*v+rx;
      f12[i]=f25[i]+c3*v+rx+rz;
      f13[i]=f26[i]+c3*v+rx-rz;
      f15[i]=f2[i]+c1*v;
      f17[i]=f4[i]+c2*v-rx;
      f21[i]=f8[i]+c2*v-rz;
      f22[i]=f9[i]+c2*v+rz;
      f23[i]=f10[i]+c3*v-rx-rz;
      f24[i]=f11[i]+c3*v-rx+rz;
    }
  }
  vel *= fReciprocal(mass);
  return 0;
}


int fD3Q27PFZouHe(long tpos, int prop, double *p0, double *uwall)
{
  double moment;
  long spos=tpos * lbsitelength;
  int qdim=lbsy.nf+lbsy.nc+lbsy.nt;
  double force[3*lbsy.nf];

  // sort out forces
    
  fD3Q27BoundaryForceDensity(force, tpos, p0, prop);

  // apply boundary condition

  if(collide>11) {
    switch (prop) {
      case PST:
        fD3Q27PPSZouHe(p0, &force[0], &lbf[spos], &lbf[spos+1*qdim],
                       &lbf[spos+2*qdim], &lbf[spos+3*qdim], &lbf[spos+4*qdim], &lbf[spos+5*qdim],
                       &lbf[spos+6*qdim], &lbf[spos+7*qdim], &lbf[spos+8*qdim], &lbf[spos+9*qdim],
                       &lbf[spos+10*qdim], &lbf[spos+11*qdim], &lbf[spos+12*qdim], &lbf[spos+13*qdim],
                       &lbf[spos+14*qdim], &lbf[spos+15*qdim], &lbf[spos+16*qdim], &lbf[spos+17*qdim],
                       &lbf[spos+18*qdim], &lbf[spos+19*qdim], &lbf[spos+20*qdim], &lbf[spos+21*qdim],
                       &lbf[spos+22*qdim], &lbf[spos+23*qdim], &lbf[spos+24*qdim], &lbf[spos+25*qdim],
                       &lbf[spos+26*qdim], moment);
        uwall[1] += moment;
        break;
      case PSD:
        fD3Q27PPSZouHe(p0, &force[0], &lbf[spos], &lbf[spos+14*qdim],
                       &lbf[spos+15*qdim], &lbf[spos+16*qdim], &lbf[spos+17*qdim], &lbf[spos+18*qdim],
                       &lbf[spos+19*qdim], &lbf[spos+20*qdim], &lbf[spos+21*qdim], &lbf[spos+22*qdim],
                       &lbf[spos+23*qdim], &lbf[spos+24*qdim], &lbf[spos+25*qdim], &lbf[spos+26*qdim],
                       &lbf[spos+1*qdim], &lbf[spos+2*qdim], &lbf[spos+3*qdim], &lbf[spos+4*qdim],
                       &lbf[spos+5*qdim], &lbf[spos+6*qdim], &lbf[spos+7*qdim], &lbf[spos+8*qdim],
                       &lbf[spos+9*qdim], &lbf[spos+10*qdim], &lbf[spos+11*qdim], &lbf[spos+12*qdim],
                       &lbf[spos+13*qdim], moment);
        uwall[1] -= moment;
        break;
      case PSL:
        fD3Q27PPSZouHe(p0, &force[0], &lbf[spos], &lbf[spos+16*qdim],
                       &lbf[spos+14*qdim], &lbf[spos+15*qdim], &lbf[spos+19*qdim], &lbf[spos+7*qdim],
                       &lbf[spos+21*qdim], &lbf[spos+9*qdim], &lbf[spos+17*qdim], &lbf[spos+18*qdim],
                       &lbf[spos+23*qdim], &lbf[spos+25*qdim], &lbf[spos+13*qdim], &lbf[spos+11*qdim],
                       &lbf[spos+3*qdim], &lbf[spos+1*qdim], &lbf[spos+2*qdim], &lbf[spos+6*qdim],
                       &lbf[spos+20*qdim], &lbf[spos+8*qdim], &lbf[spos+22*qdim], &lbf[spos+4*qdim],
                       &lbf[spos+5*qdim], &lbf[spos+10*qdim], &lbf[spos+12*qdim], &lbf[spos+26*qdim],
                       &lbf[spos+24*qdim], moment);
        uwall[0] -= moment;
        break;
      case PSR:
        fD3Q27PPSZouHe(p0, &force[0], &lbf[spos], &lbf[spos+3*qdim],
                       &lbf[spos+1*qdim], &lbf[spos+2*qdim], &lbf[spos+6*qdim], &lbf[spos+20*qdim],
                       &lbf[spos+8*qdim], &lbf[spos+22*qdim], &lbf[spos+4*qdim], &lbf[spos+5*qdim],
                       &lbf[spos+10*qdim], &lbf[spos+12*qdim], &lbf[spos+26*qdim], &lbf[spos+24*qdim],
                       &lbf[spos+16*qdim], &lbf[spos+14*qdim], &lbf[spos+15*qdim], &lbf[spos+19*qdim],
                       &lbf[spos+7*qdim], &lbf[spos+21*qdim], &lbf[spos+9*qdim], &lbf[spos+17*qdim],
                       &lbf[spos+18*qdim], &lbf[spos+23*qdim], &lbf[spos+25*qdim], &lbf[spos+13*qdim],
                       &lbf[spos+11*qdim], moment);
        uwall[0] += moment;
        break;
      case PSF:
        fD3Q27PPSZouHe(p0, &force[0], &lbf[spos], &lbf[spos+15*qdim],
                       &lbf[spos+16*qdim], &lbf[spos+14*qdim], &lbf[spos+21*qdim], &lbf[spos+22*qdim],
                       &lbf[spos+17*qdim], &lbf[spos+5*qdim], &lbf[spos+19*qdim], &lbf[spos+7*qdim],
                       &lbf[spos+23*qdim], &lbf[spos+13*qdim], &lbf[spos+24*qdim], &lbf[spos+12*qdim],
                       &lbf[spos+2*qdim], &lbf[spos+3*qdim], &lbf[spos+1*qdim], &lbf[spos+8*qdim],
                       &lbf[spos+9*qdim], &lbf[spos+4*qdim], &lbf[spos+18*qdim], &lbf[spos+6*qdim],
                       &lbf[spos+20*qdim], &lbf[spos+10*qdim], &lbf[spos+26*qdim], &lbf[spos+11*qdim],
                       &lbf[spos+25*qdim], moment);
        uwall[2] -= moment;
        break;
      case PSB:
        fD3Q27PPSZouHe(p0, &force[0], &lbf[spos], &lbf[spos+2*qdim],
                       &lbf[spos+3*qdim], &lbf[spos+1*qdim], &lbf[spos+8*qdim], &lbf[spos+9*qdim],
                       &lbf[spos+4*qdim], &lbf[spos+18*qdim], &lbf[spos+6*qdim], &lbf[spos+20*qdim],
                       &lbf[spos+10*qdim], &lbf[spos+26*qdim], &lbf[spos+11*qdim], &lbf[spos+25*qdim],
                       &lbf[spos+15*qdim], &lbf[spos+16*qdim], &lbf[spos+14*qdim], &lbf[spos+21*qdim],
                       &lbf[spos+22*qdim], &lbf[spos+17*qdim], &lbf[spos+5*qdim], &lbf[spos+19*qdim],
                       &lbf[spos+7*qdim], &lbf[spos+23*qdim], &lbf[spos+13*qdim], &lbf[spos+24*qdim],
                       &lbf[spos+12*qdim], moment);
        uwall[2] += moment;
        break;
      case CCTRB:
        fD3Q27VCCCLBEZouHe(p0, uwall[0], uwall[1], -uwall[2], &force[0], &lbf[spos], &lbf[spos+1*qdim],
                           &lbf[spos+2*qdim], &lbf[spos+16*qdim], &lbf[spos+4*qdim], &lbf[spos+5*qdim],
                           &lbf[spos+7*qdim], &lbf[spos+6*qdim], &lbf[spos+9*qdim], &lbf[spos+8*qdim],
                           &lbf[spos+11*qdim], &lbf[spos+10*qdim], &lbf[spos+13*qdim], &lbf[spos+12*qdim],
                           &lbf[spos+14*qdim], &lbf[spos+15*qdim], &lbf[spos+3*qdim], &lbf[spos+17*qdim],
                           &lbf[spos+18*qdim], &lbf[spos+20*qdim], &lbf[spos+19*qdim], &lbf[spos+22*qdim],
                           &lbf[spos+21*qdim], &lbf[spos+24*qdim], &lbf[spos+23*qdim], &lbf[spos+26*qdim],
                           &lbf[spos+25*qdim]);
        break;
      case CCTLB:
        fD3Q27VCCCLBEZouHe(p0, -uwall[0], uwall[1], -uwall[2], &force[0], &lbf[spos], &lbf[spos+14*qdim],
                           &lbf[spos+2*qdim], &lbf[spos+16*qdim], &lbf[spos+18*qdim], &lbf[spos+17*qdim],
                           &lbf[spos+19*qdim], &lbf[spos+20*qdim], &lbf[spos+9*qdim], &lbf[spos+8*qdim],
                           &lbf[spos+25*qdim], &lbf[spos+26*qdim], &lbf[spos+23*qdim], &lbf[spos+24*qdim],
                           &lbf[spos+1*qdim], &lbf[spos+15*qdim], &lbf[spos+3*qdim], &lbf[spos+5*qdim],
                           &lbf[spos+4*qdim], &lbf[spos+6*qdim], &lbf[spos+7*qdim], &lbf[spos+22*qdim],
                           &lbf[spos+21*qdim], &lbf[spos+12*qdim], &lbf[spos+13*qdim], &lbf[spos+10*qdim],
                           &lbf[spos+11*qdim]);
        break;
      case CCDLB:
        fD3Q27VCCCLBEZouHe(p0, -uwall[0], -uwall[1], -uwall[2], &force[0], &lbf[spos], &lbf[spos+14*qdim],
                           &lbf[spos+15*qdim], &lbf[spos+16*qdim], &lbf[spos+17*qdim], &lbf[spos+18*qdim],
                           &lbf[spos+19*qdim], &lbf[spos+20*qdim], &lbf[spos+21*qdim], &lbf[spos+22*qdim],
                           &lbf[spos+23*qdim], &lbf[spos+24*qdim], &lbf[spos+25*qdim], &lbf[spos+26*qdim],
                           &lbf[spos+1*qdim], &lbf[spos+2*qdim], &lbf[spos+3*qdim], &lbf[spos+4*qdim],
                           &lbf[spos+5*qdim], &lbf[spos+6*qdim], &lbf[spos+7*qdim], &lbf[spos+8*qdim],
                           &lbf[spos+9*qdim], &lbf[spos+10*qdim], &lbf[spos+11*qdim], &lbf[spos+12*qdim],
                           &lbf[spos+13*qdim]);
        break;
      case CCDRB:
        fD3Q27VCCCLBEZouHe(p0, uwall[0], -uwall[1], -uwall[2], &force[0], &lbf[spos], &lbf[spos+1*qdim],
                           &lbf[spos+15*qdim], &lbf[spos+16*qdim], &lbf[spos+5*qdim], &lbf[spos+4*qdim],
                           &lbf[spos+7*qdim], &lbf[spos+6*qdim], &lbf[spos+21*qdim], &lbf[spos+22*qdim],
                           &lbf[spos+13*qdim], &lbf[spos+12*qdim], &lbf[spos+11*qdim], &lbf[spos+10*qdim],
                           &lbf[spos+14*qdim], &lbf[spos+2*qdim], &lbf[spos+3*qdim], &lbf[spos+18*qdim],
                           &lbf[spos+17*qdim], &lbf[spos+20*qdim], &lbf[spos+19*qdim], &lbf[spos+8*qdim],
                           &lbf[spos+9*qdim], &lbf[spos+26*qdim], &lbf[spos+25*qdim], &lbf[spos+24*qdim],
                           &lbf[spos+23*qdim]);
        break;
      case CCTRF:
        fD3Q27VCCCLBEZouHe(p0, uwall[0], uwall[1], uwall[2], &force[0], &lbf[spos], &lbf[spos+1*qdim],
                           &lbf[spos+2*qdim], &lbf[spos+3*qdim], &lbf[spos+4*qdim], &lbf[spos+5*qdim],
                           &lbf[spos+6*qdim], &lbf[spos+7*qdim], &lbf[spos+8*qdim], &lbf[spos+9*qdim],
                           &lbf[spos+10*qdim], &lbf[spos+11*qdim], &lbf[spos+12*qdim], &lbf[spos+13*qdim],
                           &lbf[spos+14*qdim], &lbf[spos+15*qdim], &lbf[spos+16*qdim], &lbf[spos+17*qdim],
                           &lbf[spos+18*qdim], &lbf[spos+19*qdim], &lbf[spos+20*qdim], &lbf[spos+21*qdim],
                           &lbf[spos+22*qdim], &lbf[spos+23*qdim], &lbf[spos+24*qdim], &lbf[spos+25*qdim],
                           &lbf[spos+26*qdim]);
        break;
      case CCTLF:
        fD3Q27VCCCLBEZouHe(p0, -uwall[0], uwall[1], uwall[2], &force[0], &lbf[spos], &lbf[spos+14*qdim],
                           &lbf[spos+2*qdim], &lbf[spos+3*qdim], &lbf[spos+18*qdim], &lbf[spos+17*qdim],
                           &lbf[spos+20*qdim], &lbf[spos+19*qdim], &lbf[spos+8*qdim], &lbf[spos+9*qdim],
                           &lbf[spos+26*qdim], &lbf[spos+25*qdim], &lbf[spos+24*qdim], &lbf[spos+23*qdim],
                           &lbf[spos+1*qdim], &lbf[spos+15*qdim], &lbf[spos+16*qdim], &lbf[spos+5*qdim],
                           &lbf[spos+4*qdim], &lbf[spos+7*qdim], &lbf[spos+6*qdim], &lbf[spos+21*qdim],
                           &lbf[spos+22*qdim], &lbf[spos+13*qdim], &lbf[spos+12*qdim], &lbf[spos+11*qdim],
                           &lbf[spos+10*qdim]);
        break;
      case CCDLF:
        fD3Q27VCCCLBEZouHe(p0, -uwall[0], -uwall[1], uwall[2], &force[0], &lbf[spos], &lbf[spos+14*qdim],
                           &lbf[spos+15*qdim], &lbf[spos+3*qdim], &lbf[spos+17*qdim], &lbf[spos+18*qdim],
                           &lbf[spos+20*qdim], &lbf[spos+19*qdim], &lbf[spos+22*qdim], &lbf[spos+21*qdim],
                           &lbf[spos+24*qdim], &lbf[spos+23*qdim], &lbf[spos+26*qdim], &lbf[spos+25*qdim],
                           &lbf[spos+1*qdim], &lbf[spos+2*qdim], &lbf[spos+16*qdim], &lbf[spos+4*qdim],
                           &lbf[spos+5*qdim], &lbf[spos+7*qdim], &lbf[spos+6*qdim], &lbf[spos+9*qdim],
                           &lbf[spos+8*qdim], &lbf[spos+11*qdim], &lbf[spos+10*qdim], &lbf[spos+13*qdim],
                           &lbf[spos+12*qdim]);
        break;
      case CCDRF:
        fD3Q27VCCCLBEZouHe(p0, uwall[0], -uwall[1], uwall[2], &force[0], &lbf[spos], &lbf[spos+1*qdim],
                           &lbf[spos+15*qdim], &lbf[spos+3*qdim], &lbf[spos+5*qdim], &lbf[spos+4*qdim],
                           &lbf[spos+6*qdim], &lbf[spos+7*qdim], &lbf[spos+22*qdim], &lbf[spos+21*qdim],
                           &lbf[spos+12*qdim], &lbf[spos+13*qdim], &lbf[spos+10*qdim], &lbf[spos+11*qdim],
                           &lbf[spos+14*qdim], &lbf[spos+2*qdim], &lbf[spos+16*qdim], &lbf[spos+18*qdim],
                           &lbf[spos+17*qdim], &lbf[spos+19*qdim], &lbf[spos+20*qdim], &lbf[spos+9*qdim],
                           &lbf[spos+8*qdim], &lbf[spos+25*qdim], &lbf[spos+26*qdim], &lbf[spos+23*qdim],
                           &lbf[spos+24*qdim]);
        break;
      case CETR:
        fD3Q27VCECLBEZouHe(p0, uwall[0], uwall[1], uwall[2], &force[0], &lbf[spos], &lbf[spos+1*qdim],
                           &lbf[spos+2*qdim], &lbf[spos+3*qdim], &lbf[spos+4*qdim], &lbf[spos+5*qdim],
                           &lbf[spos+6*qdim], &lbf[spos+7*qdim], &lbf[spos+8*qdim], &lbf[spos+9*qdim],
                           &lbf[spos+10*qdim], &lbf[spos+11*qdim], &lbf[spos+12*qdim], &lbf[spos+13*qdim],
                           &lbf[spos+14*qdim], &lbf[spos+15*qdim], &lbf[spos+16*qdim], &lbf[spos+17*qdim],
                           &lbf[spos+18*qdim], &lbf[spos+19*qdim], &lbf[spos+20*qdim], &lbf[spos+21*qdim],
                           &lbf[spos+22*qdim], &lbf[spos+23*qdim], &lbf[spos+24*qdim], &lbf[spos+25*qdim],
                           &lbf[spos+26*qdim]);
        break;
      case CETL:
        fD3Q27VCECLBEZouHe(p0, uwall[1], -uwall[0], uwall[2], &force[0], &lbf[spos], &lbf[spos+2*qdim],
                           &lbf[spos+14*qdim], &lbf[spos+3*qdim], &lbf[spos+18*qdim], &lbf[spos+4*qdim],
                           &lbf[spos+8*qdim], &lbf[spos+9*qdim], &lbf[spos+20*qdim], &lbf[spos+19*qdim],
                           &lbf[spos+26*qdim], &lbf[spos+25*qdim], &lbf[spos+10*qdim], &lbf[spos+11*qdim],
                           &lbf[spos+15*qdim], &lbf[spos+1*qdim], &lbf[spos+16*qdim], &lbf[spos+5*qdim],
                           &lbf[spos+17*qdim], &lbf[spos+21*qdim], &lbf[spos+22*qdim], &lbf[spos+7*qdim],
                           &lbf[spos+6*qdim], &lbf[spos+13*qdim], &lbf[spos+12*qdim], &lbf[spos+23*qdim],
                           &lbf[spos+24*qdim]);
        break;
      case CEDL:
        fD3Q27VCECLBEZouHe(p0, -uwall[0], -uwall[1], uwall[2], &force[0], &lbf[spos], &lbf[spos+14*qdim],
                           &lbf[spos+15*qdim], &lbf[spos+3*qdim], &lbf[spos+17*qdim], &lbf[spos+18*qdim],
                           &lbf[spos+20*qdim], &lbf[spos+19*qdim], &lbf[spos+22*qdim], &lbf[spos+21*qdim],
                           &lbf[spos+24*qdim], &lbf[spos+23*qdim], &lbf[spos+26*qdim], &lbf[spos+25*qdim],
                           &lbf[spos+1*qdim], &lbf[spos+2*qdim], &lbf[spos+16*qdim], &lbf[spos+4*qdim],
                           &lbf[spos+5*qdim], &lbf[spos+7*qdim], &lbf[spos+6*qdim], &lbf[spos+9*qdim],
                           &lbf[spos+8*qdim], &lbf[spos+11*qdim], &lbf[spos+10*qdim], &lbf[spos+13*qdim],
                           &lbf[spos+12*qdim]);
        break;
      case CEDR:
        fD3Q27VCECLBEZouHe(p0, -uwall[1], uwall[0], uwall[2], &force[0], &lbf[spos], &lbf[spos+15*qdim],
                           &lbf[spos+1*qdim], &lbf[spos+3*qdim], &lbf[spos+5*qdim], &lbf[spos+17*qdim],
                           &lbf[spos+22*qdim], &lbf[spos+21*qdim], &lbf[spos+6*qdim], &lbf[spos+7*qdim],
                           &lbf[spos+12*qdim], &lbf[spos+13*qdim], &lbf[spos+24*qdim], &lbf[spos+23*qdim],
                           &lbf[spos+2*qdim], &lbf[spos+14*qdim], &lbf[spos+16*qdim], &lbf[spos+18*qdim],
                           &lbf[spos+4*qdim], &lbf[spos+9*qdim], &lbf[spos+8*qdim], &lbf[spos+19*qdim],
                           &lbf[spos+20*qdim], &lbf[spos+25*qdim], &lbf[spos+26*qdim], &lbf[spos+11*qdim],
                           &lbf[spos+10*qdim]);
        break;
      case CETF:
        fD3Q27VCECLBEZouHe(p0, uwall[1], uwall[2], uwall[0], &force[0], &lbf[spos], &lbf[spos+2*qdim],
                           &lbf[spos+3*qdim], &lbf[spos+1*qdim], &lbf[spos+8*qdim], &lbf[spos+9*qdim],
                           &lbf[spos+4*qdim], &lbf[spos+18*qdim], &lbf[spos+6*qdim], &lbf[spos+20*qdim],
                           &lbf[spos+10*qdim], &lbf[spos+26*qdim], &lbf[spos+11*qdim], &lbf[spos+25*qdim],
                           &lbf[spos+15*qdim], &lbf[spos+16*qdim], &lbf[spos+14*qdim], &lbf[spos+21*qdim],
                           &lbf[spos+22*qdim], &lbf[spos+17*qdim], &lbf[spos+5*qdim], &lbf[spos+19*qdim],
                           &lbf[spos+7*qdim], &lbf[spos+23*qdim], &lbf[spos+13*qdim], &lbf[spos+24*qdim],
                           &lbf[spos+12*qdim]);
        break;
      case CELF:
        fD3Q27VCECLBEZouHe(p0, -uwall[0], uwall[1], uwall[2], &force[0], &lbf[spos], &lbf[spos+14*qdim],
                           &lbf[spos+3*qdim], &lbf[spos+2*qdim], &lbf[spos+20*qdim], &lbf[spos+19*qdim],
                           &lbf[spos+18*qdim], &lbf[spos+17*qdim], &lbf[spos+8*qdim], &lbf[spos+22*qdim],
                           &lbf[spos+26*qdim], &lbf[spos+24*qdim], &lbf[spos+25*qdim], &lbf[spos+23*qdim],
                           &lbf[spos+1*qdim], &lbf[spos+16*qdim], &lbf[spos+15*qdim], &lbf[spos+7*qdim],
                           &lbf[spos+6*qdim], &lbf[spos+5*qdim], &lbf[spos+4*qdim], &lbf[spos+21*qdim],
                           &lbf[spos+9*qdim], &lbf[spos+13*qdim], &lbf[spos+11*qdim], &lbf[spos+12*qdim],
                           &lbf[spos+10*qdim]);
        break;
      case CEDF:
        fD3Q27VCECLBEZouHe(p0, -uwall[1], uwall[2], uwall[0], &force[0], &lbf[spos], &lbf[spos+15*qdim],
                           &lbf[spos+3*qdim], &lbf[spos+1*qdim], &lbf[spos+22*qdim], &lbf[spos+21*qdim],
                           &lbf[spos+5*qdim], &lbf[spos+17*qdim], &lbf[spos+6*qdim], &lbf[spos+20*qdim],
                           &lbf[spos+12*qdim], &lbf[spos+24*qdim], &lbf[spos+13*qdim], &lbf[spos+23*qdim],
                           &lbf[spos+2*qdim], &lbf[spos+16*qdim], &lbf[spos+14*qdim], &lbf[spos+9*qdim],
                           &lbf[spos+8*qdim], &lbf[spos+18*qdim], &lbf[spos+4*qdim], &lbf[spos+19*qdim],
                           &lbf[spos+7*qdim], &lbf[spos+25*qdim], &lbf[spos+11*qdim], &lbf[spos+26*qdim],
                           &lbf[spos+10*qdim]);
        break;
      case CERF:
        fD3Q27VCECLBEZouHe(p0, uwall[0], uwall[2], uwall[2], &force[0], &lbf[spos], &lbf[spos+1*qdim],
                           &lbf[spos+3*qdim], &lbf[spos+2*qdim], &lbf[spos+6*qdim], &lbf[spos+7*qdim],
                           &lbf[spos+4*qdim], &lbf[spos+5*qdim], &lbf[spos+8*qdim], &lbf[spos+22*qdim],
                           &lbf[spos+10*qdim], &lbf[spos+12*qdim], &lbf[spos+11*qdim], &lbf[spos+13*qdim],
                           &lbf[spos+14*qdim], &lbf[spos+16*qdim], &lbf[spos+15*qdim], &lbf[spos+19*qdim],
                           &lbf[spos+20*qdim], &lbf[spos+17*qdim], &lbf[spos+18*qdim], &lbf[spos+21*qdim],
                           &lbf[spos+9*qdim], &lbf[spos+23*qdim], &lbf[spos+25*qdim], &lbf[spos+24*qdim],
                           &lbf[spos+26*qdim]);
        break;
      case CETB:
        fD3Q27VCECLBEZouHe(p0, uwall[1], -uwall[2], uwall[0], &force[0], &lbf[spos], &lbf[spos+2*qdim],
                           &lbf[spos+16*qdim], &lbf[spos+1*qdim], &lbf[spos+9*qdim], &lbf[spos+8*qdim],
                           &lbf[spos+4*qdim], &lbf[spos+18*qdim], &lbf[spos+7*qdim], &lbf[spos+19*qdim],
                           &lbf[spos+11*qdim], &lbf[spos+25*qdim], &lbf[spos+10*qdim], &lbf[spos+26*qdim],
                           &lbf[spos+15*qdim], &lbf[spos+3*qdim], &lbf[spos+14*qdim], &lbf[spos+22*qdim],
                           &lbf[spos+21*qdim], &lbf[spos+17*qdim], &lbf[spos+5*qdim], &lbf[spos+20*qdim],
                           &lbf[spos+6*qdim], &lbf[spos+24*qdim], &lbf[spos+12*qdim], &lbf[spos+23*qdim],
                           &lbf[spos+13*qdim]);
        break;
      case CELB:
        fD3Q27VCECLBEZouHe(p0, -uwall[0], -uwall[2], uwall[1], &force[0], &lbf[spos], &lbf[spos+14*qdim],
                           &lbf[spos+16*qdim], &lbf[spos+2*qdim], &lbf[spos+19*qdim], &lbf[spos+20*qdim],
                           &lbf[spos+18*qdim], &lbf[spos+17*qdim], &lbf[spos+9*qdim], &lbf[spos+21*qdim],
                           &lbf[spos+25*qdim], &lbf[spos+23*qdim], &lbf[spos+26*qdim], &lbf[spos+24*qdim],
                           &lbf[spos+1*qdim], &lbf[spos+3*qdim], &lbf[spos+15*qdim], &lbf[spos+6*qdim],
                           &lbf[spos+7*qdim], &lbf[spos+5*qdim], &lbf[spos+4*qdim], &lbf[spos+22*qdim],
                           &lbf[spos+8*qdim], &lbf[spos+12*qdim], &lbf[spos+10*qdim], &lbf[spos+13*qdim],
                           &lbf[spos+11*qdim]);
        break;
      case CEDB:
        fD3Q27VCECLBEZouHe(p0, -uwall[1], -uwall[2], uwall[0], &force[0], &lbf[spos], &lbf[spos+15*qdim],
                           &lbf[spos+16*qdim], &lbf[spos+1*qdim], &lbf[spos+21*qdim], &lbf[spos+22*qdim],
                           &lbf[spos+5*qdim], &lbf[spos+17*qdim], &lbf[spos+7*qdim], &lbf[spos+19*qdim],
                           &lbf[spos+13*qdim], &lbf[spos+23*qdim], &lbf[spos+12*qdim], &lbf[spos+24*qdim],
                           &lbf[spos+2*qdim], &lbf[spos+3*qdim], &lbf[spos+14*qdim], &lbf[spos+8*qdim],
                           &lbf[spos+9*qdim], &lbf[spos+18*qdim], &lbf[spos+4*qdim], &lbf[spos+20*qdim],
                           &lbf[spos+6*qdim], &lbf[spos+26*qdim], &lbf[spos+10*qdim], &lbf[spos+25*qdim],
                           &lbf[spos+11*qdim]);
        break;
      case CERB:
        fD3Q27VCECLBEZouHe(p0, uwall[0], -uwall[2], uwall[1], &force[0], &lbf[spos], &lbf[spos+1*qdim],
                           &lbf[spos+16*qdim], &lbf[spos+2*qdim], &lbf[spos+7*qdim], &lbf[spos+6*qdim],
                           &lbf[spos+4*qdim], &lbf[spos+5*qdim], &lbf[spos+9*qdim], &lbf[spos+21*qdim],
                           &lbf[spos+11*qdim], &lbf[spos+13*qdim], &lbf[spos+10*qdim], &lbf[spos+12*qdim],
                           &lbf[spos+14*qdim], &lbf[spos+3*qdim], &lbf[spos+15*qdim], &lbf[spos+20*qdim],
                           &lbf[spos+19*qdim], &lbf[spos+17*qdim], &lbf[spos+18*qdim], &lbf[spos+22*qdim],
                           &lbf[spos+8*qdim], &lbf[spos+24*qdim], &lbf[spos+26*qdim], &lbf[spos+23*qdim],
                           &lbf[spos+25*qdim]);
        break;
    }
  }
  else {
    switch (prop) {
      case PST:
        fD3Q27PPSZouHe(p0, &force[0], &lbf[spos], &lbf[spos+1*qdim],
                       &lbf[spos+2*qdim], &lbf[spos+3*qdim], &lbf[spos+4*qdim], &lbf[spos+5*qdim],
                       &lbf[spos+6*qdim], &lbf[spos+7*qdim], &lbf[spos+8*qdim], &lbf[spos+9*qdim],
                       &lbf[spos+10*qdim], &lbf[spos+11*qdim], &lbf[spos+12*qdim], &lbf[spos+13*qdim],
                       &lbf[spos+14*qdim], &lbf[spos+15*qdim], &lbf[spos+16*qdim], &lbf[spos+17*qdim],
                       &lbf[spos+18*qdim], &lbf[spos+19*qdim], &lbf[spos+20*qdim], &lbf[spos+21*qdim],
                       &lbf[spos+22*qdim], &lbf[spos+23*qdim], &lbf[spos+24*qdim], &lbf[spos+25*qdim],
                       &lbf[spos+26*qdim], moment);
        uwall[1] += moment;
        break;
      case PSD:
        fD3Q27PPSZouHe(p0, &force[0], &lbf[spos], &lbf[spos+14*qdim],
                       &lbf[spos+15*qdim], &lbf[spos+16*qdim], &lbf[spos+17*qdim], &lbf[spos+18*qdim],
                       &lbf[spos+19*qdim], &lbf[spos+20*qdim], &lbf[spos+21*qdim], &lbf[spos+22*qdim],
                       &lbf[spos+23*qdim], &lbf[spos+24*qdim], &lbf[spos+25*qdim], &lbf[spos+26*qdim],
                       &lbf[spos+1*qdim], &lbf[spos+2*qdim], &lbf[spos+3*qdim], &lbf[spos+4*qdim],
                       &lbf[spos+5*qdim], &lbf[spos+6*qdim], &lbf[spos+7*qdim], &lbf[spos+8*qdim],
                       &lbf[spos+9*qdim], &lbf[spos+10*qdim], &lbf[spos+11*qdim], &lbf[spos+12*qdim],
                       &lbf[spos+13*qdim], moment);
        uwall[1] -= moment;
        break;
      case PSL:
        fD3Q27PPSZouHe(p0, &force[0], &lbf[spos], &lbf[spos+16*qdim],
                       &lbf[spos+14*qdim], &lbf[spos+15*qdim], &lbf[spos+19*qdim], &lbf[spos+7*qdim],
                       &lbf[spos+21*qdim], &lbf[spos+9*qdim], &lbf[spos+17*qdim], &lbf[spos+18*qdim],
                       &lbf[spos+23*qdim], &lbf[spos+25*qdim], &lbf[spos+13*qdim], &lbf[spos+11*qdim],
                       &lbf[spos+3*qdim], &lbf[spos+1*qdim], &lbf[spos+2*qdim], &lbf[spos+6*qdim],
                       &lbf[spos+20*qdim], &lbf[spos+8*qdim], &lbf[spos+22*qdim], &lbf[spos+4*qdim],
                       &lbf[spos+5*qdim], &lbf[spos+10*qdim], &lbf[spos+12*qdim], &lbf[spos+26*qdim],
                       &lbf[spos+24*qdim], moment);
        uwall[0] -= moment;
        break;
      case PSR:
        fD3Q27PPSZouHe(p0, &force[0], &lbf[spos], &lbf[spos+3*qdim],
                       &lbf[spos+1*qdim], &lbf[spos+2*qdim], &lbf[spos+6*qdim], &lbf[spos+20*qdim],
                       &lbf[spos+8*qdim], &lbf[spos+22*qdim], &lbf[spos+4*qdim], &lbf[spos+5*qdim],
                       &lbf[spos+10*qdim], &lbf[spos+12*qdim], &lbf[spos+26*qdim], &lbf[spos+24*qdim],
                       &lbf[spos+16*qdim], &lbf[spos+14*qdim], &lbf[spos+15*qdim], &lbf[spos+19*qdim],
                       &lbf[spos+7*qdim], &lbf[spos+21*qdim], &lbf[spos+9*qdim], &lbf[spos+17*qdim],
                       &lbf[spos+18*qdim], &lbf[spos+23*qdim], &lbf[spos+25*qdim], &lbf[spos+13*qdim],
                       &lbf[spos+11*qdim], moment);
        uwall[0] += moment;
        break;
      case PSF:
        fD3Q27PPSZouHe(p0, &force[0], &lbf[spos], &lbf[spos+15*qdim],
                       &lbf[spos+16*qdim], &lbf[spos+14*qdim], &lbf[spos+21*qdim], &lbf[spos+22*qdim],
                       &lbf[spos+17*qdim], &lbf[spos+5*qdim], &lbf[spos+19*qdim], &lbf[spos+7*qdim],
                       &lbf[spos+23*qdim], &lbf[spos+13*qdim], &lbf[spos+24*qdim], &lbf[spos+12*qdim],
                       &lbf[spos+2*qdim], &lbf[spos+3*qdim], &lbf[spos+1*qdim], &lbf[spos+8*qdim],
                       &lbf[spos+9*qdim], &lbf[spos+4*qdim], &lbf[spos+18*qdim], &lbf[spos+6*qdim],
                       &lbf[spos+20*qdim], &lbf[spos+10*qdim], &lbf[spos+26*qdim], &lbf[spos+11*qdim],
                       &lbf[spos+25*qdim], moment);
        uwall[2] -= moment;
        break;
      case PSB:
        fD3Q27PPSZouHe(p0, &force[0], &lbf[spos], &lbf[spos+2*qdim],
                       &lbf[spos+3*qdim], &lbf[spos+1*qdim], &lbf[spos+8*qdim], &lbf[spos+9*qdim],
                       &lbf[spos+4*qdim], &lbf[spos+18*qdim], &lbf[spos+6*qdim], &lbf[spos+20*qdim],
                       &lbf[spos+10*qdim], &lbf[spos+26*qdim], &lbf[spos+11*qdim], &lbf[spos+25*qdim],
                       &lbf[spos+15*qdim], &lbf[spos+16*qdim], &lbf[spos+14*qdim], &lbf[spos+21*qdim],
                       &lbf[spos+22*qdim], &lbf[spos+17*qdim], &lbf[spos+5*qdim], &lbf[spos+19*qdim],
                       &lbf[spos+7*qdim], &lbf[spos+23*qdim], &lbf[spos+13*qdim], &lbf[spos+24*qdim],
                       &lbf[spos+12*qdim], moment);
        uwall[2] += moment;
        break;
      case CCTRB:
        fD3Q27VCCZouHe(p0, uwall[0], uwall[1], -uwall[2], &force[0], &lbf[spos], &lbf[spos+1*qdim],
                       &lbf[spos+2*qdim], &lbf[spos+16*qdim], &lbf[spos+4*qdim], &lbf[spos+5*qdim],
                       &lbf[spos+7*qdim], &lbf[spos+6*qdim], &lbf[spos+9*qdim], &lbf[spos+8*qdim],
                       &lbf[spos+11*qdim], &lbf[spos+10*qdim], &lbf[spos+13*qdim], &lbf[spos+12*qdim],
                       &lbf[spos+14*qdim], &lbf[spos+15*qdim], &lbf[spos+3*qdim], &lbf[spos+17*qdim],
                       &lbf[spos+18*qdim], &lbf[spos+20*qdim], &lbf[spos+19*qdim], &lbf[spos+22*qdim],
                       &lbf[spos+21*qdim], &lbf[spos+24*qdim], &lbf[spos+23*qdim], &lbf[spos+26*qdim],
                       &lbf[spos+25*qdim]);
        break;
      case CCTLB:
        fD3Q27VCCZouHe(p0, -uwall[0], uwall[1], -uwall[2], &force[0], &lbf[spos], &lbf[spos+14*qdim],
                       &lbf[spos+2*qdim], &lbf[spos+16*qdim], &lbf[spos+18*qdim], &lbf[spos+17*qdim],
                       &lbf[spos+19*qdim], &lbf[spos+20*qdim], &lbf[spos+9*qdim], &lbf[spos+8*qdim],
                       &lbf[spos+25*qdim], &lbf[spos+26*qdim], &lbf[spos+23*qdim], &lbf[spos+24*qdim],
                       &lbf[spos+1*qdim], &lbf[spos+15*qdim], &lbf[spos+3*qdim], &lbf[spos+5*qdim],
                       &lbf[spos+4*qdim], &lbf[spos+6*qdim], &lbf[spos+7*qdim], &lbf[spos+22*qdim],
                       &lbf[spos+21*qdim], &lbf[spos+12*qdim], &lbf[spos+13*qdim], &lbf[spos+10*qdim],
                       &lbf[spos+11*qdim]);
        break;
      case CCDLB:
        fD3Q27VCCZouHe(p0, -uwall[0], -uwall[1], -uwall[2], &force[0], &lbf[spos], &lbf[spos+14*qdim],
                       &lbf[spos+15*qdim], &lbf[spos+16*qdim], &lbf[spos+17*qdim], &lbf[spos+18*qdim],
                       &lbf[spos+19*qdim], &lbf[spos+20*qdim], &lbf[spos+21*qdim], &lbf[spos+22*qdim],
                       &lbf[spos+23*qdim], &lbf[spos+24*qdim], &lbf[spos+25*qdim], &lbf[spos+26*qdim],
                       &lbf[spos+1*qdim], &lbf[spos+2*qdim], &lbf[spos+3*qdim], &lbf[spos+4*qdim],
                       &lbf[spos+5*qdim], &lbf[spos+6*qdim], &lbf[spos+7*qdim], &lbf[spos+8*qdim],
                       &lbf[spos+9*qdim], &lbf[spos+10*qdim], &lbf[spos+11*qdim], &lbf[spos+12*qdim],
                       &lbf[spos+13*qdim]);
        break;
      case CCDRB:
        fD3Q27VCCZouHe(p0, uwall[0], -uwall[1], -uwall[2], &force[0], &lbf[spos], &lbf[spos+1*qdim],
                       &lbf[spos+15*qdim], &lbf[spos+16*qdim], &lbf[spos+5*qdim], &lbf[spos+4*qdim],
                       &lbf[spos+7*qdim], &lbf[spos+6*qdim], &lbf[spos+21*qdim], &lbf[spos+22*qdim],
                       &lbf[spos+13*qdim], &lbf[spos+12*qdim], &lbf[spos+11*qdim], &lbf[spos+10*qdim],
                       &lbf[spos+14*qdim], &lbf[spos+2*qdim], &lbf[spos+3*qdim], &lbf[spos+18*qdim],
                       &lbf[spos+17*qdim], &lbf[spos+20*qdim], &lbf[spos+19*qdim], &lbf[spos+8*qdim],
                       &lbf[spos+9*qdim], &lbf[spos+26*qdim], &lbf[spos+25*qdim], &lbf[spos+24*qdim],
                       &lbf[spos+23*qdim]);
        break;
      case CCTRF:
        fD3Q27VCCZouHe(p0, uwall[0], uwall[1], uwall[2], &force[0], &lbf[spos], &lbf[spos+1*qdim],
                       &lbf[spos+2*qdim], &lbf[spos+3*qdim], &lbf[spos+4*qdim], &lbf[spos+5*qdim],
                       &lbf[spos+6*qdim], &lbf[spos+7*qdim], &lbf[spos+8*qdim], &lbf[spos+9*qdim],
                       &lbf[spos+10*qdim], &lbf[spos+11*qdim], &lbf[spos+12*qdim], &lbf[spos+13*qdim],
                       &lbf[spos+14*qdim], &lbf[spos+15*qdim], &lbf[spos+16*qdim], &lbf[spos+17*qdim],
                       &lbf[spos+18*qdim], &lbf[spos+19*qdim], &lbf[spos+20*qdim], &lbf[spos+21*qdim],
                       &lbf[spos+22*qdim], &lbf[spos+23*qdim], &lbf[spos+24*qdim], &lbf[spos+25*qdim],
                       &lbf[spos+26*qdim]);
        break;
      case CCTLF:
        fD3Q27VCCZouHe(p0, -uwall[0], uwall[1], uwall[2], &force[0], &lbf[spos], &lbf[spos+14*qdim],
                       &lbf[spos+2*qdim], &lbf[spos+3*qdim], &lbf[spos+18*qdim], &lbf[spos+17*qdim],
                       &lbf[spos+20*qdim], &lbf[spos+19*qdim], &lbf[spos+8*qdim], &lbf[spos+9*qdim],
                       &lbf[spos+26*qdim], &lbf[spos+25*qdim], &lbf[spos+24*qdim], &lbf[spos+23*qdim],
                       &lbf[spos+1*qdim], &lbf[spos+15*qdim], &lbf[spos+16*qdim], &lbf[spos+5*qdim],
                       &lbf[spos+4*qdim], &lbf[spos+7*qdim], &lbf[spos+6*qdim], &lbf[spos+21*qdim],
                       &lbf[spos+22*qdim], &lbf[spos+13*qdim], &lbf[spos+12*qdim], &lbf[spos+11*qdim],
                       &lbf[spos+10*qdim]);
        break;
      case CCDLF:
        fD3Q27VCCZouHe(p0, -uwall[0], -uwall[1], uwall[2], &force[0], &lbf[spos], &lbf[spos+14*qdim],
                       &lbf[spos+15*qdim], &lbf[spos+3*qdim], &lbf[spos+17*qdim], &lbf[spos+18*qdim],
                       &lbf[spos+20*qdim], &lbf[spos+19*qdim], &lbf[spos+22*qdim], &lbf[spos+21*qdim],
                       &lbf[spos+24*qdim], &lbf[spos+23*qdim], &lbf[spos+26*qdim], &lbf[spos+25*qdim],
                       &lbf[spos+1*qdim], &lbf[spos+2*qdim], &lbf[spos+16*qdim], &lbf[spos+4*qdim],
                       &lbf[spos+5*qdim], &lbf[spos+7*qdim], &lbf[spos+6*qdim], &lbf[spos+9*qdim],
                       &lbf[spos+8*qdim], &lbf[spos+11*qdim], &lbf[spos+10*qdim], &lbf[spos+13*qdim],
                       &lbf[spos+12*qdim]);
        break;
      case CCDRF:
        fD3Q27VCCZouHe(p0, uwall[0], -uwall[1], uwall[2], &force[0], &lbf[spos], &lbf[spos+1*qdim],
                       &lbf[spos+15*qdim], &lbf[spos+3*qdim], &lbf[spos+5*qdim], &lbf[spos+4*qdim],
                       &lbf[spos+6*qdim], &lbf[spos+7*qdim], &lbf[spos+22*qdim], &lbf[spos+21*qdim],
                       &lbf[spos+12*qdim], &lbf[spos+13*qdim], &lbf[spos+10*qdim], &lbf[spos+11*qdim],
                       &lbf[spos+14*qdim], &lbf[spos+2*qdim], &lbf[spos+16*qdim], &lbf[spos+18*qdim],
                       &lbf[spos+17*qdim], &lbf[spos+19*qdim], &lbf[spos+20*qdim], &lbf[spos+9*qdim],
                       &lbf[spos+8*qdim], &lbf[spos+25*qdim], &lbf[spos+26*qdim], &lbf[spos+23*qdim],
                       &lbf[spos+24*qdim]);
        break;
      case CETR:
        fD3Q27VCEZouHe(p0, uwall[0], uwall[1], uwall[2], &force[0], &lbf[spos], &lbf[spos+1*qdim],
                       &lbf[spos+2*qdim], &lbf[spos+3*qdim], &lbf[spos+4*qdim], &lbf[spos+5*qdim],
                       &lbf[spos+6*qdim], &lbf[spos+7*qdim], &lbf[spos+8*qdim], &lbf[spos+9*qdim],
                       &lbf[spos+10*qdim], &lbf[spos+11*qdim], &lbf[spos+12*qdim], &lbf[spos+13*qdim],
                       &lbf[spos+14*qdim], &lbf[spos+15*qdim], &lbf[spos+16*qdim], &lbf[spos+17*qdim],
                       &lbf[spos+18*qdim], &lbf[spos+19*qdim], &lbf[spos+20*qdim], &lbf[spos+21*qdim],
                       &lbf[spos+22*qdim], &lbf[spos+23*qdim], &lbf[spos+24*qdim], &lbf[spos+25*qdim],
                       &lbf[spos+26*qdim]);
        break;
      case CETL:
        fD3Q27VCEZouHe(p0, uwall[1], -uwall[0], uwall[2], &force[0], &lbf[spos], &lbf[spos+2*qdim],
                       &lbf[spos+14*qdim], &lbf[spos+3*qdim], &lbf[spos+18*qdim], &lbf[spos+4*qdim],
                       &lbf[spos+8*qdim], &lbf[spos+9*qdim], &lbf[spos+20*qdim], &lbf[spos+19*qdim],
                       &lbf[spos+26*qdim], &lbf[spos+25*qdim], &lbf[spos+10*qdim], &lbf[spos+11*qdim],
                       &lbf[spos+15*qdim], &lbf[spos+1*qdim], &lbf[spos+16*qdim], &lbf[spos+5*qdim],
                       &lbf[spos+17*qdim], &lbf[spos+21*qdim], &lbf[spos+22*qdim], &lbf[spos+7*qdim],
                       &lbf[spos+6*qdim], &lbf[spos+13*qdim], &lbf[spos+12*qdim], &lbf[spos+23*qdim],
                       &lbf[spos+24*qdim]);
        break;
      case CEDL:
        fD3Q27VCEZouHe(p0, -uwall[0], -uwall[1], uwall[2], &force[0], &lbf[spos], &lbf[spos+14*qdim],
                       &lbf[spos+15*qdim], &lbf[spos+3*qdim], &lbf[spos+17*qdim], &lbf[spos+18*qdim],
                       &lbf[spos+20*qdim], &lbf[spos+19*qdim], &lbf[spos+22*qdim], &lbf[spos+21*qdim],
                       &lbf[spos+24*qdim], &lbf[spos+23*qdim], &lbf[spos+26*qdim], &lbf[spos+25*qdim],
                       &lbf[spos+1*qdim], &lbf[spos+2*qdim], &lbf[spos+16*qdim], &lbf[spos+4*qdim],
                       &lbf[spos+5*qdim], &lbf[spos+7*qdim], &lbf[spos+6*qdim], &lbf[spos+9*qdim],
                       &lbf[spos+8*qdim], &lbf[spos+11*qdim], &lbf[spos+10*qdim], &lbf[spos+13*qdim],
                       &lbf[spos+12*qdim]);
        break;
      case CEDR:
        fD3Q27VCEZouHe(p0, -uwall[1], uwall[0], uwall[2], &force[0], &lbf[spos], &lbf[spos+15*qdim],
                       &lbf[spos+1*qdim], &lbf[spos+3*qdim], &lbf[spos+5*qdim], &lbf[spos+17*qdim],
                       &lbf[spos+22*qdim], &lbf[spos+21*qdim], &lbf[spos+6*qdim], &lbf[spos+7*qdim],
                       &lbf[spos+12*qdim], &lbf[spos+13*qdim], &lbf[spos+24*qdim], &lbf[spos+23*qdim],
                       &lbf[spos+2*qdim], &lbf[spos+14*qdim], &lbf[spos+16*qdim], &lbf[spos+18*qdim],
                       &lbf[spos+4*qdim], &lbf[spos+9*qdim], &lbf[spos+8*qdim], &lbf[spos+19*qdim],
                       &lbf[spos+20*qdim], &lbf[spos+25*qdim], &lbf[spos+26*qdim], &lbf[spos+11*qdim],
                       &lbf[spos+10*qdim]);
        break;
      case CETF:
        fD3Q27VCEZouHe(p0, uwall[1], uwall[2], uwall[0], &force[0], &lbf[spos], &lbf[spos+2*qdim],
                       &lbf[spos+3*qdim], &lbf[spos+1*qdim], &lbf[spos+8*qdim], &lbf[spos+9*qdim],
                       &lbf[spos+4*qdim], &lbf[spos+18*qdim], &lbf[spos+6*qdim], &lbf[spos+20*qdim],
                       &lbf[spos+10*qdim], &lbf[spos+26*qdim], &lbf[spos+11*qdim], &lbf[spos+25*qdim],
                       &lbf[spos+15*qdim], &lbf[spos+16*qdim], &lbf[spos+14*qdim], &lbf[spos+21*qdim],
                       &lbf[spos+22*qdim], &lbf[spos+17*qdim], &lbf[spos+5*qdim], &lbf[spos+19*qdim],
                       &lbf[spos+7*qdim], &lbf[spos+23*qdim], &lbf[spos+13*qdim], &lbf[spos+24*qdim],
                       &lbf[spos+12*qdim]);
        break;
      case CELF:
        fD3Q27VCEZouHe(p0, -uwall[0], uwall[1], uwall[2], &force[0], &lbf[spos], &lbf[spos+14*qdim],
                       &lbf[spos+3*qdim], &lbf[spos+2*qdim], &lbf[spos+20*qdim], &lbf[spos+19*qdim],
                       &lbf[spos+18*qdim], &lbf[spos+17*qdim], &lbf[spos+8*qdim], &lbf[spos+22*qdim],
                       &lbf[spos+26*qdim], &lbf[spos+24*qdim], &lbf[spos+25*qdim], &lbf[spos+23*qdim],
                       &lbf[spos+1*qdim], &lbf[spos+16*qdim], &lbf[spos+15*qdim], &lbf[spos+7*qdim],
                       &lbf[spos+6*qdim], &lbf[spos+5*qdim], &lbf[spos+4*qdim], &lbf[spos+21*qdim],
                       &lbf[spos+9*qdim], &lbf[spos+13*qdim], &lbf[spos+11*qdim], &lbf[spos+12*qdim],
                       &lbf[spos+10*qdim]);
        break;
      case CEDF:
        fD3Q27VCEZouHe(p0, -uwall[1], uwall[2], uwall[0], &force[0], &lbf[spos], &lbf[spos+15*qdim],
                       &lbf[spos+3*qdim], &lbf[spos+1*qdim], &lbf[spos+22*qdim], &lbf[spos+21*qdim],
                       &lbf[spos+5*qdim], &lbf[spos+17*qdim], &lbf[spos+6*qdim], &lbf[spos+20*qdim],
                       &lbf[spos+12*qdim], &lbf[spos+24*qdim], &lbf[spos+13*qdim], &lbf[spos+23*qdim],
                       &lbf[spos+2*qdim], &lbf[spos+16*qdim], &lbf[spos+14*qdim], &lbf[spos+9*qdim],
                       &lbf[spos+8*qdim], &lbf[spos+18*qdim], &lbf[spos+4*qdim], &lbf[spos+19*qdim],
                       &lbf[spos+7*qdim], &lbf[spos+25*qdim], &lbf[spos+11*qdim], &lbf[spos+26*qdim],
                       &lbf[spos+10*qdim]);
        break;
      case CERF:
        fD3Q27VCEZouHe(p0, uwall[0], uwall[2], uwall[2], &force[0], &lbf[spos], &lbf[spos+1*qdim],
                       &lbf[spos+3*qdim], &lbf[spos+2*qdim], &lbf[spos+6*qdim], &lbf[spos+7*qdim],
                       &lbf[spos+4*qdim], &lbf[spos+5*qdim], &lbf[spos+8*qdim], &lbf[spos+22*qdim],
                       &lbf[spos+10*qdim], &lbf[spos+12*qdim], &lbf[spos+11*qdim], &lbf[spos+13*qdim],
                       &lbf[spos+14*qdim], &lbf[spos+16*qdim], &lbf[spos+15*qdim], &lbf[spos+19*qdim],
                       &lbf[spos+20*qdim], &lbf[spos+17*qdim], &lbf[spos+18*qdim], &lbf[spos+21*qdim],
                       &lbf[spos+9*qdim], &lbf[spos+23*qdim], &lbf[spos+25*qdim], &lbf[spos+24*qdim],
                       &lbf[spos+26*qdim]);
        break;
      case CETB:
        fD3Q27VCEZouHe(p0, uwall[1], -uwall[2], uwall[0], &force[0], &lbf[spos], &lbf[spos+2*qdim],
                       &lbf[spos+16*qdim], &lbf[spos+1*qdim], &lbf[spos+9*qdim], &lbf[spos+8*qdim],
                       &lbf[spos+4*qdim], &lbf[spos+18*qdim], &lbf[spos+7*qdim], &lbf[spos+19*qdim],
                       &lbf[spos+11*qdim], &lbf[spos+25*qdim], &lbf[spos+10*qdim], &lbf[spos+26*qdim],
                       &lbf[spos+15*qdim], &lbf[spos+3*qdim], &lbf[spos+14*qdim], &lbf[spos+22*qdim],
                       &lbf[spos+21*qdim], &lbf[spos+17*qdim], &lbf[spos+5*qdim], &lbf[spos+20*qdim],
                       &lbf[spos+6*qdim], &lbf[spos+24*qdim], &lbf[spos+12*qdim], &lbf[spos+23*qdim],
                       &lbf[spos+13*qdim]);
        break;
      case CELB:
        fD3Q27VCEZouHe(p0, -uwall[0], -uwall[2], uwall[1], &force[0], &lbf[spos], &lbf[spos+14*qdim],
                       &lbf[spos+16*qdim], &lbf[spos+2*qdim], &lbf[spos+19*qdim], &lbf[spos+20*qdim],
                       &lbf[spos+18*qdim], &lbf[spos+17*qdim], &lbf[spos+9*qdim], &lbf[spos+21*qdim],
                       &lbf[spos+25*qdim], &lbf[spos+23*qdim], &lbf[spos+26*qdim], &lbf[spos+24*qdim],
                       &lbf[spos+1*qdim], &lbf[spos+3*qdim], &lbf[spos+15*qdim], &lbf[spos+6*qdim],
                       &lbf[spos+7*qdim], &lbf[spos+5*qdim], &lbf[spos+4*qdim], &lbf[spos+22*qdim],
                       &lbf[spos+8*qdim], &lbf[spos+12*qdim], &lbf[spos+10*qdim], &lbf[spos+13*qdim],
                       &lbf[spos+11*qdim]);
        break;
      case CEDB:
        fD3Q27VCEZouHe(p0, -uwall[1], -uwall[2], uwall[0], &force[0], &lbf[spos], &lbf[spos+15*qdim],
                       &lbf[spos+16*qdim], &lbf[spos+1*qdim], &lbf[spos+21*qdim], &lbf[spos+22*qdim],
                       &lbf[spos+5*qdim], &lbf[spos+17*qdim], &lbf[spos+7*qdim], &lbf[spos+19*qdim],
                       &lbf[spos+13*qdim], &lbf[spos+23*qdim], &lbf[spos+12*qdim], &lbf[spos+24*qdim],
                       &lbf[spos+2*qdim], &lbf[spos+3*qdim], &lbf[spos+14*qdim], &lbf[spos+8*qdim],
                       &lbf[spos+9*qdim], &lbf[spos+18*qdim], &lbf[spos+4*qdim], &lbf[spos+20*qdim],
                       &lbf[spos+6*qdim], &lbf[spos+26*qdim], &lbf[spos+10*qdim], &lbf[spos+25*qdim],
                       &lbf[spos+11*qdim]);
        break;
      case CERB:
        fD3Q27VCEZouHe(p0, uwall[0], -uwall[2], uwall[1], &force[0], &lbf[spos], &lbf[spos+1*qdim],
                       &lbf[spos+16*qdim], &lbf[spos+2*qdim], &lbf[spos+7*qdim], &lbf[spos+6*qdim],
                       &lbf[spos+4*qdim], &lbf[spos+5*qdim], &lbf[spos+9*qdim], &lbf[spos+21*qdim],
                       &lbf[spos+11*qdim], &lbf[spos+13*qdim], &lbf[spos+10*qdim], &lbf[spos+12*qdim],
                       &lbf[spos+14*qdim], &lbf[spos+3*qdim], &lbf[spos+15*qdim], &lbf[spos+20*qdim],
                       &lbf[spos+19*qdim], &lbf[spos+17*qdim], &lbf[spos+18*qdim], &lbf[spos+22*qdim],
                       &lbf[spos+8*qdim], &lbf[spos+24*qdim], &lbf[spos+26*qdim], &lbf[spos+23*qdim],
                       &lbf[spos+25*qdim]);
        break;
    }
  }
  return 0;
}


int fD3Q27PFSimpleZouHe(long tpos, int prop, double *p0, double *uwall)
{
  double moment;
  long spos=tpos * lbsitelength;
  int qdim=lbsy.nf+lbsy.nc+lbsy.nt;
  double force[3*lbsy.nf];

  // sort out forces
    
  fD3Q27BoundaryForceDensity(force, tpos, p0, prop);

  // apply boundary condition

  if(collide>11) {
    switch (prop) {
      case PST:
        fD3Q27PPSZouHe(p0, &force[0], &lbf[spos], &lbf[spos+1*qdim],
                       &lbf[spos+2*qdim], &lbf[spos+3*qdim], &lbf[spos+4*qdim], &lbf[spos+5*qdim],
                       &lbf[spos+6*qdim], &lbf[spos+7*qdim], &lbf[spos+8*qdim], &lbf[spos+9*qdim],
                       &lbf[spos+10*qdim], &lbf[spos+11*qdim], &lbf[spos+12*qdim], &lbf[spos+13*qdim],
                       &lbf[spos+14*qdim], &lbf[spos+15*qdim], &lbf[spos+16*qdim], &lbf[spos+17*qdim],
                       &lbf[spos+18*qdim], &lbf[spos+19*qdim], &lbf[spos+20*qdim], &lbf[spos+21*qdim],
                       &lbf[spos+22*qdim], &lbf[spos+23*qdim], &lbf[spos+24*qdim], &lbf[spos+25*qdim],
                       &lbf[spos+26*qdim], moment);
        uwall[1] += moment;
        break;
      case PSD:
        fD3Q27PPSZouHe(p0, &force[0], &lbf[spos], &lbf[spos+14*qdim],
                       &lbf[spos+15*qdim], &lbf[spos+16*qdim], &lbf[spos+17*qdim], &lbf[spos+18*qdim],
                       &lbf[spos+19*qdim], &lbf[spos+20*qdim], &lbf[spos+21*qdim], &lbf[spos+22*qdim],
                       &lbf[spos+23*qdim], &lbf[spos+24*qdim], &lbf[spos+25*qdim], &lbf[spos+26*qdim],
                       &lbf[spos+1*qdim], &lbf[spos+2*qdim], &lbf[spos+3*qdim], &lbf[spos+4*qdim],
                       &lbf[spos+5*qdim], &lbf[spos+6*qdim], &lbf[spos+7*qdim], &lbf[spos+8*qdim],
                       &lbf[spos+9*qdim], &lbf[spos+10*qdim], &lbf[spos+11*qdim], &lbf[spos+12*qdim],
                       &lbf[spos+13*qdim], moment);
        uwall[1] -= moment;
        break;
      case PSL:
        fD3Q27PPSZouHe(p0, &force[0], &lbf[spos], &lbf[spos+16*qdim],
                       &lbf[spos+14*qdim], &lbf[spos+15*qdim], &lbf[spos+19*qdim], &lbf[spos+7*qdim],
                       &lbf[spos+21*qdim], &lbf[spos+9*qdim], &lbf[spos+17*qdim], &lbf[spos+18*qdim],
                       &lbf[spos+23*qdim], &lbf[spos+25*qdim], &lbf[spos+13*qdim], &lbf[spos+11*qdim],
                       &lbf[spos+3*qdim], &lbf[spos+1*qdim], &lbf[spos+2*qdim], &lbf[spos+6*qdim],
                       &lbf[spos+20*qdim], &lbf[spos+8*qdim], &lbf[spos+22*qdim], &lbf[spos+4*qdim],
                       &lbf[spos+5*qdim], &lbf[spos+10*qdim], &lbf[spos+12*qdim], &lbf[spos+26*qdim],
                       &lbf[spos+24*qdim], moment);
        uwall[0] -= moment;
        break;
      case PSR:
        fD3Q27PPSZouHe(p0, &force[0], &lbf[spos], &lbf[spos+3*qdim],
                       &lbf[spos+1*qdim], &lbf[spos+2*qdim], &lbf[spos+6*qdim], &lbf[spos+20*qdim],
                       &lbf[spos+8*qdim], &lbf[spos+22*qdim], &lbf[spos+4*qdim], &lbf[spos+5*qdim],
                       &lbf[spos+10*qdim], &lbf[spos+12*qdim], &lbf[spos+26*qdim], &lbf[spos+24*qdim],
                       &lbf[spos+16*qdim], &lbf[spos+14*qdim], &lbf[spos+15*qdim], &lbf[spos+19*qdim],
                       &lbf[spos+7*qdim], &lbf[spos+21*qdim], &lbf[spos+9*qdim], &lbf[spos+17*qdim],
                       &lbf[spos+18*qdim], &lbf[spos+23*qdim], &lbf[spos+25*qdim], &lbf[spos+13*qdim],
                       &lbf[spos+11*qdim], moment);
        uwall[0] += moment;
        break;
      case PSF:
        fD3Q27PPSZouHe(p0, &force[0], &lbf[spos], &lbf[spos+15*qdim],
                       &lbf[spos+16*qdim], &lbf[spos+14*qdim], &lbf[spos+21*qdim], &lbf[spos+22*qdim],
                       &lbf[spos+17*qdim], &lbf[spos+5*qdim], &lbf[spos+19*qdim], &lbf[spos+7*qdim],
                       &lbf[spos+23*qdim], &lbf[spos+13*qdim], &lbf[spos+24*qdim], &lbf[spos+12*qdim],
                       &lbf[spos+2*qdim], &lbf[spos+3*qdim], &lbf[spos+1*qdim], &lbf[spos+8*qdim],
                       &lbf[spos+9*qdim], &lbf[spos+4*qdim], &lbf[spos+18*qdim], &lbf[spos+6*qdim],
                       &lbf[spos+20*qdim], &lbf[spos+10*qdim], &lbf[spos+26*qdim], &lbf[spos+11*qdim],
                       &lbf[spos+25*qdim], moment);
        uwall[2] -= moment;
        break;
      case PSB:
        fD3Q27PPSZouHe(p0, &force[0], &lbf[spos], &lbf[spos+2*qdim],
                       &lbf[spos+3*qdim], &lbf[spos+1*qdim], &lbf[spos+8*qdim], &lbf[spos+9*qdim],
                       &lbf[spos+4*qdim], &lbf[spos+18*qdim], &lbf[spos+6*qdim], &lbf[spos+20*qdim],
                       &lbf[spos+10*qdim], &lbf[spos+26*qdim], &lbf[spos+11*qdim], &lbf[spos+25*qdim],
                       &lbf[spos+15*qdim], &lbf[spos+16*qdim], &lbf[spos+14*qdim], &lbf[spos+21*qdim],
                       &lbf[spos+22*qdim], &lbf[spos+17*qdim], &lbf[spos+5*qdim], &lbf[spos+19*qdim],
                       &lbf[spos+7*qdim], &lbf[spos+23*qdim], &lbf[spos+13*qdim], &lbf[spos+24*qdim],
                       &lbf[spos+12*qdim], moment);
        uwall[2] += moment;
        break;
      case CCTRB:
        fD3Q27VCCCLBESimpleZouHe(p0, uwall[0], uwall[1], -uwall[2], &force[0], &lbf[spos], &lbf[spos+1*qdim],
                                 &lbf[spos+2*qdim], &lbf[spos+16*qdim], &lbf[spos+4*qdim], &lbf[spos+5*qdim],
                                 &lbf[spos+7*qdim], &lbf[spos+6*qdim], &lbf[spos+9*qdim], &lbf[spos+8*qdim],
                                 &lbf[spos+11*qdim], &lbf[spos+10*qdim], &lbf[spos+13*qdim], &lbf[spos+12*qdim],
                                 &lbf[spos+14*qdim], &lbf[spos+15*qdim], &lbf[spos+3*qdim], &lbf[spos+17*qdim],
                                 &lbf[spos+18*qdim], &lbf[spos+20*qdim], &lbf[spos+19*qdim], &lbf[spos+22*qdim],
                                 &lbf[spos+21*qdim], &lbf[spos+24*qdim], &lbf[spos+23*qdim], &lbf[spos+26*qdim],
                                 &lbf[spos+25*qdim]);
        break;
      case CCTLB:
        fD3Q27VCCCLBESimpleZouHe(p0, -uwall[0], uwall[1], -uwall[2], &force[0], &lbf[spos], &lbf[spos+14*qdim],
                                 &lbf[spos+2*qdim], &lbf[spos+16*qdim], &lbf[spos+18*qdim], &lbf[spos+17*qdim],
                                 &lbf[spos+19*qdim], &lbf[spos+20*qdim], &lbf[spos+9*qdim], &lbf[spos+8*qdim],
                                 &lbf[spos+25*qdim], &lbf[spos+26*qdim], &lbf[spos+23*qdim], &lbf[spos+24*qdim],
                                 &lbf[spos+1*qdim], &lbf[spos+15*qdim], &lbf[spos+3*qdim], &lbf[spos+5*qdim],
                                 &lbf[spos+4*qdim], &lbf[spos+6*qdim], &lbf[spos+7*qdim], &lbf[spos+22*qdim],
                                 &lbf[spos+21*qdim], &lbf[spos+12*qdim], &lbf[spos+13*qdim], &lbf[spos+10*qdim],
                                 &lbf[spos+11*qdim]);
        break;
      case CCDLB:
        fD3Q27VCCCLBESimpleZouHe(p0, -uwall[0], -uwall[1], -uwall[2], &force[0], &lbf[spos], &lbf[spos+14*qdim],
                                 &lbf[spos+15*qdim], &lbf[spos+16*qdim], &lbf[spos+17*qdim], &lbf[spos+18*qdim],
                                 &lbf[spos+19*qdim], &lbf[spos+20*qdim], &lbf[spos+21*qdim], &lbf[spos+22*qdim],
                                 &lbf[spos+23*qdim], &lbf[spos+24*qdim], &lbf[spos+25*qdim], &lbf[spos+26*qdim],
                                 &lbf[spos+1*qdim], &lbf[spos+2*qdim], &lbf[spos+3*qdim], &lbf[spos+4*qdim],
                                 &lbf[spos+5*qdim], &lbf[spos+6*qdim], &lbf[spos+7*qdim], &lbf[spos+8*qdim],
                                 &lbf[spos+9*qdim], &lbf[spos+10*qdim], &lbf[spos+11*qdim], &lbf[spos+12*qdim],
                                 &lbf[spos+13*qdim]);
        break;
      case CCDRB:
        fD3Q27VCCCLBESimpleZouHe(p0, uwall[0], -uwall[1], -uwall[2], &force[0], &lbf[spos], &lbf[spos+1*qdim],
                                 &lbf[spos+15*qdim], &lbf[spos+16*qdim], &lbf[spos+5*qdim], &lbf[spos+4*qdim],
                                 &lbf[spos+7*qdim], &lbf[spos+6*qdim], &lbf[spos+21*qdim], &lbf[spos+22*qdim],
                                 &lbf[spos+13*qdim], &lbf[spos+12*qdim], &lbf[spos+11*qdim], &lbf[spos+10*qdim],
                                 &lbf[spos+14*qdim], &lbf[spos+2*qdim], &lbf[spos+3*qdim], &lbf[spos+18*qdim],
                                 &lbf[spos+17*qdim], &lbf[spos+20*qdim], &lbf[spos+19*qdim], &lbf[spos+8*qdim],
                                 &lbf[spos+9*qdim], &lbf[spos+26*qdim], &lbf[spos+25*qdim], &lbf[spos+24*qdim],
                                 &lbf[spos+23*qdim]);
        break;
      case CCTRF:
        fD3Q27VCCCLBESimpleZouHe(p0, uwall[0], uwall[1], uwall[2], &force[0], &lbf[spos], &lbf[spos+1*qdim],
                                 &lbf[spos+2*qdim], &lbf[spos+3*qdim], &lbf[spos+4*qdim], &lbf[spos+5*qdim],
                                 &lbf[spos+6*qdim], &lbf[spos+7*qdim], &lbf[spos+8*qdim], &lbf[spos+9*qdim],
                                 &lbf[spos+10*qdim], &lbf[spos+11*qdim], &lbf[spos+12*qdim], &lbf[spos+13*qdim],
                                 &lbf[spos+14*qdim], &lbf[spos+15*qdim], &lbf[spos+16*qdim], &lbf[spos+17*qdim],
                                 &lbf[spos+18*qdim], &lbf[spos+19*qdim], &lbf[spos+20*qdim], &lbf[spos+21*qdim],
                                 &lbf[spos+22*qdim], &lbf[spos+23*qdim], &lbf[spos+24*qdim], &lbf[spos+25*qdim],
                                 &lbf[spos+26*qdim]);
        break;
      case CCTLF:
        fD3Q27VCCCLBESimpleZouHe(p0, -uwall[0], uwall[1], uwall[2], &force[0], &lbf[spos], &lbf[spos+14*qdim],
                                 &lbf[spos+2*qdim], &lbf[spos+3*qdim], &lbf[spos+18*qdim], &lbf[spos+17*qdim],
                                 &lbf[spos+20*qdim], &lbf[spos+19*qdim], &lbf[spos+8*qdim], &lbf[spos+9*qdim],
                                 &lbf[spos+26*qdim], &lbf[spos+25*qdim], &lbf[spos+24*qdim], &lbf[spos+23*qdim],
                                 &lbf[spos+1*qdim], &lbf[spos+15*qdim], &lbf[spos+16*qdim], &lbf[spos+5*qdim],
                                 &lbf[spos+4*qdim], &lbf[spos+7*qdim], &lbf[spos+6*qdim], &lbf[spos+21*qdim],
                                 &lbf[spos+22*qdim], &lbf[spos+13*qdim], &lbf[spos+12*qdim], &lbf[spos+11*qdim],
                                 &lbf[spos+10*qdim]);
        break;
      case CCDLF:
        fD3Q27VCCCLBESimpleZouHe(p0, -uwall[0], -uwall[1], uwall[2], &force[0], &lbf[spos], &lbf[spos+14*qdim],
                                 &lbf[spos+15*qdim], &lbf[spos+3*qdim], &lbf[spos+17*qdim], &lbf[spos+18*qdim],
                                 &lbf[spos+20*qdim], &lbf[spos+19*qdim], &lbf[spos+22*qdim], &lbf[spos+21*qdim],
                                 &lbf[spos+24*qdim], &lbf[spos+23*qdim], &lbf[spos+26*qdim], &lbf[spos+25*qdim],
                                 &lbf[spos+1*qdim], &lbf[spos+2*qdim], &lbf[spos+16*qdim], &lbf[spos+4*qdim],
                                 &lbf[spos+5*qdim], &lbf[spos+7*qdim], &lbf[spos+6*qdim], &lbf[spos+9*qdim],
                                 &lbf[spos+8*qdim], &lbf[spos+11*qdim], &lbf[spos+10*qdim], &lbf[spos+13*qdim],
                                 &lbf[spos+12*qdim]);
        break;
      case CCDRF:
        fD3Q27VCCCLBESimpleZouHe(p0, uwall[0], -uwall[1], uwall[2], &force[0], &lbf[spos], &lbf[spos+1*qdim],
                                 &lbf[spos+15*qdim], &lbf[spos+3*qdim], &lbf[spos+5*qdim], &lbf[spos+4*qdim],
                                 &lbf[spos+6*qdim], &lbf[spos+7*qdim], &lbf[spos+22*qdim], &lbf[spos+21*qdim],
                                 &lbf[spos+12*qdim], &lbf[spos+13*qdim], &lbf[spos+10*qdim], &lbf[spos+11*qdim],
                                 &lbf[spos+14*qdim], &lbf[spos+2*qdim], &lbf[spos+16*qdim], &lbf[spos+18*qdim],
                                 &lbf[spos+17*qdim], &lbf[spos+19*qdim], &lbf[spos+20*qdim], &lbf[spos+9*qdim],
                                 &lbf[spos+8*qdim], &lbf[spos+25*qdim], &lbf[spos+26*qdim], &lbf[spos+23*qdim],
                                 &lbf[spos+24*qdim]);
        break;
      case CETR:
        fD3Q27VCECLBESimpleZouHe(p0, uwall[0], uwall[1], uwall[2], &force[0], &lbf[spos], &lbf[spos+1*qdim],
                                 &lbf[spos+2*qdim], &lbf[spos+3*qdim], &lbf[spos+4*qdim], &lbf[spos+5*qdim],
                                 &lbf[spos+6*qdim], &lbf[spos+7*qdim], &lbf[spos+8*qdim], &lbf[spos+9*qdim],
                                 &lbf[spos+10*qdim], &lbf[spos+11*qdim], &lbf[spos+12*qdim], &lbf[spos+13*qdim],
                                 &lbf[spos+14*qdim], &lbf[spos+15*qdim], &lbf[spos+16*qdim], &lbf[spos+17*qdim],
                                 &lbf[spos+18*qdim], &lbf[spos+19*qdim], &lbf[spos+20*qdim], &lbf[spos+21*qdim],
                                 &lbf[spos+22*qdim], &lbf[spos+23*qdim], &lbf[spos+24*qdim], &lbf[spos+25*qdim],
                                 &lbf[spos+26*qdim]);
        break;
      case CETL:
        fD3Q27VCECLBESimpleZouHe(p0, uwall[1], -uwall[0], uwall[2], &force[0], &lbf[spos], &lbf[spos+2*qdim],
                                 &lbf[spos+14*qdim], &lbf[spos+3*qdim], &lbf[spos+18*qdim], &lbf[spos+4*qdim],
                                 &lbf[spos+8*qdim], &lbf[spos+9*qdim], &lbf[spos+20*qdim], &lbf[spos+19*qdim],
                                 &lbf[spos+26*qdim], &lbf[spos+25*qdim], &lbf[spos+10*qdim], &lbf[spos+11*qdim],
                                 &lbf[spos+15*qdim], &lbf[spos+1*qdim], &lbf[spos+16*qdim], &lbf[spos+5*qdim],
                                 &lbf[spos+17*qdim], &lbf[spos+21*qdim], &lbf[spos+22*qdim], &lbf[spos+7*qdim],
                                 &lbf[spos+6*qdim], &lbf[spos+13*qdim], &lbf[spos+12*qdim], &lbf[spos+23*qdim],
                                 &lbf[spos+24*qdim]);
        break;
      case CEDL:
        fD3Q27VCECLBESimpleZouHe(p0, -uwall[0], -uwall[1], uwall[2], &force[0], &lbf[spos], &lbf[spos+14*qdim],
                                 &lbf[spos+15*qdim], &lbf[spos+3*qdim], &lbf[spos+17*qdim], &lbf[spos+18*qdim],
                                 &lbf[spos+20*qdim], &lbf[spos+19*qdim], &lbf[spos+22*qdim], &lbf[spos+21*qdim],
                                 &lbf[spos+24*qdim], &lbf[spos+23*qdim], &lbf[spos+26*qdim], &lbf[spos+25*qdim],
                                 &lbf[spos+1*qdim], &lbf[spos+2*qdim], &lbf[spos+16*qdim], &lbf[spos+4*qdim],
                                 &lbf[spos+5*qdim], &lbf[spos+7*qdim], &lbf[spos+6*qdim], &lbf[spos+9*qdim],
                                 &lbf[spos+8*qdim], &lbf[spos+11*qdim], &lbf[spos+10*qdim], &lbf[spos+13*qdim],
                                 &lbf[spos+12*qdim]);
        break;
      case CEDR:
        fD3Q27VCECLBESimpleZouHe(p0, -uwall[1], uwall[0], uwall[2], &force[0], &lbf[spos], &lbf[spos+15*qdim],
                                 &lbf[spos+1*qdim], &lbf[spos+3*qdim], &lbf[spos+5*qdim], &lbf[spos+17*qdim],
                                 &lbf[spos+22*qdim], &lbf[spos+21*qdim], &lbf[spos+6*qdim], &lbf[spos+7*qdim],
                                 &lbf[spos+12*qdim], &lbf[spos+13*qdim], &lbf[spos+24*qdim], &lbf[spos+23*qdim],
                                 &lbf[spos+2*qdim], &lbf[spos+14*qdim], &lbf[spos+16*qdim], &lbf[spos+18*qdim],
                                 &lbf[spos+4*qdim], &lbf[spos+9*qdim], &lbf[spos+8*qdim], &lbf[spos+19*qdim],
                                 &lbf[spos+20*qdim], &lbf[spos+25*qdim], &lbf[spos+26*qdim], &lbf[spos+11*qdim],
                                 &lbf[spos+10*qdim]);
        break;
      case CETF:
        fD3Q27VCECLBESimpleZouHe(p0, uwall[1], uwall[2], uwall[0], &force[0], &lbf[spos], &lbf[spos+2*qdim],
                                 &lbf[spos+3*qdim], &lbf[spos+1*qdim], &lbf[spos+8*qdim], &lbf[spos+9*qdim],
                                 &lbf[spos+4*qdim], &lbf[spos+18*qdim], &lbf[spos+6*qdim], &lbf[spos+20*qdim],
                                 &lbf[spos+10*qdim], &lbf[spos+26*qdim], &lbf[spos+11*qdim], &lbf[spos+25*qdim],
                                 &lbf[spos+15*qdim], &lbf[spos+16*qdim], &lbf[spos+14*qdim], &lbf[spos+21*qdim],
                                 &lbf[spos+22*qdim], &lbf[spos+17*qdim], &lbf[spos+5*qdim], &lbf[spos+19*qdim],
                                 &lbf[spos+7*qdim], &lbf[spos+23*qdim], &lbf[spos+13*qdim], &lbf[spos+24*qdim],
                                 &lbf[spos+12*qdim]);
        break;
      case CELF:
        fD3Q27VCECLBESimpleZouHe(p0, -uwall[0], uwall[1], uwall[2], &force[0], &lbf[spos], &lbf[spos+14*qdim],
                                 &lbf[spos+3*qdim], &lbf[spos+2*qdim], &lbf[spos+20*qdim], &lbf[spos+19*qdim],
                                 &lbf[spos+18*qdim], &lbf[spos+17*qdim], &lbf[spos+8*qdim], &lbf[spos+22*qdim],
                                 &lbf[spos+26*qdim], &lbf[spos+24*qdim], &lbf[spos+25*qdim], &lbf[spos+23*qdim],
                                 &lbf[spos+1*qdim], &lbf[spos+16*qdim], &lbf[spos+15*qdim], &lbf[spos+7*qdim],
                                 &lbf[spos+6*qdim], &lbf[spos+5*qdim], &lbf[spos+4*qdim], &lbf[spos+21*qdim],
                                 &lbf[spos+9*qdim], &lbf[spos+13*qdim], &lbf[spos+11*qdim], &lbf[spos+12*qdim],
                                 &lbf[spos+10*qdim]);
        break;
      case CEDF:
        fD3Q27VCECLBESimpleZouHe(p0, -uwall[1], uwall[2], uwall[0], &force[0], &lbf[spos], &lbf[spos+15*qdim],
                                 &lbf[spos+3*qdim], &lbf[spos+1*qdim], &lbf[spos+22*qdim], &lbf[spos+21*qdim],
                                 &lbf[spos+5*qdim], &lbf[spos+17*qdim], &lbf[spos+6*qdim], &lbf[spos+20*qdim],
                                 &lbf[spos+12*qdim], &lbf[spos+24*qdim], &lbf[spos+13*qdim], &lbf[spos+23*qdim],
                                 &lbf[spos+2*qdim], &lbf[spos+16*qdim], &lbf[spos+14*qdim], &lbf[spos+9*qdim],
                                 &lbf[spos+8*qdim], &lbf[spos+18*qdim], &lbf[spos+4*qdim], &lbf[spos+19*qdim],
                                 &lbf[spos+7*qdim], &lbf[spos+25*qdim], &lbf[spos+11*qdim], &lbf[spos+26*qdim],
                                 &lbf[spos+10*qdim]);
        break;
      case CERF:
        fD3Q27VCECLBESimpleZouHe(p0, uwall[0], uwall[2], uwall[2], &force[0], &lbf[spos], &lbf[spos+1*qdim],
                                 &lbf[spos+3*qdim], &lbf[spos+2*qdim], &lbf[spos+6*qdim], &lbf[spos+7*qdim],
                                 &lbf[spos+4*qdim], &lbf[spos+5*qdim], &lbf[spos+8*qdim], &lbf[spos+22*qdim],
                                 &lbf[spos+10*qdim], &lbf[spos+12*qdim], &lbf[spos+11*qdim], &lbf[spos+13*qdim],
                                 &lbf[spos+14*qdim], &lbf[spos+16*qdim], &lbf[spos+15*qdim], &lbf[spos+19*qdim],
                                 &lbf[spos+20*qdim], &lbf[spos+17*qdim], &lbf[spos+18*qdim], &lbf[spos+21*qdim],
                                 &lbf[spos+9*qdim], &lbf[spos+23*qdim], &lbf[spos+25*qdim], &lbf[spos+24*qdim],
                                 &lbf[spos+26*qdim]);
        break;
      case CETB:
        fD3Q27VCECLBESimpleZouHe(p0, uwall[1], -uwall[2], uwall[0], &force[0], &lbf[spos], &lbf[spos+2*qdim],
                                 &lbf[spos+16*qdim], &lbf[spos+1*qdim], &lbf[spos+9*qdim], &lbf[spos+8*qdim],
                                 &lbf[spos+4*qdim], &lbf[spos+18*qdim], &lbf[spos+7*qdim], &lbf[spos+19*qdim],
                                 &lbf[spos+11*qdim], &lbf[spos+25*qdim], &lbf[spos+10*qdim], &lbf[spos+26*qdim],
                                 &lbf[spos+15*qdim], &lbf[spos+3*qdim], &lbf[spos+14*qdim], &lbf[spos+22*qdim],
                                 &lbf[spos+21*qdim], &lbf[spos+17*qdim], &lbf[spos+5*qdim], &lbf[spos+20*qdim],
                                 &lbf[spos+6*qdim], &lbf[spos+24*qdim], &lbf[spos+12*qdim], &lbf[spos+23*qdim],
                                 &lbf[spos+13*qdim]);
        break;
      case CELB:
        fD3Q27VCECLBESimpleZouHe(p0, -uwall[0], -uwall[2], uwall[1], &force[0], &lbf[spos], &lbf[spos+14*qdim],
                                 &lbf[spos+16*qdim], &lbf[spos+2*qdim], &lbf[spos+19*qdim], &lbf[spos+20*qdim],
                                 &lbf[spos+18*qdim], &lbf[spos+17*qdim], &lbf[spos+9*qdim], &lbf[spos+21*qdim],
                                 &lbf[spos+25*qdim], &lbf[spos+23*qdim], &lbf[spos+26*qdim], &lbf[spos+24*qdim],
                                 &lbf[spos+1*qdim], &lbf[spos+3*qdim], &lbf[spos+15*qdim], &lbf[spos+6*qdim],
                                 &lbf[spos+7*qdim], &lbf[spos+5*qdim], &lbf[spos+4*qdim], &lbf[spos+22*qdim],
                                 &lbf[spos+8*qdim], &lbf[spos+12*qdim], &lbf[spos+10*qdim], &lbf[spos+13*qdim],
                                 &lbf[spos+11*qdim]);
        break;
      case CEDB:
        fD3Q27VCECLBESimpleZouHe(p0, -uwall[1], -uwall[2], uwall[0], &force[0], &lbf[spos], &lbf[spos+15*qdim],
                                 &lbf[spos+16*qdim], &lbf[spos+1*qdim], &lbf[spos+21*qdim], &lbf[spos+22*qdim],
                                 &lbf[spos+5*qdim], &lbf[spos+17*qdim], &lbf[spos+7*qdim], &lbf[spos+19*qdim],
                                 &lbf[spos+13*qdim], &lbf[spos+23*qdim], &lbf[spos+12*qdim], &lbf[spos+24*qdim],
                                 &lbf[spos+2*qdim], &lbf[spos+3*qdim], &lbf[spos+14*qdim], &lbf[spos+8*qdim],
                                 &lbf[spos+9*qdim], &lbf[spos+18*qdim], &lbf[spos+4*qdim], &lbf[spos+20*qdim],
                                 &lbf[spos+6*qdim], &lbf[spos+26*qdim], &lbf[spos+10*qdim], &lbf[spos+25*qdim],
                                 &lbf[spos+11*qdim]);
        break;
      case CERB:
        fD3Q27VCECLBESimpleZouHe(p0, uwall[0], -uwall[2], uwall[1], &force[0], &lbf[spos], &lbf[spos+1*qdim],
                                 &lbf[spos+16*qdim], &lbf[spos+2*qdim], &lbf[spos+7*qdim], &lbf[spos+6*qdim],
                                 &lbf[spos+4*qdim], &lbf[spos+5*qdim], &lbf[spos+9*qdim], &lbf[spos+21*qdim],
                                 &lbf[spos+11*qdim], &lbf[spos+13*qdim], &lbf[spos+10*qdim], &lbf[spos+12*qdim],
                                 &lbf[spos+14*qdim], &lbf[spos+3*qdim], &lbf[spos+15*qdim], &lbf[spos+20*qdim],
                                 &lbf[spos+19*qdim], &lbf[spos+17*qdim], &lbf[spos+18*qdim], &lbf[spos+22*qdim],
                                 &lbf[spos+8*qdim], &lbf[spos+24*qdim], &lbf[spos+26*qdim], &lbf[spos+23*qdim],
                                 &lbf[spos+25*qdim]);
        break;
    }
  }
  else {
    switch (prop) {
      case PST:
        fD3Q27PPSZouHe(p0, &force[0], &lbf[spos], &lbf[spos+1*qdim],
                       &lbf[spos+2*qdim], &lbf[spos+3*qdim], &lbf[spos+4*qdim], &lbf[spos+5*qdim],
                       &lbf[spos+6*qdim], &lbf[spos+7*qdim], &lbf[spos+8*qdim], &lbf[spos+9*qdim],
                       &lbf[spos+10*qdim], &lbf[spos+11*qdim], &lbf[spos+12*qdim], &lbf[spos+13*qdim],
                       &lbf[spos+14*qdim], &lbf[spos+15*qdim], &lbf[spos+16*qdim], &lbf[spos+17*qdim],
                       &lbf[spos+18*qdim], &lbf[spos+19*qdim], &lbf[spos+20*qdim], &lbf[spos+21*qdim],
                       &lbf[spos+22*qdim], &lbf[spos+23*qdim], &lbf[spos+24*qdim], &lbf[spos+25*qdim],
                       &lbf[spos+26*qdim], moment);
        uwall[1] += moment;
        break;
      case PSD:
        fD3Q27PPSZouHe(p0, &force[0], &lbf[spos], &lbf[spos+14*qdim],
                       &lbf[spos+15*qdim], &lbf[spos+16*qdim], &lbf[spos+17*qdim], &lbf[spos+18*qdim],
                       &lbf[spos+19*qdim], &lbf[spos+20*qdim], &lbf[spos+21*qdim], &lbf[spos+22*qdim],
                       &lbf[spos+23*qdim], &lbf[spos+24*qdim], &lbf[spos+25*qdim], &lbf[spos+26*qdim],
                       &lbf[spos+1*qdim], &lbf[spos+2*qdim], &lbf[spos+3*qdim], &lbf[spos+4*qdim],
                       &lbf[spos+5*qdim], &lbf[spos+6*qdim], &lbf[spos+7*qdim], &lbf[spos+8*qdim],
                       &lbf[spos+9*qdim], &lbf[spos+10*qdim], &lbf[spos+11*qdim], &lbf[spos+12*qdim],
                       &lbf[spos+13*qdim], moment);
        uwall[1] -= moment;
        break;
      case PSL:
        fD3Q27PPSZouHe(p0, &force[0], &lbf[spos], &lbf[spos+16*qdim],
                       &lbf[spos+14*qdim], &lbf[spos+15*qdim], &lbf[spos+19*qdim], &lbf[spos+7*qdim],
                       &lbf[spos+21*qdim], &lbf[spos+9*qdim], &lbf[spos+17*qdim], &lbf[spos+18*qdim],
                       &lbf[spos+23*qdim], &lbf[spos+25*qdim], &lbf[spos+13*qdim], &lbf[spos+11*qdim],
                       &lbf[spos+3*qdim], &lbf[spos+1*qdim], &lbf[spos+2*qdim], &lbf[spos+6*qdim],
                       &lbf[spos+20*qdim], &lbf[spos+8*qdim], &lbf[spos+22*qdim], &lbf[spos+4*qdim],
                       &lbf[spos+5*qdim], &lbf[spos+10*qdim], &lbf[spos+12*qdim], &lbf[spos+26*qdim],
                       &lbf[spos+24*qdim], moment);
        uwall[0] -= moment;
        break;
      case PSR:
        fD3Q27PPSZouHe(p0, &force[0], &lbf[spos], &lbf[spos+3*qdim],
                       &lbf[spos+1*qdim], &lbf[spos+2*qdim], &lbf[spos+6*qdim], &lbf[spos+20*qdim],
                       &lbf[spos+8*qdim], &lbf[spos+22*qdim], &lbf[spos+4*qdim], &lbf[spos+5*qdim],
                       &lbf[spos+10*qdim], &lbf[spos+12*qdim], &lbf[spos+26*qdim], &lbf[spos+24*qdim],
                       &lbf[spos+16*qdim], &lbf[spos+14*qdim], &lbf[spos+15*qdim], &lbf[spos+19*qdim],
                       &lbf[spos+7*qdim], &lbf[spos+21*qdim], &lbf[spos+9*qdim], &lbf[spos+17*qdim],
                       &lbf[spos+18*qdim], &lbf[spos+23*qdim], &lbf[spos+25*qdim], &lbf[spos+13*qdim],
                       &lbf[spos+11*qdim], moment);
        uwall[0] += moment;
        break;
      case PSF:
        fD3Q27PPSZouHe(p0, &force[0], &lbf[spos], &lbf[spos+15*qdim],
                       &lbf[spos+16*qdim], &lbf[spos+14*qdim], &lbf[spos+21*qdim], &lbf[spos+22*qdim],
                       &lbf[spos+17*qdim], &lbf[spos+5*qdim], &lbf[spos+19*qdim], &lbf[spos+7*qdim],
                       &lbf[spos+23*qdim], &lbf[spos+13*qdim], &lbf[spos+24*qdim], &lbf[spos+12*qdim],
                       &lbf[spos+2*qdim], &lbf[spos+3*qdim], &lbf[spos+1*qdim], &lbf[spos+8*qdim],
                       &lbf[spos+9*qdim], &lbf[spos+4*qdim], &lbf[spos+18*qdim], &lbf[spos+6*qdim],
                       &lbf[spos+20*qdim], &lbf[spos+10*qdim], &lbf[spos+26*qdim], &lbf[spos+11*qdim],
                       &lbf[spos+25*qdim], moment);
        uwall[2] -= moment;
        break;
      case PSB:
        fD3Q27PPSZouHe(p0, &force[0], &lbf[spos], &lbf[spos+2*qdim],
                       &lbf[spos+3*qdim], &lbf[spos+1*qdim], &lbf[spos+8*qdim], &lbf[spos+9*qdim],
                       &lbf[spos+4*qdim], &lbf[spos+18*qdim], &lbf[spos+6*qdim], &lbf[spos+20*qdim],
                       &lbf[spos+10*qdim], &lbf[spos+26*qdim], &lbf[spos+11*qdim], &lbf[spos+25*qdim],
                       &lbf[spos+15*qdim], &lbf[spos+16*qdim], &lbf[spos+14*qdim], &lbf[spos+21*qdim],
                       &lbf[spos+22*qdim], &lbf[spos+17*qdim], &lbf[spos+5*qdim], &lbf[spos+19*qdim],
                       &lbf[spos+7*qdim], &lbf[spos+23*qdim], &lbf[spos+13*qdim], &lbf[spos+24*qdim],
                       &lbf[spos+12*qdim], moment);
        uwall[2] += moment;
        break;
      case CCTRB:
        fD3Q27VCCSimpleZouHe(p0, uwall[0], uwall[1], -uwall[2], &force[0], &lbf[spos], &lbf[spos+1*qdim],
                             &lbf[spos+2*qdim], &lbf[spos+16*qdim], &lbf[spos+4*qdim], &lbf[spos+5*qdim],
                             &lbf[spos+7*qdim], &lbf[spos+6*qdim], &lbf[spos+9*qdim], &lbf[spos+8*qdim],
                             &lbf[spos+11*qdim], &lbf[spos+10*qdim], &lbf[spos+13*qdim], &lbf[spos+12*qdim],
                             &lbf[spos+14*qdim], &lbf[spos+15*qdim], &lbf[spos+3*qdim], &lbf[spos+17*qdim],
                             &lbf[spos+18*qdim], &lbf[spos+20*qdim], &lbf[spos+19*qdim], &lbf[spos+22*qdim],
                             &lbf[spos+21*qdim], &lbf[spos+24*qdim], &lbf[spos+23*qdim], &lbf[spos+26*qdim],
                             &lbf[spos+25*qdim]);
        break;
      case CCTLB:
        fD3Q27VCCSimpleZouHe(p0, -uwall[0], uwall[1], -uwall[2], &force[0], &lbf[spos], &lbf[spos+14*qdim],
                             &lbf[spos+2*qdim], &lbf[spos+16*qdim], &lbf[spos+18*qdim], &lbf[spos+17*qdim],
                             &lbf[spos+19*qdim], &lbf[spos+20*qdim], &lbf[spos+9*qdim], &lbf[spos+8*qdim],
                             &lbf[spos+25*qdim], &lbf[spos+26*qdim], &lbf[spos+23*qdim], &lbf[spos+24*qdim],
                             &lbf[spos+1*qdim], &lbf[spos+15*qdim], &lbf[spos+3*qdim], &lbf[spos+5*qdim],
                             &lbf[spos+4*qdim], &lbf[spos+6*qdim], &lbf[spos+7*qdim], &lbf[spos+22*qdim],
                             &lbf[spos+21*qdim], &lbf[spos+12*qdim], &lbf[spos+13*qdim], &lbf[spos+10*qdim],
                             &lbf[spos+11*qdim]);
        break;
      case CCDLB:
        fD3Q27VCCSimpleZouHe(p0, -uwall[0], -uwall[1], -uwall[2], &force[0], &lbf[spos], &lbf[spos+14*qdim],
                             &lbf[spos+15*qdim], &lbf[spos+16*qdim], &lbf[spos+17*qdim], &lbf[spos+18*qdim],
                             &lbf[spos+19*qdim], &lbf[spos+20*qdim], &lbf[spos+21*qdim], &lbf[spos+22*qdim],
                             &lbf[spos+23*qdim], &lbf[spos+24*qdim], &lbf[spos+25*qdim], &lbf[spos+26*qdim],
                             &lbf[spos+1*qdim], &lbf[spos+2*qdim], &lbf[spos+3*qdim], &lbf[spos+4*qdim],
                             &lbf[spos+5*qdim], &lbf[spos+6*qdim], &lbf[spos+7*qdim], &lbf[spos+8*qdim],
                             &lbf[spos+9*qdim], &lbf[spos+10*qdim], &lbf[spos+11*qdim], &lbf[spos+12*qdim],
                             &lbf[spos+13*qdim]);
        break;
      case CCDRB:
        fD3Q27VCCSimpleZouHe(p0, uwall[0], -uwall[1], -uwall[2], &force[0], &lbf[spos], &lbf[spos+1*qdim],
                             &lbf[spos+15*qdim], &lbf[spos+16*qdim], &lbf[spos+5*qdim], &lbf[spos+4*qdim],
                             &lbf[spos+7*qdim], &lbf[spos+6*qdim], &lbf[spos+21*qdim], &lbf[spos+22*qdim],
                             &lbf[spos+13*qdim], &lbf[spos+12*qdim], &lbf[spos+11*qdim], &lbf[spos+10*qdim],
                             &lbf[spos+14*qdim], &lbf[spos+2*qdim], &lbf[spos+3*qdim], &lbf[spos+18*qdim],
                             &lbf[spos+17*qdim], &lbf[spos+20*qdim], &lbf[spos+19*qdim], &lbf[spos+8*qdim],
                             &lbf[spos+9*qdim], &lbf[spos+26*qdim], &lbf[spos+25*qdim], &lbf[spos+24*qdim],
                             &lbf[spos+23*qdim]);
        break;
      case CCTRF:
        fD3Q27VCCSimpleZouHe(p0, uwall[0], uwall[1], uwall[2], &force[0], &lbf[spos], &lbf[spos+1*qdim],
                             &lbf[spos+2*qdim], &lbf[spos+3*qdim], &lbf[spos+4*qdim], &lbf[spos+5*qdim],
                             &lbf[spos+6*qdim], &lbf[spos+7*qdim], &lbf[spos+8*qdim], &lbf[spos+9*qdim],
                             &lbf[spos+10*qdim], &lbf[spos+11*qdim], &lbf[spos+12*qdim], &lbf[spos+13*qdim],
                             &lbf[spos+14*qdim], &lbf[spos+15*qdim], &lbf[spos+16*qdim], &lbf[spos+17*qdim],
                             &lbf[spos+18*qdim], &lbf[spos+19*qdim], &lbf[spos+20*qdim], &lbf[spos+21*qdim],
                             &lbf[spos+22*qdim], &lbf[spos+23*qdim], &lbf[spos+24*qdim], &lbf[spos+25*qdim],
                             &lbf[spos+26*qdim]);
        break;
      case CCTLF:
        fD3Q27VCCSimpleZouHe(p0, -uwall[0], uwall[1], uwall[2], &force[0], &lbf[spos], &lbf[spos+14*qdim],
                             &lbf[spos+2*qdim], &lbf[spos+3*qdim], &lbf[spos+18*qdim], &lbf[spos+17*qdim],
                             &lbf[spos+20*qdim], &lbf[spos+19*qdim], &lbf[spos+8*qdim], &lbf[spos+9*qdim],
                             &lbf[spos+26*qdim], &lbf[spos+25*qdim], &lbf[spos+24*qdim], &lbf[spos+23*qdim],
                             &lbf[spos+1*qdim], &lbf[spos+15*qdim], &lbf[spos+16*qdim], &lbf[spos+5*qdim],
                             &lbf[spos+4*qdim], &lbf[spos+7*qdim], &lbf[spos+6*qdim], &lbf[spos+21*qdim],
                             &lbf[spos+22*qdim], &lbf[spos+13*qdim], &lbf[spos+12*qdim], &lbf[spos+11*qdim],
                             &lbf[spos+10*qdim]);
        break;
      case CCDLF:
        fD3Q27VCCSimpleZouHe(p0, -uwall[0], -uwall[1], uwall[2], &force[0], &lbf[spos], &lbf[spos+14*qdim],
                             &lbf[spos+15*qdim], &lbf[spos+3*qdim], &lbf[spos+17*qdim], &lbf[spos+18*qdim],
                             &lbf[spos+20*qdim], &lbf[spos+19*qdim], &lbf[spos+22*qdim], &lbf[spos+21*qdim],
                             &lbf[spos+24*qdim], &lbf[spos+23*qdim], &lbf[spos+26*qdim], &lbf[spos+25*qdim],
                             &lbf[spos+1*qdim], &lbf[spos+2*qdim], &lbf[spos+16*qdim], &lbf[spos+4*qdim],
                             &lbf[spos+5*qdim], &lbf[spos+7*qdim], &lbf[spos+6*qdim], &lbf[spos+9*qdim],
                             &lbf[spos+8*qdim], &lbf[spos+11*qdim], &lbf[spos+10*qdim], &lbf[spos+13*qdim],
                             &lbf[spos+12*qdim]);
        break;
      case CCDRF:
        fD3Q27VCCSimpleZouHe(p0, uwall[0], -uwall[1], uwall[2], &force[0], &lbf[spos], &lbf[spos+1*qdim],
                             &lbf[spos+15*qdim], &lbf[spos+3*qdim], &lbf[spos+5*qdim], &lbf[spos+4*qdim],
                             &lbf[spos+6*qdim], &lbf[spos+7*qdim], &lbf[spos+22*qdim], &lbf[spos+21*qdim],
                             &lbf[spos+12*qdim], &lbf[spos+13*qdim], &lbf[spos+10*qdim], &lbf[spos+11*qdim],
                             &lbf[spos+14*qdim], &lbf[spos+2*qdim], &lbf[spos+16*qdim], &lbf[spos+18*qdim],
                             &lbf[spos+17*qdim], &lbf[spos+19*qdim], &lbf[spos+20*qdim], &lbf[spos+9*qdim],
                             &lbf[spos+8*qdim], &lbf[spos+25*qdim], &lbf[spos+26*qdim], &lbf[spos+23*qdim],
                             &lbf[spos+24*qdim]);
        break;
      case CETR:
        fD3Q27VCESimpleZouHe(p0, uwall[0], uwall[1], uwall[2], &force[0], &lbf[spos], &lbf[spos+1*qdim],
                             &lbf[spos+2*qdim], &lbf[spos+3*qdim], &lbf[spos+4*qdim], &lbf[spos+5*qdim],
                             &lbf[spos+6*qdim], &lbf[spos+7*qdim], &lbf[spos+8*qdim], &lbf[spos+9*qdim],
                             &lbf[spos+10*qdim], &lbf[spos+11*qdim], &lbf[spos+12*qdim], &lbf[spos+13*qdim],
                             &lbf[spos+14*qdim], &lbf[spos+15*qdim], &lbf[spos+16*qdim], &lbf[spos+17*qdim],
                             &lbf[spos+18*qdim], &lbf[spos+19*qdim], &lbf[spos+20*qdim], &lbf[spos+21*qdim],
                             &lbf[spos+22*qdim], &lbf[spos+23*qdim], &lbf[spos+24*qdim], &lbf[spos+25*qdim],
                             &lbf[spos+26*qdim]);
        break;
      case CETL:
        fD3Q27VCESimpleZouHe(p0, uwall[1], -uwall[0], uwall[2], &force[0], &lbf[spos], &lbf[spos+2*qdim],
                             &lbf[spos+14*qdim], &lbf[spos+3*qdim], &lbf[spos+18*qdim], &lbf[spos+4*qdim],
                             &lbf[spos+8*qdim], &lbf[spos+9*qdim], &lbf[spos+20*qdim], &lbf[spos+19*qdim],
                             &lbf[spos+26*qdim], &lbf[spos+25*qdim], &lbf[spos+10*qdim], &lbf[spos+11*qdim],
                             &lbf[spos+15*qdim], &lbf[spos+1*qdim], &lbf[spos+16*qdim], &lbf[spos+5*qdim],
                             &lbf[spos+17*qdim], &lbf[spos+21*qdim], &lbf[spos+22*qdim], &lbf[spos+7*qdim],
                             &lbf[spos+6*qdim], &lbf[spos+13*qdim], &lbf[spos+12*qdim], &lbf[spos+23*qdim],
                             &lbf[spos+24*qdim]);
        break;
      case CEDL:
        fD3Q27VCESimpleZouHe(p0, -uwall[0], -uwall[1], uwall[2], &force[0], &lbf[spos], &lbf[spos+14*qdim],
                             &lbf[spos+15*qdim], &lbf[spos+3*qdim], &lbf[spos+17*qdim], &lbf[spos+18*qdim],
                             &lbf[spos+20*qdim], &lbf[spos+19*qdim], &lbf[spos+22*qdim], &lbf[spos+21*qdim],
                             &lbf[spos+24*qdim], &lbf[spos+23*qdim], &lbf[spos+26*qdim], &lbf[spos+25*qdim],
                             &lbf[spos+1*qdim], &lbf[spos+2*qdim], &lbf[spos+16*qdim], &lbf[spos+4*qdim],
                             &lbf[spos+5*qdim], &lbf[spos+7*qdim], &lbf[spos+6*qdim], &lbf[spos+9*qdim],
                             &lbf[spos+8*qdim], &lbf[spos+11*qdim], &lbf[spos+10*qdim], &lbf[spos+13*qdim],
                             &lbf[spos+12*qdim]);
        break;
      case CEDR:
        fD3Q27VCESimpleZouHe(p0, -uwall[1], uwall[0], uwall[2], &force[0], &lbf[spos], &lbf[spos+15*qdim],
                             &lbf[spos+1*qdim], &lbf[spos+3*qdim], &lbf[spos+5*qdim], &lbf[spos+17*qdim],
                             &lbf[spos+22*qdim], &lbf[spos+21*qdim], &lbf[spos+6*qdim], &lbf[spos+7*qdim],
                             &lbf[spos+12*qdim], &lbf[spos+13*qdim], &lbf[spos+24*qdim], &lbf[spos+23*qdim],
                             &lbf[spos+2*qdim], &lbf[spos+14*qdim], &lbf[spos+16*qdim], &lbf[spos+18*qdim],
                             &lbf[spos+4*qdim], &lbf[spos+9*qdim], &lbf[spos+8*qdim], &lbf[spos+19*qdim],
                             &lbf[spos+20*qdim], &lbf[spos+25*qdim], &lbf[spos+26*qdim], &lbf[spos+11*qdim],
                             &lbf[spos+10*qdim]);
        break;
      case CETF:
        fD3Q27VCESimpleZouHe(p0, uwall[1], uwall[2], uwall[0], &force[0], &lbf[spos], &lbf[spos+2*qdim],
                             &lbf[spos+3*qdim], &lbf[spos+1*qdim], &lbf[spos+8*qdim], &lbf[spos+9*qdim],
                             &lbf[spos+4*qdim], &lbf[spos+18*qdim], &lbf[spos+6*qdim], &lbf[spos+20*qdim],
                             &lbf[spos+10*qdim], &lbf[spos+26*qdim], &lbf[spos+11*qdim], &lbf[spos+25*qdim],
                             &lbf[spos+15*qdim], &lbf[spos+16*qdim], &lbf[spos+14*qdim], &lbf[spos+21*qdim],
                             &lbf[spos+22*qdim], &lbf[spos+17*qdim], &lbf[spos+5*qdim], &lbf[spos+19*qdim],
                             &lbf[spos+7*qdim], &lbf[spos+23*qdim], &lbf[spos+13*qdim], &lbf[spos+24*qdim],
                             &lbf[spos+12*qdim]);
        break;
      case CELF:
        fD3Q27VCESimpleZouHe(p0, -uwall[0], uwall[1], uwall[2], &force[0], &lbf[spos], &lbf[spos+14*qdim],
                             &lbf[spos+3*qdim], &lbf[spos+2*qdim], &lbf[spos+20*qdim], &lbf[spos+19*qdim],
                             &lbf[spos+18*qdim], &lbf[spos+17*qdim], &lbf[spos+8*qdim], &lbf[spos+22*qdim],
                             &lbf[spos+26*qdim], &lbf[spos+24*qdim], &lbf[spos+25*qdim], &lbf[spos+23*qdim],
                             &lbf[spos+1*qdim], &lbf[spos+16*qdim], &lbf[spos+15*qdim], &lbf[spos+7*qdim],
                             &lbf[spos+6*qdim], &lbf[spos+5*qdim], &lbf[spos+4*qdim], &lbf[spos+21*qdim],
                             &lbf[spos+9*qdim], &lbf[spos+13*qdim], &lbf[spos+11*qdim], &lbf[spos+12*qdim],
                             &lbf[spos+10*qdim]);
        break;
      case CEDF:
        fD3Q27VCESimpleZouHe(p0, -uwall[1], uwall[2], uwall[0], &force[0], &lbf[spos], &lbf[spos+15*qdim],
                             &lbf[spos+3*qdim], &lbf[spos+1*qdim], &lbf[spos+22*qdim], &lbf[spos+21*qdim],
                             &lbf[spos+5*qdim], &lbf[spos+17*qdim], &lbf[spos+6*qdim], &lbf[spos+20*qdim],
                             &lbf[spos+12*qdim], &lbf[spos+24*qdim], &lbf[spos+13*qdim], &lbf[spos+23*qdim],
                             &lbf[spos+2*qdim], &lbf[spos+16*qdim], &lbf[spos+14*qdim], &lbf[spos+9*qdim],
                             &lbf[spos+8*qdim], &lbf[spos+18*qdim], &lbf[spos+4*qdim], &lbf[spos+19*qdim],
                             &lbf[spos+7*qdim], &lbf[spos+25*qdim], &lbf[spos+11*qdim], &lbf[spos+26*qdim],
                             &lbf[spos+10*qdim]);
        break;
      case CERF:
        fD3Q27VCESimpleZouHe(p0, uwall[0], uwall[2], uwall[2], &force[0], &lbf[spos], &lbf[spos+1*qdim],
                             &lbf[spos+3*qdim], &lbf[spos+2*qdim], &lbf[spos+6*qdim], &lbf[spos+7*qdim],
                             &lbf[spos+4*qdim], &lbf[spos+5*qdim], &lbf[spos+8*qdim], &lbf[spos+22*qdim],
                             &lbf[spos+10*qdim], &lbf[spos+12*qdim], &lbf[spos+11*qdim], &lbf[spos+13*qdim],
                             &lbf[spos+14*qdim], &lbf[spos+16*qdim], &lbf[spos+15*qdim], &lbf[spos+19*qdim],
                             &lbf[spos+20*qdim], &lbf[spos+17*qdim], &lbf[spos+18*qdim], &lbf[spos+21*qdim],
                             &lbf[spos+9*qdim], &lbf[spos+23*qdim], &lbf[spos+25*qdim], &lbf[spos+24*qdim],
                             &lbf[spos+26*qdim]);
        break;
      case CETB:
        fD3Q27VCESimpleZouHe(p0, uwall[1], -uwall[2], uwall[0], &force[0], &lbf[spos], &lbf[spos+2*qdim],
                             &lbf[spos+16*qdim], &lbf[spos+1*qdim], &lbf[spos+9*qdim], &lbf[spos+8*qdim],
                             &lbf[spos+4*qdim], &lbf[spos+18*qdim], &lbf[spos+7*qdim], &lbf[spos+19*qdim],
                             &lbf[spos+11*qdim], &lbf[spos+25*qdim], &lbf[spos+10*qdim], &lbf[spos+26*qdim],
                             &lbf[spos+15*qdim], &lbf[spos+3*qdim], &lbf[spos+14*qdim], &lbf[spos+22*qdim],
                             &lbf[spos+21*qdim], &lbf[spos+17*qdim], &lbf[spos+5*qdim], &lbf[spos+20*qdim],
                             &lbf[spos+6*qdim], &lbf[spos+24*qdim], &lbf[spos+12*qdim], &lbf[spos+23*qdim],
                             &lbf[spos+13*qdim]);
        break;
      case CELB:
        fD3Q27VCESimpleZouHe(p0, -uwall[0], -uwall[2], uwall[1], &force[0], &lbf[spos], &lbf[spos+14*qdim],
                             &lbf[spos+16*qdim], &lbf[spos+2*qdim], &lbf[spos+19*qdim], &lbf[spos+20*qdim],
                             &lbf[spos+18*qdim], &lbf[spos+17*qdim], &lbf[spos+9*qdim], &lbf[spos+21*qdim],
                             &lbf[spos+25*qdim], &lbf[spos+23*qdim], &lbf[spos+26*qdim], &lbf[spos+24*qdim],
                             &lbf[spos+1*qdim], &lbf[spos+3*qdim], &lbf[spos+15*qdim], &lbf[spos+6*qdim],
                             &lbf[spos+7*qdim], &lbf[spos+5*qdim], &lbf[spos+4*qdim], &lbf[spos+22*qdim],
                             &lbf[spos+8*qdim], &lbf[spos+12*qdim], &lbf[spos+10*qdim], &lbf[spos+13*qdim],
                             &lbf[spos+11*qdim]);
        break;
      case CEDB:
        fD3Q27VCESimpleZouHe(p0, -uwall[1], -uwall[2], uwall[0], &force[0], &lbf[spos], &lbf[spos+15*qdim],
                             &lbf[spos+16*qdim], &lbf[spos+1*qdim], &lbf[spos+21*qdim], &lbf[spos+22*qdim],
                             &lbf[spos+5*qdim], &lbf[spos+17*qdim], &lbf[spos+7*qdim], &lbf[spos+19*qdim],
                             &lbf[spos+13*qdim], &lbf[spos+23*qdim], &lbf[spos+12*qdim], &lbf[spos+24*qdim],
                             &lbf[spos+2*qdim], &lbf[spos+3*qdim], &lbf[spos+14*qdim], &lbf[spos+8*qdim],
                             &lbf[spos+9*qdim], &lbf[spos+18*qdim], &lbf[spos+4*qdim], &lbf[spos+20*qdim],
                             &lbf[spos+6*qdim], &lbf[spos+26*qdim], &lbf[spos+10*qdim], &lbf[spos+25*qdim],
                             &lbf[spos+11*qdim]);
        break;
      case CERB:
        fD3Q27VCESimpleZouHe(p0, uwall[0], -uwall[2], uwall[1], &force[0], &lbf[spos], &lbf[spos+1*qdim],
                             &lbf[spos+16*qdim], &lbf[spos+2*qdim], &lbf[spos+7*qdim], &lbf[spos+6*qdim],
                             &lbf[spos+4*qdim], &lbf[spos+5*qdim], &lbf[spos+9*qdim], &lbf[spos+21*qdim],
                             &lbf[spos+11*qdim], &lbf[spos+13*qdim], &lbf[spos+10*qdim], &lbf[spos+12*qdim],
                             &lbf[spos+14*qdim], &lbf[spos+3*qdim], &lbf[spos+15*qdim], &lbf[spos+20*qdim],
                             &lbf[spos+19*qdim], &lbf[spos+17*qdim], &lbf[spos+18*qdim], &lbf[spos+22*qdim],
                             &lbf[spos+8*qdim], &lbf[spos+24*qdim], &lbf[spos+26*qdim], &lbf[spos+23*qdim],
                             &lbf[spos+25*qdim]);
        break;
    }
  }
  return 0;
}


int fD3Q27CPSZouHe(double *p, double v0, double v1, double v2, double *f0, double *f1,
                   double *f2, double *f3, double *f4, double *f5, double *f6,
                   double *f7, double *f8, double *f9, double *f10, double *f11,
                   double *f12, double *f13, double *f14, double *f15, double *f16,
                   double *f17, double *f18, double *f19, double *f20, double *f21,
                   double *f22, double *f23, double *f24, double *f25, double *f26)
{

  // produce fixed concentration at planar surface: expressed for bottom wall (CPST)

  double c1=5.0/9.0,c2=1.0/9.0,c3=1.0/36.0;
  for(int i=0; i<lbsy.nc; i++) {
    f5[i]=f18[i]-c2*p[i]*(v0-v1);
    f11[i]=p[i]*(1.0-c1*v1)-f0[i]-f1[i]-f2[i]-f3[i]-f6[i]-f7[i]-f14[i]-f15[i]-f16[i]-f19[i]-f20[i]-2.0*(f4[i]+f8[i]+f9[i]+f10[i]+f11[i]+f18[i]+f25[i]+f26[i]);
    f12[i]=f25[i]-c3*p[i]*(v0-v1+v2);
    f13[i]=f26[i]-c3*p[i]*(v0-v1-v2);
    f17[i]=f4[i]+c2*p[i]*(v0+v1);
    f21[i]=f8[i]+c2*p[i]*(v1+v2);
    f22[i]=f9[i]+c2*p[i]*(v1-v2);
    f23[i]=f10[i]+c3*p[i]*(v0+v1+v2);
    f24[i]=f11[i]+c3*p[i]*(v0+v1-v2);
  }
  return 0;
}

int fD3Q27CCEZouHe(double *p, double v0, double v1, double v2, double *f0, double *f1,
                   double *f2, double *f3, double *f4, double *f5, double *f6,
                   double *f7, double *f8, double *f9, double *f10, double *f11,
                   double *f12, double *f13, double *f14, double *f15, double *f16,
                   double *f17, double *f18, double *f19, double *f20, double *f21,
                   double *f22, double *f23, double *f24, double *f25, double *f26)
{

  // produce fixed concentration at concave edge: expressed for bottom left edge (CCETR)

  double q0, qxy, nz;
  double c1=4.0/9.0,c2=1.0/9.0,c3=1.0/36.0,c4=1.0/12.0,c5=1.0/72.0,c7=1.0/6.0,c8=5.0/72.0,c10=1.0/22.0,c11=1.0/44.0;

  for(int i=0; i<lbsy.nc; i++) {
    q0 = c4*(p[i]-f0[i]-f3[i]-f16[i])-c7*(f1[i]+f2[i]+f4[i]+f6[i]+f7[i]+f8[i]+f9[i]+f10[i]+f11[i])-c8*p[i]*(v0+v1);
    qxy = c5*p[i]*(v0-v1);
    nz = c10*(f16[i]-f3[i])-c11*p[i]*v2;
    f5[i]=4.0*(q0-qxy);
    f12[i]=q0-qxy+nz;
    f13[i]=q0-qxy-nz;
    f14[i]=f1[i]+c1*p[i]*v0;
    f15[i]=f2[i]+c1*p[i]*v1;
    f17[i]=f4[i]+c2*p[i]*(v0+v1);
    f18[i]=4.0*(q0+qxy);
    f19[i]=f6[i]+c2*p[i]*(v0+v2)-4.0*nz;
    f20[i]=f7[i]+c2*p[i]*(v0-v2)+4.0*nz;
    f21[i]=f8[i]+c2*p[i]*(v1+v2)-4.0*nz;
    f22[i]=f9[i]+c2*p[i]*(v1-v2)+4.0*nz;
    f23[i]=f10[i]+c3*p[i]*(v0+v1+v2)-nz;
    f24[i]=f11[i]+c3*p[i]*(v0+v1-v2)+nz;
    f25[i]=q0+qxy-nz;
    f26[i]=q0+qxy+nz;
  }
  return 0;
}

int fD3Q27CCCZouHe(double *p, double v0, double v1, double v2, double *f0, double *f1,
                   double *f2, double *f3, double *f4, double *f5, double *f6,
                   double *f7, double *f8, double *f9, double *f10, double *f11,
                   double *f12, double *f13, double *f14, double *f15, double *f16,
                   double *f17, double *f18, double *f19, double *f20, double *f21,
                   double *f22, double *f23, double *f24, double *f25, double *f26)
{

  // produce fixed concentration at concave corner: expressed for bottom left back corner (CCCTRF)

  double q0, qx, qy, qz;
  double c1=4.0/9.0,c2=1.0/9.0,c3=1.0/36.0,c4=1.0/30.0,c5=1.0/72.0,c7=1.0/15.0,c8=5.0/216.0;

  for(int i=0; i<lbsy.nc; i++) {
    q0 = c4*(p[i]-f0[i])-c7*(f1[i]+f2[i]+f3[i]+f4[i]+f6[i]+f8[i]+f10[i])-c8*p[i]*(v0+v1+v2);
    qx = c5*p[i]*v0;
    qy = c5*p[i]*v1;
    qz = c5*p[i]*v2;
    f5[i]=4.0*(q0-qx+qy);
    f7[i]=4.0*(q0-qx+qz);
    f9[i]=4.0*(q0-qy+qz);
    f11[i]=q0-qx-qy+qz;
    f12[i]=q0-qx+qy-qz;
    f13[i]=q0-qx+qy+qz;
    f14[i]=f1[i]+c1*p[i]*v0;
    f15[i]=f2[i]+c1*p[i]*v1;
    f16[i]=f3[i]+c1*p[i]*v2;
    f17[i]=f4[i]+c2*p[i]*(v0+v1);
    f18[i]=4.0*(q0+qx-qy);
    f19[i]=f6[i]+c2*p[i]*(v0+v2);
    f20[i]=4.0*(q0+qx-qz);
    f21[i]=f8[i]+c2*p[i]*(v1+v2);
    f22[i]=4.0*(q0+qy-qz);
    f23[i]=f10[i]+c3*p[i]*(v0+v1+v2);
    f24[i]=q0+qx+qx-qz;
    f25[i]=q0+qx-qy+qz;
    f26[i]=q0+qx-qy-qz;
  }
  return 0;
}


int fD3Q27PCZouHe(long tpos, int prop, double *p0, double *uwall)
{
  long spos=tpos * lbsitelength + lbsy.nf;
  int qdim=lbsy.nf+lbsy.nc+lbsy.nt;
    
  switch (prop) {
    case PST:
      fD3Q27CPSZouHe(p0, uwall[0], uwall[1], uwall[2], &lbf[spos], &lbf[spos+1*qdim],
                     &lbf[spos+2*qdim], &lbf[spos+3*qdim], &lbf[spos+4*qdim], &lbf[spos+5*qdim], &lbf[spos+6*qdim],
                     &lbf[spos+7*qdim], &lbf[spos+8*qdim], &lbf[spos+9*qdim], &lbf[spos+10*qdim], &lbf[spos+11*qdim],
                     &lbf[spos+12*qdim], &lbf[spos+13*qdim], &lbf[spos+14*qdim], &lbf[spos+15*qdim], &lbf[spos+16*qdim],
                     &lbf[spos+17*qdim], &lbf[spos+18*qdim], &lbf[spos+19*qdim], &lbf[spos+20*qdim], &lbf[spos+21*qdim],
                     &lbf[spos+22*qdim], &lbf[spos+23*qdim], &lbf[spos+24*qdim], &lbf[spos+25*qdim], &lbf[spos+26*qdim]);
      break;
    case PSD:
      fD3Q27CPSZouHe(p0, -uwall[0], -uwall[1], -uwall[2], &lbf[spos], &lbf[spos+14*qdim],
                     &lbf[spos+15*qdim], &lbf[spos+16*qdim], &lbf[spos+17*qdim], &lbf[spos+18*qdim], &lbf[spos+19*qdim],
                     &lbf[spos+20*qdim], &lbf[spos+21*qdim], &lbf[spos+22*qdim], &lbf[spos+23*qdim], &lbf[spos+24*qdim],
                     &lbf[spos+25*qdim], &lbf[spos+26*qdim], &lbf[spos+1*qdim], &lbf[spos+2*qdim], &lbf[spos+3*qdim],
                     &lbf[spos+4*qdim], &lbf[spos+5*qdim], &lbf[spos+6*qdim], &lbf[spos+7*qdim], &lbf[spos+8*qdim],
                     &lbf[spos+9*qdim], &lbf[spos+10*qdim], &lbf[spos+11*qdim], &lbf[spos+12*qdim], &lbf[spos+13*qdim]);
      break;
    case PSL:
      fD3Q27CPSZouHe(p0, -uwall[2], -uwall[0], -uwall[1], &lbf[spos], &lbf[spos+16*qdim],
                     &lbf[spos+14*qdim], &lbf[spos+15*qdim], &lbf[spos+19*qdim], &lbf[spos+7*qdim], &lbf[spos+21*qdim],
                     &lbf[spos+9*qdim], &lbf[spos+17*qdim], &lbf[spos+18*qdim], &lbf[spos+23*qdim], &lbf[spos+25*qdim],
                     &lbf[spos+13*qdim], &lbf[spos+11*qdim], &lbf[spos+3*qdim], &lbf[spos+1*qdim], &lbf[spos+2*qdim],
                     &lbf[spos+6*qdim], &lbf[spos+20*qdim], &lbf[spos+8*qdim], &lbf[spos+22*qdim], &lbf[spos+4*qdim],
                     &lbf[spos+5*qdim], &lbf[spos+10*qdim], &lbf[spos+12*qdim], &lbf[spos+26*qdim], &lbf[spos+24*qdim]);
      break;
    case PSR:
      fD3Q27CPSZouHe(p0, uwall[2], uwall[0], uwall[1], &lbf[spos], &lbf[spos+3*qdim],
                     &lbf[spos+1*qdim], &lbf[spos+2*qdim], &lbf[spos+6*qdim], &lbf[spos+20*qdim], &lbf[spos+8*qdim],
                     &lbf[spos+22*qdim], &lbf[spos+4*qdim], &lbf[spos+5*qdim], &lbf[spos+10*qdim], &lbf[spos+12*qdim],
                     &lbf[spos+26*qdim], &lbf[spos+24*qdim], &lbf[spos+16*qdim], &lbf[spos+14*qdim], &lbf[spos+15*qdim],
                     &lbf[spos+19*qdim], &lbf[spos+7*qdim], &lbf[spos+21*qdim], &lbf[spos+9*qdim], &lbf[spos+17*qdim],
                     &lbf[spos+18*qdim], &lbf[spos+23*qdim], &lbf[spos+25*qdim], &lbf[spos+13*qdim], &lbf[spos+11*qdim]);
      break;
    case PSF:
      fD3Q27CPSZouHe(p0, -uwall[1], -uwall[2], -uwall[0], &lbf[spos], &lbf[spos+15*qdim],
                     &lbf[spos+16*qdim], &lbf[spos+14*qdim], &lbf[spos+21*qdim], &lbf[spos+22*qdim], &lbf[spos+17*qdim],
                     &lbf[spos+5*qdim], &lbf[spos+19*qdim], &lbf[spos+7*qdim], &lbf[spos+23*qdim], &lbf[spos+13*qdim],
                     &lbf[spos+24*qdim], &lbf[spos+12*qdim], &lbf[spos+2*qdim], &lbf[spos+3*qdim], &lbf[spos+1*qdim],
                     &lbf[spos+8*qdim], &lbf[spos+9*qdim], &lbf[spos+4*qdim], &lbf[spos+18*qdim], &lbf[spos+6*qdim],
                     &lbf[spos+20*qdim], &lbf[spos+10*qdim], &lbf[spos+26*qdim], &lbf[spos+11*qdim], &lbf[spos+25*qdim]);
      break;
    case PSB:
      fD3Q27CPSZouHe(p0, uwall[1], uwall[2], uwall[0], &lbf[spos], &lbf[spos+2*qdim],
                     &lbf[spos+3*qdim], &lbf[spos+1*qdim], &lbf[spos+8*qdim], &lbf[spos+9*qdim], &lbf[spos+4*qdim],
                     &lbf[spos+18*qdim], &lbf[spos+6*qdim], &lbf[spos+20*qdim], &lbf[spos+10*qdim], &lbf[spos+26*qdim],
                     &lbf[spos+11*qdim], &lbf[spos+25*qdim], &lbf[spos+15*qdim], &lbf[spos+16*qdim], &lbf[spos+14*qdim],
                     &lbf[spos+21*qdim], &lbf[spos+22*qdim], &lbf[spos+17*qdim], &lbf[spos+5*qdim], &lbf[spos+19*qdim],
                     &lbf[spos+7*qdim], &lbf[spos+23*qdim], &lbf[spos+13*qdim], &lbf[spos+24*qdim], &lbf[spos+12*qdim]);
      break;
    case CCTRB:
      fD3Q27CCCZouHe(p0, uwall[0], uwall[1], -uwall[2], &lbf[spos], &lbf[spos+1*qdim],
                     &lbf[spos+2*qdim], &lbf[spos+16*qdim], &lbf[spos+4*qdim], &lbf[spos+5*qdim],
                     &lbf[spos+7*qdim], &lbf[spos+6*qdim], &lbf[spos+9*qdim], &lbf[spos+8*qdim],
                     &lbf[spos+11*qdim], &lbf[spos+10*qdim], &lbf[spos+13*qdim], &lbf[spos+12*qdim],
                     &lbf[spos+14*qdim], &lbf[spos+15*qdim], &lbf[spos+3*qdim], &lbf[spos+17*qdim],
                     &lbf[spos+18*qdim], &lbf[spos+20*qdim], &lbf[spos+19*qdim], &lbf[spos+22*qdim],
                     &lbf[spos+21*qdim], &lbf[spos+24*qdim], &lbf[spos+23*qdim], &lbf[spos+26*qdim],
                     &lbf[spos+25*qdim]);
      break;
    case CCTLB:
      fD3Q27CCCZouHe(p0, -uwall[0], uwall[1], -uwall[2], &lbf[spos], &lbf[spos+14*qdim],
                     &lbf[spos+2*qdim], &lbf[spos+16*qdim], &lbf[spos+18*qdim], &lbf[spos+17*qdim],
                     &lbf[spos+19*qdim], &lbf[spos+20*qdim], &lbf[spos+9*qdim], &lbf[spos+8*qdim],
                     &lbf[spos+25*qdim], &lbf[spos+26*qdim], &lbf[spos+23*qdim], &lbf[spos+24*qdim],
                     &lbf[spos+1*qdim], &lbf[spos+15*qdim], &lbf[spos+3*qdim], &lbf[spos+5*qdim],
                     &lbf[spos+4*qdim], &lbf[spos+6*qdim], &lbf[spos+7*qdim], &lbf[spos+22*qdim],
                     &lbf[spos+21*qdim], &lbf[spos+12*qdim], &lbf[spos+13*qdim], &lbf[spos+10*qdim],
                     &lbf[spos+11*qdim]);
      break;
    case CCDLB:
      fD3Q27CCCZouHe(p0, -uwall[0], -uwall[1], -uwall[2], &lbf[spos], &lbf[spos+14*qdim],
                     &lbf[spos+15*qdim], &lbf[spos+16*qdim], &lbf[spos+17*qdim], &lbf[spos+18*qdim],
                     &lbf[spos+19*qdim], &lbf[spos+20*qdim], &lbf[spos+21*qdim], &lbf[spos+22*qdim],
                     &lbf[spos+23*qdim], &lbf[spos+24*qdim], &lbf[spos+25*qdim], &lbf[spos+26*qdim],
                     &lbf[spos+1*qdim], &lbf[spos+2*qdim], &lbf[spos+3*qdim], &lbf[spos+4*qdim],
                     &lbf[spos+5*qdim], &lbf[spos+6*qdim], &lbf[spos+7*qdim], &lbf[spos+8*qdim],
                     &lbf[spos+9*qdim], &lbf[spos+10*qdim], &lbf[spos+11*qdim], &lbf[spos+12*qdim],
                     &lbf[spos+13*qdim]);
      break;
    case CCDRB:
      fD3Q27CCCZouHe(p0, uwall[0], -uwall[1], -uwall[2], &lbf[spos], &lbf[spos+1*qdim],
                     &lbf[spos+15*qdim], &lbf[spos+16*qdim], &lbf[spos+5*qdim], &lbf[spos+4*qdim],
                     &lbf[spos+7*qdim], &lbf[spos+6*qdim], &lbf[spos+21*qdim], &lbf[spos+22*qdim],
                     &lbf[spos+13*qdim], &lbf[spos+12*qdim], &lbf[spos+11*qdim], &lbf[spos+10*qdim],
                     &lbf[spos+14*qdim], &lbf[spos+2*qdim], &lbf[spos+3*qdim], &lbf[spos+18*qdim],
                     &lbf[spos+17*qdim], &lbf[spos+20*qdim], &lbf[spos+19*qdim], &lbf[spos+8*qdim],
                     &lbf[spos+9*qdim], &lbf[spos+26*qdim], &lbf[spos+25*qdim], &lbf[spos+24*qdim],
                     &lbf[spos+23*qdim]);
      break;
    case CCTRF:
      fD3Q27CCCZouHe(p0, uwall[0], uwall[1], uwall[2], &lbf[spos], &lbf[spos+1*qdim],
                     &lbf[spos+2*qdim], &lbf[spos+3*qdim], &lbf[spos+4*qdim], &lbf[spos+5*qdim],
                     &lbf[spos+6*qdim], &lbf[spos+7*qdim], &lbf[spos+8*qdim], &lbf[spos+9*qdim],
                     &lbf[spos+10*qdim], &lbf[spos+11*qdim], &lbf[spos+12*qdim], &lbf[spos+13*qdim],
                     &lbf[spos+14*qdim], &lbf[spos+15*qdim], &lbf[spos+16*qdim], &lbf[spos+17*qdim],
                     &lbf[spos+18*qdim], &lbf[spos+19*qdim], &lbf[spos+20*qdim], &lbf[spos+21*qdim],
                     &lbf[spos+22*qdim], &lbf[spos+23*qdim], &lbf[spos+24*qdim], &lbf[spos+25*qdim],
                     &lbf[spos+26*qdim]);
      break;
    case CCTLF:
      fD3Q27CCCZouHe(p0, -uwall[0], uwall[1], uwall[2], &lbf[spos], &lbf[spos+14*qdim],
                     &lbf[spos+2*qdim], &lbf[spos+3*qdim], &lbf[spos+18*qdim], &lbf[spos+17*qdim],
                     &lbf[spos+20*qdim], &lbf[spos+19*qdim], &lbf[spos+8*qdim], &lbf[spos+9*qdim],
                     &lbf[spos+26*qdim], &lbf[spos+25*qdim], &lbf[spos+24*qdim], &lbf[spos+23*qdim],
                     &lbf[spos+1*qdim], &lbf[spos+15*qdim], &lbf[spos+16*qdim], &lbf[spos+5*qdim],
                     &lbf[spos+4*qdim], &lbf[spos+7*qdim], &lbf[spos+6*qdim], &lbf[spos+21*qdim],
                     &lbf[spos+22*qdim], &lbf[spos+13*qdim], &lbf[spos+12*qdim], &lbf[spos+11*qdim],
                     &lbf[spos+10*qdim]);
      break;
    case CCDLF:
      fD3Q27CCCZouHe(p0, -uwall[0], -uwall[1], uwall[2], &lbf[spos], &lbf[spos+14*qdim],
                     &lbf[spos+15*qdim], &lbf[spos+3*qdim], &lbf[spos+17*qdim], &lbf[spos+18*qdim],
                     &lbf[spos+20*qdim], &lbf[spos+19*qdim], &lbf[spos+22*qdim], &lbf[spos+21*qdim],
                     &lbf[spos+24*qdim], &lbf[spos+23*qdim], &lbf[spos+26*qdim], &lbf[spos+25*qdim],
                     &lbf[spos+1*qdim], &lbf[spos+2*qdim], &lbf[spos+16*qdim], &lbf[spos+4*qdim],
                     &lbf[spos+5*qdim], &lbf[spos+7*qdim], &lbf[spos+6*qdim], &lbf[spos+9*qdim],
                     &lbf[spos+8*qdim], &lbf[spos+11*qdim], &lbf[spos+10*qdim], &lbf[spos+13*qdim],
                     &lbf[spos+12*qdim]);
      break;
    case CCDRF:
      fD3Q27CCCZouHe(p0, uwall[0], -uwall[1], uwall[2], &lbf[spos], &lbf[spos+1*qdim],
                     &lbf[spos+15*qdim], &lbf[spos+3*qdim], &lbf[spos+5*qdim], &lbf[spos+4*qdim],
                     &lbf[spos+6*qdim], &lbf[spos+7*qdim], &lbf[spos+22*qdim], &lbf[spos+21*qdim],
                     &lbf[spos+12*qdim], &lbf[spos+13*qdim], &lbf[spos+10*qdim], &lbf[spos+11*qdim],
                     &lbf[spos+14*qdim], &lbf[spos+2*qdim], &lbf[spos+16*qdim], &lbf[spos+18*qdim],
                     &lbf[spos+17*qdim], &lbf[spos+19*qdim], &lbf[spos+20*qdim], &lbf[spos+9*qdim],
                     &lbf[spos+8*qdim], &lbf[spos+25*qdim], &lbf[spos+26*qdim], &lbf[spos+23*qdim],
                     &lbf[spos+24*qdim]);
      break;
    case CETR:
      fD3Q27CCEZouHe(p0, uwall[0], uwall[1], uwall[2], &lbf[spos], &lbf[spos+1*qdim],
                     &lbf[spos+2*qdim], &lbf[spos+3*qdim], &lbf[spos+4*qdim], &lbf[spos+5*qdim],
                     &lbf[spos+6*qdim], &lbf[spos+7*qdim], &lbf[spos+8*qdim], &lbf[spos+9*qdim],
                     &lbf[spos+10*qdim], &lbf[spos+11*qdim], &lbf[spos+12*qdim], &lbf[spos+13*qdim],
                     &lbf[spos+14*qdim], &lbf[spos+15*qdim], &lbf[spos+16*qdim], &lbf[spos+17*qdim],
                     &lbf[spos+18*qdim], &lbf[spos+19*qdim], &lbf[spos+20*qdim], &lbf[spos+21*qdim],
                     &lbf[spos+22*qdim], &lbf[spos+23*qdim], &lbf[spos+24*qdim], &lbf[spos+25*qdim],
                     &lbf[spos+26*qdim]);
      break;
    case CETL:
      fD3Q27CCEZouHe(p0, uwall[1], -uwall[0], uwall[2], &lbf[spos], &lbf[spos+2*qdim],
                     &lbf[spos+14*qdim], &lbf[spos+3*qdim], &lbf[spos+18*qdim], &lbf[spos+4*qdim],
                     &lbf[spos+8*qdim], &lbf[spos+9*qdim], &lbf[spos+20*qdim], &lbf[spos+19*qdim],
                     &lbf[spos+26*qdim], &lbf[spos+25*qdim], &lbf[spos+10*qdim], &lbf[spos+11*qdim],
                     &lbf[spos+15*qdim], &lbf[spos+1*qdim], &lbf[spos+16*qdim], &lbf[spos+5*qdim],
                     &lbf[spos+17*qdim], &lbf[spos+21*qdim], &lbf[spos+22*qdim], &lbf[spos+7*qdim],
                     &lbf[spos+6*qdim], &lbf[spos+13*qdim], &lbf[spos+12*qdim], &lbf[spos+23*qdim],
                     &lbf[spos+24*qdim]);
      break;
    case CEDL:
      fD3Q27CCEZouHe(p0, -uwall[0], -uwall[1], uwall[2], &lbf[spos], &lbf[spos+14*qdim],
                     &lbf[spos+15*qdim], &lbf[spos+3*qdim], &lbf[spos+17*qdim], &lbf[spos+18*qdim],
                     &lbf[spos+20*qdim], &lbf[spos+19*qdim], &lbf[spos+22*qdim], &lbf[spos+21*qdim],
                     &lbf[spos+24*qdim], &lbf[spos+23*qdim], &lbf[spos+26*qdim], &lbf[spos+25*qdim],
                     &lbf[spos+1*qdim], &lbf[spos+2*qdim], &lbf[spos+16*qdim], &lbf[spos+4*qdim],
                     &lbf[spos+5*qdim], &lbf[spos+7*qdim], &lbf[spos+6*qdim], &lbf[spos+9*qdim],
                     &lbf[spos+8*qdim], &lbf[spos+11*qdim], &lbf[spos+10*qdim], &lbf[spos+13*qdim],
                     &lbf[spos+12*qdim]);
      break;
    case CEDR:
      fD3Q27CCEZouHe(p0, -uwall[1], uwall[0], uwall[2], &lbf[spos], &lbf[spos+15*qdim],
                     &lbf[spos+1*qdim], &lbf[spos+3*qdim], &lbf[spos+5*qdim], &lbf[spos+17*qdim],
                     &lbf[spos+22*qdim], &lbf[spos+21*qdim], &lbf[spos+6*qdim], &lbf[spos+7*qdim],
                     &lbf[spos+12*qdim], &lbf[spos+13*qdim], &lbf[spos+24*qdim], &lbf[spos+23*qdim],
                     &lbf[spos+2*qdim], &lbf[spos+14*qdim], &lbf[spos+16*qdim], &lbf[spos+18*qdim],
                     &lbf[spos+4*qdim], &lbf[spos+9*qdim], &lbf[spos+8*qdim], &lbf[spos+19*qdim],
                     &lbf[spos+20*qdim], &lbf[spos+25*qdim], &lbf[spos+26*qdim], &lbf[spos+11*qdim],
                     &lbf[spos+10*qdim]);
      break;
    case CETF:
      fD3Q27CCEZouHe(p0, uwall[1], uwall[2], uwall[0], &lbf[spos], &lbf[spos+2*qdim],
                     &lbf[spos+3*qdim], &lbf[spos+1*qdim], &lbf[spos+8*qdim], &lbf[spos+9*qdim],
                     &lbf[spos+4*qdim], &lbf[spos+18*qdim], &lbf[spos+6*qdim], &lbf[spos+20*qdim],
                     &lbf[spos+10*qdim], &lbf[spos+26*qdim], &lbf[spos+11*qdim], &lbf[spos+25*qdim],
                     &lbf[spos+15*qdim], &lbf[spos+16*qdim], &lbf[spos+14*qdim], &lbf[spos+21*qdim],
                     &lbf[spos+22*qdim], &lbf[spos+17*qdim], &lbf[spos+5*qdim], &lbf[spos+19*qdim],
                     &lbf[spos+7*qdim], &lbf[spos+23*qdim], &lbf[spos+13*qdim], &lbf[spos+24*qdim],
                     &lbf[spos+12*qdim]);
      break;
    case CELF:
      fD3Q27CCEZouHe(p0, -uwall[0], uwall[1], uwall[2], &lbf[spos], &lbf[spos+14*qdim],
                     &lbf[spos+3*qdim], &lbf[spos+2*qdim], &lbf[spos+20*qdim], &lbf[spos+19*qdim],
                     &lbf[spos+18*qdim], &lbf[spos+17*qdim], &lbf[spos+8*qdim], &lbf[spos+22*qdim],
                     &lbf[spos+26*qdim], &lbf[spos+24*qdim], &lbf[spos+25*qdim], &lbf[spos+23*qdim],
                     &lbf[spos+1*qdim], &lbf[spos+16*qdim], &lbf[spos+15*qdim], &lbf[spos+7*qdim],
                     &lbf[spos+6*qdim], &lbf[spos+5*qdim], &lbf[spos+4*qdim], &lbf[spos+21*qdim],
                     &lbf[spos+9*qdim], &lbf[spos+13*qdim], &lbf[spos+11*qdim], &lbf[spos+12*qdim],
                     &lbf[spos+10*qdim]);
      break;
    case CEDF:
      fD3Q27CCEZouHe(p0, -uwall[1], uwall[2], uwall[0], &lbf[spos], &lbf[spos+15*qdim],
                     &lbf[spos+3*qdim], &lbf[spos+1*qdim], &lbf[spos+22*qdim], &lbf[spos+21*qdim],
                     &lbf[spos+5*qdim], &lbf[spos+17*qdim], &lbf[spos+6*qdim], &lbf[spos+20*qdim],
                     &lbf[spos+12*qdim], &lbf[spos+24*qdim], &lbf[spos+13*qdim], &lbf[spos+23*qdim],
                     &lbf[spos+2*qdim], &lbf[spos+16*qdim], &lbf[spos+14*qdim], &lbf[spos+9*qdim],
                     &lbf[spos+8*qdim], &lbf[spos+18*qdim], &lbf[spos+4*qdim], &lbf[spos+19*qdim],
                     &lbf[spos+7*qdim], &lbf[spos+25*qdim], &lbf[spos+11*qdim], &lbf[spos+26*qdim],
                     &lbf[spos+10*qdim]);
      break;
    case CERF:
      fD3Q27CCEZouHe(p0, uwall[0], uwall[2], uwall[2], &lbf[spos], &lbf[spos+1*qdim],
                     &lbf[spos+3*qdim], &lbf[spos+2*qdim], &lbf[spos+6*qdim], &lbf[spos+7*qdim],
                     &lbf[spos+4*qdim], &lbf[spos+5*qdim], &lbf[spos+8*qdim], &lbf[spos+22*qdim],
                     &lbf[spos+10*qdim], &lbf[spos+12*qdim], &lbf[spos+11*qdim], &lbf[spos+13*qdim],
                     &lbf[spos+14*qdim], &lbf[spos+16*qdim], &lbf[spos+15*qdim], &lbf[spos+19*qdim],
                     &lbf[spos+20*qdim], &lbf[spos+17*qdim], &lbf[spos+18*qdim], &lbf[spos+21*qdim],
                     &lbf[spos+9*qdim], &lbf[spos+23*qdim], &lbf[spos+25*qdim], &lbf[spos+24*qdim],
                     &lbf[spos+26*qdim]);
      break;
    case CETB:
      fD3Q27CCEZouHe(p0, uwall[1], -uwall[2], uwall[0], &lbf[spos], &lbf[spos+2*qdim],
                     &lbf[spos+16*qdim], &lbf[spos+1*qdim], &lbf[spos+9*qdim], &lbf[spos+8*qdim],
                     &lbf[spos+4*qdim], &lbf[spos+18*qdim], &lbf[spos+7*qdim], &lbf[spos+19*qdim],
                     &lbf[spos+11*qdim], &lbf[spos+25*qdim], &lbf[spos+10*qdim], &lbf[spos+26*qdim],
                     &lbf[spos+15*qdim], &lbf[spos+3*qdim], &lbf[spos+14*qdim], &lbf[spos+22*qdim],
                     &lbf[spos+21*qdim], &lbf[spos+17*qdim], &lbf[spos+5*qdim], &lbf[spos+20*qdim],
                     &lbf[spos+6*qdim], &lbf[spos+24*qdim], &lbf[spos+12*qdim], &lbf[spos+23*qdim],
                     &lbf[spos+13*qdim]);
      break;
    case CELB:
      fD3Q27CCEZouHe(p0, -uwall[0], -uwall[2], uwall[1], &lbf[spos], &lbf[spos+14*qdim],
                     &lbf[spos+16*qdim], &lbf[spos+2*qdim], &lbf[spos+19*qdim], &lbf[spos+20*qdim],
                     &lbf[spos+18*qdim], &lbf[spos+17*qdim], &lbf[spos+9*qdim], &lbf[spos+21*qdim],
                     &lbf[spos+25*qdim], &lbf[spos+23*qdim], &lbf[spos+26*qdim], &lbf[spos+24*qdim],
                     &lbf[spos+1*qdim], &lbf[spos+3*qdim], &lbf[spos+15*qdim], &lbf[spos+6*qdim],
                     &lbf[spos+7*qdim], &lbf[spos+5*qdim], &lbf[spos+4*qdim], &lbf[spos+22*qdim],
                     &lbf[spos+8*qdim], &lbf[spos+12*qdim], &lbf[spos+10*qdim], &lbf[spos+13*qdim],
                     &lbf[spos+11*qdim]);
      break;
    case CEDB:
      fD3Q27CCEZouHe(p0, -uwall[1], -uwall[2], uwall[0], &lbf[spos], &lbf[spos+15*qdim],
                     &lbf[spos+16*qdim], &lbf[spos+1*qdim], &lbf[spos+21*qdim], &lbf[spos+22*qdim],
                     &lbf[spos+5*qdim], &lbf[spos+17*qdim], &lbf[spos+7*qdim], &lbf[spos+19*qdim],
                     &lbf[spos+13*qdim], &lbf[spos+23*qdim], &lbf[spos+12*qdim], &lbf[spos+24*qdim],
                     &lbf[spos+2*qdim], &lbf[spos+3*qdim], &lbf[spos+14*qdim], &lbf[spos+8*qdim],
                     &lbf[spos+9*qdim], &lbf[spos+18*qdim], &lbf[spos+4*qdim], &lbf[spos+20*qdim],
                     &lbf[spos+6*qdim], &lbf[spos+26*qdim], &lbf[spos+10*qdim], &lbf[spos+25*qdim],
                     &lbf[spos+11*qdim]);
      break;
    case CERB:
      fD3Q27CCEZouHe(p0, uwall[0], -uwall[2], uwall[1], &lbf[spos], &lbf[spos+1*qdim],
                     &lbf[spos+16*qdim], &lbf[spos+2*qdim], &lbf[spos+7*qdim], &lbf[spos+6*qdim],
                     &lbf[spos+4*qdim], &lbf[spos+5*qdim], &lbf[spos+9*qdim], &lbf[spos+21*qdim],
                     &lbf[spos+11*qdim], &lbf[spos+13*qdim], &lbf[spos+10*qdim], &lbf[spos+12*qdim],
                     &lbf[spos+14*qdim], &lbf[spos+3*qdim], &lbf[spos+15*qdim], &lbf[spos+20*qdim],
                     &lbf[spos+19*qdim], &lbf[spos+17*qdim], &lbf[spos+18*qdim], &lbf[spos+22*qdim],
                     &lbf[spos+8*qdim], &lbf[spos+24*qdim], &lbf[spos+26*qdim], &lbf[spos+23*qdim],
                     &lbf[spos+25*qdim]);
      break;
  }
  return 0;
}



int fD3Q27TPSZouHe(double p, double v0, double v1, double v2, double *f0, double *f1,
                   double *f2, double *f3, double *f4, double *f5, double *f6,
                   double *f7, double *f8, double *f9, double *f10, double *f11,
                   double *f12, double *f13, double *f14, double *f15, double *f16,
                   double *f17, double *f18, double *f19, double *f20, double *f21,
                   double *f22, double *f23, double *f24, double *f25, double *f26)
{

  // produce fixed temperature at planar surface: expressed for bottom wall

  double c1=5.0/9.0,c2=1.0/9.0,c3=1.0/36.0;
  f5[0]=f18[0]-c2*p*(v0-v1);
  f11[0]=p*(1.0-c1*v1)-f0[0]-f1[0]-f2[0]-f3[0]-f6[0]-f7[0]-f14[0]-f15[0]-f16[0]-f19[0]-f20[0]-2.0*(f4[0]+f8[0]+f9[0]+f10[0]+f11[0]+f18[0]+f25[0]+f26[0]);
  f12[0]=f25[0]-c3*p*(v0-v1+v2);
  f13[0]=f26[0]-c3*p*(v0-v1-v2);
  f17[0]=f4[0]+c2*p*(v0+v1);
  f21[0]=f8[0]+c2*p*(v1+v2);
  f22[0]=f9[0]+c2*p*(v1-v2);
  f23[0]=f10[0]+c3*p*(v0+v1+v2);
  f24[0]=f11[0]+c3*p*(v0+v1-v2);
  return 0;
}

int fD3Q27TCEZouHe(double p, double v0, double v1, double v2, double *f0, double *f1,
                   double *f2, double *f3, double *f4, double *f5, double *f6,
                   double *f7, double *f8, double *f9, double *f10, double *f11,
                   double *f12, double *f13, double *f14, double *f15, double *f16,
                   double *f17, double *f18, double *f19, double *f20, double *f21,
                   double *f22, double *f23, double *f24, double *f25, double *f26)
{

  // produce fixed temperature at concave edge: expressed for bottom left edge (TCETR)

  double q0, qxy, nz;
  double c1=4.0/9.0,c2=1.0/9.0,c3=1.0/36.0,c4=1.0/12.0,c5=1.0/72.0,c7=1.0/6.0,c8=5.0/72.0,c10=1.0/22.0,c11=1.0/44.0;

  q0 = c4*(p-f0[0]-f3[0]-f16[0])-c7*(f1[0]+f2[0]+f4[0]+f6[0]+f7[0]+f8[0]+f9[0]+f10[0]+f11[0])-c8*p*(v0+v1);
  qxy = c5*p*(v0-v1);
  nz = c10*(f16[0]-f3[0])-c11*p*v2;
  f5[0]=4.0*(q0-qxy);
  f12[0]=q0-qxy+nz;
  f13[0]=q0-qxy-nz;
  f14[0]=f1[0]+c1*p*v0;
  f15[0]=f2[0]+c1*p*v1;
  f17[0]=f4[0]+c2*p*(v0+v1);
  f18[0]=4.0*(q0+qxy);
  f19[0]=f6[0]+c2*p*(v0+v2)-4.0*nz;
  f20[0]=f7[0]+c2*p*(v0-v2)+4.0*nz;
  f21[0]=f8[0]+c2*p*(v1+v2)-4.0*nz;
  f22[0]=f9[0]+c2*p*(v1-v2)+4.0*nz;
  f23[0]=f10[0]+c3*p*(v0+v1+v2)-nz;
  f24[0]=f11[0]+c3*p*(v0+v1-v2)+nz;
  f25[0]=q0+qxy-nz;
  f26[0]=q0+qxy+nz;
  return 0;
}

int fD3Q27TCCZouHe(double p, double v0, double v1, double v2, double *f0, double *f1,
                   double *f2, double *f3, double *f4, double *f5, double *f6,
                   double *f7, double *f8, double *f9, double *f10, double *f11,
                   double *f12, double *f13, double *f14, double *f15, double *f16,
                   double *f17, double *f18, double *f19, double *f20, double *f21,
                   double *f22, double *f23, double *f24, double *f25, double *f26)
{

  // produce fixed temperature at concave corner: expressed for bottom left back corner (TCCTRF)

  double q0, qx, qy, qz;
  double c1=4.0/9.0,c2=1.0/9.0,c3=1.0/36.0,c4=1.0/30.0,c5=1.0/72.0,c7=1.0/15.0,c8=5.0/216.0;

  q0 = c4*(p-f0[0])-c7*(f1[0]+f2[0]+f3[0]+f4[0]+f6[0]+f8[0]+f10[0])-c8*p*(v0+v1+v2);
  qx = c5*p*v0;
  qy = c5*p*v1;
  qz = c5*p*v2;
  f5[0]=4.0*(q0-qx+qy);
  f7[0]=4.0*(q0-qx+qz);
  f9[0]=4.0*(q0-qy+qz);
  f11[0]=q0-qx-qy+qz;
  f12[0]=q0-qx+qy-qz;
  f13[0]=q0-qx+qy+qz;
  f14[0]=f1[0]+c1*p*v0;
  f15[0]=f2[0]+c1*p*v1;
  f16[0]=f3[0]+c1*p*v2;
  f17[0]=f4[0]+c2*p*(v0+v1);
  f18[0]=4.0*(q0+qx-qy);
  f19[0]=f6[0]+c2*p*(v0+v2);
  f20[0]=4.0*(q0+qx-qz);
  f21[0]=f8[0]+c2*p*(v1+v2);
  f22[0]=4.0*(q0+qy-qz);
  f23[0]=f10[0]+c3*p*(v0+v1+v2);
  f24[0]=q0+qx+qx-qz;
  f25[0]=q0+qx-qy+qz;
  f26[0]=q0+qx-qy-qz;
  return 0;
}

int fD3Q27PTZouHe(long tpos, int prop, double p0, double *uwall)
{
  long spos=tpos * lbsitelength + (lbsy.nf + lbsy.nc);
  int qdim=lbsy.nf+lbsy.nc+lbsy.nt;
    
  switch (prop) {
    case PST:
      fD3Q27TPSZouHe(p0, uwall[0], uwall[1], uwall[2], &lbf[spos], &lbf[spos+1*qdim],
                     &lbf[spos+2*qdim], &lbf[spos+3*qdim], &lbf[spos+4*qdim], &lbf[spos+5*qdim], &lbf[spos+6*qdim],
                     &lbf[spos+7*qdim], &lbf[spos+8*qdim], &lbf[spos+9*qdim], &lbf[spos+10*qdim], &lbf[spos+11*qdim],
                     &lbf[spos+12*qdim], &lbf[spos+13*qdim], &lbf[spos+14*qdim], &lbf[spos+15*qdim], &lbf[spos+16*qdim],
                     &lbf[spos+17*qdim], &lbf[spos+18*qdim], &lbf[spos+19*qdim], &lbf[spos+20*qdim], &lbf[spos+21*qdim],
                     &lbf[spos+22*qdim], &lbf[spos+23*qdim], &lbf[spos+24*qdim], &lbf[spos+25*qdim], &lbf[spos+26*qdim]);
      break;
    case PSD:
      fD3Q27TPSZouHe(p0, -uwall[0], -uwall[1], -uwall[2], &lbf[spos], &lbf[spos+14*qdim],
                     &lbf[spos+15*qdim], &lbf[spos+16*qdim], &lbf[spos+17*qdim], &lbf[spos+18*qdim], &lbf[spos+19*qdim],
                     &lbf[spos+20*qdim], &lbf[spos+21*qdim], &lbf[spos+22*qdim], &lbf[spos+23*qdim], &lbf[spos+24*qdim],
                     &lbf[spos+25*qdim], &lbf[spos+26*qdim], &lbf[spos+1*qdim], &lbf[spos+2*qdim], &lbf[spos+3*qdim],
                     &lbf[spos+4*qdim], &lbf[spos+5*qdim], &lbf[spos+6*qdim], &lbf[spos+7*qdim], &lbf[spos+8*qdim],
                     &lbf[spos+9*qdim], &lbf[spos+10*qdim], &lbf[spos+11*qdim], &lbf[spos+12*qdim], &lbf[spos+13*qdim]);
      break;
    case PSL:
      fD3Q27TPSZouHe(p0, -uwall[2], -uwall[0], -uwall[1], &lbf[spos], &lbf[spos+16*qdim],
                     &lbf[spos+14*qdim], &lbf[spos+15*qdim], &lbf[spos+19*qdim], &lbf[spos+7*qdim], &lbf[spos+21*qdim],
                     &lbf[spos+9*qdim], &lbf[spos+17*qdim], &lbf[spos+18*qdim], &lbf[spos+23*qdim], &lbf[spos+25*qdim],
                     &lbf[spos+13*qdim], &lbf[spos+11*qdim], &lbf[spos+3*qdim], &lbf[spos+1*qdim], &lbf[spos+2*qdim],
                     &lbf[spos+6*qdim], &lbf[spos+20*qdim], &lbf[spos+8*qdim], &lbf[spos+22*qdim], &lbf[spos+4*qdim],
                     &lbf[spos+5*qdim], &lbf[spos+10*qdim], &lbf[spos+12*qdim], &lbf[spos+26*qdim], &lbf[spos+24*qdim]);
      break;
    case PSR:
      fD3Q27TPSZouHe(p0, uwall[2], uwall[0], uwall[1], &lbf[spos], &lbf[spos+3*qdim],
                     &lbf[spos+1*qdim], &lbf[spos+2*qdim], &lbf[spos+6*qdim], &lbf[spos+20*qdim], &lbf[spos+8*qdim],
                     &lbf[spos+22*qdim], &lbf[spos+4*qdim], &lbf[spos+5*qdim], &lbf[spos+10*qdim], &lbf[spos+12*qdim],
                     &lbf[spos+26*qdim], &lbf[spos+24*qdim], &lbf[spos+16*qdim], &lbf[spos+14*qdim], &lbf[spos+15*qdim],
                     &lbf[spos+19*qdim], &lbf[spos+7*qdim], &lbf[spos+21*qdim], &lbf[spos+9*qdim], &lbf[spos+17*qdim],
                     &lbf[spos+18*qdim], &lbf[spos+23*qdim], &lbf[spos+25*qdim], &lbf[spos+13*qdim], &lbf[spos+11*qdim]);
      break;
    case PSF:
      fD3Q27TPSZouHe(p0, -uwall[1], -uwall[2], -uwall[0], &lbf[spos], &lbf[spos+15*qdim],
                     &lbf[spos+16*qdim], &lbf[spos+14*qdim], &lbf[spos+21*qdim], &lbf[spos+22*qdim], &lbf[spos+17*qdim],
                     &lbf[spos+5*qdim], &lbf[spos+19*qdim], &lbf[spos+7*qdim], &lbf[spos+23*qdim], &lbf[spos+13*qdim],
                     &lbf[spos+24*qdim], &lbf[spos+12*qdim], &lbf[spos+2*qdim], &lbf[spos+3*qdim], &lbf[spos+1*qdim],
                     &lbf[spos+8*qdim], &lbf[spos+9*qdim], &lbf[spos+4*qdim], &lbf[spos+18*qdim], &lbf[spos+6*qdim],
                     &lbf[spos+20*qdim], &lbf[spos+10*qdim], &lbf[spos+26*qdim], &lbf[spos+11*qdim], &lbf[spos+25*qdim]);
      break;
    case PSB:
      fD3Q27TPSZouHe(p0, uwall[1], uwall[2], uwall[0], &lbf[spos], &lbf[spos+2*qdim],
                     &lbf[spos+3*qdim], &lbf[spos+1*qdim], &lbf[spos+8*qdim], &lbf[spos+9*qdim], &lbf[spos+4*qdim],
                     &lbf[spos+18*qdim], &lbf[spos+6*qdim], &lbf[spos+20*qdim], &lbf[spos+10*qdim], &lbf[spos+26*qdim],
                     &lbf[spos+11*qdim], &lbf[spos+25*qdim], &lbf[spos+15*qdim], &lbf[spos+16*qdim], &lbf[spos+14*qdim],
                     &lbf[spos+21*qdim], &lbf[spos+22*qdim], &lbf[spos+17*qdim], &lbf[spos+5*qdim], &lbf[spos+19*qdim],
                     &lbf[spos+7*qdim], &lbf[spos+23*qdim], &lbf[spos+13*qdim], &lbf[spos+24*qdim], &lbf[spos+12*qdim]);
      break;
    case CCTRB:
      fD3Q27TCCZouHe(p0, uwall[0], uwall[1], -uwall[2], &lbf[spos], &lbf[spos+1*qdim],
                     &lbf[spos+2*qdim], &lbf[spos+16*qdim], &lbf[spos+4*qdim], &lbf[spos+5*qdim],
                     &lbf[spos+7*qdim], &lbf[spos+6*qdim], &lbf[spos+9*qdim], &lbf[spos+8*qdim],
                     &lbf[spos+11*qdim], &lbf[spos+10*qdim], &lbf[spos+13*qdim], &lbf[spos+12*qdim],
                     &lbf[spos+14*qdim], &lbf[spos+15*qdim], &lbf[spos+3*qdim], &lbf[spos+17*qdim],
                     &lbf[spos+18*qdim], &lbf[spos+20*qdim], &lbf[spos+19*qdim], &lbf[spos+22*qdim],
                     &lbf[spos+21*qdim], &lbf[spos+24*qdim], &lbf[spos+23*qdim], &lbf[spos+26*qdim],
                     &lbf[spos+25*qdim]);
      break;
    case CCTLB:
      fD3Q27TCCZouHe(p0, -uwall[0], uwall[1], -uwall[2], &lbf[spos], &lbf[spos+14*qdim],
                     &lbf[spos+2*qdim], &lbf[spos+16*qdim], &lbf[spos+18*qdim], &lbf[spos+17*qdim],
                     &lbf[spos+19*qdim], &lbf[spos+20*qdim], &lbf[spos+9*qdim], &lbf[spos+8*qdim],
                     &lbf[spos+25*qdim], &lbf[spos+26*qdim], &lbf[spos+23*qdim], &lbf[spos+24*qdim],
                     &lbf[spos+1*qdim], &lbf[spos+15*qdim], &lbf[spos+3*qdim], &lbf[spos+5*qdim],
                     &lbf[spos+4*qdim], &lbf[spos+6*qdim], &lbf[spos+7*qdim], &lbf[spos+22*qdim],
                     &lbf[spos+21*qdim], &lbf[spos+12*qdim], &lbf[spos+13*qdim], &lbf[spos+10*qdim],
                     &lbf[spos+11*qdim]);
      break;
    case CCDLB:
      fD3Q27TCCZouHe(p0, -uwall[0], -uwall[1], -uwall[2], &lbf[spos], &lbf[spos+14*qdim],
                     &lbf[spos+15*qdim], &lbf[spos+16*qdim], &lbf[spos+17*qdim], &lbf[spos+18*qdim],
                     &lbf[spos+19*qdim], &lbf[spos+20*qdim], &lbf[spos+21*qdim], &lbf[spos+22*qdim],
                     &lbf[spos+23*qdim], &lbf[spos+24*qdim], &lbf[spos+25*qdim], &lbf[spos+26*qdim],
                     &lbf[spos+1*qdim], &lbf[spos+2*qdim], &lbf[spos+3*qdim], &lbf[spos+4*qdim],
                     &lbf[spos+5*qdim], &lbf[spos+6*qdim], &lbf[spos+7*qdim], &lbf[spos+8*qdim],
                     &lbf[spos+9*qdim], &lbf[spos+10*qdim], &lbf[spos+11*qdim], &lbf[spos+12*qdim],
                     &lbf[spos+13*qdim]);
      break;
    case CCDRB:
      fD3Q27TCCZouHe(p0, uwall[0], -uwall[1], -uwall[2], &lbf[spos], &lbf[spos+1*qdim],
                     &lbf[spos+15*qdim], &lbf[spos+16*qdim], &lbf[spos+5*qdim], &lbf[spos+4*qdim],
                     &lbf[spos+7*qdim], &lbf[spos+6*qdim], &lbf[spos+21*qdim], &lbf[spos+22*qdim],
                     &lbf[spos+13*qdim], &lbf[spos+12*qdim], &lbf[spos+11*qdim], &lbf[spos+10*qdim],
                     &lbf[spos+14*qdim], &lbf[spos+2*qdim], &lbf[spos+3*qdim], &lbf[spos+18*qdim],
                     &lbf[spos+17*qdim], &lbf[spos+20*qdim], &lbf[spos+19*qdim], &lbf[spos+8*qdim],
                     &lbf[spos+9*qdim], &lbf[spos+26*qdim], &lbf[spos+25*qdim], &lbf[spos+24*qdim],
                     &lbf[spos+23*qdim]);
      break;
    case CCTRF:
      fD3Q27TCCZouHe(p0, uwall[0], uwall[1], uwall[2], &lbf[spos], &lbf[spos+1*qdim],
                     &lbf[spos+2*qdim], &lbf[spos+3*qdim], &lbf[spos+4*qdim], &lbf[spos+5*qdim],
                     &lbf[spos+6*qdim], &lbf[spos+7*qdim], &lbf[spos+8*qdim], &lbf[spos+9*qdim],
                     &lbf[spos+10*qdim], &lbf[spos+11*qdim], &lbf[spos+12*qdim], &lbf[spos+13*qdim],
                     &lbf[spos+14*qdim], &lbf[spos+15*qdim], &lbf[spos+16*qdim], &lbf[spos+17*qdim],
                     &lbf[spos+18*qdim], &lbf[spos+19*qdim], &lbf[spos+20*qdim], &lbf[spos+21*qdim],
                     &lbf[spos+22*qdim], &lbf[spos+23*qdim], &lbf[spos+24*qdim], &lbf[spos+25*qdim],
                     &lbf[spos+26*qdim]);
      break;
    case CCTLF:
      fD3Q27TCCZouHe(p0, -uwall[0], uwall[1], uwall[2], &lbf[spos], &lbf[spos+14*qdim],
                     &lbf[spos+2*qdim], &lbf[spos+3*qdim], &lbf[spos+18*qdim], &lbf[spos+17*qdim],
                     &lbf[spos+20*qdim], &lbf[spos+19*qdim], &lbf[spos+8*qdim], &lbf[spos+9*qdim],
                     &lbf[spos+26*qdim], &lbf[spos+25*qdim], &lbf[spos+24*qdim], &lbf[spos+23*qdim],
                     &lbf[spos+1*qdim], &lbf[spos+15*qdim], &lbf[spos+16*qdim], &lbf[spos+5*qdim],
                     &lbf[spos+4*qdim], &lbf[spos+7*qdim], &lbf[spos+6*qdim], &lbf[spos+21*qdim],
                     &lbf[spos+22*qdim], &lbf[spos+13*qdim], &lbf[spos+12*qdim], &lbf[spos+11*qdim],
                     &lbf[spos+10*qdim]);
      break;
    case CCDLF:
      fD3Q27TCCZouHe(p0, -uwall[0], -uwall[1], uwall[2], &lbf[spos], &lbf[spos+14*qdim],
                     &lbf[spos+15*qdim], &lbf[spos+3*qdim], &lbf[spos+17*qdim], &lbf[spos+18*qdim],
                     &lbf[spos+20*qdim], &lbf[spos+19*qdim], &lbf[spos+22*qdim], &lbf[spos+21*qdim],
                     &lbf[spos+24*qdim], &lbf[spos+23*qdim], &lbf[spos+26*qdim], &lbf[spos+25*qdim],
                     &lbf[spos+1*qdim], &lbf[spos+2*qdim], &lbf[spos+16*qdim], &lbf[spos+4*qdim],
                     &lbf[spos+5*qdim], &lbf[spos+7*qdim], &lbf[spos+6*qdim], &lbf[spos+9*qdim],
                     &lbf[spos+8*qdim], &lbf[spos+11*qdim], &lbf[spos+10*qdim], &lbf[spos+13*qdim],
                     &lbf[spos+12*qdim]);
      break;
    case CCDRF:
      fD3Q27TCCZouHe(p0, uwall[0], -uwall[1], uwall[2], &lbf[spos], &lbf[spos+1*qdim],
                     &lbf[spos+15*qdim], &lbf[spos+3*qdim], &lbf[spos+5*qdim], &lbf[spos+4*qdim],
                     &lbf[spos+6*qdim], &lbf[spos+7*qdim], &lbf[spos+22*qdim], &lbf[spos+21*qdim],
                     &lbf[spos+12*qdim], &lbf[spos+13*qdim], &lbf[spos+10*qdim], &lbf[spos+11*qdim],
                     &lbf[spos+14*qdim], &lbf[spos+2*qdim], &lbf[spos+16*qdim], &lbf[spos+18*qdim],
                     &lbf[spos+17*qdim], &lbf[spos+19*qdim], &lbf[spos+20*qdim], &lbf[spos+9*qdim],
                     &lbf[spos+8*qdim], &lbf[spos+25*qdim], &lbf[spos+26*qdim], &lbf[spos+23*qdim],
                     &lbf[spos+24*qdim]);
      break;
    case CETR:
      fD3Q27TCEZouHe(p0, uwall[0], uwall[1], uwall[2], &lbf[spos], &lbf[spos+1*qdim],
                     &lbf[spos+2*qdim], &lbf[spos+3*qdim], &lbf[spos+4*qdim], &lbf[spos+5*qdim],
                     &lbf[spos+6*qdim], &lbf[spos+7*qdim], &lbf[spos+8*qdim], &lbf[spos+9*qdim],
                     &lbf[spos+10*qdim], &lbf[spos+11*qdim], &lbf[spos+12*qdim], &lbf[spos+13*qdim],
                     &lbf[spos+14*qdim], &lbf[spos+15*qdim], &lbf[spos+16*qdim], &lbf[spos+17*qdim],
                     &lbf[spos+18*qdim], &lbf[spos+19*qdim], &lbf[spos+20*qdim], &lbf[spos+21*qdim],
                     &lbf[spos+22*qdim], &lbf[spos+23*qdim], &lbf[spos+24*qdim], &lbf[spos+25*qdim],
                     &lbf[spos+26*qdim]);
      break;
    case CETL:
      fD3Q27TCEZouHe(p0, uwall[1], -uwall[0], uwall[2], &lbf[spos], &lbf[spos+2*qdim],
                     &lbf[spos+14*qdim], &lbf[spos+3*qdim], &lbf[spos+18*qdim], &lbf[spos+4*qdim],
                     &lbf[spos+8*qdim], &lbf[spos+9*qdim], &lbf[spos+20*qdim], &lbf[spos+19*qdim],
                     &lbf[spos+26*qdim], &lbf[spos+25*qdim], &lbf[spos+10*qdim], &lbf[spos+11*qdim],
                     &lbf[spos+15*qdim], &lbf[spos+1*qdim], &lbf[spos+16*qdim], &lbf[spos+5*qdim],
                     &lbf[spos+17*qdim], &lbf[spos+21*qdim], &lbf[spos+22*qdim], &lbf[spos+7*qdim],
                     &lbf[spos+6*qdim], &lbf[spos+13*qdim], &lbf[spos+12*qdim], &lbf[spos+23*qdim],
                     &lbf[spos+24*qdim]);
      break;
    case CEDL:
      fD3Q27TCEZouHe(p0, -uwall[0], -uwall[1], uwall[2], &lbf[spos], &lbf[spos+14*qdim],
                     &lbf[spos+15*qdim], &lbf[spos+3*qdim], &lbf[spos+17*qdim], &lbf[spos+18*qdim],
                     &lbf[spos+20*qdim], &lbf[spos+19*qdim], &lbf[spos+22*qdim], &lbf[spos+21*qdim],
                     &lbf[spos+24*qdim], &lbf[spos+23*qdim], &lbf[spos+26*qdim], &lbf[spos+25*qdim],
                     &lbf[spos+1*qdim], &lbf[spos+2*qdim], &lbf[spos+16*qdim], &lbf[spos+4*qdim],
                     &lbf[spos+5*qdim], &lbf[spos+7*qdim], &lbf[spos+6*qdim], &lbf[spos+9*qdim],
                     &lbf[spos+8*qdim], &lbf[spos+11*qdim], &lbf[spos+10*qdim], &lbf[spos+13*qdim],
                     &lbf[spos+12*qdim]);
      break;
    case CEDR:
      fD3Q27TCEZouHe(p0, -uwall[1], uwall[0], uwall[2], &lbf[spos], &lbf[spos+15*qdim],
                     &lbf[spos+1*qdim], &lbf[spos+3*qdim], &lbf[spos+5*qdim], &lbf[spos+17*qdim],
                     &lbf[spos+22*qdim], &lbf[spos+21*qdim], &lbf[spos+6*qdim], &lbf[spos+7*qdim],
                     &lbf[spos+12*qdim], &lbf[spos+13*qdim], &lbf[spos+24*qdim], &lbf[spos+23*qdim],
                     &lbf[spos+2*qdim], &lbf[spos+14*qdim], &lbf[spos+16*qdim], &lbf[spos+18*qdim],
                     &lbf[spos+4*qdim], &lbf[spos+9*qdim], &lbf[spos+8*qdim], &lbf[spos+19*qdim],
                     &lbf[spos+20*qdim], &lbf[spos+25*qdim], &lbf[spos+26*qdim], &lbf[spos+11*qdim],
                     &lbf[spos+10*qdim]);
      break;
    case CETF:
      fD3Q27TCEZouHe(p0, uwall[1], uwall[2], uwall[0], &lbf[spos], &lbf[spos+2*qdim],
                     &lbf[spos+3*qdim], &lbf[spos+1*qdim], &lbf[spos+8*qdim], &lbf[spos+9*qdim],
                     &lbf[spos+4*qdim], &lbf[spos+18*qdim], &lbf[spos+6*qdim], &lbf[spos+20*qdim],
                     &lbf[spos+10*qdim], &lbf[spos+26*qdim], &lbf[spos+11*qdim], &lbf[spos+25*qdim],
                     &lbf[spos+15*qdim], &lbf[spos+16*qdim], &lbf[spos+14*qdim], &lbf[spos+21*qdim],
                     &lbf[spos+22*qdim], &lbf[spos+17*qdim], &lbf[spos+5*qdim], &lbf[spos+19*qdim],
                     &lbf[spos+7*qdim], &lbf[spos+23*qdim], &lbf[spos+13*qdim], &lbf[spos+24*qdim],
                     &lbf[spos+12*qdim]);
      break;
    case CELF:
      fD3Q27TCEZouHe(p0, -uwall[0], uwall[1], uwall[2], &lbf[spos], &lbf[spos+14*qdim],
                     &lbf[spos+3*qdim], &lbf[spos+2*qdim], &lbf[spos+20*qdim], &lbf[spos+19*qdim],
                     &lbf[spos+18*qdim], &lbf[spos+17*qdim], &lbf[spos+8*qdim], &lbf[spos+22*qdim],
                     &lbf[spos+26*qdim], &lbf[spos+24*qdim], &lbf[spos+25*qdim], &lbf[spos+23*qdim],
                     &lbf[spos+1*qdim], &lbf[spos+16*qdim], &lbf[spos+15*qdim], &lbf[spos+7*qdim],
                     &lbf[spos+6*qdim], &lbf[spos+5*qdim], &lbf[spos+4*qdim], &lbf[spos+21*qdim],
                     &lbf[spos+9*qdim], &lbf[spos+13*qdim], &lbf[spos+11*qdim], &lbf[spos+12*qdim],
                     &lbf[spos+10*qdim]);
      break;
    case CEDF:
      fD3Q27TCEZouHe(p0, -uwall[1], uwall[2], uwall[0], &lbf[spos], &lbf[spos+15*qdim],
                     &lbf[spos+3*qdim], &lbf[spos+1*qdim], &lbf[spos+22*qdim], &lbf[spos+21*qdim],
                     &lbf[spos+5*qdim], &lbf[spos+17*qdim], &lbf[spos+6*qdim], &lbf[spos+20*qdim],
                     &lbf[spos+12*qdim], &lbf[spos+24*qdim], &lbf[spos+13*qdim], &lbf[spos+23*qdim],
                     &lbf[spos+2*qdim], &lbf[spos+16*qdim], &lbf[spos+14*qdim], &lbf[spos+9*qdim],
                     &lbf[spos+8*qdim], &lbf[spos+18*qdim], &lbf[spos+4*qdim], &lbf[spos+19*qdim],
                     &lbf[spos+7*qdim], &lbf[spos+25*qdim], &lbf[spos+11*qdim], &lbf[spos+26*qdim],
                     &lbf[spos+10*qdim]);
      break;
    case CERF:
      fD3Q27TCEZouHe(p0, uwall[0], uwall[2], uwall[2], &lbf[spos], &lbf[spos+1*qdim],
                     &lbf[spos+3*qdim], &lbf[spos+2*qdim], &lbf[spos+6*qdim], &lbf[spos+7*qdim],
                     &lbf[spos+4*qdim], &lbf[spos+5*qdim], &lbf[spos+8*qdim], &lbf[spos+22*qdim],
                     &lbf[spos+10*qdim], &lbf[spos+12*qdim], &lbf[spos+11*qdim], &lbf[spos+13*qdim],
                     &lbf[spos+14*qdim], &lbf[spos+16*qdim], &lbf[spos+15*qdim], &lbf[spos+19*qdim],
                     &lbf[spos+20*qdim], &lbf[spos+17*qdim], &lbf[spos+18*qdim], &lbf[spos+21*qdim],
                     &lbf[spos+9*qdim], &lbf[spos+23*qdim], &lbf[spos+25*qdim], &lbf[spos+24*qdim],
                     &lbf[spos+26*qdim]);
      break;
    case CETB:
      fD3Q27TCEZouHe(p0, uwall[1], -uwall[2], uwall[0], &lbf[spos], &lbf[spos+2*qdim],
                     &lbf[spos+16*qdim], &lbf[spos+1*qdim], &lbf[spos+9*qdim], &lbf[spos+8*qdim],
                     &lbf[spos+4*qdim], &lbf[spos+18*qdim], &lbf[spos+7*qdim], &lbf[spos+19*qdim],
                     &lbf[spos+11*qdim], &lbf[spos+25*qdim], &lbf[spos+10*qdim], &lbf[spos+26*qdim],
                     &lbf[spos+15*qdim], &lbf[spos+3*qdim], &lbf[spos+14*qdim], &lbf[spos+22*qdim],
                     &lbf[spos+21*qdim], &lbf[spos+17*qdim], &lbf[spos+5*qdim], &lbf[spos+20*qdim],
                     &lbf[spos+6*qdim], &lbf[spos+24*qdim], &lbf[spos+12*qdim], &lbf[spos+23*qdim],
                     &lbf[spos+13*qdim]);
      break;
    case CELB:
      fD3Q27TCEZouHe(p0, -uwall[0], -uwall[2], uwall[1], &lbf[spos], &lbf[spos+14*qdim],
                     &lbf[spos+16*qdim], &lbf[spos+2*qdim], &lbf[spos+19*qdim], &lbf[spos+20*qdim],
                     &lbf[spos+18*qdim], &lbf[spos+17*qdim], &lbf[spos+9*qdim], &lbf[spos+21*qdim],
                     &lbf[spos+25*qdim], &lbf[spos+23*qdim], &lbf[spos+26*qdim], &lbf[spos+24*qdim],
                     &lbf[spos+1*qdim], &lbf[spos+3*qdim], &lbf[spos+15*qdim], &lbf[spos+6*qdim],
                     &lbf[spos+7*qdim], &lbf[spos+5*qdim], &lbf[spos+4*qdim], &lbf[spos+22*qdim],
                     &lbf[spos+8*qdim], &lbf[spos+12*qdim], &lbf[spos+10*qdim], &lbf[spos+13*qdim],
                     &lbf[spos+11*qdim]);
      break;
    case CEDB:
      fD3Q27TCEZouHe(p0, -uwall[1], -uwall[2], uwall[0], &lbf[spos], &lbf[spos+15*qdim],
                     &lbf[spos+16*qdim], &lbf[spos+1*qdim], &lbf[spos+21*qdim], &lbf[spos+22*qdim],
                     &lbf[spos+5*qdim], &lbf[spos+17*qdim], &lbf[spos+7*qdim], &lbf[spos+19*qdim],
                     &lbf[spos+13*qdim], &lbf[spos+23*qdim], &lbf[spos+12*qdim], &lbf[spos+24*qdim],
                     &lbf[spos+2*qdim], &lbf[spos+3*qdim], &lbf[spos+14*qdim], &lbf[spos+8*qdim],
                     &lbf[spos+9*qdim], &lbf[spos+18*qdim], &lbf[spos+4*qdim], &lbf[spos+20*qdim],
                     &lbf[spos+6*qdim], &lbf[spos+26*qdim], &lbf[spos+10*qdim], &lbf[spos+25*qdim],
                     &lbf[spos+11*qdim]);
      break;
    case CERB:
      fD3Q27TCEZouHe(p0, uwall[0], -uwall[2], uwall[1], &lbf[spos], &lbf[spos+1*qdim],
                     &lbf[spos+16*qdim], &lbf[spos+2*qdim], &lbf[spos+7*qdim], &lbf[spos+6*qdim],
                     &lbf[spos+4*qdim], &lbf[spos+5*qdim], &lbf[spos+9*qdim], &lbf[spos+21*qdim],
                     &lbf[spos+11*qdim], &lbf[spos+13*qdim], &lbf[spos+10*qdim], &lbf[spos+12*qdim],
                     &lbf[spos+14*qdim], &lbf[spos+3*qdim], &lbf[spos+15*qdim], &lbf[spos+20*qdim],
                     &lbf[spos+19*qdim], &lbf[spos+17*qdim], &lbf[spos+18*qdim], &lbf[spos+22*qdim],
                     &lbf[spos+8*qdim], &lbf[spos+24*qdim], &lbf[spos+26*qdim], &lbf[spos+23*qdim],
                     &lbf[spos+25*qdim]);
      break;
  }
  return 0;  
}


