/***************************************************
 *   DL_MESO       Version 2.7                     *
 *   Authors   :   R. S. Qin, M. A. Seaton         *
 *   Copyright :   UKRI STFC Daresbury Laboratory  *
 *             :   09/12/2018                      *
 ***************************************************/

int fOutputLegacyVTK(const char* filename="lbout")
{
  // output .vtk file with properties for all fluids

  int iprop;
  char buf[80];
  int numberOfPoints,numberOfPointsAll;
  int start[3], end[3], startall[3], endall[3], length[3];
  int* intScalarBuffer;
  float* scalarBuffer;
  float* vectorBuffer;
  ofstream file;
  stringstream sstm;
  string header,footer;
  unsigned long headersize,footersize,startpos;
    
  // find extent and number of points for I/O group
  fGroupPieceRangeLocal(start,end);
  if(!lbmpiio) {
    startall[0] = start[0];
    startall[1] = start[1];
    startall[2] = start[2];
    endall[0] = end[0];
    endall[1] = end[1];
    endall[2] = end[2];
  }
  else {
    startall[0] = startall[1] = lbdm.bwid;
    startall[2] = (lbsy.nd==3)?lbdm.bwid:0;
    endall[0] = lbsy.nx+lbdm.bwid;
    endall[1] = lbsy.ny+lbdm.bwid;
    endall[2] = (lbsy.nd==3)?(lbsy.nz+lbdm.bwid):1;
  }
  numberOfPoints = fGroupPieceDataPoints(length);
  numberOfPointsAll = (lbmpiio)?lbsy.nx*lbsy.ny*lbsy.nz:numberOfPoints;

  // open file if root process for I/O group
  if(lbIOGroup.rank==0) {
    if(!lbmpiio && lbdm.size>lbIOGroup.size)
      sprintf(buf, "%s%.6dat%.6d.vtk", filename, lbIOGroup.groupId, qVersion);
    else
      sprintf(buf, "%s%.6d.vtk", filename, qVersion);
  }
  fOpenOutputBinaryFile(buf, file);
    
  sstm.str(string());
  // write file header
  if((!lbmpiio && lbIOGroup.rank==0) || (lbmpiio && lbIOGroup.groupId==0)) {
    sstm<<"# vtk DataFile Version 3.0\n";
    sstm<<"DL_MESO_LBE\n";
    sstm<<"BINARY\n";
    sstm<<"DATASET STRUCTURED_GRID\n";
    sstm<<"DIMENSIONS  "<<(endall[0]-startall[0])<<"  "<<(endall[1]-startall[1])<<"  "<<(endall[2]-startall[2])<<"\n";
    sstm<<"POINTS  "<<numberOfPointsAll<<"  float\n";
  }
  header = sstm.str();
  headersize = header.length();
  footer = "";
  footersize = 0;
  startpos = 0;
    
  // allocate buffers for collecting data

  scalarBuffer = (float*)malloc(numberOfPoints*sizeof(float));
  vectorBuffer = (float*)malloc(3*numberOfPoints*sizeof(float));
  intScalarBuffer = (int*)malloc(numberOfPoints*sizeof(int));

  // collect and write grid points
    
  fGroupGridPoints(vectorBuffer, start, end, !bigend);
  fWriteLegacyVTKFloatBinaryData(vectorBuffer, 3*numberOfPoints, startpos, header.c_str(), footer.c_str(), headersize, footersize, file);

  // collect and write densities
    
  for(iprop=0; iprop<lbsy.nf; iprop++) {
    sstm.str(string());
    if((!lbmpiio && lbIOGroup.rank==0) || (lbmpiio && lbIOGroup.groupId==0)) {
      if(iprop==0) sstm<<"POINT_DATA  "<<numberOfPointsAll<<"\n";
      sstm<<"SCALARS density_"<<iprop<<" float"<<"\n";
      if(iprop==0) sstm<<"LOOKUP_TABLE default\n";
    }
    header = sstm.str();
    headersize = header.length();
    fGroupDensities(scalarBuffer, start, end, iprop, !bigend);
    fWriteLegacyVTKFloatBinaryData(scalarBuffer, numberOfPoints, startpos, header.c_str(), footer.c_str(), headersize, footersize, file);
  }
    
  // collect and write mass fractions
    
  for(iprop=0; iprop<lbsy.nf; iprop++) {
    sstm.str(string());
    if((!lbmpiio && lbIOGroup.rank==0) || (lbmpiio && lbIOGroup.groupId==0)) {
      sstm<<"SCALARS fraction_"<<iprop<<" float\n";
    }
    header = sstm.str();
    headersize = header.length();
    fGroupMassFractions(scalarBuffer, start, end, iprop, !bigend);
    fWriteLegacyVTKFloatBinaryData(scalarBuffer, numberOfPoints, startpos, header.c_str(), footer.c_str(), headersize, footersize, file);
  }
    
  // collect and write solute concentrations

  for(iprop=0; iprop<lbsy.nc; iprop++) {
    sstm.str(string());
    if((!lbmpiio && lbIOGroup.rank==0) || (lbmpiio && lbIOGroup.groupId==0)) {
      sstm<<"SCALARS concentration_"<<iprop<<" float\n";
    }
    header = sstm.str();
    headersize = header.length();
    fGroupSoluteConcentrations(scalarBuffer, start, end, iprop, !bigend);
    fWriteLegacyVTKFloatBinaryData(scalarBuffer, numberOfPoints, startpos, header.c_str(), footer.c_str(), headersize, footersize, file);
  }
    
  // collect and write temperatures
    
  if(lbsy.nt==1) {
    sstm.str(string());
    if((!lbmpiio && lbIOGroup.rank==0) || (lbmpiio && lbIOGroup.groupId==0)) {
      sstm<<"SCALARS temperature float\n";
    }
    header = sstm.str();
    headersize = header.length();
    fGroupTemperatures(scalarBuffer, start, end, !bigend);
    fWriteLegacyVTKFloatBinaryData(scalarBuffer, numberOfPoints, startpos, header.c_str(), footer.c_str(), headersize, footersize, file);
  }
    
  // collect and write velocities

  sstm.str(string());
  if((!lbmpiio && lbIOGroup.rank==0) || (lbmpiio && lbIOGroup.groupId==0)) {
    sstm<<"VECTORS velocity float\n";
  }
  header = sstm.str();
  headersize = header.length();
  fGroupVelocities(vectorBuffer, start, end, !bigend);
  fWriteLegacyVTKFloatBinaryData(vectorBuffer, 3*numberOfPoints, startpos, header.c_str(), footer.c_str(), headersize, footersize, file);
    
  // collect and write phase field/space property

  sstm.str(string());
  if((!lbmpiio && lbIOGroup.rank==0) || (lbmpiio && lbIOGroup.groupId==0)) {
    sstm<<"SCALARS phase_field int\n";
    sstm<<"LOOKUP_TABLE default\n";
  }
  header = sstm.str();
  headersize = header.length();
  
  fGroupPhaseField(intScalarBuffer, start, end, !bigend);
  fWriteLegacyVTKIntegerBinaryData(intScalarBuffer, numberOfPoints, startpos, header.c_str(), footer.c_str(), headersize, footersize, file);

  // close file and deallocate buffers

  fCloseOutputBinaryFile(file);

  free(scalarBuffer);
  free(vectorBuffer);
  free(intScalarBuffer);
  
  return 0;
}

int fsOutputLegacyVTK(const char* filename="lbout")
{
  int iprop;
  char buf[80];
  int numberOfPoints,numberOfPointsAll;
  int start[3], end[3], startall[3], endall[3], length[3];
  int* intScalarBuffer;
  float* scalarBuffer;
  float* vectorBuffer;
  ofstream file;
  stringstream sstm;
  string header,footer;
  unsigned long headersize,footersize,startpos;
    
  // find extent and number of points for I/O group
  fGroupPieceRangeLocal(start,end);
  if(!lbmpiio) {
    startall[0] = start[0];
    startall[1] = start[1];
    startall[2] = start[2];
    endall[0] = end[0];
    endall[1] = end[1];
    endall[2] = end[2];
  }
  else {
    startall[0] = startall[1] = lbdm.bwid;
    startall[2] = (lbsy.nd==3)?lbdm.bwid:0;
    endall[0] = lbsy.nx+lbdm.bwid;
    endall[1] = lbsy.ny+lbdm.bwid;
    endall[2] = (lbsy.nd==3)?(lbsy.nz+lbdm.bwid):1;
  }
  numberOfPoints = fGroupPieceDataPoints(length);
  numberOfPointsAll = (lbmpiio)?lbsy.nx*lbsy.ny*lbsy.nz:numberOfPoints;

  // open file if root process for I/O group
  if(lbIOGroup.rank==0) {
    if(!lbmpiio && lbdm.size>lbIOGroup.size)
      sprintf(buf, "%s%.6dat%.6d.vtk", filename, lbIOGroup.groupId, qVersion);
    else
      sprintf(buf, "%s%.6d.vtk", filename, qVersion);
  }
  fOpenOutputANSIFile(buf, file);
    
    
  sstm.str(string());
  // write file header (with opening tags for grid points)
  if((!lbmpiio && lbIOGroup.rank==0) || (lbmpiio && lbIOGroup.groupId==0)) {
    // write file header
    sstm<<"# vtk DataFile Version 3.0\n";
    sstm<<"DL_MESO_LBE\n";
    sstm<<"ASCII\n";
    sstm<<"DATASET STRUCTURED_GRID\n";
    sstm<<"DIMENSIONS  "<<(endall[0]-startall[0])<<"  "<<(endall[1]-startall[1])<<"  "<<(endall[2]-startall[2])<<"\n";
    sstm<<"POINTS  "<<numberOfPointsAll<<"  float\n";
  }
  header = sstm.str();
  headersize = header.length();
  footer = "";
  footersize = 0;
  startpos = 0;

  // allocate buffers for collecting data

  scalarBuffer = (float*)malloc(numberOfPoints*sizeof(float));
  vectorBuffer = (float*)malloc(3*numberOfPoints*sizeof(float));
  intScalarBuffer = (int*)malloc(numberOfPoints*sizeof(int));

  // collect and write grid points
    
  fGroupGridPoints(vectorBuffer, start, end, false);
  fWriteLegacyVTKFloatANSIData(vectorBuffer, 3*numberOfPoints, true, startpos, header.c_str(), footer.c_str(), headersize, footersize, file);
    
  // collect and write densities
    
  for(iprop=0; iprop<lbsy.nf; iprop++) {
    sstm.str(string());
    if((!lbmpiio && lbIOGroup.rank==0) || (lbmpiio && lbIOGroup.groupId==0)) {
      if(iprop==0) sstm<<"POINT_DATA  "<<numberOfPointsAll<<"\n";
      sstm<<"SCALARS density_"<<iprop<<" float\n";
      if(iprop==0) sstm<<"LOOKUP_TABLE default\n";
    }
    header = sstm.str();
    headersize = header.length();
    fGroupDensities(scalarBuffer, start, end, iprop, false);
    fWriteLegacyVTKFloatANSIData(scalarBuffer, numberOfPoints, false, startpos, header.c_str(), footer.c_str(), headersize, footersize, file);
  }
    
  // collect and write mass fractions
    
  for(iprop=0; iprop<lbsy.nf; iprop++) {
    sstm.str(string());
    if((!lbmpiio && lbIOGroup.rank==0) || (lbmpiio && lbIOGroup.groupId==0)) {
      sstm<<"SCALARS fraction_"<<iprop<<" float\n";
    }
    header = sstm.str();
    headersize = header.length();
    fGroupMassFractions(scalarBuffer, start, end, iprop, false);
    fWriteLegacyVTKFloatANSIData(scalarBuffer, numberOfPoints, false, startpos, header.c_str(), footer.c_str(), headersize, footersize, file);
  }
    
  // collect and write solute concentrations

  for(iprop=0; iprop<lbsy.nc; iprop++) {
    sstm.str(string());
    if((!lbmpiio && lbIOGroup.rank==0) || (lbmpiio && lbIOGroup.groupId==0)) {
      sstm<<"SCALARS concentration_"<<iprop<<" float\n";
    }
    header = sstm.str();
    headersize = header.length();
    fGroupSoluteConcentrations(scalarBuffer, start, end, iprop, false);
    fWriteLegacyVTKFloatANSIData(scalarBuffer, numberOfPoints, false, startpos, header.c_str(), footer.c_str(), headersize, footersize, file);
  }
    
  // collect and write temperatures
    
  if(lbsy.nt==1) {
    sstm.str(string());
    if((!lbmpiio && lbIOGroup.rank==0) || (lbmpiio && lbIOGroup.groupId==0)) {
      sstm<<"SCALARS temperature float\n";
    }
    header = sstm.str();
    headersize = header.length();
    fGroupTemperatures(scalarBuffer, start, end, false);
    fWriteLegacyVTKFloatANSIData(scalarBuffer, numberOfPoints, false, startpos, header.c_str(), footer.c_str(), headersize, footersize, file);
  }
    
  // collect and write velocities

  sstm.str(string());
  if((!lbmpiio && lbIOGroup.rank==0) || (lbmpiio && lbIOGroup.groupId==0)) {
    sstm<<"VECTORS velocity float"<<endl;
  }
  header = sstm.str();
  headersize = header.length();
  fGroupVelocities(vectorBuffer, start, end, false);
  fWriteLegacyVTKFloatANSIData(vectorBuffer, 3*numberOfPoints, true, startpos, header.c_str(), footer.c_str(), headersize, footersize, file);
    
  // collect and write phase field/space property

  sstm.str(string());
  if((!lbmpiio && lbIOGroup.rank==0) || (lbmpiio && lbIOGroup.groupId==0)) {
    sstm<<"SCALARS phase_field int\n";
    sstm<<"LOOKUP_TABLE default\n";
  }
  header = sstm.str();
  headersize = header.length();
  fGroupPhaseField(intScalarBuffer, start, end, false);
  fWriteLegacyVTKIntegerANSIData(intScalarBuffer, numberOfPoints, false, startpos, header.c_str(), footer.c_str(), headersize, footersize, file);

  // close file and deallocate buffers
                   
  fCloseOutputANSIFile(file);

  free(scalarBuffer);
  free(vectorBuffer);
  free(intScalarBuffer);
    
  return 0;
}


int fOutputLegacyVTKP(const char* filename="lbout", int iprop=0)
{

  // output .vtk file with macroscopic mass density and velocity for fluid iprop

  char buf[80];
  int numberOfPoints,numberOfPointsAll;
  int start[3], end[3], startall[3], endall[3], length[3];
  int* intScalarBuffer;
  float* scalarBuffer;
  float* vectorBuffer;
  ofstream file;
  stringstream sstm;
  string header,footer;
  unsigned long headersize,footersize,startpos;
    
  // find extent and number of points for I/O group
  fGroupPieceRangeLocal(start,end);
  if(!lbmpiio) {
    startall[0] = start[0];
    startall[1] = start[1];
    startall[2] = start[2];
    endall[0] = end[0];
    endall[1] = end[1];
    endall[2] = end[2];
  }
  else {
    startall[0] = startall[1] = lbdm.bwid;
    startall[2] = (lbsy.nd==3)?lbdm.bwid:0;
    endall[0] = lbsy.nx+lbdm.bwid;
    endall[1] = lbsy.ny+lbdm.bwid;
    endall[2] = (lbsy.nd==3)?(lbsy.nz+lbdm.bwid):1;
  }
  numberOfPoints = fGroupPieceDataPoints(length);
  numberOfPointsAll = (lbmpiio)?lbsy.nx*lbsy.ny*lbsy.nz:numberOfPoints;

  // open file if root process for I/O group
  if(lbIOGroup.rank==0) {
    if(!lbmpiio && lbdm.size>lbIOGroup.size)
      sprintf(buf, "%s%.6dat%.6d.vtk", filename, lbIOGroup.groupId, qVersion);
    else
      sprintf(buf, "%s%.6d.vtk", filename, qVersion);
  }
  fOpenOutputBinaryFile(buf, file);
    
  sstm.str(string());
  // write file header
  if((!lbmpiio && lbIOGroup.rank==0) || (lbmpiio && lbIOGroup.groupId==0)) {
    sstm<<"# vtk DataFile Version 3.0\n";
    sstm<<"DL_MESO_LBE\n";
    sstm<<"BINARY\n";
    sstm<<"DATASET STRUCTURED_GRID\n";
    sstm<<"DIMENSIONS  "<<(endall[0]-startall[0])<<"  "<<(endall[1]-startall[1])<<"  "<<(endall[2]-startall[2])<<"\n";
    sstm<<"POINTS  "<<numberOfPointsAll<<"  float\n";
  }
  header = sstm.str();
  headersize = header.length();
  footer = "";
  footersize = 0;
  startpos = 0;
    
  // allocate buffers for collecting data

  scalarBuffer = (float*)malloc(numberOfPoints*sizeof(float));
  vectorBuffer = (float*)malloc(3*numberOfPoints*sizeof(float));
  intScalarBuffer = (int*)malloc(numberOfPoints*sizeof(int));

  // collect and write grid points
    
  fGroupGridPoints(vectorBuffer, start, end, !bigend);
  fWriteLegacyVTKFloatBinaryData(vectorBuffer, 3*numberOfPoints, startpos, header.c_str(), footer.c_str(), headersize, footersize, file);

  // collect and write densities
    
  sstm.str(string());
  if((!lbmpiio && lbIOGroup.rank==0) || (lbmpiio && lbIOGroup.groupId==0)) {
    sstm<<"POINT_DATA  "<<numberOfPointsAll<<"\n";
    sstm<<"SCALARS density float"<<"\n";
    sstm<<"LOOKUP_TABLE default\n";
  }
  header = sstm.str();
  headersize = header.length();
  fGroupDensities(scalarBuffer, start, end, iprop, !bigend);
  fWriteLegacyVTKFloatBinaryData(scalarBuffer, numberOfPoints, startpos, header.c_str(), footer.c_str(), headersize, footersize, file);
    
  // collect and write velocities

  sstm.str(string());
  if((!lbmpiio && lbIOGroup.rank==0) || (lbmpiio && lbIOGroup.groupId==0)) {
    sstm<<"VECTORS velocity float\n";
  }
  header = sstm.str();
  headersize = header.length();
  fGroupVelocities(vectorBuffer, start, end, !bigend);
  fWriteLegacyVTKFloatBinaryData(vectorBuffer, 3*numberOfPoints, startpos, header.c_str(), footer.c_str(), headersize, footersize, file);
    
  // collect and write phase field/space property

  sstm.str(string());
  if((!lbmpiio && lbIOGroup.rank==0) || (lbmpiio && lbIOGroup.groupId==0)) {
    sstm<<"SCALARS phase_field int\n";
    sstm<<"LOOKUP_TABLE default\n";
  }
  header = sstm.str();
  headersize = header.length();
  
  fGroupPhaseField(intScalarBuffer, start, end, !bigend);
  fWriteLegacyVTKIntegerBinaryData(intScalarBuffer, numberOfPoints, startpos, header.c_str(), footer.c_str(), headersize, footersize, file);

  // close file and deallocate buffers

  fCloseOutputBinaryFile(file);

  free(scalarBuffer);
  free(vectorBuffer);
  free(intScalarBuffer);
  
  return 0;
}

int fsOutputLegacyVTKP(const char* filename="lbout", int iprop=0)
{
  char buf[80];
  int numberOfPoints,numberOfPointsAll;
  int start[3], end[3], startall[3], endall[3], length[3];
  int* intScalarBuffer;
  float* scalarBuffer;
  float* vectorBuffer;
  ofstream file;
  stringstream sstm;
  string header,footer;
  unsigned long headersize,footersize,startpos;
    
  // find extent and number of points for I/O group
  fGroupPieceRangeLocal(start,end);
  if(!lbmpiio) {
    startall[0] = start[0];
    startall[1] = start[1];
    startall[2] = start[2];
    endall[0] = end[0];
    endall[1] = end[1];
    endall[2] = end[2];
  }
  else {
    startall[0] = startall[1] = lbdm.bwid;
    startall[2] = (lbsy.nd==3)?lbdm.bwid:0;
    endall[0] = lbsy.nx+lbdm.bwid;
    endall[1] = lbsy.ny+lbdm.bwid;
    endall[2] = (lbsy.nd==3)?(lbsy.nz+lbdm.bwid):1;
  }
  numberOfPoints = fGroupPieceDataPoints(length);
  numberOfPointsAll = (lbmpiio)?lbsy.nx*lbsy.ny*lbsy.nz:numberOfPoints;

  // open file if root process for I/O group
  if(lbIOGroup.rank==0) {
    if(!lbmpiio && lbdm.size>lbIOGroup.size)
      sprintf(buf, "%s%.6dat%.6d.vtk", filename, lbIOGroup.groupId, qVersion);
    else
      sprintf(buf, "%s%.6d.vtk", filename, qVersion);
  }
  fOpenOutputANSIFile(buf, file);
    
    
  sstm.str(string());
  // write file header (with opening tags for grid points)
  if((!lbmpiio && lbIOGroup.rank==0) || (lbmpiio && lbIOGroup.groupId==0)) {
    // write file header
    sstm<<"# vtk DataFile Version 3.0\n";
    sstm<<"DL_MESO_LBE\n";
    sstm<<"ASCII\n";
    sstm<<"DATASET STRUCTURED_GRID\n";
    sstm<<"DIMENSIONS  "<<(endall[0]-startall[0])<<"  "<<(endall[1]-startall[1])<<"  "<<(endall[2]-startall[2])<<"\n";
    sstm<<"POINTS  "<<numberOfPointsAll<<"  float\n";
  }
  header = sstm.str();
  headersize = header.length();
  footer = "";
  footersize = 0;
  startpos = 0;

  // allocate buffers for collecting data

  scalarBuffer = (float*)malloc(numberOfPoints*sizeof(float));
  vectorBuffer = (float*)malloc(3*numberOfPoints*sizeof(float));
  intScalarBuffer = (int*)malloc(numberOfPoints*sizeof(int));

  // collect and write grid points
    
  fGroupGridPoints(vectorBuffer, start, end, false);
  fWriteLegacyVTKFloatANSIData(vectorBuffer, 3*numberOfPoints, true, startpos, header.c_str(), footer.c_str(), headersize, footersize, file);
    
  // collect and write densities
    
  sstm.str(string());
  if((!lbmpiio && lbIOGroup.rank==0) || (lbmpiio && lbIOGroup.groupId==0)) {
    sstm<<"POINT_DATA  "<<numberOfPointsAll<<"\n";
    sstm<<"SCALARS density float\n";
    sstm<<"LOOKUP_TABLE default\n";
  }
  header = sstm.str();
  headersize = header.length();
  fGroupDensities(scalarBuffer, start, end, iprop, false);
  fWriteLegacyVTKFloatANSIData(scalarBuffer, numberOfPoints, false, startpos, header.c_str(), footer.c_str(), headersize, footersize, file);
    
  // collect and write velocities

  sstm.str(string());
  if((!lbmpiio && lbIOGroup.rank==0) || (lbmpiio && lbIOGroup.groupId==0)) {
    sstm<<"VECTORS velocity float"<<endl;
  }
  header = sstm.str();
  headersize = header.length();
  fGroupVelocities(vectorBuffer, start, end, false);
  fWriteLegacyVTKFloatANSIData(vectorBuffer, 3*numberOfPoints, true, startpos, header.c_str(), footer.c_str(), headersize, footersize, file);
    
  // collect and write phase field/space property

  sstm.str(string());
  if((!lbmpiio && lbIOGroup.rank==0) || (lbmpiio && lbIOGroup.groupId==0)) {
    sstm<<"SCALARS phase_field int\n";
    sstm<<"LOOKUP_TABLE default\n";
  }
  header = sstm.str();
  headersize = header.length();
  fGroupPhaseField(intScalarBuffer, start, end, false);
  fWriteLegacyVTKIntegerANSIData(intScalarBuffer, numberOfPoints, false, startpos, header.c_str(), footer.c_str(), headersize, footersize, file);

  // close file and deallocate buffers
    
  fCloseOutputANSIFile(file);

  free(scalarBuffer);
  free(vectorBuffer);
  free(intScalarBuffer);
    
  return 0;
}


int fOutputLegacyVTKCA(const char* filename="lbout", int iprop=0)
{

  // output .vtk file with mass fraction and velocity for fluid iprop

  char buf[80];
  int numberOfPoints,numberOfPointsAll;
  int start[3], end[3], startall[3], endall[3], length[3];
  int* intScalarBuffer;
  float* scalarBuffer;
  float* vectorBuffer;
  ofstream file;
  stringstream sstm;
  string header,footer;
  unsigned long headersize,footersize,startpos;
    
  // find extent and number of points for I/O group
  fGroupPieceRangeLocal(start,end);
  if(!lbmpiio) {
    startall[0] = start[0];
    startall[1] = start[1];
    startall[2] = start[2];
    endall[0] = end[0];
    endall[1] = end[1];
    endall[2] = end[2];
  }
  else {
    startall[0] = startall[1] = lbdm.bwid;
    startall[2] = (lbsy.nd==3)?lbdm.bwid:0;
    endall[0] = lbsy.nx+lbdm.bwid;
    endall[1] = lbsy.ny+lbdm.bwid;
    endall[2] = (lbsy.nd==3)?(lbsy.nz+lbdm.bwid):1;
  }
  numberOfPoints = fGroupPieceDataPoints(length);
  numberOfPointsAll = (lbmpiio)?lbsy.nx*lbsy.ny*lbsy.nz:numberOfPoints;

  // open file if root process for I/O group
  if(lbIOGroup.rank==0) {
    if(!lbmpiio && lbdm.size>lbIOGroup.size)
      sprintf(buf, "%s%.6dat%.6d.vtk", filename, lbIOGroup.groupId, qVersion);
    else
      sprintf(buf, "%s%.6d.vtk", filename, qVersion);
  }
  fOpenOutputBinaryFile(buf, file);
    
  sstm.str(string());
  // write file header
  if((!lbmpiio && lbIOGroup.rank==0) || (lbmpiio && lbIOGroup.groupId==0)) {
    sstm<<"# vtk DataFile Version 3.0\n";
    sstm<<"DL_MESO_LBE\n";
    sstm<<"BINARY\n";
    sstm<<"DATASET STRUCTURED_GRID\n";
    sstm<<"DIMENSIONS  "<<(endall[0]-startall[0])<<"  "<<(endall[1]-startall[1])<<"  "<<(endall[2]-startall[2])<<"\n";
    sstm<<"POINTS  "<<numberOfPointsAll<<"  float\n";
  }
  header = sstm.str();
  headersize = header.length();
  footer = "";
  footersize = 0;
  startpos = 0;
    
  // allocate buffers for collecting data

  scalarBuffer = (float*)malloc(numberOfPoints*sizeof(float));
  vectorBuffer = (float*)malloc(3*numberOfPoints*sizeof(float));
  intScalarBuffer = (int*)malloc(numberOfPoints*sizeof(int));

  // collect and write grid points
    
  fGroupGridPoints(vectorBuffer, start, end, !bigend);
  fWriteLegacyVTKFloatBinaryData(vectorBuffer, 3*numberOfPoints, startpos, header.c_str(), footer.c_str(), headersize, footersize, file);

  // collect and write mass fractions
    
  sstm.str(string());
  if((!lbmpiio && lbIOGroup.rank==0) || (lbmpiio && lbIOGroup.groupId==0)) {
    sstm<<"POINT_DATA  "<<numberOfPointsAll<<"\n";
    sstm<<"SCALARS fraction float\n";
    sstm<<"LOOKUP_TABLE default\n";
  }
  header = sstm.str();
  headersize = header.length();
  fGroupMassFractions(scalarBuffer, start, end, iprop, !bigend);
  fWriteLegacyVTKFloatBinaryData(scalarBuffer, numberOfPoints, startpos, header.c_str(), footer.c_str(), headersize, footersize, file);
    
  // collect and write velocities

  sstm.str(string());
  if((!lbmpiio && lbIOGroup.rank==0) || (lbmpiio && lbIOGroup.groupId==0)) {
    sstm<<"VECTORS velocity float\n";
  }
  header = sstm.str();
  headersize = header.length();
  fGroupVelocities(vectorBuffer, start, end, !bigend);
  fWriteLegacyVTKFloatBinaryData(vectorBuffer, 3*numberOfPoints, startpos, header.c_str(), footer.c_str(), headersize, footersize, file);
    
  // collect and write phase field/space property

  sstm.str(string());
  if((!lbmpiio && lbIOGroup.rank==0) || (lbmpiio && lbIOGroup.groupId==0)) {
    sstm<<"SCALARS phase_field int\n";
    sstm<<"LOOKUP_TABLE default\n";
  }
  header = sstm.str();
  headersize = header.length();
  
  fGroupPhaseField(intScalarBuffer, start, end, !bigend);
  fWriteLegacyVTKIntegerBinaryData(intScalarBuffer, numberOfPoints, startpos, header.c_str(), footer.c_str(), headersize, footersize, file);

  // close file and deallocate buffers

  fCloseOutputBinaryFile(file);

  free(scalarBuffer);
  free(vectorBuffer);
  free(intScalarBuffer);
  
  return 0;
}


int fsOutputLegacyVTKCA(const char* filename="lbout", int iprop=0)
{
  char buf[80];
  int numberOfPoints,numberOfPointsAll;
  int start[3], end[3], startall[3], endall[3], length[3];
  int* intScalarBuffer;
  float* scalarBuffer;
  float* vectorBuffer;
  ofstream file;
  stringstream sstm;
  string header,footer;
  unsigned long headersize,footersize,startpos;
    
  // find extent and number of points for I/O group
  fGroupPieceRangeLocal(start,end);
  if(!lbmpiio) {
    startall[0] = start[0];
    startall[1] = start[1];
    startall[2] = start[2];
    endall[0] = end[0];
    endall[1] = end[1];
    endall[2] = end[2];
  }
  else {
    startall[0] = startall[1] = lbdm.bwid;
    startall[2] = (lbsy.nd==3)?lbdm.bwid:0;
    endall[0] = lbsy.nx+lbdm.bwid;
    endall[1] = lbsy.ny+lbdm.bwid;
    endall[2] = (lbsy.nd==3)?(lbsy.nz+lbdm.bwid):1;
  }
  numberOfPoints = fGroupPieceDataPoints(length);
  numberOfPointsAll = (lbmpiio)?lbsy.nx*lbsy.ny*lbsy.nz:numberOfPoints;

  // open file if root process for I/O group
  if(lbIOGroup.rank==0) {
    if(!lbmpiio && lbdm.size>lbIOGroup.size)
      sprintf(buf, "%s%.6dat%.6d.vtk", filename, lbIOGroup.groupId, qVersion);
    else
      sprintf(buf, "%s%.6d.vtk", filename, qVersion);
  }
  fOpenOutputANSIFile(buf, file);
    
    
  sstm.str(string());
  // write file header (with opening tags for grid points)
  if((!lbmpiio && lbIOGroup.rank==0) || (lbmpiio && lbIOGroup.groupId==0)) {
    // write file header
    sstm<<"# vtk DataFile Version 3.0\n";
    sstm<<"DL_MESO_LBE\n";
    sstm<<"ASCII\n";
    sstm<<"DATASET STRUCTURED_GRID\n";
    sstm<<"DIMENSIONS  "<<(endall[0]-startall[0])<<"  "<<(endall[1]-startall[1])<<"  "<<(endall[2]-startall[2])<<"\n";
    sstm<<"POINTS  "<<numberOfPointsAll<<"  float\n";
  }
  header = sstm.str();
  headersize = header.length();
  footer = "";
  footersize = 0;
  startpos = 0;

  // allocate buffers for collecting data

  scalarBuffer = (float*)malloc(numberOfPoints*sizeof(float));
  vectorBuffer = (float*)malloc(3*numberOfPoints*sizeof(float));
  intScalarBuffer = (int*)malloc(numberOfPoints*sizeof(int));

  // collect and write grid points
    
  fGroupGridPoints(vectorBuffer, start, end, false);
  fWriteLegacyVTKFloatANSIData(vectorBuffer, 3*numberOfPoints, true, startpos, header.c_str(), footer.c_str(), headersize, footersize, file);
    
  // collect and write mass fractions
    
  sstm.str(string());
  if((!lbmpiio && lbIOGroup.rank==0) || (lbmpiio && lbIOGroup.groupId==0)) {
    sstm<<"POINT_DATA  "<<numberOfPointsAll<<"\n";
    sstm<<"SCALARS fraction float\n";
    sstm<<"LOOKUP_TABLE default\n";
  }
  header = sstm.str();
  headersize = header.length();
  fGroupMassFractions(scalarBuffer, start, end, iprop, false);
  fWriteLegacyVTKFloatANSIData(scalarBuffer, numberOfPoints, false, startpos, header.c_str(), footer.c_str(), headersize, footersize, file);
    
  // collect and write velocities

  sstm.str(string());
  if((!lbmpiio && lbIOGroup.rank==0) || (lbmpiio && lbIOGroup.groupId==0)) {
    sstm<<"VECTORS velocity float"<<endl;
  }
  header = sstm.str();
  headersize = header.length();
  fGroupVelocities(vectorBuffer, start, end, false);
  fWriteLegacyVTKFloatANSIData(vectorBuffer, 3*numberOfPoints, true, startpos, header.c_str(), footer.c_str(), headersize, footersize, file);
    
  // collect and write phase field/space property

  sstm.str(string());
  if((!lbmpiio && lbIOGroup.rank==0) || (lbmpiio && lbIOGroup.groupId==0)) {
    sstm<<"SCALARS phase_field int\n";
    sstm<<"LOOKUP_TABLE default\n";
  }
  header = sstm.str();
  headersize = header.length();
  fGroupPhaseField(intScalarBuffer, start, end, false);
  fWriteLegacyVTKIntegerANSIData(intScalarBuffer, numberOfPoints, false, startpos, header.c_str(), footer.c_str(), headersize, footersize, file);

  // close file and deallocate buffers
    
  fCloseOutputANSIFile(file);

  free(scalarBuffer);
  free(vectorBuffer);
  free(intScalarBuffer);

  return 0;
}


int fOutputLegacyVTKCB(const char* filename="lbout", int iprop=0)
{

  // output .vtk file with concentration and velocity for solute iprop

  char buf[80];
  int numberOfPoints,numberOfPointsAll;
  int start[3], end[3], startall[3], endall[3], length[3];
  int* intScalarBuffer;
  float* scalarBuffer;
  float* vectorBuffer;
  ofstream file;
  stringstream sstm;
  string header,footer;
  unsigned long headersize,footersize,startpos;
    
  // find extent and number of points for I/O group
  fGroupPieceRangeLocal(start,end);
  if(!lbmpiio) {
    startall[0] = start[0];
    startall[1] = start[1];
    startall[2] = start[2];
    endall[0] = end[0];
    endall[1] = end[1];
    endall[2] = end[2];
  }
  else {
    startall[0] = startall[1] = lbdm.bwid;
    startall[2] = (lbsy.nd==3)?lbdm.bwid:0;
    endall[0] = lbsy.nx+lbdm.bwid;
    endall[1] = lbsy.ny+lbdm.bwid;
    endall[2] = (lbsy.nd==3)?(lbsy.nz+lbdm.bwid):1;
  }
  numberOfPoints = fGroupPieceDataPoints(length);
  numberOfPointsAll = (lbmpiio)?lbsy.nx*lbsy.ny*lbsy.nz:numberOfPoints;

  // open file if root process for I/O group
  if(lbIOGroup.rank==0) {
    if(!lbmpiio && lbdm.size>lbIOGroup.size)
      sprintf(buf, "%s%.6dat%.6d.vtk", filename, lbIOGroup.groupId, qVersion);
    else
      sprintf(buf, "%s%.6d.vtk", filename, qVersion);
  }
  fOpenOutputBinaryFile(buf, file);
    
  sstm.str(string());
  // write file header
  if((!lbmpiio && lbIOGroup.rank==0) || (lbmpiio && lbIOGroup.groupId==0)) {
    sstm<<"# vtk DataFile Version 3.0\n";
    sstm<<"DL_MESO_LBE\n";
    sstm<<"BINARY\n";
    sstm<<"DATASET STRUCTURED_GRID\n";
    sstm<<"DIMENSIONS  "<<(endall[0]-startall[0])<<"  "<<(endall[1]-startall[1])<<"  "<<(endall[2]-startall[2])<<"\n";
    sstm<<"POINTS  "<<numberOfPointsAll<<"  float\n";
  }
  header = sstm.str();
  headersize = header.length();
  footer = "";
  footersize = 0;
  startpos = 0;
    
  // allocate buffers for collecting data

  scalarBuffer = (float*)malloc(numberOfPoints*sizeof(float));
  vectorBuffer = (float*)malloc(3*numberOfPoints*sizeof(float));
  intScalarBuffer = (int*)malloc(numberOfPoints*sizeof(int));

  // collect and write grid points
    
  fGroupGridPoints(vectorBuffer, start, end, !bigend);
  fWriteLegacyVTKFloatBinaryData(vectorBuffer, 3*numberOfPoints, startpos, header.c_str(), footer.c_str(), headersize, footersize, file);

  // collect and write solute concentrations

  sstm.str(string());
  if((!lbmpiio && lbIOGroup.rank==0) || (lbmpiio && lbIOGroup.groupId==0)) {
    sstm<<"POINT_DATA  "<<numberOfPointsAll<<"\n";
    sstm<<"SCALARS concentration float\n";
    sstm<<"LOOKUP_TABLE default\n";
  }
  header = sstm.str();
  headersize = header.length();
  fGroupSoluteConcentrations(scalarBuffer, start, end, iprop, !bigend);
  fWriteLegacyVTKFloatBinaryData(scalarBuffer, numberOfPoints, startpos, header.c_str(), footer.c_str(), headersize, footersize, file);
    
  // collect and write velocities

  sstm.str(string());
  if((!lbmpiio && lbIOGroup.rank==0) || (lbmpiio && lbIOGroup.groupId==0)) {
    sstm<<"VECTORS velocity float\n";
  }
  header = sstm.str();
  headersize = header.length();
  fGroupVelocities(vectorBuffer, start, end, !bigend);
  fWriteLegacyVTKFloatBinaryData(vectorBuffer, 3*numberOfPoints, startpos, header.c_str(), footer.c_str(), headersize, footersize, file);
    
  // collect and write phase field/space property

  sstm.str(string());
  if((!lbmpiio && lbIOGroup.rank==0) || (lbmpiio && lbIOGroup.groupId==0)) {
    sstm<<"SCALARS phase_field int\n";
    sstm<<"LOOKUP_TABLE default\n";
  }
  header = sstm.str();
  headersize = header.length();
  
  fGroupPhaseField(intScalarBuffer, start, end, !bigend);
  fWriteLegacyVTKIntegerBinaryData(intScalarBuffer, numberOfPoints, startpos, header.c_str(), footer.c_str(), headersize, footersize, file);

  // close file and deallocate buffers

  fCloseOutputBinaryFile(file);

  free(scalarBuffer);
  free(vectorBuffer);
  free(intScalarBuffer);
  
  return 0;
}


int fsOutputLegacyVTKCB(const char* filename="lbout", int iprop=0)
{
  char buf[80];
  int numberOfPoints,numberOfPointsAll;
  int start[3], end[3], startall[3], endall[3], length[3];
  int* intScalarBuffer;
  float* scalarBuffer;
  float* vectorBuffer;
  ofstream file;
  stringstream sstm;
  string header,footer;
  unsigned long headersize,footersize,startpos;
    
  // find extent and number of points for I/O group
  fGroupPieceRangeLocal(start,end);
  if(!lbmpiio) {
    startall[0] = start[0];
    startall[1] = start[1];
    startall[2] = start[2];
    endall[0] = end[0];
    endall[1] = end[1];
    endall[2] = end[2];
  }
  else {
    startall[0] = startall[1] = lbdm.bwid;
    startall[2] = (lbsy.nd==3)?lbdm.bwid:0;
    endall[0] = lbsy.nx+lbdm.bwid;
    endall[1] = lbsy.ny+lbdm.bwid;
    endall[2] = (lbsy.nd==3)?(lbsy.nz+lbdm.bwid):1;
  }
  numberOfPoints = fGroupPieceDataPoints(length);
  numberOfPointsAll = (lbmpiio)?lbsy.nx*lbsy.ny*lbsy.nz:numberOfPoints;

  // open file if root process for I/O group
  if(lbIOGroup.rank==0) {
    if(!lbmpiio && lbdm.size>lbIOGroup.size)
      sprintf(buf, "%s%.6dat%.6d.vtk", filename, lbIOGroup.groupId, qVersion);
    else
      sprintf(buf, "%s%.6d.vtk", filename, qVersion);
  }
  fOpenOutputANSIFile(buf, file);
    
    
  sstm.str(string());
  // write file header (with opening tags for grid points)
  if((!lbmpiio && lbIOGroup.rank==0) || (lbmpiio && lbIOGroup.groupId==0)) {
    // write file header
    sstm<<"# vtk DataFile Version 3.0\n";
    sstm<<"DL_MESO_LBE\n";
    sstm<<"ASCII\n";
    sstm<<"DATASET STRUCTURED_GRID\n";
    sstm<<"DIMENSIONS  "<<(endall[0]-startall[0])<<"  "<<(endall[1]-startall[1])<<"  "<<(endall[2]-startall[2])<<"\n";
    sstm<<"POINTS  "<<numberOfPointsAll<<"  float\n";
  }
  header = sstm.str();
  headersize = header.length();
  footer = "";
  footersize = 0;
  startpos = 0;

  // allocate buffers for collecting data

  scalarBuffer = (float*)malloc(numberOfPoints*sizeof(float));
  vectorBuffer = (float*)malloc(3*numberOfPoints*sizeof(float));
  intScalarBuffer = (int*)malloc(numberOfPoints*sizeof(int));

  // collect and write grid points
    
  fGroupGridPoints(vectorBuffer, start, end, false);
  fWriteLegacyVTKFloatANSIData(vectorBuffer, 3*numberOfPoints, true, startpos, header.c_str(), footer.c_str(), headersize, footersize, file);
    
  // collect and write solute concentrations

  sstm.str(string());
  if((!lbmpiio && lbIOGroup.rank==0) || (lbmpiio && lbIOGroup.groupId==0)) {
    sstm<<"POINT_DATA  "<<numberOfPointsAll<<"\n";
    sstm<<"SCALARS concentration float\n";
    sstm<<"LOOKUP_TABLE default\n";
  }
  header = sstm.str();
  headersize = header.length();
  fGroupSoluteConcentrations(scalarBuffer, start, end, iprop, false);
  fWriteLegacyVTKFloatANSIData(scalarBuffer, numberOfPoints, false, startpos, header.c_str(), footer.c_str(), headersize, footersize, file);
    
  // collect and write velocities

  sstm.str(string());
  if((!lbmpiio && lbIOGroup.rank==0) || (lbmpiio && lbIOGroup.groupId==0)) {
    sstm<<"VECTORS velocity float"<<endl;
  }
  header = sstm.str();
  headersize = header.length();
  fGroupVelocities(vectorBuffer, start, end, false);
  fWriteLegacyVTKFloatANSIData(vectorBuffer, 3*numberOfPoints, true, startpos, header.c_str(), footer.c_str(), headersize, footersize, file);
    
  // collect and write phase field/space property

  sstm.str(string());
  if((!lbmpiio && lbIOGroup.rank==0) || (lbmpiio && lbIOGroup.groupId==0)) {
    sstm<<"SCALARS phase_field int\n";
    sstm<<"LOOKUP_TABLE default\n";
  }
  header = sstm.str();
  headersize = header.length();
  fGroupPhaseField(intScalarBuffer, start, end, false);
  fWriteLegacyVTKIntegerANSIData(intScalarBuffer, numberOfPoints, false, startpos, header.c_str(), footer.c_str(), headersize, footersize, file);

  // close file and deallocate buffers
    
  fCloseOutputANSIFile(file);

  free(scalarBuffer);
  free(vectorBuffer);
  free(intScalarBuffer);

  return 0;
}


int fOutputLegacyVTKT(const char* filename="lbout")
{

  // output .vtk file with scalar temperature and velocity

  char buf[80];
  int numberOfPoints,numberOfPointsAll;
  int start[3], end[3], startall[3], endall[3], length[3];
  int* intScalarBuffer;
  float* scalarBuffer;
  float* vectorBuffer;
  ofstream file;
  stringstream sstm;
  string header,footer;
  unsigned long headersize,footersize,startpos;
    
  // find extent and number of points for I/O group
  fGroupPieceRangeLocal(start,end);
  if(!lbmpiio) {
    startall[0] = start[0];
    startall[1] = start[1];
    startall[2] = start[2];
    endall[0] = end[0];
    endall[1] = end[1];
    endall[2] = end[2];
  }
  else {
    startall[0] = startall[1] = lbdm.bwid;
    startall[2] = (lbsy.nd==3)?lbdm.bwid:0;
    endall[0] = lbsy.nx+lbdm.bwid;
    endall[1] = lbsy.ny+lbdm.bwid;
    endall[2] = (lbsy.nd==3)?(lbsy.nz+lbdm.bwid):1;
  }
  numberOfPoints = fGroupPieceDataPoints(length);
  numberOfPointsAll = (lbmpiio)?lbsy.nx*lbsy.ny*lbsy.nz:numberOfPoints;

  // open file if root process for I/O group
  if(lbIOGroup.rank==0) {
    if(!lbmpiio && lbdm.size>lbIOGroup.size)
      sprintf(buf, "%s%.6dat%.6d.vtk", filename, lbIOGroup.groupId, qVersion);
    else
      sprintf(buf, "%s%.6d.vtk", filename, qVersion);
  }
  fOpenOutputBinaryFile(buf, file);
    
  sstm.str(string());
  // write file header
  if((!lbmpiio && lbIOGroup.rank==0) || (lbmpiio && lbIOGroup.groupId==0)) {
    sstm<<"# vtk DataFile Version 3.0\n";
    sstm<<"DL_MESO_LBE\n";
    sstm<<"BINARY\n";
    sstm<<"DATASET STRUCTURED_GRID\n";
    sstm<<"DIMENSIONS  "<<(endall[0]-startall[0])<<"  "<<(endall[1]-startall[1])<<"  "<<(endall[2]-startall[2])<<"\n";
    sstm<<"POINTS  "<<numberOfPointsAll<<"  float\n";
  }
  header = sstm.str();
  headersize = header.length();
  footer = "";
  footersize = 0;
  startpos = 0;
    
  // allocate buffers for collecting data

  scalarBuffer = (float*)malloc(numberOfPoints*sizeof(float));
  vectorBuffer = (float*)malloc(3*numberOfPoints*sizeof(float));
  intScalarBuffer = (int*)malloc(numberOfPoints*sizeof(int));

  // collect and write grid points
    
  fGroupGridPoints(vectorBuffer, start, end, !bigend);
  fWriteLegacyVTKFloatBinaryData(vectorBuffer, 3*numberOfPoints, startpos, header.c_str(), footer.c_str(), headersize, footersize, file);

  // collect and write temperatures
    
  sstm.str(string());
  if((!lbmpiio && lbIOGroup.rank==0) || (lbmpiio && lbIOGroup.groupId==0)) {
    sstm<<"POINT_DATA  "<<numberOfPointsAll<<"\n";
    sstm<<"SCALARS temperature float\n";
    sstm<<"LOOKUP_TABLE default\n";
  }
  header = sstm.str();
  headersize = header.length();
  fGroupTemperatures(scalarBuffer, start, end, !bigend);
  fWriteLegacyVTKFloatBinaryData(scalarBuffer, numberOfPoints, startpos, header.c_str(), footer.c_str(), headersize, footersize, file);
    
  // collect and write velocities

  sstm.str(string());
  if((!lbmpiio && lbIOGroup.rank==0) || (lbmpiio && lbIOGroup.groupId==0)) {
    sstm<<"VECTORS velocity float\n";
  }
  header = sstm.str();
  headersize = header.length();
  fGroupVelocities(vectorBuffer, start, end, !bigend);
  fWriteLegacyVTKFloatBinaryData(vectorBuffer, 3*numberOfPoints, startpos, header.c_str(), footer.c_str(), headersize, footersize, file);
    
  // collect and write phase field/space property

  sstm.str(string());
  if((!lbmpiio && lbIOGroup.rank==0) || (lbmpiio && lbIOGroup.groupId==0)) {
    sstm<<"SCALARS phase_field int\n";
    sstm<<"LOOKUP_TABLE default\n";
  }
  header = sstm.str();
  headersize = header.length();
  
  fGroupPhaseField(intScalarBuffer, start, end, !bigend);
  fWriteLegacyVTKIntegerBinaryData(intScalarBuffer, numberOfPoints, startpos, header.c_str(), footer.c_str(), headersize, footersize, file);

  // close file and deallocate buffers

  fCloseOutputBinaryFile(file);

  free(scalarBuffer);
  free(vectorBuffer);
  free(intScalarBuffer);
  
  return 0;
}


int fsOutputLegacyVTKT3D(const char* filename="lbout")
{
  char buf[80];
  int numberOfPoints,numberOfPointsAll;
  int start[3], end[3], startall[3], endall[3], length[3];
  int* intScalarBuffer;
  float* scalarBuffer;
  float* vectorBuffer;
  ofstream file;
  stringstream sstm;
  string header,footer;
  unsigned long headersize,footersize,startpos;
    
  // find extent and number of points for I/O group
  fGroupPieceRangeLocal(start,end);
  if(!lbmpiio) {
    startall[0] = start[0];
    startall[1] = start[1];
    startall[2] = start[2];
    endall[0] = end[0];
    endall[1] = end[1];
    endall[2] = end[2];
  }
  else {
    startall[0] = startall[1] = lbdm.bwid;
    startall[2] = (lbsy.nd==3)?lbdm.bwid:0;
    endall[0] = lbsy.nx+lbdm.bwid;
    endall[1] = lbsy.ny+lbdm.bwid;
    endall[2] = (lbsy.nd==3)?(lbsy.nz+lbdm.bwid):1;
  }
  numberOfPoints = fGroupPieceDataPoints(length);
  numberOfPointsAll = (lbmpiio)?lbsy.nx*lbsy.ny*lbsy.nz:numberOfPoints;

  // open file if root process for I/O group
  if(lbIOGroup.rank==0) {
    if(!lbmpiio && lbdm.size>lbIOGroup.size)
      sprintf(buf, "%s%.6dat%.6d.vtk", filename, lbIOGroup.groupId, qVersion);
    else
      sprintf(buf, "%s%.6d.vtk", filename, qVersion);
  }
  fOpenOutputANSIFile(buf, file);
    
    
  sstm.str(string());
  // write file header (with opening tags for grid points)
  if((!lbmpiio && lbIOGroup.rank==0) || (lbmpiio && lbIOGroup.groupId==0)) {
    // write file header
    sstm<<"# vtk DataFile Version 3.0\n";
    sstm<<"DL_MESO_LBE\n";
    sstm<<"ASCII\n";
    sstm<<"DATASET STRUCTURED_GRID\n";
    sstm<<"DIMENSIONS  "<<(endall[0]-startall[0])<<"  "<<(endall[1]-startall[1])<<"  "<<(endall[2]-startall[2])<<"\n";
    sstm<<"POINTS  "<<numberOfPointsAll<<"  float\n";
  }
  header = sstm.str();
  headersize = header.length();
  footer = "";
  footersize = 0;
  startpos = 0;

  // allocate buffers for collecting data

  scalarBuffer = (float*)malloc(numberOfPoints*sizeof(float));
  vectorBuffer = (float*)malloc(3*numberOfPoints*sizeof(float));
  intScalarBuffer = (int*)malloc(numberOfPoints*sizeof(int));

  // collect and write grid points
    
  fGroupGridPoints(vectorBuffer, start, end, false);
  fWriteLegacyVTKFloatANSIData(vectorBuffer, 3*numberOfPoints, true, startpos, header.c_str(), footer.c_str(), headersize, footersize, file);
    
  // collect and write temperatures
    
  sstm.str(string());
  if((!lbmpiio && lbIOGroup.rank==0) || (lbmpiio && lbIOGroup.groupId==0)) {
    sstm<<"POINT_DATA  "<<numberOfPointsAll<<"\n";
    sstm<<"SCALARS temperature float\n";
    sstm<<"LOOKUP_TABLE default\n";
  }
  header = sstm.str();
  headersize = header.length();
  fGroupTemperatures(scalarBuffer, start, end, false);
  fWriteLegacyVTKFloatANSIData(scalarBuffer, numberOfPoints, false, startpos, header.c_str(), footer.c_str(), headersize, footersize, file);
    
  // collect and write velocities

  sstm.str(string());
  if((!lbmpiio && lbIOGroup.rank==0) || (lbmpiio && lbIOGroup.groupId==0)) {
    sstm<<"VECTORS velocity float"<<endl;
  }
  header = sstm.str();
  headersize = header.length();
  fGroupVelocities(vectorBuffer, start, end, false);
  fWriteLegacyVTKFloatANSIData(vectorBuffer, 3*numberOfPoints, true, startpos, header.c_str(), footer.c_str(), headersize, footersize, file);
    
  // collect and write phase field/space property

  sstm.str(string());
  if((!lbmpiio && lbIOGroup.rank==0) || (lbmpiio && lbIOGroup.groupId==0)) {
    sstm<<"SCALARS phase_field int\n";
    sstm<<"LOOKUP_TABLE default\n";
  }
  header = sstm.str();
  headersize = header.length();
  fGroupPhaseField(intScalarBuffer, start, end, false);
  fWriteLegacyVTKIntegerANSIData(intScalarBuffer, numberOfPoints, false, startpos, header.c_str(), footer.c_str(), headersize, footersize, file);

  // close file and deallocate buffers
    
  fCloseOutputANSIFile(file);

  free(scalarBuffer);
  free(vectorBuffer);
  free(intScalarBuffer);

  return 0;
}

