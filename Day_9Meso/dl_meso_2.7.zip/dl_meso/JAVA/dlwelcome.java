import javax.swing.*;
import java.util.*;
import java.lang.*;
import java.io.*;
import java.awt.*;
import java.awt.event.*;
import java.awt.geom.*;
import java.awt.image.*;
/*
 *     DL_MESO_GUI
 *     author: R. S. Qin, M. A. Seaton
 *     copyright: UKRI STFC Daresbury Laboratory and CCP5
 *     2005, 2019
 */
class dlwelcome extends JPanel {
    JLabel lb1 =new JLabel("Welcome to DL_MESO", JLabel.CENTER);
    JLabel lb2 =new JLabel("R. S. Qin, W. Smith & M. A. Seaton", JLabel.CENTER);
    JLabel lb3 =new JLabel("<html>Copyright &copy; UKRI STFC 2019</html>", JLabel.CENTER);
    JLabel lb5 =new JLabel("Operating system: ", JLabel.CENTER);
    JLabel lb4 =new JLabel("Click one of the above buttons to start", JLabel.CENTER);
    private static String OS = System.getProperty("os.name").toLowerCase();

    public dlwelcome() {
        setSize(400, 400);
        GridLayout glt =new GridLayout(5, 1, 6, 6);
        setLayout(glt);
        Font lbf = new Font("Dialog", Font.BOLD, 24);
        lb1.setFont(lbf);
        add(lb1);
        lbf = new Font("Dialog", Font.PLAIN, 12);
        lb2.setFont(lbf);
        add(lb2);
        lb3.setFont(lbf);
        add(lb3);
        if (isWindows ())
            lb5.setText("Operating system: Windows");
        else if (isMac ())
            lb5.setText("Operating system: macOS");
        else if (isUnix ())
            lb5.setText("Operating system: Unix/Linux");
        lb5.setFont(lbf);
        add(lb5);
        lbf = new Font("Dialog", Font.PLAIN, 14);
        lb4.setFont(lbf);
        add(lb4);
    }

    public static boolean isWindows() {
        return (OS.indexOf("win") >= 0);
    }
    
    public static boolean isMac() {
        return (OS.indexOf("mac") >= 0);
    }
    
    public static boolean isUnix() {
        return (OS.indexOf("nix") >= 0 || OS.indexOf("nux") >= 0 || OS.indexOf("aix") >= 0 || OS.indexOf("sunos") >= 0 );
    }
    
}
