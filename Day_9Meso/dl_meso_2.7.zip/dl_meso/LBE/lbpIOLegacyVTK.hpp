int fOutputLegacyVTK(const char* filename);
int fsOutputLegacyVTK(const char* filename);

int fOutputLegacyVTKP(const char* filename, int iprop);
int fsOutputLegacyVTKP(const char* filename, int iprop);

int fOutputLegacyVTKCA(const char* filename, int iprop);
int fsOutputLegacyVTKCA(const char* filename, int iprop);

int fOutputLegacyVTKCB(const char* filename, int iprop);
int fsOutputLegacyVTKCB(const char* filename, int iprop);

int fOutputLegacyVTKT(const char* filename);
int fsOutputLegacyVTKT(const char* filename);
