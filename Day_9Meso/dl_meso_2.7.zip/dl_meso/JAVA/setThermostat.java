import javax.swing.*;
import java.util.*;
import java.lang.*;
import java.io.*;
import java.awt.*;
import java.awt.event.*;
import java.awt.geom.*;
import java.awt.image.*;
/*
 *     DL_MESO_GUI
 *     author: R. S. Qin, M. A. Seaton
 *     copyright: UKRI STFC Daresbury Laboratory and CCP5
 *     2005, 2018
 */
class setThermostat extends JFrame {

    setdpdSysEvt theinidpd=new setdpdSysEvt(this);
    Font font=new Font("Dialog", Font.BOLD, 13);

    JLabel thermotype = new JLabel("THERMOSTAT TYPE", JLabel.RIGHT);
    JLabel athermlabel = new JLabel("thermostat parameter a:", JLabel.RIGHT);
    JTextField atherm = new JTextField("0.0", 7);

    JButton save = new JButton("SAVE T");
    JButton close = new JButton("CANCEL T");
    
    public setThermostat(int it, double at) {
	super("DPD thermostat properties");
	setBounds(170, 120, 320, 200);
	JPanel pane=new JPanel(new GridBagLayout());

        if (it==4) {
           thermotype.setText("STOYANOV-GROOT");
           athermlabel.setText("global coupling parameter:");
           atherm.setText(Double.toString(at));
        }

        thermotype.setFont(font);
        addItem(pane, thermotype, 0, 0, 2, 1, GridBagConstraints.WEST);
	athermlabel.setFont(font);
	addItem(pane, athermlabel, 0, 1, 1, 1, GridBagConstraints.WEST);

        addItem(pane, atherm, 1, 1, 1, 1, GridBagConstraints.CENTER);

        Box buttonBox = Box.createHorizontalBox();
	save.setFont(font);
	save.addActionListener(theinidpd);
	buttonBox.add(save);
	close.setFont(font);
	close.addActionListener(theinidpd);
	buttonBox.add(close);
        addItem(pane, buttonBox, 0, 2, 2, 1, GridBagConstraints.WEST);

	this.add(pane);
        this.pack();
	setVisible(true);
    }

    private void addItem(JPanel p, JComponent c, int x, int y, int width, int height, int align)
    {
        GridBagConstraints gc = new GridBagConstraints();
        gc.gridx = x;
        gc.gridy = y;
        gc.gridwidth = width;
        gc.gridheight = height;
        gc.weightx = 100.0;
        gc.weighty = 100.0;
        gc.insets = new Insets(5, 5, 5, 5);
        gc.anchor = align;
        gc.fill = GridBagConstraints.NONE;
        p.add(c, gc);
    }

}
