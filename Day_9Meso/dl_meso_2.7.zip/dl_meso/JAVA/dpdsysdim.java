/*
 *     DL_MESO_GUI
 *     author: R. S. Qin, M. A. Seaton
 *     copyright: UKRI STFC Daresbury Laboratory and CCP5
 *     2005, 2018
 */
class dpdsysdim {
    static int srftyp = 0;
    static boolean frzwalls = false;
}
