float fGetTemperatureWrap(int ilen, int iprop);
float fGetOneMassSiteWrap(int ilen, int iprop);
float fGetOneMassSwiftSiteWrap(int ilen, int iprop);
float fGetFracSiteWrap(int ilen, int iprop);
float fGetFracSwiftSiteWrap(int ilen, int iprop);
float fGetOneConcSiteWrap(int ilen, int iprop);
void fPieceRangeLocal(int* start, int* end, bool* includeInnerHalos);
void fPieceRangeGlobal(int* myStart, int *myEnd);
int fPieceDataPoints(int* start, int* end, int* length);
void fFillBuffer(float* buffer, int* start, int* end, int iprop, bool swapbit, float (*GetFunction)(int, int));
void fPieceDensities(float* buffer, int* start, int* end, int iprop, bool swapbit);
void fPieceDensitiesSwift(float* buffer, int* start, int* end, int iprop, bool swapbit);
void fPieceMassFractions(float* buffer, int* start, int* end, int iprop, bool swapbit);
void fPieceMassFractionsSwift(float* buffer, int* start, int* end, int iprop, bool swapbit);
void fPieceSoluteConcentrations(float* buffer, int* start, int* end, int iprop, bool swapbit);
void fPieceTemperatures(float* buffer, int* start, int* end, int param, bool swapbit);
void fPieceVelocity(float* buffer, int* start, int* end, int comp, bool swapbit);
void fPieceVelocities(float* buffer, int* start, int* end, int param, bool swapbit);
void fPiecePhaseField(int* buffer, int* start, int* end, int param, bool swapbit);
void fPiecePhaseFieldFloat(float* buffer, int* start, int* end, int param, bool swapbit);
void fPieceGridPoints(float* buffer, int* start, int* end, int param, bool swapbit);
void fPieceGridPointComponent(float* buffer, int* start, int* end, int comp, bool swapbit);
void fGroupRangeGlobal(sIOGroup* ioGroup);
void fGroupPieceRangeLocal(int* start, int* end);
void fGroupPieceRangeGlobal(int* start, int* end);
int fGroupPieceDataPoints(int* length);
void fGroupGatherFloatData(sIOGroup* ioGroup, float* buffer, int* start, int* end, int dataPerPoint, int param, bool swapbit, void (*GetLocalData)(float*, int*, int*, int));
void fGroupGatherIntData(sIOGroup* ioGroup, int* buffer, int* start, int* end, int dataPerPoint, int param, bool swapbit, void (*GetLocalData)(int*, int*, int*, int));
void fGroupDensities(float* buffer, int* start, int* end, int iprop, bool swapbit);
void fGroupMassFractions(float* buffer, int* start, int* end, int iprop, bool swapbit);
void fGroupSoluteConcentrations(float* buffer, int* start, int* end, int iprop, bool swapbit);
void fGroupTemperatures(float* buffer, int* start, int* end, bool swapbit);
void fGroupPhaseField(int* buffer, int* start, int* end, bool swapbit);
void fGroupPhaseFieldFloat(float* buffer, int* start, int* end, bool swapbit);
void fGroupVelocityComponent(float* buffer, int* start, int* end, int comp, bool swapbit);
void fGroupVelocities(float* buffer, int* start, int* end, bool swapbit);
void fGroupGridPoints(float* buffer, int* start, int* end, bool swapbit);
void fGroupGridPointComponent(float* buffer, int* start, int* end, int comp, bool swapbit);

int fOpenOutputBinaryFile(const char* filename, ofstream &file);
int fCloseOutputBinaryFile(ofstream &file);
int fOpenOutputANSIFile(const char* filename, ofstream &file);
int fCloseOutputANSIFile(ofstream &file);

int fWriteVTKFloatBinaryData(float* buffer, int bufflen, unsigned long& startpos, const char* header, const char* footer, unsigned long headersize, unsigned long footersize, ofstream &file);
int fWriteVTKIntegerBinaryData(int* buffer, int bufflen, unsigned long& startpos, const char* header, const char* footer, unsigned long headersize, unsigned long footersize, ofstream &file);
int fWriteVTKFloatANSIData(float* buffer, int bufflen, unsigned long& startpos, const char* header, const char* footer, unsigned long headersize, unsigned long footersize, ofstream &file);
int fWriteVTKIntegerANSIData(int* buffer, int bufflen, unsigned long& startpos, const char* header, const char* footer, unsigned long headersize, unsigned long footersize, ofstream &file);

int fWriteLegacyVTKFloatBinaryData(float* buffer, int bufflen, unsigned long& startpos, const char* header, const char* footer, unsigned long headersize, unsigned long footersize, ofstream &file);
int fWriteLegacyVTKIntegerBinaryData(int* buffer, int bufflen, unsigned long& startpos, const char* header, const char* footer, unsigned long headersize, unsigned long footersize, ofstream &file);
int fWriteLegacyVTKFloatANSIData(float* buffer, int bufflen, bool vec, unsigned long& startpos, const char* header, const char* footer, unsigned long headersize, unsigned long footersize, ofstream &file);
int fWriteLegacyVTKIntegerANSIData(int* buffer, int bufflen, bool vec, unsigned long& startpos, const char* header, const char* footer, unsigned long headersize, unsigned long footersize, ofstream &file);

int fWritePlot3DGridFloatBinaryData(float* buffer, int bufflen, unsigned long& startpos, ofstream &file);
int fWritePlot3DGridIntegerBinaryData(int* buffer, int bufflen, unsigned long& startpos, ofstream &file);
int fWritePlot3DGridFloatANSIData(float* buffer, int bufflen, unsigned long& startpos, ofstream &file);
int fWritePlot3DGridIntegerANSIData(int* buffer, int bufflen, unsigned long& startpos, ofstream &file);

int fReadRestart(const char* filename);
int fWriteRestart(const char* filename);

