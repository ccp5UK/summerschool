import javax.swing.*;
import java.util.*;
import java.lang.*;
import java.io.*;
import java.awt.*;
import java.awt.event.*;
import java.awt.geom.*;
import java.awt.image.*;
/*
 *     DL_MESO_GUI
 *     author: R. S. Qin, M. A. Seaton
 *     copyright: UKRI STFC Daresbury Laboratory and CCP5
 *     2005, 2018
 */
class setElectrostatic extends JFrame {

    setdpdSysEvt eleinidpd=new setdpdSysEvt(this);
    Font font=new Font("Dialog", Font.BOLD, 13);

    JLabel electrotype = new JLabel("ELECTROSTATICS TYPE", JLabel.RIGHT);
    JLabel electrodetail = new JLabel("DETAIL", JLabel.RIGHT);

    JLabel kmaxlabel = new JLabel("k-vector (x, y, z):", JLabel.RIGHT);
    JLabel smearlenlabel = new JLabel("charge smearing length:", JLabel.RIGHT);
    JLabel lenbetarellabel = new JLabel("smearing length/beta relationship:", JLabel.RIGHT);
    JLabel mxspllabel = new JLabel("B-spline interpolation order:", JLabel.RIGHT);
    
    JTextField perm = new JTextField("0.0", 7);
    JTextField converr = new JTextField("0.0", 7);
    JTextField smearlen = new JTextField("0.0", 7);
    JTextField kmax1 = new JTextField("0", 4);
    JTextField kmax2 = new JTextField("0", 4);
    JTextField kmax3 = new JTextField("0", 4);
    JTextField mxspl = new JTextField("0", 7);
    JComboBox<String> permbjer = new JComboBox<String>();
    JComboBox<String> converror = new JComboBox<String>();
    JComboBox<String> lenbeta = new JComboBox<String>();
    JComboBox<String> lenbetarel = new JComboBox<String>();
    JCheckBox gausseq = new JCheckBox("no real space terms");
    
    JButton save = new JButton("SAVE E");
    JButton close = new JButton("CANCEL E");
    
    public setElectrostatic(int et, int pb, int coe, int bl, int blrel, double ae, double be, double ce, int k1, int k2, int k3, int mxs, boolean ge) {
	super("DPD electrostatic properties");
	setBounds(170, 120, 350, 400);
	JPanel pane=new JPanel(new GridBagLayout());

        permbjer.addItem("permittivity coefficient");
        permbjer.addItem("bjerrum length");
        permbjer.addItemListener(eleinidpd);
        permbjer.setSelectedIndex(pb);
        
        converror.addItem("Ewald real-space convergence");
        converror.addItem("relative error in Ewald sum");
        converror.addItemListener(eleinidpd);
        converror.setSelectedIndex(coe);
        
        lenbeta.addItem("charge smearing length");
        lenbeta.addItem("charge smearing beta");
        lenbeta.addItemListener(eleinidpd);
        lenbeta.setSelectedIndex(bl);
        
        lenbetarel.addItem("original");
        lenbetarel.addItem("overlap");
        lenbetarel.addItem("distribution");
        lenbetarel.addItemListener(eleinidpd);
        lenbetarel.setSelectedIndex(blrel);

        gausseq.setSelected(ge);
        gausseq.addItemListener(eleinidpd);
            
        kmaxlabel.setFont(font);
        addItem(pane, permbjer, 0, 2, 2, 1, GridBagConstraints.WEST);
        addItem(pane, converror, 0, 3, 2, 1, GridBagConstraints.WEST);
        addItem(pane, kmaxlabel, 0, 4, 2, 1, GridBagConstraints.WEST);
        perm.setText(Double.toString(ae));
        converr.setText(Double.toString(be));
        kmax1.setText(Integer.toString(k1));
        kmax2.setText(Integer.toString(k2));
        kmax3.setText(Integer.toString(k3));
        addItem(pane, perm, 2, 2, 3, 1, GridBagConstraints.WEST);
        addItem(pane, converr, 2, 3, 3, 1, GridBagConstraints.WEST);
        addItem(pane, kmax1, 2, 4, 1, 1, GridBagConstraints.WEST);
        addItem(pane, kmax2, 3, 4, 1, 1, GridBagConstraints.WEST);
        addItem(pane, kmax3, 4, 4, 1, 1, GridBagConstraints.WEST);

        switch (et) {
            case 1:     electrotype.setText("EWALD SUM WITH NO SMEARING");
                        electrodetail.setText("");
                        break;
            case 2:     electrotype.setText("EWALD SUM WITH LINEAR SMEARING");
                        electrodetail.setText("");
                        smearlenlabel.setFont(font);
                        addItem(pane, smearlenlabel, 0, 5, 2, 1, GridBagConstraints.WEST);
                        smearlen.setText(Double.toString(ce));
                        addItem(pane, smearlen, 2, 5, 3, 1, GridBagConstraints.WEST);
                        break;
            case 3:     electrotype.setText("EWALD SUM WITH SLATER SMEARING");
                        electrodetail.setText("EXACT FORM");
                        addItem(pane, lenbeta, 0, 5, 2, 1, GridBagConstraints.WEST);
                        smearlen.setText(Double.toString(ce));
                        addItem(pane, smearlen, 2, 5, 3, 1, GridBagConstraints.WEST);
                        lenbetarellabel.setFont(font);
                        addItem(pane, lenbetarellabel, 0, 6, 2, 1, GridBagConstraints.WEST);
                        addItem(pane, lenbetarel, 2, 6, 3, 1, GridBagConstraints.WEST);
                        break;
            case 4:     electrotype.setText("EWALD SUM WITH SLATER SMEARING");
                        electrodetail.setText("APPROXIMATE FORM");
                        addItem(pane, lenbeta, 0, 5, 2, 1, GridBagConstraints.WEST);
                        smearlen.setText(Double.toString(ce));
                        addItem(pane, smearlen, 2, 5, 3, 1, GridBagConstraints.WEST);
                        lenbetarellabel.setFont(font);
                        addItem(pane, lenbetarellabel, 0, 6, 2, 1, GridBagConstraints.WEST);
                        addItem(pane, lenbetarel, 2, 6, 3, 1, GridBagConstraints.WEST);
                        break;
            case 5:     electrotype.setText("EWALD SUM WITH GAUSSIAN SMEARING");
                        electrodetail.setText("");
                        smearlenlabel.setFont(font);
                        addItem(pane, smearlenlabel, 0, 5, 2, 1, GridBagConstraints.WEST);
                        smearlen.setText(Double.toString(ce));
                        addItem(pane, smearlen, 2, 5, 3, 1, GridBagConstraints.WEST);
                        addItem(pane, gausseq, 2, 6, 3, 1, GridBagConstraints.WEST);
                        break;
            case 6:     electrotype.setText("EWALD SUM WITH SINUSOIDAL SMEARING");
                        electrodetail.setText("");
                        smearlenlabel.setFont(font);
                        addItem(pane, smearlenlabel, 0, 5, 2, 1, GridBagConstraints.WEST);
                        smearlen.setText(Double.toString(ce));
                        addItem(pane, smearlen, 2, 5, 3, 1, GridBagConstraints.WEST);
                        break;
            case 7:     electrotype.setText("SPME WITH NO SMEARING");
                        electrodetail.setText("");
                        mxspllabel.setFont(font);
                        addItem(pane, mxspllabel, 0, 5, 2, 1, GridBagConstraints.WEST);
                        mxspl.setText(Integer.toString(mxs));
                        addItem(pane, mxspl, 2, 5, 3, 1, GridBagConstraints.WEST);
                        break;
            case 8:     electrotype.setText("SPME WITH LINEAR SMEARING");
                        electrodetail.setText("");
                        mxspllabel.setFont(font);
                        addItem(pane, mxspllabel, 0, 5, 2, 1, GridBagConstraints.WEST);
                        mxspl.setText(Integer.toString(mxs));
                        addItem(pane, mxspl, 2, 5, 3, 1, GridBagConstraints.WEST);
                        smearlenlabel.setFont(font);
                        addItem(pane, smearlenlabel, 0, 6, 2, 1, GridBagConstraints.WEST);
                        smearlen.setText(Double.toString(ce));
                        addItem(pane, smearlen, 2, 6, 3, 1, GridBagConstraints.WEST);
                        break;
            case 9:     electrotype.setText("SPME WITH SLATER SMEARING");
                        electrodetail.setText("EXACT FORM");
                        mxspllabel.setFont(font);
                        addItem(pane, mxspllabel, 0, 5, 2, 1, GridBagConstraints.WEST);
                        mxspl.setText(Integer.toString(mxs));
                        addItem(pane, mxspl, 2, 5, 3, 1, GridBagConstraints.WEST);
                        addItem(pane, lenbeta, 0, 6, 2, 1, GridBagConstraints.WEST);
                        smearlen.setText(Double.toString(ce));
                        addItem(pane, smearlen, 2, 6, 3, 1, GridBagConstraints.WEST);
                        lenbetarellabel.setFont(font);
                        addItem(pane, lenbetarellabel, 0, 7, 2, 1, GridBagConstraints.WEST);
                        addItem(pane, lenbetarel, 2, 7, 3, 1, GridBagConstraints.WEST);
                        break;
            case 10:    electrotype.setText("SPME WITH SLATER SMEARING");
                        electrodetail.setText("APPROXIMATE FORM");
                        mxspllabel.setFont(font);
                        addItem(pane, mxspllabel, 0, 5, 2, 1, GridBagConstraints.WEST);
                        mxspl.setText(Integer.toString(mxs));
                        addItem(pane, mxspl, 2, 5, 3, 1, GridBagConstraints.WEST);
                        addItem(pane, lenbeta, 0, 6, 2, 1, GridBagConstraints.WEST);
                        smearlen.setText(Double.toString(ce));
                        addItem(pane, smearlen, 2, 6, 3, 1, GridBagConstraints.WEST);
                        lenbetarellabel.setFont(font);
                        addItem(pane, lenbetarellabel, 0, 7, 2, 1, GridBagConstraints.WEST);
                        addItem(pane, lenbetarel, 2, 7, 3, 1, GridBagConstraints.WEST);
                        break;
            case 11:    electrotype.setText("SPME WITH GAUSSIAN SMEARING");
                        electrodetail.setText("");
                        mxspllabel.setFont(font);
                        addItem(pane, mxspllabel, 0, 5, 2, 1, GridBagConstraints.WEST);
                        mxspl.setText(Integer.toString(mxs));
                        addItem(pane, mxspl, 2, 5, 3, 1, GridBagConstraints.WEST);
                        smearlenlabel.setFont(font);
                        addItem(pane, smearlenlabel, 0, 6, 2, 1, GridBagConstraints.WEST);
                        smearlen.setText(Double.toString(ce));
                        addItem(pane, smearlen, 2, 6, 3, 1, GridBagConstraints.WEST);
                        addItem(pane, gausseq, 2, 7, 3, 1, GridBagConstraints.WEST);
                        break;
            case 12:    electrotype.setText("SPME WITH SINUSOIDAL SMEARING");
                        electrodetail.setText("");
                        mxspllabel.setFont(font);
                        addItem(pane, mxspllabel, 0, 5, 2, 1, GridBagConstraints.WEST);
                        mxspl.setText(Integer.toString(mxs));
                        addItem(pane, mxspl, 2, 5, 3, 1, GridBagConstraints.WEST);
                        smearlenlabel.setFont(font);
                        addItem(pane, smearlenlabel, 0, 6, 2, 1, GridBagConstraints.WEST);
                        smearlen.setText(Double.toString(ce));
                        addItem(pane, smearlen, 2, 6, 3, 1, GridBagConstraints.WEST);
                        break;
            
        }

        electrotype.setFont(font);
        electrodetail.setFont(font);
        addItem(pane, electrotype, 0, 0, 2, 1, GridBagConstraints.WEST);
        addItem(pane, electrodetail, 0, 1, 2, 1, GridBagConstraints.WEST);

        kmaxlabel.setEnabled(coe==0);
        kmax1.setEnabled(coe==0);
        kmax2.setEnabled(coe==0);
        kmax3.setEnabled(coe==0);
        kmax1.setEditable(coe==0);
        kmax2.setEditable(coe==0);
        kmax3.setEditable(coe==0);

        Box buttonBox = Box.createHorizontalBox();
        save.setFont(font);
	    save.addActionListener(eleinidpd);
	    buttonBox.add(save);
	    close.setFont(font);
	    close.addActionListener(eleinidpd);
	    buttonBox.add(close);
        addItem(pane, buttonBox, 0, 8, 5, 1, GridBagConstraints.WEST);

	    this.add(pane);
        this.pack();
	    setVisible(true);
    }

    private void addItem(JPanel p, JComponent c, int x, int y, int width, int height, int align)
    {
        GridBagConstraints gc = new GridBagConstraints();
        gc.gridx = x;
        gc.gridy = y;
        gc.gridwidth = width;
        gc.gridheight = height;
        gc.weightx = 100.0;
        gc.weighty = 100.0;
        gc.insets = new Insets(5, 5, 5, 5);
        gc.anchor = align;
        gc.fill = GridBagConstraints.NONE;
        p.add(c, gc);
    }

}
