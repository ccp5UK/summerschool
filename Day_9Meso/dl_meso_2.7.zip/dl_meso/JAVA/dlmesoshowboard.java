import javax.swing.*;
import java.util.*;
import java.lang.*;
import java.io.*;
import java.awt.*;
import java.awt.event.*;
import java.awt.geom.*;
import java.awt.image.*;
/*
 *     DL_MESO_GUI
 *     author: R. S. Qin, M. A. Seaton
 *     copyright: UKRI STFC Daresbury Laboratory and CCP5
 *     2005, 2018
 */
class dlmesoshowboard extends JFrame {

    dlmesoshowEvt dlgui = new dlmesoshowEvt(this);

    Font font=new Font("Dialog", Font.BOLD, 14);
    Color paneltop=new Color(170, 170, 230);
    JPanel row2 = new JPanel();
    JTextArea text = new JTextArea(30, 80);
    JButton clos = new JButton("exit");

    public dlmesoshowboard(String str1){ 
	super("DL_MESO ShowBoard");
	setBounds(180, 50, 620, 530);
	Container pane=getContentPane();
	BorderLayout bl = new BorderLayout();
	FlowLayout fl = new FlowLayout();
	pane.setLayout(bl);
	text.setFont(font);
	text.setLineWrap(true);
	text.setWrapStyleWord(true);
	text.setText(str1 + "\n");
	text.setEditable(false);
	JScrollPane scroll = new JScrollPane(text, 
	JScrollPane.VERTICAL_SCROLLBAR_AS_NEEDED,
        JScrollPane.HORIZONTAL_SCROLLBAR_AS_NEEDED);
	pane.add(scroll, BorderLayout.CENTER);
	row2.setLayout(fl);
	clos.setBackground(paneltop);
	clos.addActionListener(dlgui);
	row2.add(clos);
	pane.add(row2, BorderLayout.SOUTH);
	setContentPane(pane);
	setVisible(true);	
    }
}
