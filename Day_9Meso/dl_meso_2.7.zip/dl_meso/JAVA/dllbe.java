import javax.swing.*;
import java.util.*;
import java.lang.*;
import java.io.*;
import java.awt.*;
import java.awt.event.*;
import java.awt.geom.*;
import java.awt.image.*;
/*
 *     DL_MESO_GUI
 *     author: R. S. Qin, M. A. Seaton
 *     copyright: UKRI STFC Daresbury Laboratory and CCP5
 *     2005, 2018
 */
class dllbe extends JPanel {

    dlmesoguiEvt lbev=new dlmesoguiEvt(this);

    JButton defsys = new JButton("Define LBE System");
    JButton setspa =new JButton("Set LBE Space");
    JButton changecode =new JButton("Change LBE Code");
    JButton compile =new JButton("Compile LBE Code");
    JButton runcode =new JButton("Run LBE Program");    
    JButton gatherdata =new JButton("Gather LBE Data");
    JButton plotlbe =new JButton("Plot LBE Results");
    JButton closelbe = new JButton("Close LBE Panel");
    JLabel lb1 =new JLabel("Lattice Boltzmann", JLabel.CENTER);
    Font buttonfont=new Font("Serif", Font.BOLD, 16);
    Color bgcolor=new Color(170, 200, 190);
    Color focolor=new Color(10, 10, 15);

    public dllbe() {
	setSize(160, 530);
	GridLayout lbelayout =new GridLayout(9, 1, 10, 10);
	setLayout(lbelayout);

	add(lb1);

	defsys.setFont(buttonfont);
	defsys.setBackground(bgcolor);
	defsys.setForeground(focolor);
	defsys.addActionListener(lbev);
	add(defsys);

	setspa.setFont(buttonfont);
	setspa.setBackground(bgcolor);
	setspa.setForeground(focolor);
	setspa.addActionListener(lbev);
	add(setspa);	

	changecode.setFont(buttonfont);
	changecode.setBackground(bgcolor);
	changecode.setForeground(focolor);
	changecode.addActionListener(lbev);
	add(changecode);

	compile.setFont(buttonfont);
	compile.setBackground(bgcolor);
	compile.setForeground(focolor);
	compile.addActionListener(lbev);
	add(compile);

	runcode.setFont(buttonfont);
	runcode.setBackground(bgcolor);
	runcode.setForeground(focolor);
	runcode.addActionListener(lbev);
	add(runcode);

	gatherdata.setFont(buttonfont);
	gatherdata.setBackground(bgcolor);
	gatherdata.setForeground(focolor);
	gatherdata.addActionListener(lbev);
	add(gatherdata);
	
	plotlbe.setFont(buttonfont);
	plotlbe.setBackground(bgcolor);
	plotlbe.setForeground(focolor);
	plotlbe.addActionListener(lbev);
	add(plotlbe);

	closelbe.setFont(buttonfont);
	closelbe.setBackground(bgcolor);
	closelbe.setForeground(focolor);
	closelbe.addActionListener(lbev);
	add(closelbe);	
    }
}
