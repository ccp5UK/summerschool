int fD2Q9VCEKinetic(double v0, double v1, double *force, double *f0, double *f1, double *f2,
                    double *f3, double *f4, double *f5, double *f6, double *f7, double *f8);
int fD2Q9VCCKinetic(double *p, double v0, double v1, double *force, double *f0, double *f1, double *f2,
                    double *f3, double *f4, double *f5, double *f6, double *f7, double *f8);
int fD2Q9VCECLBEKinetic(double v0, double v1, double *force, double *f0, double *f1, double *f2,
                        double *f3, double *f4, double *f5, double *f6, double *f7, double *f8);
int fD2Q9VCCCLBEKinetic(double *p, double v0, double v1, double *force, double *f0, double *f1, double *f2,
                        double *f3, double *f4, double *f5, double *f6, double *f7, double *f8);
int fD2Q9VCESwiftKinetic(double v0, double v1, double *force, double *f0, double *f1, double *f2,
                         double *f3, double *f4, double *f5, double *f6, double *f7, double *f8,
                         double drdx, double drdy, double dpdx, double dpdy, double nabr, double nabp, double *omega, double T);
int fD2Q9VCCSwiftKinetic(double *p, double v0, double v1, double *force, double *f0, double *f1, double *f2,
                         double *f3, double *f4, double *f5, double *f6, double *f7, double *f8,
                         double drdx, double drdy, double dpdx, double dpdy, double nabr, double nabp, double *omega, double T);
int fD2Q9VFKinetic(long tpos, long tpos1, int prop, double *uwall, double dx, double dy, double T);
int fD2Q9PCEKinetic(double *p, double *force, double *f0, double *f1, double *f2, double *f3,
                    double *f4, double *f5, double *f6, double *f7, double *f8, double &vel);
int fD2Q9PCESwiftKinetic(double *p, double *force, double *f0, double *f1, double *f2, double *f3,
                         double *f4, double *f5, double *f6, double *f7, double *f8,
                         double drdx, double drdy, double dpdx, double dpdy, double nabr, double napr,
                         double *omega, double T, double &vel);
int fD2Q9PFKinetic(long tpos, int prop, double *p0, double *uwall, double T);

int fD3Q15VPSKinetic(double v0, double v1, double v2, double *force, double *f0, double *f1, double *f2,
                     double *f3, double *f4, double *f5, double *f6, double *f7, double *f8,
                     double *f9, double *f10, double *f11, double *f12, double *f13, double *f14);
int fD3Q15VCEKinetic(double *p, double v0, double v1, double v2, double *force, double *f0, double *f1, double *f2,
                     double *f3, double *f4, double *f5, double *f6, double *f7, double *f8,
                     double *f9, double *f10, double *f11, double *f12, double *f13, double *f14);
int fD3Q15VCCKinetic(double *p, double v0, double v1, double v2, double *force, double *f0, double *f1, double *f2,
                     double *f3, double *f4, double *f5, double *f6, double *f7, double *f8,
                     double *f9, double *f10, double *f11, double *f12, double *f13, double *f14);
int fD3Q15VPSSwiftKinetic(double v0, double v1, double v2, double *force, double *f0, double *f1, double *f2,
                          double *f3, double *f4, double *f5, double *f6, double *f7, double *f8,
                          double *f9, double *f10, double *f11, double *f12, double *f13, double *f14,
                          double drdx, double drdy, double drdz, double dpdx, double dpdy, double dpdz,
                          double nabr, double nabp, double *omega, double T);
int fD3Q15VCESwiftKinetic(double *p, double v0, double v1, double v2, double *force, double *f0, double *f1, double *f2,
                          double *f3, double *f4, double *f5, double *f6, double *f7, double *f8,
                          double *f9, double *f10, double *f11, double *f12, double *f13, double *f14,
                          double drdx, double drdy, double drdz, double dpdx, double dpdy, double dpdz,
                          double nabr, double nabp, double *omega, double T);
int fD3Q15VCCSwiftKinetic(double *p, double v0, double v1, double v2, double *force, double *f0, double *f1, double *f2,
                          double *f3, double *f4, double *f5, double *f6, double *f7, double *f8,
                          double *f9, double *f10, double *f11, double *f12, double *f13, double *f14,
                          double drdx, double drdy, double drdz, double dpdx, double dpdy, double dpdz,
                          double nabr, double nabp, double *omega, double T);
int fD3Q15VFKinetic(long tpos, long rpos, int prop, double *uwall, double dx, double dy, double dz, double T);
int fD3Q15PPSKinetic(double *p, double *force, double *f0, double *f1,
                     double *f2, double *f3, double *f4, double *f5,
                     double *f6, double *f7, double *f8, double *f9,
                     double *f10, double *f11, double *f12, double *f13,
                     double *f14, double &vel);
int fD3Q15PPSSwiftKinetic(double *p, double *force, double *f0, double *f1,
                          double *f2, double *f3, double *f4, double *f5,
                          double *f6, double *f7, double *f8, double *f9,
                          double *f10, double *f11, double *f12, double *f13,
                          double *f14, double drdx, double drdy, double drdz,
                          double dpdx, double dpdy, double dpdz, double nabr,
                          double nabp, double *omega, double T, double &vel);
int fD3Q15PFKinetic(long tpos, int prop, double *p0, double *uwall, double T);

int fD3Q19VPSKinetic(double v0, double v1, double v2, double *force, double *f0, double *f1, double *f2,
                     double *f3, double *f4, double *f5, double *f6, double *f7, double *f8,
                     double *f9, double *f10, double *f11, double *f12, double *f13, double *f14,
                     double *f15, double *f16, double *f17, double *f18);
int fD3Q19VCEKinetic(double *p, double v0, double v1, double v2, double *force, double *f0, double *f1, double *f2,
                     double *f3, double *f4, double *f5, double *f6, double *f7, double *f8,
                     double *f9, double *f10, double *f11, double *f12, double *f13, double *f14,
                     double *f15, double *f16, double *f17, double *f18);
int fD3Q19VCCKinetic(double *p, double v0, double v1, double v2, double *force, double *f0, double *f1, double *f2,
                     double *f3, double *f4, double *f5, double *f6, double *f7, double *f8,
                     double *f9, double *f10, double *f11, double *f12, double *f13, double *f14,
                     double *f15, double *f16, double *f17, double *f18);
int fD3Q19VPSCLBEKinetic(double v0, double v1, double v2, double *force, double *f0, double *f1, double *f2,
                         double *f3, double *f4, double *f5, double *f6, double *f7, double *f8,
                         double *f9, double *f10, double *f11, double *f12, double *f13, double *f14,
                         double *f15, double *f16, double *f17, double *f18);
int fD3Q19VCECLBEKinetic(double *p, double v0, double v1, double v2, double *force, double *f0, double *f1, double *f2,
                         double *f3, double *f4, double *f5, double *f6, double *f7, double *f8,
                         double *f9, double *f10, double *f11, double *f12, double *f13, double *f14,
                         double *f15, double *f16, double *f17, double *f18);
int fD3Q19VCCCLBEKinetic(double *p, double v0, double v1, double v2, double *force, double *f0, double *f1, double *f2,
                         double *f3, double *f4, double *f5, double *f6, double *f7, double *f8,
                         double *f9, double *f10, double *f11, double *f12, double *f13, double *f14,
                         double *f15, double *f16, double *f17, double *f18);
int fD3Q19VPSSwiftKinetic(double v0, double v1, double v2, double *force, double *f0, double *f1, double *f2,
                          double *f3, double *f4, double *f5, double *f6, double *f7, double *f8,
                          double *f9, double *f10, double *f11, double *f12, double *f13, double *f14,
                          double *f15, double *f16, double *f17, double *f18,
                          double drdx, double drdy, double drdz, double dpdx, double dpdy, double dpdz,
                          double nabr, double nabp, double *omega, double T);
int fD3Q19VCESwiftKinetic(double *p, double v0, double v1, double v2, double *force, double *f0, double *f1, double *f2,
                          double *f3, double *f4, double *f5, double *f6, double *f7, double *f8,
                          double *f9, double *f10, double *f11, double *f12, double *f13, double *f14,
                          double *f15, double *f16, double *f17, double *f18,
                          double drdx, double drdy, double drdz, double dpdx, double dpdy, double dpdz,
                          double nabr, double nabp, double *omega, double T);
int fD3Q19VCCSwiftKinetic(double *p, double v0, double v1, double v2, double *force, double *f0, double *f1, double *f2,
                          double *f3, double *f4, double *f5, double *f6, double *f7, double *f8,
                          double *f9, double *f10, double *f11, double *f12, double *f13, double *f14,
                          double *f15, double *f16, double *f17, double *f18,
                          double drdx, double drdy, double drdz, double dpdx, double dpdy, double dpdz,
                          double nabr, double nabp, double *omega, double T);
int fD3Q19VFKinetic(long tpos, long rpos, int prop, double *uwall, double dx, double dy, double dz, double T);
int fD3Q19PPSKinetic(double *p, double *force, double *f0, double *f1,
                     double *f2, double *f3, double *f4, double *f5,
                     double *f6, double *f7, double *f8, double *f9,
                     double *f10, double *f11, double *f12, double *f13,
                     double *f14, double *f15, double *f16, double *f17,
                     double *f18, double &vel);
int fD3Q19PPSSwiftKinetic(double *p, double *force, double *f0, double *f1,
                          double *f2, double *f3, double *f4, double *f5,
                          double *f6, double *f7, double *f8, double *f9,
                          double *f10, double *f11, double *f12, double *f13,
                          double *f14, double *f15, double *f16, double *f17,
                          double *f18, double drdx, double drdy, double drdz,
                          double dpdx, double dpdy, double dpdz, double nabr,
                          double nabp, double *omega, double T, double &vel);
int fD3Q19PFKinetic(long tpos, int prop, double *p0, double *uwall, double T);

int fD3Q27VPSKinetic(double v0, double v1, double v2, double *force, double *f0, double *f1, double *f2,
                     double *f3, double *f4, double *f5, double *f6, double *f7, double *f8,
                     double *f9, double *f10, double *f11, double *f12, double *f13, double *f14,
                     double *f15, double *f16, double *f17, double *f18, double *f19, double *f20,
                     double *f21, double *f22, double *f23, double *f24, double *f25, double *f26);
int fD3Q27VCEKinetic(double *p, double v0, double v1, double v2, double *force, double *f0, double *f1, double *f2,
                     double *f3, double *f4, double *f5, double *f6, double *f7, double *f8,
                     double *f9, double *f10, double *f11, double *f12, double *f13, double *f14,
                     double *f15, double *f16, double *f17, double *f18, double *f19, double *f20,
                     double *f21, double *f22, double *f23, double *f24, double *f25, double *f26);
int fD3Q27VCCKinetic(double *p, double v0, double v1, double v2, double *force, double *f0, double *f1, double *f2,
                     double *f3, double *f4, double *f5, double *f6, double *f7, double *f8,
                     double *f9, double *f10, double *f11, double *f12, double *f13, double *f14,
                     double *f15, double *f16, double *f17, double *f18, double *f19, double *f20,
                     double *f21, double *f22, double *f23, double *f24, double *f25, double *f26);
int fD3Q27VPSCLBEKinetic(double v0, double v1, double v2, double *force, double *f0, double *f1, double *f2,
                         double *f3, double *f4, double *f5, double *f6, double *f7, double *f8,
                         double *f9, double *f10, double *f11, double *f12, double *f13, double *f14,
                         double *f15, double *f16, double *f17, double *f18, double *f19, double *f20,
                         double *f21, double *f22, double *f23, double *f24, double *f25, double *f26);
int fD3Q27VCECLBEKinetic(double *p, double v0, double v1, double v2, double *force, double *f0, double *f1, double *f2,
                         double *f3, double *f4, double *f5, double *f6, double *f7, double *f8,
                         double *f9, double *f10, double *f11, double *f12, double *f13, double *f14,
                         double *f15, double *f16, double *f17, double *f18, double *f19, double *f20,
                         double *f21, double *f22, double *f23, double *f24, double *f25, double *f26);
int fD3Q27VCCCLBEKinetic(double *p, double v0, double v1, double v2, double *force, double *f0, double *f1, double *f2,
                         double *f3, double *f4, double *f5, double *f6, double *f7, double *f8,
                         double *f9, double *f10, double *f11, double *f12, double *f13, double *f14,
                         double *f15, double *f16, double *f17, double *f18, double *f19, double *f20,
                         double *f21, double *f22, double *f23, double *f24, double *f25, double *f26);
int fD3Q27VFKinetic(long tpos, long rpos, int prop, double *uwall);
int fD3Q27PPSKinetic(double *p, double *force, double *f0, double *f1,
                     double *f2, double *f3, double *f4, double *f5,
                     double *f6, double *f7, double *f8, double *f9,
                     double *f10, double *f11, double *f12, double *f13,
                     double *f14, double *f15, double *f16, double *f17,
                     double *f18, double *f19, double *f20, double *f21,
                     double *f22, double *f23, double *f24, double *f25,
                     double *f26, double &vel);
int fD3Q27PFKinetic(long tpos, int prop, double *p0, double *uwall);
