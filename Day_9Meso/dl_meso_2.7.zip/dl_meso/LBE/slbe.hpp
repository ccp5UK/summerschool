#include <iostream>
#include <fstream>
#include <cstdlib>
#include <ctime>
#include <cstdio>
#include <cmath>
#include <iomanip>
#include <string>
#include <cstring>
#include <sstream>
#include <vector>
#include <sys/time.h>
#include <sys/stat.h>
#ifdef _OPENMP
#include <omp.h>
#else
#define omp_get_num_thread() 1
#define omp_get_thread_num() 0
#endif
using namespace std;

/*
  DL_MESO_LBE
  Author    :   R.S. Qin, M. A. Seaton
  Copyright :   STFC Daresbury Laboratory
            :   05/11/2004, rev. 09/12/2018

*/  

#include "lbe.hpp"

typedef struct
{
    int rank;
    int cartCoords[3];
    int size;
    int rootRank;
    int groupId;
    int cartStart[3];
    int cartEnd[3];
    int gridStartGlobal[3];
    int gridEndGlobal[3];
    int subgrid[3];
}
sIOGroup;

sIOGroup lbIOGroup;

#include "lbpBASIC.hpp"
#include "lbpGET.hpp"
#include "lbpIOAGGSER.hpp"
#include "lbpMODEL.hpp"
#include "lbpIO.hpp"
#include "lbpIOPlot3D.hpp"
#include "lbpIOLegacyVTK.hpp"
#include "lbpIOVTK.hpp"
#include "lbpFORCE.hpp"
#include "lbpRHEOLOGY.hpp"
#include "lbpBGK.hpp"
#include "lbpTRT.hpp"
#include "lbpMRT.hpp"
#include "lbpCLBE.hpp"
#include "lbpSUB.hpp"
#include "lbpBOUND.hpp"
#include "lbpBOUNDZouHe.hpp"
#include "lbpBOUNDInamuro.hpp"
#include "lbpBOUNDRegular.hpp"
#include "lbpBOUNDKinetic.hpp"
#include "lbpUSER.hpp"
#include "lbpRUNSER.hpp"
#include "lbpBASIC.cpp"
#include "lbpGET.cpp"
#include "lbpIOAGGSER.cpp"
#include "lbpMODEL.cpp"
#include "lbpIO.cpp"
#include "lbpIOPlot3D.cpp"
#include "lbpIOLegacyVTK.cpp"
#include "lbpIOVTK.cpp"
#include "lbpFORCE.cpp"
#include "lbpRHEOLOGY.cpp"
#include "lbpBGK.cpp"
#include "lbpTRT.cpp"
#include "lbpMRT.cpp"
#include "lbpCLBE.cpp"
#include "lbpSUB.cpp"
#include "lbpBOUND.cpp"
#include "lbpBOUNDZouHe.cpp"
#include "lbpBOUNDInamuro.cpp"
#include "lbpBOUNDRegular.cpp"
#include "lbpBOUNDKinetic.cpp"
#include "lbpUSER.cpp"
#include "lbpRUNSER.cpp"

