/***************************************************
 *   DL_MESO       Version 2.7                     *
 *   Authors   :   R. S. Qin, M. A. Seaton         *
 *   Copyright :   UKRI STFC Daresbury Laboratory  *
 *             :   09/12/2018                      *
 ***************************************************/

long fNextStep(int q, int xpos, int ypos, int zpos)
{

  // find position of particle for next time step when moving along q 
  // direction to nearest neighbour

  return (fCppMod(xpos+lbvx[q], lbdm.xouter) * lbdm.youter
    + fCppMod(ypos+lbvy[q], lbdm.youter)) * lbdm.zouter
    + fCppMod(zpos+lbvz[q], lbdm.zouter);
}

long fNextStep(int q, int xpos, int ypos)
{

  // find position of particle for next time step when moving along q 
  // direction to nearest neighbour

  return fCppMod(xpos+lbvx[q], lbdm.xouter) * lbdm.youter
    + fCppMod(ypos+lbvy[q], lbdm.youter);
}

long fNextStep(int dx, int dy, int dz, long tpos)
{

  // find position of particle for next time step when moving along (dx, dy, dz)
  // direction to nearest neighbour
  int xpos, ypos, zpos;
  fGetCoord(tpos, xpos, ypos, zpos);
  return (fCppMod(xpos+dx, lbdm.xouter) * lbdm.youter 
    + fCppMod(ypos+dy, lbdm.youter)) * lbdm.zouter 
    + fCppMod(zpos+dz, lbdm.zouter);
}


int fMoveNonzeroAway(long tpos)
{
  int xpos, ypos, zpos;
  long spos, pos1;
  int qdim = lbsy.nf+lbsy.nc+lbsy.nt;
  int q;
  pos1 = tpos * lbsitelength;
  fGetCoord(tpos, xpos, ypos, zpos);
  for(int m=0; m<lbsitelength-lbsy.pf; m++)
    if(lbf[pos1+m] != 0) {
      q  = m / qdim;
      spos = fNextStep(q, xpos, ypos, zpos);
      lbf[spos * lbsitelength + m] += lbf[pos1+m];
      lbf[pos1+m] =0.0;
    }
  return 0;
}


int fBounceBackF(long tpos)
{

  // perform on-grid bounce-back for fluid distribution function
  
  long stpos=tpos * lbsitelength;
  int half = (lbsy.nq - 1) / 2;
  int qdim = lbsy.nf+lbsy.nc+lbsy.nt;

  for(int m=1; m<=half; m++)
    for(int j=0; j<lbsy.nf; j++)
      fSwapPair (lbf[stpos + m*qdim + j], lbf[stpos + (m+half)*qdim + j]);
    
/*
  for(int j=0; j<lbsy.nf; j++) {
    for(int m=0; m<lbsy.nq; m++) 
      lbfeq[lbopv[m]] = lbf[stpos + j*lbsy.nq + m];
    for(int m=0; m<lbsy.nq; m++)
      lbf[stpos + j*lbsy.nq + m] = lbfeq[m];
  } 
*/
    
  return 0;
}


int fBounceBackC(long tpos)
{

  // perform on-grid bounce-back for solute distribution function
  
  long stpos=tpos * lbsitelength + lbsy.nf;
  int half = (lbsy.nq - 1) / 2;
  int qdim = lbsy.nf+lbsy.nc+lbsy.nt;

  for(int m=1; m<=half; m++)
    for(int j=0; j<lbsy.nc; j++)
      fSwapPair (lbf[stpos + m*qdim + j], lbf[stpos + (m+half)*qdim + j]);
        
/*
  for(int j=0; j<lbsy.nc; j++) {
    for(int m=0; m<lbsy.nq; m++) 
      lbfeq[lbopv[m]] = lbf[stpos +j*lbsy.nq+ m];
    for(int m=0; m<lbsy.nq; m++)
      lbf[stpos +j*lbsy.nq+ m] = lbfeq[m];
  }    
*/

  return 0;
}


int fBounceBackT(long tpos)
{

  // perform on-grid bounce-back for temperature distribution function
  
  long stpos=tpos * lbsitelength + lbsy.nf + lbsy.nc;
  int half = (lbsy.nq - 1) / 2;
  int qdim = lbsy.nf+lbsy.nc+lbsy.nt;

  for(int m=1; m<=half; m++)
    for(int j=0; j<lbsy.nt; j++)
      fSwapPair (lbf[stpos + m*qdim], lbf[stpos + (m+half)*qdim]);
  
/*  for(int j=0; j<lbsy.nt; j++) {
      for(int m=0; m<lbsy.nq; m++)
        lbfeq[lbopv[m]] = lbf[stpos + m];
      for(int m=0; m<lbsy.nq; m++)
        lbf[stpos + m] = lbfeq[m];
      stpos += lbsy.nq;
    }
*/
    
  return 0;
}

int fMidBounceBackF(long tpos)
{

  // perform mid-link bounce-back for fluid distribution function
  
  long stpos= tpos * lbsitelength;
  long spos;
  int xpos, ypos, zpos;
  int qdim = lbsy.nf+lbsy.nc+lbsy.nt;

  fGetCoord(tpos, xpos, ypos, zpos); 
  for(int m=0; m<lbsy.nq; m++) {
    for(int j=0; j<lbsy.nf; j++) {
      spos = fNextStep(m, xpos, ypos, zpos);
      lbf[stpos + m*qdim + j] = lbf[spos * lbsitelength + lbopv[m]*qdim + j];
    }

  }
  return 0;
}


int fMidBounceBackC(long tpos)
{

  // perform mid-link bounce-back for solute distribution function
  
  long stpos=tpos * lbsitelength + lbsy.nf;
  long spos;
  int xpos, ypos, zpos;
  int qdim = lbsy.nf+lbsy.nc+lbsy.nt;

  fGetCoord(tpos, xpos, ypos, zpos);   
  for(int m=0; m<lbsy.nq; m++) {
    for(int j=0; j<lbsy.nc; j++) {
      spos = fNextStep(m, xpos, ypos, zpos);
      lbf[stpos + m*qdim + j] = lbf[spos * lbsitelength + (lbsy.nf + j) + lbopv[m]*qdim];
    }

  }    
  
  return 0;
}


int fMidBounceBackT(long tpos)
{

  // perform mid-link bounce-back for temperature distribution function
  
  long stpos=tpos * lbsitelength + lbsy.nf + lbsy.nc;
  long spos;
  int xpos, ypos, zpos;
  int qdim = lbsy.nf+lbsy.nc+lbsy.nt;

  fGetCoord(tpos, xpos, ypos, zpos);   
  for(int m=0; m<lbsy.nq; m++) {
    for(int j=0; j<lbsy.nt; j++) {
      spos = fNextStep(m, xpos, ypos, zpos);
      lbf[stpos + m*qdim] = lbf[spos * lbsitelength + (lbsy.nf + lbsy.nc) + lbopv[m]*qdim];
    }

  }    
  
  return 0;
}


int fSiteBlankF(long tpos)
{

  // set fluid distribution function at grid point tpos to zero (solid block)

  double *pt2 = &lbf[tpos * lbsitelength];
  int qdim = lbsy.nf+lbsy.nc+lbsy.nt;
  for(int m=0; m<lbsy.nq; m++) {
    for(int j=0; j<lbsy.nf; j++){
      pt2[m*qdim+j] = 0;
    }
  }
  pt2 = NULL;
  return 0;
}


int fSiteBlankC(long tpos)
{

  // set solute distribution function at grid point tpos to zero (solid block)

  double *pt2 = &lbf[tpos * lbsitelength + lbsy.nf];
  int qdim = lbsy.nf+lbsy.nc+lbsy.nt;
  for(int m=0; m<lbsy.nq; m++) {
    for(int j=0; j<lbsy.nc; j++){
      pt2[m*qdim+j] = 0;
    }
  }
  pt2 = NULL;
  return 0;
}

int fSiteBlankT(long tpos)
{

  // set temperature distribution function at grid point tpos to zero (solid 
  // block)
  
  double *pt2 = &lbf[tpos * lbsitelength + (lbsy.nf+lbsy.nc)*lbsy.nq];
  int qdim = lbsy.nf+lbsy.nc+lbsy.nt;
  for(int m=0; m<lbsy.nq; m++) {
    for(int j=0; j<lbsy.nt; j++){
      pt2[m*qdim+j] = 0;
    }
  }
  pt2 = NULL;
  return 0;
}

// fraction/concentration at corners and edges

int fD2CCFracSite(double *frac, long tpos)
{
  // calculate fluid densities at bottom left corner boundary (CCTRF) for fluids
  double invallmass,allmass = 0.0;
    
  fGetAllMassSite(frac, &lbf[tpos*lbsitelength]);
  for(int i=0; i<lbsy.nf; i++)
    allmass += frac[i];
  invallmass = fReciprocal(allmass);
  for(int i=0; i<lbsy.nf; i++)
    frac[i] *= invallmass;
    
  return 0;
}

double fD2CCSwiftPhi(long tpos, double dx, double dy, double dpdx, double dpdy)
{
    
  // calculate concentration at bottom left corner boundary (CCTRF) for fluids
  // with Swift free-energy interactions

  double phi = fGetOneMassSite(&lbf[tpos*lbsitelength+1])+dx*dpdx+dy*dpdy;
  return phi;
}

int fD3CECCFracSite(double *frac, long tpos)
{
  // calculate fluid densities at bottom left edge (CETR)
  // or bottom left back corner (CCTRF) for fluids
    
  double invallmass,allmass = 0.0;
  
  fGetAllMassSite(frac, &lbf[tpos*lbsitelength]);
  for(int i=0; i<lbsy.nf; i++)
    allmass += frac[i];
  invallmass = fReciprocal(allmass);
  for(int i=0; i<lbsy.nf; i++)
    frac[i] *= invallmass;
    
  return 0;
}

double fD3CECCSwiftPhi(long tpos, double dx, double dy, double dz, double dpdx, double dpdy, double dpdz)
{
  // calculate concentration at bottom left edge (CETR)
  // or bottom left back corner (CCTRF) for fluids
  // with Swift free-energy interactions
    
  double phi = fGetOneMassSite(&lbf[tpos*lbsitelength+1])+dx*dpdx+dy*dpdy+dz*dpdz;
  return phi;
}

// D2Q9

int fD2Q9CEFracSite(double *frac, double vy, double *f0, double *f1, double *f2, double *f3, double *f4, double *f5, double *f6, double *f7, double *f8)
{
  // calculate fluid densities at bottom boundary (CETF) for fluids
  double invallmass,allmass = 0.0;
    
  for(int i=0; i<lbsy.nf; i++) {
    frac[i] = (f0[i]+f2[i]+f6[i]+2.0*(f3[i]+f4[i]+f5[i]))/(1.0-vy);
    allmass += frac[i];
  }
  invallmass = fReciprocal(allmass);
  for(int i=0; i<lbsy.nf; i++)
    frac[i] *= invallmass;
    
  return 0;
}

double fD2Q9CESwiftPhi(double vy, double g0, double g1, double g2, double g3, double g4, double g5, double g6, double g7, double g8)
{
    
  // calculate concentration at bottom boundary (CETF) for fluids
  // with Swift free-energy interactions
    
  double phi = (g0+g2+g6+2.0*(g3+g4+g5))/(1.0-vy);
  return phi;
}

int fD2Q9BoundaryForceVelocity(double *force, long tpos, long tpos1, double dx, double dy, double *uwall, int prop)
{
  // calculate forces required at constant velocity boundary point for D2Q9 lattice

  long spos = tpos * lbsitelength;
  int qdim = lbsy.nf+lbsy.nc+lbsy.nt;
  double frac[lbsy.nf];
  double phi, freq = (lbbdforcetyp==1)*sin(lboscilfreq*(lbcurstep-lbequstep));

  switch (prop) {
    case CCTRF:
      if(interact==20 && lbsy.nf>1) {
        phi = fD2CCSwiftPhi(tpos1, dx, dy, lbft[4*lbsy.nf*tpos+4], lbft[4*lbsy.nf*tpos+5]);
        force[0] = 0.5*(1.0+phi)*(lbinterforce[tpos*3*lbsy.nf  ] + lbheatforce[tpos*3*lbsy.nf  ] + postequil*(lbbdforce[0]+lboscilforce[0]*freq))
                 + 0.5*(1.0-phi)*(lbinterforce[tpos*3*lbsy.nf+3] + lbheatforce[tpos*3*lbsy.nf+3] + postequil*(lbbdforce[3]+lboscilforce[3]*freq));
        force[1] = 0.5*(1.0+phi)*(lbinterforce[tpos*3*lbsy.nf+1] + lbheatforce[tpos*3*lbsy.nf+1] + postequil*(lbbdforce[1]+lboscilforce[1]*freq))
                 + 0.5*(1.0-phi)*(lbinterforce[tpos*3*lbsy.nf+4] + lbheatforce[tpos*3*lbsy.nf+4] + postequil*(lbbdforce[4]+lboscilforce[4]*freq));
        force[2] = 0.0;
        force[3] = 0.0;
      }
      else {
        if(interact>9 && interact<20) {
          fD2CCFracSite(frac, tpos1);
          for(int i=0; i<lbsy.nf; i++) {
            force[2*i  ] = frac[i] * lbinterforce[tpos*3  ] + lbheatforce[tpos*3*lbsy.nf+3*i  ] + postequil * (lbbdforce[3*i  ]+lboscilforce[3*i  ]*freq);
            force[2*i+1] = frac[i] * lbinterforce[tpos*3+1] + lbheatforce[tpos*3*lbsy.nf+3*i+1] + postequil * (lbbdforce[3*i+1]+lboscilforce[3*i+1]*freq);
          }
        }
        else {
          for(int i=0; i<lbsy.nf; i++) {
            force[2*i  ] = lbinterforce[tpos*3*lbsy.nf+3*i  ] + lbheatforce[tpos*3*lbsy.nf+3*i  ] + postequil * (lbbdforce[3*i  ]+lboscilforce[3*i  ]*freq);
            force[2*i+1] = lbinterforce[tpos*3*lbsy.nf+3*i+1] + lbheatforce[tpos*3*lbsy.nf+3*i+1] + postequil * (lbbdforce[3*i+1]+lboscilforce[3*i+1]*freq);
          }
        }
      }
      break;
    case CCTLF:
      if(interact==20 && lbsy.nf>1) {
        phi = fD2CCSwiftPhi(tpos1, dx, dy, lbft[4*lbsy.nf*tpos+4], lbft[4*lbsy.nf*tpos+5]);
        force[1] = -0.5*(1.0+phi)*(lbinterforce[tpos*3*lbsy.nf  ] + lbheatforce[tpos*3*lbsy.nf  ] + postequil*(lbbdforce[0]+lboscilforce[0]*freq))
                 -  0.5*(1.0-phi)*(lbinterforce[tpos*3*lbsy.nf+3] + lbheatforce[tpos*3*lbsy.nf+3] + postequil*(lbbdforce[3]+lboscilforce[3]*freq));
        force[0] =  0.5*(1.0+phi)*(lbinterforce[tpos*3*lbsy.nf+1] + lbheatforce[tpos*3*lbsy.nf+1] + postequil*(lbbdforce[1]+lboscilforce[1]*freq))
                 +  0.5*(1.0-phi)*(lbinterforce[tpos*3*lbsy.nf+4] + lbheatforce[tpos*3*lbsy.nf+4] + postequil*(lbbdforce[4]+lboscilforce[4]*freq));
        force[2] =  0.0;
        force[3] =  0.0;
      }
      else {
        if(interact>9 && interact<20) {
          fD2CCFracSite(frac, tpos1);
          for(int i=0; i<lbsy.nf; i++) {
            force[2*i+1] = -frac[i] * lbinterforce[tpos*3  ] - lbheatforce[tpos*3*lbsy.nf+3*i  ] - postequil * (lbbdforce[3*i  ]+lboscilforce[3*i  ]*freq);
            force[2*i  ] =  frac[i] * lbinterforce[tpos*3+1] + lbheatforce[tpos*3*lbsy.nf+3*i+1] + postequil * (lbbdforce[3*i+1]+lboscilforce[3*i+1]*freq);
          }
        }
        else {
          for(int i=0; i<lbsy.nf; i++) {
            force[2*i+1] = -lbinterforce[tpos*3*lbsy.nf+3*i  ] - lbheatforce[tpos*3*lbsy.nf+3*i  ] - postequil * (lbbdforce[3*i  ]+lboscilforce[3*i  ]*freq);
            force[2*i  ] =  lbinterforce[tpos*3*lbsy.nf+3*i+1] + lbheatforce[tpos*3*lbsy.nf+3*i+1] + postequil * (lbbdforce[3*i+1]+lboscilforce[3*i+1]*freq);
          }
        }
      }
      break;
    case CCDLF:
      if(interact==20 && lbsy.nf>1) {
        phi = fD2CCSwiftPhi(tpos1, dx, dy, lbft[4*lbsy.nf*tpos+4], lbft[4*lbsy.nf*tpos+5]);
        force[0] = -0.5*(1.0+phi)*(lbinterforce[tpos*3*lbsy.nf  ] + lbheatforce[tpos*3*lbsy.nf  ] + postequil*(lbbdforce[0]+lboscilforce[0]*freq))
                 -  0.5*(1.0-phi)*(lbinterforce[tpos*3*lbsy.nf+3] + lbheatforce[tpos*3*lbsy.nf+3] + postequil*(lbbdforce[3]+lboscilforce[3]*freq));
        force[1] = -0.5*(1.0+phi)*(lbinterforce[tpos*3*lbsy.nf+1] + lbheatforce[tpos*3*lbsy.nf+1] + postequil*(lbbdforce[1]+lboscilforce[1]*freq))
                 -  0.5*(1.0-phi)*(lbinterforce[tpos*3*lbsy.nf+4] + lbheatforce[tpos*3*lbsy.nf+4] + postequil*(lbbdforce[4]+lboscilforce[4]*freq));
        force[2] =  0.0;
        force[3] =  0.0;
      }
      else {
        if(interact>9 && interact<20) {
          fD2CCFracSite(frac, tpos1);
          for(int i=0; i<lbsy.nf; i++) {
            force[2*i  ] = -frac[i] * lbinterforce[tpos*3  ] - lbheatforce[tpos*3*lbsy.nf+3*i  ] - postequil * (lbbdforce[3*i  ]+lboscilforce[3*i  ]*freq);
            force[2*i+1] = -frac[i] * lbinterforce[tpos*3+1] - lbheatforce[tpos*3*lbsy.nf+3*i+1] - postequil * (lbbdforce[3*i+1]+lboscilforce[3*i+1]*freq);
          }
        }
        else {
          for(int i=0; i<lbsy.nf; i++) {
            force[2*i  ] = -lbinterforce[tpos*3*lbsy.nf+3*i  ] - lbheatforce[tpos*3*lbsy.nf+3*i  ] - postequil * (lbbdforce[3*i  ]+lboscilforce[3*i  ]*freq);
            force[2*i+1] = -lbinterforce[tpos*3*lbsy.nf+3*i+1] - lbheatforce[tpos*3*lbsy.nf+3*i+1] - postequil * (lbbdforce[3*i+1]+lboscilforce[3*i+1]*freq);
          }
        }
      }
      break;
    case CCDRF:
      if(interact==20 && lbsy.nf>1) {
        phi = fD2CCSwiftPhi(tpos1, dx, dy, lbft[4*lbsy.nf*tpos+4], lbft[4*lbsy.nf*tpos+5]);
        force[1] =  0.5*(1.0+phi)*(lbinterforce[tpos*3*lbsy.nf  ] + lbheatforce[tpos*3*lbsy.nf  ] + postequil*(lbbdforce[0]+lboscilforce[0]*freq))
                 +  0.5*(1.0-phi)*(lbinterforce[tpos*3*lbsy.nf+3] + lbheatforce[tpos*3*lbsy.nf+3] + postequil*(lbbdforce[3]+lboscilforce[3]*freq));
        force[0] = -0.5*(1.0+phi)*(lbinterforce[tpos*3*lbsy.nf+1] + lbheatforce[tpos*3*lbsy.nf+1] + postequil*(lbbdforce[1]+lboscilforce[1]*freq))
                 -  0.5*(1.0-phi)*(lbinterforce[tpos*3*lbsy.nf+4] + lbheatforce[tpos*3*lbsy.nf+4] + postequil*(lbbdforce[4]+lboscilforce[4]*freq));
        force[2] =  0.0;
        force[3] =  0.0;
      }
      else {
        if(interact>9 && interact<20) {
          fD2CCFracSite(frac, tpos1);
          for(int i=0; i<lbsy.nf; i++) {
            force[2*i+1] =  frac[i] * lbinterforce[tpos*3  ] + lbheatforce[tpos*3*lbsy.nf+3*i  ] + postequil * (lbbdforce[3*i  ]+lboscilforce[3*i  ]*freq);
            force[2*i  ] = -frac[i] * lbinterforce[tpos*3+1] - lbheatforce[tpos*3*lbsy.nf+3*i+1] - postequil * (lbbdforce[3*i+1]+lboscilforce[3*i+1]*freq);
          }
        }
        else {
          for(int i=0; i<lbsy.nf; i++) {
            force[2*i+1] =  lbinterforce[tpos*3*lbsy.nf+3*i  ] + lbheatforce[tpos*3*lbsy.nf+3*i  ] + postequil * (lbbdforce[3*i  ]+lboscilforce[3*i  ]*freq);
            force[2*i  ] = -lbinterforce[tpos*3*lbsy.nf+3*i+1] - lbheatforce[tpos*3*lbsy.nf+3*i+1] - postequil * (lbbdforce[3*i+1]+lboscilforce[3*i+1]*freq);
          }
        }
      }
      break;
    case CETF:
      if(interact==20 && lbsy.nf>1) {
        phi = fD2Q9CESwiftPhi(uwall[1], lbf[spos+1], lbf[spos+1+1*qdim], lbf[spos+1+2*qdim], lbf[spos+1+3*qdim], lbf[spos+1+4*qdim],
                              lbf[spos+1+5*qdim], lbf[spos+1+6*qdim], lbf[spos+1+7*qdim], lbf[spos+1+8*qdim]);
        force[0] = 0.5*(1.0+phi)*(lbinterforce[tpos*3*lbsy.nf  ] + lbheatforce[tpos*3*lbsy.nf  ] + postequil*(lbbdforce[0]+lboscilforce[0]*freq))
                 + 0.5*(1.0-phi)*(lbinterforce[tpos*3*lbsy.nf+3] + lbheatforce[tpos*3*lbsy.nf+3] + postequil*(lbbdforce[3]+lboscilforce[3]*freq));
        force[1] = 0.5*(1.0+phi)*(lbinterforce[tpos*3*lbsy.nf+1] + lbheatforce[tpos*3*lbsy.nf+1] + postequil*(lbbdforce[1]+lboscilforce[1]*freq))
                 + 0.5*(1.0-phi)*(lbinterforce[tpos*3*lbsy.nf+4] + lbheatforce[tpos*3*lbsy.nf+4] + postequil*(lbbdforce[4]+lboscilforce[4]*freq));
        force[2] = 0.0;
        force[3] = 0.0;
      }
      else {
        if(interact>9 && interact<20) {
          fD2Q9CEFracSite(frac, uwall[1], &lbf[spos], &lbf[spos+1*qdim], &lbf[spos+2*qdim],
                          &lbf[spos+3*qdim], &lbf[spos+4*qdim], &lbf[spos+5*qdim], &lbf[spos+6*qdim],
                          &lbf[spos+7*qdim], &lbf[spos+8*qdim]);
          for(int i=0; i<lbsy.nf; i++) {
            force[2*i  ] = frac[i] * lbinterforce[tpos*3  ] + lbheatforce[tpos*3*lbsy.nf+3*i  ] + postequil * (lbbdforce[3*i  ]+lboscilforce[3*i  ]*freq);
            force[2*i+1] = frac[i] * lbinterforce[tpos*3+1] + lbheatforce[tpos*3*lbsy.nf+3*i+1] + postequil * (lbbdforce[3*i+1]+lboscilforce[3*i+1]*freq);
          }
        }
        else {
          for(int i=0; i<lbsy.nf; i++) {
            force[2*i  ] = lbinterforce[tpos*3*lbsy.nf+3*i  ] + lbheatforce[tpos*3*lbsy.nf+3*i  ] + postequil * (lbbdforce[3*i  ]+lboscilforce[3*i  ]*freq);
            force[2*i+1] = lbinterforce[tpos*3*lbsy.nf+3*i+1] + lbheatforce[tpos*3*lbsy.nf+3*i+1] + postequil * (lbbdforce[3*i+1]+lboscilforce[3*i+1]*freq);
          }
        }
      }
      break;
    case CELF:
      if(interact==20 && lbsy.nf>1) {
        phi = fD2Q9CESwiftPhi(-uwall[0], lbf[spos+1], lbf[spos+1+3*qdim], lbf[spos+1+4*qdim], lbf[spos+1+5*qdim], lbf[spos+1+6*qdim],
                                                      lbf[spos+1+7*qdim], lbf[spos+1+8*qdim], lbf[spos+1+1*qdim], lbf[spos+1+2*qdim]);
        force[1] = -0.5*(1.0+phi)*(lbinterforce[tpos*3*lbsy.nf  ] + lbheatforce[tpos*3*lbsy.nf  ] + postequil*(lbbdforce[0]+lboscilforce[0]*freq))
                 -  0.5*(1.0-phi)*(lbinterforce[tpos*3*lbsy.nf+3] + lbheatforce[tpos*3*lbsy.nf+3] + postequil*(lbbdforce[3]+lboscilforce[3]*freq));
        force[0] =  0.5*(1.0+phi)*(lbinterforce[tpos*3*lbsy.nf+1] + lbheatforce[tpos*3*lbsy.nf+1] + postequil*(lbbdforce[1]+lboscilforce[1]*freq))
                 +  0.5*(1.0-phi)*(lbinterforce[tpos*3*lbsy.nf+4] + lbheatforce[tpos*3*lbsy.nf+4] + postequil*(lbbdforce[4]+lboscilforce[4]*freq));
        force[2] = 0.0;
        force[3] = 0.0;
      }
      else {
        if(interact>9 && interact<20) {
          fD2Q9CEFracSite(frac, -uwall[0], &lbf[spos], &lbf[spos+3*qdim], &lbf[spos+4*qdim],
                          &lbf[spos+5*qdim], &lbf[spos+6*qdim], &lbf[spos+7*qdim], &lbf[spos+8*qdim],
                          &lbf[spos+1*qdim], &lbf[spos+2*qdim]);
          for(int i=0; i<lbsy.nf; i++) {
            force[2*i+1] = -frac[i] * lbinterforce[tpos*3  ] - lbheatforce[tpos*3*lbsy.nf+3*i  ] - postequil * (lbbdforce[3*i  ]+lboscilforce[3*i  ]*freq);
            force[2*i  ] =  frac[i] * lbinterforce[tpos*3+1] + lbheatforce[tpos*3*lbsy.nf+3*i+1] + postequil * (lbbdforce[3*i+1]+lboscilforce[3*i+1]*freq);
          }
        }
        else {
          for(int i=0; i<lbsy.nf; i++) {
            force[2*i+1] = -lbinterforce[tpos*3*lbsy.nf+3*i  ] - lbheatforce[tpos*3*lbsy.nf+3*i  ] - postequil * (lbbdforce[3*i  ]+lboscilforce[3*i  ]*freq);
            force[2*i  ] =  lbinterforce[tpos*3*lbsy.nf+3*i+1] + lbheatforce[tpos*3*lbsy.nf+3*i+1] + postequil * (lbbdforce[3*i+1]+lboscilforce[3*i+1]*freq);
          }
        }
      }
      break;
    case CEDF:
      if(interact==20 && lbsy.nf>1) {
        phi = fD2Q9CESwiftPhi(-uwall[1], lbf[spos+1], lbf[spos+1+5*qdim], lbf[spos+1+6*qdim], lbf[spos+1+7*qdim], lbf[spos+1+8*qdim],
                                                      lbf[spos+1+1*qdim], lbf[spos+1+2*qdim], lbf[spos+1+3*qdim], lbf[spos+1+4*qdim]);
        force[0] = -0.5*(1.0+phi)*(lbinterforce[tpos*3*lbsy.nf  ] + lbheatforce[tpos*3*lbsy.nf  ] + postequil*(lbbdforce[0]+lboscilforce[0]*freq))
                 -  0.5*(1.0-phi)*(lbinterforce[tpos*3*lbsy.nf+3] + lbheatforce[tpos*3*lbsy.nf+3] + postequil*(lbbdforce[3]+lboscilforce[3]*freq));
        force[1] = -0.5*(1.0+phi)*(lbinterforce[tpos*3*lbsy.nf+1] + lbheatforce[tpos*3*lbsy.nf+1] + postequil*(lbbdforce[1]+lboscilforce[1]*freq))
                 -  0.5*(1.0-phi)*(lbinterforce[tpos*3*lbsy.nf+4] + lbheatforce[tpos*3*lbsy.nf+4] + postequil*(lbbdforce[4]+lboscilforce[4]*freq));
        force[2] = 0.0;
        force[3] = 0.0;
      }
      else {
        if(interact>9 && interact<20) {
          fD2Q9CEFracSite(frac, -uwall[1], &lbf[spos], &lbf[spos+5*qdim], &lbf[spos+6*qdim],
                          &lbf[spos+7*qdim], &lbf[spos+8*qdim], &lbf[spos+1*qdim], &lbf[spos+2*qdim],
                          &lbf[spos+3*qdim], &lbf[spos+4*qdim]);
          for(int i=0; i<lbsy.nf; i++) {
            force[2*i  ] = -frac[i] * lbinterforce[tpos*3  ] - lbheatforce[tpos*3*lbsy.nf+3*i  ] - postequil * (lbbdforce[3*i  ]+lboscilforce[3*i  ]*freq);
            force[2*i+1] = -frac[i] * lbinterforce[tpos*3+1] - lbheatforce[tpos*3*lbsy.nf+3*i+1] - postequil * (lbbdforce[3*i+1]+lboscilforce[3*i+1]*freq);
          }
        }
        else {
          for(int i=0; i<lbsy.nf; i++) {
            force[2*i  ] = -lbinterforce[tpos*3*lbsy.nf+3*i  ] - lbheatforce[tpos*3*lbsy.nf+3*i  ] - postequil * (lbbdforce[3*i  ]+lboscilforce[3*i  ]*freq);
            force[2*i+1] = -lbinterforce[tpos*3*lbsy.nf+3*i+1] - lbheatforce[tpos*3*lbsy.nf+3*i+1] - postequil * (lbbdforce[3*i+1]+lboscilforce[3*i+1]*freq);
          }
        }
      }
      break;
    case CERF:
      if(interact==20 && lbsy.nf>1) {
        phi = fD2Q9CESwiftPhi(uwall[0], lbf[spos+1], lbf[spos+1+7*qdim], lbf[spos+1+8*qdim], lbf[spos+1+1*qdim], lbf[spos+1+2*qdim],
                                                     lbf[spos+1+3*qdim], lbf[spos+1+4*qdim], lbf[spos+1+5*qdim], lbf[spos+1+6*qdim]);
        force[1] =  0.5*(1.0+phi)*(lbinterforce[tpos*3*lbsy.nf  ] + lbheatforce[tpos*3*lbsy.nf  ] + postequil*(lbbdforce[0]+lboscilforce[0]*freq))
                 +  0.5*(1.0-phi)*(lbinterforce[tpos*3*lbsy.nf+3] + lbheatforce[tpos*3*lbsy.nf+3] + postequil*(lbbdforce[3]+lboscilforce[3]*freq));
        force[0] = -0.5*(1.0+phi)*(lbinterforce[tpos*3*lbsy.nf+1] + lbheatforce[tpos*3*lbsy.nf+1] + postequil*(lbbdforce[1]+lboscilforce[1]*freq))
                 -  0.5*(1.0-phi)*(lbinterforce[tpos*3*lbsy.nf+4] + lbheatforce[tpos*3*lbsy.nf+4] + postequil*(lbbdforce[4]+lboscilforce[4]*freq));
        force[2] = 0.0;
        force[3] = 0.0;
      }
      else {
        if(interact>9 && interact<20) {
          fD2Q9CEFracSite(frac, uwall[0], &lbf[spos], &lbf[spos+7*qdim], &lbf[spos+8*qdim],
                          &lbf[spos+1*qdim], &lbf[spos+2*qdim], &lbf[spos+3*qdim], &lbf[spos+4*qdim],
                          &lbf[spos+5*qdim], &lbf[spos+6*qdim]);
          for(int i=0; i<lbsy.nf; i++) {
            force[2*i+1] =  frac[i] * lbinterforce[tpos*3  ] + lbheatforce[tpos*3*lbsy.nf+3*i  ] + postequil * (lbbdforce[3*i  ]+lboscilforce[3*i  ]*freq);
            force[2*i  ] = -frac[i] * lbinterforce[tpos*3+1] - lbheatforce[tpos*3*lbsy.nf+3*i+1] - postequil * (lbbdforce[3*i+1]+lboscilforce[3*i+1]*freq);
          }
        }
        else {
          for(int i=0; i<lbsy.nf; i++) {
            force[2*i+1] =  lbinterforce[tpos*3*lbsy.nf+3*i  ] + lbheatforce[tpos*3*lbsy.nf+3*i  ] + postequil * (lbbdforce[3*i  ]+lboscilforce[3*i  ]*freq);
            force[2*i  ] = -lbinterforce[tpos*3*lbsy.nf+3*i+1] - lbheatforce[tpos*3*lbsy.nf+3*i+1] - postequil * (lbbdforce[3*i+1]+lboscilforce[3*i+1]*freq);
          }
        }
      }
      break;
  }
  return 0;
}
                
int fD2Q9BoundaryForceDensity(double *force, long tpos, double *p0, int prop)
{
  // calculate forces required at constant density boundary point for D2Q9 lattice

  double phi, freq = (lbbdforcetyp==1)*sin(lboscilfreq*(lbcurstep-lbequstep));

  switch (prop) {
    case CCTRF:
    case CETF:
      if(interact==20 && lbsy.nf>1) {
        phi = p0[1];
        force[0] = 0.5*(1.0+phi)*(lbinterforce[tpos*3*lbsy.nf  ] + lbheatforce[tpos*3*lbsy.nf  ] + postequil*(lbbdforce[0]+lboscilforce[0]*freq))
                 + 0.5*(1.0-phi)*(lbinterforce[tpos*3*lbsy.nf+3] + lbheatforce[tpos*3*lbsy.nf+3] + postequil*(lbbdforce[3]+lboscilforce[3]*freq));
        force[1] = 0.5*(1.0+phi)*(lbinterforce[tpos*3*lbsy.nf+1] + lbheatforce[tpos*3*lbsy.nf+1] + postequil*(lbbdforce[1]+lboscilforce[1]*freq))
                 + 0.5*(1.0-phi)*(lbinterforce[tpos*3*lbsy.nf+4] + lbheatforce[tpos*3*lbsy.nf+4] + postequil*(lbbdforce[4]+lboscilforce[4]*freq));
        force[2] = 0.0;
        force[3] = 0.0;
      }
      else {
        if(interact>9 && interact<20) {
          phi = 0.0;
          for(int i=0; i<lbsy.nf; i++)
            phi += p0[i];
          phi = fReciprocal(phi);
          for(int i=0; i<lbsy.nf; i++) {
            force[2*i  ] = p0[i] * phi * lbinterforce[tpos*3  ] + lbheatforce[tpos*3*lbsy.nf+3*i  ] + postequil * (lbbdforce[3*i  ]+lboscilforce[3*i  ]*freq);
            force[2*i+1] = p0[i] * phi * lbinterforce[tpos*3+1] + lbheatforce[tpos*3*lbsy.nf+3*i+1] + postequil * (lbbdforce[3*i+1]+lboscilforce[3*i+1]*freq);
          }
        }
        else {
          for(int i=0; i<lbsy.nf; i++) {
            force[2*i  ] = lbinterforce[tpos*3*lbsy.nf+3*i  ] + lbheatforce[tpos*3*lbsy.nf+3*i  ] + postequil * (lbbdforce[3*i  ]+lboscilforce[3*i  ]*freq);
            force[2*i+1] = lbinterforce[tpos*3*lbsy.nf+3*i+1] + lbheatforce[tpos*3*lbsy.nf+3*i+1] + postequil * (lbbdforce[3*i+1]+lboscilforce[3*i+1]*freq);
          }
        }
      }
      break;
    case CCTLF:
    case CELF:
      if(interact==20 && lbsy.nf>1) {
        phi = p0[1];
        force[1] = -0.5*(1.0+phi)*(lbinterforce[tpos*3*lbsy.nf  ] + lbheatforce[tpos*3*lbsy.nf  ] + postequil*(lbbdforce[0]+lboscilforce[0]*freq))
                 -  0.5*(1.0-phi)*(lbinterforce[tpos*3*lbsy.nf+3] + lbheatforce[tpos*3*lbsy.nf+3] + postequil*(lbbdforce[3]+lboscilforce[3]*freq));
        force[0] =  0.5*(1.0+phi)*(lbinterforce[tpos*3*lbsy.nf+1] + lbheatforce[tpos*3*lbsy.nf+1] + postequil*(lbbdforce[1]+lboscilforce[1]*freq))
                 +  0.5*(1.0-phi)*(lbinterforce[tpos*3*lbsy.nf+4] + lbheatforce[tpos*3*lbsy.nf+4] + postequil*(lbbdforce[4]+lboscilforce[4]*freq));
        force[2] =  0.0;
        force[3] =  0.0;
      }
      else {
        if(interact>9 && interact<20) {
          phi = 0.0;
          for(int i=0; i<lbsy.nf; i++)
            phi += p0[i];
          phi = fReciprocal(phi);
          for(int i=0; i<lbsy.nf; i++) {
            force[2*i+1] = -p0[i] * phi * lbinterforce[tpos*3  ] - lbheatforce[tpos*3*lbsy.nf+3*i  ] - postequil * (lbbdforce[3*i  ]+lboscilforce[3*i  ]*freq);
            force[2*i  ] =  p0[i] * phi * lbinterforce[tpos*3+1] + lbheatforce[tpos*3*lbsy.nf+3*i+1] + postequil * (lbbdforce[3*i+1]+lboscilforce[3*i+1]*freq);
          }
        }
        else {
          for(int i=0; i<lbsy.nf; i++) {
            force[2*i+1] = -lbinterforce[tpos*3*lbsy.nf+3*i  ] - lbheatforce[tpos*3*lbsy.nf+3*i  ] - postequil * (lbbdforce[3*i  ]+lboscilforce[3*i  ]*freq);
            force[2*i  ] =  lbinterforce[tpos*3*lbsy.nf+3*i+1] + lbheatforce[tpos*3*lbsy.nf+3*i+1] + postequil * (lbbdforce[3*i+1]+lboscilforce[3*i+1]*freq);
          }
        }
      }
      break;
    case CCDLF:
    case CEDF:
      if(interact==20 && lbsy.nf>1) {
        phi = p0[1];
        force[0] = -0.5*(1.0+phi)*(lbinterforce[tpos*3*lbsy.nf  ] + lbheatforce[tpos*3*lbsy.nf  ] + postequil*(lbbdforce[0]+lboscilforce[0]*freq))
                 -  0.5*(1.0-phi)*(lbinterforce[tpos*3*lbsy.nf+3] + lbheatforce[tpos*3*lbsy.nf+3] + postequil*(lbbdforce[3]+lboscilforce[3]*freq));
        force[1] = -0.5*(1.0+phi)*(lbinterforce[tpos*3*lbsy.nf+1] + lbheatforce[tpos*3*lbsy.nf+1] + postequil*(lbbdforce[1]+lboscilforce[1]*freq))
                 -  0.5*(1.0-phi)*(lbinterforce[tpos*3*lbsy.nf+4] + lbheatforce[tpos*3*lbsy.nf+4] + postequil*(lbbdforce[4]+lboscilforce[4]*freq));
        force[2] =  0.0;
        force[3] =  0.0;
      }
      else {
        if(interact>9 && interact<20) {
          phi = 0.0;
          for(int i=0; i<lbsy.nf; i++)
            phi += p0[i];
          phi = fReciprocal(phi);
          for(int i=0; i<lbsy.nf; i++) {
            force[2*i  ] = -p0[i] * phi * lbinterforce[tpos*3  ] - lbheatforce[tpos*3*lbsy.nf+3*i  ] - postequil * (lbbdforce[3*i  ]+lboscilforce[3*i  ]*freq);
            force[2*i+1] = -p0[i] * phi * lbinterforce[tpos*3+1] - lbheatforce[tpos*3*lbsy.nf+3*i+1] - postequil * (lbbdforce[3*i+1]+lboscilforce[3*i+1]*freq);
          }
        }
        else {
          for(int i=0; i<lbsy.nf; i++) {
            force[2*i  ] = -lbinterforce[tpos*3*lbsy.nf+3*i  ] - lbheatforce[tpos*3*lbsy.nf+3*i  ] - postequil * (lbbdforce[3*i  ]+lboscilforce[3*i  ]*freq);
            force[2*i+1] = -lbinterforce[tpos*3*lbsy.nf+3*i+1] - lbheatforce[tpos*3*lbsy.nf+3*i+1] - postequil * (lbbdforce[3*i+1]+lboscilforce[3*i+1]*freq);
          }
        }
      }
      break;
    case CCDRF:
    case CERF:
      if(interact==20 && lbsy.nf>1) {
        phi = p0[1];
        force[1] =  0.5*(1.0+phi)*(lbinterforce[tpos*3*lbsy.nf  ] + lbheatforce[tpos*3*lbsy.nf  ] + postequil*(lbbdforce[0]+lboscilforce[0]*freq))
                 +  0.5*(1.0-phi)*(lbinterforce[tpos*3*lbsy.nf+3] + lbheatforce[tpos*3*lbsy.nf+3] + postequil*(lbbdforce[3]+lboscilforce[3]*freq));
        force[0] = -0.5*(1.0+phi)*(lbinterforce[tpos*3*lbsy.nf+1] + lbheatforce[tpos*3*lbsy.nf+1] + postequil*(lbbdforce[1]+lboscilforce[1]*freq))
                 -  0.5*(1.0-phi)*(lbinterforce[tpos*3*lbsy.nf+4] + lbheatforce[tpos*3*lbsy.nf+4] + postequil*(lbbdforce[4]+lboscilforce[4]*freq));
        force[2] =  0.0;
        force[3] =  0.0;
      }
      else {
        if(interact>9 && interact<20) {
          phi = 0.0;
          for(int i=0; i<lbsy.nf; i++)
            phi += p0[i];
          phi = fReciprocal(phi);
          for(int i=0; i<lbsy.nf; i++) {
            force[2*i+1] =  p0[i] * phi * lbinterforce[tpos*3  ] + lbheatforce[tpos*3*lbsy.nf+3*i  ] + postequil * (lbbdforce[3*i  ]+lboscilforce[3*i  ]*freq);
            force[2*i  ] = -p0[i] * phi * lbinterforce[tpos*3+1] - lbheatforce[tpos*3*lbsy.nf+3*i+1] - postequil * (lbbdforce[3*i+1]+lboscilforce[3*i+1]*freq);
          }
        }
        else {
          for(int i=0; i<lbsy.nf; i++) {
            force[2*i+1] =  lbinterforce[tpos*3*lbsy.nf+3*i  ] + lbheatforce[tpos*3*lbsy.nf+3*i  ] + postequil * (lbbdforce[3*i  ]+lboscilforce[3*i  ]*freq);
            force[2*i  ] = -lbinterforce[tpos*3*lbsy.nf+3*i+1] - lbheatforce[tpos*3*lbsy.nf+3*i+1] - postequil * (lbbdforce[3*i+1]+lboscilforce[3*i+1]*freq);
          }
        }
      }
      break;
  }
  return 0;
}


int fD2Q9OF1(long tpos, int prop)
{
  long tpos1;
  int qdim = lbsy.nf+lbsy.nc+lbsy.nt;
  int l1, l2, l3;

  tpos1 = tpos;
  l1 = 0; l2 = 0; l3 = 0;
  switch (prop) {
    case CETF:
      tpos1 = fNextStep(0, 1, 0, tpos);
      l1 = 1; l2 = 7; l3 = 8;
      break;
    case CELF:
      tpos1 = fNextStep(-1, 0, 0, tpos);
      l1 = 1; l2 = 2; l3 = 3;
      break;
    case CEDF:
      tpos1 = fNextStep(0, -1, 0, tpos);
      l1 = 3; l2 = 4; l3 = 5;
      break;
    case CERF:
      tpos1 = fNextStep(1, 0, 0, tpos);
      l1 = 5; l2 = 6; l3 = 7;
      break;
  }

  for(int i=0; i<qdim; i++) {
    lbf[tpos*lbsitelength+i+l1*qdim] = lbf[tpos1*lbsitelength+i+l1*qdim];
    lbf[tpos*lbsitelength+i+l2*qdim] = lbf[tpos1*lbsitelength+i+l2*qdim];
    lbf[tpos*lbsitelength+i+l3*qdim] = lbf[tpos1*lbsitelength+i+l3*qdim];
  }
  return 0;
}

int fD2Q9OF2(long tpos, int prop)
{
  long tpos1, tpos2;
  int qdim = lbsy.nf+lbsy.nc+lbsy.nt;
  int l1, l2, l3;

  tpos1 = tpos; tpos2 = tpos;
  l1 = 0; l2 = 0; l3 = 0;
  switch (prop) {
    case CETF:
      tpos1 = fNextStep(0, 1, 0, tpos);
      tpos2 = fNextStep(0, 2, 0, tpos);
      l1 = 1; l2 = 7; l3 = 8;
      break;
    case CELF:
      tpos1 = fNextStep(-1, 0, 0, tpos);
      tpos2 = fNextStep(-2, 0, 0, tpos);
      l1 = 1; l2 = 2; l3 = 3;
      break;
    case CEDF:
      tpos1 = fNextStep(0, -1, 0, tpos);
      tpos2 = fNextStep(0, -2, 0, tpos);
      l1 = 3; l2 = 4; l3 = 5;
      break;
    case CERF:
      tpos1 = fNextStep(1, 0, 0, tpos);
      tpos2 = fNextStep(2, 0, 0, tpos);
      l1 = 5; l2 = 6; l3 = 7;
      break;
  }

  for(int i=0; i<qdim; i++) {
    lbf[tpos*lbsitelength+i+l1*qdim] = 2.0*lbf[tpos1*lbsitelength+i+l1*qdim]-lbf[tpos2*lbsitelength+i+l1*qdim];
    lbf[tpos*lbsitelength+i+l2*qdim] = 2.0*lbf[tpos1*lbsitelength+i+l2*qdim]-lbf[tpos2*lbsitelength+i+l2*qdim];
    lbf[tpos*lbsitelength+i+l3*qdim] = 2.0*lbf[tpos1*lbsitelength+i+l3*qdim]-lbf[tpos2*lbsitelength+i+l3*qdim];
  }
  return 0;
}


// D3Q15

int fD3Q15PSFracSite(double *frac, double vy, double *f0, double *f1, double *f2, double *f3, double *f4, double *f5, double *f6, double *f7, double *f8, double *f9, double *f10, double *f11, double *f12, double *f13, double *f14)
{
  // calculate fluid densities at bottom boundary (PST) for fluids
    
  double invallmass,allmass = 0.0;
    
  for(int i=0; i<lbsy.nf; i++) {
    frac[i] = (f0[i]+f1[i]+f3[i]+f8[i]+f10[i]+2.0*(f2[i]+f4[i]+f5[i]+f13[i]+f14[i]))/(1.0-vy);
    allmass += frac[i];
  }
  invallmass = fReciprocal(allmass);
  for(int i=0; i<lbsy.nf; i++)
    frac[i] *= invallmass;
    
  return 0;
}

double fD3Q15PSSwiftPhi(double vy, double g0, double g1, double g2, double g3, double g4, double g5, double g6, double g7, double g8, double g9, double g10, double g11, double g12, double g13, double g14)
{
  // calculate concentration at bottom boundary (PST) for fluids
  // with Swift free-energy interactions
    
  double phi = (g0+g1+g3+g8+g10+2.0*(g2+g4+g5+g13+g14))/(1.0-vy);
  return phi;
}

int fD3Q15BoundaryForceVelocity(double *force, long tpos, long tpos1, double dx, double dy, double dz, double *uwall, int prop)
{
  // calculate forces required at constant velocity boundary point for D3Q15 lattice

  long spos = tpos * lbsitelength;
  int qdim = lbsy.nf+lbsy.nc+lbsy.nt;
  double frac[lbsy.nf];
  double phi, freq = (lbbdforcetyp==1)*sin(lboscilfreq*(lbcurstep-lbequstep));

  switch (prop) {
    case PST:
      if(interact==20 && lbsy.nf>1) {
        phi = fD3Q15PSSwiftPhi(uwall[1], lbf[spos+1], lbf[spos+1+1*qdim], lbf[spos+1+2*qdim], lbf[spos+1+3*qdim], lbf[spos+1+4*qdim],
                               lbf[spos+1+5*qdim], lbf[spos+1+6*qdim], lbf[spos+1+7*qdim], lbf[spos+1+8*qdim], lbf[spos+1+9*qdim],
                               lbf[spos+1+10*qdim], lbf[spos+1+11*qdim], lbf[spos+1+12*qdim], lbf[spos+1+13*qdim], lbf[spos+1+14*qdim]);
        force[0] = 0.5*(1.0+phi)*(lbinterforce[tpos*3*lbsy.nf  ] + lbheatforce[tpos*3*lbsy.nf  ] + postequil*(lbbdforce[0]+lboscilforce[0]*freq))
                 + 0.5*(1.0-phi)*(lbinterforce[tpos*3*lbsy.nf+3] + lbheatforce[tpos*3*lbsy.nf+3] + postequil*(lbbdforce[3]+lboscilforce[3]*freq));
        force[1] = 0.5*(1.0+phi)*(lbinterforce[tpos*3*lbsy.nf+1] + lbheatforce[tpos*3*lbsy.nf+1] + postequil*(lbbdforce[1]+lboscilforce[1]*freq))
                 + 0.5*(1.0-phi)*(lbinterforce[tpos*3*lbsy.nf+4] + lbheatforce[tpos*3*lbsy.nf+4] + postequil*(lbbdforce[4]+lboscilforce[4]*freq));
        force[2] = 0.5*(1.0+phi)*(lbinterforce[tpos*3*lbsy.nf+2] + lbheatforce[tpos*3*lbsy.nf+2] + postequil*(lbbdforce[2]+lboscilforce[2]*freq))
                 + 0.5*(1.0-phi)*(lbinterforce[tpos*3*lbsy.nf+5] + lbheatforce[tpos*3*lbsy.nf+5] + postequil*(lbbdforce[5]+lboscilforce[5]*freq));
        force[3] = 0.0;
        force[4] = 0.0;
        force[5] = 0.0;
      }
      else {
        if(interact>9 && interact<20) {
          fD3Q15PSFracSite(frac, uwall[1], &lbf[spos], &lbf[spos+1*qdim], &lbf[spos+2*qdim],
                           &lbf[spos+3*qdim],  &lbf[spos+4*qdim],  &lbf[spos+5*qdim],  &lbf[spos+6*qdim],
                           &lbf[spos+7*qdim],  &lbf[spos+8*qdim],  &lbf[spos+9*qdim],  &lbf[spos+10*qdim],
                           &lbf[spos+11*qdim], &lbf[spos+12*qdim], &lbf[spos+13*qdim], &lbf[spos+14*qdim]);
          for(int i=0; i<lbsy.nf; i++) {
            force[3*i  ] = frac[i] * lbinterforce[tpos*3  ] + lbheatforce[tpos*3*lbsy.nf+3*i  ] + postequil * (lbbdforce[3*i  ]+lboscilforce[3*i  ]*freq);
            force[3*i+1] = frac[i] * lbinterforce[tpos*3+1] + lbheatforce[tpos*3*lbsy.nf+3*i+1] + postequil * (lbbdforce[3*i+1]+lboscilforce[3*i+1]*freq);
            force[3*i+2] = frac[i] * lbinterforce[tpos*3+2] + lbheatforce[tpos*3*lbsy.nf+3*i+2] + postequil * (lbbdforce[3*i+2]+lboscilforce[3*i+2]*freq);
          }
        }
        else {
          for(int i=0; i<lbsy.nf; i++) {
            force[3*i  ] = lbinterforce[tpos*3*lbsy.nf+3*i  ] + lbheatforce[tpos*3*lbsy.nf+3*i  ] + postequil * (lbbdforce[3*i  ]+lboscilforce[3*i  ]*freq);
            force[3*i+1] = lbinterforce[tpos*3*lbsy.nf+3*i+1] + lbheatforce[tpos*3*lbsy.nf+3*i+1] + postequil * (lbbdforce[3*i+1]+lboscilforce[3*i+1]*freq);
            force[3*i+2] = lbinterforce[tpos*3*lbsy.nf+3*i+2] + lbheatforce[tpos*3*lbsy.nf+3*i+2] + postequil * (lbbdforce[3*i+2]+lboscilforce[3*i+2]*freq);
          }
        }
      }
      break;
    case PSD:
      if(interact==20 && lbsy.nf>1) {
        phi = fD3Q15PSSwiftPhi(-uwall[1], lbf[spos+1], lbf[spos+1+8*qdim], lbf[spos+1+9*qdim], lbf[spos+1+10*qdim], lbf[spos+1+11*qdim],
                               lbf[spos+1+12*qdim], lbf[spos+1+13*qdim], lbf[spos+1+14*qdim], lbf[spos+1+1*qdim], lbf[spos+1+2*qdim],
                               lbf[spos+1+3*qdim], lbf[spos+1+4*qdim], lbf[spos+1+5*qdim], lbf[spos+1+6*qdim], lbf[spos+1+7*qdim]);
        force[0] = -0.5*(1.0+phi)*(lbinterforce[tpos*3*lbsy.nf  ] + lbheatforce[tpos*3*lbsy.nf  ] + postequil*(lbbdforce[0]+lboscilforce[0]*freq))
                 -  0.5*(1.0-phi)*(lbinterforce[tpos*3*lbsy.nf+3] + lbheatforce[tpos*3*lbsy.nf+3] + postequil*(lbbdforce[3]+lboscilforce[3]*freq));
        force[1] = -0.5*(1.0+phi)*(lbinterforce[tpos*3*lbsy.nf+1] + lbheatforce[tpos*3*lbsy.nf+1] + postequil*(lbbdforce[1]+lboscilforce[1]*freq))
                 -  0.5*(1.0-phi)*(lbinterforce[tpos*3*lbsy.nf+4] + lbheatforce[tpos*3*lbsy.nf+4] + postequil*(lbbdforce[4]+lboscilforce[4]*freq));
        force[2] = -0.5*(1.0+phi)*(lbinterforce[tpos*3*lbsy.nf+2] + lbheatforce[tpos*3*lbsy.nf+2] + postequil*(lbbdforce[2]+lboscilforce[2]*freq))
                 -  0.5*(1.0-phi)*(lbinterforce[tpos*3*lbsy.nf+5] + lbheatforce[tpos*3*lbsy.nf+5] + postequil*(lbbdforce[5]+lboscilforce[5]*freq));
        force[3] = 0.0;
        force[4] = 0.0;
        force[5] = 0.0;
      }
      else {
        if(interact>9 && interact<20) {
          fD3Q15PSFracSite(frac, -uwall[1], &lbf[spos], &lbf[spos+8*qdim], &lbf[spos+9*qdim],
                           &lbf[spos+10*qdim], &lbf[spos+11*qdim], &lbf[spos+12*qdim], &lbf[spos+13*qdim],
                           &lbf[spos+14*qdim], &lbf[spos+1*qdim],  &lbf[spos+2*qdim],  &lbf[spos+3*qdim],
                           &lbf[spos+4*qdim],  &lbf[spos+5*qdim],  &lbf[spos+6*qdim],  &lbf[spos+7*qdim]);
          for(int i=0; i<lbsy.nf; i++) {
            force[3*i  ] = -frac[i] * lbinterforce[tpos*3  ] - lbheatforce[tpos*3*lbsy.nf+3*i  ] - postequil * (lbbdforce[3*i  ]+lboscilforce[3*i  ]*freq);
            force[3*i+1] = -frac[i] * lbinterforce[tpos*3+1] - lbheatforce[tpos*3*lbsy.nf+3*i+1] - postequil * (lbbdforce[3*i+1]+lboscilforce[3*i+1]*freq);
            force[3*i+2] = -frac[i] * lbinterforce[tpos*3+2] - lbheatforce[tpos*3*lbsy.nf+3*i+2] - postequil * (lbbdforce[3*i+2]+lboscilforce[3*i+2]*freq);
          }
        }
        else {
          for(int i=0; i<lbsy.nf; i++) {
            force[3*i  ] = -lbinterforce[tpos*3*lbsy.nf+3*i  ] - lbheatforce[tpos*3*lbsy.nf+3*i  ] - postequil * (lbbdforce[3*i  ]+lboscilforce[3*i  ]*freq);
            force[3*i+1] = -lbinterforce[tpos*3*lbsy.nf+3*i+1] - lbheatforce[tpos*3*lbsy.nf+3*i+1] - postequil * (lbbdforce[3*i+1]+lboscilforce[3*i+1]*freq);
            force[3*i+2] = -lbinterforce[tpos*3*lbsy.nf+3*i+2] - lbheatforce[tpos*3*lbsy.nf+3*i+2] - postequil * (lbbdforce[3*i+2]+lboscilforce[3*i+2]*freq);
          }
        }
      }
      break;
    case PSL:
      if(interact==20 && lbsy.nf>1) {
        phi = fD3Q15PSSwiftPhi(-uwall[0], lbf[spos+1], lbf[spos+1+10*qdim], lbf[spos+1+8*qdim], lbf[spos+1+9*qdim], lbf[spos+1+11*qdim],
                               lbf[spos+1+13*qdim], lbf[spos+1+7*qdim], lbf[spos+1+5*qdim], lbf[spos+1+3*qdim], lbf[spos+1+1*qdim],
                               lbf[spos+1+2*qdim], lbf[spos+1+4*qdim], lbf[spos+1+6*qdim], lbf[spos+1+14*qdim], lbf[spos+1+12*qdim]);
        force[1] = -0.5*(1.0+phi)*(lbinterforce[tpos*3*lbsy.nf  ] + lbheatforce[tpos*3*lbsy.nf  ] + postequil*(lbbdforce[0]+lboscilforce[0]*freq))
                 -  0.5*(1.0-phi)*(lbinterforce[tpos*3*lbsy.nf+3] + lbheatforce[tpos*3*lbsy.nf+3] + postequil*(lbbdforce[3]+lboscilforce[3]*freq));
        force[2] = -0.5*(1.0+phi)*(lbinterforce[tpos*3*lbsy.nf+1] + lbheatforce[tpos*3*lbsy.nf+1] + postequil*(lbbdforce[1]+lboscilforce[1]*freq))
                 -  0.5*(1.0-phi)*(lbinterforce[tpos*3*lbsy.nf+4] + lbheatforce[tpos*3*lbsy.nf+4] + postequil*(lbbdforce[4]+lboscilforce[4]*freq));
        force[0] = -0.5*(1.0+phi)*(lbinterforce[tpos*3*lbsy.nf+2] + lbheatforce[tpos*3*lbsy.nf+2] + postequil*(lbbdforce[2]+lboscilforce[2]*freq))
                 -  0.5*(1.0-phi)*(lbinterforce[tpos*3*lbsy.nf+5] + lbheatforce[tpos*3*lbsy.nf+5] + postequil*(lbbdforce[5]+lboscilforce[5]*freq));
        force[3] = 0.0;
        force[4] = 0.0;
        force[5] = 0.0;
      }
      else {
        if(interact>9 && interact<20) {
          fD3Q15PSFracSite(frac, -uwall[0], &lbf[spos], &lbf[spos+10*qdim], &lbf[spos+8*qdim],
                           &lbf[spos+9*qdim], &lbf[spos+11*qdim], &lbf[spos+13*qdim], &lbf[spos+7*qdim],
                           &lbf[spos+5*qdim], &lbf[spos+3*qdim],  &lbf[spos+1*qdim],  &lbf[spos+2*qdim],
                           &lbf[spos+4*qdim], &lbf[spos+6*qdim],  &lbf[spos+14*qdim], &lbf[spos+12*qdim]);
          for(int i=0; i<lbsy.nf; i++) {
            force[3*i+1] = -frac[i] * lbinterforce[tpos*3  ] - lbheatforce[tpos*3*lbsy.nf+3*i  ] - postequil * (lbbdforce[3*i  ]+lboscilforce[3*i  ]*freq);
            force[3*i+2] = -frac[i] * lbinterforce[tpos*3+1] - lbheatforce[tpos*3*lbsy.nf+3*i+1] - postequil * (lbbdforce[3*i+1]+lboscilforce[3*i+1]*freq);
            force[3*i  ] = -frac[i] * lbinterforce[tpos*3+2] - lbheatforce[tpos*3*lbsy.nf+3*i+2] - postequil * (lbbdforce[3*i+2]+lboscilforce[3*i+2]*freq);
          }
        }
        else {
          for(int i=0; i<lbsy.nf; i++) {
            force[3*i+1] = -lbinterforce[tpos*3*lbsy.nf+3*i  ] - lbheatforce[tpos*3*lbsy.nf+3*i  ] - postequil * (lbbdforce[3*i  ]+lboscilforce[3*i  ]*freq);
            force[3*i+2] = -lbinterforce[tpos*3*lbsy.nf+3*i+1] - lbheatforce[tpos*3*lbsy.nf+3*i+1] - postequil * (lbbdforce[3*i+1]+lboscilforce[3*i+1]*freq);
            force[3*i  ] = -lbinterforce[tpos*3*lbsy.nf+3*i+2] - lbheatforce[tpos*3*lbsy.nf+3*i+2] - postequil * (lbbdforce[3*i+2]+lboscilforce[3*i+2]*freq);
          }
        }
      }
      break;
    case PSR:
      if(interact==20 && lbsy.nf>1) {
        phi = fD3Q15PSSwiftPhi(uwall[0], lbf[spos+1], lbf[spos+1+3*qdim], lbf[spos+1+1*qdim], lbf[spos+1+2*qdim], lbf[spos+1+4*qdim],
                               lbf[spos+1+6*qdim], lbf[spos+1+14*qdim], lbf[spos+1+12*qdim], lbf[spos+1+10*qdim], lbf[spos+1+8*qdim],
                               lbf[spos+1+9*qdim], lbf[spos+1+11*qdim], lbf[spos+1+13*qdim], lbf[spos+1+5*qdim],  lbf[spos+1+13*qdim]);
        force[1] = 0.5*(1.0+phi)*(lbinterforce[tpos*3*lbsy.nf  ] + lbheatforce[tpos*3*lbsy.nf  ] + postequil*(lbbdforce[0]+lboscilforce[0]*freq))
                 + 0.5*(1.0-phi)*(lbinterforce[tpos*3*lbsy.nf+3] + lbheatforce[tpos*3*lbsy.nf+3] + postequil*(lbbdforce[3]+lboscilforce[3]*freq));
        force[2] = 0.5*(1.0+phi)*(lbinterforce[tpos*3*lbsy.nf+1] + lbheatforce[tpos*3*lbsy.nf+1] + postequil*(lbbdforce[1]+lboscilforce[1]*freq))
                 + 0.5*(1.0-phi)*(lbinterforce[tpos*3*lbsy.nf+4] + lbheatforce[tpos*3*lbsy.nf+4] + postequil*(lbbdforce[4]+lboscilforce[4]*freq));
        force[0] = 0.5*(1.0+phi)*(lbinterforce[tpos*3*lbsy.nf+2] + lbheatforce[tpos*3*lbsy.nf+2] + postequil*(lbbdforce[2]+lboscilforce[2]*freq))
                 + 0.5*(1.0-phi)*(lbinterforce[tpos*3*lbsy.nf+5] + lbheatforce[tpos*3*lbsy.nf+5] + postequil*(lbbdforce[5]+lboscilforce[5]*freq));
        force[3] = 0.0;
        force[4] = 0.0;
        force[5] = 0.0;
      }
      else {
        if(interact>9 && interact<20) {
          fD3Q15PSFracSite(frac, uwall[0], &lbf[spos], &lbf[spos+3*qdim], &lbf[spos+1*qdim],
                           &lbf[spos+2*qdim],  &lbf[spos+4*qdim],  &lbf[spos+6*qdim], &lbf[spos+14*qdim],
                           &lbf[spos+12*qdim], &lbf[spos+10*qdim], &lbf[spos+8*qdim], &lbf[spos+9*qdim],
                           &lbf[spos+11*qdim], &lbf[spos+13*qdim], &lbf[spos+7*qdim], &lbf[spos+5*qdim]);
          for(int i=0; i<lbsy.nf; i++) {
            force[3*i+1] = frac[i] * lbinterforce[tpos*3  ] + lbheatforce[tpos*3*lbsy.nf+3*i  ] + postequil * (lbbdforce[3*i  ]+lboscilforce[3*i  ]*freq);
            force[3*i+2] = frac[i] * lbinterforce[tpos*3+1] + lbheatforce[tpos*3*lbsy.nf+3*i+1] + postequil * (lbbdforce[3*i+1]+lboscilforce[3*i+1]*freq);
            force[3*i  ] = frac[i] * lbinterforce[tpos*3+2] + lbheatforce[tpos*3*lbsy.nf+3*i+2] + postequil * (lbbdforce[3*i+2]+lboscilforce[3*i+2]*freq);
          }
        }
        else {
          for(int i=0; i<lbsy.nf; i++) {
            force[3*i+1] = lbinterforce[tpos*3*lbsy.nf+3*i  ] + lbheatforce[tpos*3*lbsy.nf+3*i  ] + postequil * (lbbdforce[3*i  ]+lboscilforce[3*i  ]*freq);
            force[3*i+2] = lbinterforce[tpos*3*lbsy.nf+3*i+1] + lbheatforce[tpos*3*lbsy.nf+3*i+1] + postequil * (lbbdforce[3*i+1]+lboscilforce[3*i+1]*freq);
            force[3*i  ] = lbinterforce[tpos*3*lbsy.nf+3*i+2] + lbheatforce[tpos*3*lbsy.nf+3*i+2] + postequil * (lbbdforce[3*i+2]+lboscilforce[3*i+2]*freq);
          }
        }
      }
      break;
    case PSF:
      if(interact==20 && lbsy.nf>1) {
        phi = fD3Q15PSSwiftPhi(-uwall[2], lbf[spos+1], lbf[spos+1+9*qdim], lbf[spos+1+10*qdim], lbf[spos+1+8*qdim], lbf[spos+1+11*qdim],
                               lbf[spos+1+7*qdim], lbf[spos+1+12*qdim], lbf[spos+1+6*qdim], lbf[spos+1+2*qdim], lbf[spos+1+3*qdim],
                               lbf[spos+1+1*qdim], lbf[spos+1+4*qdim], lbf[spos+1+14*qdim], lbf[spos+1+5*qdim], lbf[spos+1+13*qdim]);
        force[2] = -0.5*(1.0+phi)*(lbinterforce[tpos*3*lbsy.nf  ] + lbheatforce[tpos*3*lbsy.nf  ] + postequil*(lbbdforce[0]+lboscilforce[0]*freq))
                 -  0.5*(1.0-phi)*(lbinterforce[tpos*3*lbsy.nf+3] + lbheatforce[tpos*3*lbsy.nf+3] + postequil*(lbbdforce[3]+lboscilforce[3]*freq));
        force[0] = -0.5*(1.0+phi)*(lbinterforce[tpos*3*lbsy.nf+1] + lbheatforce[tpos*3*lbsy.nf+1] + postequil*(lbbdforce[1]+lboscilforce[1]*freq))
                 -  0.5*(1.0-phi)*(lbinterforce[tpos*3*lbsy.nf+4] + lbheatforce[tpos*3*lbsy.nf+4] + postequil*(lbbdforce[4]+lboscilforce[4]*freq));
        force[1] = -0.5*(1.0+phi)*(lbinterforce[tpos*3*lbsy.nf+2] + lbheatforce[tpos*3*lbsy.nf+2] + postequil*(lbbdforce[2]+lboscilforce[2]*freq))
                 -  0.5*(1.0-phi)*(lbinterforce[tpos*3*lbsy.nf+5] + lbheatforce[tpos*3*lbsy.nf+5] + postequil*(lbbdforce[5]+lboscilforce[5]*freq));
        force[3] = 0.0;
        force[4] = 0.0;
        force[5] = 0.0;
      }
      else {
        if(interact>9 && interact<20) {
          fD3Q15PSFracSite(frac, -uwall[2], &lbf[spos], &lbf[spos+9*qdim], &lbf[spos+10*qdim],
                           &lbf[spos+8*qdim],  &lbf[spos+11*qdim], &lbf[spos+7*qdim],  &lbf[spos+12*qdim],
                           &lbf[spos+6*qdim],  &lbf[spos+2*qdim],  &lbf[spos+3*qdim],  &lbf[spos+1*qdim],
                           &lbf[spos+4*qdim],  &lbf[spos+14*qdim], &lbf[spos+5*qdim],  &lbf[spos+13*qdim]);
          for(int i=0; i<lbsy.nf; i++) {
            force[3*i+2] = -frac[i] * lbinterforce[tpos*3  ] - lbheatforce[tpos*3*lbsy.nf+3*i  ] - postequil * (lbbdforce[3*i  ]+lboscilforce[3*i  ]*freq);
            force[3*i  ] = -frac[i] * lbinterforce[tpos*3+1] - lbheatforce[tpos*3*lbsy.nf+3*i+1] - postequil * (lbbdforce[3*i+1]+lboscilforce[3*i+1]*freq);
            force[3*i+1] = -frac[i] * lbinterforce[tpos*3+2] - lbheatforce[tpos*3*lbsy.nf+3*i+2] - postequil * (lbbdforce[3*i+2]+lboscilforce[3*i+2]*freq);
          }
        }
        else {
          for(int i=0; i<lbsy.nf; i++) {
            force[3*i+2] = -lbinterforce[tpos*3*lbsy.nf+3*i  ] - lbheatforce[tpos*3*lbsy.nf+3*i  ] - postequil * (lbbdforce[3*i  ]+lboscilforce[3*i  ]*freq);
            force[3*i  ] = -lbinterforce[tpos*3*lbsy.nf+3*i+1] - lbheatforce[tpos*3*lbsy.nf+3*i+1] - postequil * (lbbdforce[3*i+1]+lboscilforce[3*i+1]*freq);
            force[3*i+1] = -lbinterforce[tpos*3*lbsy.nf+3*i+2] - lbheatforce[tpos*3*lbsy.nf+3*i+2] - postequil * (lbbdforce[3*i+2]+lboscilforce[3*i+2]*freq);
          }
        }
      }
      break;
    case PSB:
      if(interact==20 && lbsy.nf>1) {
        phi = fD3Q15PSSwiftPhi(uwall[2], lbf[spos+1], lbf[spos+1+2*qdim], lbf[spos+1+3*qdim], lbf[spos+1+1*qdim], lbf[spos+1+4*qdim],
                               lbf[spos+1+14*qdim], lbf[spos+1+5*qdim], lbf[spos+1+13*qdim], lbf[spos+1+9*qdim], lbf[spos+1+10*qdim],
                               lbf[spos+1+8*qdim], lbf[spos+1+11*qdim], lbf[spos+1+7*qdim], lbf[spos+1+12*qdim], lbf[spos+1+6*qdim]);
        force[2] = 0.5*(1.0+phi)*(lbinterforce[tpos*3*lbsy.nf  ] + lbheatforce[tpos*3*lbsy.nf  ] + postequil*(lbbdforce[0]+lboscilforce[0]*freq))
                 + 0.5*(1.0-phi)*(lbinterforce[tpos*3*lbsy.nf+3] + lbheatforce[tpos*3*lbsy.nf+3] + postequil*(lbbdforce[3]+lboscilforce[3]*freq));
        force[0] = 0.5*(1.0+phi)*(lbinterforce[tpos*3*lbsy.nf+1] + lbheatforce[tpos*3*lbsy.nf+1] + postequil*(lbbdforce[1]+lboscilforce[1]*freq))
                 + 0.5*(1.0-phi)*(lbinterforce[tpos*3*lbsy.nf+4] + lbheatforce[tpos*3*lbsy.nf+4] + postequil*(lbbdforce[4]+lboscilforce[4]*freq));
        force[1] = 0.5*(1.0+phi)*(lbinterforce[tpos*3*lbsy.nf+2] + lbheatforce[tpos*3*lbsy.nf+2] + postequil*(lbbdforce[2]+lboscilforce[2]*freq))
                 + 0.5*(1.0-phi)*(lbinterforce[tpos*3*lbsy.nf+5] + lbheatforce[tpos*3*lbsy.nf+5] + postequil*(lbbdforce[5]+lboscilforce[5]*freq));
        force[3] = 0.0;
        force[4] = 0.0;
        force[5] = 0.0;
      }
      else {
        if(interact>9 && interact<20) {
          fD3Q15PSFracSite(frac, uwall[2], &lbf[spos], &lbf[spos+2*qdim], &lbf[spos+3*qdim],
                           &lbf[spos+1*qdim],  &lbf[spos+4*qdim],  &lbf[spos+14*qdim], &lbf[spos+5*qdim],
                           &lbf[spos+13*qdim], &lbf[spos+9*qdim],  &lbf[spos+10*qdim], &lbf[spos+8*qdim],
                           &lbf[spos+11*qdim], &lbf[spos+7*qdim],  &lbf[spos+12*qdim], &lbf[spos+6*qdim]);
          for(int i=0; i<lbsy.nf; i++) {
            force[3*i+2] = frac[i] * lbinterforce[tpos*3  ] + lbheatforce[tpos*3*lbsy.nf+3*i  ] + postequil * (lbbdforce[3*i  ]+lboscilforce[3*i  ]*freq);
            force[3*i  ] = frac[i] * lbinterforce[tpos*3+1] + lbheatforce[tpos*3*lbsy.nf+3*i+1] + postequil * (lbbdforce[3*i+1]+lboscilforce[3*i+1]*freq);
            force[3*i+1] = frac[i] * lbinterforce[tpos*3+2] + lbheatforce[tpos*3*lbsy.nf+3*i+2] + postequil * (lbbdforce[3*i+2]+lboscilforce[3*i+2]*freq);
          }
        }
        else {
          for(int i=0; i<lbsy.nf; i++) {
            force[3*i+2] = lbinterforce[tpos*3*lbsy.nf+3*i  ] + lbheatforce[tpos*3*lbsy.nf+3*i  ] + postequil * (lbbdforce[3*i  ]+lboscilforce[3*i  ]*freq);
            force[3*i  ] = lbinterforce[tpos*3*lbsy.nf+3*i+1] + lbheatforce[tpos*3*lbsy.nf+3*i+1] + postequil * (lbbdforce[3*i+1]+lboscilforce[3*i+1]*freq);
            force[3*i+1] = lbinterforce[tpos*3*lbsy.nf+3*i+2] + lbheatforce[tpos*3*lbsy.nf+3*i+2] + postequil * (lbbdforce[3*i+2]+lboscilforce[3*i+2]*freq);
          }
        }
      }
      break;
    case CCTRB:
      if(interact==20 && lbsy.nf>1) {
        phi = fD3CECCSwiftPhi(tpos1, dx, dy, dz, lbft[4*lbsy.nf*tpos+4], lbft[4*lbsy.nf*tpos+5], lbft[4*lbsy.nf*tpos+6]);
        force[0] =  0.5*(1.0+phi)*(lbinterforce[tpos*3*lbsy.nf  ] + lbheatforce[tpos*3*lbsy.nf  ] + postequil*(lbbdforce[0]+lboscilforce[0]*freq))
                 +  0.5*(1.0-phi)*(lbinterforce[tpos*3*lbsy.nf+3] + lbheatforce[tpos*3*lbsy.nf+3] + postequil*(lbbdforce[3]+lboscilforce[3]*freq));
        force[1] =  0.5*(1.0+phi)*(lbinterforce[tpos*3*lbsy.nf+1] + lbheatforce[tpos*3*lbsy.nf+1] + postequil*(lbbdforce[1]+lboscilforce[1]*freq))
                 +  0.5*(1.0-phi)*(lbinterforce[tpos*3*lbsy.nf+4] + lbheatforce[tpos*3*lbsy.nf+4] + postequil*(lbbdforce[4]+lboscilforce[4]*freq));
        force[2] = -0.5*(1.0+phi)*(lbinterforce[tpos*3*lbsy.nf+2] + lbheatforce[tpos*3*lbsy.nf+2] + postequil*(lbbdforce[2]+lboscilforce[2]*freq))
                 -  0.5*(1.0-phi)*(lbinterforce[tpos*3*lbsy.nf+5] + lbheatforce[tpos*3*lbsy.nf+5] + postequil*(lbbdforce[5]+lboscilforce[5]*freq));
        force[3] =  0.0;
        force[4] =  0.0;
        force[5] =  0.0;
      }
      else {
        if(interact>9 && interact<20) {
          fD3CECCFracSite(frac, tpos1);
          for(int i=0; i<lbsy.nf; i++) {
            force[3*i  ] =  frac[i] * lbinterforce[tpos*3  ] + lbheatforce[tpos*3*lbsy.nf+3*i  ] + postequil * (lbbdforce[3*i  ]+lboscilforce[3*i  ]*freq);
            force[3*i+1] =  frac[i] * lbinterforce[tpos*3+1] + lbheatforce[tpos*3*lbsy.nf+3*i+1] + postequil * (lbbdforce[3*i+1]+lboscilforce[3*i+1]*freq);
            force[3*i+2] = -frac[i] * lbinterforce[tpos*3+2] - lbheatforce[tpos*3*lbsy.nf+3*i+2] - postequil * (lbbdforce[3*i+2]+lboscilforce[3*i+2]*freq);
          }
        }
        else {
          for(int i=0; i<lbsy.nf; i++) {
            force[3*i  ] =  lbinterforce[tpos*3*lbsy.nf+3*i  ] + lbheatforce[tpos*3*lbsy.nf+3*i  ] + postequil * (lbbdforce[3*i  ]+lboscilforce[3*i  ]*freq);
            force[3*i+1] =  lbinterforce[tpos*3*lbsy.nf+3*i+1] + lbheatforce[tpos*3*lbsy.nf+3*i+1] + postequil * (lbbdforce[3*i+1]+lboscilforce[3*i+1]*freq);
            force[3*i+2] = -lbinterforce[tpos*3*lbsy.nf+3*i+2] - lbheatforce[tpos*3*lbsy.nf+3*i+2] - postequil * (lbbdforce[3*i+2]+lboscilforce[3*i+2]*freq);
          }
        }
      }
      break;
    case CCTLB:
      if(interact==20 && lbsy.nf>1) {
        phi = fD3CECCSwiftPhi(tpos1, dx, dy, dz, lbft[4*lbsy.nf*tpos+4], lbft[4*lbsy.nf*tpos+5], lbft[4*lbsy.nf*tpos+6]);
        force[0] = -0.5*(1.0+phi)*(lbinterforce[tpos*3*lbsy.nf  ] + lbheatforce[tpos*3*lbsy.nf  ] + postequil*(lbbdforce[0]+lboscilforce[0]*freq))
                 -  0.5*(1.0-phi)*(lbinterforce[tpos*3*lbsy.nf+3] + lbheatforce[tpos*3*lbsy.nf+3] + postequil*(lbbdforce[3]+lboscilforce[3]*freq));
        force[1] =  0.5*(1.0+phi)*(lbinterforce[tpos*3*lbsy.nf+1] + lbheatforce[tpos*3*lbsy.nf+1] + postequil*(lbbdforce[1]+lboscilforce[1]*freq))
                 +  0.5*(1.0-phi)*(lbinterforce[tpos*3*lbsy.nf+4] + lbheatforce[tpos*3*lbsy.nf+4] + postequil*(lbbdforce[4]+lboscilforce[4]*freq));
        force[2] = -0.5*(1.0+phi)*(lbinterforce[tpos*3*lbsy.nf+2] + lbheatforce[tpos*3*lbsy.nf+2] + postequil*(lbbdforce[2]+lboscilforce[2]*freq))
                 -  0.5*(1.0-phi)*(lbinterforce[tpos*3*lbsy.nf+5] + lbheatforce[tpos*3*lbsy.nf+5] + postequil*(lbbdforce[5]+lboscilforce[5]*freq));
        force[3] =  0.0;
        force[4] =  0.0;
        force[5] =  0.0;
      }
      else {
        if(interact>9 && interact<20) {
          fD3CECCFracSite(frac, tpos1);
          for(int i=0; i<lbsy.nf; i++) {
            force[3*i  ] = -frac[i] * lbinterforce[tpos*3  ] - lbheatforce[tpos*3*lbsy.nf+3*i  ] - postequil * (lbbdforce[3*i  ]+lboscilforce[3*i  ]*freq);
            force[3*i+1] =  frac[i] * lbinterforce[tpos*3+1] + lbheatforce[tpos*3*lbsy.nf+3*i+1] + postequil * (lbbdforce[3*i+1]+lboscilforce[3*i+1]*freq);
            force[3*i+2] = -frac[i] * lbinterforce[tpos*3+2] - lbheatforce[tpos*3*lbsy.nf+3*i+2] - postequil * (lbbdforce[3*i+2]+lboscilforce[3*i+2]*freq);
          }
        }
        else {
          for(int i=0; i<lbsy.nf; i++) {
            force[3*i  ] = -lbinterforce[tpos*3*lbsy.nf+3*i  ] - lbheatforce[tpos*3*lbsy.nf+3*i  ] - postequil * (lbbdforce[3*i  ]+lboscilforce[3*i  ]*freq);
            force[3*i+1] =  lbinterforce[tpos*3*lbsy.nf+3*i+1] + lbheatforce[tpos*3*lbsy.nf+3*i+1] + postequil * (lbbdforce[3*i+1]+lboscilforce[3*i+1]*freq);
            force[3*i+2] = -lbinterforce[tpos*3*lbsy.nf+3*i+2] - lbheatforce[tpos*3*lbsy.nf+3*i+2] - postequil * (lbbdforce[3*i+2]+lboscilforce[3*i+2]*freq);
          }
        }
      }
      break;
    case CCDLB:
      if(interact==20 && lbsy.nf>1) {
        phi = fD3CECCSwiftPhi(tpos1, dx, dy, dz, lbft[4*lbsy.nf*tpos+4], lbft[4*lbsy.nf*tpos+5], lbft[4*lbsy.nf*tpos+6]);
        force[0] = -0.5*(1.0+phi)*(lbinterforce[tpos*3*lbsy.nf  ] + lbheatforce[tpos*3*lbsy.nf  ] + postequil*(lbbdforce[0]+lboscilforce[0]*freq))
                 -  0.5*(1.0-phi)*(lbinterforce[tpos*3*lbsy.nf+3] + lbheatforce[tpos*3*lbsy.nf+3] + postequil*(lbbdforce[3]+lboscilforce[3]*freq));
        force[1] = -0.5*(1.0+phi)*(lbinterforce[tpos*3*lbsy.nf+1] + lbheatforce[tpos*3*lbsy.nf+1] + postequil*(lbbdforce[1]+lboscilforce[1]*freq))
                 -  0.5*(1.0-phi)*(lbinterforce[tpos*3*lbsy.nf+4] + lbheatforce[tpos*3*lbsy.nf+4] + postequil*(lbbdforce[4]+lboscilforce[4]*freq));
        force[2] = -0.5*(1.0+phi)*(lbinterforce[tpos*3*lbsy.nf+2] + lbheatforce[tpos*3*lbsy.nf+2] + postequil*(lbbdforce[2]+lboscilforce[2]*freq))
                 -  0.5*(1.0-phi)*(lbinterforce[tpos*3*lbsy.nf+5] + lbheatforce[tpos*3*lbsy.nf+5] + postequil*(lbbdforce[5]+lboscilforce[5]*freq));
        force[3] =  0.0;
        force[4] =  0.0;
        force[5] =  0.0;
      }
      else {
        if(interact>9 && interact<20) {
          fD3CECCFracSite(frac, tpos1);
          for(int i=0; i<lbsy.nf; i++) {
            force[3*i  ] = -frac[i] * lbinterforce[tpos*3  ] - lbheatforce[tpos*3*lbsy.nf+3*i  ] - postequil * (lbbdforce[3*i  ]+lboscilforce[3*i  ]*freq);
            force[3*i+1] = -frac[i] * lbinterforce[tpos*3+1] - lbheatforce[tpos*3*lbsy.nf+3*i+1] - postequil * (lbbdforce[3*i+1]+lboscilforce[3*i+1]*freq);
            force[3*i+2] = -frac[i] * lbinterforce[tpos*3+2] - lbheatforce[tpos*3*lbsy.nf+3*i+2] - postequil * (lbbdforce[3*i+2]+lboscilforce[3*i+2]*freq);
          }
        }
        else {
          for(int i=0; i<lbsy.nf; i++) {
            force[3*i  ] = -lbinterforce[tpos*3*lbsy.nf+3*i  ] - lbheatforce[tpos*3*lbsy.nf+3*i  ] - postequil * (lbbdforce[3*i  ]+lboscilforce[3*i  ]*freq);
            force[3*i+1] = -lbinterforce[tpos*3*lbsy.nf+3*i+1] - lbheatforce[tpos*3*lbsy.nf+3*i+1] - postequil * (lbbdforce[3*i+1]+lboscilforce[3*i+1]*freq);
            force[3*i+2] = -lbinterforce[tpos*3*lbsy.nf+3*i+2] - lbheatforce[tpos*3*lbsy.nf+3*i+2] - postequil * (lbbdforce[3*i+2]+lboscilforce[3*i+2]*freq);
          }
        }
      }
      break;
    case CCDRB:
      if(interact==20 && lbsy.nf>1) {
        phi = fD3CECCSwiftPhi(tpos1, dx, dy, dz, lbft[4*lbsy.nf*tpos+4], lbft[4*lbsy.nf*tpos+5], lbft[4*lbsy.nf*tpos+6]);
        force[0] =  0.5*(1.0+phi)*(lbinterforce[tpos*3*lbsy.nf  ] + lbheatforce[tpos*3*lbsy.nf  ] + postequil*(lbbdforce[0]+lboscilforce[0]*freq))
                 +  0.5*(1.0-phi)*(lbinterforce[tpos*3*lbsy.nf+3] + lbheatforce[tpos*3*lbsy.nf+3] + postequil*(lbbdforce[3]+lboscilforce[3]*freq));
        force[1] = -0.5*(1.0+phi)*(lbinterforce[tpos*3*lbsy.nf+1] + lbheatforce[tpos*3*lbsy.nf+1] + postequil*(lbbdforce[1]+lboscilforce[1]*freq))
                 -  0.5*(1.0-phi)*(lbinterforce[tpos*3*lbsy.nf+4] + lbheatforce[tpos*3*lbsy.nf+4] + postequil*(lbbdforce[4]+lboscilforce[4]*freq));
        force[2] = -0.5*(1.0+phi)*(lbinterforce[tpos*3*lbsy.nf+2] + lbheatforce[tpos*3*lbsy.nf+2] + postequil*(lbbdforce[2]+lboscilforce[2]*freq))
                 -  0.5*(1.0-phi)*(lbinterforce[tpos*3*lbsy.nf+5] + lbheatforce[tpos*3*lbsy.nf+5] + postequil*(lbbdforce[5]+lboscilforce[5]*freq));
        force[3] =  0.0;
        force[4] =  0.0;
        force[5] =  0.0;
      }
      else {
        if(interact>9 && interact<20) {
          fD3CECCFracSite(frac, tpos1);
          for(int i=0; i<lbsy.nf; i++) {
            force[3*i  ] =  frac[i] * lbinterforce[tpos*3  ] + lbheatforce[tpos*3*lbsy.nf+3*i  ] + postequil * (lbbdforce[3*i  ]+lboscilforce[3*i  ]*freq);
            force[3*i+1] = -frac[i] * lbinterforce[tpos*3+1] - lbheatforce[tpos*3*lbsy.nf+3*i+1] - postequil * (lbbdforce[3*i+1]+lboscilforce[3*i+1]*freq);
            force[3*i+2] = -frac[i] * lbinterforce[tpos*3+2] - lbheatforce[tpos*3*lbsy.nf+3*i+2] - postequil * (lbbdforce[3*i+2]+lboscilforce[3*i+2]*freq);
          }
        }
        else {
          for(int i=0; i<lbsy.nf; i++) {
            force[3*i  ] =  lbinterforce[tpos*3*lbsy.nf+3*i  ] + lbheatforce[tpos*3*lbsy.nf+3*i  ] + postequil * (lbbdforce[3*i  ]+lboscilforce[3*i  ]*freq);
            force[3*i+1] = -lbinterforce[tpos*3*lbsy.nf+3*i+1] - lbheatforce[tpos*3*lbsy.nf+3*i+1] - postequil * (lbbdforce[3*i+1]+lboscilforce[3*i+1]*freq);
            force[3*i+2] = -lbinterforce[tpos*3*lbsy.nf+3*i+2] - lbheatforce[tpos*3*lbsy.nf+3*i+2] - postequil * (lbbdforce[3*i+2]+lboscilforce[3*i+2]*freq);
          }
        }
      }
      break;
    case CCTRF:
    case CETR:
      if(interact==20 && lbsy.nf>1) {
        phi = fD3CECCSwiftPhi(tpos1, dx, dy, dz, lbft[4*lbsy.nf*tpos+4], lbft[4*lbsy.nf*tpos+5], lbft[4*lbsy.nf*tpos+6]);
        force[0] = 0.5*(1.0+phi)*(lbinterforce[tpos*3*lbsy.nf  ] + lbheatforce[tpos*3*lbsy.nf  ] + postequil*(lbbdforce[0]+lboscilforce[0]*freq))
                 + 0.5*(1.0-phi)*(lbinterforce[tpos*3*lbsy.nf+3] + lbheatforce[tpos*3*lbsy.nf+3] + postequil*(lbbdforce[3]+lboscilforce[3]*freq));
        force[1] = 0.5*(1.0+phi)*(lbinterforce[tpos*3*lbsy.nf+1] + lbheatforce[tpos*3*lbsy.nf+1] + postequil*(lbbdforce[1]+lboscilforce[1]*freq))
                 + 0.5*(1.0-phi)*(lbinterforce[tpos*3*lbsy.nf+4] + lbheatforce[tpos*3*lbsy.nf+4] + postequil*(lbbdforce[4]+lboscilforce[4]*freq));
        force[2] = 0.5*(1.0+phi)*(lbinterforce[tpos*3*lbsy.nf+2] + lbheatforce[tpos*3*lbsy.nf+2] + postequil*(lbbdforce[2]+lboscilforce[2]*freq))
                 + 0.5*(1.0-phi)*(lbinterforce[tpos*3*lbsy.nf+5] + lbheatforce[tpos*3*lbsy.nf+5] + postequil*(lbbdforce[5]+lboscilforce[5]*freq));
        force[3] = 0.0;
        force[4] = 0.0;
        force[5] = 0.0;
      }
      else {
        if(interact>9 && interact<20) {
          fD3CECCFracSite(frac, tpos1);
          for(int i=0; i<lbsy.nf; i++) {
            force[3*i  ] = frac[i] * lbinterforce[tpos*3  ] + lbheatforce[tpos*3*lbsy.nf+3*i  ] + postequil * (lbbdforce[3*i  ]+lboscilforce[3*i  ]*freq);
            force[3*i+1] = frac[i] * lbinterforce[tpos*3+1] + lbheatforce[tpos*3*lbsy.nf+3*i+1] + postequil * (lbbdforce[3*i+1]+lboscilforce[3*i+1]*freq);
            force[3*i+2] = frac[i] * lbinterforce[tpos*3+2] + lbheatforce[tpos*3*lbsy.nf+3*i+2] + postequil * (lbbdforce[3*i+2]+lboscilforce[3*i+2]*freq);
          }
        }
        else {
          for(int i=0; i<lbsy.nf; i++) {
            force[3*i  ] = lbinterforce[tpos*3*lbsy.nf+3*i  ] + lbheatforce[tpos*3*lbsy.nf+3*i  ] + postequil * (lbbdforce[3*i  ]+lboscilforce[3*i  ]*freq);
            force[3*i+1] = lbinterforce[tpos*3*lbsy.nf+3*i+1] + lbheatforce[tpos*3*lbsy.nf+3*i+1] + postequil * (lbbdforce[3*i+1]+lboscilforce[3*i+1]*freq);
            force[3*i+2] = lbinterforce[tpos*3*lbsy.nf+3*i+2] + lbheatforce[tpos*3*lbsy.nf+3*i+2] + postequil * (lbbdforce[3*i+2]+lboscilforce[3*i+2]*freq);
          }
        }
      }
      break;
    case CCTLF:
      if(interact==20 && lbsy.nf>1) {
        phi = fD3CECCSwiftPhi(tpos1, dx, dy, dz, lbft[4*lbsy.nf*tpos+4], lbft[4*lbsy.nf*tpos+5], lbft[4*lbsy.nf*tpos+6]);
        force[0] = -0.5*(1.0+phi)*(lbinterforce[tpos*3*lbsy.nf  ] + lbheatforce[tpos*3*lbsy.nf  ] + postequil*(lbbdforce[0]+lboscilforce[0]*freq))
                 -  0.5*(1.0-phi)*(lbinterforce[tpos*3*lbsy.nf+3] + lbheatforce[tpos*3*lbsy.nf+3] + postequil*(lbbdforce[3]+lboscilforce[3]*freq));
        force[1] =  0.5*(1.0+phi)*(lbinterforce[tpos*3*lbsy.nf+1] + lbheatforce[tpos*3*lbsy.nf+1] + postequil*(lbbdforce[1]+lboscilforce[1]*freq))
                 +  0.5*(1.0-phi)*(lbinterforce[tpos*3*lbsy.nf+4] + lbheatforce[tpos*3*lbsy.nf+4] + postequil*(lbbdforce[4]+lboscilforce[4]*freq));
        force[2] =  0.5*(1.0+phi)*(lbinterforce[tpos*3*lbsy.nf+2] + lbheatforce[tpos*3*lbsy.nf+2] + postequil*(lbbdforce[2]+lboscilforce[2]*freq))
                 +  0.5*(1.0-phi)*(lbinterforce[tpos*3*lbsy.nf+5] + lbheatforce[tpos*3*lbsy.nf+5] + postequil*(lbbdforce[5]+lboscilforce[5]*freq));
        force[3] =  0.0;
        force[4] =  0.0;
        force[5] =  0.0;
      }
      else {
        if(interact>9 && interact<20) {
          fD3CECCFracSite(frac, tpos1);
          for(int i=0; i<lbsy.nf; i++) {
            force[3*i  ] = -frac[i] * lbinterforce[tpos*3  ] - lbheatforce[tpos*3*lbsy.nf+3*i  ] - postequil * (lbbdforce[3*i  ]+lboscilforce[3*i  ]*freq);
            force[3*i+1] =  frac[i] * lbinterforce[tpos*3+1] + lbheatforce[tpos*3*lbsy.nf+3*i+1] + postequil * (lbbdforce[3*i+1]+lboscilforce[3*i+1]*freq);
            force[3*i+2] =  frac[i] * lbinterforce[tpos*3+2] + lbheatforce[tpos*3*lbsy.nf+3*i+2] + postequil * (lbbdforce[3*i+2]+lboscilforce[3*i+2]*freq);
          }
        }
        else {
          for(int i=0; i<lbsy.nf; i++) {
            force[3*i  ] = -lbinterforce[tpos*3*lbsy.nf+3*i  ] - lbheatforce[tpos*3*lbsy.nf+3*i  ] - postequil * (lbbdforce[3*i  ]+lboscilforce[3*i  ]*freq);
            force[3*i+1] =  lbinterforce[tpos*3*lbsy.nf+3*i+1] + lbheatforce[tpos*3*lbsy.nf+3*i+1] + postequil * (lbbdforce[3*i+1]+lboscilforce[3*i+1]*freq);
            force[3*i+2] =  lbinterforce[tpos*3*lbsy.nf+3*i+2] + lbheatforce[tpos*3*lbsy.nf+3*i+2] + postequil * (lbbdforce[3*i+2]+lboscilforce[3*i+2]*freq);
          }
        }
      }
      break;
    case CCDLF:
    case CEDL:
      if(interact==20 && lbsy.nf>1) {
        phi = fD3CECCSwiftPhi(tpos1, dx, dy, dz, lbft[4*lbsy.nf*tpos+4], lbft[4*lbsy.nf*tpos+5], lbft[4*lbsy.nf*tpos+6]);
        force[0] = -0.5*(1.0+phi)*(lbinterforce[tpos*3*lbsy.nf  ] + lbheatforce[tpos*3*lbsy.nf  ] + postequil*(lbbdforce[0]+lboscilforce[0]*freq))
                 -  0.5*(1.0-phi)*(lbinterforce[tpos*3*lbsy.nf+3] + lbheatforce[tpos*3*lbsy.nf+3] + postequil*(lbbdforce[3]+lboscilforce[3]*freq));
        force[1] = -0.5*(1.0+phi)*(lbinterforce[tpos*3*lbsy.nf+1] + lbheatforce[tpos*3*lbsy.nf+1] + postequil*(lbbdforce[1]+lboscilforce[1]*freq))
                 -  0.5*(1.0-phi)*(lbinterforce[tpos*3*lbsy.nf+4] + lbheatforce[tpos*3*lbsy.nf+4] + postequil*(lbbdforce[4]+lboscilforce[4]*freq));
        force[2] =  0.5*(1.0+phi)*(lbinterforce[tpos*3*lbsy.nf+2] + lbheatforce[tpos*3*lbsy.nf+2] + postequil*(lbbdforce[2]+lboscilforce[2]*freq))
                 +  0.5*(1.0-phi)*(lbinterforce[tpos*3*lbsy.nf+5] + lbheatforce[tpos*3*lbsy.nf+5] + postequil*(lbbdforce[5]+lboscilforce[5]*freq));
        force[3] =  0.0;
        force[4] =  0.0;
        force[5] =  0.0;
      }
      else {
        if(interact>9 && interact<20) {
          fD3CECCFracSite(frac, tpos1);
          for(int i=0; i<lbsy.nf; i++) {
            force[3*i  ] = -frac[i] * lbinterforce[tpos*3  ] - lbheatforce[tpos*3*lbsy.nf+3*i  ] - postequil * (lbbdforce[3*i  ]+lboscilforce[3*i  ]*freq);
            force[3*i+1] = -frac[i] * lbinterforce[tpos*3+1] - lbheatforce[tpos*3*lbsy.nf+3*i+1] - postequil * (lbbdforce[3*i+1]+lboscilforce[3*i+1]*freq);
            force[3*i+2] =  frac[i] * lbinterforce[tpos*3+2] + lbheatforce[tpos*3*lbsy.nf+3*i+2] + postequil * (lbbdforce[3*i+2]+lboscilforce[3*i+2]*freq);
          }
        }
        else {
          for(int i=0; i<lbsy.nf; i++) {
            force[3*i  ] = -lbinterforce[tpos*3*lbsy.nf+3*i  ] - lbheatforce[tpos*3*lbsy.nf+3*i  ] - postequil * (lbbdforce[3*i  ]+lboscilforce[3*i  ]*freq);
            force[3*i+1] = -lbinterforce[tpos*3*lbsy.nf+3*i+1] - lbheatforce[tpos*3*lbsy.nf+3*i+1] - postequil * (lbbdforce[3*i+1]+lboscilforce[3*i+1]*freq);
            force[3*i+2] =  lbinterforce[tpos*3*lbsy.nf+3*i+2] + lbheatforce[tpos*3*lbsy.nf+3*i+2] + postequil * (lbbdforce[3*i+2]+lboscilforce[3*i+2]*freq);
          }
        }
      }
      break;
    case CCDRF:
      if(interact==20 && lbsy.nf>1) {
        phi = fD3CECCSwiftPhi(tpos1, dx, dy, dz, lbft[4*lbsy.nf*tpos+4], lbft[4*lbsy.nf*tpos+5], lbft[4*lbsy.nf*tpos+6]);
        force[0] =  0.5*(1.0+phi)*(lbinterforce[tpos*3*lbsy.nf  ] + lbheatforce[tpos*3*lbsy.nf  ] + postequil*(lbbdforce[0]+lboscilforce[0]*freq))
                 +  0.5*(1.0-phi)*(lbinterforce[tpos*3*lbsy.nf+3] + lbheatforce[tpos*3*lbsy.nf+3] + postequil*(lbbdforce[3]+lboscilforce[3]*freq));
        force[1] = -0.5*(1.0+phi)*(lbinterforce[tpos*3*lbsy.nf+1] + lbheatforce[tpos*3*lbsy.nf+1] + postequil*(lbbdforce[1]+lboscilforce[1]*freq))
                 -  0.5*(1.0-phi)*(lbinterforce[tpos*3*lbsy.nf+4] + lbheatforce[tpos*3*lbsy.nf+4] + postequil*(lbbdforce[4]+lboscilforce[4]*freq));
        force[2] =  0.5*(1.0+phi)*(lbinterforce[tpos*3*lbsy.nf+2] + lbheatforce[tpos*3*lbsy.nf+2] + postequil*(lbbdforce[2]+lboscilforce[2]*freq))
                 +  0.5*(1.0-phi)*(lbinterforce[tpos*3*lbsy.nf+5] + lbheatforce[tpos*3*lbsy.nf+5] + postequil*(lbbdforce[5]+lboscilforce[5]*freq));
        force[3] =  0.0;
        force[4] =  0.0;
        force[5] =  0.0;
      }
      else {
        if(interact>9 && interact<20) {
          fD3CECCFracSite(frac, tpos1);
          for(int i=0; i<lbsy.nf; i++) {
            force[3*i  ] =  frac[i] * lbinterforce[tpos*3  ] + lbheatforce[tpos*3*lbsy.nf+3*i  ] + postequil * (lbbdforce[3*i  ]+lboscilforce[3*i  ]*freq);
            force[3*i+1] = -frac[i] * lbinterforce[tpos*3+1] - lbheatforce[tpos*3*lbsy.nf+3*i+1] - postequil * (lbbdforce[3*i+1]+lboscilforce[3*i+1]*freq);
            force[3*i+2] =  frac[i] * lbinterforce[tpos*3+2] + lbheatforce[tpos*3*lbsy.nf+3*i+2] + postequil * (lbbdforce[3*i+2]+lboscilforce[3*i+2]*freq);
          }
        }
        else {
          for(int i=0; i<lbsy.nf; i++) {
            force[3*i  ] =  lbinterforce[tpos*3*lbsy.nf+3*i  ] + lbheatforce[tpos*3*lbsy.nf+3*i  ] + postequil * (lbbdforce[3*i  ]+lboscilforce[3*i  ]*freq);
            force[3*i+1] = -lbinterforce[tpos*3*lbsy.nf+3*i+1] - lbheatforce[tpos*3*lbsy.nf+3*i+1] - postequil * (lbbdforce[3*i+1]+lboscilforce[3*i+1]*freq);
            force[3*i+2] =  lbinterforce[tpos*3*lbsy.nf+3*i+2] + lbheatforce[tpos*3*lbsy.nf+3*i+2] + postequil * (lbbdforce[3*i+2]+lboscilforce[3*i+2]*freq);
          }
        }
      }
      break;
    case CETL:
      if(interact==20 && lbsy.nf>1) {
        phi = fD3CECCSwiftPhi(tpos1, dx, dy, dz, lbft[4*lbsy.nf*tpos+4], lbft[4*lbsy.nf*tpos+5], lbft[4*lbsy.nf*tpos+6]);
        force[1] = -0.5*(1.0+phi)*(lbinterforce[tpos*3*lbsy.nf  ] + lbheatforce[tpos*3*lbsy.nf  ] + postequil*(lbbdforce[0]+lboscilforce[0]*freq))
                 -  0.5*(1.0-phi)*(lbinterforce[tpos*3*lbsy.nf+3] + lbheatforce[tpos*3*lbsy.nf+3] + postequil*(lbbdforce[3]+lboscilforce[3]*freq));
        force[0] =  0.5*(1.0+phi)*(lbinterforce[tpos*3*lbsy.nf+1] + lbheatforce[tpos*3*lbsy.nf+1] + postequil*(lbbdforce[1]+lboscilforce[1]*freq))
                 +  0.5*(1.0-phi)*(lbinterforce[tpos*3*lbsy.nf+4] + lbheatforce[tpos*3*lbsy.nf+4] + postequil*(lbbdforce[4]+lboscilforce[4]*freq));
        force[2] =  0.5*(1.0+phi)*(lbinterforce[tpos*3*lbsy.nf+2] + lbheatforce[tpos*3*lbsy.nf+2] + postequil*(lbbdforce[2]+lboscilforce[2]*freq))
                 +  0.5*(1.0-phi)*(lbinterforce[tpos*3*lbsy.nf+5] + lbheatforce[tpos*3*lbsy.nf+5] + postequil*(lbbdforce[5]+lboscilforce[5]*freq));
        force[3] =  0.0;
        force[4] =  0.0;
        force[5] =  0.0;
      }
      else {
        if(interact>9 && interact<20) {
          fD3CECCFracSite(frac, tpos1);
          for(int i=0; i<lbsy.nf; i++) {
            force[3*i+1] = -frac[i] * lbinterforce[tpos*3  ] - lbheatforce[tpos*3*lbsy.nf+3*i  ] - postequil * (lbbdforce[3*i  ]+lboscilforce[3*i  ]*freq);
            force[3*i  ] =  frac[i] * lbinterforce[tpos*3+1] + lbheatforce[tpos*3*lbsy.nf+3*i+1] + postequil * (lbbdforce[3*i+1]+lboscilforce[3*i+1]*freq);
            force[3*i+2] =  frac[i] * lbinterforce[tpos*3+2] + lbheatforce[tpos*3*lbsy.nf+3*i+2] + postequil * (lbbdforce[3*i+2]+lboscilforce[3*i+2]*freq);
          }
        }
        else {
          for(int i=0; i<lbsy.nf; i++) {
            force[3*i+1] = -lbinterforce[tpos*3*lbsy.nf+3*i  ] - lbheatforce[tpos*3*lbsy.nf+3*i  ] - postequil * (lbbdforce[3*i  ]+lboscilforce[3*i  ]*freq);
            force[3*i  ] =  lbinterforce[tpos*3*lbsy.nf+3*i+1] + lbheatforce[tpos*3*lbsy.nf+3*i+1] + postequil * (lbbdforce[3*i+1]+lboscilforce[3*i+1]*freq);
            force[3*i+2] =  lbinterforce[tpos*3*lbsy.nf+3*i+2] + lbheatforce[tpos*3*lbsy.nf+3*i+2] + postequil * (lbbdforce[3*i+2]+lboscilforce[3*i+2]*freq);
          }
        }
      }
      break;
    case CEDR:
      if(interact==20 && lbsy.nf>1) {
        phi = fD3CECCSwiftPhi(tpos1, dx, dy, dz, lbft[4*lbsy.nf*tpos+4], lbft[4*lbsy.nf*tpos+5], lbft[4*lbsy.nf*tpos+6]);
        force[1] =  0.5*(1.0+phi)*(lbinterforce[tpos*3*lbsy.nf  ] + lbheatforce[tpos*3*lbsy.nf  ] + postequil*(lbbdforce[0]+lboscilforce[0]*freq))
                 +  0.5*(1.0-phi)*(lbinterforce[tpos*3*lbsy.nf+3] + lbheatforce[tpos*3*lbsy.nf+3] + postequil*(lbbdforce[3]+lboscilforce[3]*freq));
        force[0] = -0.5*(1.0+phi)*(lbinterforce[tpos*3*lbsy.nf+1] + lbheatforce[tpos*3*lbsy.nf+1] + postequil*(lbbdforce[1]+lboscilforce[1]*freq))
                 -  0.5*(1.0-phi)*(lbinterforce[tpos*3*lbsy.nf+4] + lbheatforce[tpos*3*lbsy.nf+4] + postequil*(lbbdforce[4]+lboscilforce[4]*freq));
        force[2] =  0.5*(1.0+phi)*(lbinterforce[tpos*3*lbsy.nf+2] + lbheatforce[tpos*3*lbsy.nf+2] + postequil*(lbbdforce[2]+lboscilforce[2]*freq))
                 +  0.5*(1.0-phi)*(lbinterforce[tpos*3*lbsy.nf+5] + lbheatforce[tpos*3*lbsy.nf+5] + postequil*(lbbdforce[5]+lboscilforce[5]*freq));
        force[3] =  0.0;
        force[4] =  0.0;
        force[5] =  0.0;
      }
      else {
        if(interact>9 && interact<20) {
          fD3CECCFracSite(frac, tpos1);
          for(int i=0; i<lbsy.nf; i++) {
            force[3*i+1] =  frac[i] * lbinterforce[tpos*3  ] + lbheatforce[tpos*3*lbsy.nf+3*i  ] + postequil * (lbbdforce[3*i  ]+lboscilforce[3*i  ]*freq);
            force[3*i  ] = -frac[i] * lbinterforce[tpos*3+1] - lbheatforce[tpos*3*lbsy.nf+3*i+1] - postequil * (lbbdforce[3*i+1]+lboscilforce[3*i+1]*freq);
            force[3*i+2] =  frac[i] * lbinterforce[tpos*3+2] + lbheatforce[tpos*3*lbsy.nf+3*i+2] + postequil * (lbbdforce[3*i+2]+lboscilforce[3*i+2]*freq);
          }
        }
        else {
          for(int i=0; i<lbsy.nf; i++) {
            force[3*i+1] =  lbinterforce[tpos*3*lbsy.nf+3*i  ] + lbheatforce[tpos*3*lbsy.nf+3*i  ] + postequil * (lbbdforce[3*i  ]+lboscilforce[3*i  ]*freq);
            force[3*i  ] = -lbinterforce[tpos*3*lbsy.nf+3*i+1] - lbheatforce[tpos*3*lbsy.nf+3*i+1] - postequil * (lbbdforce[3*i+1]+lboscilforce[3*i+1]*freq);
            force[3*i+2] =  lbinterforce[tpos*3*lbsy.nf+3*i+2] + lbheatforce[tpos*3*lbsy.nf+3*i+2] + postequil * (lbbdforce[3*i+2]+lboscilforce[3*i+2]*freq);
          }
        }
      }
      break;
    case CETF:
      if(interact==20 && lbsy.nf>1) {
        phi = fD3CECCSwiftPhi(tpos1, dx, dy, dz, lbft[4*lbsy.nf*tpos+4], lbft[4*lbsy.nf*tpos+5], lbft[4*lbsy.nf*tpos+6]);
        force[2] = 0.5*(1.0+phi)*(lbinterforce[tpos*3*lbsy.nf  ] + lbheatforce[tpos*3*lbsy.nf  ] + postequil*(lbbdforce[0]+lboscilforce[0]*freq))
                 + 0.5*(1.0-phi)*(lbinterforce[tpos*3*lbsy.nf+3] + lbheatforce[tpos*3*lbsy.nf+3] + postequil*(lbbdforce[3]+lboscilforce[3]*freq));
        force[0] = 0.5*(1.0+phi)*(lbinterforce[tpos*3*lbsy.nf+1] + lbheatforce[tpos*3*lbsy.nf+1] + postequil*(lbbdforce[1]+lboscilforce[1]*freq))
                 + 0.5*(1.0-phi)*(lbinterforce[tpos*3*lbsy.nf+4] + lbheatforce[tpos*3*lbsy.nf+4] + postequil*(lbbdforce[4]+lboscilforce[4]*freq));
        force[1] = 0.5*(1.0+phi)*(lbinterforce[tpos*3*lbsy.nf+2] + lbheatforce[tpos*3*lbsy.nf+2] + postequil*(lbbdforce[2]+lboscilforce[2]*freq))
                 + 0.5*(1.0-phi)*(lbinterforce[tpos*3*lbsy.nf+5] + lbheatforce[tpos*3*lbsy.nf+5] + postequil*(lbbdforce[5]+lboscilforce[5]*freq));
        force[3] = 0.0;
        force[4] = 0.0;
        force[5] = 0.0;
      }
      else {
        if(interact>9 && interact<20) {
          fD3CECCFracSite(frac, tpos1);
          for(int i=0; i<lbsy.nf; i++) {
            force[3*i+2] = frac[i] * lbinterforce[tpos*3  ] + lbheatforce[tpos*3*lbsy.nf+3*i  ] + postequil * (lbbdforce[3*i  ]+lboscilforce[3*i  ]*freq);
            force[3*i  ] = frac[i] * lbinterforce[tpos*3+1] + lbheatforce[tpos*3*lbsy.nf+3*i+1] + postequil * (lbbdforce[3*i+1]+lboscilforce[3*i+1]*freq);
            force[3*i+1] = frac[i] * lbinterforce[tpos*3+2] + lbheatforce[tpos*3*lbsy.nf+3*i+2] + postequil * (lbbdforce[3*i+2]+lboscilforce[3*i+2]*freq);
          }
        }
        else {
          for(int i=0; i<lbsy.nf; i++) {
            force[3*i+2] = lbinterforce[tpos*3*lbsy.nf+3*i  ] + lbheatforce[tpos*3*lbsy.nf+3*i  ] + postequil * (lbbdforce[3*i  ]+lboscilforce[3*i  ]*freq);
            force[3*i  ] = lbinterforce[tpos*3*lbsy.nf+3*i+1] + lbheatforce[tpos*3*lbsy.nf+3*i+1] + postequil * (lbbdforce[3*i+1]+lboscilforce[3*i+1]*freq);
            force[3*i+1] = lbinterforce[tpos*3*lbsy.nf+3*i+2] + lbheatforce[tpos*3*lbsy.nf+3*i+2] + postequil * (lbbdforce[3*i+2]+lboscilforce[3*i+2]*freq);
          }
        }
      }
      break;
    case CELF:
      if(interact==20 && lbsy.nf>1) {
        phi = fD3CECCSwiftPhi(tpos1, dx, dy, dz, lbft[4*lbsy.nf*tpos+4], lbft[4*lbsy.nf*tpos+5], lbft[4*lbsy.nf*tpos+6]);
        force[0] = -0.5*(1.0+phi)*(lbinterforce[tpos*3*lbsy.nf  ] + lbheatforce[tpos*3*lbsy.nf  ] + postequil*(lbbdforce[0]+lboscilforce[0]*freq))
                 -  0.5*(1.0-phi)*(lbinterforce[tpos*3*lbsy.nf+3] + lbheatforce[tpos*3*lbsy.nf+3] + postequil*(lbbdforce[3]+lboscilforce[3]*freq));
        force[2] =  0.5*(1.0+phi)*(lbinterforce[tpos*3*lbsy.nf+1] + lbheatforce[tpos*3*lbsy.nf+1] + postequil*(lbbdforce[1]+lboscilforce[1]*freq))
                 +  0.5*(1.0-phi)*(lbinterforce[tpos*3*lbsy.nf+4] + lbheatforce[tpos*3*lbsy.nf+4] + postequil*(lbbdforce[4]+lboscilforce[4]*freq));
        force[1] =  0.5*(1.0+phi)*(lbinterforce[tpos*3*lbsy.nf+2] + lbheatforce[tpos*3*lbsy.nf+2] + postequil*(lbbdforce[2]+lboscilforce[2]*freq))
                 +  0.5*(1.0-phi)*(lbinterforce[tpos*3*lbsy.nf+5] + lbheatforce[tpos*3*lbsy.nf+5] + postequil*(lbbdforce[5]+lboscilforce[5]*freq));
        force[3] =  0.0;
        force[4] =  0.0;
        force[5] =  0.0;
      }
      else {
        if(interact>9 && interact<20) {
          fD3CECCFracSite(frac, tpos1);
          for(int i=0; i<lbsy.nf; i++) {
            force[3*i  ] = -frac[i] * lbinterforce[tpos*3  ] - lbheatforce[tpos*3*lbsy.nf+3*i  ] - postequil * (lbbdforce[3*i  ]+lboscilforce[3*i  ]*freq);
            force[3*i+2] =  frac[i] * lbinterforce[tpos*3+1] + lbheatforce[tpos*3*lbsy.nf+3*i+1] + postequil * (lbbdforce[3*i+1]+lboscilforce[3*i+1]*freq);
            force[3*i+1] =  frac[i] * lbinterforce[tpos*3+2] + lbheatforce[tpos*3*lbsy.nf+3*i+2] + postequil * (lbbdforce[3*i+2]+lboscilforce[3*i+2]*freq);
          }
        }
        else {
          for(int i=0; i<lbsy.nf; i++) {
            force[3*i  ] = -lbinterforce[tpos*3*lbsy.nf+3*i  ] - lbheatforce[tpos*3*lbsy.nf+3*i  ] - postequil * (lbbdforce[3*i  ]+lboscilforce[3*i  ]*freq);
            force[3*i+2] =  lbinterforce[tpos*3*lbsy.nf+3*i+1] + lbheatforce[tpos*3*lbsy.nf+3*i+1] + postequil * (lbbdforce[3*i+1]+lboscilforce[3*i+1]*freq);
            force[3*i+1] =  lbinterforce[tpos*3*lbsy.nf+3*i+2] + lbheatforce[tpos*3*lbsy.nf+3*i+2] + postequil * (lbbdforce[3*i+2]+lboscilforce[3*i+2]*freq);
          }
        }
      }
      break;
    case CEDF:
      if(interact==20 && lbsy.nf>1) {
        phi = fD3CECCSwiftPhi(tpos1, dx, dy, dz, lbft[4*lbsy.nf*tpos+4], lbft[4*lbsy.nf*tpos+5], lbft[4*lbsy.nf*tpos+6]);
        force[2] =  0.5*(1.0+phi)*(lbinterforce[tpos*3*lbsy.nf  ] + lbheatforce[tpos*3*lbsy.nf  ] + postequil*(lbbdforce[0]+lboscilforce[0]*freq))
                 +  0.5*(1.0-phi)*(lbinterforce[tpos*3*lbsy.nf+3] + lbheatforce[tpos*3*lbsy.nf+3] + postequil*(lbbdforce[3]+lboscilforce[3]*freq));
        force[0] = -0.5*(1.0+phi)*(lbinterforce[tpos*3*lbsy.nf+1] + lbheatforce[tpos*3*lbsy.nf+1] + postequil*(lbbdforce[1]+lboscilforce[1]*freq))
                 -  0.5*(1.0-phi)*(lbinterforce[tpos*3*lbsy.nf+4] + lbheatforce[tpos*3*lbsy.nf+4] + postequil*(lbbdforce[4]+lboscilforce[4]*freq));
        force[1] =  0.5*(1.0+phi)*(lbinterforce[tpos*3*lbsy.nf+2] + lbheatforce[tpos*3*lbsy.nf+2] + postequil*(lbbdforce[2]+lboscilforce[2]*freq))
                 +  0.5*(1.0-phi)*(lbinterforce[tpos*3*lbsy.nf+5] + lbheatforce[tpos*3*lbsy.nf+5] + postequil*(lbbdforce[5]+lboscilforce[5]*freq));
        force[3] =  0.0;
        force[4] =  0.0;
        force[5] =  0.0;
      }
      else {
        if(interact>9 && interact<20) {
          fD3CECCFracSite(frac, tpos1);
          for(int i=0; i<lbsy.nf; i++) {
            force[3*i+2] =  frac[i] * lbinterforce[tpos*3  ] + lbheatforce[tpos*3*lbsy.nf+3*i  ] + postequil * (lbbdforce[3*i  ]+lboscilforce[3*i  ]*freq);
            force[3*i  ] = -frac[i] * lbinterforce[tpos*3+1] - lbheatforce[tpos*3*lbsy.nf+3*i+1] - postequil * (lbbdforce[3*i+1]+lboscilforce[3*i+1]*freq);
            force[3*i+1] =  frac[i] * lbinterforce[tpos*3+2] + lbheatforce[tpos*3*lbsy.nf+3*i+2] + postequil * (lbbdforce[3*i+2]+lboscilforce[3*i+2]*freq);
          }
        }
        else {
          for(int i=0; i<lbsy.nf; i++) {
            force[3*i+2] =  lbinterforce[tpos*3*lbsy.nf+3*i  ] + lbheatforce[tpos*3*lbsy.nf+3*i  ] + postequil * (lbbdforce[3*i  ]+lboscilforce[3*i  ]*freq);
            force[3*i  ] = -lbinterforce[tpos*3*lbsy.nf+3*i+1] - lbheatforce[tpos*3*lbsy.nf+3*i+1] - postequil * (lbbdforce[3*i+1]+lboscilforce[3*i+1]*freq);
            force[3*i+1] =  lbinterforce[tpos*3*lbsy.nf+3*i+2] + lbheatforce[tpos*3*lbsy.nf+3*i+2] + postequil * (lbbdforce[3*i+2]+lboscilforce[3*i+2]*freq);
          }
        }
      }
      break;
    case CERF:
      if(interact==20 && lbsy.nf>1) {
        phi = fD3CECCSwiftPhi(tpos1, dx, dy, dz, lbft[4*lbsy.nf*tpos+4], lbft[4*lbsy.nf*tpos+5], lbft[4*lbsy.nf*tpos+6]);
        force[0] = 0.5*(1.0+phi)*(lbinterforce[tpos*3*lbsy.nf  ] + lbheatforce[tpos*3*lbsy.nf  ] + postequil*(lbbdforce[0]+lboscilforce[0]*freq))
                 + 0.5*(1.0-phi)*(lbinterforce[tpos*3*lbsy.nf+3] + lbheatforce[tpos*3*lbsy.nf+3] + postequil*(lbbdforce[3]+lboscilforce[3]*freq));
        force[2] = 0.5*(1.0+phi)*(lbinterforce[tpos*3*lbsy.nf+1] + lbheatforce[tpos*3*lbsy.nf+1] + postequil*(lbbdforce[1]+lboscilforce[1]*freq))
                 + 0.5*(1.0-phi)*(lbinterforce[tpos*3*lbsy.nf+4] + lbheatforce[tpos*3*lbsy.nf+4] + postequil*(lbbdforce[4]+lboscilforce[4]*freq));
        force[1] = 0.5*(1.0+phi)*(lbinterforce[tpos*3*lbsy.nf+2] + lbheatforce[tpos*3*lbsy.nf+2] + postequil*(lbbdforce[2]+lboscilforce[2]*freq))
                 + 0.5*(1.0-phi)*(lbinterforce[tpos*3*lbsy.nf+5] + lbheatforce[tpos*3*lbsy.nf+5] + postequil*(lbbdforce[5]+lboscilforce[5]*freq));
        force[3] = 0.0;
        force[4] = 0.0;
        force[5] = 0.0;
      }
      else {
        if(interact>9 && interact<20) {
          fD3CECCFracSite(frac, tpos1);
          for(int i=0; i<lbsy.nf; i++) {
            force[3*i  ] = frac[i] * lbinterforce[tpos*3  ] + lbheatforce[tpos*3*lbsy.nf+3*i  ] + postequil * (lbbdforce[3*i  ]+lboscilforce[3*i  ]*freq);
            force[3*i+2] = frac[i] * lbinterforce[tpos*3+1] + lbheatforce[tpos*3*lbsy.nf+3*i+1] + postequil * (lbbdforce[3*i+1]+lboscilforce[3*i+1]*freq);
            force[3*i+1] = frac[i] * lbinterforce[tpos*3+2] + lbheatforce[tpos*3*lbsy.nf+3*i+2] + postequil * (lbbdforce[3*i+2]+lboscilforce[3*i+2]*freq);
          }
        }
        else {
          for(int i=0; i<lbsy.nf; i++) {
            force[3*i  ] = lbinterforce[tpos*3*lbsy.nf+3*i  ] + lbheatforce[tpos*3*lbsy.nf+3*i  ] + postequil * (lbbdforce[3*i  ]+lboscilforce[3*i  ]*freq);
            force[3*i+2] = lbinterforce[tpos*3*lbsy.nf+3*i+1] + lbheatforce[tpos*3*lbsy.nf+3*i+1] + postequil * (lbbdforce[3*i+1]+lboscilforce[3*i+1]*freq);
            force[3*i+1] = lbinterforce[tpos*3*lbsy.nf+3*i+2] + lbheatforce[tpos*3*lbsy.nf+3*i+2] + postequil * (lbbdforce[3*i+2]+lboscilforce[3*i+2]*freq);
          }
        }
      }
      break;
    case CETB:
      if(interact==20 && lbsy.nf>1) {
        phi = fD3CECCSwiftPhi(tpos1, dx, dy, dz, lbft[4*lbsy.nf*tpos+4], lbft[4*lbsy.nf*tpos+5], lbft[4*lbsy.nf*tpos+6]);
        force[2] =  0.5*(1.0+phi)*(lbinterforce[tpos*3*lbsy.nf  ] + lbheatforce[tpos*3*lbsy.nf  ] + postequil*(lbbdforce[0]+lboscilforce[0]*freq))
                 +  0.5*(1.0-phi)*(lbinterforce[tpos*3*lbsy.nf+3] + lbheatforce[tpos*3*lbsy.nf+3] + postequil*(lbbdforce[3]+lboscilforce[3]*freq));
        force[0] =  0.5*(1.0+phi)*(lbinterforce[tpos*3*lbsy.nf+1] + lbheatforce[tpos*3*lbsy.nf+1] + postequil*(lbbdforce[1]+lboscilforce[1]*freq))
                 +  0.5*(1.0-phi)*(lbinterforce[tpos*3*lbsy.nf+4] + lbheatforce[tpos*3*lbsy.nf+4] + postequil*(lbbdforce[4]+lboscilforce[4]*freq));
        force[1] = -0.5*(1.0+phi)*(lbinterforce[tpos*3*lbsy.nf+2] + lbheatforce[tpos*3*lbsy.nf+2] + postequil*(lbbdforce[2]+lboscilforce[2]*freq))
                 -  0.5*(1.0-phi)*(lbinterforce[tpos*3*lbsy.nf+5] + lbheatforce[tpos*3*lbsy.nf+5] + postequil*(lbbdforce[5]+lboscilforce[5]*freq));
        force[3] =  0.0;
        force[4] =  0.0;
        force[5] =  0.0;
      }
      else {
        if(interact>9 && interact<20) {
          fD3CECCFracSite(frac, tpos1);
          for(int i=0; i<lbsy.nf; i++) {
            force[3*i+2] =  frac[i] * lbinterforce[tpos*3  ] + lbheatforce[tpos*3*lbsy.nf+3*i  ] + postequil * (lbbdforce[3*i  ]+lboscilforce[3*i  ]*freq);
            force[3*i  ] =  frac[i] * lbinterforce[tpos*3+1] + lbheatforce[tpos*3*lbsy.nf+3*i+1] + postequil * (lbbdforce[3*i+1]+lboscilforce[3*i+1]*freq);
            force[3*i+1] = -frac[i] * lbinterforce[tpos*3+2] - lbheatforce[tpos*3*lbsy.nf+3*i+2] - postequil * (lbbdforce[3*i+2]+lboscilforce[3*i+2]*freq);
          }
        }
        else {
          for(int i=0; i<lbsy.nf; i++) {
            force[3*i+2] =  lbinterforce[tpos*3*lbsy.nf+3*i  ] + lbheatforce[tpos*3*lbsy.nf+3*i  ] + postequil * (lbbdforce[3*i  ]+lboscilforce[3*i  ]*freq);
            force[3*i  ] =  lbinterforce[tpos*3*lbsy.nf+3*i+1] + lbheatforce[tpos*3*lbsy.nf+3*i+1] + postequil * (lbbdforce[3*i+1]+lboscilforce[3*i+1]*freq);
            force[3*i+1] = -lbinterforce[tpos*3*lbsy.nf+3*i+2] - lbheatforce[tpos*3*lbsy.nf+3*i+2] - postequil * (lbbdforce[3*i+2]+lboscilforce[3*i+2]*freq);
          }
        }
      }
      break;
    case CELB:
      if(interact==20 && lbsy.nf>1) {
        phi = fD3CECCSwiftPhi(tpos1, dx, dy, dz, lbft[4*lbsy.nf*tpos+4], lbft[4*lbsy.nf*tpos+5], lbft[4*lbsy.nf*tpos+6]);
        force[0] = -0.5*(1.0+phi)*(lbinterforce[tpos*3*lbsy.nf  ] + lbheatforce[tpos*3*lbsy.nf  ] + postequil*(lbbdforce[0]+lboscilforce[0]*freq))
                 -  0.5*(1.0-phi)*(lbinterforce[tpos*3*lbsy.nf+3] + lbheatforce[tpos*3*lbsy.nf+3] + postequil*(lbbdforce[3]+lboscilforce[3]*freq));
        force[2] =  0.5*(1.0+phi)*(lbinterforce[tpos*3*lbsy.nf+1] + lbheatforce[tpos*3*lbsy.nf+1] + postequil*(lbbdforce[1]+lboscilforce[1]*freq))
                 +  0.5*(1.0-phi)*(lbinterforce[tpos*3*lbsy.nf+4] + lbheatforce[tpos*3*lbsy.nf+4] + postequil*(lbbdforce[4]+lboscilforce[4]*freq));
        force[1] = -0.5*(1.0+phi)*(lbinterforce[tpos*3*lbsy.nf+2] + lbheatforce[tpos*3*lbsy.nf+2] + postequil*(lbbdforce[2]+lboscilforce[2]*freq))
                 -  0.5*(1.0-phi)*(lbinterforce[tpos*3*lbsy.nf+5] + lbheatforce[tpos*3*lbsy.nf+5] + postequil*(lbbdforce[5]+lboscilforce[5]*freq));
        force[3] =  0.0;
        force[4] =  0.0;
        force[5] =  0.0;
      }
      else {
        if(interact>9 && interact<20) {
          fD3CECCFracSite(frac, tpos1);
          for(int i=0; i<lbsy.nf; i++) {
            force[3*i  ] = -frac[i] * lbinterforce[tpos*3  ] - lbheatforce[tpos*3*lbsy.nf+3*i  ] - postequil * (lbbdforce[3*i  ]+lboscilforce[3*i  ]*freq);
            force[3*i+2] =  frac[i] * lbinterforce[tpos*3+1] + lbheatforce[tpos*3*lbsy.nf+3*i+1] + postequil * (lbbdforce[3*i+1]+lboscilforce[3*i+1]*freq);
            force[3*i+1] = -frac[i] * lbinterforce[tpos*3+2] - lbheatforce[tpos*3*lbsy.nf+3*i+2] - postequil * (lbbdforce[3*i+2]+lboscilforce[3*i+2]*freq);
          }
        }
        else {
          for(int i=0; i<lbsy.nf; i++) {
            force[3*i  ] = -lbinterforce[tpos*3*lbsy.nf+3*i  ] - lbheatforce[tpos*3*lbsy.nf+3*i  ] - postequil * (lbbdforce[3*i  ]+lboscilforce[3*i  ]*freq);
            force[3*i+2] =  lbinterforce[tpos*3*lbsy.nf+3*i+1] + lbheatforce[tpos*3*lbsy.nf+3*i+1] + postequil * (lbbdforce[3*i+1]+lboscilforce[3*i+1]*freq);
            force[3*i+1] = -lbinterforce[tpos*3*lbsy.nf+3*i+2] - lbheatforce[tpos*3*lbsy.nf+3*i+2] - postequil * (lbbdforce[3*i+2]+lboscilforce[3*i+2]*freq);
          }
        }
      }
      break;
    case CEDB:
      if(interact==20 && lbsy.nf>1) {
        phi = fD3CECCSwiftPhi(tpos1, dx, dy, dz, lbft[4*lbsy.nf*tpos+4], lbft[4*lbsy.nf*tpos+5], lbft[4*lbsy.nf*tpos+6]);
        force[2] =  0.5*(1.0+phi)*(lbinterforce[tpos*3*lbsy.nf  ] + lbheatforce[tpos*3*lbsy.nf  ] + postequil*(lbbdforce[0]+lboscilforce[0]*freq))
                 +  0.5*(1.0-phi)*(lbinterforce[tpos*3*lbsy.nf+3] + lbheatforce[tpos*3*lbsy.nf+3] + postequil*(lbbdforce[3]+lboscilforce[3]*freq));
        force[0] = -0.5*(1.0+phi)*(lbinterforce[tpos*3*lbsy.nf+1] + lbheatforce[tpos*3*lbsy.nf+1] + postequil*(lbbdforce[1]+lboscilforce[1]*freq))
                 -  0.5*(1.0-phi)*(lbinterforce[tpos*3*lbsy.nf+4] + lbheatforce[tpos*3*lbsy.nf+4] + postequil*(lbbdforce[4]+lboscilforce[4]*freq));
        force[1] = -0.5*(1.0+phi)*(lbinterforce[tpos*3*lbsy.nf+2] + lbheatforce[tpos*3*lbsy.nf+2] + postequil*(lbbdforce[2]+lboscilforce[2]*freq))
                 -  0.5*(1.0-phi)*(lbinterforce[tpos*3*lbsy.nf+5] + lbheatforce[tpos*3*lbsy.nf+5] + postequil*(lbbdforce[5]+lboscilforce[5]*freq));
        force[3] =  0.0;
        force[4] =  0.0;
        force[5] =  0.0;
      }
      else {
        if(interact>9 && interact<20) {
          fD3CECCFracSite(frac, tpos1);
          for(int i=0; i<lbsy.nf; i++) {
            force[3*i+2] =  frac[i] * lbinterforce[tpos*3  ] + lbheatforce[tpos*3*lbsy.nf+3*i  ] + postequil * (lbbdforce[3*i  ]+lboscilforce[3*i  ]*freq);
            force[3*i  ] = -frac[i] * lbinterforce[tpos*3+1] - lbheatforce[tpos*3*lbsy.nf+3*i+1] - postequil * (lbbdforce[3*i+1]+lboscilforce[3*i+1]*freq);
            force[3*i+1] = -frac[i] * lbinterforce[tpos*3+2] - lbheatforce[tpos*3*lbsy.nf+3*i+2] - postequil * (lbbdforce[3*i+2]+lboscilforce[3*i+2]*freq);
          }
        }
        else {
          for(int i=0; i<lbsy.nf; i++) {
            force[3*i+2] =  lbinterforce[tpos*3*lbsy.nf+3*i  ] + lbheatforce[tpos*3*lbsy.nf+3*i  ] + postequil * (lbbdforce[3*i  ]+lboscilforce[3*i  ]*freq);
            force[3*i  ] = -lbinterforce[tpos*3*lbsy.nf+3*i+1] - lbheatforce[tpos*3*lbsy.nf+3*i+1] - postequil * (lbbdforce[3*i+1]+lboscilforce[3*i+1]*freq);
            force[3*i+1] = -lbinterforce[tpos*3*lbsy.nf+3*i+2] - lbheatforce[tpos*3*lbsy.nf+3*i+2] - postequil * (lbbdforce[3*i+2]+lboscilforce[3*i+2]*freq);
          }
        }
      }
      break;
    case CERB:
      if(interact==20 && lbsy.nf>1) {
        phi = fD3CECCSwiftPhi(tpos1, dx, dy, dz, lbft[4*lbsy.nf*tpos+4], lbft[4*lbsy.nf*tpos+5], lbft[4*lbsy.nf*tpos+6]);
        force[0] =  0.5*(1.0+phi)*(lbinterforce[tpos*3*lbsy.nf  ] + lbheatforce[tpos*3*lbsy.nf  ] + postequil*(lbbdforce[0]+lboscilforce[0]*freq))
                 +  0.5*(1.0-phi)*(lbinterforce[tpos*3*lbsy.nf+3] + lbheatforce[tpos*3*lbsy.nf+3] + postequil*(lbbdforce[3]+lboscilforce[3]*freq));
        force[2] =  0.5*(1.0+phi)*(lbinterforce[tpos*3*lbsy.nf+1] + lbheatforce[tpos*3*lbsy.nf+1] + postequil*(lbbdforce[1]+lboscilforce[1]*freq))
                 +  0.5*(1.0-phi)*(lbinterforce[tpos*3*lbsy.nf+4] + lbheatforce[tpos*3*lbsy.nf+4] + postequil*(lbbdforce[4]+lboscilforce[4]*freq));
        force[1] = -0.5*(1.0+phi)*(lbinterforce[tpos*3*lbsy.nf+2] + lbheatforce[tpos*3*lbsy.nf+2] + postequil*(lbbdforce[2]+lboscilforce[2]*freq))
                 -  0.5*(1.0-phi)*(lbinterforce[tpos*3*lbsy.nf+5] + lbheatforce[tpos*3*lbsy.nf+5] + postequil*(lbbdforce[5]+lboscilforce[5]*freq));
        force[3] =  0.0;
        force[4] =  0.0;
        force[5] =  0.0;
      }
      else {
        if(interact>9 && interact<20) {
          fD3CECCFracSite(frac, tpos1);
          for(int i=0; i<lbsy.nf; i++) {
            force[3*i  ] =  frac[i] * lbinterforce[tpos*3  ] + lbheatforce[tpos*3*lbsy.nf+3*i  ] + postequil * (lbbdforce[3*i  ]+lboscilforce[3*i  ]*freq);
            force[3*i+2] =  frac[i] * lbinterforce[tpos*3+1] + lbheatforce[tpos*3*lbsy.nf+3*i+1] + postequil * (lbbdforce[3*i+1]+lboscilforce[3*i+1]*freq);
            force[3*i+1] = -frac[i] * lbinterforce[tpos*3+2] - lbheatforce[tpos*3*lbsy.nf+3*i+2] - postequil * (lbbdforce[3*i+2]+lboscilforce[3*i+2]*freq);
          }
        }
        else {
          for(int i=0; i<lbsy.nf; i++) {
            force[3*i  ] =  lbinterforce[tpos*3*lbsy.nf+3*i  ] + lbheatforce[tpos*3*lbsy.nf+3*i  ] + postequil * (lbbdforce[3*i  ]+lboscilforce[3*i  ]*freq);
            force[3*i+2] =  lbinterforce[tpos*3*lbsy.nf+3*i+1] + lbheatforce[tpos*3*lbsy.nf+3*i+1] + postequil * (lbbdforce[3*i+1]+lboscilforce[3*i+1]*freq);
            force[3*i+1] = -lbinterforce[tpos*3*lbsy.nf+3*i+2] - lbheatforce[tpos*3*lbsy.nf+3*i+2] - postequil * (lbbdforce[3*i+2]+lboscilforce[3*i+2]*freq);
          }
        }
      }
      break;
  }
  return 0;
}
                
int fD3Q15BoundaryForceDensity(double *force, long tpos, double *p0, int prop)
{
  // calculate forces required at constant density boundary point for D3Q15 lattice

  double phi, freq = (lbbdforcetyp==1)*sin(lboscilfreq*(lbcurstep-lbequstep));

  switch (prop) {
    case PST:
    case CCTRF:
    case CETR:
      if(interact>9 && interact<20) {
        phi = 0.0;
        for(int i=0; i<lbsy.nf; i++)
          phi += p0[i];
        phi = fReciprocal(phi);
        for(int i=0; i<lbsy.nf; i++) {
          force[3*i  ] = p0[i] * phi * lbinterforce[tpos*3  ] + lbheatforce[tpos*3*lbsy.nf+3*i  ] + postequil * (lbbdforce[3*i  ]+lboscilforce[3*i  ]*freq);
          force[3*i+1] = p0[i] * phi * lbinterforce[tpos*3+1] + lbheatforce[tpos*3*lbsy.nf+3*i+1] + postequil * (lbbdforce[3*i+1]+lboscilforce[3*i+1]*freq);
          force[3*i+2] = p0[i] * phi * lbinterforce[tpos*3+2] + lbheatforce[tpos*3*lbsy.nf+3*i+2] + postequil * (lbbdforce[3*i+2]+lboscilforce[3*i+2]*freq);
        }
      }
      else {
        for(int i=0; i<lbsy.nf; i++) {
          force[3*i  ] = lbinterforce[tpos*3*lbsy.nf+3*i  ] + lbheatforce[tpos*3*lbsy.nf+3*i  ] + postequil * (lbbdforce[3*i  ]+lboscilforce[3*i  ]*freq);
          force[3*i+1] = lbinterforce[tpos*3*lbsy.nf+3*i+1] + lbheatforce[tpos*3*lbsy.nf+3*i+1] + postequil * (lbbdforce[3*i+1]+lboscilforce[3*i+1]*freq);
          force[3*i+2] = lbinterforce[tpos*3*lbsy.nf+3*i+2] + lbheatforce[tpos*3*lbsy.nf+3*i+2] + postequil * (lbbdforce[3*i+2]+lboscilforce[3*i+2]*freq);
        }
      }
      break;
    case PSD:
      if(interact>9 && interact<20) {
        phi = 0.0;
        for(int i=0; i<lbsy.nf; i++)
          phi += p0[i];
        phi = fReciprocal(phi);
        for(int i=0; i<lbsy.nf; i++) {
          force[3*i  ] = -p0[i] * phi * lbinterforce[tpos*3  ] - lbheatforce[tpos*3*lbsy.nf+3*i  ] - postequil * (lbbdforce[3*i  ]+lboscilforce[3*i  ]*freq);
          force[3*i+1] = -p0[i] * phi * lbinterforce[tpos*3+1] - lbheatforce[tpos*3*lbsy.nf+3*i+1] - postequil * (lbbdforce[3*i+1]+lboscilforce[3*i+1]*freq);
          force[3*i+2] = -p0[i] * phi * lbinterforce[tpos*3+2] - lbheatforce[tpos*3*lbsy.nf+3*i+2] - postequil * (lbbdforce[3*i+2]+lboscilforce[3*i+2]*freq);
        }
      }
      else {
        for(int i=0; i<lbsy.nf; i++) {
          force[3*i  ] = -lbinterforce[tpos*3*lbsy.nf+3*i  ] - lbheatforce[tpos*3*lbsy.nf+3*i  ] - postequil * (lbbdforce[3*i  ]+lboscilforce[3*i  ]*freq);
          force[3*i+1] = -lbinterforce[tpos*3*lbsy.nf+3*i+1] - lbheatforce[tpos*3*lbsy.nf+3*i+1] - postequil * (lbbdforce[3*i+1]+lboscilforce[3*i+1]*freq);
          force[3*i+2] = -lbinterforce[tpos*3*lbsy.nf+3*i+2] - lbheatforce[tpos*3*lbsy.nf+3*i+2] - postequil * (lbbdforce[3*i+2]+lboscilforce[3*i+2]*freq);
        }
      }
      break;
    case PSL:
      if(interact>9 && interact<20) {
        phi = 0.0;
        for(int i=0; i<lbsy.nf; i++)
          phi += p0[i];
        phi = fReciprocal(phi);
        for(int i=0; i<lbsy.nf; i++) {
          force[3*i+1] = -p0[i] * phi * lbinterforce[tpos*3  ] - lbheatforce[tpos*3*lbsy.nf+3*i  ] - postequil * (lbbdforce[3*i  ]+lboscilforce[3*i  ]*freq);
          force[3*i+2] = -p0[i] * phi * lbinterforce[tpos*3+1] - lbheatforce[tpos*3*lbsy.nf+3*i+1] - postequil * (lbbdforce[3*i+1]+lboscilforce[3*i+1]*freq);
          force[3*i  ] = -p0[i] * phi * lbinterforce[tpos*3+2] - lbheatforce[tpos*3*lbsy.nf+3*i+2] - postequil * (lbbdforce[3*i+2]+lboscilforce[3*i+2]*freq);
        }
      }
      else {
        for(int i=0; i<lbsy.nf; i++) {
          force[3*i+1] = -lbinterforce[tpos*3*lbsy.nf+3*i  ] - lbheatforce[tpos*3*lbsy.nf+3*i  ] - postequil * (lbbdforce[3*i  ]+lboscilforce[3*i  ]*freq);
          force[3*i+2] = -lbinterforce[tpos*3*lbsy.nf+3*i+1] - lbheatforce[tpos*3*lbsy.nf+3*i+1] - postequil * (lbbdforce[3*i+1]+lboscilforce[3*i+1]*freq);
          force[3*i  ] = -lbinterforce[tpos*3*lbsy.nf+3*i+2] - lbheatforce[tpos*3*lbsy.nf+3*i+2] - postequil * (lbbdforce[3*i+2]+lboscilforce[3*i+2]*freq);
        }
      }
      break;
    case PSR:
      if(interact>9 && interact<20) {
        phi = 0.0;
        for(int i=0; i<lbsy.nf; i++)
          phi += p0[i];
        phi = fReciprocal(phi);
        for(int i=0; i<lbsy.nf; i++) {
          force[3*i+1] = p0[i] * phi * lbinterforce[tpos*3  ] + lbheatforce[tpos*3*lbsy.nf+3*i  ] + postequil * (lbbdforce[3*i  ]+lboscilforce[3*i  ]*freq);
          force[3*i+2] = p0[i] * phi * lbinterforce[tpos*3+1] + lbheatforce[tpos*3*lbsy.nf+3*i+1] + postequil * (lbbdforce[3*i+1]+lboscilforce[3*i+1]*freq);
          force[3*i  ] = p0[i] * phi * lbinterforce[tpos*3+2] + lbheatforce[tpos*3*lbsy.nf+3*i+2] + postequil * (lbbdforce[3*i+2]+lboscilforce[3*i+2]*freq);
        }
      }
      else {
        for(int i=0; i<lbsy.nf; i++) {
          force[3*i+1] = lbinterforce[tpos*3*lbsy.nf+3*i  ] + lbheatforce[tpos*3*lbsy.nf+3*i  ] + postequil * (lbbdforce[3*i  ]+lboscilforce[3*i  ]*freq);
          force[3*i+2] = lbinterforce[tpos*3*lbsy.nf+3*i+1] + lbheatforce[tpos*3*lbsy.nf+3*i+1] + postequil * (lbbdforce[3*i+1]+lboscilforce[3*i+1]*freq);
          force[3*i  ] = lbinterforce[tpos*3*lbsy.nf+3*i+2] + lbheatforce[tpos*3*lbsy.nf+3*i+2] + postequil * (lbbdforce[3*i+2]+lboscilforce[3*i+2]*freq);
        }
      }
      break;
    case PSF:
      if(interact>9 && interact<20) {
        phi = 0.0;
        for(int i=0; i<lbsy.nf; i++)
          phi += p0[i];
        phi = fReciprocal(phi);
        for(int i=0; i<lbsy.nf; i++) {
          force[3*i+2] = -p0[i] * phi * lbinterforce[tpos*3  ] - lbheatforce[tpos*3*lbsy.nf+3*i  ] - postequil * (lbbdforce[3*i  ]+lboscilforce[3*i  ]*freq);
          force[3*i  ] = -p0[i] * phi * lbinterforce[tpos*3+1] - lbheatforce[tpos*3*lbsy.nf+3*i+1] - postequil * (lbbdforce[3*i+1]+lboscilforce[3*i+1]*freq);
          force[3*i+1] = -p0[i] * phi * lbinterforce[tpos*3+2] - lbheatforce[tpos*3*lbsy.nf+3*i+2] - postequil * (lbbdforce[3*i+2]+lboscilforce[3*i+2]*freq);
        }
      }
      else {
        for(int i=0; i<lbsy.nf; i++) {
          force[3*i+2] = -lbinterforce[tpos*3*lbsy.nf+3*i  ] - lbheatforce[tpos*3*lbsy.nf+3*i  ] - postequil * (lbbdforce[3*i  ]+lboscilforce[3*i  ]*freq);
          force[3*i  ] = -lbinterforce[tpos*3*lbsy.nf+3*i+1] - lbheatforce[tpos*3*lbsy.nf+3*i+1] - postequil * (lbbdforce[3*i+1]+lboscilforce[3*i+1]*freq);
          force[3*i+1] = -lbinterforce[tpos*3*lbsy.nf+3*i+2] - lbheatforce[tpos*3*lbsy.nf+3*i+2] - postequil * (lbbdforce[3*i+2]+lboscilforce[3*i+2]*freq);
        }
      }
      break;
    case PSB:
      if(interact>9 && interact<20) {
        phi = 0.0;
        for(int i=0; i<lbsy.nf; i++)
          phi += p0[i];
        phi = fReciprocal(phi);
        for(int i=0; i<lbsy.nf; i++) {
          force[3*i+2] = p0[i] * phi * lbinterforce[tpos*3  ] + lbheatforce[tpos*3*lbsy.nf+3*i  ] + postequil * (lbbdforce[3*i  ]+lboscilforce[3*i  ]*freq);
          force[3*i  ] = p0[i] * phi * lbinterforce[tpos*3+1] + lbheatforce[tpos*3*lbsy.nf+3*i+1] + postequil * (lbbdforce[3*i+1]+lboscilforce[3*i+1]*freq);
          force[3*i+1] = p0[i] * phi * lbinterforce[tpos*3+2] + lbheatforce[tpos*3*lbsy.nf+3*i+2] + postequil * (lbbdforce[3*i+2]+lboscilforce[3*i+2]*freq);
        }
      }
      else {
        for(int i=0; i<lbsy.nf; i++) {
          force[3*i+2] = lbinterforce[tpos*3*lbsy.nf+3*i  ] + lbheatforce[tpos*3*lbsy.nf+3*i  ] + postequil * (lbbdforce[3*i  ]+lboscilforce[3*i  ]*freq);
          force[3*i  ] = lbinterforce[tpos*3*lbsy.nf+3*i+1] + lbheatforce[tpos*3*lbsy.nf+3*i+1] + postequil * (lbbdforce[3*i+1]+lboscilforce[3*i+1]*freq);
          force[3*i+1] = lbinterforce[tpos*3*lbsy.nf+3*i+2] + lbheatforce[tpos*3*lbsy.nf+3*i+2] + postequil * (lbbdforce[3*i+2]+lboscilforce[3*i+2]*freq);
        }
      }
      break;
    case CCTRB:
      if(interact>9 && interact<20) {
        phi = 0.0;
        for(int i=0; i<lbsy.nf; i++)
          phi += p0[i];
        phi = fReciprocal(phi);
        for(int i=0; i<lbsy.nf; i++) {
          force[3*i  ] =  p0[i] * phi * lbinterforce[tpos*3  ] + lbheatforce[tpos*3*lbsy.nf+3*i  ] + postequil * (lbbdforce[3*i  ]+lboscilforce[3*i  ]*freq);
          force[3*i+1] =  p0[i] * phi * lbinterforce[tpos*3+1] + lbheatforce[tpos*3*lbsy.nf+3*i+1] + postequil * (lbbdforce[3*i+1]+lboscilforce[3*i+1]*freq);
          force[3*i+2] = -p0[i] * phi * lbinterforce[tpos*3+2] - lbheatforce[tpos*3*lbsy.nf+3*i+2] - postequil * (lbbdforce[3*i+2]+lboscilforce[3*i+2]*freq);
        }
      }
      else {
        for(int i=0; i<lbsy.nf; i++) {
          force[3*i  ] =  lbinterforce[tpos*3*lbsy.nf+3*i  ] + lbheatforce[tpos*3*lbsy.nf+3*i  ] + postequil * (lbbdforce[3*i  ]+lboscilforce[3*i  ]*freq);
          force[3*i+1] =  lbinterforce[tpos*3*lbsy.nf+3*i+1] + lbheatforce[tpos*3*lbsy.nf+3*i+1] + postequil * (lbbdforce[3*i+1]+lboscilforce[3*i+1]*freq);
          force[3*i+2] = -lbinterforce[tpos*3*lbsy.nf+3*i+2] - lbheatforce[tpos*3*lbsy.nf+3*i+2] - postequil * (lbbdforce[3*i+2]+lboscilforce[3*i+2]*freq);
        }
      }
      break;
    case CCTLB:
      if(interact>9 && interact<20) {
        phi = 0.0;
        for(int i=0; i<lbsy.nf; i++)
          phi += p0[i];
        phi = fReciprocal(phi);
        for(int i=0; i<lbsy.nf; i++) {
          force[3*i  ] = -p0[i] * phi * lbinterforce[tpos*3  ] - lbheatforce[tpos*3*lbsy.nf+3*i  ] - postequil * (lbbdforce[3*i  ]+lboscilforce[3*i  ]*freq);
          force[3*i+1] =  p0[i] * phi * lbinterforce[tpos*3+1] + lbheatforce[tpos*3*lbsy.nf+3*i+1] + postequil * (lbbdforce[3*i+1]+lboscilforce[3*i+1]*freq);
          force[3*i+2] = -p0[i] * phi * lbinterforce[tpos*3+2] - lbheatforce[tpos*3*lbsy.nf+3*i+2] - postequil * (lbbdforce[3*i+2]+lboscilforce[3*i+2]*freq);
        }
      }
      else {
        for(int i=0; i<lbsy.nf; i++) {
          force[3*i  ] = -lbinterforce[tpos*3*lbsy.nf+3*i  ] - lbheatforce[tpos*3*lbsy.nf+3*i  ] - postequil * (lbbdforce[3*i  ]+lboscilforce[3*i  ]*freq);
          force[3*i+1] =  lbinterforce[tpos*3*lbsy.nf+3*i+1] + lbheatforce[tpos*3*lbsy.nf+3*i+1] + postequil * (lbbdforce[3*i+1]+lboscilforce[3*i+1]*freq);
          force[3*i+2] = -lbinterforce[tpos*3*lbsy.nf+3*i+2] - lbheatforce[tpos*3*lbsy.nf+3*i+2] - postequil * (lbbdforce[3*i+2]+lboscilforce[3*i+2]*freq);
        }
      }
      break;
    case CCDRB:
      if(interact>9 && interact<20) {
        phi = 0.0;
        for(int i=0; i<lbsy.nf; i++)
          phi += p0[i];
        phi = fReciprocal(phi);
        for(int i=0; i<lbsy.nf; i++) {
          force[3*i  ] =  p0[i] * phi * lbinterforce[tpos*3  ] + lbheatforce[tpos*3*lbsy.nf+3*i  ] + postequil * (lbbdforce[3*i  ]+lboscilforce[3*i  ]*freq);
          force[3*i+1] = -p0[i] * phi * lbinterforce[tpos*3+1] - lbheatforce[tpos*3*lbsy.nf+3*i+1] - postequil * (lbbdforce[3*i+1]+lboscilforce[3*i+1]*freq);
          force[3*i+2] = -p0[i] * phi * lbinterforce[tpos*3+2] - lbheatforce[tpos*3*lbsy.nf+3*i+2] - postequil * (lbbdforce[3*i+2]+lboscilforce[3*i+2]*freq);
        }
      }
      else {
        for(int i=0; i<lbsy.nf; i++) {
          force[3*i  ] =  lbinterforce[tpos*3*lbsy.nf+3*i  ] + lbheatforce[tpos*3*lbsy.nf+3*i  ] + postequil * (lbbdforce[3*i  ]+lboscilforce[3*i  ]*freq);
          force[3*i+1] = -lbinterforce[tpos*3*lbsy.nf+3*i+1] - lbheatforce[tpos*3*lbsy.nf+3*i+1] - postequil * (lbbdforce[3*i+1]+lboscilforce[3*i+1]*freq);
          force[3*i+2] = -lbinterforce[tpos*3*lbsy.nf+3*i+2] - lbheatforce[tpos*3*lbsy.nf+3*i+2] - postequil * (lbbdforce[3*i+2]+lboscilforce[3*i+2]*freq);
        }
      }
      break;
    case CCTLF:
      if(interact>9 && interact<20) {
        phi = 0.0;
        for(int i=0; i<lbsy.nf; i++)
          phi += p0[i];
        phi = fReciprocal(phi);
        for(int i=0; i<lbsy.nf; i++) {
          force[3*i  ] = -p0[i] * phi * lbinterforce[tpos*3  ] - lbheatforce[tpos*3*lbsy.nf+3*i  ] - postequil * (lbbdforce[3*i  ]+lboscilforce[3*i  ]*freq);
          force[3*i+1] =  p0[i] * phi * lbinterforce[tpos*3+1] + lbheatforce[tpos*3*lbsy.nf+3*i+1] + postequil * (lbbdforce[3*i+1]+lboscilforce[3*i+1]*freq);
          force[3*i+2] =  p0[i] * phi * lbinterforce[tpos*3+2] + lbheatforce[tpos*3*lbsy.nf+3*i+2] + postequil * (lbbdforce[3*i+2]+lboscilforce[3*i+2]*freq);
        }
      }
      else {
        for(int i=0; i<lbsy.nf; i++) {
          force[3*i  ] = -lbinterforce[tpos*3*lbsy.nf+3*i  ] - lbheatforce[tpos*3*lbsy.nf+3*i  ] - postequil * (lbbdforce[3*i  ]+lboscilforce[3*i  ]*freq);
          force[3*i+1] =  lbinterforce[tpos*3*lbsy.nf+3*i+1] + lbheatforce[tpos*3*lbsy.nf+3*i+1] + postequil * (lbbdforce[3*i+1]+lboscilforce[3*i+1]*freq);
          force[3*i+2] =  lbinterforce[tpos*3*lbsy.nf+3*i+2] + lbheatforce[tpos*3*lbsy.nf+3*i+2] + postequil * (lbbdforce[3*i+2]+lboscilforce[3*i+2]*freq);
        }
      }
      break;
    case CCDLF:
    case CEDL:
      if(interact>9 && interact<20) {
        phi = 0.0;
        for(int i=0; i<lbsy.nf; i++)
          phi += p0[i];
        phi = fReciprocal(phi);
        for(int i=0; i<lbsy.nf; i++) {
          force[3*i  ] = -p0[i] * phi * lbinterforce[tpos*3  ] - lbheatforce[tpos*3*lbsy.nf+3*i  ] - postequil * (lbbdforce[3*i  ]+lboscilforce[3*i  ]*freq);
          force[3*i+1] = -p0[i] * phi * lbinterforce[tpos*3+1] - lbheatforce[tpos*3*lbsy.nf+3*i+1] - postequil * (lbbdforce[3*i+1]+lboscilforce[3*i+1]*freq);
          force[3*i+2] =  p0[i] * phi * lbinterforce[tpos*3+2] + lbheatforce[tpos*3*lbsy.nf+3*i+2] + postequil * (lbbdforce[3*i+2]+lboscilforce[3*i+2]*freq);
        }
      }
      else {
        for(int i=0; i<lbsy.nf; i++) {
          force[3*i  ] = -lbinterforce[tpos*3*lbsy.nf+3*i  ] - lbheatforce[tpos*3*lbsy.nf+3*i  ] - postequil * (lbbdforce[3*i  ]+lboscilforce[3*i  ]*freq);
          force[3*i+1] = -lbinterforce[tpos*3*lbsy.nf+3*i+1] - lbheatforce[tpos*3*lbsy.nf+3*i+1] - postequil * (lbbdforce[3*i+1]+lboscilforce[3*i+1]*freq);
          force[3*i+2] =  lbinterforce[tpos*3*lbsy.nf+3*i+2] + lbheatforce[tpos*3*lbsy.nf+3*i+2] + postequil * (lbbdforce[3*i+2]+lboscilforce[3*i+2]*freq);
        }
      }
      break;
    case CCDRF:
      if(interact>9 && interact<20) {
        phi = 0.0;
        for(int i=0; i<lbsy.nf; i++)
          phi += p0[i];
        phi = fReciprocal(phi);
        for(int i=0; i<lbsy.nf; i++) {
          force[3*i  ] =  p0[i] * phi * lbinterforce[tpos*3  ] + lbheatforce[tpos*3*lbsy.nf+3*i  ] + postequil * (lbbdforce[3*i  ]+lboscilforce[3*i  ]*freq);
          force[3*i+1] = -p0[i] * phi * lbinterforce[tpos*3+1] - lbheatforce[tpos*3*lbsy.nf+3*i+1] - postequil * (lbbdforce[3*i+1]+lboscilforce[3*i+1]*freq);
          force[3*i+2] =  p0[i] * phi * lbinterforce[tpos*3+2] + lbheatforce[tpos*3*lbsy.nf+3*i+2] + postequil * (lbbdforce[3*i+2]+lboscilforce[3*i+2]*freq);
        }
      }
      else {
        for(int i=0; i<lbsy.nf; i++) {
          force[3*i  ] =  lbinterforce[tpos*3*lbsy.nf+3*i  ] + lbheatforce[tpos*3*lbsy.nf+3*i  ] + postequil * (lbbdforce[3*i  ]+lboscilforce[3*i  ]*freq);
          force[3*i+1] = -lbinterforce[tpos*3*lbsy.nf+3*i+1] - lbheatforce[tpos*3*lbsy.nf+3*i+1] - postequil * (lbbdforce[3*i+1]+lboscilforce[3*i+1]*freq);
          force[3*i+2] =  lbinterforce[tpos*3*lbsy.nf+3*i+2] + lbheatforce[tpos*3*lbsy.nf+3*i+2] + postequil * (lbbdforce[3*i+2]+lboscilforce[3*i+2]*freq);
        }
      }
      break;
    case CETL:
      if(interact>9 && interact<20) {
        phi = 0.0;
        for(int i=0; i<lbsy.nf; i++)
          phi += p0[i];
        phi = fReciprocal(phi);
        for(int i=0; i<lbsy.nf; i++) {
          force[3*i+1] = -p0[i] * phi * lbinterforce[tpos*3  ] - lbheatforce[tpos*3*lbsy.nf+3*i  ] - postequil * (lbbdforce[3*i  ]+lboscilforce[3*i  ]*freq);
          force[3*i  ] =  p0[i] * phi * lbinterforce[tpos*3+1] + lbheatforce[tpos*3*lbsy.nf+3*i+1] + postequil * (lbbdforce[3*i+1]+lboscilforce[3*i+1]*freq);
          force[3*i+2] =  p0[i] * phi * lbinterforce[tpos*3+2] + lbheatforce[tpos*3*lbsy.nf+3*i+2] + postequil * (lbbdforce[3*i+2]+lboscilforce[3*i+2]*freq);
        }
      }
      else {
        for(int i=0; i<lbsy.nf; i++) {
          force[3*i+1] = -lbinterforce[tpos*3*lbsy.nf+3*i  ] - lbheatforce[tpos*3*lbsy.nf+3*i  ] - postequil * (lbbdforce[3*i  ]+lboscilforce[3*i  ]*freq);
          force[3*i  ] =  lbinterforce[tpos*3*lbsy.nf+3*i+1] + lbheatforce[tpos*3*lbsy.nf+3*i+1] + postequil * (lbbdforce[3*i+1]+lboscilforce[3*i+1]*freq);
          force[3*i+2] =  lbinterforce[tpos*3*lbsy.nf+3*i+2] + lbheatforce[tpos*3*lbsy.nf+3*i+2] + postequil * (lbbdforce[3*i+2]+lboscilforce[3*i+2]*freq);
        }
      }
      break;
    case CEDR:
      if(interact>9 && interact<20) {
        phi = 0.0;
        for(int i=0; i<lbsy.nf; i++)
          phi += p0[i];
        phi = fReciprocal(phi);
        for(int i=0; i<lbsy.nf; i++) {
          force[3*i+1] =  p0[i] * phi * lbinterforce[tpos*3  ] + lbheatforce[tpos*3*lbsy.nf+3*i  ] + postequil * (lbbdforce[3*i  ]+lboscilforce[3*i  ]*freq);
          force[3*i  ] = -p0[i] * phi * lbinterforce[tpos*3+1] - lbheatforce[tpos*3*lbsy.nf+3*i+1] - postequil * (lbbdforce[3*i+1]+lboscilforce[3*i+1]*freq);
          force[3*i+2] =  p0[i] * phi * lbinterforce[tpos*3+2] + lbheatforce[tpos*3*lbsy.nf+3*i+2] + postequil * (lbbdforce[3*i+2]+lboscilforce[3*i+2]*freq);
        }
      }
      else {
        for(int i=0; i<lbsy.nf; i++) {
          force[3*i+1] =  lbinterforce[tpos*3*lbsy.nf+3*i  ] + lbheatforce[tpos*3*lbsy.nf+3*i  ] + postequil * (lbbdforce[3*i  ]+lboscilforce[3*i  ]*freq);
          force[3*i  ] = -lbinterforce[tpos*3*lbsy.nf+3*i+1] - lbheatforce[tpos*3*lbsy.nf+3*i+1] - postequil * (lbbdforce[3*i+1]+lboscilforce[3*i+1]*freq);
          force[3*i+2] =  lbinterforce[tpos*3*lbsy.nf+3*i+2] + lbheatforce[tpos*3*lbsy.nf+3*i+2] + postequil * (lbbdforce[3*i+2]+lboscilforce[3*i+2]*freq);
        }
      }
      break;
    case CETF:
      if(interact>9 && interact<20) {
        phi = 0.0;
        for(int i=0; i<lbsy.nf; i++)
          phi += p0[i];
        phi = fReciprocal(phi);
        for(int i=0; i<lbsy.nf; i++) {
          force[3*i+2] = p0[i] * phi * lbinterforce[tpos*3  ] + lbheatforce[tpos*3*lbsy.nf+3*i  ] + postequil * (lbbdforce[3*i  ]+lboscilforce[3*i  ]*freq);
          force[3*i  ] = p0[i] * phi * lbinterforce[tpos*3+1] + lbheatforce[tpos*3*lbsy.nf+3*i+1] + postequil * (lbbdforce[3*i+1]+lboscilforce[3*i+1]*freq);
          force[3*i+1] = p0[i] * phi * lbinterforce[tpos*3+2] + lbheatforce[tpos*3*lbsy.nf+3*i+2] + postequil * (lbbdforce[3*i+2]+lboscilforce[3*i+2]*freq);
        }
      }
      else {
        for(int i=0; i<lbsy.nf; i++) {
          force[3*i+2] = lbinterforce[tpos*3*lbsy.nf+3*i  ] + lbheatforce[tpos*3*lbsy.nf+3*i  ] + postequil * (lbbdforce[3*i  ]+lboscilforce[3*i  ]*freq);
          force[3*i  ] = lbinterforce[tpos*3*lbsy.nf+3*i+1] + lbheatforce[tpos*3*lbsy.nf+3*i+1] + postequil * (lbbdforce[3*i+1]+lboscilforce[3*i+1]*freq);
          force[3*i+1] = lbinterforce[tpos*3*lbsy.nf+3*i+2] + lbheatforce[tpos*3*lbsy.nf+3*i+2] + postequil * (lbbdforce[3*i+2]+lboscilforce[3*i+2]*freq);
        }
      }
      break;
    case CELF:
      if(interact>9 && interact<20) {
        phi = 0.0;
        for(int i=0; i<lbsy.nf; i++)
          phi += p0[i];
        phi = fReciprocal(phi);
        for(int i=0; i<lbsy.nf; i++) {
          force[3*i  ] = -p0[i] * phi * lbinterforce[tpos*3  ] - lbheatforce[tpos*3*lbsy.nf+3*i  ] - postequil * (lbbdforce[3*i  ]+lboscilforce[3*i  ]*freq);
          force[3*i+2] =  p0[i] * phi * lbinterforce[tpos*3+1] + lbheatforce[tpos*3*lbsy.nf+3*i+1] + postequil * (lbbdforce[3*i+1]+lboscilforce[3*i+1]*freq);
          force[3*i+1] =  p0[i] * phi * lbinterforce[tpos*3+2] + lbheatforce[tpos*3*lbsy.nf+3*i+2] + postequil * (lbbdforce[3*i+2]+lboscilforce[3*i+2]*freq);
        }
      }
      else {
        for(int i=0; i<lbsy.nf; i++) {
          force[3*i  ] = -lbinterforce[tpos*3*lbsy.nf+3*i  ] - lbheatforce[tpos*3*lbsy.nf+3*i  ] - postequil * (lbbdforce[3*i  ]+lboscilforce[3*i  ]*freq);
          force[3*i+2] =  lbinterforce[tpos*3*lbsy.nf+3*i+1] + lbheatforce[tpos*3*lbsy.nf+3*i+1] + postequil * (lbbdforce[3*i+1]+lboscilforce[3*i+1]*freq);
          force[3*i+1] =  lbinterforce[tpos*3*lbsy.nf+3*i+2] + lbheatforce[tpos*3*lbsy.nf+3*i+2] + postequil * (lbbdforce[3*i+2]+lboscilforce[3*i+2]*freq);
        }
      }
      break;
    case CEDF:
      if(interact>9 && interact<20) {
        phi = 0.0;
        for(int i=0; i<lbsy.nf; i++)
          phi += p0[i];
        phi = fReciprocal(phi);
        for(int i=0; i<lbsy.nf; i++) {
          force[3*i+2] =  p0[i] * phi * lbinterforce[tpos*3  ] + lbheatforce[tpos*3*lbsy.nf+3*i  ] + postequil * (lbbdforce[3*i  ]+lboscilforce[3*i  ]*freq);
          force[3*i  ] = -p0[i] * phi * lbinterforce[tpos*3+1] - lbheatforce[tpos*3*lbsy.nf+3*i+1] - postequil * (lbbdforce[3*i+1]+lboscilforce[3*i+1]*freq);
          force[3*i+1] =  p0[i] * phi * lbinterforce[tpos*3+2] + lbheatforce[tpos*3*lbsy.nf+3*i+2] + postequil * (lbbdforce[3*i+2]+lboscilforce[3*i+2]*freq);
        }
      }
      else {
        for(int i=0; i<lbsy.nf; i++) {
          force[3*i+2] =  lbinterforce[tpos*3*lbsy.nf+3*i  ] + lbheatforce[tpos*3*lbsy.nf+3*i  ] + postequil * (lbbdforce[3*i  ]+lboscilforce[3*i  ]*freq);
          force[3*i  ] = -lbinterforce[tpos*3*lbsy.nf+3*i+1] - lbheatforce[tpos*3*lbsy.nf+3*i+1] - postequil * (lbbdforce[3*i+1]+lboscilforce[3*i+1]*freq);
          force[3*i+1] =  lbinterforce[tpos*3*lbsy.nf+3*i+2] + lbheatforce[tpos*3*lbsy.nf+3*i+2] + postequil * (lbbdforce[3*i+2]+lboscilforce[3*i+2]*freq);
        }
      }
      break;
    case CERF:
      if(interact>9 && interact<20) {
        phi = 0.0;
        for(int i=0; i<lbsy.nf; i++)
          phi += p0[i];
        phi = fReciprocal(phi);
        for(int i=0; i<lbsy.nf; i++) {
          force[3*i  ] = p0[i] * phi * lbinterforce[tpos*3  ] + lbheatforce[tpos*3*lbsy.nf+3*i  ] + postequil * (lbbdforce[3*i  ]+lboscilforce[3*i  ]*freq);
          force[3*i+2] = p0[i] * phi * lbinterforce[tpos*3+1] + lbheatforce[tpos*3*lbsy.nf+3*i+1] + postequil * (lbbdforce[3*i+1]+lboscilforce[3*i+1]*freq);
          force[3*i+1] = p0[i] * phi * lbinterforce[tpos*3+2] + lbheatforce[tpos*3*lbsy.nf+3*i+2] + postequil * (lbbdforce[3*i+2]+lboscilforce[3*i+2]*freq);
        }
      }
      else {
        for(int i=0; i<lbsy.nf; i++) {
          force[3*i  ] = lbinterforce[tpos*3*lbsy.nf+3*i  ] + lbheatforce[tpos*3*lbsy.nf+3*i  ] + postequil * (lbbdforce[3*i  ]+lboscilforce[3*i  ]*freq);
          force[3*i+2] = lbinterforce[tpos*3*lbsy.nf+3*i+1] + lbheatforce[tpos*3*lbsy.nf+3*i+1] + postequil * (lbbdforce[3*i+1]+lboscilforce[3*i+1]*freq);
          force[3*i+1] = lbinterforce[tpos*3*lbsy.nf+3*i+2] + lbheatforce[tpos*3*lbsy.nf+3*i+2] + postequil * (lbbdforce[3*i+2]+lboscilforce[3*i+2]*freq);
        }
      }
      break;
    case CETB:
      if(interact>9 && interact<20) {
        phi = 0.0;
        for(int i=0; i<lbsy.nf; i++)
          phi += p0[i];
        phi = fReciprocal(phi);
        for(int i=0; i<lbsy.nf; i++) {
          force[3*i+2] =  p0[i] * phi * lbinterforce[tpos*3  ] + lbheatforce[tpos*3*lbsy.nf+3*i  ] + postequil * (lbbdforce[3*i  ]+lboscilforce[3*i  ]*freq);
          force[3*i  ] =  p0[i] * phi * lbinterforce[tpos*3+1] + lbheatforce[tpos*3*lbsy.nf+3*i+1] + postequil * (lbbdforce[3*i+1]+lboscilforce[3*i+1]*freq);
          force[3*i+1] = -p0[i] * phi * lbinterforce[tpos*3+2] - lbheatforce[tpos*3*lbsy.nf+3*i+2] - postequil * (lbbdforce[3*i+2]+lboscilforce[3*i+2]*freq);
        }
      }
      else {
        for(int i=0; i<lbsy.nf; i++) {
          force[3*i+2] =  lbinterforce[tpos*3*lbsy.nf+3*i  ] + lbheatforce[tpos*3*lbsy.nf+3*i  ] + postequil * (lbbdforce[3*i  ]+lboscilforce[3*i  ]*freq);
          force[3*i  ] =  lbinterforce[tpos*3*lbsy.nf+3*i+1] + lbheatforce[tpos*3*lbsy.nf+3*i+1] + postequil * (lbbdforce[3*i+1]+lboscilforce[3*i+1]*freq);
          force[3*i+1] = -lbinterforce[tpos*3*lbsy.nf+3*i+2] - lbheatforce[tpos*3*lbsy.nf+3*i+2] - postequil * (lbbdforce[3*i+2]+lboscilforce[3*i+2]*freq);
        }
      }
      break;
    case CELB:
      if(interact>9 && interact<20) {
        phi = 0.0;
        for(int i=0; i<lbsy.nf; i++)
          phi += p0[i];
        phi = fReciprocal(phi);
        for(int i=0; i<lbsy.nf; i++) {
          force[3*i  ] = -p0[i] * phi * lbinterforce[tpos*3  ] - lbheatforce[tpos*3*lbsy.nf+3*i  ] - postequil * (lbbdforce[3*i  ]+lboscilforce[3*i  ]*freq);
          force[3*i+2] =  p0[i] * phi * lbinterforce[tpos*3+1] + lbheatforce[tpos*3*lbsy.nf+3*i+1] + postequil * (lbbdforce[3*i+1]+lboscilforce[3*i+1]*freq);
          force[3*i+1] = -p0[i] * phi * lbinterforce[tpos*3+2] - lbheatforce[tpos*3*lbsy.nf+3*i+2] - postequil * (lbbdforce[3*i+2]+lboscilforce[3*i+2]*freq);
        }
      }
      else {
        for(int i=0; i<lbsy.nf; i++) {
          force[3*i  ] = -lbinterforce[tpos*3*lbsy.nf+3*i  ] - lbheatforce[tpos*3*lbsy.nf+3*i  ] - postequil * (lbbdforce[3*i  ]+lboscilforce[3*i  ]*freq);
          force[3*i+2] =  lbinterforce[tpos*3*lbsy.nf+3*i+1] + lbheatforce[tpos*3*lbsy.nf+3*i+1] + postequil * (lbbdforce[3*i+1]+lboscilforce[3*i+1]*freq);
          force[3*i+1] = -lbinterforce[tpos*3*lbsy.nf+3*i+2] - lbheatforce[tpos*3*lbsy.nf+3*i+2] - postequil * (lbbdforce[3*i+2]+lboscilforce[3*i+2]*freq);
        }
      }
      break;
    case CEDB:
      if(interact>9 && interact<20) {
        phi = 0.0;
        for(int i=0; i<lbsy.nf; i++)
          phi += p0[i];
        phi = fReciprocal(phi);
        for(int i=0; i<lbsy.nf; i++) {
          force[3*i+2] =  p0[i] * phi * lbinterforce[tpos*3  ] + lbheatforce[tpos*3*lbsy.nf+3*i  ] + postequil * (lbbdforce[3*i  ]+lboscilforce[3*i  ]*freq);
          force[3*i  ] = -p0[i] * phi * lbinterforce[tpos*3+1] - lbheatforce[tpos*3*lbsy.nf+3*i+1] - postequil * (lbbdforce[3*i+1]+lboscilforce[3*i+1]*freq);
          force[3*i+1] = -p0[i] * phi * lbinterforce[tpos*3+2] - lbheatforce[tpos*3*lbsy.nf+3*i+2] - postequil * (lbbdforce[3*i+2]+lboscilforce[3*i+2]*freq);
        }
      }
      else {
        for(int i=0; i<lbsy.nf; i++) {
          force[3*i+2] =  lbinterforce[tpos*3*lbsy.nf+3*i  ] + lbheatforce[tpos*3*lbsy.nf+3*i  ] + postequil * (lbbdforce[3*i  ]+lboscilforce[3*i  ]*freq);
          force[3*i  ] = -lbinterforce[tpos*3*lbsy.nf+3*i+1] - lbheatforce[tpos*3*lbsy.nf+3*i+1] - postequil * (lbbdforce[3*i+1]+lboscilforce[3*i+1]*freq);
          force[3*i+1] = -lbinterforce[tpos*3*lbsy.nf+3*i+2] - lbheatforce[tpos*3*lbsy.nf+3*i+2] - postequil * (lbbdforce[3*i+2]+lboscilforce[3*i+2]*freq);
        }
      }
      break;
    case CERB:
      if(interact>9 && interact<20) {
        phi = 0.0;
        for(int i=0; i<lbsy.nf; i++)
          phi += p0[i];
        phi = fReciprocal(phi);
        for(int i=0; i<lbsy.nf; i++) {
          force[3*i  ] =  p0[i] * phi * lbinterforce[tpos*3  ] + lbheatforce[tpos*3*lbsy.nf+3*i  ] + postequil * (lbbdforce[3*i  ]+lboscilforce[3*i  ]*freq);
          force[3*i+2] =  p0[i] * phi * lbinterforce[tpos*3+1] + lbheatforce[tpos*3*lbsy.nf+3*i+1] + postequil * (lbbdforce[3*i+1]+lboscilforce[3*i+1]*freq);
          force[3*i+1] = -p0[i] * phi * lbinterforce[tpos*3+2] - lbheatforce[tpos*3*lbsy.nf+3*i+2] - postequil * (lbbdforce[3*i+2]+lboscilforce[3*i+2]*freq);
        }
      }
      else {
        for(int i=0; i<lbsy.nf; i++) {
          force[3*i  ] =  lbinterforce[tpos*3*lbsy.nf+3*i  ] + lbheatforce[tpos*3*lbsy.nf+3*i  ] + postequil * (lbbdforce[3*i  ]+lboscilforce[3*i  ]*freq);
          force[3*i+2] =  lbinterforce[tpos*3*lbsy.nf+3*i+1] + lbheatforce[tpos*3*lbsy.nf+3*i+1] + postequil * (lbbdforce[3*i+1]+lboscilforce[3*i+1]*freq);
          force[3*i+1] = -lbinterforce[tpos*3*lbsy.nf+3*i+2] - lbheatforce[tpos*3*lbsy.nf+3*i+2] - postequil * (lbbdforce[3*i+2]+lboscilforce[3*i+2]*freq);
        }
      }
      break;
  }
  return 0;
}


int fD3Q15OF1(long tpos, int prop)
{
  long tpos1;
  int qdim = lbsy.nf+lbsy.nc+lbsy.nt;
  int l1, l2, l3, l4, l5;

  tpos1 = tpos;
  l1 = 0; l2 = 0; l3 = 0; l4 = 0; l5 = 0;
  switch (prop) {
    case PST:
      tpos1 = fNextStep(0, 1, 0, tpos);
      l1 = 6; l2 = 7; l3 = 9; l4 = 11; l5 = 12;
      break;
    case PSD:
      tpos1 = fNextStep(0, -1, 0, tpos);
      l1 = 2; l2 = 4; l3 = 5; l4 = 13; l5 = 14;
      break;
    case PSL:
      tpos1 = fNextStep(-1, 0, 0, tpos);
      l1 = 1; l2 = 4; l3 = 5; l4 = 6; l5 = 7;
      break;
    case PSR:
      tpos1 = fNextStep(1, 0, 0, tpos);
      l1 = 8; l2 = 11; l3 = 12; l4 = 13; l5 = 14;
      break;
    case PSF:
      tpos1 = fNextStep(0, 0, 1, tpos);
      l1 = 5; l2 = 7; l3 = 10; l4 = 11; l5 = 13;
      break;
    case PSB:
      tpos1 = fNextStep(0, 0, -1, tpos);
      l1 = 3; l2 = 4; l3 = 6; l4 = 12; l5 = 14;
      break;
  }

  for(int i=0; i<qdim; i++) {
    lbf[tpos*lbsitelength+i+l1*qdim] = lbf[tpos1*lbsitelength+i+l1*qdim];
    lbf[tpos*lbsitelength+i+l2*qdim] = lbf[tpos1*lbsitelength+i+l2*qdim];
    lbf[tpos*lbsitelength+i+l3*qdim] = lbf[tpos1*lbsitelength+i+l3*qdim];
    lbf[tpos*lbsitelength+i+l4*qdim] = lbf[tpos1*lbsitelength+i+l4*qdim];
    lbf[tpos*lbsitelength+i+l5*qdim] = lbf[tpos1*lbsitelength+i+l5*qdim];
  }
  return 0;
}

int fD3Q15OF2(long tpos, int prop)
{
  long tpos1, tpos2;
  int qdim = lbsy.nf+lbsy.nc+lbsy.nt;
  int l1, l2, l3, l4, l5;
    
  tpos1 = tpos; tpos2 = tpos;
  l1 = 0; l2 = 0; l3 = 0; l4 = 0; l5 = 0;
  switch (prop) {
    case PST:
      tpos1 = fNextStep(0, 1, 0, tpos);
      tpos2 = fNextStep(0, 2, 0, tpos);
      l1 = 6; l2 = 7; l3 = 9; l4 = 11; l5 = 12;
      break;
    case PSD:
      tpos1 = fNextStep(0, -1, 0, tpos);
      tpos2 = fNextStep(0, -2, 0, tpos);
      l1 = 2; l2 = 4; l3 = 5; l4 = 13; l5 = 14;
      break;
    case PSL:
      tpos1 = fNextStep(-1, 0, 0, tpos);
      tpos2 = fNextStep(-2, 0, 0, tpos);
      l1 = 1; l2 = 4; l3 = 5; l4 = 6; l5 = 7;
      break;
    case PSR:
      tpos1 = fNextStep(1, 0, 0, tpos);
      tpos2 = fNextStep(2, 0, 0, tpos);
      l1 = 8; l2 = 11; l3 = 12; l4 = 13; l5 = 14;
      break;
    case PSF:
      tpos1 = fNextStep(0, 0, 1, tpos);
      tpos2 = fNextStep(0, 0, 2, tpos);
      l1 = 5; l2 = 7; l3 = 10; l4 = 11; l5 = 13;
      break;
    case PSB:
      tpos1 = fNextStep(0, 0, -1, tpos);
      tpos2 = fNextStep(0, 0, -2, tpos);
      l1 = 3; l2 = 4; l3 = 6; l4 = 12; l5 = 14;
      break;
  }

  for(int i=0; i<qdim; i++) {
    lbf[tpos*lbsitelength+i+l1*qdim] = 2.0*lbf[tpos1*lbsitelength+i+l1*qdim]-lbf[tpos2*lbsitelength+i+l1*qdim];
    lbf[tpos*lbsitelength+i+l2*qdim] = 2.0*lbf[tpos1*lbsitelength+i+l2*qdim]-lbf[tpos2*lbsitelength+i+l2*qdim];
    lbf[tpos*lbsitelength+i+l3*qdim] = 2.0*lbf[tpos1*lbsitelength+i+l3*qdim]-lbf[tpos2*lbsitelength+i+l3*qdim];
    lbf[tpos*lbsitelength+i+l4*qdim] = 2.0*lbf[tpos1*lbsitelength+i+l4*qdim]-lbf[tpos2*lbsitelength+i+l4*qdim];
    lbf[tpos*lbsitelength+i+l5*qdim] = 2.0*lbf[tpos1*lbsitelength+i+l5*qdim]-lbf[tpos2*lbsitelength+i+l5*qdim];
  }
  return 0;
}


// D3Q19

int fD3Q19PSFracSite(double *frac, double vy, double *f0, double *f1, double *f2, double *f3, double *f4, double *f5, double *f6, double *f7, double *f8, double *f9, double *f10, double *f11, double *f12, double *f13, double *f14, double *f15, double *f16, double *f17, double *f18)
{
  // calculate fluid densities at bottom boundary (PST) for fluids
    
  double invallmass,allmass = 0.0;
    
  for(int i=0; i<lbsy.nf; i++) {
    frac[i] = (f0[i]+f1[i]+f3[i]+f6[i]+f7[i]+f10[i]+f12[i]+f15[i]+f16[i]+2.0*(f2[i]+f4[i]+f8[i]+f9[i]+f14[i]))/(1.0-vy);
    allmass += frac[i];
  }
  invallmass = fReciprocal(allmass);
  for(int i=0; i<lbsy.nf; i++)
    frac[i] *= invallmass;
    
  return 0;
}

double fD3Q19PSSwiftPhi(double vy, double g0, double g1, double g2, double g3, double g4, double g5, double g6, double g7, double g8, double g9, double g10, double g11, double g12, double g13, double g14, double g15, double g16, double g17, double g18)
{
  // calculate concentration at bottom boundary (CETF) for fluids
  // with Swift free-energy interactions
    
  double phi = (g0+g1+g3+g6+g7+g10+g12+g15+g16+2.0*(g2+g4+g8+g9+g14))/(1.0-vy);
  return phi;
}

int fD3Q19BoundaryForceVelocity(double *force, long tpos, long tpos1, double dx, double dy, double dz, double *uwall, int prop)
{
  // calculate forces required at constant velocity boundary point for D3Q19 lattice

  long spos = tpos * lbsitelength;
  int qdim = lbsy.nf+lbsy.nc+lbsy.nt;
  double frac[lbsy.nf];
  double phi, freq = (lbbdforcetyp==1)*sin(lboscilfreq*(lbcurstep-lbequstep));

  switch (prop) {
    case PST:
      if(interact==20 && lbsy.nf>1) {
        phi = fD3Q19PSSwiftPhi(uwall[1], lbf[spos+1], lbf[spos+1+1*qdim], lbf[spos+1+2*qdim], lbf[spos+1+3*qdim], lbf[spos+1+4*qdim],
                               lbf[spos+1+5*qdim], lbf[spos+1+6*qdim], lbf[spos+1+7*qdim], lbf[spos+1+8*qdim], lbf[spos+1+9*qdim],
                               lbf[spos+1+10*qdim], lbf[spos+1+11*qdim], lbf[spos+1+12*qdim], lbf[spos+1+13*qdim], lbf[spos+1+14*qdim],
                               lbf[spos+1+15*qdim], lbf[spos+1+16*qdim], lbf[spos+1+17*qdim], lbf[spos+1+18*qdim]);
        force[0] = 0.5*(1.0+phi)*(lbinterforce[tpos*3*lbsy.nf  ] + lbheatforce[tpos*3*lbsy.nf  ] + postequil*(lbbdforce[0]+lboscilforce[0]*freq))
                 + 0.5*(1.0-phi)*(lbinterforce[tpos*3*lbsy.nf+3] + lbheatforce[tpos*3*lbsy.nf+3] + postequil*(lbbdforce[3]+lboscilforce[3]*freq));
        force[1] = 0.5*(1.0+phi)*(lbinterforce[tpos*3*lbsy.nf+1] + lbheatforce[tpos*3*lbsy.nf+1] + postequil*(lbbdforce[1]+lboscilforce[1]*freq))
                 + 0.5*(1.0-phi)*(lbinterforce[tpos*3*lbsy.nf+4] + lbheatforce[tpos*3*lbsy.nf+4] + postequil*(lbbdforce[4]+lboscilforce[4]*freq));
        force[2] = 0.5*(1.0+phi)*(lbinterforce[tpos*3*lbsy.nf+2] + lbheatforce[tpos*3*lbsy.nf+2] + postequil*(lbbdforce[2]+lboscilforce[2]*freq))
                 + 0.5*(1.0-phi)*(lbinterforce[tpos*3*lbsy.nf+5] + lbheatforce[tpos*3*lbsy.nf+5] + postequil*(lbbdforce[5]+lboscilforce[5]*freq));
        force[3] = 0.0;
        force[4] = 0.0;
        force[5] = 0.0;
      }
      else {
        if(interact>9 && interact<20) {
          fD3Q19PSFracSite(frac, uwall[1], &lbf[spos], &lbf[spos+1*qdim], &lbf[spos+2*qdim],
                           &lbf[spos+3*qdim],  &lbf[spos+4*qdim],  &lbf[spos+5*qdim],  &lbf[spos+6*qdim],
                           &lbf[spos+7*qdim],  &lbf[spos+8*qdim],  &lbf[spos+9*qdim],  &lbf[spos+10*qdim],
                           &lbf[spos+11*qdim], &lbf[spos+12*qdim], &lbf[spos+13*qdim], &lbf[spos+14*qdim],
                           &lbf[spos+15*qdim], &lbf[spos+16*qdim], &lbf[spos+17*qdim], &lbf[spos+18*qdim]);
          for(int i=0; i<lbsy.nf; i++) {
            force[3*i  ] = frac[i] * lbinterforce[tpos*3  ] + lbheatforce[tpos*3*lbsy.nf+3*i  ] + postequil * (lbbdforce[3*i  ]+lboscilforce[3*i  ]*freq);
            force[3*i+1] = frac[i] * lbinterforce[tpos*3+1] + lbheatforce[tpos*3*lbsy.nf+3*i+1] + postequil * (lbbdforce[3*i+1]+lboscilforce[3*i+1]*freq);
            force[3*i+2] = frac[i] * lbinterforce[tpos*3+2] + lbheatforce[tpos*3*lbsy.nf+3*i+2] + postequil * (lbbdforce[3*i+2]+lboscilforce[3*i+2]*freq);
          }
        }
        else {
          for(int i=0; i<lbsy.nf; i++) {
            force[3*i  ] = lbinterforce[tpos*3*lbsy.nf+3*i  ] + lbheatforce[tpos*3*lbsy.nf+3*i  ] + postequil * (lbbdforce[3*i  ]+lboscilforce[3*i  ]*freq);
            force[3*i+1] = lbinterforce[tpos*3*lbsy.nf+3*i+1] + lbheatforce[tpos*3*lbsy.nf+3*i+1] + postequil * (lbbdforce[3*i+1]+lboscilforce[3*i+1]*freq);
            force[3*i+2] = lbinterforce[tpos*3*lbsy.nf+3*i+2] + lbheatforce[tpos*3*lbsy.nf+3*i+2] + postequil * (lbbdforce[3*i+2]+lboscilforce[3*i+2]*freq);
          }
        }
      }
      break;
    case PSD:
      if(interact==20 && lbsy.nf>1) {
        phi = fD3Q19PSSwiftPhi(-uwall[1], lbf[spos+1], lbf[spos+1+10*qdim], lbf[spos+1+11*qdim], lbf[spos+1+12*qdim], lbf[spos+1+13*qdim],
                               lbf[spos+1+14*qdim], lbf[spos+1+15*qdim], lbf[spos+1+16*qdim], lbf[spos+1+17*qdim], lbf[spos+1+18*qdim],
                               lbf[spos+1+1*qdim], lbf[spos+1+2*qdim], lbf[spos+1+3*qdim], lbf[spos+1+4*qdim], lbf[spos+1+5*qdim],
                               lbf[spos+1+6*qdim], lbf[spos+1+7*qdim], lbf[spos+1+8*qdim], lbf[spos+1+9*qdim]);
        force[0] = -0.5*(1.0+phi)*(lbinterforce[tpos*3*lbsy.nf  ] + lbheatforce[tpos*3*lbsy.nf  ] + postequil*(lbbdforce[0]+lboscilforce[0]*freq))
                 -  0.5*(1.0-phi)*(lbinterforce[tpos*3*lbsy.nf+3] + lbheatforce[tpos*3*lbsy.nf+3] + postequil*(lbbdforce[3]+lboscilforce[3]*freq));
        force[1] = -0.5*(1.0+phi)*(lbinterforce[tpos*3*lbsy.nf+1] + lbheatforce[tpos*3*lbsy.nf+1] + postequil*(lbbdforce[1]+lboscilforce[1]*freq))
                 -  0.5*(1.0-phi)*(lbinterforce[tpos*3*lbsy.nf+4] + lbheatforce[tpos*3*lbsy.nf+4] + postequil*(lbbdforce[4]+lboscilforce[4]*freq));
        force[2] = -0.5*(1.0+phi)*(lbinterforce[tpos*3*lbsy.nf+2] + lbheatforce[tpos*3*lbsy.nf+2] + postequil*(lbbdforce[2]+lboscilforce[2]*freq))
                 -  0.5*(1.0-phi)*(lbinterforce[tpos*3*lbsy.nf+5] + lbheatforce[tpos*3*lbsy.nf+5] + postequil*(lbbdforce[5]+lboscilforce[5]*freq));
        force[3] = 0.0;
        force[4] = 0.0;
        force[5] = 0.0;
      }
      else {
        if(interact>9 && interact<20) {
          fD3Q19PSFracSite(frac, -uwall[1], &lbf[spos], &lbf[spos+10*qdim], &lbf[spos+11*qdim],
                           &lbf[spos+12*qdim], &lbf[spos+13*qdim], &lbf[spos+14*qdim], &lbf[spos+15*qdim],
                           &lbf[spos+16*qdim], &lbf[spos+17*qdim], &lbf[spos+18*qdim], &lbf[spos+1*qdim],
                           &lbf[spos+2*qdim],  &lbf[spos+3*qdim],  &lbf[spos+4*qdim],  &lbf[spos+5*qdim],
                           &lbf[spos+6*qdim],  &lbf[spos+7*qdim],  &lbf[spos+8*qdim],  &lbf[spos+9*qdim]);
          for(int i=0; i<lbsy.nf; i++) {
            force[3*i  ] = -frac[i] * lbinterforce[tpos*3  ] - lbheatforce[tpos*3*lbsy.nf+3*i  ] - postequil * (lbbdforce[3*i  ]+lboscilforce[3*i  ]*freq);
            force[3*i+1] = -frac[i] * lbinterforce[tpos*3+1] - lbheatforce[tpos*3*lbsy.nf+3*i+1] - postequil * (lbbdforce[3*i+1]+lboscilforce[3*i+1]*freq);
            force[3*i+2] = -frac[i] * lbinterforce[tpos*3+2] - lbheatforce[tpos*3*lbsy.nf+3*i+2] - postequil * (lbbdforce[3*i+2]+lboscilforce[3*i+2]*freq);
          }
        }
        else {
          for(int i=0; i<lbsy.nf; i++) {
            force[3*i  ] = -lbinterforce[tpos*3*lbsy.nf+3*i  ] - lbheatforce[tpos*3*lbsy.nf+3*i  ] - postequil * (lbbdforce[3*i  ]+lboscilforce[3*i  ]*freq);
            force[3*i+1] = -lbinterforce[tpos*3*lbsy.nf+3*i+1] - lbheatforce[tpos*3*lbsy.nf+3*i+1] - postequil * (lbbdforce[3*i+1]+lboscilforce[3*i+1]*freq);
            force[3*i+2] = -lbinterforce[tpos*3*lbsy.nf+3*i+2] - lbheatforce[tpos*3*lbsy.nf+3*i+2] - postequil * (lbbdforce[3*i+2]+lboscilforce[3*i+2]*freq);
          }
        }
      }
      break;
    case PSL:
      if(interact==20 && lbsy.nf>1) {
        phi = fD3Q19PSSwiftPhi(-uwall[0], lbf[spos+1], lbf[spos+1+12*qdim], lbf[spos+1+10*qdim], lbf[spos+1+11*qdim], lbf[spos+1+15*qdim],
                               lbf[spos+1+7*qdim], lbf[spos+1+17*qdim], lbf[spos+1+9*qdim], lbf[spos+1+13*qdim], lbf[spos+1+14*qdim],
                               lbf[spos+1+3*qdim], lbf[spos+1+1*qdim], lbf[spos+1+2*qdim], lbf[spos+1+6*qdim], lbf[spos+1+16*qdim],
                               lbf[spos+1+8*qdim], lbf[spos+1+18*qdim], lbf[spos+1+4*qdim], lbf[spos+1+5*qdim]);
        force[1] = -0.5*(1.0+phi)*(lbinterforce[tpos*3*lbsy.nf  ] + lbheatforce[tpos*3*lbsy.nf  ] + postequil*(lbbdforce[0]+lboscilforce[0]*freq))
                 -  0.5*(1.0-phi)*(lbinterforce[tpos*3*lbsy.nf+3] + lbheatforce[tpos*3*lbsy.nf+3] + postequil*(lbbdforce[3]+lboscilforce[3]*freq));
        force[2] = -0.5*(1.0+phi)*(lbinterforce[tpos*3*lbsy.nf+1] + lbheatforce[tpos*3*lbsy.nf+1] + postequil*(lbbdforce[1]+lboscilforce[1]*freq))
                 -  0.5*(1.0-phi)*(lbinterforce[tpos*3*lbsy.nf+4] + lbheatforce[tpos*3*lbsy.nf+4] + postequil*(lbbdforce[4]+lboscilforce[4]*freq));
        force[0] = -0.5*(1.0+phi)*(lbinterforce[tpos*3*lbsy.nf+2] + lbheatforce[tpos*3*lbsy.nf+2] + postequil*(lbbdforce[2]+lboscilforce[2]*freq))
                 -  0.5*(1.0-phi)*(lbinterforce[tpos*3*lbsy.nf+5] + lbheatforce[tpos*3*lbsy.nf+5] + postequil*(lbbdforce[5]+lboscilforce[5]*freq));
        force[3] = 0.0;
        force[4] = 0.0;
        force[5] = 0.0;
      }
      else {
        if(interact>9 && interact<20) {
          fD3Q19PSFracSite(frac, -uwall[0], &lbf[spos], &lbf[spos+12*qdim], &lbf[spos+10*qdim],
                           &lbf[spos+11*qdim], &lbf[spos+15*qdim], &lbf[spos+7*qdim],  &lbf[spos+17*qdim],
                           &lbf[spos+9*qdim],  &lbf[spos+13*qdim], &lbf[spos+14*qdim], &lbf[spos+3*qdim],
                           &lbf[spos+1*qdim],  &lbf[spos+2*qdim],  &lbf[spos+6*qdim],  &lbf[spos+16*qdim],
                           &lbf[spos+8*qdim],  &lbf[spos+18*qdim], &lbf[spos+4*qdim],  &lbf[spos+5*qdim]);
          for(int i=0; i<lbsy.nf; i++) {
            force[3*i+1] = -frac[i] * lbinterforce[tpos*3  ] - lbheatforce[tpos*3*lbsy.nf+3*i  ] - postequil * (lbbdforce[3*i  ]+lboscilforce[3*i  ]*freq);
            force[3*i+2] = -frac[i] * lbinterforce[tpos*3+1] - lbheatforce[tpos*3*lbsy.nf+3*i+1] - postequil * (lbbdforce[3*i+1]+lboscilforce[3*i+1]*freq);
            force[3*i  ] = -frac[i] * lbinterforce[tpos*3+2] - lbheatforce[tpos*3*lbsy.nf+3*i+2] - postequil * (lbbdforce[3*i+2]+lboscilforce[3*i+2]*freq);
          }
        }
        else {
          for(int i=0; i<lbsy.nf; i++) {
            force[3*i+1] = -lbinterforce[tpos*3*lbsy.nf+3*i  ] - lbheatforce[tpos*3*lbsy.nf+3*i  ] - postequil * (lbbdforce[3*i  ]+lboscilforce[3*i  ]*freq);
            force[3*i+2] = -lbinterforce[tpos*3*lbsy.nf+3*i+1] - lbheatforce[tpos*3*lbsy.nf+3*i+1] - postequil * (lbbdforce[3*i+1]+lboscilforce[3*i+1]*freq);
            force[3*i  ] = -lbinterforce[tpos*3*lbsy.nf+3*i+2] - lbheatforce[tpos*3*lbsy.nf+3*i+2] - postequil * (lbbdforce[3*i+2]+lboscilforce[3*i+2]*freq);
          }
        }
      }
      break;
    case PSR:
      if(interact==20 && lbsy.nf>1) {
        phi = fD3Q19PSSwiftPhi(uwall[0], lbf[spos+1], lbf[spos+1+3*qdim], lbf[spos+1+1*qdim], lbf[spos+1+2*qdim], lbf[spos+1+6*qdim],
                               lbf[spos+1+16*qdim], lbf[spos+1+8*qdim], lbf[spos+1+18*qdim], lbf[spos+1+4*qdim], lbf[spos+1+5*qdim],
                               lbf[spos+1+12*qdim], lbf[spos+1+10*qdim], lbf[spos+1+11*qdim], lbf[spos+1+15*qdim], lbf[spos+1+7*qdim],
                               lbf[spos+1+17*qdim], lbf[spos+1+9*qdim], lbf[spos+1+13*qdim], lbf[spos+1+14*qdim]);
        force[1] = 0.5*(1.0+phi)*(lbinterforce[tpos*3*lbsy.nf  ] + lbheatforce[tpos*3*lbsy.nf  ] + postequil*(lbbdforce[0]+lboscilforce[0]*freq))
                 + 0.5*(1.0-phi)*(lbinterforce[tpos*3*lbsy.nf+3] + lbheatforce[tpos*3*lbsy.nf+3] + postequil*(lbbdforce[3]+lboscilforce[3]*freq));
        force[2] = 0.5*(1.0+phi)*(lbinterforce[tpos*3*lbsy.nf+1] + lbheatforce[tpos*3*lbsy.nf+1] + postequil*(lbbdforce[1]+lboscilforce[1]*freq))
                 + 0.5*(1.0-phi)*(lbinterforce[tpos*3*lbsy.nf+4] + lbheatforce[tpos*3*lbsy.nf+4] + postequil*(lbbdforce[4]+lboscilforce[4]*freq));
        force[0] = 0.5*(1.0+phi)*(lbinterforce[tpos*3*lbsy.nf+2] + lbheatforce[tpos*3*lbsy.nf+2] + postequil*(lbbdforce[2]+lboscilforce[2]*freq))
                 + 0.5*(1.0-phi)*(lbinterforce[tpos*3*lbsy.nf+5] + lbheatforce[tpos*3*lbsy.nf+5] + postequil*(lbbdforce[5]+lboscilforce[5]*freq));
        force[3] = 0.0;
        force[4] = 0.0;
        force[5] = 0.0;
      }
      else {
        if(interact>9 && interact<20) {
          fD3Q19PSFracSite(frac, uwall[0], &lbf[spos], &lbf[spos+3*qdim], &lbf[spos+1*qdim],
                           &lbf[spos+2*qdim],  &lbf[spos+6*qdim],  &lbf[spos+16*qdim], &lbf[spos+8*qdim],
                           &lbf[spos+18*qdim], &lbf[spos+4*qdim],  &lbf[spos+5*qdim],  &lbf[spos+12*qdim],
                           &lbf[spos+10*qdim], &lbf[spos+11*qdim], &lbf[spos+15*qdim], &lbf[spos+7*qdim],
                           &lbf[spos+17*qdim], &lbf[spos+9*qdim],  &lbf[spos+13*qdim], &lbf[spos+14*qdim]);
          for(int i=0; i<lbsy.nf; i++) {
            force[3*i+1] = frac[i] * lbinterforce[tpos*3  ] + lbheatforce[tpos*3*lbsy.nf+3*i  ] + postequil * (lbbdforce[3*i  ]+lboscilforce[3*i  ]*freq);
            force[3*i+2] = frac[i] * lbinterforce[tpos*3+1] + lbheatforce[tpos*3*lbsy.nf+3*i+1] + postequil * (lbbdforce[3*i+1]+lboscilforce[3*i+1]*freq);
            force[3*i  ] = frac[i] * lbinterforce[tpos*3+2] + lbheatforce[tpos*3*lbsy.nf+3*i+2] + postequil * (lbbdforce[3*i+2]+lboscilforce[3*i+2]*freq);
          }
        }
        else {
          for(int i=0; i<lbsy.nf; i++) {
            force[3*i+1] = lbinterforce[tpos*3*lbsy.nf+3*i  ] + lbheatforce[tpos*3*lbsy.nf+3*i  ] + postequil * (lbbdforce[3*i  ]+lboscilforce[3*i  ]*freq);
            force[3*i+2] = lbinterforce[tpos*3*lbsy.nf+3*i+1] + lbheatforce[tpos*3*lbsy.nf+3*i+1] + postequil * (lbbdforce[3*i+1]+lboscilforce[3*i+1]*freq);
            force[3*i  ] = lbinterforce[tpos*3*lbsy.nf+3*i+2] + lbheatforce[tpos*3*lbsy.nf+3*i+2] + postequil * (lbbdforce[3*i+2]+lboscilforce[3*i+2]*freq);
          }
        }
      }
      break;
    case PSF:
      if(interact==20 && lbsy.nf>1) {
        phi = fD3Q19PSSwiftPhi(-uwall[2], lbf[spos+1], lbf[spos+1+11*qdim], lbf[spos+1+12*qdim], lbf[spos+1+10*qdim], lbf[spos+1+17*qdim],
                               lbf[spos+1+18*qdim], lbf[spos+1+13*qdim], lbf[spos+1+5*qdim], lbf[spos+1+15*qdim], lbf[spos+1+7*qdim],
                               lbf[spos+1+2*qdim], lbf[spos+1+3*qdim], lbf[spos+1+1*qdim], lbf[spos+1+8*qdim], lbf[spos+1+9*qdim],
                               lbf[spos+1+4*qdim], lbf[spos+1+14*qdim], lbf[spos+1+6*qdim], lbf[spos+1+16*qdim]);
        force[2] = -0.5*(1.0+phi)*(lbinterforce[tpos*3*lbsy.nf  ] + lbheatforce[tpos*3*lbsy.nf  ] + postequil*(lbbdforce[0]+lboscilforce[0]*freq))
                 -  0.5*(1.0-phi)*(lbinterforce[tpos*3*lbsy.nf+3] + lbheatforce[tpos*3*lbsy.nf+3] + postequil*(lbbdforce[3]+lboscilforce[3]*freq));
        force[0] = -0.5*(1.0+phi)*(lbinterforce[tpos*3*lbsy.nf+1] + lbheatforce[tpos*3*lbsy.nf+1] + postequil*(lbbdforce[1]+lboscilforce[1]*freq))
                 -  0.5*(1.0-phi)*(lbinterforce[tpos*3*lbsy.nf+4] + lbheatforce[tpos*3*lbsy.nf+4] + postequil*(lbbdforce[4]+lboscilforce[4]*freq));
        force[1] = -0.5*(1.0+phi)*(lbinterforce[tpos*3*lbsy.nf+2] + lbheatforce[tpos*3*lbsy.nf+2] + postequil*(lbbdforce[2]+lboscilforce[2]*freq))
                 -  0.5*(1.0-phi)*(lbinterforce[tpos*3*lbsy.nf+5] + lbheatforce[tpos*3*lbsy.nf+5] + postequil*(lbbdforce[5]+lboscilforce[5]*freq));
        force[3] = 0.0;
        force[4] = 0.0;
        force[5] = 0.0;
      }
      else {
        if(interact>9 && interact<20) {
          fD3Q19PSFracSite(frac, -uwall[2], &lbf[spos], &lbf[spos+11*qdim], &lbf[spos+12*qdim],
                           &lbf[spos+10*qdim], &lbf[spos+17*qdim], &lbf[spos+18*qdim], &lbf[spos+13*qdim],
                           &lbf[spos+5*qdim],  &lbf[spos+15*qdim], &lbf[spos+7*qdim],  &lbf[spos+2*qdim],
                           &lbf[spos+3*qdim],  &lbf[spos+1*qdim],  &lbf[spos+8*qdim],  &lbf[spos+9*qdim],
                           &lbf[spos+4*qdim],  &lbf[spos+14*qdim], &lbf[spos+6*qdim],  &lbf[spos+16*qdim]);
          for(int i=0; i<lbsy.nf; i++) {
            force[3*i+2] = -frac[i] * lbinterforce[tpos*3  ] - lbheatforce[tpos*3*lbsy.nf+3*i  ] - postequil * (lbbdforce[3*i  ]+lboscilforce[3*i  ]*freq);
            force[3*i  ] = -frac[i] * lbinterforce[tpos*3+1] - lbheatforce[tpos*3*lbsy.nf+3*i+1] - postequil * (lbbdforce[3*i+1]+lboscilforce[3*i+1]*freq);
            force[3*i+1] = -frac[i] * lbinterforce[tpos*3+2] - lbheatforce[tpos*3*lbsy.nf+3*i+2] - postequil * (lbbdforce[3*i+2]+lboscilforce[3*i+2]*freq);
          }
        }
        else {
          for(int i=0; i<lbsy.nf; i++) {
            force[3*i+2] = -lbinterforce[tpos*3*lbsy.nf+3*i  ] - lbheatforce[tpos*3*lbsy.nf+3*i  ] - postequil * (lbbdforce[3*i  ]+lboscilforce[3*i  ]*freq);
            force[3*i  ] = -lbinterforce[tpos*3*lbsy.nf+3*i+1] - lbheatforce[tpos*3*lbsy.nf+3*i+1] - postequil * (lbbdforce[3*i+1]+lboscilforce[3*i+1]*freq);
            force[3*i+1] = -lbinterforce[tpos*3*lbsy.nf+3*i+2] - lbheatforce[tpos*3*lbsy.nf+3*i+2] - postequil * (lbbdforce[3*i+2]+lboscilforce[3*i+2]*freq);
          }
        }
      }
      break;
    case PSB:
      if(interact==20 && lbsy.nf>1) {
        phi = fD3Q19PSSwiftPhi(uwall[2], lbf[spos+1], lbf[spos+1+2*qdim], lbf[spos+1+3*qdim], lbf[spos+1+1*qdim], lbf[spos+1+8*qdim],
                               lbf[spos+1+9*qdim], lbf[spos+1+4*qdim], lbf[spos+1+14*qdim], lbf[spos+1+6*qdim], lbf[spos+1+16*qdim],
                               lbf[spos+1+11*qdim], lbf[spos+1+12*qdim], lbf[spos+1+10*qdim], lbf[spos+1+17*qdim], lbf[spos+1+18*qdim],
                               lbf[spos+1+13*qdim], lbf[spos+1+5*qdim], lbf[spos+1+15*qdim], lbf[spos+1+7*qdim]);
        force[2] = 0.5*(1.0+phi)*(lbinterforce[tpos*3*lbsy.nf  ] + lbheatforce[tpos*3*lbsy.nf  ] + postequil*(lbbdforce[0]+lboscilforce[0]*freq))
                 + 0.5*(1.0-phi)*(lbinterforce[tpos*3*lbsy.nf+3] + lbheatforce[tpos*3*lbsy.nf+3] + postequil*(lbbdforce[3]+lboscilforce[3]*freq));
        force[0] = 0.5*(1.0+phi)*(lbinterforce[tpos*3*lbsy.nf+1] + lbheatforce[tpos*3*lbsy.nf+1] + postequil*(lbbdforce[1]+lboscilforce[1]*freq))
                 + 0.5*(1.0-phi)*(lbinterforce[tpos*3*lbsy.nf+4] + lbheatforce[tpos*3*lbsy.nf+4] + postequil*(lbbdforce[4]+lboscilforce[4]*freq));
        force[1] = 0.5*(1.0+phi)*(lbinterforce[tpos*3*lbsy.nf+2] + lbheatforce[tpos*3*lbsy.nf+2] + postequil*(lbbdforce[2]+lboscilforce[2]*freq))
                 + 0.5*(1.0-phi)*(lbinterforce[tpos*3*lbsy.nf+5] + lbheatforce[tpos*3*lbsy.nf+5] + postequil*(lbbdforce[5]+lboscilforce[5]*freq));
        force[3] = 0.0;
        force[4] = 0.0;
        force[5] = 0.0;
      }
      else {
        if(interact>9 && interact<20) {
          fD3Q19PSFracSite(frac, uwall[2], &lbf[spos], &lbf[spos+2*qdim], &lbf[spos+3*qdim],
                           &lbf[spos+1*qdim],  &lbf[spos+8*qdim],  &lbf[spos+9*qdim],  &lbf[spos+4*qdim],
                           &lbf[spos+14*qdim], &lbf[spos+6*qdim],  &lbf[spos+16*qdim], &lbf[spos+11*qdim],
                           &lbf[spos+12*qdim], &lbf[spos+10*qdim], &lbf[spos+17*qdim], &lbf[spos+18*qdim],
                           &lbf[spos+13*qdim], &lbf[spos+5*qdim],  &lbf[spos+15*qdim], &lbf[spos+7*qdim]);
          for(int i=0; i<lbsy.nf; i++) {
            force[3*i+2] = frac[i] * lbinterforce[tpos*3  ] + lbheatforce[tpos*3*lbsy.nf+3*i  ] + postequil * (lbbdforce[3*i  ]+lboscilforce[3*i  ]*freq);
            force[3*i  ] = frac[i] * lbinterforce[tpos*3+1] + lbheatforce[tpos*3*lbsy.nf+3*i+1] + postequil * (lbbdforce[3*i+1]+lboscilforce[3*i+1]*freq);
            force[3*i+1] = frac[i] * lbinterforce[tpos*3+2] + lbheatforce[tpos*3*lbsy.nf+3*i+2] + postequil * (lbbdforce[3*i+2]+lboscilforce[3*i+2]*freq);
          }
        }
        else {
          for(int i=0; i<lbsy.nf; i++) {
            force[3*i+2] = lbinterforce[tpos*3*lbsy.nf+3*i  ] + lbheatforce[tpos*3*lbsy.nf+3*i  ] + postequil * (lbbdforce[3*i  ]+lboscilforce[3*i  ]*freq);
            force[3*i  ] = lbinterforce[tpos*3*lbsy.nf+3*i+1] + lbheatforce[tpos*3*lbsy.nf+3*i+1] + postequil * (lbbdforce[3*i+1]+lboscilforce[3*i+1]*freq);
            force[3*i+1] = lbinterforce[tpos*3*lbsy.nf+3*i+2] + lbheatforce[tpos*3*lbsy.nf+3*i+2] + postequil * (lbbdforce[3*i+2]+lboscilforce[3*i+2]*freq);
          }
        }
      }
      break;
    case CCTRB:
      if(interact==20 && lbsy.nf>1) {
        phi = fD3CECCSwiftPhi(tpos1, dx, dy, dz, lbft[4*lbsy.nf*tpos+4], lbft[4*lbsy.nf*tpos+5], lbft[4*lbsy.nf*tpos+6]);
        force[0] =  0.5*(1.0+phi)*(lbinterforce[tpos*3*lbsy.nf  ] + lbheatforce[tpos*3*lbsy.nf  ] + postequil*(lbbdforce[0]+lboscilforce[0]*freq))
                 +  0.5*(1.0-phi)*(lbinterforce[tpos*3*lbsy.nf+3] + lbheatforce[tpos*3*lbsy.nf+3] + postequil*(lbbdforce[3]+lboscilforce[3]*freq));
        force[1] =  0.5*(1.0+phi)*(lbinterforce[tpos*3*lbsy.nf+1] + lbheatforce[tpos*3*lbsy.nf+1] + postequil*(lbbdforce[1]+lboscilforce[1]*freq))
                 +  0.5*(1.0-phi)*(lbinterforce[tpos*3*lbsy.nf+4] + lbheatforce[tpos*3*lbsy.nf+4] + postequil*(lbbdforce[4]+lboscilforce[4]*freq));
        force[2] = -0.5*(1.0+phi)*(lbinterforce[tpos*3*lbsy.nf+2] + lbheatforce[tpos*3*lbsy.nf+2] + postequil*(lbbdforce[2]+lboscilforce[2]*freq))
                 -  0.5*(1.0-phi)*(lbinterforce[tpos*3*lbsy.nf+5] + lbheatforce[tpos*3*lbsy.nf+5] + postequil*(lbbdforce[5]+lboscilforce[5]*freq));
        force[3] =  0.0;
        force[4] =  0.0;
        force[5] =  0.0;
      }
      else {
        if(interact>9 && interact<20) {
          fD3CECCFracSite(frac, tpos1);
          for(int i=0; i<lbsy.nf; i++) {
            force[3*i  ] =  frac[i] * lbinterforce[tpos*3  ] + lbheatforce[tpos*3*lbsy.nf+3*i  ] + postequil * (lbbdforce[3*i  ]+lboscilforce[3*i  ]*freq);
            force[3*i+1] =  frac[i] * lbinterforce[tpos*3+1] + lbheatforce[tpos*3*lbsy.nf+3*i+1] + postequil * (lbbdforce[3*i+1]+lboscilforce[3*i+1]*freq);
            force[3*i+2] = -frac[i] * lbinterforce[tpos*3+2] - lbheatforce[tpos*3*lbsy.nf+3*i+2] - postequil * (lbbdforce[3*i+2]+lboscilforce[3*i+2]*freq);
          }
        }
        else {
          for(int i=0; i<lbsy.nf; i++) {
            force[3*i  ] =  lbinterforce[tpos*3*lbsy.nf+3*i  ] + lbheatforce[tpos*3*lbsy.nf+3*i  ] + postequil * (lbbdforce[3*i  ]+lboscilforce[3*i  ]*freq);
            force[3*i+1] =  lbinterforce[tpos*3*lbsy.nf+3*i+1] + lbheatforce[tpos*3*lbsy.nf+3*i+1] + postequil * (lbbdforce[3*i+1]+lboscilforce[3*i+1]*freq);
            force[3*i+2] = -lbinterforce[tpos*3*lbsy.nf+3*i+2] - lbheatforce[tpos*3*lbsy.nf+3*i+2] - postequil * (lbbdforce[3*i+2]+lboscilforce[3*i+2]*freq);
          }
        }
      }
      break;
    case CCTLB:
      if(interact==20 && lbsy.nf>1) {
        phi = fD3CECCSwiftPhi(tpos1, dx, dy, dz, lbft[4*lbsy.nf*tpos+4], lbft[4*lbsy.nf*tpos+5], lbft[4*lbsy.nf*tpos+6]);
        force[0] = -0.5*(1.0+phi)*(lbinterforce[tpos*3*lbsy.nf  ] + lbheatforce[tpos*3*lbsy.nf  ] + postequil*(lbbdforce[0]+lboscilforce[0]*freq))
                 -  0.5*(1.0-phi)*(lbinterforce[tpos*3*lbsy.nf+3] + lbheatforce[tpos*3*lbsy.nf+3] + postequil*(lbbdforce[3]+lboscilforce[3]*freq));
        force[1] =  0.5*(1.0+phi)*(lbinterforce[tpos*3*lbsy.nf+1] + lbheatforce[tpos*3*lbsy.nf+1] + postequil*(lbbdforce[1]+lboscilforce[1]*freq))
                 +  0.5*(1.0-phi)*(lbinterforce[tpos*3*lbsy.nf+4] + lbheatforce[tpos*3*lbsy.nf+4] + postequil*(lbbdforce[4]+lboscilforce[4]*freq));
        force[2] = -0.5*(1.0+phi)*(lbinterforce[tpos*3*lbsy.nf+2] + lbheatforce[tpos*3*lbsy.nf+2] + postequil*(lbbdforce[2]+lboscilforce[2]*freq))
                 -  0.5*(1.0-phi)*(lbinterforce[tpos*3*lbsy.nf+5] + lbheatforce[tpos*3*lbsy.nf+5] + postequil*(lbbdforce[5]+lboscilforce[5]*freq));
        force[3] =  0.0;
        force[4] =  0.0;
        force[5] =  0.0;
      }
      else {
        if(interact>9 && interact<20) {
          fD3CECCFracSite(frac, tpos1);
          for(int i=0; i<lbsy.nf; i++) {
            force[3*i  ] = -frac[i] * lbinterforce[tpos*3  ] - lbheatforce[tpos*3*lbsy.nf+3*i  ] - postequil * (lbbdforce[3*i  ]+lboscilforce[3*i  ]*freq);
            force[3*i+1] =  frac[i] * lbinterforce[tpos*3+1] + lbheatforce[tpos*3*lbsy.nf+3*i+1] + postequil * (lbbdforce[3*i+1]+lboscilforce[3*i+1]*freq);
            force[3*i+2] = -frac[i] * lbinterforce[tpos*3+2] - lbheatforce[tpos*3*lbsy.nf+3*i+2] - postequil * (lbbdforce[3*i+2]+lboscilforce[3*i+2]*freq);
          }
        }
        else {
          for(int i=0; i<lbsy.nf; i++) {
            force[3*i  ] = -lbinterforce[tpos*3*lbsy.nf+3*i  ] - lbheatforce[tpos*3*lbsy.nf+3*i  ] - postequil * (lbbdforce[3*i  ]+lboscilforce[3*i  ]*freq);
            force[3*i+1] =  lbinterforce[tpos*3*lbsy.nf+3*i+1] + lbheatforce[tpos*3*lbsy.nf+3*i+1] + postequil * (lbbdforce[3*i+1]+lboscilforce[3*i+1]*freq);
            force[3*i+2] = -lbinterforce[tpos*3*lbsy.nf+3*i+2] - lbheatforce[tpos*3*lbsy.nf+3*i+2] - postequil * (lbbdforce[3*i+2]+lboscilforce[3*i+2]*freq);
          }
        }
      }
      break;
    case CCDLB:
      if(interact==20 && lbsy.nf>1) {
        phi = fD3CECCSwiftPhi(tpos1, dx, dy, dz, lbft[4*lbsy.nf*tpos+4], lbft[4*lbsy.nf*tpos+5], lbft[4*lbsy.nf*tpos+6]);
        force[0] = -0.5*(1.0+phi)*(lbinterforce[tpos*3*lbsy.nf  ] + lbheatforce[tpos*3*lbsy.nf  ] + postequil*(lbbdforce[0]+lboscilforce[0]*freq))
                 -  0.5*(1.0-phi)*(lbinterforce[tpos*3*lbsy.nf+3] + lbheatforce[tpos*3*lbsy.nf+3] + postequil*(lbbdforce[3]+lboscilforce[3]*freq));
        force[1] = -0.5*(1.0+phi)*(lbinterforce[tpos*3*lbsy.nf+1] + lbheatforce[tpos*3*lbsy.nf+1] + postequil*(lbbdforce[1]+lboscilforce[1]*freq))
                 -  0.5*(1.0-phi)*(lbinterforce[tpos*3*lbsy.nf+4] + lbheatforce[tpos*3*lbsy.nf+4] + postequil*(lbbdforce[4]+lboscilforce[4]*freq));
        force[2] = -0.5*(1.0+phi)*(lbinterforce[tpos*3*lbsy.nf+2] + lbheatforce[tpos*3*lbsy.nf+2] + postequil*(lbbdforce[2]+lboscilforce[2]*freq))
                 -  0.5*(1.0-phi)*(lbinterforce[tpos*3*lbsy.nf+5] + lbheatforce[tpos*3*lbsy.nf+5] + postequil*(lbbdforce[5]+lboscilforce[5]*freq));
        force[3] =  0.0;
        force[4] =  0.0;
        force[5] =  0.0;
      }
      else {
        if(interact>9 && interact<20) {
          fD3CECCFracSite(frac, tpos1);
          for(int i=0; i<lbsy.nf; i++) {
            force[3*i  ] = -frac[i] * lbinterforce[tpos*3  ] - lbheatforce[tpos*3*lbsy.nf+3*i  ] - postequil * (lbbdforce[3*i  ]+lboscilforce[3*i  ]*freq);
            force[3*i+1] = -frac[i] * lbinterforce[tpos*3+1] - lbheatforce[tpos*3*lbsy.nf+3*i+1] - postequil * (lbbdforce[3*i+1]+lboscilforce[3*i+1]*freq);
            force[3*i+2] = -frac[i] * lbinterforce[tpos*3+2] - lbheatforce[tpos*3*lbsy.nf+3*i+2] - postequil * (lbbdforce[3*i+2]+lboscilforce[3*i+2]*freq);
          }
        }
        else {
          for(int i=0; i<lbsy.nf; i++) {
            force[3*i  ] = -lbinterforce[tpos*3*lbsy.nf+3*i  ] - lbheatforce[tpos*3*lbsy.nf+3*i  ] - postequil * (lbbdforce[3*i  ]+lboscilforce[3*i  ]*freq);
            force[3*i+1] = -lbinterforce[tpos*3*lbsy.nf+3*i+1] - lbheatforce[tpos*3*lbsy.nf+3*i+1] - postequil * (lbbdforce[3*i+1]+lboscilforce[3*i+1]*freq);
            force[3*i+2] = -lbinterforce[tpos*3*lbsy.nf+3*i+2] - lbheatforce[tpos*3*lbsy.nf+3*i+2] - postequil * (lbbdforce[3*i+2]+lboscilforce[3*i+2]*freq);
          }
        }
      }
      break;
    case CCDRB:
      if(interact==20 && lbsy.nf>1) {
        phi = fD3CECCSwiftPhi(tpos1, dx, dy, dz, lbft[4*lbsy.nf*tpos+4], lbft[4*lbsy.nf*tpos+5], lbft[4*lbsy.nf*tpos+6]);
        force[0] =  0.5*(1.0+phi)*(lbinterforce[tpos*3*lbsy.nf  ] + lbheatforce[tpos*3*lbsy.nf  ] + postequil*(lbbdforce[0]+lboscilforce[0]*freq))
                 +  0.5*(1.0-phi)*(lbinterforce[tpos*3*lbsy.nf+3] + lbheatforce[tpos*3*lbsy.nf+3] + postequil*(lbbdforce[3]+lboscilforce[3]*freq));
        force[1] = -0.5*(1.0+phi)*(lbinterforce[tpos*3*lbsy.nf+1] + lbheatforce[tpos*3*lbsy.nf+1] + postequil*(lbbdforce[1]+lboscilforce[1]*freq))
                 -  0.5*(1.0-phi)*(lbinterforce[tpos*3*lbsy.nf+4] + lbheatforce[tpos*3*lbsy.nf+4] + postequil*(lbbdforce[4]+lboscilforce[4]*freq));
        force[2] = -0.5*(1.0+phi)*(lbinterforce[tpos*3*lbsy.nf+2] + lbheatforce[tpos*3*lbsy.nf+2] + postequil*(lbbdforce[2]+lboscilforce[2]*freq))
                 -  0.5*(1.0-phi)*(lbinterforce[tpos*3*lbsy.nf+5] + lbheatforce[tpos*3*lbsy.nf+5] + postequil*(lbbdforce[5]+lboscilforce[5]*freq));
        force[3] =  0.0;
        force[4] =  0.0;
        force[5] =  0.0;
      }
      else {
        if(interact>9 && interact<20) {
          fD3CECCFracSite(frac, tpos1);
          for(int i=0; i<lbsy.nf; i++) {
            force[3*i  ] =  frac[i] * lbinterforce[tpos*3  ] + lbheatforce[tpos*3*lbsy.nf+3*i  ] + postequil * (lbbdforce[3*i  ]+lboscilforce[3*i  ]*freq);
            force[3*i+1] = -frac[i] * lbinterforce[tpos*3+1] - lbheatforce[tpos*3*lbsy.nf+3*i+1] - postequil * (lbbdforce[3*i+1]+lboscilforce[3*i+1]*freq);
            force[3*i+2] = -frac[i] * lbinterforce[tpos*3+2] - lbheatforce[tpos*3*lbsy.nf+3*i+2] - postequil * (lbbdforce[3*i+2]+lboscilforce[3*i+2]*freq);
          }
        }
        else {
          for(int i=0; i<lbsy.nf; i++) {
            force[3*i  ] =  lbinterforce[tpos*3*lbsy.nf+3*i  ] + lbheatforce[tpos*3*lbsy.nf+3*i  ] + postequil * (lbbdforce[3*i  ]+lboscilforce[3*i  ]*freq);
            force[3*i+1] = -lbinterforce[tpos*3*lbsy.nf+3*i+1] - lbheatforce[tpos*3*lbsy.nf+3*i+1] - postequil * (lbbdforce[3*i+1]+lboscilforce[3*i+1]*freq);
            force[3*i+2] = -lbinterforce[tpos*3*lbsy.nf+3*i+2] - lbheatforce[tpos*3*lbsy.nf+3*i+2] - postequil * (lbbdforce[3*i+2]+lboscilforce[3*i+2]*freq);
          }
        }
      }
      break;
    case CCTRF:
    case CETR:
      if(interact==20 && lbsy.nf>1) {
        phi = fD3CECCSwiftPhi(tpos1, dx, dy, dz, lbft[4*lbsy.nf*tpos+4], lbft[4*lbsy.nf*tpos+5], lbft[4*lbsy.nf*tpos+6]);
        force[0] = 0.5*(1.0+phi)*(lbinterforce[tpos*3*lbsy.nf  ] + lbheatforce[tpos*3*lbsy.nf  ] + postequil*(lbbdforce[0]+lboscilforce[0]*freq))
                 + 0.5*(1.0-phi)*(lbinterforce[tpos*3*lbsy.nf+3] + lbheatforce[tpos*3*lbsy.nf+3] + postequil*(lbbdforce[3]+lboscilforce[3]*freq));
        force[1] = 0.5*(1.0+phi)*(lbinterforce[tpos*3*lbsy.nf+1] + lbheatforce[tpos*3*lbsy.nf+1] + postequil*(lbbdforce[1]+lboscilforce[1]*freq))
                 + 0.5*(1.0-phi)*(lbinterforce[tpos*3*lbsy.nf+4] + lbheatforce[tpos*3*lbsy.nf+4] + postequil*(lbbdforce[4]+lboscilforce[4]*freq));
        force[2] = 0.5*(1.0+phi)*(lbinterforce[tpos*3*lbsy.nf+2] + lbheatforce[tpos*3*lbsy.nf+2] + postequil*(lbbdforce[2]+lboscilforce[2]*freq))
                 + 0.5*(1.0-phi)*(lbinterforce[tpos*3*lbsy.nf+5] + lbheatforce[tpos*3*lbsy.nf+5] + postequil*(lbbdforce[5]+lboscilforce[5]*freq));
        force[3] = 0.0;
        force[4] = 0.0;
        force[5] = 0.0;
      }
      else {
        if(interact>9 && interact<20) {
          fD3CECCFracSite(frac, tpos1);
          for(int i=0; i<lbsy.nf; i++) {
            force[3*i  ] = frac[i] * lbinterforce[tpos*3  ] + lbheatforce[tpos*3*lbsy.nf+3*i  ] + postequil * (lbbdforce[3*i  ]+lboscilforce[3*i  ]*freq);
            force[3*i+1] = frac[i] * lbinterforce[tpos*3+1] + lbheatforce[tpos*3*lbsy.nf+3*i+1] + postequil * (lbbdforce[3*i+1]+lboscilforce[3*i+1]*freq);
            force[3*i+2] = frac[i] * lbinterforce[tpos*3+2] + lbheatforce[tpos*3*lbsy.nf+3*i+2] + postequil * (lbbdforce[3*i+2]+lboscilforce[3*i+2]*freq);
          }
        }
        else {
          for(int i=0; i<lbsy.nf; i++) {
            force[3*i  ] = lbinterforce[tpos*3*lbsy.nf+3*i  ] + lbheatforce[tpos*3*lbsy.nf+3*i  ] + postequil * (lbbdforce[3*i  ]+lboscilforce[3*i  ]*freq);
            force[3*i+1] = lbinterforce[tpos*3*lbsy.nf+3*i+1] + lbheatforce[tpos*3*lbsy.nf+3*i+1] + postequil * (lbbdforce[3*i+1]+lboscilforce[3*i+1]*freq);
            force[3*i+2] = lbinterforce[tpos*3*lbsy.nf+3*i+2] + lbheatforce[tpos*3*lbsy.nf+3*i+2] + postequil * (lbbdforce[3*i+2]+lboscilforce[3*i+2]*freq);
          }
        }
      }
      break;
    case CCTLF:
      if(interact==20 && lbsy.nf>1) {
        phi = fD3CECCSwiftPhi(tpos1, dx, dy, dz, lbft[4*lbsy.nf*tpos+4], lbft[4*lbsy.nf*tpos+5], lbft[4*lbsy.nf*tpos+6]);
        force[0] = -0.5*(1.0+phi)*(lbinterforce[tpos*3*lbsy.nf  ] + lbheatforce[tpos*3*lbsy.nf  ] + postequil*(lbbdforce[0]+lboscilforce[0]*freq))
                 -  0.5*(1.0-phi)*(lbinterforce[tpos*3*lbsy.nf+3] + lbheatforce[tpos*3*lbsy.nf+3] + postequil*(lbbdforce[3]+lboscilforce[3]*freq));
        force[1] =  0.5*(1.0+phi)*(lbinterforce[tpos*3*lbsy.nf+1] + lbheatforce[tpos*3*lbsy.nf+1] + postequil*(lbbdforce[1]+lboscilforce[1]*freq))
                 +  0.5*(1.0-phi)*(lbinterforce[tpos*3*lbsy.nf+4] + lbheatforce[tpos*3*lbsy.nf+4] + postequil*(lbbdforce[4]+lboscilforce[4]*freq));
        force[2] =  0.5*(1.0+phi)*(lbinterforce[tpos*3*lbsy.nf+2] + lbheatforce[tpos*3*lbsy.nf+2] + postequil*(lbbdforce[2]+lboscilforce[2]*freq))
                 +  0.5*(1.0-phi)*(lbinterforce[tpos*3*lbsy.nf+5] + lbheatforce[tpos*3*lbsy.nf+5] + postequil*(lbbdforce[5]+lboscilforce[5]*freq));
        force[3] =  0.0;
        force[4] =  0.0;
        force[5] =  0.0;
      }
      else {
        if(interact>9 && interact<20) {
          fD3CECCFracSite(frac, tpos1);
          for(int i=0; i<lbsy.nf; i++) {
            force[3*i  ] = -frac[i] * lbinterforce[tpos*3  ] - lbheatforce[tpos*3*lbsy.nf+3*i  ] - postequil * (lbbdforce[3*i  ]+lboscilforce[3*i  ]*freq);
            force[3*i+1] =  frac[i] * lbinterforce[tpos*3+1] + lbheatforce[tpos*3*lbsy.nf+3*i+1] + postequil * (lbbdforce[3*i+1]+lboscilforce[3*i+1]*freq);
            force[3*i+2] =  frac[i] * lbinterforce[tpos*3+2] + lbheatforce[tpos*3*lbsy.nf+3*i+2] + postequil * (lbbdforce[3*i+2]+lboscilforce[3*i+2]*freq);
          }
        }
        else {
          for(int i=0; i<lbsy.nf; i++) {
            force[3*i  ] = -lbinterforce[tpos*3*lbsy.nf+3*i  ] - lbheatforce[tpos*3*lbsy.nf+3*i  ] - postequil * (lbbdforce[3*i  ]+lboscilforce[3*i  ]*freq);
            force[3*i+1] =  lbinterforce[tpos*3*lbsy.nf+3*i+1] + lbheatforce[tpos*3*lbsy.nf+3*i+1] + postequil * (lbbdforce[3*i+1]+lboscilforce[3*i+1]*freq);
            force[3*i+2] =  lbinterforce[tpos*3*lbsy.nf+3*i+2] + lbheatforce[tpos*3*lbsy.nf+3*i+2] + postequil * (lbbdforce[3*i+2]+lboscilforce[3*i+2]*freq);
          }
        }
      }
      break;
    case CCDLF:
    case CEDL:
      if(interact==20 && lbsy.nf>1) {
        phi = fD3CECCSwiftPhi(tpos1, dx, dy, dz, lbft[4*lbsy.nf*tpos+4], lbft[4*lbsy.nf*tpos+5], lbft[4*lbsy.nf*tpos+6]);
        force[0] = -0.5*(1.0+phi)*(lbinterforce[tpos*3*lbsy.nf  ] + lbheatforce[tpos*3*lbsy.nf  ] + postequil*(lbbdforce[0]+lboscilforce[0]*freq))
                 -  0.5*(1.0-phi)*(lbinterforce[tpos*3*lbsy.nf+3] + lbheatforce[tpos*3*lbsy.nf+3] + postequil*(lbbdforce[3]+lboscilforce[3]*freq));
        force[1] = -0.5*(1.0+phi)*(lbinterforce[tpos*3*lbsy.nf+1] + lbheatforce[tpos*3*lbsy.nf+1] + postequil*(lbbdforce[1]+lboscilforce[1]*freq))
                 -  0.5*(1.0-phi)*(lbinterforce[tpos*3*lbsy.nf+4] + lbheatforce[tpos*3*lbsy.nf+4] + postequil*(lbbdforce[4]+lboscilforce[4]*freq));
        force[2] =  0.5*(1.0+phi)*(lbinterforce[tpos*3*lbsy.nf+2] + lbheatforce[tpos*3*lbsy.nf+2] + postequil*(lbbdforce[2]+lboscilforce[2]*freq))
                 +  0.5*(1.0-phi)*(lbinterforce[tpos*3*lbsy.nf+5] + lbheatforce[tpos*3*lbsy.nf+5] + postequil*(lbbdforce[5]+lboscilforce[5]*freq));
        force[3] =  0.0;
        force[4] =  0.0;
        force[5] =  0.0;
      }
      else {
        if(interact>9 && interact<20) {
          fD3CECCFracSite(frac, tpos1);
          for(int i=0; i<lbsy.nf; i++) {
            force[3*i  ] = -frac[i] * lbinterforce[tpos*3  ] - lbheatforce[tpos*3*lbsy.nf+3*i  ] - postequil * (lbbdforce[3*i  ]+lboscilforce[3*i  ]*freq);
            force[3*i+1] = -frac[i] * lbinterforce[tpos*3+1] - lbheatforce[tpos*3*lbsy.nf+3*i+1] - postequil * (lbbdforce[3*i+1]+lboscilforce[3*i+1]*freq);
            force[3*i+2] =  frac[i] * lbinterforce[tpos*3+2] + lbheatforce[tpos*3*lbsy.nf+3*i+2] + postequil * (lbbdforce[3*i+2]+lboscilforce[3*i+2]*freq);
          }
        }
        else {
          for(int i=0; i<lbsy.nf; i++) {
            force[3*i  ] = -lbinterforce[tpos*3*lbsy.nf+3*i  ] - lbheatforce[tpos*3*lbsy.nf+3*i  ] - postequil * (lbbdforce[3*i  ]+lboscilforce[3*i  ]*freq);
            force[3*i+1] = -lbinterforce[tpos*3*lbsy.nf+3*i+1] - lbheatforce[tpos*3*lbsy.nf+3*i+1] - postequil * (lbbdforce[3*i+1]+lboscilforce[3*i+1]*freq);
            force[3*i+2] =  lbinterforce[tpos*3*lbsy.nf+3*i+2] + lbheatforce[tpos*3*lbsy.nf+3*i+2] + postequil * (lbbdforce[3*i+2]+lboscilforce[3*i+2]*freq);
          }
        }
      }
      break;
    case CCDRF:
      if(interact==20 && lbsy.nf>1) {
        phi = fD3CECCSwiftPhi(tpos1, dx, dy, dz, lbft[4*lbsy.nf*tpos+4], lbft[4*lbsy.nf*tpos+5], lbft[4*lbsy.nf*tpos+6]);
        force[0] =  0.5*(1.0+phi)*(lbinterforce[tpos*3*lbsy.nf  ] + lbheatforce[tpos*3*lbsy.nf  ] + postequil*(lbbdforce[0]+lboscilforce[0]*freq))
                 +  0.5*(1.0-phi)*(lbinterforce[tpos*3*lbsy.nf+3] + lbheatforce[tpos*3*lbsy.nf+3] + postequil*(lbbdforce[3]+lboscilforce[3]*freq));
        force[1] = -0.5*(1.0+phi)*(lbinterforce[tpos*3*lbsy.nf+1] + lbheatforce[tpos*3*lbsy.nf+1] + postequil*(lbbdforce[1]+lboscilforce[1]*freq))
                 -  0.5*(1.0-phi)*(lbinterforce[tpos*3*lbsy.nf+4] + lbheatforce[tpos*3*lbsy.nf+4] + postequil*(lbbdforce[4]+lboscilforce[4]*freq));
        force[2] =  0.5*(1.0+phi)*(lbinterforce[tpos*3*lbsy.nf+2] + lbheatforce[tpos*3*lbsy.nf+2] + postequil*(lbbdforce[2]+lboscilforce[2]*freq))
                 +  0.5*(1.0-phi)*(lbinterforce[tpos*3*lbsy.nf+5] + lbheatforce[tpos*3*lbsy.nf+5] + postequil*(lbbdforce[5]+lboscilforce[5]*freq));
        force[3] =  0.0;
        force[4] =  0.0;
        force[5] =  0.0;
      }
      else {
        if(interact>9 && interact<20) {
          fD3CECCFracSite(frac, tpos1);
          for(int i=0; i<lbsy.nf; i++) {
            force[3*i  ] =  frac[i] * lbinterforce[tpos*3  ] + lbheatforce[tpos*3*lbsy.nf+3*i  ] + postequil * (lbbdforce[3*i  ]+lboscilforce[3*i  ]*freq);
            force[3*i+1] = -frac[i] * lbinterforce[tpos*3+1] - lbheatforce[tpos*3*lbsy.nf+3*i+1] - postequil * (lbbdforce[3*i+1]+lboscilforce[3*i+1]*freq);
            force[3*i+2] =  frac[i] * lbinterforce[tpos*3+2] + lbheatforce[tpos*3*lbsy.nf+3*i+2] + postequil * (lbbdforce[3*i+2]+lboscilforce[3*i+2]*freq);
          }
        }
        else {
          for(int i=0; i<lbsy.nf; i++) {
            force[3*i  ] =  lbinterforce[tpos*3*lbsy.nf+3*i  ] + lbheatforce[tpos*3*lbsy.nf+3*i  ] + postequil * (lbbdforce[3*i  ]+lboscilforce[3*i  ]*freq);
            force[3*i+1] = -lbinterforce[tpos*3*lbsy.nf+3*i+1] - lbheatforce[tpos*3*lbsy.nf+3*i+1] - postequil * (lbbdforce[3*i+1]+lboscilforce[3*i+1]*freq);
            force[3*i+2] =  lbinterforce[tpos*3*lbsy.nf+3*i+2] + lbheatforce[tpos*3*lbsy.nf+3*i+2] + postequil * (lbbdforce[3*i+2]+lboscilforce[3*i+2]*freq);
          }
        }
      }
      break;
    case CETL:
      if(interact==20 && lbsy.nf>1) {
        phi = fD3CECCSwiftPhi(tpos1, dx, dy, dz, lbft[4*lbsy.nf*tpos+4], lbft[4*lbsy.nf*tpos+5], lbft[4*lbsy.nf*tpos+6]);
        force[1] = -0.5*(1.0+phi)*(lbinterforce[tpos*3*lbsy.nf  ] + lbheatforce[tpos*3*lbsy.nf  ] + postequil*(lbbdforce[0]+lboscilforce[0]*freq))
                 -  0.5*(1.0-phi)*(lbinterforce[tpos*3*lbsy.nf+3] + lbheatforce[tpos*3*lbsy.nf+3] + postequil*(lbbdforce[3]+lboscilforce[3]*freq));
        force[0] =  0.5*(1.0+phi)*(lbinterforce[tpos*3*lbsy.nf+1] + lbheatforce[tpos*3*lbsy.nf+1] + postequil*(lbbdforce[1]+lboscilforce[1]*freq))
                 +  0.5*(1.0-phi)*(lbinterforce[tpos*3*lbsy.nf+4] + lbheatforce[tpos*3*lbsy.nf+4] + postequil*(lbbdforce[4]+lboscilforce[4]*freq));
        force[2] =  0.5*(1.0+phi)*(lbinterforce[tpos*3*lbsy.nf+2] + lbheatforce[tpos*3*lbsy.nf+2] + postequil*(lbbdforce[2]+lboscilforce[2]*freq))
                 +  0.5*(1.0-phi)*(lbinterforce[tpos*3*lbsy.nf+5] + lbheatforce[tpos*3*lbsy.nf+5] + postequil*(lbbdforce[5]+lboscilforce[5]*freq));
        force[3] =  0.0;
        force[4] =  0.0;
        force[5] =  0.0;
      }
      else {
        if(interact>9 && interact<20) {
          fD3CECCFracSite(frac, tpos1);
          for(int i=0; i<lbsy.nf; i++) {
            force[3*i+1] = -frac[i] * lbinterforce[tpos*3  ] - lbheatforce[tpos*3*lbsy.nf+3*i  ] - postequil * (lbbdforce[3*i  ]+lboscilforce[3*i  ]*freq);
            force[3*i  ] =  frac[i] * lbinterforce[tpos*3+1] + lbheatforce[tpos*3*lbsy.nf+3*i+1] + postequil * (lbbdforce[3*i+1]+lboscilforce[3*i+1]*freq);
            force[3*i+2] =  frac[i] * lbinterforce[tpos*3+2] + lbheatforce[tpos*3*lbsy.nf+3*i+2] + postequil * (lbbdforce[3*i+2]+lboscilforce[3*i+2]*freq);
          }
        }
        else {
          for(int i=0; i<lbsy.nf; i++) {
            force[3*i+1] = -lbinterforce[tpos*3*lbsy.nf+3*i  ] - lbheatforce[tpos*3*lbsy.nf+3*i  ] - postequil * (lbbdforce[3*i  ]+lboscilforce[3*i  ]*freq);
            force[3*i  ] =  lbinterforce[tpos*3*lbsy.nf+3*i+1] + lbheatforce[tpos*3*lbsy.nf+3*i+1] + postequil * (lbbdforce[3*i+1]+lboscilforce[3*i+1]*freq);
            force[3*i+2] =  lbinterforce[tpos*3*lbsy.nf+3*i+2] + lbheatforce[tpos*3*lbsy.nf+3*i+2] + postequil * (lbbdforce[3*i+2]+lboscilforce[3*i+2]*freq);
          }
        }
      }
      break;
    case CEDR:
      if(interact==20 && lbsy.nf>1) {
        phi = fD3CECCSwiftPhi(tpos1, dx, dy, dz, lbft[4*lbsy.nf*tpos+4], lbft[4*lbsy.nf*tpos+5], lbft[4*lbsy.nf*tpos+6]);
        force[1] =  0.5*(1.0+phi)*(lbinterforce[tpos*3*lbsy.nf  ] + lbheatforce[tpos*3*lbsy.nf  ] + postequil*(lbbdforce[0]+lboscilforce[0]*freq))
                 +  0.5*(1.0-phi)*(lbinterforce[tpos*3*lbsy.nf+3] + lbheatforce[tpos*3*lbsy.nf+3] + postequil*(lbbdforce[3]+lboscilforce[3]*freq));
        force[0] = -0.5*(1.0+phi)*(lbinterforce[tpos*3*lbsy.nf+1] + lbheatforce[tpos*3*lbsy.nf+1] + postequil*(lbbdforce[1]+lboscilforce[1]*freq))
                 -  0.5*(1.0-phi)*(lbinterforce[tpos*3*lbsy.nf+4] + lbheatforce[tpos*3*lbsy.nf+4] + postequil*(lbbdforce[4]+lboscilforce[4]*freq));
        force[2] =  0.5*(1.0+phi)*(lbinterforce[tpos*3*lbsy.nf+2] + lbheatforce[tpos*3*lbsy.nf+2] + postequil*(lbbdforce[2]+lboscilforce[2]*freq))
                 +  0.5*(1.0-phi)*(lbinterforce[tpos*3*lbsy.nf+5] + lbheatforce[tpos*3*lbsy.nf+5] + postequil*(lbbdforce[5]+lboscilforce[5]*freq));
        force[3] =  0.0;
        force[4] =  0.0;
        force[5] =  0.0;
      }
      else {
        if(interact>9 && interact<20) {
          fD3CECCFracSite(frac, tpos1);
          for(int i=0; i<lbsy.nf; i++) {
            force[3*i+1] =  frac[i] * lbinterforce[tpos*3  ] + lbheatforce[tpos*3*lbsy.nf+3*i  ] + postequil * (lbbdforce[3*i  ]+lboscilforce[3*i  ]*freq);
            force[3*i  ] = -frac[i] * lbinterforce[tpos*3+1] - lbheatforce[tpos*3*lbsy.nf+3*i+1] - postequil * (lbbdforce[3*i+1]+lboscilforce[3*i+1]*freq);
            force[3*i+2] =  frac[i] * lbinterforce[tpos*3+2] + lbheatforce[tpos*3*lbsy.nf+3*i+2] + postequil * (lbbdforce[3*i+2]+lboscilforce[3*i+2]*freq);
          }
        }
        else {
          for(int i=0; i<lbsy.nf; i++) {
            force[3*i+1] =  lbinterforce[tpos*3*lbsy.nf+3*i  ] + lbheatforce[tpos*3*lbsy.nf+3*i  ] + postequil * (lbbdforce[3*i  ]+lboscilforce[3*i  ]*freq);
            force[3*i  ] = -lbinterforce[tpos*3*lbsy.nf+3*i+1] - lbheatforce[tpos*3*lbsy.nf+3*i+1] - postequil * (lbbdforce[3*i+1]+lboscilforce[3*i+1]*freq);
            force[3*i+2] =  lbinterforce[tpos*3*lbsy.nf+3*i+2] + lbheatforce[tpos*3*lbsy.nf+3*i+2] + postequil * (lbbdforce[3*i+2]+lboscilforce[3*i+2]*freq);
          }
        }
      }
      break;
    case CETF:
      if(interact==20 && lbsy.nf>1) {
        phi = fD3CECCSwiftPhi(tpos1, dx, dy, dz, lbft[4*lbsy.nf*tpos+4], lbft[4*lbsy.nf*tpos+5], lbft[4*lbsy.nf*tpos+6]);
        force[2] = 0.5*(1.0+phi)*(lbinterforce[tpos*3*lbsy.nf  ] + lbheatforce[tpos*3*lbsy.nf  ] + postequil*(lbbdforce[0]+lboscilforce[0]*freq))
                 + 0.5*(1.0-phi)*(lbinterforce[tpos*3*lbsy.nf+3] + lbheatforce[tpos*3*lbsy.nf+3] + postequil*(lbbdforce[3]+lboscilforce[3]*freq));
        force[0] = 0.5*(1.0+phi)*(lbinterforce[tpos*3*lbsy.nf+1] + lbheatforce[tpos*3*lbsy.nf+1] + postequil*(lbbdforce[1]+lboscilforce[1]*freq))
                 + 0.5*(1.0-phi)*(lbinterforce[tpos*3*lbsy.nf+4] + lbheatforce[tpos*3*lbsy.nf+4] + postequil*(lbbdforce[4]+lboscilforce[4]*freq));
        force[1] = 0.5*(1.0+phi)*(lbinterforce[tpos*3*lbsy.nf+2] + lbheatforce[tpos*3*lbsy.nf+2] + postequil*(lbbdforce[2]+lboscilforce[2]*freq))
                 + 0.5*(1.0-phi)*(lbinterforce[tpos*3*lbsy.nf+5] + lbheatforce[tpos*3*lbsy.nf+5] + postequil*(lbbdforce[5]+lboscilforce[5]*freq));
        force[3] = 0.0;
        force[4] = 0.0;
        force[5] = 0.0;
      }
      else {
        if(interact>9 && interact<20) {
          fD3CECCFracSite(frac, tpos1);
          for(int i=0; i<lbsy.nf; i++) {
            force[3*i+2] = frac[i] * lbinterforce[tpos*3  ] + lbheatforce[tpos*3*lbsy.nf+3*i  ] + postequil * (lbbdforce[3*i  ]+lboscilforce[3*i  ]*freq);
            force[3*i  ] = frac[i] * lbinterforce[tpos*3+1] + lbheatforce[tpos*3*lbsy.nf+3*i+1] + postequil * (lbbdforce[3*i+1]+lboscilforce[3*i+1]*freq);
            force[3*i+1] = frac[i] * lbinterforce[tpos*3+2] + lbheatforce[tpos*3*lbsy.nf+3*i+2] + postequil * (lbbdforce[3*i+2]+lboscilforce[3*i+2]*freq);
          }
        }
        else {
          for(int i=0; i<lbsy.nf; i++) {
            force[3*i+2] = lbinterforce[tpos*3*lbsy.nf+3*i  ] + lbheatforce[tpos*3*lbsy.nf+3*i  ] + postequil * (lbbdforce[3*i  ]+lboscilforce[3*i  ]*freq);
            force[3*i  ] = lbinterforce[tpos*3*lbsy.nf+3*i+1] + lbheatforce[tpos*3*lbsy.nf+3*i+1] + postequil * (lbbdforce[3*i+1]+lboscilforce[3*i+1]*freq);
            force[3*i+1] = lbinterforce[tpos*3*lbsy.nf+3*i+2] + lbheatforce[tpos*3*lbsy.nf+3*i+2] + postequil * (lbbdforce[3*i+2]+lboscilforce[3*i+2]*freq);
          }
        }
      }
      break;
    case CELF:
      if(interact==20 && lbsy.nf>1) {
        phi = fD3CECCSwiftPhi(tpos1, dx, dy, dz, lbft[4*lbsy.nf*tpos+4], lbft[4*lbsy.nf*tpos+5], lbft[4*lbsy.nf*tpos+6]);
        force[0] = -0.5*(1.0+phi)*(lbinterforce[tpos*3*lbsy.nf  ] + lbheatforce[tpos*3*lbsy.nf  ] + postequil*(lbbdforce[0]+lboscilforce[0]*freq))
                 -  0.5*(1.0-phi)*(lbinterforce[tpos*3*lbsy.nf+3] + lbheatforce[tpos*3*lbsy.nf+3] + postequil*(lbbdforce[3]+lboscilforce[3]*freq));
        force[2] =  0.5*(1.0+phi)*(lbinterforce[tpos*3*lbsy.nf+1] + lbheatforce[tpos*3*lbsy.nf+1] + postequil*(lbbdforce[1]+lboscilforce[1]*freq))
                 +  0.5*(1.0-phi)*(lbinterforce[tpos*3*lbsy.nf+4] + lbheatforce[tpos*3*lbsy.nf+4] + postequil*(lbbdforce[4]+lboscilforce[4]*freq));
        force[1] =  0.5*(1.0+phi)*(lbinterforce[tpos*3*lbsy.nf+2] + lbheatforce[tpos*3*lbsy.nf+2] + postequil*(lbbdforce[2]+lboscilforce[2]*freq))
                 +  0.5*(1.0-phi)*(lbinterforce[tpos*3*lbsy.nf+5] + lbheatforce[tpos*3*lbsy.nf+5] + postequil*(lbbdforce[5]+lboscilforce[5]*freq));
        force[3] =  0.0;
        force[4] =  0.0;
        force[5] =  0.0;
      }
      else {
        if(interact>9 && interact<20) {
          fD3CECCFracSite(frac, tpos1);
          for(int i=0; i<lbsy.nf; i++) {
            force[3*i  ] = -frac[i] * lbinterforce[tpos*3  ] - lbheatforce[tpos*3*lbsy.nf+3*i  ] - postequil * (lbbdforce[3*i  ]+lboscilforce[3*i  ]*freq);
            force[3*i+2] =  frac[i] * lbinterforce[tpos*3+1] + lbheatforce[tpos*3*lbsy.nf+3*i+1] + postequil * (lbbdforce[3*i+1]+lboscilforce[3*i+1]*freq);
            force[3*i+1] =  frac[i] * lbinterforce[tpos*3+2] + lbheatforce[tpos*3*lbsy.nf+3*i+2] + postequil * (lbbdforce[3*i+2]+lboscilforce[3*i+2]*freq);
          }
        }
        else {
          for(int i=0; i<lbsy.nf; i++) {
            force[3*i  ] = -lbinterforce[tpos*3*lbsy.nf+3*i  ] - lbheatforce[tpos*3*lbsy.nf+3*i  ] - postequil * (lbbdforce[3*i  ]+lboscilforce[3*i  ]*freq);
            force[3*i+2] =  lbinterforce[tpos*3*lbsy.nf+3*i+1] + lbheatforce[tpos*3*lbsy.nf+3*i+1] + postequil * (lbbdforce[3*i+1]+lboscilforce[3*i+1]*freq);
            force[3*i+1] =  lbinterforce[tpos*3*lbsy.nf+3*i+2] + lbheatforce[tpos*3*lbsy.nf+3*i+2] + postequil * (lbbdforce[3*i+2]+lboscilforce[3*i+2]*freq);
          }
        }
      }
      break;
    case CEDF:
      if(interact==20 && lbsy.nf>1) {
        phi = fD3CECCSwiftPhi(tpos1, dx, dy, dz, lbft[4*lbsy.nf*tpos+4], lbft[4*lbsy.nf*tpos+5], lbft[4*lbsy.nf*tpos+6]);
        force[2] =  0.5*(1.0+phi)*(lbinterforce[tpos*3*lbsy.nf  ] + lbheatforce[tpos*3*lbsy.nf  ] + postequil*(lbbdforce[0]+lboscilforce[0]*freq))
                 +  0.5*(1.0-phi)*(lbinterforce[tpos*3*lbsy.nf+3] + lbheatforce[tpos*3*lbsy.nf+3] + postequil*(lbbdforce[3]+lboscilforce[3]*freq));
        force[0] = -0.5*(1.0+phi)*(lbinterforce[tpos*3*lbsy.nf+1] + lbheatforce[tpos*3*lbsy.nf+1] + postequil*(lbbdforce[1]+lboscilforce[1]*freq))
                 -  0.5*(1.0-phi)*(lbinterforce[tpos*3*lbsy.nf+4] + lbheatforce[tpos*3*lbsy.nf+4] + postequil*(lbbdforce[4]+lboscilforce[4]*freq));
        force[1] =  0.5*(1.0+phi)*(lbinterforce[tpos*3*lbsy.nf+2] + lbheatforce[tpos*3*lbsy.nf+2] + postequil*(lbbdforce[2]+lboscilforce[2]*freq))
                 +  0.5*(1.0-phi)*(lbinterforce[tpos*3*lbsy.nf+5] + lbheatforce[tpos*3*lbsy.nf+5] + postequil*(lbbdforce[5]+lboscilforce[5]*freq));
        force[3] =  0.0;
        force[4] =  0.0;
        force[5] =  0.0;
      }
      else {
        if(interact>9 && interact<20) {
          fD3CECCFracSite(frac, tpos1);
          for(int i=0; i<lbsy.nf; i++) {
            force[3*i+2] =  frac[i] * lbinterforce[tpos*3  ] + lbheatforce[tpos*3*lbsy.nf+3*i  ] + postequil * (lbbdforce[3*i  ]+lboscilforce[3*i  ]*freq);
            force[3*i  ] = -frac[i] * lbinterforce[tpos*3+1] - lbheatforce[tpos*3*lbsy.nf+3*i+1] - postequil * (lbbdforce[3*i+1]+lboscilforce[3*i+1]*freq);
            force[3*i+1] =  frac[i] * lbinterforce[tpos*3+2] + lbheatforce[tpos*3*lbsy.nf+3*i+2] + postequil * (lbbdforce[3*i+2]+lboscilforce[3*i+2]*freq);
          }
        }
        else {
          for(int i=0; i<lbsy.nf; i++) {
            force[3*i+2] =  lbinterforce[tpos*3*lbsy.nf+3*i  ] + lbheatforce[tpos*3*lbsy.nf+3*i  ] + postequil * (lbbdforce[3*i  ]+lboscilforce[3*i  ]*freq);
            force[3*i  ] = -lbinterforce[tpos*3*lbsy.nf+3*i+1] - lbheatforce[tpos*3*lbsy.nf+3*i+1] - postequil * (lbbdforce[3*i+1]+lboscilforce[3*i+1]*freq);
            force[3*i+1] =  lbinterforce[tpos*3*lbsy.nf+3*i+2] + lbheatforce[tpos*3*lbsy.nf+3*i+2] + postequil * (lbbdforce[3*i+2]+lboscilforce[3*i+2]*freq);
          }
        }
      }
      break;
    case CERF:
      if(interact==20 && lbsy.nf>1) {
        phi = fD3CECCSwiftPhi(tpos1, dx, dy, dz, lbft[4*lbsy.nf*tpos+4], lbft[4*lbsy.nf*tpos+5], lbft[4*lbsy.nf*tpos+6]);
        force[0] = 0.5*(1.0+phi)*(lbinterforce[tpos*3*lbsy.nf  ] + lbheatforce[tpos*3*lbsy.nf  ] + postequil*(lbbdforce[0]+lboscilforce[0]*freq))
                 + 0.5*(1.0-phi)*(lbinterforce[tpos*3*lbsy.nf+3] + lbheatforce[tpos*3*lbsy.nf+3] + postequil*(lbbdforce[3]+lboscilforce[3]*freq));
        force[2] = 0.5*(1.0+phi)*(lbinterforce[tpos*3*lbsy.nf+1] + lbheatforce[tpos*3*lbsy.nf+1] + postequil*(lbbdforce[1]+lboscilforce[1]*freq))
                 + 0.5*(1.0-phi)*(lbinterforce[tpos*3*lbsy.nf+4] + lbheatforce[tpos*3*lbsy.nf+4] + postequil*(lbbdforce[4]+lboscilforce[4]*freq));
        force[1] = 0.5*(1.0+phi)*(lbinterforce[tpos*3*lbsy.nf+2] + lbheatforce[tpos*3*lbsy.nf+2] + postequil*(lbbdforce[2]+lboscilforce[2]*freq))
                 + 0.5*(1.0-phi)*(lbinterforce[tpos*3*lbsy.nf+5] + lbheatforce[tpos*3*lbsy.nf+5] + postequil*(lbbdforce[5]+lboscilforce[5]*freq));
        force[3] = 0.0;
        force[4] = 0.0;
        force[5] = 0.0;
      }
      else {
        if(interact>9 && interact<20) {
          fD3CECCFracSite(frac, tpos1);
          for(int i=0; i<lbsy.nf; i++) {
            force[3*i  ] = frac[i] * lbinterforce[tpos*3  ] + lbheatforce[tpos*3*lbsy.nf+3*i  ] + postequil * (lbbdforce[3*i  ]+lboscilforce[3*i  ]*freq);
            force[3*i+2] = frac[i] * lbinterforce[tpos*3+1] + lbheatforce[tpos*3*lbsy.nf+3*i+1] + postequil * (lbbdforce[3*i+1]+lboscilforce[3*i+1]*freq);
            force[3*i+1] = frac[i] * lbinterforce[tpos*3+2] + lbheatforce[tpos*3*lbsy.nf+3*i+2] + postequil * (lbbdforce[3*i+2]+lboscilforce[3*i+2]*freq);
          }
        }
        else {
          for(int i=0; i<lbsy.nf; i++) {
            force[3*i  ] = lbinterforce[tpos*3*lbsy.nf+3*i  ] + lbheatforce[tpos*3*lbsy.nf+3*i  ] + postequil * (lbbdforce[3*i  ]+lboscilforce[3*i  ]*freq);
            force[3*i+2] = lbinterforce[tpos*3*lbsy.nf+3*i+1] + lbheatforce[tpos*3*lbsy.nf+3*i+1] + postequil * (lbbdforce[3*i+1]+lboscilforce[3*i+1]*freq);
            force[3*i+1] = lbinterforce[tpos*3*lbsy.nf+3*i+2] + lbheatforce[tpos*3*lbsy.nf+3*i+2] + postequil * (lbbdforce[3*i+2]+lboscilforce[3*i+2]*freq);
          }
        }
      }
      break;
    case CETB:
      if(interact==20 && lbsy.nf>1) {
        phi = fD3CECCSwiftPhi(tpos1, dx, dy, dz, lbft[4*lbsy.nf*tpos+4], lbft[4*lbsy.nf*tpos+5], lbft[4*lbsy.nf*tpos+6]);
        force[2] =  0.5*(1.0+phi)*(lbinterforce[tpos*3*lbsy.nf  ] + lbheatforce[tpos*3*lbsy.nf  ] + postequil*(lbbdforce[0]+lboscilforce[0]*freq))
                 +  0.5*(1.0-phi)*(lbinterforce[tpos*3*lbsy.nf+3] + lbheatforce[tpos*3*lbsy.nf+3] + postequil*(lbbdforce[3]+lboscilforce[3]*freq));
        force[0] =  0.5*(1.0+phi)*(lbinterforce[tpos*3*lbsy.nf+1] + lbheatforce[tpos*3*lbsy.nf+1] + postequil*(lbbdforce[1]+lboscilforce[1]*freq))
                 +  0.5*(1.0-phi)*(lbinterforce[tpos*3*lbsy.nf+4] + lbheatforce[tpos*3*lbsy.nf+4] + postequil*(lbbdforce[4]+lboscilforce[4]*freq));
        force[1] = -0.5*(1.0+phi)*(lbinterforce[tpos*3*lbsy.nf+2] + lbheatforce[tpos*3*lbsy.nf+2] + postequil*(lbbdforce[2]+lboscilforce[2]*freq))
                 -  0.5*(1.0-phi)*(lbinterforce[tpos*3*lbsy.nf+5] + lbheatforce[tpos*3*lbsy.nf+5] + postequil*(lbbdforce[5]+lboscilforce[5]*freq));
        force[3] =  0.0;
        force[4] =  0.0;
        force[5] =  0.0;
      }
      else {
        if(interact>9 && interact<20) {
          fD3CECCFracSite(frac, tpos1);
          for(int i=0; i<lbsy.nf; i++) {
            force[3*i+2] =  frac[i] * lbinterforce[tpos*3  ] + lbheatforce[tpos*3*lbsy.nf+3*i  ] + postequil * (lbbdforce[3*i  ]+lboscilforce[3*i  ]*freq);
            force[3*i  ] =  frac[i] * lbinterforce[tpos*3+1] + lbheatforce[tpos*3*lbsy.nf+3*i+1] + postequil * (lbbdforce[3*i+1]+lboscilforce[3*i+1]*freq);
            force[3*i+1] = -frac[i] * lbinterforce[tpos*3+2] - lbheatforce[tpos*3*lbsy.nf+3*i+2] - postequil * (lbbdforce[3*i+2]+lboscilforce[3*i+2]*freq);
          }
        }
        else {
          for(int i=0; i<lbsy.nf; i++) {
            force[3*i+2] =  lbinterforce[tpos*3*lbsy.nf+3*i  ] + lbheatforce[tpos*3*lbsy.nf+3*i  ] + postequil * (lbbdforce[3*i  ]+lboscilforce[3*i  ]*freq);
            force[3*i  ] =  lbinterforce[tpos*3*lbsy.nf+3*i+1] + lbheatforce[tpos*3*lbsy.nf+3*i+1] + postequil * (lbbdforce[3*i+1]+lboscilforce[3*i+1]*freq);
            force[3*i+1] = -lbinterforce[tpos*3*lbsy.nf+3*i+2] - lbheatforce[tpos*3*lbsy.nf+3*i+2] - postequil * (lbbdforce[3*i+2]+lboscilforce[3*i+2]*freq);
          }
        }
      }
      break;
    case CELB:
      if(interact==20 && lbsy.nf>1) {
        phi = fD3CECCSwiftPhi(tpos1, dx, dy, dz, lbft[4*lbsy.nf*tpos+4], lbft[4*lbsy.nf*tpos+5], lbft[4*lbsy.nf*tpos+6]);
        force[0] = -0.5*(1.0+phi)*(lbinterforce[tpos*3*lbsy.nf  ] + lbheatforce[tpos*3*lbsy.nf  ] + postequil*(lbbdforce[0]+lboscilforce[0]*freq))
                 -  0.5*(1.0-phi)*(lbinterforce[tpos*3*lbsy.nf+3] + lbheatforce[tpos*3*lbsy.nf+3] + postequil*(lbbdforce[3]+lboscilforce[3]*freq));
        force[2] =  0.5*(1.0+phi)*(lbinterforce[tpos*3*lbsy.nf+1] + lbheatforce[tpos*3*lbsy.nf+1] + postequil*(lbbdforce[1]+lboscilforce[1]*freq))
                 +  0.5*(1.0-phi)*(lbinterforce[tpos*3*lbsy.nf+4] + lbheatforce[tpos*3*lbsy.nf+4] + postequil*(lbbdforce[4]+lboscilforce[4]*freq));
        force[1] = -0.5*(1.0+phi)*(lbinterforce[tpos*3*lbsy.nf+2] + lbheatforce[tpos*3*lbsy.nf+2] + postequil*(lbbdforce[2]+lboscilforce[2]*freq))
                 -  0.5*(1.0-phi)*(lbinterforce[tpos*3*lbsy.nf+5] + lbheatforce[tpos*3*lbsy.nf+5] + postequil*(lbbdforce[5]+lboscilforce[5]*freq));
        force[3] =  0.0;
        force[4] =  0.0;
        force[5] =  0.0;
      }
      else {
        if(interact>9 && interact<20) {
          fD3CECCFracSite(frac, tpos1);
          for(int i=0; i<lbsy.nf; i++) {
            force[3*i  ] = -frac[i] * lbinterforce[tpos*3  ] - lbheatforce[tpos*3*lbsy.nf+3*i  ] - postequil * (lbbdforce[3*i  ]+lboscilforce[3*i  ]*freq);
            force[3*i+2] =  frac[i] * lbinterforce[tpos*3+1] + lbheatforce[tpos*3*lbsy.nf+3*i+1] + postequil * (lbbdforce[3*i+1]+lboscilforce[3*i+1]*freq);
            force[3*i+1] = -frac[i] * lbinterforce[tpos*3+2] - lbheatforce[tpos*3*lbsy.nf+3*i+2] - postequil * (lbbdforce[3*i+2]+lboscilforce[3*i+2]*freq);
          }
        }
        else {
          for(int i=0; i<lbsy.nf; i++) {
            force[3*i  ] = -lbinterforce[tpos*3*lbsy.nf+3*i  ] - lbheatforce[tpos*3*lbsy.nf+3*i  ] - postequil * (lbbdforce[3*i  ]+lboscilforce[3*i  ]*freq);
            force[3*i+2] =  lbinterforce[tpos*3*lbsy.nf+3*i+1] + lbheatforce[tpos*3*lbsy.nf+3*i+1] + postequil * (lbbdforce[3*i+1]+lboscilforce[3*i+1]*freq);
            force[3*i+1] = -lbinterforce[tpos*3*lbsy.nf+3*i+2] - lbheatforce[tpos*3*lbsy.nf+3*i+2] - postequil * (lbbdforce[3*i+2]+lboscilforce[3*i+2]*freq);
          }
        }
      }
      break;
    case CEDB:
      if(interact==20 && lbsy.nf>1) {
        phi = fD3CECCSwiftPhi(tpos1, dx, dy, dz, lbft[4*lbsy.nf*tpos+4], lbft[4*lbsy.nf*tpos+5], lbft[4*lbsy.nf*tpos+6]);
        force[2] =  0.5*(1.0+phi)*(lbinterforce[tpos*3*lbsy.nf  ] + lbheatforce[tpos*3*lbsy.nf  ] + postequil*(lbbdforce[0]+lboscilforce[0]*freq))
                 +  0.5*(1.0-phi)*(lbinterforce[tpos*3*lbsy.nf+3] + lbheatforce[tpos*3*lbsy.nf+3] + postequil*(lbbdforce[3]+lboscilforce[3]*freq));
        force[0] = -0.5*(1.0+phi)*(lbinterforce[tpos*3*lbsy.nf+1] + lbheatforce[tpos*3*lbsy.nf+1] + postequil*(lbbdforce[1]+lboscilforce[1]*freq))
                 -  0.5*(1.0-phi)*(lbinterforce[tpos*3*lbsy.nf+4] + lbheatforce[tpos*3*lbsy.nf+4] + postequil*(lbbdforce[4]+lboscilforce[4]*freq));
        force[1] = -0.5*(1.0+phi)*(lbinterforce[tpos*3*lbsy.nf+2] + lbheatforce[tpos*3*lbsy.nf+2] + postequil*(lbbdforce[2]+lboscilforce[2]*freq))
                 -  0.5*(1.0-phi)*(lbinterforce[tpos*3*lbsy.nf+5] + lbheatforce[tpos*3*lbsy.nf+5] + postequil*(lbbdforce[5]+lboscilforce[5]*freq));
        force[3] =  0.0;
        force[4] =  0.0;
        force[5] =  0.0;
      }
      else {
        if(interact>9 && interact<20) {
          fD3CECCFracSite(frac, tpos1);
          for(int i=0; i<lbsy.nf; i++) {
            force[3*i+2] =  frac[i] * lbinterforce[tpos*3  ] + lbheatforce[tpos*3*lbsy.nf+3*i  ] + postequil * (lbbdforce[3*i  ]+lboscilforce[3*i  ]*freq);
            force[3*i  ] = -frac[i] * lbinterforce[tpos*3+1] - lbheatforce[tpos*3*lbsy.nf+3*i+1] - postequil * (lbbdforce[3*i+1]+lboscilforce[3*i+1]*freq);
            force[3*i+1] = -frac[i] * lbinterforce[tpos*3+2] - lbheatforce[tpos*3*lbsy.nf+3*i+2] - postequil * (lbbdforce[3*i+2]+lboscilforce[3*i+2]*freq);
          }
        }
        else {
          for(int i=0; i<lbsy.nf; i++) {
            force[3*i+2] =  lbinterforce[tpos*3*lbsy.nf+3*i  ] + lbheatforce[tpos*3*lbsy.nf+3*i  ] + postequil * (lbbdforce[3*i  ]+lboscilforce[3*i  ]*freq);
            force[3*i  ] = -lbinterforce[tpos*3*lbsy.nf+3*i+1] - lbheatforce[tpos*3*lbsy.nf+3*i+1] - postequil * (lbbdforce[3*i+1]+lboscilforce[3*i+1]*freq);
            force[3*i+1] = -lbinterforce[tpos*3*lbsy.nf+3*i+2] - lbheatforce[tpos*3*lbsy.nf+3*i+2] - postequil * (lbbdforce[3*i+2]+lboscilforce[3*i+2]*freq);
          }
        }
      }
      break;
    case CERB:
      if(interact==20 && lbsy.nf>1) {
        phi = fD3CECCSwiftPhi(tpos1, dx, dy, dz, lbft[4*lbsy.nf*tpos+4], lbft[4*lbsy.nf*tpos+5], lbft[4*lbsy.nf*tpos+6]);
        force[0] =  0.5*(1.0+phi)*(lbinterforce[tpos*3*lbsy.nf  ] + lbheatforce[tpos*3*lbsy.nf  ] + postequil*(lbbdforce[0]+lboscilforce[0]*freq))
                 +  0.5*(1.0-phi)*(lbinterforce[tpos*3*lbsy.nf+3] + lbheatforce[tpos*3*lbsy.nf+3] + postequil*(lbbdforce[3]+lboscilforce[3]*freq));
        force[2] =  0.5*(1.0+phi)*(lbinterforce[tpos*3*lbsy.nf+1] + lbheatforce[tpos*3*lbsy.nf+1] + postequil*(lbbdforce[1]+lboscilforce[1]*freq))
                 +  0.5*(1.0-phi)*(lbinterforce[tpos*3*lbsy.nf+4] + lbheatforce[tpos*3*lbsy.nf+4] + postequil*(lbbdforce[4]+lboscilforce[4]*freq));
        force[1] = -0.5*(1.0+phi)*(lbinterforce[tpos*3*lbsy.nf+2] + lbheatforce[tpos*3*lbsy.nf+2] + postequil*(lbbdforce[2]+lboscilforce[2]*freq))
                 -  0.5*(1.0-phi)*(lbinterforce[tpos*3*lbsy.nf+5] + lbheatforce[tpos*3*lbsy.nf+5] + postequil*(lbbdforce[5]+lboscilforce[5]*freq));
        force[3] =  0.0;
        force[4] =  0.0;
        force[5] =  0.0;
      }
      else {
        if(interact>9 && interact<20) {
          fD3CECCFracSite(frac, tpos1);
          for(int i=0; i<lbsy.nf; i++) {
            force[3*i  ] =  frac[i] * lbinterforce[tpos*3  ] + lbheatforce[tpos*3*lbsy.nf+3*i  ] + postequil * (lbbdforce[3*i  ]+lboscilforce[3*i  ]*freq);
            force[3*i+2] =  frac[i] * lbinterforce[tpos*3+1] + lbheatforce[tpos*3*lbsy.nf+3*i+1] + postequil * (lbbdforce[3*i+1]+lboscilforce[3*i+1]*freq);
            force[3*i+1] = -frac[i] * lbinterforce[tpos*3+2] - lbheatforce[tpos*3*lbsy.nf+3*i+2] - postequil * (lbbdforce[3*i+2]+lboscilforce[3*i+2]*freq);
          }
        }
        else {
          for(int i=0; i<lbsy.nf; i++) {
            force[3*i  ] =  lbinterforce[tpos*3*lbsy.nf+3*i  ] + lbheatforce[tpos*3*lbsy.nf+3*i  ] + postequil * (lbbdforce[3*i  ]+lboscilforce[3*i  ]*freq);
            force[3*i+2] =  lbinterforce[tpos*3*lbsy.nf+3*i+1] + lbheatforce[tpos*3*lbsy.nf+3*i+1] + postequil * (lbbdforce[3*i+1]+lboscilforce[3*i+1]*freq);
            force[3*i+1] = -lbinterforce[tpos*3*lbsy.nf+3*i+2] - lbheatforce[tpos*3*lbsy.nf+3*i+2] - postequil * (lbbdforce[3*i+2]+lboscilforce[3*i+2]*freq);
          }
        }
      }
      break;
  }
  return 0;
}

int fD3Q19BoundaryForceDensity(double *force, long tpos, double *p0, int prop)
{
  // calculate forces required at constant density boundary point for D3Q19 lattice

  double phi, freq = (lbbdforcetyp==1)*sin(lboscilfreq*(lbcurstep-lbequstep));

  switch (prop) {
    case PST:
    case CCTRF:
    case CETR:
      if(interact>9 && interact<20) {
        phi = 0.0;
        for(int i=0; i<lbsy.nf; i++)
          phi += p0[i];
        phi = fReciprocal(phi);
        for(int i=0; i<lbsy.nf; i++) {
          force[3*i  ] = p0[i] * phi * lbinterforce[tpos*3  ] + lbheatforce[tpos*3*lbsy.nf+3*i  ] + postequil * (lbbdforce[3*i  ]+lboscilforce[3*i  ]*freq);
          force[3*i+1] = p0[i] * phi * lbinterforce[tpos*3+1] + lbheatforce[tpos*3*lbsy.nf+3*i+1] + postequil * (lbbdforce[3*i+1]+lboscilforce[3*i+1]*freq);
          force[3*i+2] = p0[i] * phi * lbinterforce[tpos*3+2] + lbheatforce[tpos*3*lbsy.nf+3*i+2] + postequil * (lbbdforce[3*i+2]+lboscilforce[3*i+2]*freq);
        }
      }
      else {
        for(int i=0; i<lbsy.nf; i++) {
          force[3*i  ] = lbinterforce[tpos*3*lbsy.nf+3*i  ] + lbheatforce[tpos*3*lbsy.nf+3*i  ] + postequil * (lbbdforce[3*i  ]+lboscilforce[3*i  ]*freq);
          force[3*i+1] = lbinterforce[tpos*3*lbsy.nf+3*i+1] + lbheatforce[tpos*3*lbsy.nf+3*i+1] + postequil * (lbbdforce[3*i+1]+lboscilforce[3*i+1]*freq);
          force[3*i+2] = lbinterforce[tpos*3*lbsy.nf+3*i+2] + lbheatforce[tpos*3*lbsy.nf+3*i+2] + postequil * (lbbdforce[3*i+2]+lboscilforce[3*i+2]*freq);
        }
      }
      break;
    case PSD:
      if(interact>9 && interact<20) {
        phi = 0.0;
        for(int i=0; i<lbsy.nf; i++)
          phi += p0[i];
        phi = fReciprocal(phi);
        for(int i=0; i<lbsy.nf; i++) {
          force[3*i  ] = -p0[i] * phi * lbinterforce[tpos*3  ] - lbheatforce[tpos*3*lbsy.nf+3*i  ] - postequil * (lbbdforce[3*i  ]+lboscilforce[3*i  ]*freq);
          force[3*i+1] = -p0[i] * phi * lbinterforce[tpos*3+1] - lbheatforce[tpos*3*lbsy.nf+3*i+1] - postequil * (lbbdforce[3*i+1]+lboscilforce[3*i+1]*freq);
          force[3*i+2] = -p0[i] * phi * lbinterforce[tpos*3+2] - lbheatforce[tpos*3*lbsy.nf+3*i+2] - postequil * (lbbdforce[3*i+2]+lboscilforce[3*i+2]*freq);
        }
      }
      else {
        for(int i=0; i<lbsy.nf; i++) {
          force[3*i  ] = -lbinterforce[tpos*3*lbsy.nf+3*i  ] - lbheatforce[tpos*3*lbsy.nf+3*i  ] - postequil * (lbbdforce[3*i  ]+lboscilforce[3*i  ]*freq);
          force[3*i+1] = -lbinterforce[tpos*3*lbsy.nf+3*i+1] - lbheatforce[tpos*3*lbsy.nf+3*i+1] - postequil * (lbbdforce[3*i+1]+lboscilforce[3*i+1]*freq);
          force[3*i+2] = -lbinterforce[tpos*3*lbsy.nf+3*i+2] - lbheatforce[tpos*3*lbsy.nf+3*i+2] - postequil * (lbbdforce[3*i+2]+lboscilforce[3*i+2]*freq);
        }
      }
      break;
    case PSL:
      if(interact>9 && interact<20) {
        phi = 0.0;
        for(int i=0; i<lbsy.nf; i++)
          phi += p0[i];
        phi = fReciprocal(phi);
        for(int i=0; i<lbsy.nf; i++) {
          force[3*i+1] = -p0[i] * phi * lbinterforce[tpos*3  ] - lbheatforce[tpos*3*lbsy.nf+3*i  ] - postequil * (lbbdforce[3*i  ]+lboscilforce[3*i  ]*freq);
          force[3*i+2] = -p0[i] * phi * lbinterforce[tpos*3+1] - lbheatforce[tpos*3*lbsy.nf+3*i+1] - postequil * (lbbdforce[3*i+1]+lboscilforce[3*i+1]*freq);
          force[3*i  ] = -p0[i] * phi * lbinterforce[tpos*3+2] - lbheatforce[tpos*3*lbsy.nf+3*i+2] - postequil * (lbbdforce[3*i+2]+lboscilforce[3*i+2]*freq);
        }
      }
      else {
        for(int i=0; i<lbsy.nf; i++) {
          force[3*i+1] = -lbinterforce[tpos*3*lbsy.nf+3*i  ] - lbheatforce[tpos*3*lbsy.nf+3*i  ] - postequil * (lbbdforce[3*i  ]+lboscilforce[3*i  ]*freq);
          force[3*i+2] = -lbinterforce[tpos*3*lbsy.nf+3*i+1] - lbheatforce[tpos*3*lbsy.nf+3*i+1] - postequil * (lbbdforce[3*i+1]+lboscilforce[3*i+1]*freq);
          force[3*i  ] = -lbinterforce[tpos*3*lbsy.nf+3*i+2] - lbheatforce[tpos*3*lbsy.nf+3*i+2] - postequil * (lbbdforce[3*i+2]+lboscilforce[3*i+2]*freq);
        }
      }
      break;
    case PSR:
      if(interact>9 && interact<20) {
        phi = 0.0;
        for(int i=0; i<lbsy.nf; i++)
          phi += p0[i];
        phi = fReciprocal(phi);
        for(int i=0; i<lbsy.nf; i++) {
          force[3*i+1] = p0[i] * phi * lbinterforce[tpos*3  ] + lbheatforce[tpos*3*lbsy.nf+3*i  ] + postequil * (lbbdforce[3*i  ]+lboscilforce[3*i  ]*freq);
          force[3*i+2] = p0[i] * phi * lbinterforce[tpos*3+1] + lbheatforce[tpos*3*lbsy.nf+3*i+1] + postequil * (lbbdforce[3*i+1]+lboscilforce[3*i+1]*freq);
          force[3*i  ] = p0[i] * phi * lbinterforce[tpos*3+2] + lbheatforce[tpos*3*lbsy.nf+3*i+2] + postequil * (lbbdforce[3*i+2]+lboscilforce[3*i+2]*freq);
        }
      }
      else {
        for(int i=0; i<lbsy.nf; i++) {
          force[3*i+1] = lbinterforce[tpos*3*lbsy.nf+3*i  ] + lbheatforce[tpos*3*lbsy.nf+3*i  ] + postequil * (lbbdforce[3*i  ]+lboscilforce[3*i  ]*freq);
          force[3*i+2] = lbinterforce[tpos*3*lbsy.nf+3*i+1] + lbheatforce[tpos*3*lbsy.nf+3*i+1] + postequil * (lbbdforce[3*i+1]+lboscilforce[3*i+1]*freq);
          force[3*i  ] = lbinterforce[tpos*3*lbsy.nf+3*i+2] + lbheatforce[tpos*3*lbsy.nf+3*i+2] + postequil * (lbbdforce[3*i+2]+lboscilforce[3*i+2]*freq);
        }
      }
      break;
    case PSF:
      if(interact>9 && interact<20) {
        phi = 0.0;
        for(int i=0; i<lbsy.nf; i++)
          phi += p0[i];
        phi = fReciprocal(phi);
        for(int i=0; i<lbsy.nf; i++) {
          force[3*i+2] = -p0[i] * phi * lbinterforce[tpos*3  ] - lbheatforce[tpos*3*lbsy.nf+3*i  ] - postequil * (lbbdforce[3*i  ]+lboscilforce[3*i  ]*freq);
          force[3*i  ] = -p0[i] * phi * lbinterforce[tpos*3+1] - lbheatforce[tpos*3*lbsy.nf+3*i+1] - postequil * (lbbdforce[3*i+1]+lboscilforce[3*i+1]*freq);
          force[3*i+1] = -p0[i] * phi * lbinterforce[tpos*3+2] - lbheatforce[tpos*3*lbsy.nf+3*i+2] - postequil * (lbbdforce[3*i+2]+lboscilforce[3*i+2]*freq);
        }
      }
      else {
        for(int i=0; i<lbsy.nf; i++) {
          force[3*i+2] = -lbinterforce[tpos*3*lbsy.nf+3*i  ] - lbheatforce[tpos*3*lbsy.nf+3*i  ] - postequil * (lbbdforce[3*i  ]+lboscilforce[3*i  ]*freq);
          force[3*i  ] = -lbinterforce[tpos*3*lbsy.nf+3*i+1] - lbheatforce[tpos*3*lbsy.nf+3*i+1] - postequil * (lbbdforce[3*i+1]+lboscilforce[3*i+1]*freq);
          force[3*i+1] = -lbinterforce[tpos*3*lbsy.nf+3*i+2] - lbheatforce[tpos*3*lbsy.nf+3*i+2] - postequil * (lbbdforce[3*i+2]+lboscilforce[3*i+2]*freq);
        }
      }
      break;
    case PSB:
      if(interact>9 && interact<20) {
        phi = 0.0;
        for(int i=0; i<lbsy.nf; i++)
          phi += p0[i];
        phi = fReciprocal(phi);
        for(int i=0; i<lbsy.nf; i++) {
          force[3*i+2] = p0[i] * phi * lbinterforce[tpos*3  ] + lbheatforce[tpos*3*lbsy.nf+3*i  ] + postequil * (lbbdforce[3*i  ]+lboscilforce[3*i  ]*freq);
          force[3*i  ] = p0[i] * phi * lbinterforce[tpos*3+1] + lbheatforce[tpos*3*lbsy.nf+3*i+1] + postequil * (lbbdforce[3*i+1]+lboscilforce[3*i+1]*freq);
          force[3*i+1] = p0[i] * phi * lbinterforce[tpos*3+2] + lbheatforce[tpos*3*lbsy.nf+3*i+2] + postequil * (lbbdforce[3*i+2]+lboscilforce[3*i+2]*freq);
        }
      }
      else {
        for(int i=0; i<lbsy.nf; i++) {
          force[3*i+2] = lbinterforce[tpos*3*lbsy.nf+3*i  ] + lbheatforce[tpos*3*lbsy.nf+3*i  ] + postequil * (lbbdforce[3*i  ]+lboscilforce[3*i  ]*freq);
          force[3*i  ] = lbinterforce[tpos*3*lbsy.nf+3*i+1] + lbheatforce[tpos*3*lbsy.nf+3*i+1] + postequil * (lbbdforce[3*i+1]+lboscilforce[3*i+1]*freq);
          force[3*i+1] = lbinterforce[tpos*3*lbsy.nf+3*i+2] + lbheatforce[tpos*3*lbsy.nf+3*i+2] + postequil * (lbbdforce[3*i+2]+lboscilforce[3*i+2]*freq);
        }
      }
      break;
    case CCTRB:
      if(interact>9 && interact<20) {
        phi = 0.0;
        for(int i=0; i<lbsy.nf; i++)
          phi += p0[i];
        phi = fReciprocal(phi);
        for(int i=0; i<lbsy.nf; i++) {
          force[3*i  ] =  p0[i] * phi * lbinterforce[tpos*3  ] + lbheatforce[tpos*3*lbsy.nf+3*i  ] + postequil * (lbbdforce[3*i  ]+lboscilforce[3*i  ]*freq);
          force[3*i+1] =  p0[i] * phi * lbinterforce[tpos*3+1] + lbheatforce[tpos*3*lbsy.nf+3*i+1] + postequil * (lbbdforce[3*i+1]+lboscilforce[3*i+1]*freq);
          force[3*i+2] = -p0[i] * phi * lbinterforce[tpos*3+2] - lbheatforce[tpos*3*lbsy.nf+3*i+2] - postequil * (lbbdforce[3*i+2]+lboscilforce[3*i+2]*freq);
        }
      }
      else {
        for(int i=0; i<lbsy.nf; i++) {
          force[3*i  ] =  lbinterforce[tpos*3*lbsy.nf+3*i  ] + lbheatforce[tpos*3*lbsy.nf+3*i  ] + postequil * (lbbdforce[3*i  ]+lboscilforce[3*i  ]*freq);
          force[3*i+1] =  lbinterforce[tpos*3*lbsy.nf+3*i+1] + lbheatforce[tpos*3*lbsy.nf+3*i+1] + postequil * (lbbdforce[3*i+1]+lboscilforce[3*i+1]*freq);
          force[3*i+2] = -lbinterforce[tpos*3*lbsy.nf+3*i+2] - lbheatforce[tpos*3*lbsy.nf+3*i+2] - postequil * (lbbdforce[3*i+2]+lboscilforce[3*i+2]*freq);
        }
      }
      break;
    case CCTLB:
      if(interact>9 && interact<20) {
        phi = 0.0;
        for(int i=0; i<lbsy.nf; i++)
          phi += p0[i];
        phi = fReciprocal(phi);
        for(int i=0; i<lbsy.nf; i++) {
          force[3*i  ] = -p0[i] * phi * lbinterforce[tpos*3  ] - lbheatforce[tpos*3*lbsy.nf+3*i  ] - postequil * (lbbdforce[3*i  ]+lboscilforce[3*i  ]*freq);
          force[3*i+1] =  p0[i] * phi * lbinterforce[tpos*3+1] + lbheatforce[tpos*3*lbsy.nf+3*i+1] + postequil * (lbbdforce[3*i+1]+lboscilforce[3*i+1]*freq);
          force[3*i+2] = -p0[i] * phi * lbinterforce[tpos*3+2] - lbheatforce[tpos*3*lbsy.nf+3*i+2] - postequil * (lbbdforce[3*i+2]+lboscilforce[3*i+2]*freq);
        }
      }
      else {
        for(int i=0; i<lbsy.nf; i++) {
          force[3*i  ] = -lbinterforce[tpos*3*lbsy.nf+3*i  ] - lbheatforce[tpos*3*lbsy.nf+3*i  ] - postequil * (lbbdforce[3*i  ]+lboscilforce[3*i  ]*freq);
          force[3*i+1] =  lbinterforce[tpos*3*lbsy.nf+3*i+1] + lbheatforce[tpos*3*lbsy.nf+3*i+1] + postequil * (lbbdforce[3*i+1]+lboscilforce[3*i+1]*freq);
          force[3*i+2] = -lbinterforce[tpos*3*lbsy.nf+3*i+2] - lbheatforce[tpos*3*lbsy.nf+3*i+2] - postequil * (lbbdforce[3*i+2]+lboscilforce[3*i+2]*freq);
        }
      }
      break;
    case CCDRB:
      if(interact>9 && interact<20) {
        phi = 0.0;
        for(int i=0; i<lbsy.nf; i++)
          phi += p0[i];
        phi = fReciprocal(phi);
        for(int i=0; i<lbsy.nf; i++) {
          force[3*i  ] =  p0[i] * phi * lbinterforce[tpos*3  ] + lbheatforce[tpos*3*lbsy.nf+3*i  ] + postequil * (lbbdforce[3*i  ]+lboscilforce[3*i  ]*freq);
          force[3*i+1] = -p0[i] * phi * lbinterforce[tpos*3+1] - lbheatforce[tpos*3*lbsy.nf+3*i+1] - postequil * (lbbdforce[3*i+1]+lboscilforce[3*i+1]*freq);
          force[3*i+2] = -p0[i] * phi * lbinterforce[tpos*3+2] - lbheatforce[tpos*3*lbsy.nf+3*i+2] - postequil * (lbbdforce[3*i+2]+lboscilforce[3*i+2]*freq);
        }
      }
      else {
        for(int i=0; i<lbsy.nf; i++) {
          force[3*i  ] =  lbinterforce[tpos*3*lbsy.nf+3*i  ] + lbheatforce[tpos*3*lbsy.nf+3*i  ] + postequil * (lbbdforce[3*i  ]+lboscilforce[3*i  ]*freq);
          force[3*i+1] = -lbinterforce[tpos*3*lbsy.nf+3*i+1] - lbheatforce[tpos*3*lbsy.nf+3*i+1] - postequil * (lbbdforce[3*i+1]+lboscilforce[3*i+1]*freq);
          force[3*i+2] = -lbinterforce[tpos*3*lbsy.nf+3*i+2] - lbheatforce[tpos*3*lbsy.nf+3*i+2] - postequil * (lbbdforce[3*i+2]+lboscilforce[3*i+2]*freq);
        }
      }
      break;
    case CCTLF:
      if(interact>9 && interact<20) {
        phi = 0.0;
        for(int i=0; i<lbsy.nf; i++)
          phi += p0[i];
        phi = fReciprocal(phi);
        for(int i=0; i<lbsy.nf; i++) {
          force[3*i  ] = -p0[i] * phi * lbinterforce[tpos*3  ] - lbheatforce[tpos*3*lbsy.nf+3*i  ] - postequil * (lbbdforce[3*i  ]+lboscilforce[3*i  ]*freq);
          force[3*i+1] =  p0[i] * phi * lbinterforce[tpos*3+1] + lbheatforce[tpos*3*lbsy.nf+3*i+1] + postequil * (lbbdforce[3*i+1]+lboscilforce[3*i+1]*freq);
          force[3*i+2] =  p0[i] * phi * lbinterforce[tpos*3+2] + lbheatforce[tpos*3*lbsy.nf+3*i+2] + postequil * (lbbdforce[3*i+2]+lboscilforce[3*i+2]*freq);
        }
      }
      else {
        for(int i=0; i<lbsy.nf; i++) {
          force[3*i  ] = -lbinterforce[tpos*3*lbsy.nf+3*i  ] - lbheatforce[tpos*3*lbsy.nf+3*i  ] - postequil * (lbbdforce[3*i  ]+lboscilforce[3*i  ]*freq);
          force[3*i+1] =  lbinterforce[tpos*3*lbsy.nf+3*i+1] + lbheatforce[tpos*3*lbsy.nf+3*i+1] + postequil * (lbbdforce[3*i+1]+lboscilforce[3*i+1]*freq);
          force[3*i+2] =  lbinterforce[tpos*3*lbsy.nf+3*i+2] + lbheatforce[tpos*3*lbsy.nf+3*i+2] + postequil * (lbbdforce[3*i+2]+lboscilforce[3*i+2]*freq);
        }
      }
      break;
    case CCDLF:
    case CEDL:
      if(interact>9 && interact<20) {
        phi = 0.0;
        for(int i=0; i<lbsy.nf; i++)
          phi += p0[i];
        phi = fReciprocal(phi);
        for(int i=0; i<lbsy.nf; i++) {
          force[3*i  ] = -p0[i] * phi * lbinterforce[tpos*3  ] - lbheatforce[tpos*3*lbsy.nf+3*i  ] - postequil * (lbbdforce[3*i  ]+lboscilforce[3*i  ]*freq);
          force[3*i+1] = -p0[i] * phi * lbinterforce[tpos*3+1] - lbheatforce[tpos*3*lbsy.nf+3*i+1] - postequil * (lbbdforce[3*i+1]+lboscilforce[3*i+1]*freq);
          force[3*i+2] =  p0[i] * phi * lbinterforce[tpos*3+2] + lbheatforce[tpos*3*lbsy.nf+3*i+2] + postequil * (lbbdforce[3*i+2]+lboscilforce[3*i+2]*freq);
        }
      }
      else {
        for(int i=0; i<lbsy.nf; i++) {
          force[3*i  ] = -lbinterforce[tpos*3*lbsy.nf+3*i  ] - lbheatforce[tpos*3*lbsy.nf+3*i  ] - postequil * (lbbdforce[3*i  ]+lboscilforce[3*i  ]*freq);
          force[3*i+1] = -lbinterforce[tpos*3*lbsy.nf+3*i+1] - lbheatforce[tpos*3*lbsy.nf+3*i+1] - postequil * (lbbdforce[3*i+1]+lboscilforce[3*i+1]*freq);
          force[3*i+2] =  lbinterforce[tpos*3*lbsy.nf+3*i+2] + lbheatforce[tpos*3*lbsy.nf+3*i+2] + postequil * (lbbdforce[3*i+2]+lboscilforce[3*i+2]*freq);
        }
      }
      break;
    case CCDRF:
      if(interact>9 && interact<20) {
        phi = 0.0;
        for(int i=0; i<lbsy.nf; i++)
          phi += p0[i];
        phi = fReciprocal(phi);
        for(int i=0; i<lbsy.nf; i++) {
          force[3*i  ] =  p0[i] * phi * lbinterforce[tpos*3  ] + lbheatforce[tpos*3*lbsy.nf+3*i  ] + postequil * (lbbdforce[3*i  ]+lboscilforce[3*i  ]*freq);
          force[3*i+1] = -p0[i] * phi * lbinterforce[tpos*3+1] - lbheatforce[tpos*3*lbsy.nf+3*i+1] - postequil * (lbbdforce[3*i+1]+lboscilforce[3*i+1]*freq);
          force[3*i+2] =  p0[i] * phi * lbinterforce[tpos*3+2] + lbheatforce[tpos*3*lbsy.nf+3*i+2] + postequil * (lbbdforce[3*i+2]+lboscilforce[3*i+2]*freq);
        }
      }
      else {
        for(int i=0; i<lbsy.nf; i++) {
          force[3*i  ] =  lbinterforce[tpos*3*lbsy.nf+3*i  ] + lbheatforce[tpos*3*lbsy.nf+3*i  ] + postequil * (lbbdforce[3*i  ]+lboscilforce[3*i  ]*freq);
          force[3*i+1] = -lbinterforce[tpos*3*lbsy.nf+3*i+1] - lbheatforce[tpos*3*lbsy.nf+3*i+1] - postequil * (lbbdforce[3*i+1]+lboscilforce[3*i+1]*freq);
          force[3*i+2] =  lbinterforce[tpos*3*lbsy.nf+3*i+2] + lbheatforce[tpos*3*lbsy.nf+3*i+2] + postequil * (lbbdforce[3*i+2]+lboscilforce[3*i+2]*freq);
        }
      }
      break;
    case CETL:
      if(interact>9 && interact<20) {
        phi = 0.0;
        for(int i=0; i<lbsy.nf; i++)
          phi += p0[i];
        phi = fReciprocal(phi);
        for(int i=0; i<lbsy.nf; i++) {
          force[3*i+1] = -p0[i] * phi * lbinterforce[tpos*3  ] - lbheatforce[tpos*3*lbsy.nf+3*i  ] - postequil * (lbbdforce[3*i  ]+lboscilforce[3*i  ]*freq);
          force[3*i  ] =  p0[i] * phi * lbinterforce[tpos*3+1] + lbheatforce[tpos*3*lbsy.nf+3*i+1] + postequil * (lbbdforce[3*i+1]+lboscilforce[3*i+1]*freq);
          force[3*i+2] =  p0[i] * phi * lbinterforce[tpos*3+2] + lbheatforce[tpos*3*lbsy.nf+3*i+2] + postequil * (lbbdforce[3*i+2]+lboscilforce[3*i+2]*freq);
        }
      }
      else {
        for(int i=0; i<lbsy.nf; i++) {
          force[3*i+1] = -lbinterforce[tpos*3*lbsy.nf+3*i  ] - lbheatforce[tpos*3*lbsy.nf+3*i  ] - postequil * (lbbdforce[3*i  ]+lboscilforce[3*i  ]*freq);
          force[3*i  ] =  lbinterforce[tpos*3*lbsy.nf+3*i+1] + lbheatforce[tpos*3*lbsy.nf+3*i+1] + postequil * (lbbdforce[3*i+1]+lboscilforce[3*i+1]*freq);
          force[3*i+2] =  lbinterforce[tpos*3*lbsy.nf+3*i+2] + lbheatforce[tpos*3*lbsy.nf+3*i+2] + postequil * (lbbdforce[3*i+2]+lboscilforce[3*i+2]*freq);
        }
      }
      break;
    case CEDR:
      if(interact>9 && interact<20) {
        phi = 0.0;
        for(int i=0; i<lbsy.nf; i++)
          phi += p0[i];
        phi = fReciprocal(phi);
        for(int i=0; i<lbsy.nf; i++) {
          force[3*i+1] =  p0[i] * phi * lbinterforce[tpos*3  ] + lbheatforce[tpos*3*lbsy.nf+3*i  ] + postequil * (lbbdforce[3*i  ]+lboscilforce[3*i  ]*freq);
          force[3*i  ] = -p0[i] * phi * lbinterforce[tpos*3+1] - lbheatforce[tpos*3*lbsy.nf+3*i+1] - postequil * (lbbdforce[3*i+1]+lboscilforce[3*i+1]*freq);
          force[3*i+2] =  p0[i] * phi * lbinterforce[tpos*3+2] + lbheatforce[tpos*3*lbsy.nf+3*i+2] + postequil * (lbbdforce[3*i+2]+lboscilforce[3*i+2]*freq);
        }
      }
      else {
        for(int i=0; i<lbsy.nf; i++) {
          force[3*i+1] =  lbinterforce[tpos*3*lbsy.nf+3*i  ] + lbheatforce[tpos*3*lbsy.nf+3*i  ] + postequil * (lbbdforce[3*i  ]+lboscilforce[3*i  ]*freq);
          force[3*i  ] = -lbinterforce[tpos*3*lbsy.nf+3*i+1] - lbheatforce[tpos*3*lbsy.nf+3*i+1] - postequil * (lbbdforce[3*i+1]+lboscilforce[3*i+1]*freq);
          force[3*i+2] =  lbinterforce[tpos*3*lbsy.nf+3*i+2] + lbheatforce[tpos*3*lbsy.nf+3*i+2] + postequil * (lbbdforce[3*i+2]+lboscilforce[3*i+2]*freq);
        }
      }
      break;
    case CETF:
      if(interact>9 && interact<20) {
        phi = 0.0;
        for(int i=0; i<lbsy.nf; i++)
          phi += p0[i];
        phi = fReciprocal(phi);
        for(int i=0; i<lbsy.nf; i++) {
          force[3*i+2] = p0[i] * phi * lbinterforce[tpos*3  ] + lbheatforce[tpos*3*lbsy.nf+3*i  ] + postequil * (lbbdforce[3*i  ]+lboscilforce[3*i  ]*freq);
          force[3*i  ] = p0[i] * phi * lbinterforce[tpos*3+1] + lbheatforce[tpos*3*lbsy.nf+3*i+1] + postequil * (lbbdforce[3*i+1]+lboscilforce[3*i+1]*freq);
          force[3*i+1] = p0[i] * phi * lbinterforce[tpos*3+2] + lbheatforce[tpos*3*lbsy.nf+3*i+2] + postequil * (lbbdforce[3*i+2]+lboscilforce[3*i+2]*freq);
        }
      }
      else {
        for(int i=0; i<lbsy.nf; i++) {
          force[3*i+2] = lbinterforce[tpos*3*lbsy.nf+3*i  ] + lbheatforce[tpos*3*lbsy.nf+3*i  ] + postequil * (lbbdforce[3*i  ]+lboscilforce[3*i  ]*freq);
          force[3*i  ] = lbinterforce[tpos*3*lbsy.nf+3*i+1] + lbheatforce[tpos*3*lbsy.nf+3*i+1] + postequil * (lbbdforce[3*i+1]+lboscilforce[3*i+1]*freq);
          force[3*i+1] = lbinterforce[tpos*3*lbsy.nf+3*i+2] + lbheatforce[tpos*3*lbsy.nf+3*i+2] + postequil * (lbbdforce[3*i+2]+lboscilforce[3*i+2]*freq);
        }
      }
      break;
    case CELF:
      if(interact>9 && interact<20) {
        phi = 0.0;
        for(int i=0; i<lbsy.nf; i++)
          phi += p0[i];
        phi = fReciprocal(phi);
        for(int i=0; i<lbsy.nf; i++) {
          force[3*i  ] = -p0[i] * phi * lbinterforce[tpos*3  ] - lbheatforce[tpos*3*lbsy.nf+3*i  ] - postequil * (lbbdforce[3*i  ]+lboscilforce[3*i  ]*freq);
          force[3*i+2] =  p0[i] * phi * lbinterforce[tpos*3+1] + lbheatforce[tpos*3*lbsy.nf+3*i+1] + postequil * (lbbdforce[3*i+1]+lboscilforce[3*i+1]*freq);
          force[3*i+1] =  p0[i] * phi * lbinterforce[tpos*3+2] + lbheatforce[tpos*3*lbsy.nf+3*i+2] + postequil * (lbbdforce[3*i+2]+lboscilforce[3*i+2]*freq);
        }
      }
      else {
        for(int i=0; i<lbsy.nf; i++) {
          force[3*i  ] = -lbinterforce[tpos*3*lbsy.nf+3*i  ] - lbheatforce[tpos*3*lbsy.nf+3*i  ] - postequil * (lbbdforce[3*i  ]+lboscilforce[3*i  ]*freq);
          force[3*i+2] =  lbinterforce[tpos*3*lbsy.nf+3*i+1] + lbheatforce[tpos*3*lbsy.nf+3*i+1] + postequil * (lbbdforce[3*i+1]+lboscilforce[3*i+1]*freq);
          force[3*i+1] =  lbinterforce[tpos*3*lbsy.nf+3*i+2] + lbheatforce[tpos*3*lbsy.nf+3*i+2] + postequil * (lbbdforce[3*i+2]+lboscilforce[3*i+2]*freq);
        }
      }
      break;
    case CEDF:
      if(interact>9 && interact<20) {
        phi = 0.0;
        for(int i=0; i<lbsy.nf; i++)
          phi += p0[i];
        phi = fReciprocal(phi);
        for(int i=0; i<lbsy.nf; i++) {
          force[3*i+2] =  p0[i] * phi * lbinterforce[tpos*3  ] + lbheatforce[tpos*3*lbsy.nf+3*i  ] + postequil * (lbbdforce[3*i  ]+lboscilforce[3*i  ]*freq);
          force[3*i  ] = -p0[i] * phi * lbinterforce[tpos*3+1] - lbheatforce[tpos*3*lbsy.nf+3*i+1] - postequil * (lbbdforce[3*i+1]+lboscilforce[3*i+1]*freq);
          force[3*i+1] =  p0[i] * phi * lbinterforce[tpos*3+2] + lbheatforce[tpos*3*lbsy.nf+3*i+2] + postequil * (lbbdforce[3*i+2]+lboscilforce[3*i+2]*freq);
        }
      }
      else {
        for(int i=0; i<lbsy.nf; i++) {
          force[3*i+2] =  lbinterforce[tpos*3*lbsy.nf+3*i  ] + lbheatforce[tpos*3*lbsy.nf+3*i  ] + postequil * (lbbdforce[3*i  ]+lboscilforce[3*i  ]*freq);
          force[3*i  ] = -lbinterforce[tpos*3*lbsy.nf+3*i+1] - lbheatforce[tpos*3*lbsy.nf+3*i+1] - postequil * (lbbdforce[3*i+1]+lboscilforce[3*i+1]*freq);
          force[3*i+1] =  lbinterforce[tpos*3*lbsy.nf+3*i+2] + lbheatforce[tpos*3*lbsy.nf+3*i+2] + postequil * (lbbdforce[3*i+2]+lboscilforce[3*i+2]*freq);
        }
      }
      break;
    case CERF:
      if(interact>9 && interact<20) {
        phi = 0.0;
        for(int i=0; i<lbsy.nf; i++)
          phi += p0[i];
        phi = fReciprocal(phi);
        for(int i=0; i<lbsy.nf; i++) {
          force[3*i  ] = p0[i] * phi * lbinterforce[tpos*3  ] + lbheatforce[tpos*3*lbsy.nf+3*i  ] + postequil * (lbbdforce[3*i  ]+lboscilforce[3*i  ]*freq);
          force[3*i+2] = p0[i] * phi * lbinterforce[tpos*3+1] + lbheatforce[tpos*3*lbsy.nf+3*i+1] + postequil * (lbbdforce[3*i+1]+lboscilforce[3*i+1]*freq);
          force[3*i+1] = p0[i] * phi * lbinterforce[tpos*3+2] + lbheatforce[tpos*3*lbsy.nf+3*i+2] + postequil * (lbbdforce[3*i+2]+lboscilforce[3*i+2]*freq);
        }
      }
      else {
        for(int i=0; i<lbsy.nf; i++) {
          force[3*i  ] = lbinterforce[tpos*3*lbsy.nf+3*i  ] + lbheatforce[tpos*3*lbsy.nf+3*i  ] + postequil * (lbbdforce[3*i  ]+lboscilforce[3*i  ]*freq);
          force[3*i+2] = lbinterforce[tpos*3*lbsy.nf+3*i+1] + lbheatforce[tpos*3*lbsy.nf+3*i+1] + postequil * (lbbdforce[3*i+1]+lboscilforce[3*i+1]*freq);
          force[3*i+1] = lbinterforce[tpos*3*lbsy.nf+3*i+2] + lbheatforce[tpos*3*lbsy.nf+3*i+2] + postequil * (lbbdforce[3*i+2]+lboscilforce[3*i+2]*freq);
        }
      }
      break;
    case CETB:
      if(interact>9 && interact<20) {
        phi = 0.0;
        for(int i=0; i<lbsy.nf; i++)
          phi += p0[i];
        phi = fReciprocal(phi);
        for(int i=0; i<lbsy.nf; i++) {
          force[3*i+2] =  p0[i] * phi * lbinterforce[tpos*3  ] + lbheatforce[tpos*3*lbsy.nf+3*i  ] + postequil * (lbbdforce[3*i  ]+lboscilforce[3*i  ]*freq);
          force[3*i  ] =  p0[i] * phi * lbinterforce[tpos*3+1] + lbheatforce[tpos*3*lbsy.nf+3*i+1] + postequil * (lbbdforce[3*i+1]+lboscilforce[3*i+1]*freq);
          force[3*i+1] = -p0[i] * phi * lbinterforce[tpos*3+2] - lbheatforce[tpos*3*lbsy.nf+3*i+2] - postequil * (lbbdforce[3*i+2]+lboscilforce[3*i+2]*freq);
        }
      }
      else {
        for(int i=0; i<lbsy.nf; i++) {
          force[3*i+2] =  lbinterforce[tpos*3*lbsy.nf+3*i  ] + lbheatforce[tpos*3*lbsy.nf+3*i  ] + postequil * (lbbdforce[3*i  ]+lboscilforce[3*i  ]*freq);
          force[3*i  ] =  lbinterforce[tpos*3*lbsy.nf+3*i+1] + lbheatforce[tpos*3*lbsy.nf+3*i+1] + postequil * (lbbdforce[3*i+1]+lboscilforce[3*i+1]*freq);
          force[3*i+1] = -lbinterforce[tpos*3*lbsy.nf+3*i+2] - lbheatforce[tpos*3*lbsy.nf+3*i+2] - postequil * (lbbdforce[3*i+2]+lboscilforce[3*i+2]*freq);
        }
      }
      break;
    case CELB:
      if(interact>9 && interact<20) {
        phi = 0.0;
        for(int i=0; i<lbsy.nf; i++)
          phi += p0[i];
        phi = fReciprocal(phi);
        for(int i=0; i<lbsy.nf; i++) {
          force[3*i  ] = -p0[i] * phi * lbinterforce[tpos*3  ] - lbheatforce[tpos*3*lbsy.nf+3*i  ] - postequil * (lbbdforce[3*i  ]+lboscilforce[3*i  ]*freq);
          force[3*i+2] =  p0[i] * phi * lbinterforce[tpos*3+1] + lbheatforce[tpos*3*lbsy.nf+3*i+1] + postequil * (lbbdforce[3*i+1]+lboscilforce[3*i+1]*freq);
          force[3*i+1] = -p0[i] * phi * lbinterforce[tpos*3+2] - lbheatforce[tpos*3*lbsy.nf+3*i+2] - postequil * (lbbdforce[3*i+2]+lboscilforce[3*i+2]*freq);
        }
      }
      else {
        for(int i=0; i<lbsy.nf; i++) {
          force[3*i  ] = -lbinterforce[tpos*3*lbsy.nf+3*i  ] - lbheatforce[tpos*3*lbsy.nf+3*i  ] - postequil * (lbbdforce[3*i  ]+lboscilforce[3*i  ]*freq);
          force[3*i+2] =  lbinterforce[tpos*3*lbsy.nf+3*i+1] + lbheatforce[tpos*3*lbsy.nf+3*i+1] + postequil * (lbbdforce[3*i+1]+lboscilforce[3*i+1]*freq);
          force[3*i+1] = -lbinterforce[tpos*3*lbsy.nf+3*i+2] - lbheatforce[tpos*3*lbsy.nf+3*i+2] - postequil * (lbbdforce[3*i+2]+lboscilforce[3*i+2]*freq);
        }
      }
      break;
    case CEDB:
      if(interact>9 && interact<20) {
        phi = 0.0;
        for(int i=0; i<lbsy.nf; i++)
          phi += p0[i];
        phi = fReciprocal(phi);
        for(int i=0; i<lbsy.nf; i++) {
          force[3*i+2] =  p0[i] * phi * lbinterforce[tpos*3  ] + lbheatforce[tpos*3*lbsy.nf+3*i  ] + postequil * (lbbdforce[3*i  ]+lboscilforce[3*i  ]*freq);
          force[3*i  ] = -p0[i] * phi * lbinterforce[tpos*3+1] - lbheatforce[tpos*3*lbsy.nf+3*i+1] - postequil * (lbbdforce[3*i+1]+lboscilforce[3*i+1]*freq);
          force[3*i+1] = -p0[i] * phi * lbinterforce[tpos*3+2] - lbheatforce[tpos*3*lbsy.nf+3*i+2] - postequil * (lbbdforce[3*i+2]+lboscilforce[3*i+2]*freq);
        }
      }
      else {
        for(int i=0; i<lbsy.nf; i++) {
          force[3*i+2] =  lbinterforce[tpos*3*lbsy.nf+3*i  ] + lbheatforce[tpos*3*lbsy.nf+3*i  ] + postequil * (lbbdforce[3*i  ]+lboscilforce[3*i  ]*freq);
          force[3*i  ] = -lbinterforce[tpos*3*lbsy.nf+3*i+1] - lbheatforce[tpos*3*lbsy.nf+3*i+1] - postequil * (lbbdforce[3*i+1]+lboscilforce[3*i+1]*freq);
          force[3*i+1] = -lbinterforce[tpos*3*lbsy.nf+3*i+2] - lbheatforce[tpos*3*lbsy.nf+3*i+2] - postequil * (lbbdforce[3*i+2]+lboscilforce[3*i+2]*freq);
        }
      }
      break;
    case CERB:
      if(interact>9 && interact<20) {
        phi = 0.0;
        for(int i=0; i<lbsy.nf; i++)
          phi += p0[i];
        phi = fReciprocal(phi);
        for(int i=0; i<lbsy.nf; i++) {
          force[3*i  ] =  p0[i] * phi * lbinterforce[tpos*3  ] + lbheatforce[tpos*3*lbsy.nf+3*i  ] + postequil * (lbbdforce[3*i  ]+lboscilforce[3*i  ]*freq);
          force[3*i+2] =  p0[i] * phi * lbinterforce[tpos*3+1] + lbheatforce[tpos*3*lbsy.nf+3*i+1] + postequil * (lbbdforce[3*i+1]+lboscilforce[3*i+1]*freq);
          force[3*i+1] = -p0[i] * phi * lbinterforce[tpos*3+2] - lbheatforce[tpos*3*lbsy.nf+3*i+2] - postequil * (lbbdforce[3*i+2]+lboscilforce[3*i+2]*freq);
        }
      }
      else {
        for(int i=0; i<lbsy.nf; i++) {
          force[3*i  ] =  lbinterforce[tpos*3*lbsy.nf+3*i  ] + lbheatforce[tpos*3*lbsy.nf+3*i  ] + postequil * (lbbdforce[3*i  ]+lboscilforce[3*i  ]*freq);
          force[3*i+2] =  lbinterforce[tpos*3*lbsy.nf+3*i+1] + lbheatforce[tpos*3*lbsy.nf+3*i+1] + postequil * (lbbdforce[3*i+1]+lboscilforce[3*i+1]*freq);
          force[3*i+1] = -lbinterforce[tpos*3*lbsy.nf+3*i+2] - lbheatforce[tpos*3*lbsy.nf+3*i+2] - postequil * (lbbdforce[3*i+2]+lboscilforce[3*i+2]*freq);
        }
      }
      break;
  }
  return 0;
}


int fD3Q19OF1(long tpos, int prop)
{
  long tpos1;
  int qdim = lbsy.nf+lbsy.nc+lbsy.nt;
  int l1, l2, l3, l4, l5;

  tpos1 = tpos;
  l1 = 0; l2 = 0; l3 = 0; l4 = 0; l5 = 0;
  switch (prop) {
    case PST:
      tpos1 = fNextStep(0, 1, 0, tpos);
      l1 = 5; l2 = 11; l3 = 13; l4 = 17; l5 = 18;
      break;
    case PSD:
      tpos1 = fNextStep(0, -1, 0, tpos);
      l1 = 2; l2 = 4; l3 = 8; l4 = 9; l5 = 14;
      break;
    case PSL:
      tpos1 = fNextStep(-1, 0, 0, tpos);
      l1 = 1; l2 = 4; l3 = 5; l4 = 6; l5 = 7;
      break;
    case PSR:
      tpos1 = fNextStep(1, 0, 0, tpos);
      l1 = 10; l2 = 13; l3 = 14; l4 = 15; l5 = 16;
      break;
    case PSF:
      tpos1 = fNextStep(0, 0, 1, tpos);
      l1 = 7; l2 = 9; l3 = 12; l4 = 15; l5 = 17;
      break;
    case PSB:
      tpos1 = fNextStep(0, 0, -1, tpos);
      l1 = 3; l2 = 6; l3 = 8; l4 = 16; l5 = 18;
      break;
  }

  for(int i=0; i<qdim; i++) {
    lbf[tpos*lbsitelength+i+l1*qdim] = lbf[tpos1*lbsitelength+i+l1*qdim];
    lbf[tpos*lbsitelength+i+l2*qdim] = lbf[tpos1*lbsitelength+i+l2*qdim];
    lbf[tpos*lbsitelength+i+l3*qdim] = lbf[tpos1*lbsitelength+i+l3*qdim];
    lbf[tpos*lbsitelength+i+l4*qdim] = lbf[tpos1*lbsitelength+i+l4*qdim];
    lbf[tpos*lbsitelength+i+l5*qdim] = lbf[tpos1*lbsitelength+i+l5*qdim];
  }
  return 0;
}

int fD3Q19OF2(long tpos, int prop)
{
  long tpos1, tpos2;
  int qdim = lbsy.nf+lbsy.nc+lbsy.nt;
  int l1, l2, l3, l4, l5;

  tpos1 = tpos; tpos2 = tpos;
  l1 = 0; l2 = 0; l3 = 0; l4 = 0; l5 = 0;
  switch (prop) {
    case PST:
      tpos1 = fNextStep(0, 1, 0, tpos);
      tpos2 = fNextStep(0, 2, 0, tpos);
      l1 = 5; l2 = 11; l3 = 13; l4 = 17; l5 = 18;
      break;
    case PSD:
      tpos1 = fNextStep(0, -1, 0, tpos);
      tpos2 = fNextStep(0, -2, 0, tpos);
      l1 = 2; l2 = 4; l3 = 8; l4 = 9; l5 = 14;
      break;
    case PSL:
      tpos1 = fNextStep(-1, 0, 0, tpos);
      tpos2 = fNextStep(-2, 0, 0, tpos);
      l1 = 1; l2 = 4; l3 = 5; l4 = 6; l5 = 7;
      break;
    case PSR:
      tpos1 = fNextStep(1, 0, 0, tpos);
      tpos2 = fNextStep(2, 0, 0, tpos);
      l1 = 10; l2 = 13; l3 = 14; l4 = 15; l5 = 16;
      break;
    case PSF:
      tpos1 = fNextStep(0, 0, 1, tpos);
      tpos2 = fNextStep(0, 0, 2, tpos);
      l1 = 7; l2 = 9; l3 = 12; l4 = 15; l5 = 17;
      break;
    case PSB:
      tpos1 = fNextStep(0, 0, -1, tpos);
      tpos2 = fNextStep(0, 0, -2, tpos);
      l1 = 3; l2 = 6; l3 = 8; l4 = 16; l5 = 18;
      break;
  }

  for(int i=0; i<qdim; i++) {
    lbf[tpos*lbsitelength+i+l1*qdim] = 2.0*lbf[tpos1*lbsitelength+i+l1*qdim]-lbf[tpos2*lbsitelength+i+l1*qdim];
    lbf[tpos*lbsitelength+i+l2*qdim] = 2.0*lbf[tpos1*lbsitelength+i+l2*qdim]-lbf[tpos2*lbsitelength+i+l2*qdim];
    lbf[tpos*lbsitelength+i+l3*qdim] = 2.0*lbf[tpos1*lbsitelength+i+l3*qdim]-lbf[tpos2*lbsitelength+i+l3*qdim];
    lbf[tpos*lbsitelength+i+l4*qdim] = 2.0*lbf[tpos1*lbsitelength+i+l4*qdim]-lbf[tpos2*lbsitelength+i+l4*qdim];
    lbf[tpos*lbsitelength+i+l5*qdim] = 2.0*lbf[tpos1*lbsitelength+i+l5*qdim]-lbf[tpos2*lbsitelength+i+l5*qdim];
  }
  return 0;
}


// D3Q27

int fD3Q27PSFracSite(double *frac, double vy, double *f0, double *f1, double *f2, double *f3, double *f4, double *f5, double *f6, double *f7, double *f8, double *f9, double *f10, double *f11, double *f12, double *f13, double *f14, double *f15, double *f16, double *f17, double *f18, double *f19, double *f20, double *f21, double *f22, double *f23, double *f24, double *f25, double *f26)
{
  // calculate fluid densities at bottom boundary (PST) for fluids
    
  double invallmass,allmass = 0.0;
    
  for(int i=0; i<lbsy.nf; i++) {
    frac[i] = (f0[i]+f1[i]+f3[i]+f6[i]+f7[i]+f14[i]+f16[i]+f19[i]+f20[i]+2.0*(f2[i]+f4[i]+f8[i]+f9[i]+f10[i]+f11[i]+f18[i]+f25[i]+f26[i]))/(1.0-vy);
    allmass += frac[i];
  }
  invallmass = fReciprocal(allmass);
  for(int i=0; i<lbsy.nf; i++)
    frac[i] *= invallmass;
    
  return 0;
}

int fD3Q27BoundaryForceVelocity(double *force, long tpos, long tpos1, double *uwall, int prop)
{
  // calculate forces required at constant velocity boundary point for D3Q27 lattice

  long spos = tpos * lbsitelength;
  int qdim = lbsy.nf+lbsy.nc+lbsy.nt;
  double frac[lbsy.nf];
  double freq = (lbbdforcetyp==1)*sin(lboscilfreq*(lbcurstep-lbequstep));

  switch (prop) {
    case PST:
      if(interact>9 && interact<20) {
        fD3Q27PSFracSite(frac, uwall[1], &lbf[spos], &lbf[spos+1*qdim], &lbf[spos+2*qdim],
                         &lbf[spos+3*qdim],  &lbf[spos+4*qdim],  &lbf[spos+5*qdim],  &lbf[spos+6*qdim],
                         &lbf[spos+7*qdim],  &lbf[spos+8*qdim],  &lbf[spos+9*qdim],  &lbf[spos+10*qdim],
                         &lbf[spos+11*qdim], &lbf[spos+12*qdim], &lbf[spos+13*qdim], &lbf[spos+14*qdim],
                         &lbf[spos+15*qdim], &lbf[spos+16*qdim], &lbf[spos+17*qdim], &lbf[spos+18*qdim],
                         &lbf[spos+19*qdim], &lbf[spos+20*qdim], &lbf[spos+21*qdim], &lbf[spos+22*qdim],
                         &lbf[spos+23*qdim], &lbf[spos+24*qdim], &lbf[spos+25*qdim], &lbf[spos+26*qdim]);
        for(int i=0; i<lbsy.nf; i++) {
          force[3*i  ] = frac[i] * lbinterforce[tpos*3  ] + lbheatforce[tpos*3*lbsy.nf+3*i  ] + postequil * (lbbdforce[3*i  ]+lboscilforce[3*i  ]*freq);
          force[3*i+1] = frac[i] * lbinterforce[tpos*3+1] + lbheatforce[tpos*3*lbsy.nf+3*i+1] + postequil * (lbbdforce[3*i+1]+lboscilforce[3*i+1]*freq);
          force[3*i+2] = frac[i] * lbinterforce[tpos*3+2] + lbheatforce[tpos*3*lbsy.nf+3*i+2] + postequil * (lbbdforce[3*i+2]+lboscilforce[3*i+2]*freq);
        }
      }
      else {
        for(int i=0; i<lbsy.nf; i++) {
          force[3*i  ] = lbinterforce[tpos*3*lbsy.nf+3*i  ] + lbheatforce[tpos*3*lbsy.nf+3*i  ] + postequil * (lbbdforce[3*i  ]+lboscilforce[3*i  ]*freq);
          force[3*i+1] = lbinterforce[tpos*3*lbsy.nf+3*i+1] + lbheatforce[tpos*3*lbsy.nf+3*i+1] + postequil * (lbbdforce[3*i+1]+lboscilforce[3*i+1]*freq);
          force[3*i+2] = lbinterforce[tpos*3*lbsy.nf+3*i+2] + lbheatforce[tpos*3*lbsy.nf+3*i+2] + postequil * (lbbdforce[3*i+2]+lboscilforce[3*i+2]*freq);
        }
      }
      break;
    case PSD:
      if(interact>9 && interact<20) {
        fD3Q27PSFracSite(frac, -uwall[1], &lbf[spos], &lbf[spos+14*qdim], &lbf[spos+15*qdim],
                         &lbf[spos+16*qdim], &lbf[spos+17*qdim], &lbf[spos+18*qdim], &lbf[spos+19*qdim],
                         &lbf[spos+20*qdim], &lbf[spos+21*qdim], &lbf[spos+22*qdim], &lbf[spos+23*qdim],
                         &lbf[spos+24*qdim], &lbf[spos+25*qdim], &lbf[spos+26*qdim], &lbf[spos+1*qdim],
                         &lbf[spos+2*qdim],  &lbf[spos+3*qdim],  &lbf[spos+4*qdim],  &lbf[spos+5*qdim],
                         &lbf[spos+6*qdim],  &lbf[spos+7*qdim],  &lbf[spos+8*qdim],  &lbf[spos+9*qdim],
                         &lbf[spos+10*qdim], &lbf[spos+11*qdim], &lbf[spos+12*qdim], &lbf[spos+13*qdim]);
        for(int i=0; i<lbsy.nf; i++) {
          force[3*i  ] = -frac[i] * lbinterforce[tpos*3  ] - lbheatforce[tpos*3*lbsy.nf+3*i  ] - postequil * (lbbdforce[3*i  ]+lboscilforce[3*i  ]*freq);
          force[3*i+1] = -frac[i] * lbinterforce[tpos*3+1] - lbheatforce[tpos*3*lbsy.nf+3*i+1] - postequil * (lbbdforce[3*i+1]+lboscilforce[3*i+1]*freq);
          force[3*i+2] = -frac[i] * lbinterforce[tpos*3+2] - lbheatforce[tpos*3*lbsy.nf+3*i+2] - postequil * (lbbdforce[3*i+2]+lboscilforce[3*i+2]*freq);
        }
      }
      else {
        for(int i=0; i<lbsy.nf; i++) {
          force[3*i  ] = -lbinterforce[tpos*3*lbsy.nf+3*i  ] - lbheatforce[tpos*3*lbsy.nf+3*i  ] - postequil * (lbbdforce[3*i  ]+lboscilforce[3*i  ]*freq);
          force[3*i+1] = -lbinterforce[tpos*3*lbsy.nf+3*i+1] - lbheatforce[tpos*3*lbsy.nf+3*i+1] - postequil * (lbbdforce[3*i+1]+lboscilforce[3*i+1]*freq);
          force[3*i+2] = -lbinterforce[tpos*3*lbsy.nf+3*i+2] - lbheatforce[tpos*3*lbsy.nf+3*i+2] - postequil * (lbbdforce[3*i+2]+lboscilforce[3*i+2]*freq);
        }
      }
      break;
    case PSL:
      if(interact>9 && interact<20) {
        fD3Q27PSFracSite(frac, -uwall[0], &lbf[spos], &lbf[spos+16*qdim], &lbf[spos+14*qdim],
                         &lbf[spos+15*qdim], &lbf[spos+19*qdim], &lbf[spos+7*qdim],  &lbf[spos+21*qdim],
                         &lbf[spos+9*qdim],  &lbf[spos+17*qdim], &lbf[spos+18*qdim], &lbf[spos+23*qdim],
                         &lbf[spos+25*qdim], &lbf[spos+13*qdim], &lbf[spos+11*qdim], &lbf[spos+3*qdim],
                         &lbf[spos+1*qdim],  &lbf[spos+2*qdim],  &lbf[spos+6*qdim],  &lbf[spos+20*qdim],
                         &lbf[spos+8*qdim],  &lbf[spos+22*qdim], &lbf[spos+4*qdim],  &lbf[spos+5*qdim],
                         &lbf[spos+10*qdim], &lbf[spos+12*qdim], &lbf[spos+26*qdim], &lbf[spos+24*qdim]);
        for(int i=0; i<lbsy.nf; i++) {
          force[3*i+1] = -frac[i] * lbinterforce[tpos*3  ] - lbheatforce[tpos*3*lbsy.nf+3*i  ] - postequil * (lbbdforce[3*i  ]+lboscilforce[3*i  ]*freq);
          force[3*i+2] = -frac[i] * lbinterforce[tpos*3+1] - lbheatforce[tpos*3*lbsy.nf+3*i+1] - postequil * (lbbdforce[3*i+1]+lboscilforce[3*i+1]*freq);
          force[3*i  ] = -frac[i] * lbinterforce[tpos*3+2] - lbheatforce[tpos*3*lbsy.nf+3*i+2] - postequil * (lbbdforce[3*i+2]+lboscilforce[3*i+2]*freq);
        }
      }
      else {
        for(int i=0; i<lbsy.nf; i++) {
          force[3*i+1] = -lbinterforce[tpos*3*lbsy.nf+3*i  ] - lbheatforce[tpos*3*lbsy.nf+3*i  ] - postequil * (lbbdforce[3*i  ]+lboscilforce[3*i  ]*freq);
          force[3*i+2] = -lbinterforce[tpos*3*lbsy.nf+3*i+1] - lbheatforce[tpos*3*lbsy.nf+3*i+1] - postequil * (lbbdforce[3*i+1]+lboscilforce[3*i+1]*freq);
          force[3*i  ] = -lbinterforce[tpos*3*lbsy.nf+3*i+2] - lbheatforce[tpos*3*lbsy.nf+3*i+2] - postequil * (lbbdforce[3*i+2]+lboscilforce[3*i+2]*freq);
        }
      }
      break;
    case PSR:
      if(interact>9 && interact<20) {
        fD3Q27PSFracSite(frac, uwall[0], &lbf[spos], &lbf[spos+3*qdim], &lbf[spos+1*qdim],
                         &lbf[spos+2*qdim],  &lbf[spos+6*qdim],  &lbf[spos+20*qdim], &lbf[spos+8*qdim],
                         &lbf[spos+22*qdim], &lbf[spos+4*qdim],  &lbf[spos+5*qdim],  &lbf[spos+10*qdim],
                         &lbf[spos+12*qdim], &lbf[spos+26*qdim], &lbf[spos+24*qdim], &lbf[spos+16*qdim],
                         &lbf[spos+14*qdim], &lbf[spos+15*qdim], &lbf[spos+19*qdim], &lbf[spos+7*qdim],
                         &lbf[spos+21*qdim], &lbf[spos+9*qdim],  &lbf[spos+17*qdim], &lbf[spos+18*qdim],
                         &lbf[spos+23*qdim], &lbf[spos+25*qdim], &lbf[spos+13*qdim], &lbf[spos+11*qdim]);
        for(int i=0; i<lbsy.nf; i++) {
          force[3*i+1] = frac[i] * lbinterforce[tpos*3  ] + lbheatforce[tpos*3*lbsy.nf+3*i  ] + postequil * (lbbdforce[3*i  ]+lboscilforce[3*i  ]*freq);
          force[3*i+2] = frac[i] * lbinterforce[tpos*3+1] + lbheatforce[tpos*3*lbsy.nf+3*i+1] + postequil * (lbbdforce[3*i+1]+lboscilforce[3*i+1]*freq);
          force[3*i  ] = frac[i] * lbinterforce[tpos*3+2] + lbheatforce[tpos*3*lbsy.nf+3*i+2] + postequil * (lbbdforce[3*i+2]+lboscilforce[3*i+2]*freq);
        }
      }
      else {
        for(int i=0; i<lbsy.nf; i++) {
          force[3*i+1] = lbinterforce[tpos*3*lbsy.nf+3*i  ] + lbheatforce[tpos*3*lbsy.nf+3*i  ] + postequil * (lbbdforce[3*i  ]+lboscilforce[3*i  ]*freq);
          force[3*i+2] = lbinterforce[tpos*3*lbsy.nf+3*i+1] + lbheatforce[tpos*3*lbsy.nf+3*i+1] + postequil * (lbbdforce[3*i+1]+lboscilforce[3*i+1]*freq);
          force[3*i  ] = lbinterforce[tpos*3*lbsy.nf+3*i+2] + lbheatforce[tpos*3*lbsy.nf+3*i+2] + postequil * (lbbdforce[3*i+2]+lboscilforce[3*i+2]*freq);
        }
      }
      break;
    case PSF:
      if(interact>9 && interact<20) {
        fD3Q27PSFracSite(frac, -uwall[2], &lbf[spos], &lbf[spos+15*qdim], &lbf[spos+16*qdim],
                         &lbf[spos+14*qdim], &lbf[spos+21*qdim], &lbf[spos+22*qdim], &lbf[spos+17*qdim],
                         &lbf[spos+5*qdim],  &lbf[spos+19*qdim], &lbf[spos+7*qdim],  &lbf[spos+23*qdim],
                         &lbf[spos+13*qdim], &lbf[spos+24*qdim], &lbf[spos+12*qdim], &lbf[spos+2*qdim],
                         &lbf[spos+3*qdim],  &lbf[spos+1*qdim],  &lbf[spos+8*qdim],  &lbf[spos+9*qdim],
                         &lbf[spos+4*qdim],  &lbf[spos+18*qdim], &lbf[spos+6*qdim],  &lbf[spos+20*qdim],
                         &lbf[spos+10*qdim], &lbf[spos+26*qdim], &lbf[spos+11*qdim], &lbf[spos+25*qdim]);
        for(int i=0; i<lbsy.nf; i++) {
          force[3*i+2] = -frac[i] * lbinterforce[tpos*3  ] - lbheatforce[tpos*3*lbsy.nf+3*i  ] - postequil * (lbbdforce[3*i  ]+lboscilforce[3*i  ]*freq);
          force[3*i  ] = -frac[i] * lbinterforce[tpos*3+1] - lbheatforce[tpos*3*lbsy.nf+3*i+1] - postequil * (lbbdforce[3*i+1]+lboscilforce[3*i+1]*freq);
          force[3*i+1] = -frac[i] * lbinterforce[tpos*3+2] - lbheatforce[tpos*3*lbsy.nf+3*i+2] - postequil * (lbbdforce[3*i+2]+lboscilforce[3*i+2]*freq);
        }
      }
      else {
        for(int i=0; i<lbsy.nf; i++) {
          force[3*i+2] = -lbinterforce[tpos*3*lbsy.nf+3*i  ] - lbheatforce[tpos*3*lbsy.nf+3*i  ] - postequil * (lbbdforce[3*i  ]+lboscilforce[3*i  ]*freq);
          force[3*i  ] = -lbinterforce[tpos*3*lbsy.nf+3*i+1] - lbheatforce[tpos*3*lbsy.nf+3*i+1] - postequil * (lbbdforce[3*i+1]+lboscilforce[3*i+1]*freq);
          force[3*i+1] = -lbinterforce[tpos*3*lbsy.nf+3*i+2] - lbheatforce[tpos*3*lbsy.nf+3*i+2] - postequil * (lbbdforce[3*i+2]+lboscilforce[3*i+2]*freq);
        }
      }
      break;
    case PSB:
      if(interact>9 && interact<20) {
        fD3Q27PSFracSite(frac, uwall[2], &lbf[spos], &lbf[spos+2*qdim], &lbf[spos+3*qdim],
                         &lbf[spos+1*qdim],  &lbf[spos+8*qdim],  &lbf[spos+9*qdim],  &lbf[spos+4*qdim],
                         &lbf[spos+18*qdim], &lbf[spos+6*qdim],  &lbf[spos+20*qdim], &lbf[spos+10*qdim],
                         &lbf[spos+26*qdim], &lbf[spos+11*qdim], &lbf[spos+25*qdim], &lbf[spos+15*qdim],
                         &lbf[spos+16*qdim], &lbf[spos+14*qdim], &lbf[spos+21*qdim], &lbf[spos+22*qdim],
                         &lbf[spos+17*qdim], &lbf[spos+5*qdim],  &lbf[spos+19*qdim], &lbf[spos+7*qdim],
                         &lbf[spos+23*qdim], &lbf[spos+13*qdim], &lbf[spos+24*qdim], &lbf[spos+12*qdim]);
        for(int i=0; i<lbsy.nf; i++) {
          force[3*i+2] = frac[i] * lbinterforce[tpos*3  ] + lbheatforce[tpos*3*lbsy.nf+3*i  ] + postequil * (lbbdforce[3*i  ]+lboscilforce[3*i  ]*freq);
          force[3*i  ] = frac[i] * lbinterforce[tpos*3+1] + lbheatforce[tpos*3*lbsy.nf+3*i+1] + postequil * (lbbdforce[3*i+1]+lboscilforce[3*i+1]*freq);
          force[3*i+1] = frac[i] * lbinterforce[tpos*3+2] + lbheatforce[tpos*3*lbsy.nf+3*i+2] + postequil * (lbbdforce[3*i+2]+lboscilforce[3*i+2]*freq);
        }
      }
      else {
        for(int i=0; i<lbsy.nf; i++) {
          force[3*i+2] = lbinterforce[tpos*3*lbsy.nf+3*i  ] + lbheatforce[tpos*3*lbsy.nf+3*i  ] + postequil * (lbbdforce[3*i  ]+lboscilforce[3*i  ]*freq);
          force[3*i  ] = lbinterforce[tpos*3*lbsy.nf+3*i+1] + lbheatforce[tpos*3*lbsy.nf+3*i+1] + postequil * (lbbdforce[3*i+1]+lboscilforce[3*i+1]*freq);
          force[3*i+1] = lbinterforce[tpos*3*lbsy.nf+3*i+2] + lbheatforce[tpos*3*lbsy.nf+3*i+2] + postequil * (lbbdforce[3*i+2]+lboscilforce[3*i+2]*freq);
        }
      }
      break;
    case CCTRB:
      if(interact>9 && interact<20) {
        fD3CECCFracSite(frac, tpos1);
        for(int i=0; i<lbsy.nf; i++) {
          force[3*i  ] =  frac[i] * lbinterforce[tpos*3  ] + lbheatforce[tpos*3*lbsy.nf+3*i  ] + postequil * (lbbdforce[3*i  ]+lboscilforce[3*i  ]*freq);
          force[3*i+1] =  frac[i] * lbinterforce[tpos*3+1] + lbheatforce[tpos*3*lbsy.nf+3*i+1] + postequil * (lbbdforce[3*i+1]+lboscilforce[3*i+1]*freq);
          force[3*i+2] = -frac[i] * lbinterforce[tpos*3+2] - lbheatforce[tpos*3*lbsy.nf+3*i+2] - postequil * (lbbdforce[3*i+2]+lboscilforce[3*i+2]*freq);
        }
      }
      else {
        for(int i=0; i<lbsy.nf; i++) {
          force[3*i  ] =  lbinterforce[tpos*3*lbsy.nf+3*i  ] + lbheatforce[tpos*3*lbsy.nf+3*i  ] + postequil * (lbbdforce[3*i  ]+lboscilforce[3*i  ]*freq);
          force[3*i+1] =  lbinterforce[tpos*3*lbsy.nf+3*i+1] + lbheatforce[tpos*3*lbsy.nf+3*i+1] + postequil * (lbbdforce[3*i+1]+lboscilforce[3*i+1]*freq);
          force[3*i+2] = -lbinterforce[tpos*3*lbsy.nf+3*i+2] - lbheatforce[tpos*3*lbsy.nf+3*i+2] - postequil * (lbbdforce[3*i+2]+lboscilforce[3*i+2]*freq);
        }
      }
      break;
    case CCTLB:
      if(interact>9 && interact<20) {
        fD3CECCFracSite(frac, tpos1);
        for(int i=0; i<lbsy.nf; i++) {
          force[3*i  ] = -frac[i] * lbinterforce[tpos*3  ] - lbheatforce[tpos*3*lbsy.nf+3*i  ] - postequil * (lbbdforce[3*i  ]+lboscilforce[3*i  ]*freq);
          force[3*i+1] =  frac[i] * lbinterforce[tpos*3+1] + lbheatforce[tpos*3*lbsy.nf+3*i+1] + postequil * (lbbdforce[3*i+1]+lboscilforce[3*i+1]*freq);
          force[3*i+2] = -frac[i] * lbinterforce[tpos*3+2] - lbheatforce[tpos*3*lbsy.nf+3*i+2] - postequil * (lbbdforce[3*i+2]+lboscilforce[3*i+2]*freq);
        }
      }
      else {
        for(int i=0; i<lbsy.nf; i++) {
          force[3*i  ] = -lbinterforce[tpos*3*lbsy.nf+3*i  ] - lbheatforce[tpos*3*lbsy.nf+3*i  ] - postequil * (lbbdforce[3*i  ]+lboscilforce[3*i  ]*freq);
          force[3*i+1] =  lbinterforce[tpos*3*lbsy.nf+3*i+1] + lbheatforce[tpos*3*lbsy.nf+3*i+1] + postequil * (lbbdforce[3*i+1]+lboscilforce[3*i+1]*freq);
          force[3*i+2] = -lbinterforce[tpos*3*lbsy.nf+3*i+2] - lbheatforce[tpos*3*lbsy.nf+3*i+2] - postequil * (lbbdforce[3*i+2]+lboscilforce[3*i+2]*freq);
        }
      }
      break;
    case CCDLB:
      if(interact>9 && interact<20) {
        fD3CECCFracSite(frac, tpos1);
        for(int i=0; i<lbsy.nf; i++) {
          force[3*i  ] = -frac[i] * lbinterforce[tpos*3  ] - lbheatforce[tpos*3*lbsy.nf+3*i  ] - postequil * (lbbdforce[3*i  ]+lboscilforce[3*i  ]*freq);
          force[3*i+1] = -frac[i] * lbinterforce[tpos*3+1] - lbheatforce[tpos*3*lbsy.nf+3*i+1] - postequil * (lbbdforce[3*i+1]+lboscilforce[3*i+1]*freq);
          force[3*i+2] = -frac[i] * lbinterforce[tpos*3+2] - lbheatforce[tpos*3*lbsy.nf+3*i+2] - postequil * (lbbdforce[3*i+2]+lboscilforce[3*i+2]*freq);
        }
      }
      else {
        for(int i=0; i<lbsy.nf; i++) {
          force[3*i  ] = -lbinterforce[tpos*3*lbsy.nf+3*i  ] - lbheatforce[tpos*3*lbsy.nf+3*i  ] - postequil * (lbbdforce[3*i  ]+lboscilforce[3*i  ]*freq);
          force[3*i+1] = -lbinterforce[tpos*3*lbsy.nf+3*i+1] - lbheatforce[tpos*3*lbsy.nf+3*i+1] - postequil * (lbbdforce[3*i+1]+lboscilforce[3*i+1]*freq);
          force[3*i+2] = -lbinterforce[tpos*3*lbsy.nf+3*i+2] - lbheatforce[tpos*3*lbsy.nf+3*i+2] - postequil * (lbbdforce[3*i+2]+lboscilforce[3*i+2]*freq);
        }
      }
      break;
    case CCDRB:
      if(interact>9 && interact<20) {
        fD3CECCFracSite(frac, tpos1);
        for(int i=0; i<lbsy.nf; i++) {
          force[3*i  ] =  frac[i] * lbinterforce[tpos*3  ] + lbheatforce[tpos*3*lbsy.nf+3*i  ] + postequil * (lbbdforce[3*i  ]+lboscilforce[3*i  ]*freq);
          force[3*i+1] = -frac[i] * lbinterforce[tpos*3+1] - lbheatforce[tpos*3*lbsy.nf+3*i+1] - postequil * (lbbdforce[3*i+1]+lboscilforce[3*i+1]*freq);
          force[3*i+2] = -frac[i] * lbinterforce[tpos*3+2] - lbheatforce[tpos*3*lbsy.nf+3*i+2] - postequil * (lbbdforce[3*i+2]+lboscilforce[3*i+2]*freq);
        }
      }
      else {
        for(int i=0; i<lbsy.nf; i++) {
          force[3*i  ] =  lbinterforce[tpos*3*lbsy.nf+3*i  ] + lbheatforce[tpos*3*lbsy.nf+3*i  ] + postequil * (lbbdforce[3*i  ]+lboscilforce[3*i  ]*freq);
          force[3*i+1] = -lbinterforce[tpos*3*lbsy.nf+3*i+1] - lbheatforce[tpos*3*lbsy.nf+3*i+1] - postequil * (lbbdforce[3*i+1]+lboscilforce[3*i+1]*freq);
          force[3*i+2] = -lbinterforce[tpos*3*lbsy.nf+3*i+2] - lbheatforce[tpos*3*lbsy.nf+3*i+2] - postequil * (lbbdforce[3*i+2]+lboscilforce[3*i+2]*freq);
        }
      }
      break;
    case CCTRF:
    case CETR:
      if(interact>9 && interact<20) {
        fD3CECCFracSite(frac, tpos1);
        for(int i=0; i<lbsy.nf; i++) {
          force[3*i  ] = frac[i] * lbinterforce[tpos*3  ] + lbheatforce[tpos*3*lbsy.nf+3*i  ] + postequil * (lbbdforce[3*i  ]+lboscilforce[3*i  ]*freq);
          force[3*i+1] = frac[i] * lbinterforce[tpos*3+1] + lbheatforce[tpos*3*lbsy.nf+3*i+1] + postequil * (lbbdforce[3*i+1]+lboscilforce[3*i+1]*freq);
          force[3*i+2] = frac[i] * lbinterforce[tpos*3+2] + lbheatforce[tpos*3*lbsy.nf+3*i+2] + postequil * (lbbdforce[3*i+2]+lboscilforce[3*i+2]*freq);
        }
      }
      else {
        for(int i=0; i<lbsy.nf; i++) {
          force[3*i  ] = lbinterforce[tpos*3*lbsy.nf+3*i  ] + lbheatforce[tpos*3*lbsy.nf+3*i  ] + postequil * (lbbdforce[3*i  ]+lboscilforce[3*i  ]*freq);
          force[3*i+1] = lbinterforce[tpos*3*lbsy.nf+3*i+1] + lbheatforce[tpos*3*lbsy.nf+3*i+1] + postequil * (lbbdforce[3*i+1]+lboscilforce[3*i+1]*freq);
          force[3*i+2] = lbinterforce[tpos*3*lbsy.nf+3*i+2] + lbheatforce[tpos*3*lbsy.nf+3*i+2] + postequil * (lbbdforce[3*i+2]+lboscilforce[3*i+2]*freq);
        }
      }
      break;
    case CCTLF:
      if(interact>9 && interact<20) {
        fD3CECCFracSite(frac, tpos1);
        for(int i=0; i<lbsy.nf; i++) {
          force[3*i  ] = -frac[i] * lbinterforce[tpos*3  ] - lbheatforce[tpos*3*lbsy.nf+3*i  ] - postequil * (lbbdforce[3*i  ]+lboscilforce[3*i  ]*freq);
          force[3*i+1] =  frac[i] * lbinterforce[tpos*3+1] + lbheatforce[tpos*3*lbsy.nf+3*i+1] + postequil * (lbbdforce[3*i+1]+lboscilforce[3*i+1]*freq);
          force[3*i+2] =  frac[i] * lbinterforce[tpos*3+2] + lbheatforce[tpos*3*lbsy.nf+3*i+2] + postequil * (lbbdforce[3*i+2]+lboscilforce[3*i+2]*freq);
        }
      }
      else {
        for(int i=0; i<lbsy.nf; i++) {
          force[3*i  ] = -lbinterforce[tpos*3*lbsy.nf+3*i  ] - lbheatforce[tpos*3*lbsy.nf+3*i  ] - postequil * (lbbdforce[3*i  ]+lboscilforce[3*i  ]*freq);
          force[3*i+1] =  lbinterforce[tpos*3*lbsy.nf+3*i+1] + lbheatforce[tpos*3*lbsy.nf+3*i+1] + postequil * (lbbdforce[3*i+1]+lboscilforce[3*i+1]*freq);
          force[3*i+2] =  lbinterforce[tpos*3*lbsy.nf+3*i+2] + lbheatforce[tpos*3*lbsy.nf+3*i+2] + postequil * (lbbdforce[3*i+2]+lboscilforce[3*i+2]*freq);
        }
      }
      break;
    case CCDLF:
    case CEDL:
      if(interact>9 && interact<20) {
        fD3CECCFracSite(frac, tpos1);
        for(int i=0; i<lbsy.nf; i++) {
          force[3*i  ] = -frac[i] * lbinterforce[tpos*3  ] - lbheatforce[tpos*3*lbsy.nf+3*i  ] - postequil * (lbbdforce[3*i  ]+lboscilforce[3*i  ]*freq);
          force[3*i+1] = -frac[i] * lbinterforce[tpos*3+1] - lbheatforce[tpos*3*lbsy.nf+3*i+1] - postequil * (lbbdforce[3*i+1]+lboscilforce[3*i+1]*freq);
          force[3*i+2] =  frac[i] * lbinterforce[tpos*3+2] + lbheatforce[tpos*3*lbsy.nf+3*i+2] + postequil * (lbbdforce[3*i+2]+lboscilforce[3*i+2]*freq);
        }
      }
      else {
        for(int i=0; i<lbsy.nf; i++) {
          force[3*i  ] = -lbinterforce[tpos*3*lbsy.nf+3*i  ] - lbheatforce[tpos*3*lbsy.nf+3*i  ] - postequil * (lbbdforce[3*i  ]+lboscilforce[3*i  ]*freq);
          force[3*i+1] = -lbinterforce[tpos*3*lbsy.nf+3*i+1] - lbheatforce[tpos*3*lbsy.nf+3*i+1] - postequil * (lbbdforce[3*i+1]+lboscilforce[3*i+1]*freq);
          force[3*i+2] =  lbinterforce[tpos*3*lbsy.nf+3*i+2] + lbheatforce[tpos*3*lbsy.nf+3*i+2] + postequil * (lbbdforce[3*i+2]+lboscilforce[3*i+2]*freq);
        }
      }
      break;
    case CCDRF:
      if(interact>9 && interact<20) {
        fD3CECCFracSite(frac, tpos1);
        for(int i=0; i<lbsy.nf; i++) {
          force[3*i  ] =  frac[i] * lbinterforce[tpos*3  ] + lbheatforce[tpos*3*lbsy.nf+3*i  ] + postequil * (lbbdforce[3*i  ]+lboscilforce[3*i  ]*freq);
          force[3*i+1] = -frac[i] * lbinterforce[tpos*3+1] - lbheatforce[tpos*3*lbsy.nf+3*i+1] - postequil * (lbbdforce[3*i+1]+lboscilforce[3*i+1]*freq);
          force[3*i+2] =  frac[i] * lbinterforce[tpos*3+2] + lbheatforce[tpos*3*lbsy.nf+3*i+2] + postequil * (lbbdforce[3*i+2]+lboscilforce[3*i+2]*freq);
        }
      }
      else {
        for(int i=0; i<lbsy.nf; i++) {
          force[3*i  ] =  lbinterforce[tpos*3*lbsy.nf+3*i  ] + lbheatforce[tpos*3*lbsy.nf+3*i  ] + postequil * (lbbdforce[3*i  ]+lboscilforce[3*i  ]*freq);
          force[3*i+1] = -lbinterforce[tpos*3*lbsy.nf+3*i+1] - lbheatforce[tpos*3*lbsy.nf+3*i+1] - postequil * (lbbdforce[3*i+1]+lboscilforce[3*i+1]*freq);
          force[3*i+2] =  lbinterforce[tpos*3*lbsy.nf+3*i+2] + lbheatforce[tpos*3*lbsy.nf+3*i+2] + postequil * (lbbdforce[3*i+2]+lboscilforce[3*i+2]*freq);
        }
      }
      break;
    case CETL:
      if(interact>9 && interact<20) {
        fD3CECCFracSite(frac, tpos1);
        for(int i=0; i<lbsy.nf; i++) {
          force[3*i+1] = -frac[i] * lbinterforce[tpos*3  ] - lbheatforce[tpos*3*lbsy.nf+3*i  ] - postequil * (lbbdforce[3*i  ]+lboscilforce[3*i  ]*freq);
          force[3*i  ] =  frac[i] * lbinterforce[tpos*3+1] + lbheatforce[tpos*3*lbsy.nf+3*i+1] + postequil * (lbbdforce[3*i+1]+lboscilforce[3*i+1]*freq);
          force[3*i+2] =  frac[i] * lbinterforce[tpos*3+2] + lbheatforce[tpos*3*lbsy.nf+3*i+2] + postequil * (lbbdforce[3*i+2]+lboscilforce[3*i+2]*freq);
        }
      }
      else {
        for(int i=0; i<lbsy.nf; i++) {
          force[3*i+1] = -lbinterforce[tpos*3*lbsy.nf+3*i  ] - lbheatforce[tpos*3*lbsy.nf+3*i  ] - postequil * (lbbdforce[3*i  ]+lboscilforce[3*i  ]*freq);
          force[3*i  ] =  lbinterforce[tpos*3*lbsy.nf+3*i+1] + lbheatforce[tpos*3*lbsy.nf+3*i+1] + postequil * (lbbdforce[3*i+1]+lboscilforce[3*i+1]*freq);
          force[3*i+2] =  lbinterforce[tpos*3*lbsy.nf+3*i+2] + lbheatforce[tpos*3*lbsy.nf+3*i+2] + postequil * (lbbdforce[3*i+2]+lboscilforce[3*i+2]*freq);
        }
      }
      break;
    case CEDR:
      if(interact>9 && interact<20) {
        fD3CECCFracSite(frac, tpos1);
        for(int i=0; i<lbsy.nf; i++) {
          force[3*i+1] =  frac[i] * lbinterforce[tpos*3  ] + lbheatforce[tpos*3*lbsy.nf+3*i  ] + postequil * (lbbdforce[3*i  ]+lboscilforce[3*i  ]*freq);
          force[3*i  ] = -frac[i] * lbinterforce[tpos*3+1] - lbheatforce[tpos*3*lbsy.nf+3*i+1] - postequil * (lbbdforce[3*i+1]+lboscilforce[3*i+1]*freq);
          force[3*i+2] =  frac[i] * lbinterforce[tpos*3+2] + lbheatforce[tpos*3*lbsy.nf+3*i+2] + postequil * (lbbdforce[3*i+2]+lboscilforce[3*i+2]*freq);
        }
      }
      else {
        for(int i=0; i<lbsy.nf; i++) {
          force[3*i+1] =  lbinterforce[tpos*3*lbsy.nf+3*i  ] + lbheatforce[tpos*3*lbsy.nf+3*i  ] + postequil * (lbbdforce[3*i  ]+lboscilforce[3*i  ]*freq);
          force[3*i  ] = -lbinterforce[tpos*3*lbsy.nf+3*i+1] - lbheatforce[tpos*3*lbsy.nf+3*i+1] - postequil * (lbbdforce[3*i+1]+lboscilforce[3*i+1]*freq);
          force[3*i+2] =  lbinterforce[tpos*3*lbsy.nf+3*i+2] + lbheatforce[tpos*3*lbsy.nf+3*i+2] + postequil * (lbbdforce[3*i+2]+lboscilforce[3*i+2]*freq);
        }
      }
      break;
    case CETF:
      if(interact>9 && interact<20) {
        fD3CECCFracSite(frac, tpos1);
        for(int i=0; i<lbsy.nf; i++) {
          force[3*i+2] = frac[i] * lbinterforce[tpos*3  ] + lbheatforce[tpos*3*lbsy.nf+3*i  ] + postequil * (lbbdforce[3*i  ]+lboscilforce[3*i  ]*freq);
          force[3*i  ] = frac[i] * lbinterforce[tpos*3+1] + lbheatforce[tpos*3*lbsy.nf+3*i+1] + postequil * (lbbdforce[3*i+1]+lboscilforce[3*i+1]*freq);
          force[3*i+1] = frac[i] * lbinterforce[tpos*3+2] + lbheatforce[tpos*3*lbsy.nf+3*i+2] + postequil * (lbbdforce[3*i+2]+lboscilforce[3*i+2]*freq);
        }
      }
      else {
        for(int i=0; i<lbsy.nf; i++) {
          force[3*i+2] = lbinterforce[tpos*3*lbsy.nf+3*i  ] + lbheatforce[tpos*3*lbsy.nf+3*i  ] + postequil * (lbbdforce[3*i  ]+lboscilforce[3*i  ]*freq);
          force[3*i  ] = lbinterforce[tpos*3*lbsy.nf+3*i+1] + lbheatforce[tpos*3*lbsy.nf+3*i+1] + postequil * (lbbdforce[3*i+1]+lboscilforce[3*i+1]*freq);
          force[3*i+1] = lbinterforce[tpos*3*lbsy.nf+3*i+2] + lbheatforce[tpos*3*lbsy.nf+3*i+2] + postequil * (lbbdforce[3*i+2]+lboscilforce[3*i+2]*freq);
        }
      }
      break;
    case CELF:
      if(interact>9 && interact<20) {
        fD3CECCFracSite(frac, tpos1);
        for(int i=0; i<lbsy.nf; i++) {
          force[3*i  ] = -frac[i] * lbinterforce[tpos*3  ] - lbheatforce[tpos*3*lbsy.nf+3*i  ] - postequil * (lbbdforce[3*i  ]+lboscilforce[3*i  ]*freq);
          force[3*i+2] =  frac[i] * lbinterforce[tpos*3+1] + lbheatforce[tpos*3*lbsy.nf+3*i+1] + postequil * (lbbdforce[3*i+1]+lboscilforce[3*i+1]*freq);
          force[3*i+1] =  frac[i] * lbinterforce[tpos*3+2] + lbheatforce[tpos*3*lbsy.nf+3*i+2] + postequil * (lbbdforce[3*i+2]+lboscilforce[3*i+2]*freq);
        }
      }
      else {
        for(int i=0; i<lbsy.nf; i++) {
          force[3*i  ] = -lbinterforce[tpos*3*lbsy.nf+3*i  ] - lbheatforce[tpos*3*lbsy.nf+3*i  ] - postequil * (lbbdforce[3*i  ]+lboscilforce[3*i  ]*freq);
          force[3*i+2] =  lbinterforce[tpos*3*lbsy.nf+3*i+1] + lbheatforce[tpos*3*lbsy.nf+3*i+1] + postequil * (lbbdforce[3*i+1]+lboscilforce[3*i+1]*freq);
          force[3*i+1] =  lbinterforce[tpos*3*lbsy.nf+3*i+2] + lbheatforce[tpos*3*lbsy.nf+3*i+2] + postequil * (lbbdforce[3*i+2]+lboscilforce[3*i+2]*freq);
        }
      }
      break;
    case CEDF:
      if(interact>9 && interact<20) {
        fD3CECCFracSite(frac, tpos1);
        for(int i=0; i<lbsy.nf; i++) {
          force[3*i+2] =  frac[i] * lbinterforce[tpos*3  ] + lbheatforce[tpos*3*lbsy.nf+3*i  ] + postequil * (lbbdforce[3*i  ]+lboscilforce[3*i  ]*freq);
          force[3*i  ] = -frac[i] * lbinterforce[tpos*3+1] - lbheatforce[tpos*3*lbsy.nf+3*i+1] - postequil * (lbbdforce[3*i+1]+lboscilforce[3*i+1]*freq);
          force[3*i+1] =  frac[i] * lbinterforce[tpos*3+2] + lbheatforce[tpos*3*lbsy.nf+3*i+2] + postequil * (lbbdforce[3*i+2]+lboscilforce[3*i+2]*freq);
        }
      }
      else {
        for(int i=0; i<lbsy.nf; i++) {
          force[3*i+2] =  lbinterforce[tpos*3*lbsy.nf+3*i  ] + lbheatforce[tpos*3*lbsy.nf+3*i  ] + postequil * (lbbdforce[3*i  ]+lboscilforce[3*i  ]*freq);
          force[3*i  ] = -lbinterforce[tpos*3*lbsy.nf+3*i+1] - lbheatforce[tpos*3*lbsy.nf+3*i+1] - postequil * (lbbdforce[3*i+1]+lboscilforce[3*i+1]*freq);
          force[3*i+1] =  lbinterforce[tpos*3*lbsy.nf+3*i+2] + lbheatforce[tpos*3*lbsy.nf+3*i+2] + postequil * (lbbdforce[3*i+2]+lboscilforce[3*i+2]*freq);
        }
      }
      break;
    case CERF:
      if(interact>9 && interact<20) {
        fD3CECCFracSite(frac, tpos1);
        for(int i=0; i<lbsy.nf; i++) {
          force[3*i  ] = frac[i] * lbinterforce[tpos*3  ] + lbheatforce[tpos*3*lbsy.nf+3*i  ] + postequil * (lbbdforce[3*i  ]+lboscilforce[3*i  ]*freq);
          force[3*i+2] = frac[i] * lbinterforce[tpos*3+1] + lbheatforce[tpos*3*lbsy.nf+3*i+1] + postequil * (lbbdforce[3*i+1]+lboscilforce[3*i+1]*freq);
          force[3*i+1] = frac[i] * lbinterforce[tpos*3+2] + lbheatforce[tpos*3*lbsy.nf+3*i+2] + postequil * (lbbdforce[3*i+2]+lboscilforce[3*i+2]*freq);
        }
      }
      else {
        for(int i=0; i<lbsy.nf; i++) {
          force[3*i  ] = lbinterforce[tpos*3*lbsy.nf+3*i  ] + lbheatforce[tpos*3*lbsy.nf+3*i  ] + postequil * (lbbdforce[3*i  ]+lboscilforce[3*i  ]*freq);
          force[3*i+2] = lbinterforce[tpos*3*lbsy.nf+3*i+1] + lbheatforce[tpos*3*lbsy.nf+3*i+1] + postequil * (lbbdforce[3*i+1]+lboscilforce[3*i+1]*freq);
          force[3*i+1] = lbinterforce[tpos*3*lbsy.nf+3*i+2] + lbheatforce[tpos*3*lbsy.nf+3*i+2] + postequil * (lbbdforce[3*i+2]+lboscilforce[3*i+2]*freq);
        }
      }
      break;
    case CETB:
      if(interact>9 && interact<20) {
        fD3CECCFracSite(frac, tpos1);
        for(int i=0; i<lbsy.nf; i++) {
          force[3*i+2] =  frac[i] * lbinterforce[tpos*3  ] + lbheatforce[tpos*3*lbsy.nf+3*i  ] + postequil * (lbbdforce[3*i  ]+lboscilforce[3*i  ]*freq);
          force[3*i  ] =  frac[i] * lbinterforce[tpos*3+1] + lbheatforce[tpos*3*lbsy.nf+3*i+1] + postequil * (lbbdforce[3*i+1]+lboscilforce[3*i+1]*freq);
          force[3*i+1] = -frac[i] * lbinterforce[tpos*3+2] - lbheatforce[tpos*3*lbsy.nf+3*i+2] - postequil * (lbbdforce[3*i+2]+lboscilforce[3*i+2]*freq);
        }
      }
      else {
        for(int i=0; i<lbsy.nf; i++) {
          force[3*i+2] =  lbinterforce[tpos*3*lbsy.nf+3*i  ] + lbheatforce[tpos*3*lbsy.nf+3*i  ] + postequil * (lbbdforce[3*i  ]+lboscilforce[3*i  ]*freq);
          force[3*i  ] =  lbinterforce[tpos*3*lbsy.nf+3*i+1] + lbheatforce[tpos*3*lbsy.nf+3*i+1] + postequil * (lbbdforce[3*i+1]+lboscilforce[3*i+1]*freq);
          force[3*i+1] = -lbinterforce[tpos*3*lbsy.nf+3*i+2] - lbheatforce[tpos*3*lbsy.nf+3*i+2] - postequil * (lbbdforce[3*i+2]+lboscilforce[3*i+2]*freq);
        }
      }
      break;
    case CELB:
      if(interact>9 && interact<20) {
        fD3CECCFracSite(frac, tpos1);
        for(int i=0; i<lbsy.nf; i++) {
          force[3*i  ] = -frac[i] * lbinterforce[tpos*3  ] - lbheatforce[tpos*3*lbsy.nf+3*i  ] - postequil * (lbbdforce[3*i  ]+lboscilforce[3*i  ]*freq);
          force[3*i+2] =  frac[i] * lbinterforce[tpos*3+1] + lbheatforce[tpos*3*lbsy.nf+3*i+1] + postequil * (lbbdforce[3*i+1]+lboscilforce[3*i+1]*freq);
          force[3*i+1] = -frac[i] * lbinterforce[tpos*3+2] - lbheatforce[tpos*3*lbsy.nf+3*i+2] - postequil * (lbbdforce[3*i+2]+lboscilforce[3*i+2]*freq);
        }
      }
      else {
        for(int i=0; i<lbsy.nf; i++) {
          force[3*i  ] = -lbinterforce[tpos*3*lbsy.nf+3*i  ] - lbheatforce[tpos*3*lbsy.nf+3*i  ] - postequil * (lbbdforce[3*i  ]+lboscilforce[3*i  ]*freq);
          force[3*i+2] =  lbinterforce[tpos*3*lbsy.nf+3*i+1] + lbheatforce[tpos*3*lbsy.nf+3*i+1] + postequil * (lbbdforce[3*i+1]+lboscilforce[3*i+1]*freq);
          force[3*i+1] = -lbinterforce[tpos*3*lbsy.nf+3*i+2] - lbheatforce[tpos*3*lbsy.nf+3*i+2] - postequil * (lbbdforce[3*i+2]+lboscilforce[3*i+2]*freq);
        }
      }
      break;
    case CEDB:
      if(interact>9 && interact<20) {
        fD3CECCFracSite(frac, tpos1);
        for(int i=0; i<lbsy.nf; i++) {
          force[3*i+2] =  frac[i] * lbinterforce[tpos*3  ] + lbheatforce[tpos*3*lbsy.nf+3*i  ] + postequil * (lbbdforce[3*i  ]+lboscilforce[3*i  ]*freq);
          force[3*i  ] = -frac[i] * lbinterforce[tpos*3+1] - lbheatforce[tpos*3*lbsy.nf+3*i+1] - postequil * (lbbdforce[3*i+1]+lboscilforce[3*i+1]*freq);
          force[3*i+1] = -frac[i] * lbinterforce[tpos*3+2] - lbheatforce[tpos*3*lbsy.nf+3*i+2] - postequil * (lbbdforce[3*i+2]+lboscilforce[3*i+2]*freq);
        }
      }
      else {
        for(int i=0; i<lbsy.nf; i++) {
          force[3*i+2] =  lbinterforce[tpos*3*lbsy.nf+3*i  ] + lbheatforce[tpos*3*lbsy.nf+3*i  ] + postequil * (lbbdforce[3*i  ]+lboscilforce[3*i  ]*freq);
          force[3*i  ] = -lbinterforce[tpos*3*lbsy.nf+3*i+1] - lbheatforce[tpos*3*lbsy.nf+3*i+1] - postequil * (lbbdforce[3*i+1]+lboscilforce[3*i+1]*freq);
          force[3*i+1] = -lbinterforce[tpos*3*lbsy.nf+3*i+2] - lbheatforce[tpos*3*lbsy.nf+3*i+2] - postequil * (lbbdforce[3*i+2]+lboscilforce[3*i+2]*freq);
        }
      }
      break;
    case CERB:
      if(interact>9 && interact<20) {
        fD3CECCFracSite(frac, tpos1);
        for(int i=0; i<lbsy.nf; i++) {
          force[3*i  ] =  frac[i] * lbinterforce[tpos*3  ] + lbheatforce[tpos*3*lbsy.nf+3*i  ] + postequil * (lbbdforce[3*i  ]+lboscilforce[3*i  ]*freq);
          force[3*i+2] =  frac[i] * lbinterforce[tpos*3+1] + lbheatforce[tpos*3*lbsy.nf+3*i+1] + postequil * (lbbdforce[3*i+1]+lboscilforce[3*i+1]*freq);
          force[3*i+1] = -frac[i] * lbinterforce[tpos*3+2] - lbheatforce[tpos*3*lbsy.nf+3*i+2] - postequil * (lbbdforce[3*i+2]+lboscilforce[3*i+2]*freq);
        }
      }
      else {
        for(int i=0; i<lbsy.nf; i++) {
          force[3*i  ] =  lbinterforce[tpos*3*lbsy.nf+3*i  ] + lbheatforce[tpos*3*lbsy.nf+3*i  ] + postequil * (lbbdforce[3*i  ]+lboscilforce[3*i  ]*freq);
          force[3*i+2] =  lbinterforce[tpos*3*lbsy.nf+3*i+1] + lbheatforce[tpos*3*lbsy.nf+3*i+1] + postequil * (lbbdforce[3*i+1]+lboscilforce[3*i+1]*freq);
          force[3*i+1] = -lbinterforce[tpos*3*lbsy.nf+3*i+2] - lbheatforce[tpos*3*lbsy.nf+3*i+2] - postequil * (lbbdforce[3*i+2]+lboscilforce[3*i+2]*freq);
        }
      }
      break;
  }
  return 0;
}

int fD3Q27BoundaryForceDensity(double *force, long tpos, double *p0, int prop)
{
  // calculate forces required at constant density boundary point for D3Q27 lattice

  double phi, freq = (lbbdforcetyp==1)*sin(lboscilfreq*(lbcurstep-lbequstep));

  switch (prop) {
    case PST:
    case CCTRF:
    case CETR:
      if(interact>9 && interact<20) {
        phi = 0.0;
        for(int i=0; i<lbsy.nf; i++)
          phi += p0[i];
        phi = fReciprocal(phi);
        for(int i=0; i<lbsy.nf; i++) {
          force[3*i  ] = p0[i] * phi * lbinterforce[tpos*3  ] + lbheatforce[tpos*3*lbsy.nf+3*i  ] + postequil * (lbbdforce[3*i  ]+lboscilforce[3*i  ]*freq);
          force[3*i+1] = p0[i] * phi * lbinterforce[tpos*3+1] + lbheatforce[tpos*3*lbsy.nf+3*i+1] + postequil * (lbbdforce[3*i+1]+lboscilforce[3*i+1]*freq);
          force[3*i+2] = p0[i] * phi * lbinterforce[tpos*3+2] + lbheatforce[tpos*3*lbsy.nf+3*i+2] + postequil * (lbbdforce[3*i+2]+lboscilforce[3*i+2]*freq);
        }
      }
      else {
        for(int i=0; i<lbsy.nf; i++) {
          force[3*i  ] = lbinterforce[tpos*3*lbsy.nf+3*i  ] + lbheatforce[tpos*3*lbsy.nf+3*i  ] + postequil * (lbbdforce[3*i  ]+lboscilforce[3*i  ]*freq);
          force[3*i+1] = lbinterforce[tpos*3*lbsy.nf+3*i+1] + lbheatforce[tpos*3*lbsy.nf+3*i+1] + postequil * (lbbdforce[3*i+1]+lboscilforce[3*i+1]*freq);
          force[3*i+2] = lbinterforce[tpos*3*lbsy.nf+3*i+2] + lbheatforce[tpos*3*lbsy.nf+3*i+2] + postequil * (lbbdforce[3*i+2]+lboscilforce[3*i+2]*freq);
        }
      }
      break;
    case PSD:
      if(interact>9 && interact<20) {
        phi = 0.0;
        for(int i=0; i<lbsy.nf; i++)
          phi += p0[i];
        phi = fReciprocal(phi);
        for(int i=0; i<lbsy.nf; i++) {
          force[3*i  ] = -p0[i] * phi * lbinterforce[tpos*3  ] - lbheatforce[tpos*3*lbsy.nf+3*i  ] - postequil * (lbbdforce[3*i  ]+lboscilforce[3*i  ]*freq);
          force[3*i+1] = -p0[i] * phi * lbinterforce[tpos*3+1] - lbheatforce[tpos*3*lbsy.nf+3*i+1] - postequil * (lbbdforce[3*i+1]+lboscilforce[3*i+1]*freq);
          force[3*i+2] = -p0[i] * phi * lbinterforce[tpos*3+2] - lbheatforce[tpos*3*lbsy.nf+3*i+2] - postequil * (lbbdforce[3*i+2]+lboscilforce[3*i+2]*freq);
        }
      }
      else {
        for(int i=0; i<lbsy.nf; i++) {
          force[3*i  ] = -lbinterforce[tpos*3*lbsy.nf+3*i  ] - lbheatforce[tpos*3*lbsy.nf+3*i  ] - postequil * (lbbdforce[3*i  ]+lboscilforce[3*i  ]*freq);
          force[3*i+1] = -lbinterforce[tpos*3*lbsy.nf+3*i+1] - lbheatforce[tpos*3*lbsy.nf+3*i+1] - postequil * (lbbdforce[3*i+1]+lboscilforce[3*i+1]*freq);
          force[3*i+2] = -lbinterforce[tpos*3*lbsy.nf+3*i+2] - lbheatforce[tpos*3*lbsy.nf+3*i+2] - postequil * (lbbdforce[3*i+2]+lboscilforce[3*i+2]*freq);
        }
      }
      break;
    case PSL:
      if(interact>9 && interact<20) {
        phi = 0.0;
        for(int i=0; i<lbsy.nf; i++)
          phi += p0[i];
        phi = fReciprocal(phi);
        for(int i=0; i<lbsy.nf; i++) {
          force[3*i+1] = -p0[i] * phi * lbinterforce[tpos*3  ] - lbheatforce[tpos*3*lbsy.nf+3*i  ] - postequil * (lbbdforce[3*i  ]+lboscilforce[3*i  ]*freq);
          force[3*i+2] = -p0[i] * phi * lbinterforce[tpos*3+1] - lbheatforce[tpos*3*lbsy.nf+3*i+1] - postequil * (lbbdforce[3*i+1]+lboscilforce[3*i+1]*freq);
          force[3*i  ] = -p0[i] * phi * lbinterforce[tpos*3+2] - lbheatforce[tpos*3*lbsy.nf+3*i+2] - postequil * (lbbdforce[3*i+2]+lboscilforce[3*i+2]*freq);
        }
      }
      else {
        for(int i=0; i<lbsy.nf; i++) {
          force[3*i+1] = -lbinterforce[tpos*3*lbsy.nf+3*i  ] - lbheatforce[tpos*3*lbsy.nf+3*i  ] - postequil * (lbbdforce[3*i  ]+lboscilforce[3*i  ]*freq);
          force[3*i+2] = -lbinterforce[tpos*3*lbsy.nf+3*i+1] - lbheatforce[tpos*3*lbsy.nf+3*i+1] - postequil * (lbbdforce[3*i+1]+lboscilforce[3*i+1]*freq);
          force[3*i  ] = -lbinterforce[tpos*3*lbsy.nf+3*i+2] - lbheatforce[tpos*3*lbsy.nf+3*i+2] - postequil * (lbbdforce[3*i+2]+lboscilforce[3*i+2]*freq);
        }
      }
      break;
    case PSR:
      if(interact>9 && interact<20) {
        phi = 0.0;
        for(int i=0; i<lbsy.nf; i++)
          phi += p0[i];
        phi = fReciprocal(phi);
        for(int i=0; i<lbsy.nf; i++) {
          force[3*i+1] = p0[i] * phi * lbinterforce[tpos*3  ] + lbheatforce[tpos*3*lbsy.nf+3*i  ] + postequil * (lbbdforce[3*i  ]+lboscilforce[3*i  ]*freq);
          force[3*i+2] = p0[i] * phi * lbinterforce[tpos*3+1] + lbheatforce[tpos*3*lbsy.nf+3*i+1] + postequil * (lbbdforce[3*i+1]+lboscilforce[3*i+1]*freq);
          force[3*i  ] = p0[i] * phi * lbinterforce[tpos*3+2] + lbheatforce[tpos*3*lbsy.nf+3*i+2] + postequil * (lbbdforce[3*i+2]+lboscilforce[3*i+2]*freq);
        }
      }
      else {
        for(int i=0; i<lbsy.nf; i++) {
          force[3*i+1] = lbinterforce[tpos*3*lbsy.nf+3*i  ] + lbheatforce[tpos*3*lbsy.nf+3*i  ] + postequil * (lbbdforce[3*i  ]+lboscilforce[3*i  ]*freq);
          force[3*i+2] = lbinterforce[tpos*3*lbsy.nf+3*i+1] + lbheatforce[tpos*3*lbsy.nf+3*i+1] + postequil * (lbbdforce[3*i+1]+lboscilforce[3*i+1]*freq);
          force[3*i  ] = lbinterforce[tpos*3*lbsy.nf+3*i+2] + lbheatforce[tpos*3*lbsy.nf+3*i+2] + postequil * (lbbdforce[3*i+2]+lboscilforce[3*i+2]*freq);
        }
      }
      break;
    case PSF:
      if(interact>9 && interact<20) {
        phi = 0.0;
        for(int i=0; i<lbsy.nf; i++)
          phi += p0[i];
        phi = fReciprocal(phi);
        for(int i=0; i<lbsy.nf; i++) {
          force[3*i+2] = -p0[i] * phi * lbinterforce[tpos*3  ] - lbheatforce[tpos*3*lbsy.nf+3*i  ] - postequil * (lbbdforce[3*i  ]+lboscilforce[3*i  ]*freq);
          force[3*i  ] = -p0[i] * phi * lbinterforce[tpos*3+1] - lbheatforce[tpos*3*lbsy.nf+3*i+1] - postequil * (lbbdforce[3*i+1]+lboscilforce[3*i+1]*freq);
          force[3*i+1] = -p0[i] * phi * lbinterforce[tpos*3+2] - lbheatforce[tpos*3*lbsy.nf+3*i+2] - postequil * (lbbdforce[3*i+2]+lboscilforce[3*i+2]*freq);
        }
      }
      else {
        for(int i=0; i<lbsy.nf; i++) {
          force[3*i+2] = -lbinterforce[tpos*3*lbsy.nf+3*i  ] - lbheatforce[tpos*3*lbsy.nf+3*i  ] - postequil * (lbbdforce[3*i  ]+lboscilforce[3*i  ]*freq);
          force[3*i  ] = -lbinterforce[tpos*3*lbsy.nf+3*i+1] - lbheatforce[tpos*3*lbsy.nf+3*i+1] - postequil * (lbbdforce[3*i+1]+lboscilforce[3*i+1]*freq);
          force[3*i+1] = -lbinterforce[tpos*3*lbsy.nf+3*i+2] - lbheatforce[tpos*3*lbsy.nf+3*i+2] - postequil * (lbbdforce[3*i+2]+lboscilforce[3*i+2]*freq);
        }
      }
      break;
    case PSB:
      if(interact>9 && interact<20) {
        phi = 0.0;
        for(int i=0; i<lbsy.nf; i++)
          phi += p0[i];
        phi = fReciprocal(phi);
        for(int i=0; i<lbsy.nf; i++) {
          force[3*i+2] = p0[i] * phi * lbinterforce[tpos*3  ] + lbheatforce[tpos*3*lbsy.nf+3*i  ] + postequil * (lbbdforce[3*i  ]+lboscilforce[3*i  ]*freq);
          force[3*i  ] = p0[i] * phi * lbinterforce[tpos*3+1] + lbheatforce[tpos*3*lbsy.nf+3*i+1] + postequil * (lbbdforce[3*i+1]+lboscilforce[3*i+1]*freq);
          force[3*i+1] = p0[i] * phi * lbinterforce[tpos*3+2] + lbheatforce[tpos*3*lbsy.nf+3*i+2] + postequil * (lbbdforce[3*i+2]+lboscilforce[3*i+2]*freq);
        }
      }
      else {
        for(int i=0; i<lbsy.nf; i++) {
          force[3*i+2] = lbinterforce[tpos*3*lbsy.nf+3*i  ] + lbheatforce[tpos*3*lbsy.nf+3*i  ] + postequil * (lbbdforce[3*i  ]+lboscilforce[3*i  ]*freq);
          force[3*i  ] = lbinterforce[tpos*3*lbsy.nf+3*i+1] + lbheatforce[tpos*3*lbsy.nf+3*i+1] + postequil * (lbbdforce[3*i+1]+lboscilforce[3*i+1]*freq);
          force[3*i+1] = lbinterforce[tpos*3*lbsy.nf+3*i+2] + lbheatforce[tpos*3*lbsy.nf+3*i+2] + postequil * (lbbdforce[3*i+2]+lboscilforce[3*i+2]*freq);
        }
      }
      break;
    case CCTRB:
      if(interact>9 && interact<20) {
        phi = 0.0;
        for(int i=0; i<lbsy.nf; i++)
          phi += p0[i];
        phi = fReciprocal(phi);
        for(int i=0; i<lbsy.nf; i++) {
          force[3*i  ] =  p0[i] * phi * lbinterforce[tpos*3  ] + lbheatforce[tpos*3*lbsy.nf+3*i  ] + postequil * (lbbdforce[3*i  ]+lboscilforce[3*i  ]*freq);
          force[3*i+1] =  p0[i] * phi * lbinterforce[tpos*3+1] + lbheatforce[tpos*3*lbsy.nf+3*i+1] + postequil * (lbbdforce[3*i+1]+lboscilforce[3*i+1]*freq);
          force[3*i+2] = -p0[i] * phi * lbinterforce[tpos*3+2] - lbheatforce[tpos*3*lbsy.nf+3*i+2] - postequil * (lbbdforce[3*i+2]+lboscilforce[3*i+2]*freq);
        }
      }
      else {
        for(int i=0; i<lbsy.nf; i++) {
          force[3*i  ] =  lbinterforce[tpos*3*lbsy.nf+3*i  ] + lbheatforce[tpos*3*lbsy.nf+3*i  ] + postequil * (lbbdforce[3*i  ]+lboscilforce[3*i  ]*freq);
          force[3*i+1] =  lbinterforce[tpos*3*lbsy.nf+3*i+1] + lbheatforce[tpos*3*lbsy.nf+3*i+1] + postequil * (lbbdforce[3*i+1]+lboscilforce[3*i+1]*freq);
          force[3*i+2] = -lbinterforce[tpos*3*lbsy.nf+3*i+2] - lbheatforce[tpos*3*lbsy.nf+3*i+2] - postequil * (lbbdforce[3*i+2]+lboscilforce[3*i+2]*freq);
        }
      }
      break;
    case CCTLB:
      if(interact>9 && interact<20) {
        phi = 0.0;
        for(int i=0; i<lbsy.nf; i++)
          phi += p0[i];
        phi = fReciprocal(phi);
        for(int i=0; i<lbsy.nf; i++) {
          force[3*i  ] = -p0[i] * phi * lbinterforce[tpos*3  ] - lbheatforce[tpos*3*lbsy.nf+3*i  ] - postequil * (lbbdforce[3*i  ]+lboscilforce[3*i  ]*freq);
          force[3*i+1] =  p0[i] * phi * lbinterforce[tpos*3+1] + lbheatforce[tpos*3*lbsy.nf+3*i+1] + postequil * (lbbdforce[3*i+1]+lboscilforce[3*i+1]*freq);
          force[3*i+2] = -p0[i] * phi * lbinterforce[tpos*3+2] - lbheatforce[tpos*3*lbsy.nf+3*i+2] - postequil * (lbbdforce[3*i+2]+lboscilforce[3*i+2]*freq);
        }
      }
      else {
        for(int i=0; i<lbsy.nf; i++) {
          force[3*i  ] = -lbinterforce[tpos*3*lbsy.nf+3*i  ] - lbheatforce[tpos*3*lbsy.nf+3*i  ] - postequil * (lbbdforce[3*i  ]+lboscilforce[3*i  ]*freq);
          force[3*i+1] =  lbinterforce[tpos*3*lbsy.nf+3*i+1] + lbheatforce[tpos*3*lbsy.nf+3*i+1] + postequil * (lbbdforce[3*i+1]+lboscilforce[3*i+1]*freq);
          force[3*i+2] = -lbinterforce[tpos*3*lbsy.nf+3*i+2] - lbheatforce[tpos*3*lbsy.nf+3*i+2] - postequil * (lbbdforce[3*i+2]+lboscilforce[3*i+2]*freq);
        }
      }
      break;
    case CCDRB:
      if(interact>9 && interact<20) {
        phi = 0.0;
        for(int i=0; i<lbsy.nf; i++)
          phi += p0[i];
        phi = fReciprocal(phi);
        for(int i=0; i<lbsy.nf; i++) {
          force[3*i  ] =  p0[i] * phi * lbinterforce[tpos*3  ] + lbheatforce[tpos*3*lbsy.nf+3*i  ] + postequil * (lbbdforce[3*i  ]+lboscilforce[3*i  ]*freq);
          force[3*i+1] = -p0[i] * phi * lbinterforce[tpos*3+1] - lbheatforce[tpos*3*lbsy.nf+3*i+1] - postequil * (lbbdforce[3*i+1]+lboscilforce[3*i+1]*freq);
          force[3*i+2] = -p0[i] * phi * lbinterforce[tpos*3+2] - lbheatforce[tpos*3*lbsy.nf+3*i+2] - postequil * (lbbdforce[3*i+2]+lboscilforce[3*i+2]*freq);
        }
      }
      else {
        for(int i=0; i<lbsy.nf; i++) {
          force[3*i  ] =  lbinterforce[tpos*3*lbsy.nf+3*i  ] + lbheatforce[tpos*3*lbsy.nf+3*i  ] + postequil * (lbbdforce[3*i  ]+lboscilforce[3*i  ]*freq);
          force[3*i+1] = -lbinterforce[tpos*3*lbsy.nf+3*i+1] - lbheatforce[tpos*3*lbsy.nf+3*i+1] - postequil * (lbbdforce[3*i+1]+lboscilforce[3*i+1]*freq);
          force[3*i+2] = -lbinterforce[tpos*3*lbsy.nf+3*i+2] - lbheatforce[tpos*3*lbsy.nf+3*i+2] - postequil * (lbbdforce[3*i+2]+lboscilforce[3*i+2]*freq);
        }
      }
      break;
    case CCTLF:
      if(interact>9 && interact<20) {
        phi = 0.0;
        for(int i=0; i<lbsy.nf; i++)
          phi += p0[i];
        phi = fReciprocal(phi);
        for(int i=0; i<lbsy.nf; i++) {
          force[3*i  ] = -p0[i] * phi * lbinterforce[tpos*3  ] - lbheatforce[tpos*3*lbsy.nf+3*i  ] - postequil * (lbbdforce[3*i  ]+lboscilforce[3*i  ]*freq);
          force[3*i+1] =  p0[i] * phi * lbinterforce[tpos*3+1] + lbheatforce[tpos*3*lbsy.nf+3*i+1] + postequil * (lbbdforce[3*i+1]+lboscilforce[3*i+1]*freq);
          force[3*i+2] =  p0[i] * phi * lbinterforce[tpos*3+2] + lbheatforce[tpos*3*lbsy.nf+3*i+2] + postequil * (lbbdforce[3*i+2]+lboscilforce[3*i+2]*freq);
        }
      }
      else {
        for(int i=0; i<lbsy.nf; i++) {
          force[3*i  ] = -lbinterforce[tpos*3*lbsy.nf+3*i  ] - lbheatforce[tpos*3*lbsy.nf+3*i  ] - postequil * (lbbdforce[3*i  ]+lboscilforce[3*i  ]*freq);
          force[3*i+1] =  lbinterforce[tpos*3*lbsy.nf+3*i+1] + lbheatforce[tpos*3*lbsy.nf+3*i+1] + postequil * (lbbdforce[3*i+1]+lboscilforce[3*i+1]*freq);
          force[3*i+2] =  lbinterforce[tpos*3*lbsy.nf+3*i+2] + lbheatforce[tpos*3*lbsy.nf+3*i+2] + postequil * (lbbdforce[3*i+2]+lboscilforce[3*i+2]*freq);
        }
      }
      break;
    case CCDLF:
    case CEDL:
      if(interact>9 && interact<20) {
        phi = 0.0;
        for(int i=0; i<lbsy.nf; i++)
          phi += p0[i];
        phi = fReciprocal(phi);
        for(int i=0; i<lbsy.nf; i++) {
          force[3*i  ] = -p0[i] * phi * lbinterforce[tpos*3  ] - lbheatforce[tpos*3*lbsy.nf+3*i  ] - postequil * (lbbdforce[3*i  ]+lboscilforce[3*i  ]*freq);
          force[3*i+1] = -p0[i] * phi * lbinterforce[tpos*3+1] - lbheatforce[tpos*3*lbsy.nf+3*i+1] - postequil * (lbbdforce[3*i+1]+lboscilforce[3*i+1]*freq);
          force[3*i+2] =  p0[i] * phi * lbinterforce[tpos*3+2] + lbheatforce[tpos*3*lbsy.nf+3*i+2] + postequil * (lbbdforce[3*i+2]+lboscilforce[3*i+2]*freq);
        }
      }
      else {
        for(int i=0; i<lbsy.nf; i++) {
          force[3*i  ] = -lbinterforce[tpos*3*lbsy.nf+3*i  ] - lbheatforce[tpos*3*lbsy.nf+3*i  ] - postequil * (lbbdforce[3*i  ]+lboscilforce[3*i  ]*freq);
          force[3*i+1] = -lbinterforce[tpos*3*lbsy.nf+3*i+1] - lbheatforce[tpos*3*lbsy.nf+3*i+1] - postequil * (lbbdforce[3*i+1]+lboscilforce[3*i+1]*freq);
          force[3*i+2] =  lbinterforce[tpos*3*lbsy.nf+3*i+2] + lbheatforce[tpos*3*lbsy.nf+3*i+2] + postequil * (lbbdforce[3*i+2]+lboscilforce[3*i+2]*freq);
        }
      }
      break;
    case CCDRF:
      if(interact>9 && interact<20) {
        phi = 0.0;
        for(int i=0; i<lbsy.nf; i++)
          phi += p0[i];
        phi = fReciprocal(phi);
        for(int i=0; i<lbsy.nf; i++) {
          force[3*i  ] =  p0[i] * phi * lbinterforce[tpos*3  ] + lbheatforce[tpos*3*lbsy.nf+3*i  ] + postequil * (lbbdforce[3*i  ]+lboscilforce[3*i  ]*freq);
          force[3*i+1] = -p0[i] * phi * lbinterforce[tpos*3+1] - lbheatforce[tpos*3*lbsy.nf+3*i+1] - postequil * (lbbdforce[3*i+1]+lboscilforce[3*i+1]*freq);
          force[3*i+2] =  p0[i] * phi * lbinterforce[tpos*3+2] + lbheatforce[tpos*3*lbsy.nf+3*i+2] + postequil * (lbbdforce[3*i+2]+lboscilforce[3*i+2]*freq);
        }
      }
      else {
        for(int i=0; i<lbsy.nf; i++) {
          force[3*i  ] =  lbinterforce[tpos*3*lbsy.nf+3*i  ] + lbheatforce[tpos*3*lbsy.nf+3*i  ] + postequil * (lbbdforce[3*i  ]+lboscilforce[3*i  ]*freq);
          force[3*i+1] = -lbinterforce[tpos*3*lbsy.nf+3*i+1] - lbheatforce[tpos*3*lbsy.nf+3*i+1] - postequil * (lbbdforce[3*i+1]+lboscilforce[3*i+1]*freq);
          force[3*i+2] =  lbinterforce[tpos*3*lbsy.nf+3*i+2] + lbheatforce[tpos*3*lbsy.nf+3*i+2] + postequil * (lbbdforce[3*i+2]+lboscilforce[3*i+2]*freq);
        }
      }
      break;
    case CETL:
      if(interact>9 && interact<20) {
        phi = 0.0;
        for(int i=0; i<lbsy.nf; i++)
          phi += p0[i];
        phi = fReciprocal(phi);
        for(int i=0; i<lbsy.nf; i++) {
          force[3*i+1] = -p0[i] * phi * lbinterforce[tpos*3  ] - lbheatforce[tpos*3*lbsy.nf+3*i  ] - postequil * (lbbdforce[3*i  ]+lboscilforce[3*i  ]*freq);
          force[3*i  ] =  p0[i] * phi * lbinterforce[tpos*3+1] + lbheatforce[tpos*3*lbsy.nf+3*i+1] + postequil * (lbbdforce[3*i+1]+lboscilforce[3*i+1]*freq);
          force[3*i+2] =  p0[i] * phi * lbinterforce[tpos*3+2] + lbheatforce[tpos*3*lbsy.nf+3*i+2] + postequil * (lbbdforce[3*i+2]+lboscilforce[3*i+2]*freq);
        }
      }
      else {
        for(int i=0; i<lbsy.nf; i++) {
          force[3*i+1] = -lbinterforce[tpos*3*lbsy.nf+3*i  ] - lbheatforce[tpos*3*lbsy.nf+3*i  ] - postequil * (lbbdforce[3*i  ]+lboscilforce[3*i  ]*freq);
          force[3*i  ] =  lbinterforce[tpos*3*lbsy.nf+3*i+1] + lbheatforce[tpos*3*lbsy.nf+3*i+1] + postequil * (lbbdforce[3*i+1]+lboscilforce[3*i+1]*freq);
          force[3*i+2] =  lbinterforce[tpos*3*lbsy.nf+3*i+2] + lbheatforce[tpos*3*lbsy.nf+3*i+2] + postequil * (lbbdforce[3*i+2]+lboscilforce[3*i+2]*freq);
        }
      }
      break;
    case CEDR:
      if(interact>9 && interact<20) {
        phi = 0.0;
        for(int i=0; i<lbsy.nf; i++)
          phi += p0[i];
        phi = fReciprocal(phi);
        for(int i=0; i<lbsy.nf; i++) {
          force[3*i+1] =  p0[i] * phi * lbinterforce[tpos*3  ] + lbheatforce[tpos*3*lbsy.nf+3*i  ] + postequil * (lbbdforce[3*i  ]+lboscilforce[3*i  ]*freq);
          force[3*i  ] = -p0[i] * phi * lbinterforce[tpos*3+1] - lbheatforce[tpos*3*lbsy.nf+3*i+1] - postequil * (lbbdforce[3*i+1]+lboscilforce[3*i+1]*freq);
          force[3*i+2] =  p0[i] * phi * lbinterforce[tpos*3+2] + lbheatforce[tpos*3*lbsy.nf+3*i+2] + postequil * (lbbdforce[3*i+2]+lboscilforce[3*i+2]*freq);
        }
      }
      else {
        for(int i=0; i<lbsy.nf; i++) {
          force[3*i+1] =  lbinterforce[tpos*3*lbsy.nf+3*i  ] + lbheatforce[tpos*3*lbsy.nf+3*i  ] + postequil * (lbbdforce[3*i  ]+lboscilforce[3*i  ]*freq);
          force[3*i  ] = -lbinterforce[tpos*3*lbsy.nf+3*i+1] - lbheatforce[tpos*3*lbsy.nf+3*i+1] - postequil * (lbbdforce[3*i+1]+lboscilforce[3*i+1]*freq);
          force[3*i+2] =  lbinterforce[tpos*3*lbsy.nf+3*i+2] + lbheatforce[tpos*3*lbsy.nf+3*i+2] + postequil * (lbbdforce[3*i+2]+lboscilforce[3*i+2]*freq);
        }
      }
      break;
    case CETF:
      if(interact>9 && interact<20) {
        phi = 0.0;
        for(int i=0; i<lbsy.nf; i++)
          phi += p0[i];
        phi = fReciprocal(phi);
        for(int i=0; i<lbsy.nf; i++) {
          force[3*i+2] = p0[i] * phi * lbinterforce[tpos*3  ] + lbheatforce[tpos*3*lbsy.nf+3*i  ] + postequil * (lbbdforce[3*i  ]+lboscilforce[3*i  ]*freq);
          force[3*i  ] = p0[i] * phi * lbinterforce[tpos*3+1] + lbheatforce[tpos*3*lbsy.nf+3*i+1] + postequil * (lbbdforce[3*i+1]+lboscilforce[3*i+1]*freq);
          force[3*i+1] = p0[i] * phi * lbinterforce[tpos*3+2] + lbheatforce[tpos*3*lbsy.nf+3*i+2] + postequil * (lbbdforce[3*i+2]+lboscilforce[3*i+2]*freq);
        }
      }
      else {
        for(int i=0; i<lbsy.nf; i++) {
          force[3*i+2] = lbinterforce[tpos*3*lbsy.nf+3*i  ] + lbheatforce[tpos*3*lbsy.nf+3*i  ] + postequil * (lbbdforce[3*i  ]+lboscilforce[3*i  ]*freq);
          force[3*i  ] = lbinterforce[tpos*3*lbsy.nf+3*i+1] + lbheatforce[tpos*3*lbsy.nf+3*i+1] + postequil * (lbbdforce[3*i+1]+lboscilforce[3*i+1]*freq);
          force[3*i+1] = lbinterforce[tpos*3*lbsy.nf+3*i+2] + lbheatforce[tpos*3*lbsy.nf+3*i+2] + postequil * (lbbdforce[3*i+2]+lboscilforce[3*i+2]*freq);
        }
      }
      break;
    case CELF:
      if(interact>9 && interact<20) {
        phi = 0.0;
        for(int i=0; i<lbsy.nf; i++)
          phi += p0[i];
        phi = fReciprocal(phi);
        for(int i=0; i<lbsy.nf; i++) {
          force[3*i  ] = -p0[i] * phi * lbinterforce[tpos*3  ] - lbheatforce[tpos*3*lbsy.nf+3*i  ] - postequil * (lbbdforce[3*i  ]+lboscilforce[3*i  ]*freq);
          force[3*i+2] =  p0[i] * phi * lbinterforce[tpos*3+1] + lbheatforce[tpos*3*lbsy.nf+3*i+1] + postequil * (lbbdforce[3*i+1]+lboscilforce[3*i+1]*freq);
          force[3*i+1] =  p0[i] * phi * lbinterforce[tpos*3+2] + lbheatforce[tpos*3*lbsy.nf+3*i+2] + postequil * (lbbdforce[3*i+2]+lboscilforce[3*i+2]*freq);
        }
      }
      else {
        for(int i=0; i<lbsy.nf; i++) {
          force[3*i  ] = -lbinterforce[tpos*3*lbsy.nf+3*i  ] - lbheatforce[tpos*3*lbsy.nf+3*i  ] - postequil * (lbbdforce[3*i  ]+lboscilforce[3*i  ]*freq);
          force[3*i+2] =  lbinterforce[tpos*3*lbsy.nf+3*i+1] + lbheatforce[tpos*3*lbsy.nf+3*i+1] + postequil * (lbbdforce[3*i+1]+lboscilforce[3*i+1]*freq);
          force[3*i+1] =  lbinterforce[tpos*3*lbsy.nf+3*i+2] + lbheatforce[tpos*3*lbsy.nf+3*i+2] + postequil * (lbbdforce[3*i+2]+lboscilforce[3*i+2]*freq);
        }
      }
      break;
    case CEDF:
      if(interact>9 && interact<20) {
        phi = 0.0;
        for(int i=0; i<lbsy.nf; i++)
          phi += p0[i];
        phi = fReciprocal(phi);
        for(int i=0; i<lbsy.nf; i++) {
          force[3*i+2] =  p0[i] * phi * lbinterforce[tpos*3  ] + lbheatforce[tpos*3*lbsy.nf+3*i  ] + postequil * (lbbdforce[3*i  ]+lboscilforce[3*i  ]*freq);
          force[3*i  ] = -p0[i] * phi * lbinterforce[tpos*3+1] - lbheatforce[tpos*3*lbsy.nf+3*i+1] - postequil * (lbbdforce[3*i+1]+lboscilforce[3*i+1]*freq);
          force[3*i+1] =  p0[i] * phi * lbinterforce[tpos*3+2] + lbheatforce[tpos*3*lbsy.nf+3*i+2] + postequil * (lbbdforce[3*i+2]+lboscilforce[3*i+2]*freq);
        }
      }
      else {
        for(int i=0; i<lbsy.nf; i++) {
          force[3*i+2] =  lbinterforce[tpos*3*lbsy.nf+3*i  ] + lbheatforce[tpos*3*lbsy.nf+3*i  ] + postequil * (lbbdforce[3*i  ]+lboscilforce[3*i  ]*freq);
          force[3*i  ] = -lbinterforce[tpos*3*lbsy.nf+3*i+1] - lbheatforce[tpos*3*lbsy.nf+3*i+1] - postequil * (lbbdforce[3*i+1]+lboscilforce[3*i+1]*freq);
          force[3*i+1] =  lbinterforce[tpos*3*lbsy.nf+3*i+2] + lbheatforce[tpos*3*lbsy.nf+3*i+2] + postequil * (lbbdforce[3*i+2]+lboscilforce[3*i+2]*freq);
        }
      }
      break;
    case CERF:
      if(interact>9 && interact<20) {
        phi = 0.0;
        for(int i=0; i<lbsy.nf; i++)
          phi += p0[i];
        phi = fReciprocal(phi);
        for(int i=0; i<lbsy.nf; i++) {
          force[3*i  ] = p0[i] * phi * lbinterforce[tpos*3  ] + lbheatforce[tpos*3*lbsy.nf+3*i  ] + postequil * (lbbdforce[3*i  ]+lboscilforce[3*i  ]*freq);
          force[3*i+2] = p0[i] * phi * lbinterforce[tpos*3+1] + lbheatforce[tpos*3*lbsy.nf+3*i+1] + postequil * (lbbdforce[3*i+1]+lboscilforce[3*i+1]*freq);
          force[3*i+1] = p0[i] * phi * lbinterforce[tpos*3+2] + lbheatforce[tpos*3*lbsy.nf+3*i+2] + postequil * (lbbdforce[3*i+2]+lboscilforce[3*i+2]*freq);
        }
      }
      else {
        for(int i=0; i<lbsy.nf; i++) {
          force[3*i  ] = lbinterforce[tpos*3*lbsy.nf+3*i  ] + lbheatforce[tpos*3*lbsy.nf+3*i  ] + postequil * (lbbdforce[3*i  ]+lboscilforce[3*i  ]*freq);
          force[3*i+2] = lbinterforce[tpos*3*lbsy.nf+3*i+1] + lbheatforce[tpos*3*lbsy.nf+3*i+1] + postequil * (lbbdforce[3*i+1]+lboscilforce[3*i+1]*freq);
          force[3*i+1] = lbinterforce[tpos*3*lbsy.nf+3*i+2] + lbheatforce[tpos*3*lbsy.nf+3*i+2] + postequil * (lbbdforce[3*i+2]+lboscilforce[3*i+2]*freq);
        }
      }
      break;
    case CETB:
      if(interact>9 && interact<20) {
        phi = 0.0;
        for(int i=0; i<lbsy.nf; i++)
          phi += p0[i];
        phi = fReciprocal(phi);
        for(int i=0; i<lbsy.nf; i++) {
          force[3*i+2] =  p0[i] * phi * lbinterforce[tpos*3  ] + lbheatforce[tpos*3*lbsy.nf+3*i  ] + postequil * (lbbdforce[3*i  ]+lboscilforce[3*i  ]*freq);
          force[3*i  ] =  p0[i] * phi * lbinterforce[tpos*3+1] + lbheatforce[tpos*3*lbsy.nf+3*i+1] + postequil * (lbbdforce[3*i+1]+lboscilforce[3*i+1]*freq);
          force[3*i+1] = -p0[i] * phi * lbinterforce[tpos*3+2] - lbheatforce[tpos*3*lbsy.nf+3*i+2] - postequil * (lbbdforce[3*i+2]+lboscilforce[3*i+2]*freq);
        }
      }
      else {
        for(int i=0; i<lbsy.nf; i++) {
          force[3*i+2] =  lbinterforce[tpos*3*lbsy.nf+3*i  ] + lbheatforce[tpos*3*lbsy.nf+3*i  ] + postequil * (lbbdforce[3*i  ]+lboscilforce[3*i  ]*freq);
          force[3*i  ] =  lbinterforce[tpos*3*lbsy.nf+3*i+1] + lbheatforce[tpos*3*lbsy.nf+3*i+1] + postequil * (lbbdforce[3*i+1]+lboscilforce[3*i+1]*freq);
          force[3*i+1] = -lbinterforce[tpos*3*lbsy.nf+3*i+2] - lbheatforce[tpos*3*lbsy.nf+3*i+2] - postequil * (lbbdforce[3*i+2]+lboscilforce[3*i+2]*freq);
        }
      }
      break;
    case CELB:
      if(interact>9 && interact<20) {
        phi = 0.0;
        for(int i=0; i<lbsy.nf; i++)
          phi += p0[i];
        phi = fReciprocal(phi);
        for(int i=0; i<lbsy.nf; i++) {
          force[3*i  ] = -p0[i] * phi * lbinterforce[tpos*3  ] - lbheatforce[tpos*3*lbsy.nf+3*i  ] - postequil * (lbbdforce[3*i  ]+lboscilforce[3*i  ]*freq);
          force[3*i+2] =  p0[i] * phi * lbinterforce[tpos*3+1] + lbheatforce[tpos*3*lbsy.nf+3*i+1] + postequil * (lbbdforce[3*i+1]+lboscilforce[3*i+1]*freq);
          force[3*i+1] = -p0[i] * phi * lbinterforce[tpos*3+2] - lbheatforce[tpos*3*lbsy.nf+3*i+2] - postequil * (lbbdforce[3*i+2]+lboscilforce[3*i+2]*freq);
        }
      }
      else {
        for(int i=0; i<lbsy.nf; i++) {
          force[3*i  ] = -lbinterforce[tpos*3*lbsy.nf+3*i  ] - lbheatforce[tpos*3*lbsy.nf+3*i  ] - postequil * (lbbdforce[3*i  ]+lboscilforce[3*i  ]*freq);
          force[3*i+2] =  lbinterforce[tpos*3*lbsy.nf+3*i+1] + lbheatforce[tpos*3*lbsy.nf+3*i+1] + postequil * (lbbdforce[3*i+1]+lboscilforce[3*i+1]*freq);
          force[3*i+1] = -lbinterforce[tpos*3*lbsy.nf+3*i+2] - lbheatforce[tpos*3*lbsy.nf+3*i+2] - postequil * (lbbdforce[3*i+2]+lboscilforce[3*i+2]*freq);
        }
      }
      break;
    case CEDB:
      if(interact>9 && interact<20) {
        phi = 0.0;
        for(int i=0; i<lbsy.nf; i++)
          phi += p0[i];
        phi = fReciprocal(phi);
        for(int i=0; i<lbsy.nf; i++) {
          force[3*i+2] =  p0[i] * phi * lbinterforce[tpos*3  ] + lbheatforce[tpos*3*lbsy.nf+3*i  ] + postequil * (lbbdforce[3*i  ]+lboscilforce[3*i  ]*freq);
          force[3*i  ] = -p0[i] * phi * lbinterforce[tpos*3+1] - lbheatforce[tpos*3*lbsy.nf+3*i+1] - postequil * (lbbdforce[3*i+1]+lboscilforce[3*i+1]*freq);
          force[3*i+1] = -p0[i] * phi * lbinterforce[tpos*3+2] - lbheatforce[tpos*3*lbsy.nf+3*i+2] - postequil * (lbbdforce[3*i+2]+lboscilforce[3*i+2]*freq);
        }
      }
      else {
        for(int i=0; i<lbsy.nf; i++) {
          force[3*i+2] =  lbinterforce[tpos*3*lbsy.nf+3*i  ] + lbheatforce[tpos*3*lbsy.nf+3*i  ] + postequil * (lbbdforce[3*i  ]+lboscilforce[3*i  ]*freq);
          force[3*i  ] = -lbinterforce[tpos*3*lbsy.nf+3*i+1] - lbheatforce[tpos*3*lbsy.nf+3*i+1] - postequil * (lbbdforce[3*i+1]+lboscilforce[3*i+1]*freq);
          force[3*i+1] = -lbinterforce[tpos*3*lbsy.nf+3*i+2] - lbheatforce[tpos*3*lbsy.nf+3*i+2] - postequil * (lbbdforce[3*i+2]+lboscilforce[3*i+2]*freq);
        }
      }
      break;
    case CERB:
      if(interact>9 && interact<20) {
        phi = 0.0;
        for(int i=0; i<lbsy.nf; i++)
          phi += p0[i];
        phi = fReciprocal(phi);
        for(int i=0; i<lbsy.nf; i++) {
          force[3*i  ] =  p0[i] * phi * lbinterforce[tpos*3  ] + lbheatforce[tpos*3*lbsy.nf+3*i  ] + postequil * (lbbdforce[3*i  ]+lboscilforce[3*i  ]*freq);
          force[3*i+2] =  p0[i] * phi * lbinterforce[tpos*3+1] + lbheatforce[tpos*3*lbsy.nf+3*i+1] + postequil * (lbbdforce[3*i+1]+lboscilforce[3*i+1]*freq);
          force[3*i+1] = -p0[i] * phi * lbinterforce[tpos*3+2] - lbheatforce[tpos*3*lbsy.nf+3*i+2] - postequil * (lbbdforce[3*i+2]+lboscilforce[3*i+2]*freq);
        }
      }
      else {
        for(int i=0; i<lbsy.nf; i++) {
          force[3*i  ] =  lbinterforce[tpos*3*lbsy.nf+3*i  ] + lbheatforce[tpos*3*lbsy.nf+3*i  ] + postequil * (lbbdforce[3*i  ]+lboscilforce[3*i  ]*freq);
          force[3*i+2] =  lbinterforce[tpos*3*lbsy.nf+3*i+1] + lbheatforce[tpos*3*lbsy.nf+3*i+1] + postequil * (lbbdforce[3*i+1]+lboscilforce[3*i+1]*freq);
          force[3*i+1] = -lbinterforce[tpos*3*lbsy.nf+3*i+2] - lbheatforce[tpos*3*lbsy.nf+3*i+2] - postequil * (lbbdforce[3*i+2]+lboscilforce[3*i+2]*freq);
        }
      }
      break;
  }
  return 0;
}


int fD3Q27OF1(long tpos, int prop)
{
  long tpos1;
  int qdim = lbsy.nf+lbsy.nc+lbsy.nt;
  int l1, l2, l3, l4, l5, l6, l7, l8, l9;
  tpos1 = tpos;
  l1 = 0; l2 = 0; l3 = 0; l4 = 0; l5 = 0; l6 = 0; l7 = 0; l8 = 0; l9 = 0;
  switch (prop) {
    case PST:
      tpos1 = fNextStep(0, 1, 0, tpos);
      l1 = 5; l2 = 12; l3 = 13; l4 = 15; l5 = 17; l6 = 21; l7 = 22; l8 = 23; l9 = 24;
      break;
    case PSD:
      tpos1 = fNextStep(0, -1, 0, tpos);
      l1 = 2; l2 = 4; l3 = 8; l4 = 9; l5 = 10; l6 = 11; l7 = 18; l8 = 25; l9 = 26;
      break;
    case PSL:
      tpos1 = fNextStep(-1, 0, 0, tpos);
      l1 = 1; l2 = 4; l3 = 5; l4 = 6; l5 = 7; l6 = 10; l7 = 11; l8 = 12; l9 = 13;
      break;
    case PSR:
      tpos1 = fNextStep(1, 0, 0, tpos);
      l1 = 14; l2 = 17; l3 = 18; l4 = 19; l5 = 20; l6 = 23; l7 = 24; l8 = 25; l9 = 26;
      break;
    case PSF:
      tpos1 = fNextStep(0, 0, 1, tpos);
      l1 = 7; l2 = 9; l3 = 11; l4 = 13; l5 = 16; l6 = 19; l7 = 21; l8 = 23; l9 = 25;
      break;
    case PSB:
      tpos1 = fNextStep(0, 0, -1, tpos);
      l1 = 3; l2 = 6; l3 = 8; l4 = 10; l5 = 12; l6 = 20; l7 = 22; l8 = 24; l9 = 26;
      break;
  }
    
  for(int i=0; i<qdim; i++) {
    lbf[tpos*lbsitelength+i+l1*qdim] = lbf[tpos1*lbsitelength+i+l1*qdim];
    lbf[tpos*lbsitelength+i+l2*qdim] = lbf[tpos1*lbsitelength+i+l2*qdim];
    lbf[tpos*lbsitelength+i+l3*qdim] = lbf[tpos1*lbsitelength+i+l3*qdim];
    lbf[tpos*lbsitelength+i+l4*qdim] = lbf[tpos1*lbsitelength+i+l4*qdim];
    lbf[tpos*lbsitelength+i+l5*qdim] = lbf[tpos1*lbsitelength+i+l5*qdim];
    lbf[tpos*lbsitelength+i+l6*qdim] = lbf[tpos1*lbsitelength+i+l6*qdim];
    lbf[tpos*lbsitelength+i+l7*qdim] = lbf[tpos1*lbsitelength+i+l7*qdim];
    lbf[tpos*lbsitelength+i+l8*qdim] = lbf[tpos1*lbsitelength+i+l8*qdim];
    lbf[tpos*lbsitelength+i+l9*qdim] = lbf[tpos1*lbsitelength+i+l9*qdim];
  }
  return 0;
}

int fD3Q27OF2(long tpos, int prop)
{
  long tpos1, tpos2;
  int qdim = lbsy.nf+lbsy.nc+lbsy.nt;
  int l1, l2, l3, l4, l5, l6, l7, l8, l9;
  tpos1 = tpos; tpos2 = tpos;
  l1 = 0; l2 = 0; l3 = 0; l4 = 0; l5 = 0; l6 = 0; l7 = 0; l8 = 0; l9 = 0;
  switch (prop) {
    case PST:
      tpos1 = fNextStep(0, 1, 0, tpos);
      tpos2 = fNextStep(0, 2, 0, tpos);
      l1 = 5; l2 = 12; l3 = 13; l4 = 15; l5 = 17; l6 = 21; l7 = 22; l8 = 23; l9 = 24;
      break;
    case PSD:
      tpos1 = fNextStep(0, -1, 0, tpos);
      tpos2 = fNextStep(0, -2, 0, tpos);
      l1 = 2; l2 = 4; l3 = 8; l4 = 9; l5 = 10; l6 = 11; l7 = 18; l8 = 25; l9 = 26;
      break;
    case PSL:
      tpos1 = fNextStep(-1, 0, 0, tpos);
      tpos2 = fNextStep(-2, 0, 0, tpos);
      l1 = 1; l2 = 4; l3 = 5; l4 = 6; l5 = 7; l6 = 10; l7 = 11; l8 = 12; l9 = 13;
      break;
    case PSR:
      tpos1 = fNextStep(1, 0, 0, tpos);
      tpos2 = fNextStep(2, 0, 0, tpos);
      l1 = 14; l2 = 17; l3 = 18; l4 = 19; l5 = 20; l6 = 23; l7 = 24; l8 = 25; l9 = 26;
      break;
    case PSF:
      tpos1 = fNextStep(0, 0, 1, tpos);
      tpos2 = fNextStep(0, 0, 2, tpos);
      l1 = 7; l2 = 9; l3 = 11; l4 = 13; l5 = 16; l6 = 19; l7 = 21; l8 = 23; l9 = 25;
      break;
    case PSB:
      tpos1 = fNextStep(0, 0, -1, tpos);
      tpos2 = fNextStep(0, 0, -2, tpos);
      l1 = 3; l2 = 6; l3 = 8; l4 = 10; l5 = 12; l6 = 20; l7 = 22; l8 = 24; l9 = 26;
      break;
  }
    
  for(int i=0; i<qdim; i++) {
    lbf[tpos*lbsitelength+i+l1*qdim] = 2.0*lbf[tpos1*lbsitelength+i+l1*qdim]-lbf[tpos2*lbsitelength+i+l1*qdim];
    lbf[tpos*lbsitelength+i+l2*qdim] = 2.0*lbf[tpos1*lbsitelength+i+l2*qdim]-lbf[tpos2*lbsitelength+i+l2*qdim];
    lbf[tpos*lbsitelength+i+l3*qdim] = 2.0*lbf[tpos1*lbsitelength+i+l3*qdim]-lbf[tpos2*lbsitelength+i+l3*qdim];
    lbf[tpos*lbsitelength+i+l4*qdim] = 2.0*lbf[tpos1*lbsitelength+i+l4*qdim]-lbf[tpos2*lbsitelength+i+l4*qdim];
    lbf[tpos*lbsitelength+i+l5*qdim] = 2.0*lbf[tpos1*lbsitelength+i+l5*qdim]-lbf[tpos2*lbsitelength+i+l5*qdim];
    lbf[tpos*lbsitelength+i+l6*qdim] = 2.0*lbf[tpos1*lbsitelength+i+l6*qdim]-lbf[tpos2*lbsitelength+i+l6*qdim];
    lbf[tpos*lbsitelength+i+l7*qdim] = 2.0*lbf[tpos1*lbsitelength+i+l7*qdim]-lbf[tpos2*lbsitelength+i+l7*qdim];
    lbf[tpos*lbsitelength+i+l8*qdim] = 2.0*lbf[tpos1*lbsitelength+i+l8*qdim]-lbf[tpos2*lbsitelength+i+l8*qdim];
    lbf[tpos*lbsitelength+i+l9*qdim] = 2.0*lbf[tpos1*lbsitelength+i+l9*qdim]-lbf[tpos2*lbsitelength+i+l9*qdim];
  }
  return 0;
}

int fFixedSpeedFluid(long tpos, int prop, int type, double *uwall)
{
  long rpos;
  double freq, T, dx, dy, dz, c1=1.0/3.0;
  int xx, zz;
    
  // produce boundary with fixed speed: set up condition based on direction
    
  T = 0.0;
  dx = 0.0; dy = 0.0; dz = 0.0;
  rpos = 0;
  if(lbsy.nd>2) {
    switch (prop) {
      case PST: // PST
      case CCTRB: // CCTRB
      case CCTLB: // CCTLB
      case CCTRF: // CCTRF
      case CCTLF: // CCTLF
      case CETR: // CETR
      case CETL: // CETL
      case CETF: // CETF
      case CETB: // CETB
        if (prop==21 || prop==47 || prop==51)
          xx = 0;
        else
          xx = (prop%2==0)?-1:1;
        if (prop==21 || prop==43 || prop==44)
          zz = 0;
        else
          zz = (prop>30 && prop<51)?1:-1;
        rpos = fNextStep(xx, 1, zz, tpos);
        if (prop==21) {
          dx = 0.0; dy = -1.0; dz = 0.0;
        }
        else if (prop<43) {
          dx = -xx * c1; dy = -c1; dz = -zz * c1;
        }
        else {
          dx = -0.5 * xx; dy = -0.5; dz = -0.5 * zz;
        }
        if(lbsy.nt>0)
          T = (type%2==0)?fGetTemperatureSite(rpos):lbbott;
        else
          T = lbsyst;
        freq = (lbbotvbc==1)*sin(lbbotvfq*(lbcurstep-lbequstep));
        uwall[0] = lbbotv[0]+lbbotvoscil[0]*freq; uwall[1] = lbbotv[1]+lbbotvoscil[1]*freq; uwall[2] = lbbotv[2]+lbbotvoscil[2]*freq;
        break;
      case PSD: // PSD
      case CCDLB: // CCDLB
      case CCDRB: // CCDRB
      case CCDLF: // CCDLF
      case CCDRF: // CCDRF
      case CEDL: // CEDL
      case CEDR: // CEDR
      case CEDF: // CEDF
      case CEDB: // CEDB
        if (prop==22 || prop==49 || prop==53)
          xx = 0;
        else
          xx = (prop%2==0)?1:-1;
        if (prop==22 || prop==45 || prop==46)
          zz = 0;
        else
          zz = (prop>30 && prop<51)?1:-1;
        rpos = fNextStep(xx, -1, zz, tpos);
        if (prop==22) {
          dx = 0.0; dy = 1.0; dz = 0.0;
        }
        else if (prop<43) {
          dx = -xx * c1; dy = c1; dz = -zz * c1;
        }
        else {
          dx = -0.5 * xx; dy = 0.5; dz = -0.5 * zz;
        }
        if(lbsy.nt>0)
          T = (type%2==0)?fGetTemperatureSite(rpos):lbtopt;
        else
          T = lbsyst;
        freq = (lbtopvbc==1)*sin(lbtopvfq*(lbcurstep-lbequstep));
        uwall[0] = lbtopv[0]+lbtopvoscil[0]*freq; uwall[1] = lbtopv[1]+lbtopvoscil[1]*freq; uwall[2] = lbtopv[2]+lbtopvoscil[2]*freq;
        break;
      case PSL: // PSL
      case CELF: // CELF
      case CELB: // CELB
        if (prop==23) {
          rpos = fNextStep(-1, 0, 0, tpos);
          dx = 1.0; dy = 0.0; dz = 0.0;
        }
        else {
          rpos = fNextStep(-1, 0, (prop==48)?1:-1, tpos);
          dx = 0.5; dy = 0.0; dz = (prop==48)?-0.5:0.5;
        }
        if(lbsy.nt>0)
          T = (type%2==0)?fGetTemperatureSite(rpos):lbrigt;
        else
          T = lbsyst;
        freq = (lbrigvbc==1)*sin(lbrigvfq*(lbcurstep-lbequstep));
        uwall[0] = lbrigv[0]+lbrigvoscil[0]*freq; uwall[1] = lbrigv[1]+lbrigvoscil[1]*freq; uwall[2] = lbrigv[2]+lbrigvoscil[2]*freq;
        break;
      case PSR: // PSR
      case CERF: // CERF
      case CERB: // CERB
        if (prop==24) {
          rpos = fNextStep(1, 0, 0, tpos);
          dx = -1.0; dy = 0.0; dz = 0.0;
        }
        else {
          rpos = fNextStep(1, 0, (prop==50)?1:-1, tpos);
          dx = -0.5; dy = 0.0; dz = (prop==50)?-0.5:0.5;
        }
        if(lbsy.nt>0)
          T = (type%2==0)?fGetTemperatureSite(rpos):lbleft;
        else
          T = lbsyst;
        freq = (lblefvbc==1)*sin(lblefvfq*(lbcurstep-lbequstep));
        uwall[0] = lblefv[0]+lblefvoscil[0]*freq; uwall[1] = lblefv[1]+lblefvoscil[1]*freq; uwall[2] = lblefv[2]+lblefvoscil[2]*freq;
        break;
      case PSF: // PSF
        rpos = fNextStep(0, 0, -1, tpos);
        if(lbsy.nt>0)
          T = (type%2==0)?fGetTemperatureSite(rpos):lbbact;
        else
          T = lbsyst;
        freq = (lbbacvbc==1)*sin(lbbacvfq*(lbcurstep-lbequstep));
        uwall[0] = lbbacv[0]+lbbacvoscil[0]*freq; uwall[1] = lbbacv[1]+lbbacvoscil[1]*freq; uwall[2] = lbfrov[2]+lbbacvoscil[2]*freq;
        break;
      case PSB: // PSB
        rpos = fNextStep(0, 0, 1, tpos);
        if(lbsy.nt>0)
          T = (type%2==0)?fGetTemperatureSite(rpos):lbfrot;
        else
          T = lbsyst;
        freq = (lbfrovbc==1)*sin(lbfrovfq*(lbcurstep-lbequstep));
        uwall[0] = lbfrov[0]+lbfrovoscil[0]*freq; uwall[1] = lbfrov[1]+lbfrovoscil[1]*freq; uwall[2] = lbfrov[2]+lbfrovoscil[2]*freq;
        break;
    }
  }
  else {
    switch (prop) {
      case CCTRF: // CCTRF
      case CCTLF: // CCTLF
      case CETF: // CETF
        if(prop==47) {
          rpos = fNextStep(0, 1, 0, tpos);
          dx = 0.0; dy = -1.0;
        }
        else {
          rpos = fNextStep((prop==31)?1:-1, 1, 0, tpos);
          dx = (prop==31)?-0.5:0.5; dy = -0.5;
        }
        if(lbsy.nt>0)
          T = (type%2==0)?fGetTemperatureSite(rpos):lbbott;
        else
          T = lbsyst;
        freq = (lbbotvbc==1)*sin(lbbotvfq*(lbcurstep-lbequstep));
        uwall[0] = lbbotv[0]+lbbotvoscil[0]*freq; uwall[1] = lbbotv[1]+lbbotvoscil[1]*freq; uwall[2] = 0.0;
        break;
      case CELF: // CELF
        rpos = fNextStep(-1, 0, 0, tpos);
        if(lbsy.nt>0)
          T = (type%2==0)?fGetTemperatureSite(rpos):lbrigt;
        else
          T = lbsyst;
        freq = (lbrigvbc==1)*sin(lbrigvfq*(lbcurstep-lbequstep));
        uwall[0] = lbrigv[0]+lbrigvoscil[0]*freq; uwall[1] = lbrigv[1]+lbrigvoscil[1]*freq; uwall[2] = 0.0;
        break;
      case CCDLF: // CCDLF
      case CCDRF: // CCDRF
      case CEDF: // CEDF
        if(prop==49) {
          rpos = fNextStep(0, -1, 0, tpos);
          dx = 0.0; dy = 1.0;
        }
        else {
          rpos = fNextStep((prop==33)?-1:1, -1, 0, tpos);
          dx = (prop==33)?0.5:-0.5; dy = 0.5;
        }
        if(lbsy.nt>0)
          T = (type%2==0)?fGetTemperatureSite(rpos):lbtopt;
        else
          T = lbsyst;
        freq = (lbtopvbc==1)*sin(lbtopvfq*(lbcurstep-lbequstep));
        uwall[0] = lbtopv[0]+lbtopvoscil[0]*freq; uwall[1] = lbtopv[1]+lbtopvoscil[1]*freq; uwall[2] = 0.0;
        break;
      case CERF: // CERF
        rpos = fNextStep(1, 0, 0, tpos);
        if(lbsy.nt>0)
          T = (type%2==0)?fGetTemperatureSite(rpos):lbleft;
        else
          T = lbsyst;
        freq = (lblefvbc==1)*sin(lblefvfq*(lbcurstep-lbequstep));
        uwall[0] = lblefv[0]+lblefvoscil[0]*freq; uwall[1] = lblefv[1]+lblefvoscil[1]*freq; uwall[2] = 0.0;
        break;
    }
  }

  switch (lbbctyp) {
    case 0:
      // Zou/He boundary condition
      if(lbsy.nq == 9)
        fD2Q9VFZouHe(tpos, rpos, prop, uwall, dx, dy);
      else if(lbsy.nq == 15)
        fD3Q15VFZouHe(tpos, rpos, prop, uwall, dx, dy, dz);
      else if(lbsy.nq == 19)
        fD3Q19VFZouHe(tpos, rpos, prop, uwall, dx, dy, dz);
      else if(lbsy.nq == 27)
        fD3Q27VFZouHe(tpos, rpos, prop, uwall);
      else if(lbdm.rank ==0) {
        cout << "the boundary condition for D" << lbsy.nd << "Q" << lbsy.nq
             << " model has not been defined" << endl;
        if(lbsy.nd == 2)
          cout << "the D2Q9 model can be used" << endl;
        else
          cout << "the D3Q15, D3Q19 or D3Q27 models can be used" << endl;
        exit(1);
      }
      break;
    case 1:
      // Inamuro boundary condition
      if(lbsy.nq == 9)
        fD2Q9VFInamuro(tpos, rpos, prop, uwall, dx, dy, T);
      else if(lbsy.nq == 15)
        fD3Q15VFInamuro(tpos, rpos, prop, uwall, dx, dy, dz, T);
      else if(lbsy.nq == 19)
        fD3Q19VFInamuro(tpos, rpos, prop, uwall, dx, dy, dz, T);
      else if(lbsy.nq == 27)
        fD3Q27VFInamuro(tpos, rpos, prop, uwall);
      else if(lbdm.rank ==0) {
        cout << "the boundary condition for D" << lbsy.nd << "Q" << lbsy.nq
             << " model has not been defined" << endl;
        if(lbsy.nd == 2)
          cout << "the D2Q9 model can be used" << endl;
        else
          cout << "the D3Q15, D3Q19 or D3Q27 models can be used" << endl;
        exit(1);
      }
      break;
    case 2:
      // Regularised boundary condition
      if(lbsy.nq == 9)
        fD2Q9VFRegular(tpos, rpos, prop, uwall, dx, dy, T);
      else if(lbsy.nq == 15)
        fD3Q15VFRegular(tpos, rpos, prop, uwall, dx, dy, dz, T);
      else if(lbsy.nq == 19)
        fD3Q19VFRegular(tpos, rpos, prop, uwall, dx, dy, dz, T);
      else if(lbsy.nq == 27)
        fD3Q27VFRegular(tpos, rpos, prop, uwall);
      else if(lbdm.rank ==0) {
        cout << "the boundary condition for D" << lbsy.nd << "Q" << lbsy.nq
             << " model has not been defined" << endl;
        if(lbsy.nd == 2)
          cout << "the D2Q9 model can be used" << endl;
        else
          cout << "the D3Q15, D3Q19 or D3Q27 models can be used" << endl;
        exit(1);
      }
      break;
    case 10:
      // Simplified Zou/He boundary condition
      if(lbsy.nq == 9)
        fD2Q9VFSimpleZouHe(tpos, rpos, prop, uwall, dx, dy);
      else if(lbsy.nq == 15)
        fD3Q15VFSimpleZouHe(tpos, rpos, prop, uwall, dx, dy, dz);
      else if(lbsy.nq == 19)
        fD3Q19VFSimpleZouHe(tpos, rpos, prop, uwall, dx, dy, dz);
      else if(lbsy.nq == 27)
        fD3Q27VFSimpleZouHe(tpos, rpos, prop, uwall);
      else if(lbdm.rank ==0) {
        cout << "the boundary condition for D" << lbsy.nd << "Q" << lbsy.nq
             << " model has not been defined" << endl;
        if(lbsy.nd == 2)
          cout << "the D2Q9 model can be used" << endl;
        else
          cout << "the D3Q15, D3Q19 or D3Q27 models can be used" << endl;
        exit(1);
      }
      break;
    case 11:
      // Kinetic boundary condition
      if(lbsy.nq == 9)
        fD2Q9VFKinetic(tpos, rpos, prop, uwall, dx, dy, T);
      else if(lbsy.nq == 15)
        fD3Q15VFKinetic(tpos, rpos, prop, uwall, dx, dy, dz, T);
      else if(lbsy.nq == 19)
        fD3Q19VFKinetic(tpos, rpos, prop, uwall, dx, dy, dz, T);
      else if(lbsy.nq == 27)
        fD3Q27VFKinetic(tpos, rpos, prop, uwall);
      else if(lbdm.rank ==0) {
        cout << "the boundary condition for D" << lbsy.nd << "Q" << lbsy.nq
             << " model has not been defined" << endl;
        if(lbsy.nd == 2)
          cout << "the D2Q9 model can be used" << endl;
        else
          cout << "the D3Q15, D3Q19 or D3Q27 models can be used" << endl;
        exit(1);
      }
      break;
  }
  
  return 0;
}

int fFixedDensityFluid(long tpos, int prop, int type, double *uwall)
{
  long rpos;
  double T;
  double p0[lbsy.nf];
  int yy, zz;

  // produce boundary with fixed density/pressure: set up condition based on direction
    
  uwall[0]=0.0; uwall[1]=0.0; uwall[2]=0.0;
  T = 0.0;
  rpos = 0;
  if(lbsy.nd>2) {
    switch (prop) {
      case PST: // PST
      case CETF: // CETF
      case CETB: // CETB
        if(prop==21)
          rpos = fNextStep(0, 1, 0, tpos);
        else
          rpos = fNextStep(0, 1, (prop==47)?1:-1, tpos);
        if(lbsy.nt>0)
          T = (type%2==0)?fGetTemperatureSite(rpos):lbbott;
        else
          T = lbsyst;
        for(int i=0; i<lbsy.nf; i++)
          p0[i] = lbbotp[i];
        break;
      case PSD: // PSD
      case CEDF: // CEDF
      case CEDB: // CEDB
        if(prop==22)
          rpos = fNextStep(0, -1, 0, tpos);
        else
          rpos = fNextStep(0, -1, (prop==49)?1:-1, tpos);
        if(lbsy.nt>0)
          T = (type%2==0)?fGetTemperatureSite(rpos):lbtopt;
        else
          T = lbsyst;
        for(int i=0; i<lbsy.nf; i++)
          p0[i] = lbtopp[i];
        break;
      case PSL: // PSL
      case CCTLB: // CCTLB
      case CCDLB: // CCDLB
      case CCTLF: // CCTLF
      case CCDLF: // CCDLF
      case CETL: // CETL
      case CEDL: // CEDL
      case CELF: // CELF
      case CELB: // CELB
        if (prop==23 || prop>47)
          yy = 0;
        else
          yy = (prop%2==0)?1:-1;
        if (prop==23 || (prop>42 && prop<47))
          zz = 0;
        else
          zz = (prop>30 && prop<51)?1:-1;
        rpos = fNextStep(-1, yy, zz, tpos);
        if(lbsy.nt>0)
          T = (type%2==0)?fGetTemperatureSite(rpos):lbrigt;
        else
          T = lbsyst;
        for(int i=0; i<lbsy.nf; i++)
          p0[i] = lbrigp[i];
        break;
      case PSR: // PSR
      case CCTRB: // CCTRB
      case CCDRB: // CCDRB
      case CCTRF: // CCTRF
      case CCDRF: // CCDRF
      case CETR: // CETR
      case CEDR: // CEDR
      case CERF: // CERF
      case CERB: // CERB
        if (prop==24 || prop>47)
          yy = 0;
        else
          yy = (prop%2==0)?1:-1;
        if (prop==24 || (prop>42 && prop<47))
          zz = 0;
        else
          zz = (prop>30 && prop<51)?1:-1;
        rpos = fNextStep(1, yy, zz, tpos);
        if(lbsy.nt>0)
          T = (type%2==0)?fGetTemperatureSite(rpos):lbleft;
        else
          T = lbsyst;
        for(int i=0; i<lbsy.nf; i++)
          p0[i] = lblefp[i];
        break;
      case PSF: // PSF
        rpos = fNextStep(0, 0, -1, tpos);
        if(lbsy.nt>0)
          T = (type%2==0)?fGetTemperatureSite(rpos):lbbact;
        else
          T = lbsyst;
        for(int i=0; i<lbsy.nf; i++)
          p0[i] = lbbacp[i];
        break;
      case PSB: // PSB
        rpos = fNextStep(0, 0, 1, tpos);
        if(lbsy.nt>0)
          T = (type%2==0)?fGetTemperatureSite(rpos):lbfrot;
        else
          T = lbsyst;
        for(int i=0; i<lbsy.nf; i++)
          p0[i] = lbfrop[i];
        break;
    }
  }
  else {
    switch (prop) {
      case CETF: // CETF
        rpos = fNextStep(0, 1, 0, tpos);
        if(lbsy.nt>0)
          T = (type%2==0)?fGetTemperatureSite(rpos):lbbott;
        else
          T = lbsyst;
        for(int i=0; i<lbsy.nf; i++)
          p0[i] = lbbotp[i];
        break;
      case CCTLF: // CCTLF
      case CCDLF: // CCDLF
      case CELF: // CELF
        if(prop==48)
          rpos = fNextStep(-1, 0, 0, tpos);
        else
          rpos = fNextStep(-1, (prop==32)?1:-1, 0, tpos);
        if(lbsy.nt>0)
          T = (type%2==0)?fGetTemperatureSite(rpos):lbrigt;
        else
          T = lbsyst;
        for(int i=0; i<lbsy.nf; i++)
          p0[i] = lbrigp[i];
        break;
      case CEDF: // CEDF
        rpos = fNextStep(0, -1, 0, tpos);
        if(lbsy.nt>0)
          T = (type%2==0)?fGetTemperatureSite(rpos):lbtopt;
        else
          T = lbsyst;
        for(int i=0; i<lbsy.nf; i++)
          p0[i] = lbtopp[i];
        break;
      case CCTRF: // CCTRF
      case CCDRF: // CCDRF
      case CERF: // CERF
        if(prop==50)
          rpos = fNextStep(1, 0, 0, tpos);
        else
          rpos = fNextStep(1, (prop==31)?1:-1, 0, tpos);
        if(lbsy.nt>0)
          T = (type%2==0)?fGetTemperatureSite(rpos):lbleft;
        else
          T = lbsyst;
        for(int i=0; i<lbsy.nf; i++)
          p0[i] = lblefp[i];
        break;
    }
  }
  
  switch (lbbctyp) {
    case 0:
      // Zou/He boundary condition
      if(lbsy.nq == 9)
        fD2Q9PFZouHe(tpos, prop, p0, uwall);
      else if(lbsy.nq == 15)
        fD3Q15PFZouHe(tpos, prop, p0, uwall);
      else if(lbsy.nq == 19)
        fD3Q19PFZouHe(tpos, prop, p0, uwall);
      else if(lbsy.nq == 27)
        fD3Q27PFZouHe(tpos, prop, p0, uwall);
      else if(lbdm.rank ==0) {
        cout << "the boundary condition for D" << lbsy.nd << "Q" << lbsy.nq
             << " model has not been defined" << endl;
        if(lbsy.nd == 2)
          cout << "the D2Q9 model can be used" << endl;
        else
          cout << "the D3Q15, D3Q19 or D3Q27 models can be used" << endl;
        exit(1);
      }
      break;
    case 1:
      // Inamuro boundary condition
      if(lbsy.nq == 9)
        fD2Q9PFInamuro(tpos, prop, p0, uwall, T);
      else if(lbsy.nq == 15)
        fD3Q15PFInamuro(tpos, prop, p0, uwall, T);
      else if(lbsy.nq == 19)
        fD3Q19PFInamuro(tpos, prop, p0, uwall, T);
      else if(lbsy.nq == 27)
        fD3Q27PFInamuro(tpos, prop, p0, uwall);
      else if(lbdm.rank ==0) {
        cout << "the boundary condition for D" << lbsy.nd << "Q" << lbsy.nq
             << " model has not been defined" << endl;
        if(lbsy.nd == 2)
          cout << "the D2Q9 model can be used" << endl;
        else
          cout << "the D3Q15, D3Q19 or D3Q27 models can be used" << endl;
        exit(1);
      }
      break;
    case 2:
      // Regularised boundary condition
      if(lbsy.nq == 9)
        fD2Q9PFRegular(tpos, prop, p0, uwall, T);
      else if(lbsy.nq == 15)
        fD3Q15PFRegular(tpos, prop, p0, uwall, T);
      else if(lbsy.nq == 19)
        fD3Q19PFRegular(tpos, prop, p0, uwall, T);
      else if(lbsy.nq == 27)
        fD3Q27PFRegular(tpos, prop, p0, uwall);
      else if(lbdm.rank ==0) {
        cout << "the boundary condition for D" << lbsy.nd << "Q" << lbsy.nq
             << " model has not been defined" << endl;
        if(lbsy.nd == 2)
          cout << "the D2Q9 model can be used" << endl;
        else
          cout << "the D3Q15, D3Q19 or D3Q27 models can be used" << endl;
        exit(1);
      } 
      break;
    case 10:
      // Simplified Zou/He boundary condition
      if(lbsy.nq == 9)
        fD2Q9PFSimpleZouHe(tpos, prop, p0, uwall);
      else if(lbsy.nq == 15)
        fD3Q15PFSimpleZouHe(tpos, prop, p0, uwall);
      else if(lbsy.nq == 19)
        fD3Q19PFSimpleZouHe(tpos, prop, p0, uwall);
      else if(lbsy.nq == 27)
        fD3Q27PFSimpleZouHe(tpos, prop, p0, uwall);
      else if(lbdm.rank ==0) {
        cout << "the boundary condition for D" << lbsy.nd << "Q" << lbsy.nq
             << " model has not been defined" << endl;
        if(lbsy.nd == 2)
          cout << "the D2Q9 model can be used" << endl;
        else
          cout << "the D3Q15, D3Q19 or D3Q27 models can be used" << endl;
        exit(1);
      }
      break;
    case 11:
      // Kinetic boundary condition
      if(lbsy.nq == 9)
        fD2Q9PFKinetic(tpos, prop, p0, uwall, T);
      else if(lbsy.nq == 15)
        fD3Q15PFKinetic(tpos, prop, p0, uwall, T);
      else if(lbsy.nq == 19)
        fD3Q19PFKinetic(tpos, prop, p0, uwall, T);
      else if(lbsy.nq == 27)
        fD3Q27PFKinetic(tpos, prop, p0, uwall);
      else if(lbdm.rank ==0) {
        cout << "the boundary condition for D" << lbsy.nd << "Q" << lbsy.nq
             << " model has not been defined" << endl;
        if(lbsy.nd == 2)
          cout << "the D2Q9 model can be used" << endl;
        else
          cout << "the D3Q15, D3Q19 or D3Q27 models can be used" << endl;
        exit(1);
      }
      break;
  }
  
  return 0;
}

int fFixedSoluteConcen(long tpos, int prop, double *uwall)
{

  double p0[lbsy.nc];
    
  // produce boundary with fixed solute concentration: set up condition based on direction

  if(lbsy.nc>0) {
      
    if (lbsy.nd>2) {
      switch (prop) {
        case PST: // PST
        case CCTRB: // CCTRB
        case CCTLB: // CCTLB
        case CCTRF: // CCTRF
        case CCTLF: // CCTLF
        case CETR: // CETR
        case CETL: // CETL
        case CETF: // CETF
        case CETB: // CETB
          for(int i=0; i<lbsy.nc; i++)
            p0[i] = lbbotc[i];
          break;
        case PSD: // PSD
        case CCDLB: // CCDLB
        case CCDRB: // CCDRB
        case CCDLF: // CCDLF
        case CCDRF: // CCDRF
        case CEDL: // CEDL
        case CEDR: // CEDR
        case CEDF: // CEDF
        case CEDB: // CEDB
          for(int i=0; i<lbsy.nc; i++)
            p0[i] = lbtopc[i];
          break;
        case PSL: // PSL
        case CELF: // CELF
        case CELB: // CELB
          for(int i=0; i<lbsy.nc; i++)
            p0[i] = lbrigc[i];
          break;
        case PSR: // PSR
        case CERF: // CERF
        case CERB: // CERB
          for(int i=0; i<lbsy.nc; i++)
            p0[i] = lblefc[i];
          break;
        case PSF: // PSF
          for(int i=0; i<lbsy.nc; i++)
            p0[i] = lbbacc[i];
          break;
        case PSB: // PSB
          for(int i=0; i<lbsy.nc; i++)
            p0[i] = lbfroc[i];
          break;
      }
    }
    else {
      switch (prop) {
        case CETF: // CETF
          for(int i=0; i<lbsy.nc; i++)
            p0[i] = lbbotc[i];
          break;
        case CCTLF: // CCTLF
        case CCDLF: // CCDLF
        case CELF: // CELF
          for(int i=0; i<lbsy.nc; i++)
            p0[i] = lbrigc[i];
          break;
        case CEDF: // CEDF
          for(int i=0; i<lbsy.nc; i++)
            p0[i] = lbtopc[i];
          break;
        case CCTRF: // CCTRF
        case CCDRF: // CCDRF
        case CERF: // CERF
          for(int i=0; i<lbsy.nc; i++)
            p0[i] = lblefc[i];
          break;
      }
    }

    switch (lbsbctyp) {
      case 0:
      // Zou/He boundary condition
        if(lbsy.nq == 9)
          fD2Q9PCZouHe(tpos, prop, p0, uwall);
        else if(lbsy.nq == 15)
          fD3Q15PCZouHe(tpos, prop, p0, uwall);
        else if(lbsy.nq == 19)
          fD3Q19PCZouHe(tpos, prop, p0, uwall);
        else if(lbsy.nq == 27)
          fD3Q27PCZouHe(tpos, prop, p0, uwall);
        else if(lbdm.rank ==0) {
          cout << "the boundary condition for D" << lbsy.nd << "Q" << lbsy.nq
               << " model has not been defined" << endl;
          if(lbsy.nd == 2)
            cout << "the D2Q9 model can be used" << endl;
          else
            cout << "the D3Q15, D3Q19 or D3Q27 models can be used" << endl;
          exit(1);
        }
        break;
      case 1:
      // Inamuro boundary condition
        if(lbsy.nq == 9)
          fD2Q9PCInamuro(tpos, prop, p0, uwall);
        else if(lbsy.nq == 15)
          fD3Q15PCInamuro(tpos, prop, p0, uwall);
        else if(lbsy.nq == 19)
          fD3Q19PCInamuro(tpos, prop, p0, uwall);
        else if(lbsy.nq == 27)
          fD3Q27PCInamuro(tpos, prop, p0, uwall);
        else if(lbdm.rank ==0) {
          cout << "the boundary condition for D" << lbsy.nd << "Q" << lbsy.nq
               << " model has not been defined" << endl;
          if(lbsy.nd == 2)
            cout << "the D2Q9 model can be used" << endl;
          else
            cout << "the D3Q15, D3Q19 or D3Q27 models can be used" << endl;
          exit(1);
        }
        break;
    }
  }
  return 0;
}

int fFixedTemperature(long tpos, int prop, double *uwall)
{
  double p0;

  // produce boundary with fixed temperature: set up condition based on direction
    
  if(lbsy.nt>0) {
      
    p0 = lbsyst;
    if (lbsy.nd>2) {
      switch (prop) {
        case PST: // PST
        case CCTRB: // CCTRB
        case CCTLB: // CCTLB
        case CCTRF: // CCTRF
        case CCTLF: // CCTLF
        case CETR: // CETR
        case CETL: // CETL
        case CETF: // CETF
        case CETB: // CETB
          p0 = lbbott;
          break;
        case PSD: // PSD
        case CCDLB: // CCDLB
        case CCDRB: // CCDRB
        case CCDLF: // CCDLF
        case CCDRF: // CCDRF
        case CEDL: // CEDL
        case CEDR: // CEDR
        case CEDF: // CEDF
        case CEDB: // CEDB
          p0 = lbtopt;
          break;
        case PSL: // PSL
        case CELF: // CELF
        case CELB: // CELB
          p0 = lbrigt;
          break;
        case PSR: // PSR
        case CERF: // CERF
        case CERB: // CERB
          p0 = lbleft;
          break;
        case PSF: // PSF
          p0 = lbbact;
          break;
        case PSB: // PSB
          p0 = lbfrot;
          break;
      }
    }
    else {
      switch (prop) {
        case CETF: // CETF
          p0 = lbbott;
          break;
        case CCTLF: // CCTLF
        case CCDLF: // CCDLF
        case CELF: // CELF
          p0 = lbrigt;
          break;
        case CEDF: // CEDF
          p0 = lbtopt;
          break;
        case CCTRF: // CCTRF
        case CCDRF: // CCDRF
        case CERF: // CERF
          p0 = lbleft;
          break;
      }
    }
    
    switch (lbtbctyp) {
      case 0:
      // Zou/He boundary condition
        if(lbsy.nq == 9)
          fD2Q9PTZouHe(tpos, prop, p0, uwall);
        else if(lbsy.nq == 15)
          fD3Q15PTZouHe(tpos, prop, p0, uwall);
        else if(lbsy.nq == 19)
          fD3Q19PTZouHe(tpos, prop, p0, uwall);
        else if(lbsy.nq == 27)
          fD3Q27PTZouHe(tpos, prop, p0, uwall);
        else if(lbdm.rank ==0) {
          cout << "the boundary condition for D" << lbsy.nd << "Q" << lbsy.nq
               << " model has not been defined" << endl;
          if(lbsy.nd == 2)
            cout << "the D2Q9 model can be used" << endl;
          else
            cout << "the D3Q15, D3Q19 or D3Q27 models can be used" << endl;
          exit(1);
        }
        break;
      case 1:
      // Inamuro boundary condition
        if(lbsy.nq == 9)
          fD2Q9PTInamuro(tpos, prop, p0, uwall);
        else if(lbsy.nq == 15)
          fD3Q15PTInamuro(tpos, prop, p0, uwall);
        else if(lbsy.nq == 19)
          fD3Q19PTInamuro(tpos, prop, p0, uwall);
        else if(lbsy.nq == 27)
          fD3Q27PTInamuro(tpos, prop, p0, uwall);
        else if(lbdm.rank ==0) {
          cout << "the boundary condition for D" << lbsy.nd << "Q" << lbsy.nq
               << " model has not been defined" << endl;
          if(lbsy.nd == 2)
            cout << "the D2Q9 model can be used" << endl;
          else
            cout << "the D3Q15, D3Q19 or D3Q27 models can be used" << endl;
          exit(1);
        }
        break;
    }
      
  }
  return 0;
}

int fOutFlow(long tpos, int prop)
{
    // set all unknown distribution functions at outlet boundary to give Neumann boundary condition
    // (either copy neighbours or extrapolate from neighbour and nearest neighbour)

  switch (lbgradord) {
    case 1:
      if(lbsy.nq == 9)
        fD2Q9OF1(tpos, prop);
      else if(lbsy.nq == 15)
        fD3Q15OF1(tpos, prop);
      else if(lbsy.nq == 19)
        fD3Q19OF1(tpos, prop);
      else if(lbsy.nq == 27)
        fD3Q27OF1(tpos, prop);
      else if(lbdm.rank ==0) {
        cout << "the boundary condition for D" << lbsy.nd << "Q" << lbsy.nq
             << " model has not been defined" << endl;
        if(lbsy.nd == 2)
          cout << "the D2Q9 model can be used" << endl;
        else
          cout << "the D3Q15, D3Q19 or D3Q27 models can be used" << endl;
        exit(1);
      }
      break;
    case 2:
      if(lbsy.nq == 9)
        fD2Q9OF2(tpos, prop);
      else if(lbsy.nq == 15)
        fD3Q15OF2(tpos, prop);
      else if(lbsy.nq == 19)
        fD3Q19OF2(tpos, prop);
      else if(lbsy.nq == 27)
        fD3Q27OF2(tpos, prop);
      else if(lbdm.rank ==0) {
        cout << "the boundary condition for D" << lbsy.nd << "Q" << lbsy.nq
             << " model has not been defined" << endl;
        if(lbsy.nd == 2)
          cout << "the D2Q9 model can be used" << endl;
        else
          cout << "the D3Q15, D3Q19 or D3Q27 models can be used" << endl;
        exit(1);
      }
      break;
  }
  return 0;
}

int fPostCollBoundary()
{
  for(long il=0; il<lbdm.touter; il++){
    if(lbphi[il] == 13) {
      fMidBounceBackF(il);
      fMidBounceBackC(il);
      fMidBounceBackT(il);
    }
  }    
  return 0;
}

int fPostPropBoundary()
{
  int a3, a12;
  double uw[3];
  if(lbsy.nt == 1) {
    lbinit += lbsysdt * lbdt;
    lbtopt += lbtopdt * lbdt;
    lbbott += lbbotdt * lbdt;
    lbfrot += lbfrodt * lbdt;
    lbbact += lbbacdt * lbdt;
    lbleft += lblefdt * lbdt;
    lbrigt += lbrigdt * lbdt;
  }
  for(long il=0; il<lbdm.touter; il++){
    if(lbphi[il] == 0) ;
    else if(lbphi[il] == 10);
    else if(lbphi[il] == 11) {
      fSiteBlankF(il);
      fSiteBlankC(il);
      fSiteBlankT(il); 
    }
    else if(lbphi[il] == 12) {
      fBounceBackF(il);
      fBounceBackC(il);
      fBounceBackT(il);
    }
    else if(lbphi[il] == 13);
    else if(lbphi[il]>20 && lbphi[il]<100) {
      a12 = lbphi[il];
      fOutFlow(il, a12);
    }
    else if (lbphi[il]>110 && lbphi[il]<890) {
      a12 = lbphi[il] % 100;
      a3=lbphi[il]/100;
      if(a3 == 1) {
        fFixedSpeedFluid(il, a12, a3, uw);
	    fFixedSoluteConcen(il, a12, uw);
	    fFixedTemperature(il, a12, uw);
      }
      else if(a3 == 2) {
	    fFixedSpeedFluid(il, a12, a3, uw);
	    fFixedSoluteConcen(il, a12, uw);
	    fBounceBackT(il);
      }
      else if(a3 == 3) {
	    fFixedSpeedFluid(il, a12, a3, uw);
	    fBounceBackC(il);
	    fFixedTemperature(il, a12, uw);
      }
      else if(a3 == 4) {
	    fFixedSpeedFluid(il, a12, a3, uw);
	    fBounceBackC(il);
	    fBounceBackT(il);
      }
      else if(a3 == 5) {
	    fFixedDensityFluid(il, a12, a3, uw);
	    fFixedSoluteConcen(il, a12, uw);
	    fFixedTemperature(il, a12, uw);
      } 
      else if(a3 == 6) {
	    fFixedDensityFluid(il, a12, a3, uw);
	    fFixedSoluteConcen(il, a12, uw);
	    fBounceBackT(il);
      }
      else if(a3 == 7) {
	    fFixedDensityFluid(il, a12, a3, uw);
	    fBounceBackC(il);
	    fFixedTemperature(il, a12, uw);
      }
      else if(a3 == 8) {
	    fFixedDensityFluid(il, a12, a3, uw);
	    fBounceBackC(il);
	    fBounceBackT(il);
      }
    }
    else {
      if(lbdm.rank == 0)
	cout << "error: boundary condition not recognised" << endl;
      exit(1);
    }
  }
  return 0;
}

int fNeighbourBoundary()
{
  int testphi, xpos, ypos, zpos, xneigh, yneigh, zneigh, xm, xp, ym, yp, zm, zp;
  double dx, dy, dz, rdxyz;
    
  for(long il=0; il<lbdm.touter; il++) {
    fGetCoord(il, xpos, ypos, zpos);
    lbneigh[il] = 0;
    xneigh = 0; yneigh = 0; zneigh = 0;
    dx = 0.0; dy = 0.0; dz = 0.0;
    // grid points lying on constant velocity/density boundaries
    if(lbphi[il]>100) {
      testphi = lbphi[il] % 100;
      // test neighbouring points for non-fluid nodes based on boundary condition
      // at current grid point
      if((testphi>34 && testphi<43) || (testphi>54 && testphi<67)) {
        xneigh = 1; yneigh = 1; zneigh = 1;
      }
      else {
        if(lbsy.nd==3) {
          switch (testphi) {
            case PST:
              yp = lbphi[fNextStep(0, 2, 0, il)];
              xneigh = 1;
              yneigh = (yp>10 || lbgradord==1)?2:3;
              zneigh = 1;
              dy = 1.0;
              break;
            case PSD:
              ym = lbphi[fNextStep(0, -2, 0, il)];
              xneigh = 1;
              yneigh = (ym>10 || lbgradord==1)?4:5;
              zneigh = 1;
              dy = -1.0;
              break;
            case PSL:
              xm = lbphi[fNextStep(0, -2, 0, il)];
              xneigh = (xm>10 || lbgradord==1)?2:3;
              yneigh = 1;
              zneigh = 1;
              dx = -1.0;
              break;
            case PSR:
              xp = lbphi[fNextStep(0, 2, 0, il)];
              xneigh = (xp>10 || lbgradord==1)?4:5;
              yneigh = 1;
              zneigh = 1;
              dx = 1.0;
              break;
            case PSF:
              zm = lbphi[fNextStep(0, 0, -2, il)];
              xneigh = 1;
              yneigh = 1;
              zneigh = (zm>10 || lbgradord==1)?2:3;
              dz = -1.0;
              break;
            case PSB:
              zp = lbphi[fNextStep(0, 0, 2, il)];
              xneigh = 1;
              yneigh = 1;
              zneigh = (zp>10 || lbgradord==1)?4:5;
              dz = 1.0;
              break;
            case CCTRB:
              xp = lbphi[fNextStep(2, 0, 0, il)];
              yp = lbphi[fNextStep(0, 2, 0, il)];
              zm = lbphi[fNextStep(0, 0, -2, il)];
              xneigh = (xp>10 || lbgradord==1)?2:3;
              yneigh = (yp>10 || lbgradord==1)?2:3;
              zneigh = (zm>10 || lbgradord==1)?4:5;
              dx = 1.0; dy = 1.0; dz = -1.0;
              break;
            case CCTLB:
              xm = lbphi[fNextStep(-2, 0, 0, il)];
              yp = lbphi[fNextStep(0, 2, 0, il)];
              zm = lbphi[fNextStep(0, 0, -2, il)];
              xneigh = (xm>10 || lbgradord==1)?4:5;
              yneigh = (yp>10 || lbgradord==1)?2:3;
              zneigh = (zm>10 || lbgradord==1)?4:5;
              dx = -1.0; dy = 1.0; dz = -1.0;
              break;
            case CCDLB:
              xm = lbphi[fNextStep(-2, 0, 0, il)];
              ym = lbphi[fNextStep(0, -2, 0, il)];
              zm = lbphi[fNextStep(0, 0, -2, il)];
              xneigh = (xm>10 || lbgradord==1)?4:5;
              yneigh = (ym>10 || lbgradord==1)?4:5;
              zneigh = (zm>10 || lbgradord==1)?4:5;
              dx = -1.0; dy = -1.0; dz = -1.0;
              break;
            case CCDRB:
              xp = lbphi[fNextStep(2, 0, 0, il)];
              ym = lbphi[fNextStep(0, -2, 0, il)];
              zm = lbphi[fNextStep(0, 0, -2, il)];
              xneigh = (xp>10 || lbgradord==1)?2:3;
              yneigh = (ym>10 || lbgradord==1)?4:5;
              zneigh = (zm>10 || lbgradord==1)?4:5;
              dx = 1.0; dy = -1.0; dz = -1.0;
              break;
            case CCTRF:
              xp = lbphi[fNextStep(2, 0, 0, il)];
              yp = lbphi[fNextStep(0, 2, 0, il)];
              zp = lbphi[fNextStep(0, 0, 2, il)];
              xneigh = (xp>10 || lbgradord==1)?2:3;
              yneigh = (yp>10 || lbgradord==1)?2:3;
              zneigh = (zp>10 || lbgradord==1)?2:3;
              dx = 1.0; dy = 1.0; dz = 1.0;
              break;
            case CCTLF:
              xm = lbphi[fNextStep(-2, 0, 0, il)];
              yp = lbphi[fNextStep(0, 2, 0, il)];
              zp = lbphi[fNextStep(0, 0, 2, il)];
              xneigh = (xm>10 || lbgradord==1)?4:5;
              yneigh = (yp>10 || lbgradord==1)?2:3;
              zneigh = (zp>10 || lbgradord==1)?2:3;
              dx = -1.0; dy = 1.0; dz = 1.0;
              break;
            case CCDLF:
              xm = lbphi[fNextStep(-2, 0, 0, il)];
              ym = lbphi[fNextStep(0, -2, 0, il)];
              zp = lbphi[fNextStep(0, 0, 2, il)];
              xneigh = (xm>10 || lbgradord==1)?4:5;
              yneigh = (ym>10 || lbgradord==1)?4:5;
              zneigh = (zp>10 || lbgradord==1)?2:3;
              dx = -1.0; dy = -1.0; dz = 1.0;
              break;
            case CCDRF:
              xp = lbphi[fNextStep(2, 0, 0, il)];
              ym = lbphi[fNextStep(0, -2, 0, il)];
              zp = lbphi[fNextStep(0, 0, 2, il)];
              xneigh = (xp>10 || lbgradord==1)?2:3;
              yneigh = (ym>10 || lbgradord==1)?4:5;
              zneigh = (zp>10 || lbgradord==1)?2:3;
              dx = 1.0; dy = -1.0; dz = 1.0;
              break;
            case CETR:
              xp = lbphi[fNextStep(2, 0, 0, il)];
              yp = lbphi[fNextStep(0, 2, 0, il)];
              xneigh = (xp>10 || lbgradord==1)?2:3;
              yneigh = (yp>10 || lbgradord==1)?2:3;
              zneigh = 1;
              dx = 1.0; dy = 1.0;
              break;
            case CETL:
              xm = lbphi[fNextStep(-2, 0, 0, il)];
              yp = lbphi[fNextStep(0, 2, 0, il)];
              xneigh = (xm>10 || lbgradord==1)?4:5;
              yneigh = (yp>10 || lbgradord==1)?2:3;
              zneigh = 1;
              dx = -1.0; dy = 1.0;
              break;
            case CEDL:
              xm = lbphi[fNextStep(-2, 0, 0, il)];
              ym = lbphi[fNextStep(0, -2, 0, il)];
              xneigh = (xm>10 || lbgradord==1)?4:5;
              yneigh = (ym>10 || lbgradord==1)?4:5;
              zneigh = 1;
              dx = -1.0; dy = -1.0;
              break;
            case CEDR:
              xp = lbphi[fNextStep(2, 0, 0, il)];
              ym = lbphi[fNextStep(0, -2, 0, il)];
              xneigh = (xp>10 || lbgradord==1)?2:3;
              yneigh = (ym>10 || lbgradord==1)?4:5;
              zneigh = 1;
              dx = 1.0; dy = -1.0;
              break;
            case CETF:
              yp = lbphi[fNextStep(0, 2, 0, il)];
              zp = lbphi[fNextStep(0, 0, 2, il)];
              xneigh = 1;
              yneigh = (yp>10 || lbgradord==1)?2:3;
              zneigh = (zp>10 || lbgradord==1)?2:3;
              dy = 1.0; dz = 1.0;
              break;
            case CELF:
              xm = lbphi[fNextStep(-2, 0, 0, il)];
              zp = lbphi[fNextStep(0, 0, 2, il)];
              xneigh = (xm>10 || lbgradord==1)?4:5;
              yneigh = 1;
              zneigh = (zp>10 || lbgradord==1)?2:3;
              dx = -1.0; dz = 1.0;
              break;
            case CEDF:
              ym = lbphi[fNextStep(0, -2, 0, il)];
              zp = lbphi[fNextStep(0, 0, 2, il)];
              xneigh = 1;
              yneigh = (ym>10 || lbgradord==1)?4:5;
              zneigh = (zp>10 || lbgradord==1)?2:3;
              dy = -1.0; dz = 1.0;
              break;
            case CERF:
              xp = lbphi[fNextStep(2, 0, 0, il)];
              zp = lbphi[fNextStep(0, 0, 2, il)];
              xneigh = (xp>10 || lbgradord==1)?2:3;
              yneigh = 1;
              zneigh = (zp>10 || lbgradord==1)?2:3;
              dx = 1.0; dz = 1.0;
              break;
            case CETB:
              yp = lbphi[fNextStep(0, 2, 0, il)];
              zm = lbphi[fNextStep(0, 0, -2, il)];
              xneigh = 1;
              yneigh = (yp>10 || lbgradord==1)?2:3;
              zneigh = (zm>10 || lbgradord==1)?4:5;
              dy = 1.0; dz = -1.0;
              break;
            case CELB:
              xm = lbphi[fNextStep(-2, 0, 0, il)];
              zm = lbphi[fNextStep(0, 0, -2, il)];
              xneigh = (xm>10 || lbgradord==1)?4:5;
              yneigh = 1;
              zneigh = (zm>10 || lbgradord==1)?4:5;
              dx = -1.0; dz = -1.0;
              break;
            case CEDB:
              ym = lbphi[fNextStep(0, -2, 0, il)];
              zm = lbphi[fNextStep(0, 0, -2, il)];
              xneigh = 1;
              yneigh = (ym>10 || lbgradord==1)?4:5;
              zneigh = (zm>10 || lbgradord==1)?4:5;
              dy = -1.0; dz = -1.0;
              break;
            case CERB:
              xp = lbphi[fNextStep(2, 0, 0, il)];
              zm = lbphi[fNextStep(0, 0, -2, il)];
              xneigh = (xp>10 || lbgradord==1)?2:3;
              yneigh = 1;
              zneigh = (zm>10 || lbgradord==1)?4:5;
              dx = 1.0; dz = -1.0;
              break;
          }
        }
        else {
          switch (testphi) {
            case CCTRF:
              xp = lbphi[fNextStep(2, 0, 0, il)];
              yp = lbphi[fNextStep(0, 2, 0, il)];
              xneigh = (xp>10 || lbgradord==1)?2:3;
              yneigh = (yp>10 || lbgradord==1)?2:3;
              zneigh = 1;
              dx = 1.0; dy = 1.0;
              break;
            case CCTLF:
              xm = lbphi[fNextStep(-2, 0, 0, il)];
              yp = lbphi[fNextStep(0, 2, 0, il)];
              xneigh = (xm>10 || lbgradord==1)?4:5;
              yneigh = (yp>10 || lbgradord==1)?2:3;
              zneigh = 1;
              dx = -1.0; dy = 1.0;
              break;
            case CCDLF:
              xm = lbphi[fNextStep(-2, 0, 0, il)];
              ym = lbphi[fNextStep(0, -2, 0, il)];
              xneigh = (xm>10 || lbgradord==1)?4:5;
              yneigh = (ym>10 || lbgradord==1)?4:5;
              zneigh = 1;
              dx = -1.0; dy = -1.0;
              break;
            case CCDRF:
              xp = lbphi[fNextStep(2, 0, 0, il)];
              ym = lbphi[fNextStep(0, -2, 0, il)];
              xneigh = (xp>10 || lbgradord==1)?2:3;
              yneigh = (ym>10 || lbgradord==1)?4:5;
              zneigh = 1;
              dx = 1.0; dy = -1.0;
              break;
            case CETF:
              yp = lbphi[fNextStep(0, 2, 0, il)];
              xneigh = 1;
              yneigh = (yp>10 || lbgradord==1)?2:3;
              zneigh = 1;
              dy = 1.0;
              break;
            case CELF:
              xm = lbphi[fNextStep(-2, 0, 0, il)];
              xneigh = (xm>10 || lbgradord==1)?4:5;
              yneigh = 1;
              zneigh = 1;
              dx = -1.0;
              break;
            case CEDF:
              ym = lbphi[fNextStep(0, -2, 0, il)];
              xneigh = 1;
              yneigh = (ym>10 || lbgradord==1)?4:5;
              zneigh = 1;
              dy = -1.0;
              break;
            case CERF:
              xp = lbphi[fNextStep(2, 0, 0, il)];
              xneigh = (xp>10 || lbgradord==1)?2:3;
              yneigh = 1;
              zneigh = 1;
              dx = 1.0;
              break;
          }
        }
      }
    }
    // grid points corresponding to fluid, bounce-back, blank or outflow nodes
    else {
      // if using free-energy model, only need to take care with
      // neighbouring points that are bounce-back, blank or outflow nodes
      if(interact==20) {
        testphi = 0;
        xm = lbphi[fNextStep(-1, -1, -1, il)];
        testphi += (xm>10 && xm<100);
        xm = lbphi[fNextStep(-1, -1,  1, il)];
        testphi += (xm>10 && xm<100);
        xm = lbphi[fNextStep(-1,  1,  1, il)];
        testphi += (xm>10 && xm<100);
        xm = lbphi[fNextStep(-1,  1, -1, il)];
        testphi += (xm>10 && xm<100);
        xm = lbphi[fNextStep( 1, -1, -1, il)];
        testphi += (xm>10 && xm<100);
        xm = lbphi[fNextStep( 1, -1,  1, il)];
        testphi += (xm>10 && xm<100);
        xm = lbphi[fNextStep( 1,  1,  1, il)];
        testphi += (xm>10 && xm<100);
        xm = lbphi[fNextStep( 1,  1, -1, il)];
        testphi += (xm>10 && xm<100);
        xm = lbphi[fNextStep(-1, -1,  0, il)];
        testphi += (xm>10 && xm<100);
        xm = lbphi[fNextStep(-1,  1,  0, il)];
        testphi += (xm>10 && xm<100);
        xm = lbphi[fNextStep( 1, -1,  0, il)];
        testphi += (xm>10 && xm<100);
        xm = lbphi[fNextStep( 1,  1,  0, il)];
        testphi += (xm>10 && xm<100);
        xm = lbphi[fNextStep(-1,  0, -1, il)];
        testphi += (xm>10 && xm<100);
        xm = lbphi[fNextStep(-1,  0,  1, il)];
        testphi += (xm>10 && xm<100);
        xm = lbphi[fNextStep( 1,  0, -1, il)];
        testphi += (xm>10 && xm<100);
        xm = lbphi[fNextStep( 1,  0,  1, il)];
        testphi += (xm>10 && xm<100);
        xm = lbphi[fNextStep( 0, -1, -1, il)];
        testphi += (xm>10 && xm<100);
        xm = lbphi[fNextStep( 0, -1,  1, il)];
        testphi += (xm>10 && xm<100);
        xm = lbphi[fNextStep( 0,  1, -1, il)];
        testphi += (xm>10 && xm<100);
        xm = lbphi[fNextStep( 0,  1,  1, il)];
        testphi += (xm>10 && xm<100);
        if(testphi>0) {
          xneigh = 1; yneigh = 1; zneigh = 1;
        }
        xm = lbphi[fNextStep(-1,  0,  0, il)];
        xp = lbphi[fNextStep( 1,  0,  0, il)];
        ym = lbphi[fNextStep( 0, -1,  0, il)];
        yp = lbphi[fNextStep( 0,  1,  0, il)];
        zm = lbphi[fNextStep( 0,  0, -1, il)];
        zp = lbphi[fNextStep( 0,  0,  1, il)];
        if(xm>10 && xm<100 && xp>10 && xp<100)
          xneigh = 6;
        else if(xm>10 && xm<100) {
          testphi = lbphi[fNextStep(2, 0, 0, il)];
          xneigh = ((testphi>10 && testphi<100) || lbgradord==1)?2:3;
        }
        else if(xp>10 && xp<100) {
          testphi = lbphi[fNextStep(-2, 0, 0, il)];
          xneigh = ((testphi>10 && testphi<100) || lbgradord==1)?4:5;
        }
        if(ym>10 && ym<100 && yp>10 && yp<100)
          yneigh = 6;
        else if(ym>10 && ym<100) {
          testphi = lbphi[fNextStep(0, 2, 0, il)];
          yneigh = ((testphi>10 && testphi<100) || lbgradord==1)?2:3;
        }
        else if(yp>10 && yp<100) {
          testphi = lbphi[fNextStep(0, -2, 0, il)];
          yneigh = ((testphi>10 && testphi<100) || lbgradord==1)?4:5;
        }
        if(lbsy.nd>2) {
          if(zm>10 && zm<100 && zp>10 && zp<100)
            zneigh = 6;
          else if(zm>10 && zm<100) {
            testphi = lbphi[fNextStep(0, 0, 2, il)];
            zneigh = ((testphi>10 && testphi<100) || lbgradord==1)?2:3;
          }
          else if(zp>10 && zp<100) {
            testphi = lbphi[fNextStep(0, 0, -2, il)];
            zneigh = ((testphi>10 && testphi<100) || lbgradord==1)?4:5;
          }
        }
      }
      else {
        testphi = 0;
        xm = lbphi[fNextStep(-1, -1, -1, il)];
        testphi += (xm>10);
        xm = lbphi[fNextStep(-1, -1,  1, il)];
        testphi += (xm>10);
        xm = lbphi[fNextStep(-1,  1,  1, il)];
        testphi += (xm>10);
        xm = lbphi[fNextStep(-1,  1, -1, il)];
        testphi += (xm>10);
        xm = lbphi[fNextStep( 1, -1, -1, il)];
        testphi += (xm>10);
        xm = lbphi[fNextStep( 1, -1,  1, il)];
        testphi += (xm>10);
        xm = lbphi[fNextStep( 1,  1,  1, il)];
        testphi += (xm>10);
        xm = lbphi[fNextStep( 1,  1, -1, il)];
        testphi += (xm>10);
        xm = lbphi[fNextStep(-1, -1,  0, il)];
        testphi += (xm>10);
        xm = lbphi[fNextStep(-1,  1,  0, il)];
        testphi += (xm>10);
        xm = lbphi[fNextStep( 1, -1,  0, il)];
        testphi += (xm>10);
        xm = lbphi[fNextStep( 1,  1,  0, il)];
        testphi += (xm>10);
        xm = lbphi[fNextStep(-1,  0, -1, il)];
        testphi += (xm>10);
        xm = lbphi[fNextStep(-1,  0,  1, il)];
        testphi += (xm>10);
        xm = lbphi[fNextStep( 1,  0, -1, il)];
        testphi += (xm>10);
        xm = lbphi[fNextStep( 1,  0,  1, il)];
        testphi += (xm>10);
        xm = lbphi[fNextStep( 0, -1, -1, il)];
        testphi += (xm>10);
        xm = lbphi[fNextStep( 0, -1,  1, il)];
        testphi += (xm>10);
        xm = lbphi[fNextStep( 0,  1, -1, il)];
        testphi += (xm>10);
        xm = lbphi[fNextStep( 0,  1,  1, il)];
        testphi += (xm>10);
        if(testphi>0) {
          xneigh = 1; yneigh = 1; zneigh = 1;
        }
        xm = lbphi[fNextStep(-1,  0,  0, il)];
        xp = lbphi[fNextStep( 1,  0,  0, il)];
        ym = lbphi[fNextStep( 0, -1,  0, il)];
        yp = lbphi[fNextStep( 0,  1,  0, il)];
        zm = lbphi[fNextStep( 0,  0, -1, il)];
        zp = lbphi[fNextStep( 0,  0,  1, il)];
        if(xm>10 && xp>10)
          xneigh = 6;
        else if(xm>10) {
          testphi = lbphi[fNextStep(2, 0, 0, il)];
          xneigh = (testphi>10 || lbgradord==1)?2:3;
        }
        else if(xp>10) {
          testphi = lbphi[fNextStep(-2, 0, 0, il)];
          xneigh = (testphi>10 || lbgradord==1)?4:5;
        }
        if(ym>10 && yp>10)
          yneigh = 6;
        else if(ym>10) {
          testphi = lbphi[fNextStep(0, 2, 0, il)];
          yneigh = (testphi>10 || lbgradord==1)?2:3;
        }
        else if(yp>10) {
          testphi = lbphi[fNextStep(0, -2, 0, il)];
          yneigh = (testphi>10 || lbgradord==1)?4:5;
        }
        if(lbsy.nd>2) {
          if(zm>10 && zp>10)
            zneigh = 6;
          else if(zm>10) {
            testphi = lbphi[fNextStep(0, 0, 2, il)];
            zneigh = (testphi>10 || lbgradord==1)?2:3;
          }
          else if(zp>10) {
            testphi = lbphi[fNextStep(0, 0, -2, il)];
            zneigh = (testphi>10 || lbgradord==1)?4:5;
          }
        }
      }
      if(xneigh>0) {
        if(yneigh==0)
          yneigh = 1;
        if(zneigh==0)
          zneigh = 1;
      }
      if(yneigh>0) {
        if(xneigh==0)
          xneigh = 1;
        if(zneigh==0)
          zneigh = 1;
      }
      if(zneigh>0) {
        if(xneigh==0)
          xneigh = 1;
        if(yneigh==0)
          yneigh = 1;
      }
      for(int i=1; i<lbsy.nq; i++) {
        xm = lbphi[fNextStep(lbvx[i], lbvy[i], lbvz[i], il)];
        dx += (xm<11)*lbvx[i];
        dy += (xm<11)*lbvy[i];
        dz += (xm<11)*lbvz[i];
      }
    }
    lbneigh[il] = 100 * xneigh + 10 * yneigh + zneigh;
    rdxyz = fReciprocal(sqrt(dx*dx+dy*dy+dz*dz));
    lbboundnorm[3*il  ] = dx*rdxyz;
    lbboundnorm[3*il+1] = dy*rdxyz;
    lbboundnorm[3*il+2] = dz*rdxyz;
  }
  return 0;
}

int fsPeriodic()
{
  // apply periodic boundary condition on distribution functions for either 2D or 3D system

  if(lbsy.nd == 2)
    fsPeriodic2D();
  else
    fsPeriodic3D();
  return 0;
}

int fsBoundPeriodic()
{
  // apply periodic boundary condition on space properties for either 2D or 3D system

  if(lbsy.nd == 2)
    fsBoundPeriodic2D();
  else
    fsBoundPeriodic3D();
  return 0;
}

int fsForcePeriodic()
{
  // apply periodic boundary condition on forces for either 2D or 3D system

  if(lbsy.nd == 2)
    fsForcePeriodic2D();
  else
    fsForcePeriodic3D();
  return 0;
}

int fsIndexPeriodic()
{
  // apply periodic boundary condition on phase indices for either 2D or 3D system

  if(lbsy.nd == 2)
    fsIndexPeriodic2D();
  else
    fsIndexPeriodic3D();
  return 0;
}

int fsPeriodic2D()
{
  // apply periodic boundary condition for 2D systems with boundary layer points
  unsigned long i, j, ipos, jpos;

  for (i=0; i<lbdm.bwid; i++) {
    ipos = (i*lbdm.youter+lbdm.bwid) * lbsitelength;
    jpos = ((lbdm.xouter - 2*lbdm.bwid + i) * lbdm.youter + lbdm.bwid) * lbsitelength;
    for (j=0; j<(lbdm.yinner*lbsitelength); j++) {
      lbf[ipos+j] = lbf[jpos+j];
    }
  }

  for (i=0; i<lbdm.bwid; i++) {
    ipos = ((lbdm.xouter - lbdm.bwid + i) * lbdm.youter + lbdm.bwid) * lbsitelength;
    jpos = ((lbdm.bwid + i) * lbdm.youter + lbdm.bwid) * lbsitelength;
    for (j=0; j<(lbdm.yinner*lbsitelength); j++) {
      lbf[ipos+j] = lbf[jpos+j];
    }
  }

  for (i=0; i<lbdm.xouter; i++) {
    ipos = ((i+1)*lbdm.youter - lbdm.bwid) * lbsitelength;
    jpos = (i * lbdm.youter + lbdm.bwid) * lbsitelength;
    for (j=0; j<(lbdm.bwid*lbsitelength); j++) {
      lbf[ipos+j] = lbf[jpos+j];
    }
  }

  for (i=0; i<lbdm.xouter; i++) {
    ipos = i * lbdm.youter * lbsitelength;
    jpos = ((i+1) * lbdm.youter - 2 * lbdm.bwid) * lbsitelength;
    for (j=0; j<(lbdm.bwid*lbsitelength); j++) {
      lbf[ipos+j] = lbf[jpos+j];
    }
  }

  return 0;
}

int fsPeriodic3D()
{
  // apply periodic boundary condition for 3D systems with boundary layer points

  unsigned long i, j, k, ipos, jpos;

  for (i=0; i<lbdm.bwid; i++) 
    for (j=0; j<lbdm.yinner; j++) {
      ipos = ((i * lbdm.youter + lbdm.bwid + j) * lbdm.zouter + lbdm.bwid) * lbsitelength;
      jpos = (((lbdm.xouter - 2*lbdm.bwid + i) * lbdm.youter + lbdm.bwid + j) * lbdm.zouter + lbdm.bwid) * lbsitelength;
      for (k=0; k<(lbdm.zinner*lbsitelength); k++) {
        lbf[ipos+k] = lbf[jpos+k];
      }
    }

  for (i=0; i<lbdm.bwid; i++) 
    for (j=0; j<lbdm.yinner; j++) {
      ipos = (((lbdm.xouter - lbdm.bwid + i) * lbdm.youter + lbdm.bwid + j) * lbdm.zouter + lbdm.bwid) * lbsitelength;
      jpos = (((lbdm.bwid + i) * lbdm.youter + lbdm.bwid + j) * lbdm.zouter + lbdm.bwid) * lbsitelength;
      for (k=0; k<(lbdm.zinner*lbsitelength); k++) {
        lbf[ipos+k] = lbf[jpos+k];
      }
    }

  for (i=0; i<lbdm.xouter; i++) 
    for (j=0; j<lbdm.bwid; j++) {
      ipos = (((i+1) * lbdm.youter - lbdm.bwid + j) * lbdm.zouter + lbdm.bwid) * lbsitelength;
      jpos = ((i * lbdm.youter + lbdm.bwid + j) * lbdm.zouter + lbdm.bwid) * lbsitelength;
      for (k=0; k<(lbdm.zinner*lbsitelength); k++) {
        lbf[ipos+k] = lbf[jpos+k];
      }
    }

  for (i=0; i<lbdm.xouter; i++) 
    for (j=0; j<lbdm.bwid; j++) {
      ipos = ((i * lbdm.youter + j) * lbdm.zouter + lbdm.bwid) * lbsitelength;
      jpos = (((i+1) * lbdm.youter - 2 * lbdm.bwid + j) * lbdm.zouter + lbdm.bwid) * lbsitelength;
      for (k=0; k<(lbdm.zinner*lbsitelength); k++) {
        lbf[ipos+k] = lbf[jpos+k];
      }
    }

  for (i=0; i<lbdm.xouter; i++) 
    for (j=0; j<lbdm.youter; j++) {
      ipos = ((i * lbdm.youter + j) * lbdm.zouter) * lbsitelength;
      jpos = ((i * lbdm.youter + j + 1) * lbdm.zouter - 2 * lbdm.bwid) * lbsitelength;
      for (k=0; k<(lbdm.bwid*lbsitelength); k++) {
        lbf[ipos+k] = lbf[jpos+k];
      }
    }

  for (i=0; i<lbdm.xouter; i++) 
    for (j=0; j<lbdm.youter; j++) {
      ipos = ((i * lbdm.youter + j + 1) * lbdm.zouter - lbdm.bwid) * lbsitelength;
      jpos = ((i * lbdm.youter + j) * lbdm.zouter + lbdm.bwid) * lbsitelength;
      for (k=0; k<(lbdm.bwid*lbsitelength); k++) {
        lbf[ipos+k] = lbf[jpos+k];
      }
    }

  return 0;
}

int fsBoundPeriodic2D()
{
  // apply periodic boundary condition for 2D systems with boundary layer points
  unsigned long i, j, ipos, jpos;

  for (i=0; i<lbdm.bwid; i++) {
    ipos = i * lbdm.youter + lbdm.bwid;
    jpos = (lbdm.xouter - 2*lbdm.bwid + i) * lbdm.youter + lbdm.bwid;
    for (j=0; j<lbdm.yinner; j++) {
      lbphi[ipos+j] = lbphi[jpos+j];
    }
  }

  for (i=0; i<lbdm.bwid; i++) {
    ipos = (lbdm.xouter - lbdm.bwid + i) * lbdm.youter + lbdm.bwid;
    jpos = (lbdm.bwid + i) * lbdm.youter + lbdm.bwid;
    for (j=0; j<lbdm.yinner; j++) {
      lbphi[ipos+j] = lbphi[jpos+j];
    }
  }

  for (i=0; i<lbdm.xouter; i++) {
    ipos = (i+1)*lbdm.youter - lbdm.bwid;
    jpos = i * lbdm.youter + lbdm.bwid;
    for (j=0; j<lbdm.bwid; j++) {
      lbphi[ipos+j] = lbphi[jpos+j];
    }
  }

  for (i=0; i<lbdm.xouter; i++) {
    ipos = i * lbdm.youter;
    jpos = (i+1) * lbdm.youter - 2 * lbdm.bwid;
    for (j=0; j<lbdm.bwid; j++) {
      lbphi[ipos+j] = lbphi[jpos+j];
    }
  }

  return 0;
}

int fsBoundPeriodic3D()
{
  // apply periodic boundary condition for 3D systems with boundary layer points

  unsigned long i, j, k, ipos, jpos;

  for (i=0; i<lbdm.bwid; i++) 
    for (j=0; j<lbdm.yinner; j++) {
      ipos = (i * lbdm.youter + lbdm.bwid + j) * lbdm.zouter + lbdm.bwid;
      jpos = ((lbdm.xouter - 2*lbdm.bwid + i) * lbdm.youter + lbdm.bwid + j) * lbdm.zouter + lbdm.bwid;
      for (k=0; k<lbdm.zinner; k++) {
        lbphi[ipos+k] = lbphi[jpos+k];
      }
    }

  for (i=0; i<lbdm.bwid; i++) 
    for (j=0; j<lbdm.yinner; j++) {
      ipos = ((lbdm.xouter - lbdm.bwid + i) * lbdm.youter + lbdm.bwid + j) * lbdm.zouter + lbdm.bwid;
      jpos = ((lbdm.bwid + i) * lbdm.youter + lbdm.bwid + j) * lbdm.zouter + lbdm.bwid;
      for (k=0; k<lbdm.zinner; k++) {
        lbphi[ipos+k] = lbphi[jpos+k];
      }
    }

  for (i=0; i<lbdm.xouter; i++) 
    for (j=0; j<lbdm.bwid; j++) {
      ipos = ((i+1) * lbdm.youter - lbdm.bwid + j) * lbdm.zouter + lbdm.bwid;
      jpos = (i * lbdm.youter + lbdm.bwid + j) * lbdm.zouter + lbdm.bwid;
      for (k=0; k<lbdm.zinner; k++) {
        lbphi[ipos+k] = lbphi[jpos+k];
      }
    }

  for (i=0; i<lbdm.xouter; i++) 
    for (j=0; j<lbdm.bwid; j++) {
      ipos = (i * lbdm.youter + j) * lbdm.zouter + lbdm.bwid;
      jpos = ((i+1) * lbdm.youter - 2 * lbdm.bwid + j) * lbdm.zouter + lbdm.bwid;
      for (k=0; k<lbdm.zinner; k++) {
        lbphi[ipos+k] = lbphi[jpos+k];
      }
    }

  for (i=0; i<lbdm.xouter; i++) 
    for (j=0; j<lbdm.youter; j++) {
      ipos = (i * lbdm.youter + j) * lbdm.zouter;
      jpos = (i * lbdm.youter + j + 1) * lbdm.zouter - 2 * lbdm.bwid;
      for (k=0; k<lbdm.bwid; k++) {
        lbphi[ipos+k] = lbphi[jpos+k];
      }
    }

  for (i=0; i<lbdm.xouter; i++) 
    for (j=0; j<lbdm.youter; j++) {
      ipos = (i * lbdm.youter + j + 1) * lbdm.zouter - lbdm.bwid;
      jpos = (i * lbdm.youter + j) * lbdm.zouter + lbdm.bwid;
      for (k=0; k<lbdm.bwid; k++) {
        lbphi[ipos+k] = lbphi[jpos+k];
      }
    }

  return 0;
}

int fsForcePeriodic2D()
{
  // apply periodic boundary condition for 2D systems with boundary layer points
  unsigned long i, j, ipos, jpos;

  for (i=0; i<lbdm.bwid; i++) {
    ipos = (i*lbdm.youter+lbdm.bwid) * 3;
    jpos = ((lbdm.xouter - 2*lbdm.bwid + i) * lbdm.youter + lbdm.bwid) * 3;
    for (j=0; j<(lbdm.yinner*3); j++) {
      lbinterforce[ipos+j] = lbinterforce[jpos+j];
    }
  }

  for (i=0; i<lbdm.bwid; i++) {
    ipos = ((lbdm.xouter - lbdm.bwid + i) * lbdm.youter + lbdm.bwid) * 3;
    jpos = ((lbdm.bwid + i) * lbdm.youter + lbdm.bwid) * 3;
    for (j=0; j<(lbdm.yinner*3); j++) {
      lbinterforce[ipos+j] = lbinterforce[jpos+j];
    }
  }

  for (i=0; i<lbdm.xouter; i++) {
    ipos = ((i+1)*lbdm.youter - lbdm.bwid) * 3;
    jpos = (i * lbdm.youter + lbdm.bwid) * 3;
    for (j=0; j<(lbdm.bwid*3); j++) {
      lbinterforce[ipos+j] = lbinterforce[jpos+j];
    }
  }

  for (i=0; i<lbdm.xouter; i++) {
    ipos = i * lbdm.youter * 3;
    jpos = ((i+1) * lbdm.youter - 2 * lbdm.bwid) * 3;
    for (j=0; j<(lbdm.bwid*3); j++) {
      lbinterforce[ipos+j] = lbinterforce[jpos+j];
    }
  }

  return 0;
}

int fsForcePeriodic3D()
{
  // apply periodic boundary condition for 3D systems with boundary layer points

  unsigned long i, j, k, ipos, jpos;

  for (i=0; i<lbdm.bwid; i++) 
    for (j=0; j<lbdm.yinner; j++) {
      ipos = ((i * lbdm.youter + lbdm.bwid + j) * lbdm.zouter + lbdm.bwid) * 3;
      jpos = (((lbdm.xouter - 2*lbdm.bwid + i) * lbdm.youter + lbdm.bwid + j) * lbdm.zouter + lbdm.bwid) * 3;
      for (k=0; k<(lbdm.zinner*3); k++) {
        lbinterforce[ipos+k] = lbinterforce[jpos+k];
      }
    }

  for (i=0; i<lbdm.bwid; i++) 
    for (j=0; j<lbdm.yinner; j++) {
      ipos = (((lbdm.xouter - lbdm.bwid + i) * lbdm.youter + lbdm.bwid + j) * lbdm.zouter + lbdm.bwid) * 3;
      jpos = (((lbdm.bwid + i) * lbdm.youter + lbdm.bwid + j) * lbdm.zouter + lbdm.bwid) * 3;
      for (k=0; k<(lbdm.zinner*3); k++) {
        lbinterforce[ipos+k] = lbinterforce[jpos+k];
      }
    }

  for (i=0; i<lbdm.xouter; i++) 
    for (j=0; j<lbdm.bwid; j++) {
      ipos = (((i+1) * lbdm.youter - lbdm.bwid + j) * lbdm.zouter + lbdm.bwid) * 3;
      jpos = ((i * lbdm.youter + lbdm.bwid + j) * lbdm.zouter + lbdm.bwid) * 3;
      for (k=0; k<(lbdm.zinner*3); k++) {
        lbinterforce[ipos+k] = lbinterforce[jpos+k];
      }
    }

  for (i=0; i<lbdm.xouter; i++) 
    for (j=0; j<lbdm.bwid; j++) {
      ipos = ((i * lbdm.youter + j) * lbdm.zouter + lbdm.bwid) * 3;
      jpos = (((i+1) * lbdm.youter - 2 * lbdm.bwid + j) * lbdm.zouter + lbdm.bwid) * 3;
      for (k=0; k<(lbdm.zinner*3); k++) {
        lbinterforce[ipos+k] = lbinterforce[jpos+k];
      }
    }

  for (i=0; i<lbdm.xouter; i++) 
    for (j=0; j<lbdm.youter; j++) {
      ipos = ((i * lbdm.youter + j) * lbdm.zouter) * 3;
      jpos = ((i * lbdm.youter + j + 1) * lbdm.zouter - 2 * lbdm.bwid) * 3;
      for (k=0; k<(lbdm.bwid*3); k++) {
        lbinterforce[ipos+k] = lbinterforce[jpos+k];
      }
    }

  for (i=0; i<lbdm.xouter; i++) 
    for (j=0; j<lbdm.youter; j++) {
      ipos = ((i * lbdm.youter + j + 1) * lbdm.zouter - lbdm.bwid) * 3;
      jpos = ((i * lbdm.youter + j) * lbdm.zouter + lbdm.bwid) * 3;
      for (k=0; k<(lbdm.bwid*3); k++) {
        lbinterforce[ipos+k] = lbinterforce[jpos+k];
      }
    }

  return 0;
}

int fsIndexPeriodic2D()
{
  // apply periodic boundary condition for 2D systems with boundary layer points
  unsigned long i, j, ipos, jpos;
  int numpair = 3 * lbsy.nf * (lbsy.nf-1) / 2;

  for (i=0; i<lbdm.bwid; i++) {
    ipos = (i * lbdm.youter + lbdm.bwid) * numpair;
    jpos = ((lbdm.xouter - 2*lbdm.bwid + i) * lbdm.youter + lbdm.bwid) * numpair;
    for (j=0; j<(lbdm.yinner*numpair); j++) {
      lbft[ipos+j] = lbft[jpos+j];
    }
  }

  for (i=0; i<lbdm.bwid; i++) {
    ipos = ((lbdm.xouter - lbdm.bwid + i) * lbdm.youter + lbdm.bwid) * numpair;
    jpos = ((lbdm.bwid + i) * lbdm.youter + lbdm.bwid) * numpair;
    for (j=0; j<(lbdm.yinner*numpair); j++) {
      lbft[ipos+j] = lbft[jpos+j];
    }
  }

  for (i=0; i<lbdm.xouter; i++) {
    ipos = ((i+1)*lbdm.youter - lbdm.bwid) * numpair;
    jpos = (i * lbdm.youter + lbdm.bwid) * numpair;
    for (j=0; j<(lbdm.bwid*numpair); j++) {
      lbft[ipos+j] = lbft[jpos+j];
    }
  }

  for (i=0; i<lbdm.xouter; i++) {
    ipos = i * lbdm.youter * numpair;
    jpos = ((i+1) * lbdm.youter - 2 * lbdm.bwid) * numpair;
    for (j=0; j<(lbdm.bwid*numpair); j++) {
      lbft[ipos+j] = lbft[jpos+j];
    }
  }

  return 0;
}

int fsIndexPeriodic3D()
{
  // apply periodic boundary condition for 3D systems with boundary layer points

  unsigned long i, j, k, ipos, jpos;
  int numpair = 3 * lbsy.nf * (lbsy.nf-1) / 2;

  for (i=0; i<lbdm.bwid; i++) 
    for (j=0; j<lbdm.yinner; j++) {
      ipos = ((i * lbdm.youter + lbdm.bwid + j) * lbdm.zouter + lbdm.bwid) * numpair;
      jpos = (((lbdm.xouter - 2*lbdm.bwid + i) * lbdm.youter + lbdm.bwid + j) * lbdm.zouter + lbdm.bwid) * numpair;
      for (k=0; k<(lbdm.zinner*numpair); k++) {
        lbft[ipos+k] = lbft[jpos+k];
      }
    }

  for (i=0; i<lbdm.bwid; i++) 
    for (j=0; j<lbdm.yinner; j++) {
      ipos = (((lbdm.xouter - lbdm.bwid + i) * lbdm.youter + lbdm.bwid + j) * lbdm.zouter + lbdm.bwid) * numpair;
      jpos = (((lbdm.bwid + i) * lbdm.youter + lbdm.bwid + j) * lbdm.zouter + lbdm.bwid) * numpair;
      for (k=0; k<(lbdm.zinner*numpair); k++) {
        lbft[ipos+k] = lbft[jpos+k];
      }
    }

  for (i=0; i<lbdm.xouter; i++) 
    for (j=0; j<lbdm.bwid; j++) {
      ipos = (((i+1) * lbdm.youter - lbdm.bwid + j) * lbdm.zouter + lbdm.bwid) * numpair;
      jpos = ((i * lbdm.youter + lbdm.bwid + j) * lbdm.zouter + lbdm.bwid) * numpair;
      for (k=0; k<(lbdm.zinner*numpair); k++) {
        lbft[ipos+k] = lbft[jpos+k];
      }
    }

  for (i=0; i<lbdm.xouter; i++) 
    for (j=0; j<lbdm.bwid; j++) {
      ipos = ((i * lbdm.youter + j) * lbdm.zouter + lbdm.bwid) * numpair;
      jpos = (((i+1) * lbdm.youter - 2 * lbdm.bwid + j) * lbdm.zouter + lbdm.bwid) * numpair;
      for (k=0; k<(lbdm.zinner*numpair); k++) {
        lbft[ipos+k] = lbft[jpos+k];
      }
    }

  for (i=0; i<lbdm.xouter; i++) 
    for (j=0; j<lbdm.youter; j++) {
      ipos = ((i * lbdm.youter + j) * lbdm.zouter) * numpair;
      jpos = ((i * lbdm.youter + j + 1) * lbdm.zouter - 2 * lbdm.bwid) * numpair;
      for (k=0; k<(lbdm.bwid*numpair); k++) {
        lbft[ipos+k] = lbft[jpos+k];
      }
    }

  for (i=0; i<lbdm.xouter; i++) 
    for (j=0; j<lbdm.youter; j++) {
      ipos = ((i * lbdm.youter + j + 1) * lbdm.zouter - lbdm.bwid) * numpair;
      jpos = ((i * lbdm.youter + j) * lbdm.zouter + lbdm.bwid) * numpair;
      for (k=0; k<(lbdm.bwid*numpair); k++) {
        lbft[ipos+k] = lbft[jpos+k];
      }
    }

  return 0;
}


