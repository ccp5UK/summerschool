import javax.swing.*;
import java.util.*;
import java.lang.*;
import java.io.*;
import java.awt.*;
import java.awt.event.*;
import java.awt.geom.*;
import java.awt.image.*;
/*
 *     DL_MESO_GUI
 *     author: R. S. Qin, M. A. Seaton
 *     copyright: UKRI STFC Daresbury Laboratory and CCP5
 *     2005, 2018
 */
class setlbeSys extends JPanel {

    setlbeSysEvt inilbe=new setlbeSysEvt(this);
    
    Font font=new Font("Dialog", Font.BOLD, 13);
    Color bgcolor=new Color(170, 200, 190);
    Color focolor=new Color(10, 10, 15);
    Color paneltop=new Color(170, 170, 230);

    JLabel setmod=new JLabel("LBE model:", JLabel.RIGHT);
    JComboBox<String> model=new JComboBox<String>();
    JCheckBox yesincomp=new JCheckBox("incompressible", false);

    JLabel colllabel=new JLabel("collision/forcing type:", JLabel.RIGHT);
    JComboBox<String> collide=new JComboBox<String>();

    JLabel interalabel=new JLabel("interactions:", JLabel.RIGHT);
    JComboBox<String> interact=new JComboBox<String>();
    
    JLabel setgrid = new JLabel("number of grid points", JLabel.RIGHT);
    JLabel totxlabel =new JLabel("x:", JLabel.RIGHT);
    JTextField totx =new JTextField("40", 6);
    JLabel totylabel =new JLabel("y:", JLabel.RIGHT);
    JTextField toty =new JTextField("30", 6);
    JLabel totzlabel =new JLabel("z:", JLabel.RIGHT);
    JTextField totz =new JTextField("1", 6);

    JLabel tottlabel =new JLabel("total steps:", JLabel.RIGHT);
    JTextField tott =new JTextField("10", 6);
    JLabel equillabel =new JLabel("equilibration steps:", JLabel.RIGHT);
    JTextField equt =new JTextField("0", 6);

    JLabel savetlabel =new JLabel("save span:", JLabel.RIGHT);
    JTextField savet =new JTextField("5", 6);
    JLabel bdwidlabel =new JLabel("boundary width:", JLabel.RIGHT);
    JTextField bwid =new JTextField("1", 6);

    JLabel dumptlabel =new JLabel("dump span:", JLabel.RIGHT);
    JTextField dumpt =new JTextField("10000", 6);
    JCheckBox yesrestart=new JCheckBox("restart", false);
    
    JLabel outfmtlabel=new JLabel("output format:", JLabel.RIGHT);
    JComboBox<String> outformat=new JComboBox<String>();
    JCheckBox outansi = new JCheckBox("text", false);
    
    JLabel soundvlabel =new JLabel("sound speed:", JLabel.RIGHT);
    JTextField soundv =new JTextField("540", 6);
    JLabel viscolabel =new JLabel("kinetic viscosity:",JLabel.RIGHT);
    JTextField kineticv =new JTextField("0.001", 6);
    
    JLabel noiselabel =new JLabel("noise (0~1):", JLabel.RIGHT);
    JTextField noiei =new JTextField("0", 6);
    ButtonGroup phasefield =new ButtonGroup();
    JCheckBox phaseyes = new JCheckBox("phase field", false);
    JCheckBox phaseno = new JCheckBox("no phase field", true);

    JLabel fluidlabel =new JLabel("number of fluids (phases)", JLabel.RIGHT);
    JTextField fluidn = new JTextField("1", 6);
    JLabel direclabel =new JLabel(">>", JLabel.RIGHT);
    JButton setf=new JButton("set fluid parameters");

    JButton sete=new JButton("set fluid interactions");
    
    JButton setfr=new JButton("set fluid forces");

    JLabel solutelabel =new JLabel("number of solutes", JLabel.RIGHT);
    JTextField solutn = new JTextField("0", 6);
    JLabel direclabel2 =new JLabel(">>", JLabel.RIGHT);
    JButton setn=new JButton("set solute parameters");

    JLabel tempslabel =new JLabel("using temperature scalar?", JLabel.RIGHT);
    JCheckBox yest = new JCheckBox("yes", false);
    JLabel direclabel3 =new JLabel(">>", JLabel.RIGHT);
    JButton sett=new JButton("set thermal parameters");

    JLabel combinelabel =new JLabel("combine outputs:", JLabel.RIGHT);
    JCheckBox combinex=new JCheckBox("x", false);
    JCheckBox combiney=new JCheckBox("y", false);
    JCheckBox combinez=new JCheckBox("z", false);
    
    JLabel calctimelabel =new JLabel("calculation time (s):", JLabel.RIGHT);
    JTextField calctime =new JTextField("0", 6);

    JButton opens=new JButton("OPEN");
    JButton saves=new JButton("SAVE");

    public setlbeSys() {
//        setSize(620, 580);
        JPanel panel1 = new JPanel();
        panel1.setLayout(new GridBagLayout());
      
        // row1	
		setmod.setFont(font);
        addItem(panel1, setmod, 0, 0, 1, 1, GridBagConstraints.WEST);

        model.addItem("D2Q9");
        model.addItem("D3Q15");
        model.addItem("D3Q19");
        model.addItem("D3Q27");
		model.setFont(font);
		model.addItemListener(inilbe);
        addItem(panel1, model, 2, 0, 1, 1, GridBagConstraints.WEST);
		yesincomp.addActionListener(inilbe);
        addItem(panel1, yesincomp, 4, 0, 3, 1, GridBagConstraints.WEST);

        // row2
        colllabel.setFont(font);
        addItem(panel1, colllabel, 0, 1, 1, 1, GridBagConstraints.WEST);

        collide.addItem("BGK");
        collide.addItem("BGK/EDM");
        collide.addItem("BGK/Guo");
        collide.addItem("BGK/He");
        collide.addItem("TRT");
        collide.addItem("TRT/EDM");
        collide.addItem("TRT/Guo");
        collide.addItem("TRT/He");
        collide.addItem("MRT");
        collide.addItem("MRT/EDM");
        collide.addItem("MRT/Guo");
        collide.addItem("MRT/He");
        collide.addItem("CLBE");
        collide.addItem("CLBE/EDM");
        collide.addItem("CLBE/Guo");
        collide.addItem("CLBE/He");
        collide.setFont(font);
		collide.addItemListener(inilbe);
        addItem(panel1, collide, 2, 1, 1, 1, GridBagConstraints.WEST);
        
        // row3
        interalabel.setFont(font);
        addItem(panel1, interalabel, 0, 2, 1, 1, GridBagConstraints.WEST);

        interact.addItem("no interactions");
        interact.addItem("Shan/Chen");
        interact.addItem("Shan/Chen Quadratic");
        interact.addItem("Lishchuk");
        interact.addItem("Lishchuk/Spencer");
        interact.addItem("Lishchuk/Spencer tensor");
        interact.addItem("Lishchuk Local");
        interact.addItem("Swift");
        interact.setFont(font);
		interact.addItemListener(inilbe);
        addItem(panel1, interact, 2, 2, 3, 1, GridBagConstraints.WEST);

        // row4
		setgrid.setFont(font);
        addItem(panel1, setgrid, 0, 3, 1, 1, GridBagConstraints.WEST);

		totxlabel.setFont(font);
        addItem(panel1, totxlabel, 1, 3, 1, 1, GridBagConstraints.WEST);
		totx.setEditable(true);
		totylabel.setFont(font);
		toty.setEditable(true);
		totzlabel.setFont(font);
		totzlabel.setEnabled(false);
		totz.setEditable(false);
		totz.setEnabled(false);
        Box totbox = Box.createHorizontalBox();
        totbox.add(totx);
        totbox.add(Box.createRigidArea(new Dimension(46,0)));
        totbox.add(totylabel);
        totbox.add(toty);
        totbox.add(Box.createRigidArea(new Dimension(46,0)));
        totbox.add(totzlabel);
        totbox.add(totz);
        addItem(panel1, totbox, 2, 3, 5, 1, GridBagConstraints.WEST);

        // row5
		tottlabel.setFont(font);
        addItem(panel1, tottlabel, 0, 4, 1, 1, GridBagConstraints.WEST);
		tott.setEditable(true);
		equillabel.setFont(font);
        addItem(panel1, equillabel, 3, 4, 3, 1, GridBagConstraints.WEST);
		tott.setEditable(true);

        addItem(panel1, tott, 2, 4, 1, 1, GridBagConstraints.WEST);
        addItem(panel1, equt, 6, 4, 1, 1, GridBagConstraints.WEST);

        // row6
		savetlabel.setFont(font);
        addItem(panel1, savetlabel, 0, 5, 1, 1, GridBagConstraints.WEST);
		savet.setEditable(true);
        addItem(panel1, savet, 2, 5, 1, 1, GridBagConstraints.WEST);

		bdwidlabel.setFont(font);
        addItem(panel1, bdwidlabel, 3, 5, 2, 1, GridBagConstraints.WEST);
		bwid.setEditable(true);
        addItem(panel1, bwid, 6, 5, 1, 1, GridBagConstraints.WEST);

        // row7
		dumptlabel.setFont(font);
        addItem(panel1, dumptlabel, 0, 6, 1, 1, GridBagConstraints.WEST);
		dumpt.setEditable(true);
        addItem(panel1, dumpt, 2, 6, 1, 1, GridBagConstraints.WEST);
		yesrestart.addActionListener(inilbe);
        addItem(panel1, yesrestart, 4, 6, 3, 1, GridBagConstraints.WEST);

        // row8
        outfmtlabel.setFont(font);
        addItem(panel1, outfmtlabel, 0, 7, 1, 1, GridBagConstraints.WEST);

        outformat.addItem("VTK");
        outformat.addItem("LegacyVTK");
        outformat.addItem("Plot3D");
        outformat.setFont(font);
		outformat.addItemListener(inilbe);
        addItem(panel1, outformat, 2, 7, 2, 1, GridBagConstraints.WEST);
        
        outansi.addActionListener(inilbe);
        addItem(panel1, outansi, 4, 7, 1, 1, GridBagConstraints.WEST);

		// row9
		soundvlabel.setFont(font);
        addItem(panel1, soundvlabel, 0, 8, 1, 1, GridBagConstraints.WEST);
		soundv.setEditable(true);
        addItem(panel1, soundv, 2, 8, 1, 1, GridBagConstraints.WEST);

		viscolabel.setFont(font);
        addItem(panel1, viscolabel, 3, 8, 2, 1, GridBagConstraints.WEST);
		kineticv.setEditable(true);
        addItem(panel1, kineticv, 6, 8, 1, 1, GridBagConstraints.WEST);
        
		// row10
		noiselabel.setFont(font);
        addItem(panel1, noiselabel, 0, 9, 1, 1, GridBagConstraints.WEST);
		noiei.setEditable(true);
        addItem(panel1, noiei, 2, 9, 1, 1, GridBagConstraints.WEST);

		phasefield.add(phaseyes);
		phasefield.add(phaseno);

        Box phasebox = Box.createHorizontalBox();
		phaseyes.setFont(font);
		phaseyes.setEnabled(false);
		phaseyes.addItemListener(inilbe);
		phaseno.setFont(font);
		phaseno.setEnabled(false);
		phaseno.addItemListener(inilbe);
        phasebox.add(phaseyes);
        phasebox.add(phaseno);
        addItem(panel1, phasebox, 3, 9, 4, 1, GridBagConstraints.WEST);

		// row11
		fluidlabel.setFont(font);
        addItem(panel1, fluidlabel, 0, 10, 1, 1, GridBagConstraints.WEST);
        addItem(panel1, fluidn, 2, 10, 1, 1, GridBagConstraints.WEST);
        addItem(panel1, direclabel, 3, 10, 1, 1, GridBagConstraints.CENTER);
		setf.addActionListener(inilbe);
        addItemFill(panel1, setf, 4, 10, 3, 1, GridBagConstraints.WEST, GridBagConstraints.HORIZONTAL);

		// row12
		setfr.addActionListener(inilbe);
		addItemFill(panel1, setfr, 4, 11, 3, 1, GridBagConstraints.WEST, GridBagConstraints.HORIZONTAL);

		// row13
		sete.addActionListener(inilbe);
		addItemFill(panel1, sete, 4, 12, 3, 1, GridBagConstraints.WEST, GridBagConstraints.HORIZONTAL);
        sete.setEnabled(false);

		// row14
		solutelabel.setFont(font);
        addItem(panel1, solutelabel, 0, 13, 1, 1, GridBagConstraints.WEST);
        addItem(panel1, solutn, 2, 13, 1, 1, GridBagConstraints.WEST);
        addItem(panel1, direclabel2, 3, 13, 1, 1, GridBagConstraints.CENTER);
		setn.addActionListener(inilbe);
        addItemFill(panel1, setn, 4, 13, 3, 1, GridBagConstraints.WEST, GridBagConstraints.HORIZONTAL);

		// row15
		tempslabel.setFont(font);
        addItem(panel1, tempslabel, 0, 14, 1, 1, GridBagConstraints.WEST);
		yest.addActionListener(inilbe);
        addItem(panel1, yest, 2, 14, 1, 1, GridBagConstraints.WEST);
        addItem(panel1, direclabel3, 3, 14, 1, 1, GridBagConstraints.CENTER);
		sett.addActionListener(inilbe);
        addItemFill(panel1, sett, 4, 14, 3, 1, GridBagConstraints.WEST, GridBagConstraints.HORIZONTAL);

        // row16
        combinelabel.setFont(font);
        addItem(panel1, combinelabel, 0, 15, 1, 1, GridBagConstraints.WEST);
        combinex.setBackground(bgcolor);
        combinex.addActionListener(inilbe);
        combiney.setBackground(bgcolor);
        combiney.addActionListener(inilbe);
        combinez.setBackground(bgcolor);
        combinez.setEnabled(false);
        combinez.addActionListener(inilbe);
        Box combinebox = Box.createHorizontalBox();
        combinebox.add(combinex);
        combinebox.add(combiney);
        combinebox.add(combinez);
        addItem(panel1, combinebox, 2, 15, 5, 1, GridBagConstraints.WEST);

        // row17
		calctimelabel.setFont(font);
        addItem(panel1, calctimelabel, 0, 16, 1, 1, GridBagConstraints.WEST);
		calctime.setEditable(true);
        addItem(panel1, calctime, 2, 16, 1, 1, GridBagConstraints.WEST);

        // row18
        Box buttonbox = Box.createHorizontalBox();
		opens.setBackground(bgcolor);
		opens.addActionListener(inilbe);
		saves.setBackground(bgcolor);
		saves.addActionListener(inilbe);
        buttonbox.add(opens);
        buttonbox.add(saves);
        addItemPadding(panel1, buttonbox, 0, 17, 7, 1, GridBagConstraints.CENTER, 20);

        panel1.setSize(panel1.getPreferredSize());
        panel1.doLayout();
        this.add(panel1);
    }

    private void addItem(JPanel p, JComponent c, int x, int y, int width, int height, int align)
    {
        GridBagConstraints gc = new GridBagConstraints();
        gc.gridx = x;
        gc.gridy = y;
        gc.gridwidth = width;
        gc.gridheight = height;
        gc.weightx = 100.0;
        gc.weighty = 100.0;
        gc.insets = new Insets(3, 3, 3, 3);
        gc.anchor = align;
        gc.fill = GridBagConstraints.NONE;
        p.add(c, gc);
    }

    private void addItemFill(JPanel p, JComponent c, int x, int y, int width, int height, int align, int fill)
    {
        GridBagConstraints gc = new GridBagConstraints();
        gc.gridx = x;
        gc.gridy = y;
        gc.gridwidth = width;
        gc.gridheight = height;
        gc.weightx = 100.0;
        gc.weighty = 100.0;
        gc.insets = new Insets(5, 5, 5, 5);
        gc.anchor = align;
        gc.fill = fill;
        p.add(c, gc);
    }

    private void addItemPadding(JPanel p, JComponent c, int x, int y, int width, int height, int align, int padding)
    {
        GridBagConstraints gc = new GridBagConstraints();
        gc.gridx = x;
        gc.gridy = y;
        gc.gridwidth = width;
        gc.gridheight = height;
        gc.weightx = 100.0;
        gc.weighty = 100.0;
        gc.insets = new Insets(padding, padding, padding, padding);
        gc.anchor = align;
        gc.fill = GridBagConstraints.NONE;
        p.add(c, gc);
    }

}
