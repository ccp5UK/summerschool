import javax.swing.*;
import java.util.*;
import java.lang.*;
import java.io.*;
import java.awt.*;
import java.awt.event.*;
import java.awt.geom.*;
import java.awt.image.*;
/*
 *     DL_MESO_GUI
 *     author: R. S. Qin, M. A. Seaton
 *     copyright: UKRI STFC Daresbury Laboratory and CCP5
 *     2005, 2018
 */
class setSolute extends JFrame {

    setlbeSysEvt solinilbe=new setlbeSysEvt(this);
    Font font=new Font("Dialog", Font.BOLD, 13);

    JLabel concenlabel = new JLabel("initial solute concentrations:",
				    JLabel.RIGHT);
    JTextField[] iniconcen = new JTextField[6];
   
/*    JLabel toplabel = new JLabel("top:", JLabel.RIGHT);
    JTextField[] topconcen = new JTextField[6];
    
    JLabel dowlabel = new JLabel("bottom:", JLabel.RIGHT);
    JTextField[] dowconcen = new JTextField[6];
    
    JLabel leflabel = new JLabel("left:", JLabel.RIGHT);
    JTextField[] lefconcen = new JTextField[6];
    
    JLabel riglabel = new JLabel("right:", JLabel.RIGHT);
    JTextField[] rigconcen = new JTextField[6];

    JLabel frolabel = new JLabel("front:", JLabel.RIGHT);
    JTextField[] froconcen = new JTextField[6];
    
    JLabel baclabel = new JLabel("back:", JLabel.RIGHT);
    JTextField[] bacconcen = new JTextField[6]; */
    
    JLabel viscositylabel = new JLabel("solute relaxation time:",
				       JLabel.RIGHT);
    JTextField[] diffusivities = new JTextField[6];
    
    JButton save = new JButton("SAVE C");
    JButton close = new JButton("CANCEL C");
    
    public setSolute(int totc, int dim, double[] solrelax, double[] concs) {
	super("LBE solute properties");
	setBounds(170, 120, 250+70*totc, 320);
	JPanel pane=new JPanel(new GridBagLayout());

        for(int i=0; i<totc; i++) {
            addItem(pane, new JLabel("solute "+i), i+1, 0, 1, 1, GridBagConstraints.CENTER);
        }
	
        concenlabel.setFont(font);
        addItem(pane, concenlabel, 0, 1, 1, 1, GridBagConstraints.WEST);

        for(int i=0; i<totc; i++) {
            iniconcen[i]=new JTextField(5);
            iniconcen[i].setText(Double.toString(concs[i]));
            addItem(pane, iniconcen[i], 1+i, 1, 1, 1, GridBagConstraints.CENTER);
        }
        
        viscositylabel.setFont(font);
        addItem(pane, viscositylabel, 0, 2, 2, 1, GridBagConstraints.WEST);
	
        for(int i=0; i<totc; i++) {
            diffusivities[i]=new JTextField(5);
            diffusivities[i].setText(Double.toString(solrelax[i]));
            addItem(pane, diffusivities[i], 1+i, 2, 1, 1, GridBagConstraints.CENTER);
        }
	
        Box buttonBox = Box.createHorizontalBox();
        save.setFont(font);
        save.addActionListener(solinilbe);
        buttonBox.add(save);
        close.setFont(font);
        close.addActionListener(solinilbe);
        buttonBox.add(close);
        addItem(pane, buttonBox, 0, 3, 3, 1, GridBagConstraints.WEST);

        this.add(pane);
        this.pack();
        setVisible(true);
    }

    private void addItem(JPanel p, JComponent c, int x, int y, int width, int height, int align)
    {
        GridBagConstraints gc = new GridBagConstraints();
        gc.gridx = x;
        gc.gridy = y;
        gc.gridwidth = width;
        gc.gridheight = height;
        gc.weightx = 100.0;
        gc.weighty = 100.0;
        gc.insets = new Insets(5, 5, 5, 5);
        gc.anchor = align;
        gc.fill = GridBagConstraints.NONE;
        p.add(c, gc);
    }

}
