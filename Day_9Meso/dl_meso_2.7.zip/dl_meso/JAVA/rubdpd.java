import javax.swing.*;
import java.util.*;
import java.lang.*;
import java.io.*;
import java.awt.*;
import java.awt.event.*;
import java.awt.geom.*;
import java.awt.image.*;
/*
 *     DL_MESO_GUI
 *     author: R. S. Qin, W. Smith and M. A. Seaton 2006, 2018
 *     copyright: UKRI STFC Daresbury Laboratory and CCP5
 */
class rubdpd extends JPanel {
    rubdpdEvt cdpd = new rubdpdEvt(this); 
    
    Font font=new Font("Dialog", Font.BOLD, 12);
    Color paneltop=new Color(170, 170, 230);
    
    JPanel row1a =new JPanel();
    JPanel row1b =new JPanel();
    
    JPanel row2a =new JPanel();
    JComboBox<String> command= new JComboBox<String>();
    JTextField commandalt = new JTextField (10);
    JPanel row2b =new JPanel();
    
    JPanel row3 =new JPanel();    
    JLabel info1 = new JLabel("You may need to write the job script file"
			      + " for your machine");
    JPanel row31 =new JPanel();
    JButton runbutton = new JButton("RUN DPD");

    public rubdpd() {
        setSize(620, 530);
        GridLayout gl =new GridLayout(6, 1, 5, 5);
        FlowLayout fl = new FlowLayout(FlowLayout.CENTER);
        BorderLayout bl = new BorderLayout();
        setLayout(gl);
        add(row1a);
        add(row1b);
        command.addItem("Choose a Command");
        command.addItem("./dpd.exe");
        command.addItem("dpd.exe");
        command.addItem("llsubmit hpc-script");
        command.addItem("bsub ibm-script");
        command.addItem("qsub cray-script");
        command.addItem("other ...");
        command.addItemListener(cdpd);
        row2a.setLayout(fl);
        row2a.add(command);
        row2a.add(commandalt);
        add(row2a);
        runbutton.addActionListener(cdpd);
        row2b.add(runbutton);
        add(row2b);
        row31.setLayout(fl);
        row31.add(info1);
        add(row31);
    }
}
