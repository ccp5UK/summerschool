#include "plbe.hpp"

int main(int argc, char** argv)
{
  bigend = fBigEndian();
  fStartMPI(argc, argv);
  fDefineSystem("lbin.sys");
  fDefineDomain();
  fStartDLMESO();
  fMemoryAllocation();
  fGetModel();
  fDefineNeighbours();
  fDefineMessage();
  fPrintSystemInfo();
  fAllReady();
  fPrintDomainInfo();
  fAllReady();
  fInputParameters("lbin.sys");
  fPrintParameters();
  fReadSpaceParameter("lbin.spa");
  fCreateIOGroups();
  fNeighbourBoundary();
  fBoundNonBlockCommunication();
  fMarkBoundArea();
  fInitializeSystem();               // assuming no restart for this simulation
  fReadInitialState("lbin.init");
  fAllReady();
  fOutputInfo();
  if(outformat==2)                   // Grid for Plot3D output files
    fOutputGrid();  
  if(interact==1 || interact==2)
    fCalcPotential_ShanChen();
  timetotal=fCheckTimeMPI();
  for(int i=0; i<= lbtotstep; i++) { 
    fNonBlockCommunication();
    if(lbcurstep==lbtotstep || (lbdump>0 && lbcurstep%lbdump == 0))
      fWriteRestart();
    if(i%lbsave  == 0) {
      fOutputVTKP();                 // Substitute with required file type and/or output
      qVersion++;
      if(lbdm.rank == 0)
        cout << i << " \t ";
      fPrintSystemMass();
      fPrintSystemMomentum();
    }
    fInteractionForceZero();         // Remove if no additional forces or mesophase interactions used
    fCalcPotential_ShanChen();       // Substitute with required potential/phase index/density/concentration gradients
                                     // (or remove if no mesophase interactions required)
//  fIndexNonBlockCommunication();   // Required for Lishchuk continuum-based interactions and Swift free-energy interactions
    fInteractionForceShanChen();     // Substitute with required mesophase interactions and/or add additional forces
    fForceNonBlockCommunication();   // Remove if no additional forces or mesophase interactions used
    switch (nonnewtonian) {          // Remove this switch block if only simple Newtonian fluids are in use
      case 1:
        fGetSystemOmegaSimple();
        break;
      case 2:
        fGetSystemOmega();
        break;
    }
    fCollisionBGK();                 // Substitute with required collision and forcing algorithm
    fPostCollBoundary();
    fPropagationCombinedSwap();
    fPostPropBoundary();
  }
  timetotal=fCheckTimeMPI();
  fFreeMemory();
  fFinishDLMESO();
  fCloseMPI();
  return 0;
}

