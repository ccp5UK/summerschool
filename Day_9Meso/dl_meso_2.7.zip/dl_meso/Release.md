Release notes for DL_MESO
=========================

Version 2.7 rev 11: 2024-07-04
-------------------------------

+ Bug fix:
  + DL_MESO_DPD:
    + Corrected second stage of Shardlow integrator to properly integrate random forces
    + Corrected virial and stress tensor assignment for DPD-VV and Shardlow integrators to avoid double-counting of particle pairs crossing subdomains
    + Update of serial version of timchk subroutine to use 64-bit system clock (reduces possibility of reporting negative times due to cycle overflow)
    + Corrected assignment of global particle indices and species when gathering data for CONFIG file writing in serial 
    + Minor corrections to OpenMP subroutines
    + isosurfaces.F90: Corrected check for first trajectory frame, increased tolerance for finding eigenvalues (previous value occasionally caused infinite loops due to calculational precision)
    + local.F90: Revised calculations of time-averaged velocities and temperatures to account for temporarily empty voxels (e.g. when using many-body DPD)
    + rdf.F90: Corrected values of Fourier-transformed RDFs written to RDFDAT files 
    + rdfmol.F90: Corrected values of Fourier-transformed RDFs written to RDFMOLDAT files
    + widom.F90: Corrected reading of vacuum gap information from CONTROL file 

+ Improvements:
  + Updates to version numbers and dates printed during simulations

+ Documentation:
  + Minor changes to user manual
  + Updates to README and Release.md file

Version 2.7 rev 10a: 2022-07-19
-------------------------------

+ Bug fix:
  + DL_MESO_DPD:
    + widom_insertion.F90: Fixed calculations of Ewald reciprocal space potentials (multipliers of potential energy for reciprocal vectors previously orders of magnitude too high), corrected accumulation of potentials for each trajectory frame
    
+ No changes made to version numbers/dates printed in code or documentation

Version 2.7 rev 10: 2022-03-21
------------------------------

+ Bug fixes:
  + DL_MESO_DPD:
    + Corrected long-range terms for potential energy, virial and conservative stress tensor contributions when using Lennard-Jones interactions (partial reversal of changes in 2.7 rev 09)
    + widom_insertion.F90: Fixed long-range potential corrections for Lennard-Jones interactions, moved full reading of CONTROL file earlier to ensure squares of many-body DPD, real-space electrostatic and surface interaction cutoff distances are calculated correctly

+ Improvements:
  + Updates to version numbers and dates printed during simulations

+ Documentation:
  + Minor changes to user manual
  + Updates to README and Release.md file
  + New DL_MESO Technical Manual for user-developers (constructed using Doxygen and Sphinx) to document DL_MESO_LBE, DL_MESO_DPD and DL_MESO Java GUI source codes, offer advice on how to modify the codes to provide new functionalities, give further details on file formats etc.
  
Version 2.7 rev 09: 2021-09-10
------------------------------

+ Bug fixes:
  + DL_MESO_LBE:
    + Corrected Shan/Chen pseudopotential calculations for Soave-Redlich-Kwong and Peng-Robinson equations of state when using temperature fields instead of constant system temperature 
  + DL_MESO_DPD:
    + Corrected long-range terms for conservative stress tensor contributions when using Lennard-Jones interactions, including removing terms for frozen particle pairs
    + widom_insertion.F90: Additional scan of CONTROL file before reading FIELD file to obtain cutoff distance required for long-range corrections
    
+ Improvements:
  + Better formatting of input data printing to OUTPUT file in DL_MESO_DPD
  + Modified formatting of floating point numbers in VTK files written by local.F90 utility
  + Added verbose mode option in widom_insertion.F90 utility to print excess chemical potentials to screen
  + Tidying up of Fast Fourier Transform solver in dipole.F90 utility
      
+ Documentation:
  + Minor changes to user manual
  + Updates to README files
  + New Release.md file listing changes to DL_MESO over major versions and minor revisions (including bug fixes and other improvements) 
    
Version 2.7 rev 08: 2020-03-18
------------------------------

+ Bug fixes:
  + DL_MESO_LBE:
    + Corrected shear rate calculations for non-Newtonian rheological models with TRT collisions
    + Correct fluid densities in output files when using Swift free-energy interactions
  + DL_MESO_DPD:
    + Fixed reading of CONFIG files to ensure numbers of particles and species are detected correctly
    + Omitted many-body DPD self-potential terms between pairs of frozen particles
    + Corrected relative velocities when applying Peters thermostat
    
+ Improvements:
  + Clean-ups of DL_MESO_LBE, DL_MESO_DPD and utilities to remove extraneous variable declarations and ensure declared variables are initialised
  + Added OpenMP multithreading in DL_MESO_DPD for many-body DPD self-potential calculations
  + Updated SurfaceDrop DPD test case

+ Documentation:
  + Minor changes to user manual
  + Updates to README files

Version 2.7 rev 07: 2019-12-18
------------------------------

+ Bug fixes:
  + DL_MESO_DPD: Corrected radix-3 constant in internal FFT solver used for SPME calculations and dipole autocorrelation functions in dipole.F90 utility
  + convert-input.cpp: Removed extraneous keyword for CONTROL file (already printed in FIELD file)
  + widom_insertion.F90: Corrected OpenMP directives
  
+ Improvements:
  + DL_MESO_DPD and utilities: increased word length for parsing numbers, inclusion of '+' symbol when parsing real numbers
  + New utilities (export_image_xml.F90 and traject_selected_xml.F90) to produce GALAMOST XML-based files from export and HISTORY files
  + Renamed export_image.F90 to export_image_vtf.F90
  + Updates to GUI for new DL_MESO_DPD utilities
  + Minor changes to makefiles
  + Updates to version numbers and dates printed during simulations

+ Documentation:
  + Changes to manual compilation and utilities appendices in user manual
  + Updates to README files
  
Version 2.7 rev 06: 2019-12-02
------------------------------

+ Bug fixes:
  + DL_MESO_DPD: Corrected error code for attempting a restart without an export file
  + GUI: Reading equations of state for LBE simulations
  
+ Improvements:
  + New DL_MESO_DPD utiltiy (traject_xml.F90) to write GALAMOST XML-based formatted trajectory files from HISTORY to be opened in OVITO (alternative visualisation package to VMD)
  + Renamed traject.F90 and traject_selected.F90 DL_MESO_DPD utilties to traject_vtf.F90 and traject_selected_vtf.F90
  + Updates to version numbers and dates printed during simulations

+ Documentation:
  + Corrected citation in user manual
  + Small changes to utility appendix in user manual
  + Updates to README files


Version 2.7 rev 05a: 2019-10-29
-------------------------------

+ Bug fixes:
  + DL_MESO_DPD: 
    + Setting default values for frequencies of writing HISTORY, CORREL and Stress_*.d files to avoid floating-point errors if any are not specified
    + Removed superfluous OPEN statement in history_config.F90 (causing compiler errors for endianness checking)
    
+ No changes made to version numbers/dates printed in code or documentation

Version 2.7 rev 05: 2019-10-03
------------------------------

+ Bug fixes:
  + DL_MESO_LBE: 
    + Corrections for Swift free-energy interactions: parameters for local equilibrium distribution functions in three-dimensions, gradient calculation stencils and implementations of Inamuro and kinetic boundary conditions (to avoid divisions-by-zero)
    + Avoiding segmentation faults when calculation density/concentration gradients for Swift interactions
    + Corrections to Lishchuk wetting forces
  + DL_MESO_DPD: Additional error message for missing 'finish' directives at ends of molecule definitions in FIELD file
  + GUI: Reading wall interaction parameters from lbin.sys files
  
+ Improvements:
  + Updates to version numbers and dates printed during simulations

+ Documentation:
  + Small changes to general information and LBE feature chapters in user manual
  + Updates and minor corrections to README files

Version 2.7 rev 04: 2019-06-25
------------------------------

+ Bug fixes:
  + GUI: Corrected reading in of FIELD files for post-processing of results
  
+ Improvements:
  + widom_insertion.F90 utility:
    + Added options to select first and last timesteps
    + Show block average and standard deviation values for chemical potentials for each trajectory frame as well as rolling averages
    + Sped up calculations of many-body DPD potentials (separating out contributions to localised densities due to inserted particles)
    + Application of OpenMP multithreading to speed up calculations
  + Added new command-line options for Widom insertion in Process DPD data section of GUI 
  + Updates to version numbers and dates printed during simulations

+ Documentation:
  + Updates to utilities appendix in user manual
  + Updates to README files

Version 2.7 rev 03: 2019-03-19
------------------------------

+ Bug fixes:
  + Revised text parsing subroutines in DL_MESO_DPD and utilities to ensure tab characters and commas do not get included in species/molecule names or disrupt parsing of numbers (finally solves problem of reading files with tabs!)
  + Corrected intramolecular electrostatic interactions in widom_insertion.F90 utility
  
+ Improvements:
  + Added options to select first and last timesteps as well as frequency in several DL_MESO_DPD utilities (dipole.F90, isosurfaces.F90, local.F90, radius.F90, rdf.F90, rdfmol.F90)
  + Included surface interactions (with optional offset from box boundary) to widom_insertion.F90 utility
  + Updates to version numbers and dates printed during simulations
  
+ Documentation:
  + Small corrections to quickstart and DPD input files chapters, utilities appendix in user manual
  + Updates to README files

Version 2.7 rev 02: 2019-02-15
------------------------------

+ Bug fixes:
  + DL_MESO_DPD: 
    + New error messages if old style of specifying charge smearing and parameter is used (rather than tacitly using point charges) or pressure not specified when using barostat
    + Additional checks to total particle numbers when reading CONFIG and export files

+ Improvements:
  + Updates to version numbers and dates printed during simulations
  
+ Documentation:
  + New quickstart chapter in user manual
  + Small corrections to GUI chapter, DPD features chapter, DPD error and lattice schemes appendices in user manual
  + Updates to README files
  
Version 2.7 rev 01: 2019-01-07
------------------------------

+ Bug fixes:
  + DL_MESO_LBE: Formatting of solute and thermal relaxation times printed at beginnings of calculation
  + Check on particle species inside molecules in export_image.F90

+ Improvements:
  + Renaming of all Fortran files to use .F90 extension instead of .f90 to automatically invoke precompiler (and go through #ifdef options)
  + Inclusion of particle masses and charges in VTF files by traject.F90, traject_selected.F90 and export_image.F90 utilities
  + Modified CONFIG file in DPD FloryHuggins test case to use origin in centre of box instead of bottom left back corner
  + Modified PhaseSeparation case to properly use older-style CONFIG file
  + Re-runs of all test cases
  + Updates to version numbers, dates and messages at ends of simulations
  
+ Documentation:
  + Updated figures and details for DPD examples chapter in user manual
  + Corrections to appendices on input file changes and manual compilation in user manual
  + Updates to README files

Version 2.7: 2018-12-11
-----------------------

+ Improvements and new features in DL_MESO_LBE:
  + Several bug fixes
  + Addition of variant Lishchuk continuum-based interactions between fluids: Lishchuk-Spencer viscous perturbation forces and 'Spencer tensor' form (using forcing term without interfacial curvature)
  + Addition of cascaded LBE (CLBE) collisions for D2Q9, D3Q19 and D3Q27 lattice schemes
  + Addition of moment-based MRT collisions for D3Q27 lattice scheme
  + Inclusion of oscillatory boundary velocities and system-wide body forces on fluids
  + Addition of non-Newtonian rheological models by calculating shear rates from local momentum flux tensors
  + Addition of Inamuro, regularised and kinetic boundary conditions for constant velocities and densities
  + Addition of Zou-He boundary conditions for constant solute concentrations and temperatures
  + Addition of outflow boundary conditions for edge/planar boundaries around simulation box
  + Addition of He forcing terms
  + Option to gather data among groups of processor cores along Cartesian directions and write fewer files per time frame
  + Option to use MPI-IO to combine data from all processor cores into one file per time frame
  + Addition of simulation restart capability: lbout.dump file with distribution functions at all grid points, can be read into DL_MESO_LBE to resume calculation (specified by option in lbin.sys file)
  + Explicit messages identifying date, major version and revision numbers of code 
  + New utilities:
    + lbedumpinit.cpp: Uses lbout.dump restart file to create lbin.init file as initial condition for new simulation
    + lbedumpvtk.cpp: Creates a structured XML-based VTK file with current simulation state given in lbout.dump file for visualisation in Paraview

+ Improvements and new features in DL_MESO_DPD:
  + Several bug fixes, including use of Fortran 2003 features and corrections to long-range corrections for Lennard-Jones potentials
  + Option in OpenMP multithreading to sum up forces one thread at a time instead of using additional memory per thread
  + Smooth Particle Mesh Ewald (SPME) as an alternative to reciprocal-space part of standard Ewald summation
    + Compile-time options to use IBM ESSL or FFTW fast Fourier transform solvers instead of internal solver
  + Additional linear, exact Slater and sinusoidal charge smearing schemes for electrostatic interactions
    + Option to use point charges
  + Separated frozen particle walls from other surface types in CONTROL and FIELD files: can now apply reflective boundaries with these walls, setting the position in the CONTROL file
  + Additional bounceback reflections as alternative to specular reflections
  + Additional Weeks-Chandler-Andersen surface interactions
  + Stress tensors separated out by conservative, random, dissipative and kinetic contributions, averages and fluctuations reported in OUTPUT file
  + More efficient reading of input files:
    + CONTROL and FIELD files read by single processor core and results broadcast to others
    + CONFIG file divided among processor cores and particle data redistributed based on positions
  + Collection of particle data among groups of processor cores and concurrent writing to single export and HISTORY files by small number of cores using MPI-IO or streamed I/O
  + Separation of statistical accumulators and random number generator states from export into REVIVE file (accumulators written by single processor core, random number generator states by all cores using MPI-IO)
  + New Stress_*.d files reporting stress tensors separated out by contributions (similar tabulated format to CORREL)
  + 'l_init' option in CONTROL file to write CFGINI (CONFIG) file for initial configuration when starting simulation from scratch
  + Explicit messages identifying date, major version and revision numbers of code 
  + New widom_insertion.f90 utility: applies Widom insertion (trial insertion of particles or molecules) in HISTORY file trajectory frames to calculate excess chemical potentials
  + Modifications to utilities:
    + dipole.f90: now includes autocorrelation function and Fourier transform calculations previously available in dipoleaf.f90 utility (now removed)
    + molecule-generate.cpp: command-line option to write molecule configurations to separate file for use by GUI
    + All utilities changed to use new export and HISTORY file formats
      + Can now check endianness of data in HISTORY files before reading
      + No need to specify number of cores used to carry out DL_MESO_DPD calculation
      + If writing trajectory or restart data, options available to sort particles by index (due to changes in HISTORY and export files)
      + Improved command-line options for all utilities: now based on '-x' to allow options to come in any order, plus '-h' available to display available options for each utility
    
+ Improvements and new features in Java GUI:
  + Revamp of LBE system and space sections to move all details for boundary conditions to LBE space section (although some information needed in lbin.sys file)
  + Addition of new collision, forcing types, rheological models and interaction types in LBE system section
  + Addition of new charge smearing types and SPME to DPD system section
  + Revamped DPD interaction section to allow reading of existing FIELD file 

+ New/modified test cases:
  + LBE: New 2D_KarmanVortexOutflow and 2D_PowerLaw test cases
  + DPD: New AlkylSulphate and FloryHuggins test cases
  + Recalculation of all test cases with new versions of codes
  
+ Changes to documentation:
  + Removal of code development chapters and sections from user manual (to go into soon-to-be-written technical manual)
  + Revisions to cover new features and input file formats
  + Extended chapters on DL_MESO_LBE and DL_MESO_DPD features
  + Revisions to README files
  + New appendices on input file changes from previous DL_MESO versions and LBE lattice schemes


Version 2.6 rev 16: 2018-03-28
------------------------------

+ Bug fixes in DL_MESO_DPD:
  + Changes to communication subroutines for Lees-Edwards shearing boundaries to allow second calls per processor core (if systems are narrow or using small numbers of cores) and ensure values for system shifts are not modified (affects reciprocal-space part of Ewald sums)
  
  + Changes to documentation:
    + Modifications to DPD package reference chapter for above changes

Version 2.6 rev 15: 2018-02-19
------------------------------

+ Bug fix in DL_MESO_DPD: Warren's two-parameter many-body DPD interaction forces use localised densities based on all species (not individually, which can cause erroneous phase separation for multiple component systems)

+ Re-ran SurfaceDrop test case (affected by bug fix)

+ Changes to documentation:
  + Revision to results of SurfaceDrop test case in DPD example simulation chapter of user manual

Version 2.6 rev 14: 2017-12-01
------------------------------

+ Bug fixes to utilities written in C++ (lbeplot3dgather.cpp for DL_MESO_LBE, convert-input.cpp and molecule-generate.cpp for DL_MESO_DPD) to explicitly assign file existences to Booleans, in line with more recent C++ standards 

Version 2.6 rev 13: 2017-08-10
------------------------------

+ Bug fixes:
  + DL_MESO_DPD: corrected condition to determine FENE or WLC bonds are within maximum lengths to avoid divisions-by-zero
  + DL_MESO_LBE: corrected second-order gradient stencil and more efficient definitions of neighbouring grid points for serial calculations of Lishchuk continuum-based interaction model 

Version 2.6 rev 12: 2017-04-14
------------------------------

+ Bug fixes in DL_MESO_LBE:
  + Corrected specification of neighbouring grid points and weighting factors for stencils to calculate density/concentration gradients in Swift free-energy interactions
  + Corrected expressions to calculate Galilean invariance coefficients for Swift free-energy interactions
  + Corrected scaling of molecular attraction coefficients for Redlich-Kwong and Carnahan-Starling-Redlich-Kwong equations of state (Shan-Chen and Swift interactions)
  + Corrected bulk relaxation times for MRT collisions (previously erroneously replaced with antisymmetric relaxation time for TRT collisions)
  + Corrected lbeinitcreate.cpp utility to set background fluid density to zero inside fluid drops

Version 2.6 rev 11: 2017-03-27
------------------------------

+ Bug fixes in DL_MESO_DPD and utilities:
  + Replacement of strategy switching off pairwise thermostats across shearing boundaries with corrections to relative velocities across boundaries: restores Galilean invariance for systems with linear shear
  + Corrected accumulation of xz- and zx-components of stress tensors during reciprocal-space part of Ewald sum: correct pressure tensor values now given in CORREL files
  + Utilities rdf.f90 and rdfmol.f90 modified to ensure no double counting of particle/molecule pairs if system dimensions are less than 3 maximum lengths

Version 2.6 rev 10: 2017-02-07
------------------------------

+ Bug fixes in DL_MESO_DPD:
  + Removal of division-by-zero if not using many-body DPD interactions (calculating reciprocal of many-body cutoff distance)
  + Corrected calculation of stress tensors with Peters thermostat to exclude frozen beads

Version 2.6 rev 09: 2017-01-24
------------------------------

+ Bug fix in DL_MESO_DPD: corrected MPI communication to construct boundary halo for calculating localised densities, as required for many-body DPD interactions 

Version 2.6 rev 08: 2017-01-06
------------------------------

+ Bug fixes in DL_MESO_DPD and utilities:
  + Corrected real-space contributions and frozen particle correction terms for Ewald sums with (approximate) Slater-type charge smearing
  + Corrected condition to change many-body DPD link cells (if not using many-body DPD interactions) for serial version of code
  + Modified condition to expand communication buffer arrays if using barostat (particularly if simulation initially starts far from required pressure)
  + Corrected values used to calculate Fourier transforms of molecular radial distribution functions in rdfmol.f90 utility
  + Corrected variable definitions in dipole.f90 utility
  
+ Improvements:
  + Modifications to OpenMP version of real-space Ewald calculations to improve efficiency (corrected shared variables in main threaded loop)
  + Recalculation of DL_MESO_DPD Polyelectrolyte test case

  + Changes to documentation:
    + Revision of DPD features chapter to correct expressions for potentials and forces with Slater-based charge smearing and DPD example simulations chapter to update Polyelectrolyte test case


Version 2.6 rev 07: 2016-11-29
------------------------------

+ Bug fixes:
  + DL_MESO_LBE: Corrected distribution function for Zou-He constant density/pressure boundaries when using two-fluid Swift free-energy interactions
  + DL_MESO_DPD:
    + Corrected reading of parameters in CONTROL file for constant stress (surface area, surface tension and semi-isotropic) ensembles with Berendsen barostat
    + Removed extraneous array (definition and deallocation) for constant pressure systems using the Langevin barostat with DPD thermostat integrated using standard Velocity Verlet (MD-VV) 

Version 2.6 rev 06: 2016-10-10
------------------------------
+ Bug fixes:
  + DL_MESO_LBE: Corrected logic in deciding to apply constant solute concentration boundary conditions (for single solutes in three dimensions)
  + DL_MESO_DPD: Corrected array allocations and deallocations in history_config.f90 utility to allow writing of CONFIG files with less data per particle than supplied in HISTORY* files 

Version 2.6 rev 05: 2016-07-11
------------------------------

+ Bug fixes in DL_MESO_DPD:
  + Corrected printing of unit cell volume given in CONFIG files when using 'nfold' option
  + Corrected insertion of molecules provided in CONFIG files
  + Corrected end-of-file determination (of HISTORY* files) in local.f90 utility

Version 2.6 rev 04: 2016-03-01
------------------------------

+ Bug fixes in DL_MESO_DPD:
  + Corrected checks for allocating arrays based on information given in FIELD files
  + Corrected reading of HISTORY* files for numbers of timesteps in dipoleaf.f90 utility

Version 2.6 rev 03: 2016-02-12
------------------------------

+ Bug fix in DL_MESO_DPD:
  + Corrected allocation of pair data arrays used in calculations of pairwise forces (interaction and thermostat)

Version 2.6 rev 02: 2016-01-25
------------------------------

+ Bug fixes in DL_MESO_DPD:
  + Corrected allocation of pair data arrays used in recalculations of dissipative forces for DPD-VV integration (only in code without OpenMP multithreading)
  + Corrected determination of pairwise masses for Lowe-Andersen thermostat

Version 2.6 rev 01: 2016-01-11
------------------------------

+ Bug fix in DL_MESO_DPD utility traject_selected.f90: corrected writing of trajectory data to VTF file to start from first specified frame in HISTORY* (not from the first available frame)

Version 2.6: 2015-11-30
-----------------------

+ Improvements and new features in DL_MESO_LBE:
  + Several optimisations, including choice of memory layout for distribution functions to make better use of caching
  + Several bug fixes
  + Application of OpenMP multithreading over main calculation sections (collisions, propagation, mesophase interaction calculations)
  + Additional Shan-Chen interaction option with quadratic pseudopotential terms
  + Addition of local form of Lishchuk continuum-based interactions between fluids, using on-site calculations of interfacial normals (without searching surrounding grid points) and forcing terms without interfacial curvatures
  + Addition of Swift free-energy interactions for single fluid and two-fluid systems 
  + Options and parameters for surface wetting types (solid-fluid interactions) for Shan-Chen and Swift interactions
  + Addition of many pseudopotential types for Shan-Chen interactions and free energy functionals for Swift free-energy interactions, including those providing cubic and hard-sphere equations of state
  + Addition of Two-Relaxation-Time (TRT) collisions
  + Addition of Equal Difference Method (EDM) forcing
  + Output files now default to big-endian binary for serial and parallel calculations: option available to write in text/ANSI instead 

+ Improvements and new features in DL_MESO_DPD:
  + Optimisations to force calculations, including loop de-nesting and reduction in division operations, inter-core communications and non-DPD pairwise thermostatting
  + Several bug fixes
  + Application of OpenMP multithreeading for force calculations, localised density calculations for many-body DPD, bonded interactions and Ewald summation in new alternative code modules
  + Addition of Gaussian charge smearing for electrostatic interactions, including option to eliminate pairwise real-space calculations for Ewald sums
  + Addition of constant electric fields as external forces acting on charged particles
  + Inclusion of constant surface area (NPAT) and constant surface tension (NsT) ensembles with Langevin and Berendsen barostats (with semi-isotropic option for latter)
  + Addition of column headers in CORREL file to identify tabulated properties
  + 'l_scr' option in CONTROL file to redirect contents of OUTPUT file to screen or standard output
  + User selection of data level for particles output to HISTORY* files (including positions, velocities and forces)
  + New utilities:
    + dipole.f90: calculates dipole moments for charged molecules from trajectories in HISTORY* files
    + dipoleaf.f90: calculates autocorrelation functions of dipole moments for charged molecules and their Fourier transforms from trajectories in HISTORY* files
    + history_config.f90: produces CONFIG file from a selected trajectory frame given in HISTORY* files
    + isosurfaces.f90: obtains density grids of a selected particle type from HISTORY* files (output as VTK files) and calculates eigenvalues of second moment of isosurface normals as order parameter for mesophase detection
    + radius.f90: calculates end-to-end distances and radii of gyration of molecules in HISTORY* files, providing a histogram of end-to-end distances
    + rdf.f90: calculates radial distribution functions (RDFs) between pairs of particle species from trajectories given in HISTORY* files and their Fourier transforms (structural factors), optionally using OpenMP to speed up calculations
    + rdfmol.f90: calculates radial distribution functions (RDFs) between pairs of molecule types from trajectories given in HISTORY* files and their Fourier transforms (structural factors), optionally using OpenMP to speed up calculations
  + Modifications to utilities: 
    + Renaming of exportconfig.f90 to export_config.f90, exportimage.f90 to export_image.f90 and trajectselected.f90 to traject_selected.f90 
    + local.f90: calculations of localised stress tensors if forces included in HISTORY* files
    + traject.f90: optimised reading of data from HISTORY* files and writing to VTF files (no sorting by particle indices), option to write separate VTF files for unbonded and bonded particles 
    + traject_selected.f90: optimised reading of data from HISTORY* files and writing to VTF files (no sorting by particle indices)

+ Improvements and new features in Java GUI:
  + Automated detection of operating system for creating makefiles and launching utilities
  + Revamped LBE simulation properties to specify fluid interaction properties for new mesophase interactions
  + Added charge smearing schemes to DPD simulation properties
  + Modification to LBE boundary conditions to avoid use of edge and corner conditions if constant velocity/density boundaries intersect with periodic or bounceback boundaries

+ New/modified test cases:
  + LBE: New 2D_PhaseSeparation and 3D_DropShear test cases
  + DPD: New LipidBilayer and SurfaceDrop test cases
  + Recalculation of all test cases with new versions of codes
  
+ Changes to documentation:
  + Clickable links in user manual contents page
  + Revisions to cover new features and input file formats
  + Extended chapters on DL_MESO_LBE and DL_MESO_DPD features
  + Revisions to README files


Version 2.5 rev 16: 2014-12-09
------------------------------

+ Bug fix in DL_MESO_DPD: Corrected assignment of particle indices for molecules when using 'nfold' option with CONFIG file

Version 2.5 rev 15: 2014-06-14
------------------------------

+ Bug fixes in DL_MESO_DPD: 
  + Corrected virial and stress tensor calculations for bond interactions (particularly noticeable when using constant-pressure ensembles)
  + Corrected force for Morse anharmonic bonds
  
+ Changes to documentation: corrected equation for Marko-Siggia bond potential in DPD features chapter of user manual

Version 2.5 rev 14: 2014-05-06
------------------------------

+ Bug fixes in DL_MESO_DPD:
  + Corrected assignment of species to non-frozen particles while initialising simulation from scratch (excluding frozen particles used in walls)
  + Corrected calculations of correction forces for charged frozen particles with Slater-type smearing
  + Removed endianness checks in traject.f90, trajectselected.f90, local.f90, exportconfig.f90 and exportimage.f90 utilities (generally unreliable)

Version 2.5 rev 13: 2013-04-22
------------------------------

+ Bug fixes in DL_MESO_LBE:
  + Corrected writing of tags for XML-based VTK files when running in parallel with solutes
  + Corrected calculation of solute concentration for XML-based VTK files when running in serial

Version 2.5 rev 12: 2013-04-17
------------------------------

+ Bug fixes in DL_MESO_DPD:
  + Added breaking of infinite loops when constructing linked-cell lists
  + Modified calculations of pairwise thermostats (both DPD and others) to not apply thermostatting across Lees-Edwards shearing boundaries to reduce viscous damping near to boundaries (but see Version 2.6 rev 11 above)
  
+ Improvements:
  + Re-running of DL_MESO_DPD ShearFlow test case to exploit bug fixes
  
+ Changes to documentation:
  + Revision of ShearFlow test case in DPD example simulations chapter of user manual

Version 2.5 rev 11: 2013-01-31
------------------------------

+ Bug fixes in DL_MESO_DPD:
  + Corrected communications of particle forces in boundary halos for Lees-Edwards shearing boundaries
  + Corrected calculated potentials for 'standard DPD' Groot-Warren interactions (repeat from Version 2.4 rev 06)
  + Corrected DPD wall potentials and forces to match pairwise Groot-Warren forces
  + Modified timing subroutine in serial version to avoid negative tick counting

Version 2.5 rev 10: 2012-11-06
------------------------------

+ Bug fix in DL_MESO_LBE: applying collisions to grid points with Zou-He boundary conditions

+ Improvements:
  + Re-running of DL_MESO_LBE 2D_DropShear, 2D_LidCavity, 2D_Pressure, 2D_RayleighBenard, 2D_Shear, 3D_RayleighBenard and 3D_Shear test cases
  + Removal of old-style input files for DPD test cases
  
+ Changes to documentation:
  + Revision of LBE example simulations chapter to update test cases affected by bug fix and LBE package reference chapter to update code changes in user manual

Version 2.5 rev 09: 2012-10-12
------------------------------

+ Bug fixes in DL_MESO_DPD:
  + Correction to modifications of Ewald sum reciprocal space coordinates when shearing is applied
  + Corrections to exportconfig.f90 utility to correctly read export* files with two sets of particle forces (e.g. when using DPD-VV integration)
  
+ Changes to documentation:
  + Minor correction to DPD features chapter in user manual

Version 2.5 rev 08: 2012-09-03
------------------------------

+ Bug fix in DL_MESO_DPD: Corrected magnitude of random forces for Langevin barostats

+ Changes to documentation:
  + Correction to DPD features chapter in user manual to reflect above bug fix

Version 2.5 rev 07: 2012-08-22
------------------------------

+ Bug fix in DL_MESO_DPD: Corrected expressions for potential energy and forces of Lennard-Jones and Weeks-Chandler-Andersen interactions

+ Improvements:
  + Modification to restarting DPD simulations in DL_MESO_DPD to avoid needing to make changes to FIELD files when using frozen particle walls

Version 2.5 rev 06: 2012-08-06
------------------------------

+ Bug fixes in DL_MESO_DPD:
  + Corrected dissipative force import communcations for systems with DPD-VV integration but without Lees-Edwards shearing
  + Corrected writing of angle and dihedral interactions in FIELD file by molecule-generate.cpp utility

Version 2.5 rev 05: 2012-07-20
------------------------------

+ Bug fixes in DL_MESO_DPD:
  + Corrected MPI communication routines for Lees-Edwards shearing boundaries to ensure correct shifts in particle positions
  + Corrected piston random parameter and modified convergence criteria for Langevin barostat (changing from total absolute velocity differences to mean squared velocity differences)
  
+ Changes to documentation:
  + Corrected description of Langevin barostat in DPD features chapter and corrected headers for Lees-Edwards shearing subroutines in DPD package reference chapter of user manual

Version 2.5 rev 04: 2012-07-12
------------------------------

+ Bug fixes in DL_MESO_DPD:
  + Corrected reporting of dihedral information from FIELD file in OUTPUT
  + Corrected forces for harmonic cosine dihedrals
  + Reworked random assignment of species to unbonded beads during intialisation to reduce memory usage (especially for very large systems)

+ Improvements:
  + DL_MESO_LBE: Revision of C/C++ headers to remove incorrect and extraneous ones
  + DL_MESO_DPD input-convert.cpp and molecule-generate.cpp: Revision of C/C++ headers to remove incorrect and extraneous ones

+ Changes to documentation:
  + Revisions to LBE theory chapter to improve clarity
  + Changes to LBE basic definition chapter to update and correct information about DL_MESO_LBE

Version 2.5 rev 03: 2012-05-03
------------------------------

+ Bug fix in DL_MESO_DPD: Correction to parsing of double precision real numbers that do not include decimal points

Version 2.5 rev 02: 2012-04-27
------------------------------

+ Bug fixes in DL_MESO_DPD:
  + Removal of division-by-zero when initialising systems without unbonded particles
  + Corrected assignment of molecule positions and types when reading CONFIG files

+ Bug fix in DL_MESO_LBE: removal of division-by-zero if Boussinesq forces are applied with referencee temperatures set to zero

+ Improvements:
  + DL_MESO_DPD: parallel particle deport communication routines no longer dependent on boundary halo size
  + Additional error checks in DL_MESO_DPD utility molecule-generate.cpp
  + DL_MESO_LBE 2D_LidCavity test case modified to use incompressible fluid and calculation re-run
  + New button in LBE and DPD system sections to open existing lbin.sys or CONTROL file and read values into GUI
  + Changes to default values for input file parameters in GUI
  
+ Changes to documentation:
  + Revisions and corrections to GUI and LBE features chapters, and manual compilation appendix in user manual
  + Update to  2D_LidCavity test case in LBE example simulations chapter

Version 2.5 rev 01: 2012-04-18
------------------------------

+ Improvements to GUI:
  + Added Lees-Edwards shear as surface option in DPD system window
  + Added suggested default values for barostats, electrostatics and Stoyanov-Groot thermostat
  
+ Changes to documentation:
  + Updated GUI chapter in user manual

Version 2.5: 2012-04-11
-----------------------

+ Improvements and new features in DL_MESO_LBE:
  + Main codes (slbe.cpp and plbe.cpp) revised to allow users to specify collision/forcing, mesophase interaction algorithm, fluid compressibility and output file format in lbin.sys rather than modifying source code
    + Still possible to customise which routines are used with slbecustom.cpp and plbecustom.cpp source files
  + Several bug fixes and a new function to avoid divisions-by-zero
  + New file output routines to write all available data to files (Plot3D, legacy VTK, XML-based VTK)
  + Additional Shan-Chen interaction option with wetting effects (solid-fluid interactions)
  + Addition of Lishchuk continuum-based interactions between fluids for hydrodynamically-driven systems
  + Boussinesq (temperature-dependent buoyancy) forces available for simulations with convection effects
  + New utility (lbeinitcreate.cpp) to create lbin.init files with fluid drops and rectangular/cuboidal regions of fixed solute concentrations or temperature

+ Improvements and new features in DL_MESO_DPD:
  + Change to dynamically allocatable arrays for particle, species and interaction data: no limits on numbers of particles per processor core or particle species
  + Changes to double precision floating point numbers throughout code to explicitly specify real type with required precision (substituting FORTRAN77 deprecated double precision type)
  + Changes to input file formats to more human-friendly forms, close to those used in DL_POLY:
    + CONTROL file consists of human-readable keywords and values, particle species and interaction data moved to FIELD
    + FIELD file consists of sections with keywords for particle species, interactions and molecule definitions
    + MOLECULE file no longer needed (contents now in FIELD file)
  + 'nfold' option added for CONTROL file to duplicate system provided in CONFIG file and start larger simulations
  + Different conservative interaction types between pairs of particle species now available (can run simulations with mixtures of Lennard-Jones, WCA, DPD and many-body DPD interactions)
  + Added stress tensor calculations, results reported in CORREL
  + Added frozen particlea to fix particles of a particular species in place, allowing them to interact but not move
    + Additional option in CONTROL and FIELD files to set up frozen particle lattices as walls around outside of simulation box
  + Added Lees-Edwards shearing periodic boundary conditions to apply linear shear (constant velocity gradients) to particles
  + New convert-input.cpp utility to convert input files (CONTROL, FIELD, MOLECULE) from earlier versions of DL_MESO_DPD to new (DL_POLY-style) files (CONTROL, FIELD)
  + Modifications to utilities: 
    + exportconfig.f90: can take command-line options to provide number of processor cores (nodes) used to run DL_MESO_DPD and CONFIG file key (specifying level of particle data needed in CONFIG file)
    + exportimage.f90: can take command-line options to provide number of processor cores (nodes) used to run DL_MESO_DPD
    + local.f90: can take command-line options to provide number of processor cores (nodes) used to run DL_MESO_DPD and numbers of divisions of system in each direction, produces VTK file with time-averaged values of properties
    + traject.f90: can take command-line options to provide number of processor cores (nodes) used to run DL_MESO_DPD
    + trajectselected.f90: can take command-line options to provide number of processor cores (nodes) used to run DL_MESO_DPD
    + All utilities attempt to detect endianness used to write export* and HISTORY* files (but see Version 2.5 rev 13 above)

+ Improvements and new features in Java GUI:
  + Additional interaction and boundary condition options in simulation properties sections for LBE and DPD
  + Revamped DPD simulation properties section to write information in CONTROL file
  + Replacement of Set DPD Molecules window with Set DPD Interactions window to specify particle and interaction information (including creation of molecule definitions) to go into FIELD file 
  + Bug fixes to make GUI compatible with Java version 7 and upwards

+ New/modified test cases:
  + LBE: New 2D_DropShear, 2D_RayleighBenard and 3D_RayleighBenard test cases, modified 2D_LidCavity test case to give correct lid velocity
  + DPD: New PoiseuilleFlow, ShearFlow and VapourLiquid test cases, modified AmphiphileMesophases test case to give clear lamellar mesophase
  + Removal of video files (now on DL_MESO Example Simulations website)
  
+ Changes to documentation:
  + Revisions to cover new features and input file formats
  + New chapters on DL_MESO_LBE and DL_MESO_DPD input files
  + New appendix with DL_MESO_DPD error messages
  + Revisions to README files
  

Version 2.4 rev 06: 2011-12-23
------------------------------

+ Bug fix in DL_MESO_LBE:
  + Corrected values obtained for densities of fluids other than fluid 0 when writing to Legacy VTK output files
  
+ Bug fixes in DL_MESO_DPD:
  + Modification to system initialisation to prevent unbonded particles being positioned on top of each other or close together when using Lennard-Jones or Weeks-Chandler-Andersen interactions
  + Corrected calculated potentials for 'standard DPD' Groot-Warren interactions
  + Corrections to exportconfig.f90 and exportimage.f90 utilties in dealing with bonds in export* files when global bond option was used in DL_MESO_DPD calculation

Version 2.4 rev 05: 2011-09-08
------------------------------

+ Bug fix in DL_MESO_DPD: Further correction to real-space Ewald sum electrostatic force with Slater-type charge smearing 

Version 2.4 rev 04: 2011-08-09
------------------------------

+ Bug fix in DL_MESO_DPD: Correction to real-space Ewald sum electrostatic force with Slater-type charge smearing 

+ Improvements:
  + Change to assignment of particles in linked-cell lists for Ewald sums to only include charged particles
  + Correction made to DL_MESO_DPD Polyelectrolyte test case to apply correct charges (zero) on polymer particles for neutral polymer simulation 

Version 2.4 rev 03: 2011-07-28
------------------------------

+ Bug fix in DL_MESO_LBE:
  + Avoidance of division-by-zero when calculating equilibrium velocities for BGK collisions (if density of individual fluid is zero)
  
+ Bug fixes in DL_MESO_DPD:
  + Corrections made to assigning molecule numbers and dihedrals to table when reading CONFIG files
  + Correction made to writing HISTORY* files when using global bond interactions in parallel running (only getting processor core 0 to write bond data)
  + Amended traject.f90 and trajectselected.f90 utilities to add last numbered particle to VTF files to enable these can be read by VMD  
  
+ Improvements:
  + Modifications to subroutines contracting bond, angle and dihedral tables in DL_MESO_DPD to avoid zeroing shifted entries (improves efficiency of calculations) 

Version 2.4 rev 02: 2011-06-17
------------------------------

+ Bug fixes in DL_MESO_LBE:
  + Replacement of Zou-He boundary conditions with Inamuro conditions for constant solute concentration and temperature boundaries (solves problem of overly-high velocities calculated for Zou-He conditions: eventually fixed in DL_MESO version 2.7)
  + Correction in reading densities (pressures) for given number of fluids in lbin.init file
  + Amendment to lbeplot3dgather.cpp utility to read and write grid files for two-dimensional simulations
  
+ Bug fix in DL_MESO_DPD: Ensure arrays used to store and share locations of particles in molecules are zeroed before use

+ Bug fixes in GUI:
  + Added default values to thermal properties in subwindow for LBE system section
  + Corrections in passing number of dimensions to and using this value in LBE space section
  
+ Changes to documentation:
  + Revision of boundary conditions for solute concentrations and temperatures in LBE features chapter of user manual

Version 2.4 rev 01: 2011-06-07
------------------------------

+ Bug fix in DL_MESO_DPD: Corrections in boundary halo creation MPI communications when using hard surfaces (avoiding sending data to beyond surfaces) to avoid orphaned send/receive calls

Version 2.4: 2011-06-01
-----------------------

+ Improvements and new features in DL_MESO_LBE:
  + New swap-based propagation routines to improve calculational efficiency (by default, two separate swaps in serial and one combined swap in parallel)
  + New serial code (slbecombine.cpp) to use of combined swap propagation option in single processor core runs, with additional routines to fill boundary halos in serial runs
  + Additional option to apply forces to fluids using Guo algorithm
  + Moments-based multiple-relaxation-time (MRT) collision schemes for D2Q9, D3Q15 and D3Q19 lattices
  + Option to use exactly incompressible fluids (modification to local equilibrium distribution function to include constant densities)
  + Zou-He boundary conditions for constant velocity/density available for all four lattices
  + Addition of mid-link bounceback boundary conditions for any lattice site
  + New input file (lbin.init) to read initial conditions for simulation, overwriting default values obtained from lbin.sys
  + Additional XML-based VTK output format (text/ANSI in serial, binary in parallel) for visualisation in Paraview
  + New utility (lbevtkgather.cpp) to create linking files for XML-based VTK output files created in parallel
  + Utility to gather Plot3D output files renamed to lbeplot3dgather.cpp
  + Makefile for DL_MESO_LBE utilities added in LBE/utility folder

+ Improvements and new features in DL_MESO_DPD:
  + Restructured modules with subroutines and functions to reduce number of duplicates for serial/parallel versions
  + Increased maximum number of particle species from 4 to 6
  + Range of pairwise thermostats and implementations: DPD Velocity Verlet (DPD-VV), Lowe-Andersen, Peters, Stoyanov-Groot
  + Langevin and Berendsen barostats coupled to thermostats for constant pressure (NPT) ensembles
  + Addition of many-body (density-dependent) DPD conservative interactions with Warren's two-parameter implementation for vapour-liquid systems
  + Addition of electrostatic interactions with (approximate) exponential (Slater-like) charge smearing using Ewald summation
  + Addition of hard surfaces around simulation box with specular reflection and Groot-Warren ('standard DPD') wall interactions
  + Addition of constant body force option on all particles (e.g. gravity)
  + New (optional) CONFIG file to specify initial configuration of particles in simulation: uses similar format to DL_POLY
  + New exportconfig.f90 utility added to produce CONFIG file from export* files
  + New trajectselected.f90 utility to generate VTF files from HISTORY* files with a limited subset of particles and/or trajectory frames
  + Modifications to utilities: 
    + molecule-generate.cpp: enables detection of available particle species from CONTROL file and allows user to specify which species are used in molecules
    + exportimage.f90: now able to read export* files from both serial and parallel runs of DL_MESO_DPD
    + traject.f90: now able to read HISTORY* files from both serial and parallel runs of DL_MESO_DPD
    + local.f90: now able to read HISTORY* files from both serial and parallel runs of DL_MESO_DPD
  + Makefile for DL_MESO_DPD utilities added in DPD/utility folder

+ Improvements and new features in Java GUI:
  + Revamped and tidied up layout in all sections, including pop-up subwindows for fluid/particle properties available by clicking buttons
  + Added new Set DPD Molecules window with 'create molecules' button (launches molecule-generate.cpp utility) and specifications of bond interactions and molecule definitions 
  + Greater flexibility in code compilation, running, result gathering/processing and plotting sections

+ New/modified test cases:
  + LBE: New 2D_KarmanVortex and 2D_LidCavity test cases
  + DPD: Reworked MicelleSelfAssemble test case into AmphiphileMesophases test case, new Polyelectrolyte and VesicleFormation test cases
  
+ Changes to documentation:
  + Division of user manual into separate parts for DL_MESO_LBE and DL_MESO_DPD
  + New chapters on DL_MESO_LBE and DL_MESO_DPD code features
  + Separated appendices on DL_MESO codes and utilities, new appendix with Licence Agreement
  + Addition of LICENCE (Academic Licence Agreement) to folder
  + Revisions to README files


Version 2.3 rev 03: 2011-03-11
------------------------------

+ Bug fix in DL_MESO_DPD: Corrected conditions for detecting when to contract bond, angle and dihedral tables during parallel deport communication step

Version 2.3 rev 02: 2010-08-25
------------------------------

+ Bug fixes in DL_MESO_DPD:
  + Modified searches of global/local particle index list for bonded particles to detect duplicate entries for global particle indices (will be next to each other in list)
  + Corrected reading of export file in exportimage_ser.f90 utility to obtain numbers of particles, bonds, angles and dihedrals etc.

Version 2.3 rev 01: 2010-05-24
------------------------------

+ Bug fixes in DL_MESO_LBE:
  + Added additional call to fill boundary halo points with distribution functions between collisions and propagation
  + Moved first call of communication to occur before output files are written

Version 2.3: 2010-05-12
-----------------------

+ Improvements and new features in DL_MESO_LBE:
  + Bug fixes in parallel version to initialise system correctly and obtain distribution functions in boundary halos at correct times
  + Additional (legacy) VTK output format (text/ANSI in serial, binary in parallel) for visualisation in Paraview
  + Small improvements to Plot3D output file writing
  + lbegather.cpp now in LBE/utilities folder

+ Improvements and new features in DL_MESO_DPD:
  + Switch from C++ to Fortran: started from FORTRAN77 DL_DPD code and converted to Fortran90 
  + Gathered subroutines and functions into modules, with alternatives for serial/parallel versions
  + Added makefiles to compile and link DL_MESO_DPD modules into an executable (DPD/makefiles)
  + Limit removed on numbers of processor cores (no longer have to be a power of 2)
  + Non-cubic orthorhombic simulation volumes
  + User-specifable conservative force parameters between particles of different types (overriding default of using mixing rules)
  + Added bond, angle and dihedral forces between particles in defined molecules
  + New input files to define molecules (particles connected by bonds): MOLECULE for particle locations, FIELD to specify bond/angle/dihedral interactions between particle pairs, triples or quadruples inside molecules
  + New trajectory file(s) HISTORY*: saves particle positions and velocities at user-specified intervals (one file per processor core)
  + Modified restart file format (now called export*) to one file per processor core to store all particle data (parallel code previously did not do this)
  + Statistics file (previously PLOTFILE) now called CORREL and prints additional data (e.g. bond lengths, angles and dihedrals)
  + New utilities (some with different versions to deal with outputs from serial and parallel versions of DL_MESO_DPD) in DPD/utilities folder:
    + molecule-generate.cpp: generates MOLECULE and FIELD files for chain molecules constructed using a random walk confined inside a cube
    + exportimage_ser.f90 and exportimage_par.f90: generate a VTF file from export* files (generated by DL_MESO_DPD as restart capability) to visualise simulation state in VMD
    + traject_ser.f90 and traject_par.f90: gather up particle data from HISTORY* files and generates a VTF file to visualise simulation trajectory in VMD
    + local_ser.f90 and local_par.f90: divides volume into slices/cuboids and calculates local properties (temperature, density, velocity) inside each division, generating VTK files to visualise in Paraview

+ Improvements and new features in Java GUI:
  + Modified DPD system section to include new options for trajectory (HISTORY*) files
  + Modified DPD compilation section to generate and use makefile

+ New/modified test cases:
  + LBE: New 2D_CylinderFlow test case
  + DPD: Renamed mixture test cases to Mixture_Par and Mixture_Ser, new Aggregate, MicelleSelfAssemble and PhaseSeparation test cases
  + Added visualisations of test cases (pictures or AVI videos)

+ Changes to documentation:
  + New DPD basic definition and DPD package reference chapters in user manual
  + Appendix in user manual on manual compilation and running of DL_MESO_LBE and DL_MESO_DPD, how to compile and use available utilities
  + New README files for DL_MESO package and utilities


Version 2.2: 2006-11-21
-----------------------

+ Features in DL_MESO_LBE:
  + Serial and MPI-based (domain decomposed) parallel versions in C++
    + Customisable base codes
  + D2Q9, D3Q15, D3Q19 and D3Q27 lattice schemes
  + BGK (single relaxation time) collisions for multiple fluids, solutes and temperature field
  + Shan-Chen mesoscopic interactions (using 1993 pseudopotential form)
  + On-site bounceback and blank site boundary conditions at any grid point
  + Zou-He constant velocity/density/concentration/temperature (D2Q9 and D3Q19 only) boundary conditions at edges/planes of simulation box, equilibrium forcing at corners and edges
  + Reads simulation information from lbin.sys file, boundary condition information from lbin.spa file
  + Simulation outputs (snapshots) in Plot3D format: utility to gather together data generated by parallel version of DL_MESO_LBE
  
+ Features in DL_MESO_DPD:
  + Newly-created DPD code - separate serial and MPI-based (domain decomposed) parallel versions - in C++
    + Parallel version runs on numbers of processor cores equal to a power of 2
    + Cubic system volumes with periodic boundaries
  + Applies DPD thermostat (pairwise dissipative and random forces) to interacting particles, using Velocity Verlet force integration
  + Up to 4 particle species with Lennard-Jones, Weeks-Chandler-Andersen or Groot-Warren ('standard DPD') conservative interaction forces
    + Face-centred cubes for total numbers of particles (maximum of 32000 particles per processor core)
    + Lorentz-Berthelot (geometric mean energy parameter, arithmetic mean interaction distance) mixing rules for interactions between different species
  + Reads simulation information from CONTROL file
  + Saves statistical data to tabulated PLOTFILE file
  + Simulation restart capability in EXPORT file (particle coordinates, velocities and forces, statistical properties and accumulators, random number generator state)

+ Java Graphical User Interface (GUI)
  + Enables input files to be created for both DL_MESO_LBE and DL_MESO_DPD
  + Options to edit, compile and run codes, to collect data and plot results (not all working as intended) 

+ Test cases
  + LBE: 2D_Pressure, 2D_Shear, 3D_PhaseSeparation, 3D_Shear
  + DPD: Parallel (512000 particles, 2 species) and serial (1000 particles, 3 species) mixtures

+ Documentation:
  + User manual with sections on general information, the DL_MESO GUI, basic theory of LBE and DPD, DL_MESO_LBE basic definition, examples (test cases) and DL_MESO_LBE package reference  
