import javax.swing.*;
import java.util.*;
import java.lang.*;
import java.io.*;
import java.awt.*;
import java.awt.event.*;
import java.awt.geom.*;
import java.awt.image.*;
/*
 *     DL_MESO_GUI
 *     author: R. S. Qin, M. A. Seaton
 *     copyright: UKRI STFC Daresbury Laboratory and CCP5
 *     2005, 2018
 */
class gatherlbeEvt implements ItemListener, ActionListener{
    gatherlbe gui;
    static String ostype,utilcmd,outtype="",rcmd="gather-file"; 
    private static String OS = System.getProperty("os.name").toLowerCase();
    public gatherlbeEvt(gatherlbe in){
        gui = in;
    }

    public void actionPerformed(ActionEvent event) {
        String cmd =event.getActionCommand();
        if (cmd == "Gather data"){
            if (isWindows())
                ostype="";
            else if (isMac())
                ostype="./";
            else if (isUnix())
                ostype="./";
            rcmd = ostype + utilcmd;
            if (utilcmd=="plot3d.exe" || utilcmd=="vtk.exe")
                rcmd = rcmd + outtype;
            try {
                Process p2 = Runtime.getRuntime().exec(rcmd);
                BufferedReader ou2 = new BufferedReader
                (new InputStreamReader(p2.getInputStream()));
                String line2;
                while ((line2 = ou2.readLine()) != null)
                    System.out.println(line2);
            } catch (IOException e1) {
                System.out.println(e1);
            }
        }
    }
    public void itemStateChanged(ItemEvent event) {
        Object item=event.getItem();
        String answer=item.toString();
        if(answer == "Plot3D") {
            utilcmd="plot3d.exe";
            gui.vtktype.setEnabled(true);	
        }
        else if(answer == "VTK") {
            utilcmd="vtk.exe";
            gui.vtktype.setEnabled(true);	
        }
        else if(answer == "lbout.dump to VTK") {
            utilcmd="dump_to_vtk.exe";
            outtype="";
            gui.vtktype.setEnabled(false);
        }
        else if(answer == "lbout.dump to lbin.init") {
            utilcmd="dump_to_init.exe";
            outtype="";
            gui.vtktype.setEnabled(false);
        }
        else if(answer == "all")
            outtype="";
        else if(answer == "density")
            outtype=" -d";
        else if(answer == "mass fraction")
            outtype=" -f";
        else if(answer == "solute concentration")
            outtype=" -c";
        else if(answer == "temperature")
            outtype=" -t";
    }

    public static boolean isWindows() {
        return (OS.indexOf("win") >= 0);
    }
    
    public static boolean isMac() {
        return (OS.indexOf("mac") >= 0);
    }
    
    public static boolean isUnix() {
        return (OS.indexOf("nix") >= 0 || OS.indexOf("nux") >= 0 || OS.indexOf("aix") >= 0 || OS.indexOf("sunos") >= 0 );
    }

}
