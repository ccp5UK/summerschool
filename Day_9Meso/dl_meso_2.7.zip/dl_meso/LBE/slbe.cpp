#include "slbe.hpp"

int main(int argc, char* argv[])
{
  bigend = fBigEndian();
  lbcurstep = 0;
  fDefineSystem();
  fSetSerialDomain();
  fStartDLMESO();
  fMemoryAllocation();
  fGetModel();
  fPrintSystemInfo();
  fsPrintDomainInfo();
  fInputParameters();
  fPrintParameters();
  fReadSpaceParameter();
  fsCreateIOGroups();
  fNeighbourBoundary();
  if(lbrestart>0) {
    fReadRestart("lbout.dump");
    if(postequil>0) {
      fReadSpaceParameter();
      fNeighbourBoundary();
    }
  }
  else {
    fInitializeSystem();
    fReadInitialState();
  }
  if(outformat==2)  // Grid for Plot3D output files
    fsOutputGrid(); 
  if(interact==1 || interact==2)
    fCalcPotential_ShanChen();
  timetotal=fCheckTimeSerial();
  switch (interact) {
    case 0:
    // no mesoscopic interactions
      fsNoInteract();
      break;
    case 1:
    // Shan/Chen pseudopotential interactions
      fsShanChen();
      break;
    case 2:
    // Shan/Chen pseudopotential interactions with quadratic pseudopotential term
      fsShanChenQuadratic();
      break;
    case 10:
    // Lishchuk continuum-based interactions (with interfacial normals determined non-locally)
      fsLishchuk();
      break;
    case 11:
    // Lishchuk-Spencer continuum-based interactions (with interfacial normals determined non-locally)
      fsLishchukSpencer();
      break;
    case 12:
    // Lishchuk-Spencer-tensor continuum-based interactions (with interfacial normals determined non-locally)
      fsLishchukSpencerTensor();
      break;
    case 13:
    // Lishchuk continuum-based interactions (with interfacial normals determined locally)
      fsLishchukLocal();
      break;
    case 20:
    // Swift free-energy interactions
      fsSwift();
      break;
  }
  if(lbcurstep<=lbtotstep) {
    fWriteRestart();
    if(lbcurstep==lbtotstep) lbcurstep -= 1;
    fPrintEarlyTermination();
  }
  timetotal=fCheckTimeSerial();
  fFreeMemory();
  fFinishDLMESO();
  return 0;
}

