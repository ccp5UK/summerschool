import javax.swing.*;
import java.util.*;
import java.lang.*;
import java.io.*;
import java.awt.*;
import java.awt.event.*;
import java.awt.geom.*;
import java.awt.image.*;
/*
 *     DL_MESO_GUI
 *     author: R. S. Qin, M. A. Seaton
 *     copyright: UKRI STFC Daresbury Laboratory and CCP5
 *     2005, 2018
 */
class setBarostat extends JFrame {

    setdpdSysEvt barinidpd=new setdpdSysEvt(this);
    Font font=new Font("Dialog", Font.BOLD, 13);

    JLabel barotype = new JLabel("THERMOSTAT TYPE", JLabel.RIGHT);
    JLabel abarolabel = new JLabel("barostat parameter a:", JLabel.RIGHT);
    JLabel bbarolabel = new JLabel("barostat parameter b:", JLabel.RIGHT);
    JLabel cbarolabel = new JLabel("barostat parameter c:", JLabel.RIGHT);
    JTextField abaro = new JTextField("0.0", 7);
    JTextField bbaro = new JTextField("0.0", 7);
    JTextField cbaro = new JTextField("0.0", 7);

    JCheckBox isotrop = new JCheckBox("semi-isotropic system");
    JButton save = new JButton("SAVE B");
    JButton close = new JButton("CANCEL B");
    
    public setBarostat(int bt, double ab, double bb, double cb, boolean iso) {
	super("DPD barostat properties");
	setBounds(170, 120, 320, 200);
	JPanel pane=new JPanel(new GridBagLayout());

        if (bt==1) { 
           barotype.setText("LANGEVIN NPT (constant pressure)");
           abarolabel.setText("barostat relaxation time:");
           bbarolabel.setText("piston drag coefficient:");
           abarolabel.setFont(font);
           bbarolabel.setFont(font);
           addItem(pane, abarolabel, 0, 1, 1, 1, GridBagConstraints.WEST);
           addItem(pane, bbarolabel, 0, 2, 1, 1, GridBagConstraints.WEST);
           abaro.setText(Double.toString(ab));
           bbaro.setText(Double.toString(bb));
           addItem(pane, abaro, 1, 1, 1, 1, GridBagConstraints.WEST);
           addItem(pane, bbaro, 1, 2, 1, 1, GridBagConstraints.WEST);
        }
        else if (bt==2) {
            barotype.setText("LANGEVIN NPAT (constant surface area)");
            abarolabel.setText("barostat relaxation time:");
            bbarolabel.setText("piston drag coefficient:");
            abarolabel.setFont(font);
            bbarolabel.setFont(font);
            addItem(pane, abarolabel, 0, 1, 1, 1, GridBagConstraints.WEST);
            addItem(pane, bbarolabel, 0, 2, 1, 1, GridBagConstraints.WEST);
            abaro.setText(Double.toString(ab));
            bbaro.setText(Double.toString(bb));
            addItem(pane, abaro, 1, 1, 1, 1, GridBagConstraints.WEST);
            addItem(pane, bbaro, 1, 2, 1, 1, GridBagConstraints.WEST);
        }
        else if (bt==3) {
            barotype.setText("LANGEVIN NsT (constant surface tension)");
            abarolabel.setText("barostat relaxation time:");
            bbarolabel.setText("piston drag coefficient:");
            cbarolabel.setText("surface tension (z-component):");
            abarolabel.setFont(font);
            bbarolabel.setFont(font);
            cbarolabel.setFont(font);
            addItem(pane, abarolabel, 0, 1, 1, 1, GridBagConstraints.WEST);
            addItem(pane, bbarolabel, 0, 2, 1, 1, GridBagConstraints.WEST);
            addItem(pane, cbarolabel, 0, 3, 1, 1, GridBagConstraints.WEST);
            abaro.setText(Double.toString(ab));
            bbaro.setText(Double.toString(bb));
            cbaro.setText(Double.toString(cb));
            addItem(pane, abaro, 1, 1, 1, 1, GridBagConstraints.WEST);
            addItem(pane, bbaro, 1, 2, 1, 1, GridBagConstraints.WEST);
            addItem(pane, cbaro, 1, 3, 1, 1, GridBagConstraints.WEST);
            isotrop.setSelected(iso);
            addItem(pane, isotrop, 0, 4, 2, 1, GridBagConstraints.WEST);
        }
        else if (bt==4) {
            barotype.setText("BERENDSEN NPT (constant pressure)");
            abarolabel.setText("compressibility/relaxation:");
            abarolabel.setFont(font);
            addItem(pane, abarolabel, 0, 1, 1, 1, GridBagConstraints.WEST);
            abaro.setText(Double.toString(ab));
            addItem(pane, abaro, 1, 1, 1, 1, GridBagConstraints.WEST);
        }           
        else if (bt==5) {
            barotype.setText("BERENDSEN NPAT (constant surface area)");
            abarolabel.setText("compressibility/relaxation:");
            abarolabel.setFont(font);
            addItem(pane, abarolabel, 0, 1, 1, 1, GridBagConstraints.WEST);
            abaro.setText(Double.toString(ab));
            addItem(pane, abaro, 1, 1, 1, 1, GridBagConstraints.WEST);
        }
        else if (bt==6) {
            barotype.setText("BERENDSEN NsT (constant surface tension)");
            abarolabel.setText("compressibility/relaxation:");
            bbarolabel.setText("surface tension (z-component):");
            abarolabel.setFont(font);
            bbarolabel.setFont(font);
            addItem(pane, abarolabel, 0, 1, 1, 1, GridBagConstraints.WEST);
            addItem(pane, bbarolabel, 0, 2, 1, 1, GridBagConstraints.WEST);
            abaro.setText(Double.toString(ab));
            bbaro.setText(Double.toString(bb));
            addItem(pane, abaro, 1, 1, 1, 1, GridBagConstraints.WEST);
            addItem(pane, bbaro, 1, 2, 1, 1, GridBagConstraints.WEST);
            isotrop.setSelected(iso);
            addItem(pane, isotrop, 0, 3, 2, 1, GridBagConstraints.WEST);
        }

        barotype.setFont(font);
        addItem(pane, barotype, 0, 0, 2, 1, GridBagConstraints.WEST);


        Box buttonBox = Box.createHorizontalBox();
        save.setFont(font);
        save.addActionListener(barinidpd);
        buttonBox.add(save);
        close.setFont(font);
        close.addActionListener(barinidpd);
        buttonBox.add(close);
        addItem(pane, buttonBox, 0, 5, 2, 1, GridBagConstraints.WEST);

        this.add(pane);
        this.pack();
        setVisible(true);
    }

    private void addItem(JPanel p, JComponent c, int x, int y, int width, int height, int align)
    {
        GridBagConstraints gc = new GridBagConstraints();
        gc.gridx = x;
        gc.gridy = y;
        gc.gridwidth = width;
        gc.gridheight = height;
        gc.weightx = 100.0;
        gc.weighty = 100.0;
        gc.insets = new Insets(5, 5, 5, 5);
        gc.anchor = align;
        gc.fill = GridBagConstraints.NONE;
        p.add(c, gc);
    }

}
