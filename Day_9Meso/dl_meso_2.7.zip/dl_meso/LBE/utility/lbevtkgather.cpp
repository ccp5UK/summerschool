#include <iostream>
#include <iomanip>
#include <fstream>
#include <string>
#include <cstring>
#include <cstdlib>
#include <stdio.h>
#include <sys/stat.h>
using namespace std;
int outtype,numfluid,numsolute,numtemp;

/**************************************************
 *   DL_MESO       Version 2.7                    *
 *   Authors   :   R. S. Qin, M. A. Seaton        *
 *   Copyright :   UKRI STFC Daresbury Laboratory *
 *             :   09/12/2018                     *
 **************************************************/

class cGatherData
{

  // creates parallel VTK files (lbtout%.6d.pvts) to link files created by
  // individual processes (lbout*.vts), where %.6d is the saved time step

  // the data structure follows the VTK XML standard for structured grids
  
public:

  cGatherData()
    {

      getsize();
      gatherallVTK();

    }

  ~cGatherData()
    {

    }

  int getsize();

  int gatherallVTK();
  
protected:

  int sizeofint;

  int sizeofsys;

  int sizeofver;

  int ntx, nty, ntz;

  int *xs, *xe, *ys, *ye, *zs, *ze;

};


int cGatherData::getsize()
{

  // this procedure is required to avoid mismatches caused by different 
  // machines

  char buf[80];
  char issue[22];
  int x1, x2, y1, y2, z1, z2;
  int j=0;

//  if (outtype<0 || outtype>4)
//    {
//      cout<<"Which output type was produced?"<<endl;
//      cout<<"(0 = all, 1 = density, 2 = mass fraction, 3 = solute concentration, 4 = temperature)"<<endl;
//      while (outtype<0 || outtype>4)
//        {
//          cin >> outtype;
//        }
//    }

  ifstream myfile("lbout.info");

  if(!myfile)
    {
      cout<<"error opening "<<"lbout.info"<<" file\n"; 
      exit(1);
    }

  while (!myfile.eof() && j<5)
    {

      myfile >> issue >> x1;

      if(!strcmp(issue, "sizeofSystem")) {
        sizeofsys = int(x1);
        j++;
      }
      else if(!strcmp(issue, "sizeofInteger")) {
        sizeofint = int(x1);
        j++;
      }
      else if(!strcmp(issue, "numberofFluids")) {
        numfluid = int(x1);
        j++;
      }
      else if(!strcmp(issue, "numberofSolutes")) {
        numsolute = int(x1);
        j++;
      }
      else if(!strcmp(issue, "numberofTemperatures")) {
        numtemp = int(x1);
        j++;
      }
    }

  myfile.close();

  xs=new int[sizeofsys];
  xe=new int[sizeofsys];
  ys=new int[sizeofsys];
  ye=new int[sizeofsys];
  zs=new int[sizeofsys];
  ze=new int[sizeofsys];

  //  this procedure can deal with unequal numbers of grid points among
  //  processes

  struct stat results;

  for(int i=0; i<sizeofsys; i++)
    {
      sprintf(buf, "lbout%.6dat000000.vts", i);

      if(stat(buf, &results) != 0) {
        cout<<"error opening "<<buf<<" file\n";
        exit(1);
      }

    }

  //  work out the number of VTK-files available

  int i=0;
  
  while(1)
    {

      sprintf(buf, "lbout000000at%.6d.vts", i);

      ifstream myfile(buf);

      if(!myfile)
        {
          sizeofver = i;
          break;
        }
      
      i++;
      
    }

  //  determine sizes of extents for pieces and entire system

  ifstream myfile1("lbout.ext");

  if(!myfile1)
    {
      cout<<"error opening lbout.ext file\n"; 
      exit(1);
    }

  ntx = 0;
  nty = 0;
  ntz = 0;

  while (!myfile1.eof())
    {
      myfile1 >> issue >> x1 >> x2 >> y1 >> y2 >> z1 >> z2;
      for(int i=0; i<sizeofsys; i++) {
        sprintf(buf, "extent_%.6d", i);
        if(!strcmp(issue, buf)) {
          xs[i] = x1;
          xe[i] = x2;
          ys[i] = y1;
          ye[i] = y2;
          zs[i] = z1;
          ze[i] = z2;
          if(x2>ntx)
            ntx = x2;
          if(y2>nty)
            nty = y2;
          if(z2>ntz)
            ntz = z2;
        } 

      }
      
    }

  myfile1.close();

  return 0;
  
}


int cGatherData::gatherallVTK()
{

  // write .pvts file for each timestep

  char namebuf[80];

  for(int k=0; k<sizeofver; k++) {

    sprintf(namebuf, "lbtout%.6d.pvts", k);

    ofstream ofile(namebuf);

    ofile<<"<?xml version=\"1.0\"?>"<<endl;
    ofile<<"<VTKFile type=\"PStructuredGrid\" version=\"0.1\" byte_order=\"BigEndian\">"<<endl;
    ofile<<"<PStructuredGrid WholeExtent=\"0 "<<ntx<<" 0 "<<nty<<" 0 "<<ntz<<"\" GhostLevel=\"1\">"<<endl;
    ofile<<"<PPointData Scalars=\"phase_field\" Vectors=\"velocity\">"<<endl;

    switch (outtype) {
      case 0:
        for(int iprop=0; iprop<numfluid; iprop++)
          ofile<<"<PDataArray Name=\"density_"<<iprop<<"\" type=\"Float32\"/>"<<endl;
        for(int iprop=0; iprop<numfluid; iprop++)
          ofile<<"<PDataArray Name=\"fraction_"<<iprop<<"\" type=\"Float32\"/>"<<endl;
        for(int iprop=0; iprop<numsolute; iprop++)
          ofile<<"<PDataArray Name=\"concentration_"<<iprop<<"\" type=\"Float32\"/>"<<endl;
        if(numtemp==1)
          ofile<<"<PDataArray Name=\"temperature\" type=\"Float32\"/>"<<endl;
        break;
      case 1:
        ofile<<"<PDataArray Name=\"density\" type=\"Float32\"/>"<<endl;
        break;
      case 2:
        ofile<<"<PDataArray Name=\"fraction\" type=\"Float32\"/>"<<endl;
        break;
      case 3:
        ofile<<"<PDataArray Name=\"concentration\" type=\"Float32\"/>"<<endl;
        break;
      case 4:
        ofile<<"<PDataArray Name=\"temperature\" type=\"Float32\"/>"<<endl;
        break;
    }

    ofile<<"<PDataArray Name=\"velocity\" type=\"Float32\" NumberOfComponents=\"3\"/>"<<endl;
    ofile<<"<PDataArray Name=\"phase_field\" type=\"Int32\"/>"<<endl;
    ofile<<"</PPointData>"<<endl;
    ofile<<"<PPoints>"<<endl;
    ofile<<"<PDataArray type=\"Float32\" NumberOfComponents=\"3\"/>"<<endl;
    ofile<<"</PPoints>"<<endl;

    for(int i=0; i<sizeofsys; i++) {
      ofile<<"<Piece Extent=\""<<xs[i]<<" "<<xe[i]<<" "<<ys[i]<<" "<<ye[i]<<" "<<zs[i]<<" "<<ze[i]
           <<"\" Source=\"lbout"<<setw(6)<<setfill('0')<<i<<"at"<<setw(6)<<setfill('0')<<k<<".vts\"/>"<<endl;
    }

    ofile<<"</PStructuredGrid>"<<endl;
    ofile<<"</VTKFile>"<<endl;
    ofile.close();

  }

  return 0;
}


int main(int argc, char* argv[])
{
  string word;
  outtype=0;
  for(int i=1; i<argc; i++) {
    word = argv[i];
    if(word.compare(0,2,"-a")==0 || word.compare(0,2,"-A")==0)
      outtype = 0;
    else if(word.compare(0,2,"-d")==0 || word.compare(0,2,"-D")==0)
      outtype = 1;
    else if(word.compare(0,2,"-f")==0 || word.compare(0,2,"-F")==0)
      outtype = 2;
    else if(word.compare(0,2,"-c")==0 || word.compare(0,2,"-C")==0)
      outtype = 3;
    else if(word.compare(0,2,"-t")==0 || word.compare(0,2,"-T")==0)
      outtype = 4;
    else if(word.compare(0,2,"-h")==0 || word.compare(0,2,"-H")==0) {
      cout << "DL_MESO VTK gather utility, creates linking *.pvts files" << endl;
      cout << "for *.vts files generated when running DL_MESO in parallel" << endl;
      cout << "to allow easy visualization (requires lbout.info and" << endl;
      cout << "lbout.ext files)" << endl;
      cout << "Usage: " << argv[0] << " [OPTIONS]" << endl << endl;
      cout << "Options:" << endl << endl;
      cout << "-h" << endl;
      cout << "       display this help and exit" << endl << endl;
      cout << "-a" << endl;
      cout << "       create linking files for *.vts files with all properties" << endl;
      cout << "       (densities, mass fractions, solute concentrations and" << endl;
      cout << "       temperatures): default option" << endl << endl;
      cout << "-d" << endl;
      cout << "       create linking files for *.vts files with a single fluid" << endl;
      cout << "       density" << endl << endl;
      cout << "-f" << endl;
      cout << "       create linking files for *.vts files with a single fluid" << endl;
      cout << "       mass fraction" << endl << endl;
      cout << "-c" << endl;
      cout << "       create linking files for *.vts files with a single solute" << endl;
      cout << "       concentration" << endl << endl;
      cout << "-t" << endl;
      cout << "       create linking files for *.vts files with temperatures only" << endl << endl;
      exit(0);
    }
  }

  cGatherData aa;

  return 0;
}
