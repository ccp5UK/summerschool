/***************************************************
 *   DL_MESO       Version 2.7                     *
 *   Authors   :   R. S. Qin, M. A. Seaton         *
 *   Copyright :   UKRI STFC Daresbury Laboratory  *
 *             :   09/12/2018                      *
 ***************************************************/

// D2Q9

int fD2Q9VCEInamuro(double v0, double v1, double *force,
                    double *f0, double *f1, double *f2,
	                double *f3, double *f4, double *f5,
                    double *f6, double *f7, double *f8)
{

  // produce fixed velocity at bottom boundary (VCETF) for compressible/incompressible fluids

  double rho, rho0, rrho0, rhop, v0t;
  double c1=1.0/9.0,c2=1.0/36.0;
    
  if(!incompress) {
    for(int i=0; i<lbsy.nf; i++) {
      rho = (f0[i]+f2[i]+f6[i]+2.0*(f3[i]+f4[i]+f5[i])-0.5*force[2*i+1])/(1.0-v1);
      rhop = 6.0*(rho*v1+f3[i]+f4[i]+f5[i]-0.5*force[2*i+1])/(1.0+3.0*v1*(1.0+v1));
      v0t = 6.0*(rho*v0+f2[i]+f3[i]-f5[i]-f6[i]-force[2*i  ])/(rhop*(1.0+3.0*v1)); // v0t = v0 + v0s
      f1[i]=c2*rhop*(1.0+3.0*(v1*(1.0+v1)-v0t*(1.0-v0t))-9.0*v0t*v1);
      f7[i]=c2*rhop*(1.0+3.0*(v1*(1.0+v1)+v0t*(1.0+v0t))+9.0*v0t*v1);
      f8[i]=c1*rhop*(1.0+3.0*v1*(1.0+v1)-1.5*v0t*v0t);
    }
  }
  else {
    for(int i=0; i<lbsy.nf; i++) {
      rho0 = lbincp[i];
      rrho0 = fReciprocal(rho0);
      rhop = 6.0*(f3[i]+f4[i]+f5[i])+3.0*rho0*v1*(1.0-v1)-3.0*force[2*i+1];
      v0t = 6.0*(v0+(f2[i]+f3[i]-f5[i]-f6[i]-0.5*force[2*i  ])*rrho0)/(1.0+3.0*v1); // v0t = v0 + v0s
      f1[i]=c2*(rhop+rho0*(3.0*(v1*(1.0+v1)-v0t*(1.0-v0t))-9.0*v0t*v1));
      f7[i]=c2*(rhop+rho0*(3.0*(v1*(1.0+v1)+v0t*(1.0+v0t))+9.0*v0t*v1));
      f8[i]=c1*(rhop+rho0*(3.0*v1*(1.0+v1)-1.5*v0t*v0t));
    }
  }
  return 0;
}

int fD2Q9VCCInamuro(double *p, double v0, double v1, double *force,
                    double *f0, double *f1, double *f2,
	                double *f3, double *f4, double *f5,
                    double *f6, double *f7, double *f8)
{

  // produce fixed velocity at bottom left corner boundary (VCCTRF) for compressible/incompressible fluids

  double rho0, rhop;
  double c1=1.0/9.0,c2=1.0/36.0;

  if(!incompress) {
    for(int i=0; i<lbsy.nf; i++) {
      rhop = 36.0*(p[i]*(1.0+0.5*v0+0.5*v1)-f0[i]-0.5*(f2[i]+f4[i])-0.25*force[2*i]-0.25*force[2*i+1])/(16.0+24.0*(v0+v1)+21*(v0*v0+v1*v1));
      f1[i]=c2*rhop*(1.0+3.0*(v1*(1.0+v1)-v0*(1.0-v0))-9.0*v0*v1);
      f5[i]=c2*rhop*(1.0+3.0*(v0*(1.0+v0)-v1*(1.0-v1))-9.0*v0*v1);
      f6[i]=c1*rhop*(1.0+3.0*v0*(1.0+v0)-1.5*v1*v1);
      f7[i]=c2*rhop*(1.0+3.0*(v1*(1.0+v1)+v0*(1.0+v0))+9.0*v0*v1);
      f8[i]=c1*rhop*(1.0+3.0*v1*(1.0+v1)-1.5*v0*v0);
    }
  }
  else {
    for(int i=0; i<lbsy.nf; i++) {
      rho0 = lbincp[i];
      rhop = 2.25*(p[i]-f0[i])-1.125*(f2[i]+f4[i])-0.375*rho0*(v0+v1)-1.3125*rho0*(v0*v0+v1*v1);
      f1[i]=c2*(rhop+rho0*(3.0*(v1*(1.0+v1)-v0*(1.0-v0))-9.0*v0*v1));
      f5[i]=c2*(rhop+rho0*(3.0*(v0*(1.0+v0)-v1*(1.0-v1))-9.0*v0*v1));
      f6[i]=c1*(rhop+rho0*(3.0*v0*(1.0+v0)-1.5*v1*v1));
      f7[i]=c2*(rhop+rho0*(3.0*(v1*(1.0+v1)+v0*(1.0+v0))+9.0*v0*v1));
      f8[i]=c1*(rhop+rho0*(3.0*v1*(1.0+v1)-1.5*v0*v0));
    }
  }
  return 0;
}

int fD2Q9VCECLBEInamuro(double v0, double v1, double *force,
                        double *f0, double *f1, double *f2,
                        double *f3, double *f4, double *f5,
                        double *f6, double *f7, double *f8)
{

  // produce fixed velocity at bottom boundary (VCETF) for compressible fluids
  // using higher-order equilibrium distribution functions for CLBE collisions

  double rho, rhop, v0t;
  double c1=1.0/9.0,c2=1.0/36.0;
    
  for(int i=0; i<lbsy.nf; i++) {
    rho = (f0[i]+f2[i]+f6[i]+2.0*(f3[i]+f4[i]+f5[i])-0.5*force[2*i+1])/(1.0-v1);
    rhop = 6.0*(rho*v1+f3[i]+f4[i]+f5[i]-0.5*force[2*i+1])/(1.0+3.0*v1*(1.0+v1));
    v0t = 6.0*(rho*v0+f2[i]+f3[i]-f5[i]-f6[i]-force[2*i  ])/(rhop*(1.0+3.0*v1*(1.0+v1))); // v0t = v0 + v0s
    f1[i]=c2*rhop*(1.0+3.0*(v1*(1.0+v1)-v0t*(1.0-v0t))-9.0*v0t*v1*(1.0-v0t)*(1.0+v1));
    f7[i]=c2*rhop*(1.0+3.0*(v1*(1.0+v1)+v0t*(1.0+v0t))+9.0*v0t*v1*(1.0+v0t)*(1.0+v1));
    f8[i]=c1*rhop*(1.0+3.0*v1*(1.0+v1)-1.5*v0t*v0t*(1.0+3.0*v1*(1.0+v1)));
  }
  return 0;
}

int fD2Q9VCCCLBEInamuro(double *p, double v0, double v1, double *force,
                        double *f0, double *f1, double *f2,
                        double *f3, double *f4, double *f5,
                        double *f6, double *f7, double *f8)
{

  // produce fixed velocity at bottom left corner boundary (VCCTRF) for compressible fluids
  // using higher-order equilibrium distribution functions for CLBE collisions

  double rhop;
  double c1=1.0/9.0,c2=1.0/36.0;
    
  for(int i=0; i<lbsy.nf; i++) {
    rhop = 36.0*(p[i]*(1.0+0.5*v0+0.5*v1)-f0[i]-0.5*(f2[i]+f4[i])-0.25*force[2*i]-0.25*force[2*i+1])/(16.0+24.0*(v0+v1)+21*(v0*v0+v1*v1)-9.0*v0*v1*(v0+v1+v0*v1));
    f1[i]=c2*rhop*(1.0+3.0*(v1*(1.0+v1)-v0*(1.0-v0))-9.0*v0*v1*(1.0-v0)*(1.0+v1));
    f5[i]=c2*rhop*(1.0+3.0*(v0*(1.0+v0)-v1*(1.0-v1))-9.0*v0*v1*(1.0+v0)*(1.0-v1));
    f6[i]=c1*rhop*(1.0+3.0*v0*(1.0+v0)-1.5*v1*v1*(1.0+3.0*v0*(1.0+v0)));
    f7[i]=c2*rhop*(1.0+3.0*(v1*(1.0+v1)+v0*(1.0+v0))+9.0*v0*v1*(1.0+v0)*(1.0+v1));
    f8[i]=c1*rhop*(1.0+3.0*v1*(1.0+v1)-1.5*v0*v0*(1.0+3.0*v1*(1.0+v1)));
  }
  return 0;
}

int fD2Q9VCESwiftInamuro(double v0, double v1, double *force,
                         double *f0, double *f1, double *f2,
                         double *f3, double *f4, double *f5,
                         double *f6, double *f7, double *f8,
	                     double drdx, double drdy, double dpdx, double dpdy,
                         double nabr, double nabp, double *omega, double T)
{

  // produce fixed velocity at bottom boundary (VCETF) for compressible fluids with Swift free-energy interactions

  double rho, phi, omegat, pb, mu, lambda, d2rdx2, d2rdy2, d2rdxdy, nabrp, rhop, phip, v0t;
  double c0=1.0/3.0,c1=1.0/6.0,c2=1.0/12.0,c3=1.0/24.0;

  rho = (f0[0]+f2[0]+f6[0]+2.0*(f3[0]+f4[0]+f5[0])-0.5*force[1])/(1.0-v1);
  if(lbsy.nf>1) {
    phi = (f0[1]+f2[1]+f6[1]+2.0*(f3[1]+f4[1]+f5[1]))/(1.0-v1);
    omegat = 0.5*(1.0+phi)*omega[0]+0.5*(1.0-phi)*omega[1];
    mu = lbfemob*fGetPotentialSwift(phi, nabp);
    d2rdx2 = (lbfeeos>0)?(drdx*drdx):0.0 + dpdx*dpdx;
    d2rdy2 = (lbfeeos>0)?(drdy*drdy):0.0 + dpdy*dpdy;
    d2rdxdy = (lbfeeos>0)?(drdx*drdy):0.0 + dpdx*dpdy;
    nabrp = (lbfeeos>0)?(rho*nabr):0.0 + phi*nabp;
    if(fCppAbs(v1)>0.0)
      phip = (2.0*(phi-f0[1]-f2[1]-f3[1]-f4[1]-f5[1]-f6[1])-mu)*fReciprocal(v1*(1.0+v1));
    else
      phip = phi;
    f1[1]=c2*phip*(v0*(v0-1.0)+v1*(v1+1.0))-0.25*phip*v0*v1+c2*mu;
    f7[1]=c2*phip*(v0*(v0+1.0)+v1*(v1+1.0))+0.25*phip*v0*v1+c2*mu;
    f8[1]=c0*phip*v1*(1.0+v1)-c1*phip*v0*v0+c0*mu;
  }
  else {
    phi = 0.0;
    omegat = omega[0];
    d2rdx2 = drdx*drdx;
    d2rdy2 = drdy*drdy;
    d2rdxdy = drdx*drdy;
    nabrp = rho*nabr;
  }
  pb = fGetBulkPressureSwift(rho, phi, T);
  lambda = fGetLambdaSwift(rho, omegat, T);
  rhop = (2.0*(rho*v1+f3[0]+f4[0]+f5[0])-force[1]-pb+lbkappa*(nabrp+0.5*d2rdx2-0.5*d2rdy2)-lambda*(1.5*v0*drdx+3.5*v1*drdy))*fReciprocal(v1*(1.0+v1));
  if(rhop<lbevaplim)
    rhop = rho;
  v0t = (6.0*(rho*v0+f2[0]+f3[0]-f5[0]-f6[0])-3.0*force[0]-3.0*lambda*(v1*drdx+v0*drdy)-3.0*lbkappa*d2rdxdy)*fReciprocal(rhop*(1.0+3.0*v1));
  f1[0]=c2*rhop*(v0t*(v0t-1.0)+v1*(v1+1.0))-0.25*rhop*v0t*v1+lambda*(0.375*(v0*drdx+v1*drdy)-0.25*(v1*drdx+v0*drdy))
       +c2*(pb-lbkappa*nabrp)-lbkappa*(c3*(d2rdx2+d2rdy2)+0.25*d2rdxdy);
  f7[0]=c2*rhop*(v0t*(v0t+1.0)+v1*(v1+1.0))+0.25*rhop*v0t*v1+lambda*(0.375*(v0*drdx+v1*drdy)+0.25*(v1*drdx+v0*drdy))
       +c2*(pb-lbkappa*nabrp)-lbkappa*(c3*(d2rdx2+d2rdy2)-0.25*d2rdxdy);
  f8[0]=c0*rhop*v1*(1.0+v1)-c1*rhop*v0t*v0t+lambda*v1*drdy+c0*(pb-lbkappa*nabrp)+lbkappa*(c0*d2rdy2-c1*d2rdx2);
  return 0;
}

int fD2Q9VCCSwiftInamuro(double *p, double v0, double v1, double *force,
                         double *f0, double *f1, double *f2,
	                     double *f3, double *f4, double *f5,
                         double *f6, double *f7, double *f8,
	                     double drdx, double drdy, double dpdx, double dpdy,
                         double nabr, double nabp, double *omega, double T)
{

  // produce fixed velocity at bottom left corner boundary (VCETF)
  // for compressible fluids with Swift free-energy interactions

  double rho, phi, omegat, pb, mu, lambda, d2rdx2, d2rdy2, d2rdxdy, nabrp, rhop, phip;
  double c0=1.0/3.0,c1=1.0/6.0,c2=1.0/12.0,c3=1.0/24.0,c4=4.0/3.0;

  rho = p[0];
  if(lbsy.nf>1) {
    phi = p[1];
    omegat = 0.5*(1.0+phi)*omega[0]+0.5*(1.0-phi)*omega[1];
    mu = lbfemob*fGetPotentialSwift(phi, nabp);
    d2rdx2 = (lbfeeos>0)?(drdx*drdx):0.0 + dpdx*dpdx;
    d2rdy2 = (lbfeeos>0)?(drdy*drdy):0.0 + dpdy*dpdy;
    d2rdxdy = (lbfeeos>0)?(drdx*drdy):0.0 + dpdx*dpdy;
    nabrp = (lbfeeos>0)?(rho*nabr):0.0 + phi*nabp;
    if(fCppAbs(v0)>0.0 || fCppAbs(v1)>0.0)
      phip = (12.0*(phi-f0[1]-f2[1]-f3[1]-f4[1])-11.0*mu)*fReciprocal(5.0*(v0+v1+v0*v0+v1*v1));
    else
      phip = phi;
    f1[1]=c2*phip*(v0*(v0-1.0)+v1*(v1+1.0))-0.25*phip*v0*v1+c2*mu;
    f5[1]=c2*phip*(v0*(v0+1.0)+v1*(v1-1.0))-0.25*phip*v0*v1+c2*mu;
    f6[1]=c0*phip*v0*(1.0+v0)-c1*phip*v1*v1+c0*mu;
    f7[1]=c2*phip*(v0*(v0+1.0)+v1*(v1+1.0))+0.25*phip*v0*v1+c2*mu;
    f8[1]=c0*phip*v1*(1.0+v1)-c1*phip*v0*v0+c0*mu;
  }
  else {
    phi = 0.0;
    omegat = omega[0];
    d2rdx2 = drdx*drdx;
    d2rdy2 = drdy*drdy;
    d2rdxdy = drdx*drdy;
    nabrp = rho*nabr;
  }
  pb = fGetBulkPressureSwift(rho, phi, T);
  lambda = fGetLambdaSwift(rho, omegat, T);
  rhop = 12.0*(rho*(1.0+0.5*v0+0.5*v1)-f0[0]-0.5*(f2[0]+f4[0])-3.0*lambda*(v0*drdx+v1*drdy)-c4*(pb-lbkappa*nabrp)-c2*lbkappa*(d2rdx2+d2rdy2)-0.25*force[0]-0.25*force[1])*
              fReciprocal(8.0*(v0+v1)+7.0*(v0*v0+v1*v1));
  if(rhop<lbevaplim)
    rhop = rho;
  f1[0]=c2*rhop*(v0*(v0-1.0)+v1*(v1+1.0))-0.25*rhop*v0*v1+lambda*(0.375*(v0*drdx+v1*drdy)-0.25*(v1*drdx+v0*drdy))
       +c2*(pb-lbkappa*nabrp)-lbkappa*(c3*(d2rdx2+d2rdy2)+0.25*d2rdxdy);
  f5[0]=c2*rhop*(v0*(v0+1.0)+v1*(v1-1.0))-0.25*rhop*v0*v1+lambda*(0.375*(v0*drdx+v1*drdy)-0.25*(v1*drdx+v0*drdy))
       +c2*(pb-lbkappa*nabrp)-lbkappa*(c3*(d2rdx2+d2rdy2)+0.25*d2rdxdy);
  f6[0]=c0*rhop*v0*(1.0+v0)-c1*rhop*v1*v1+lambda*v0*drdx+c0*(pb-lbkappa*nabrp)+lbkappa*(c0*d2rdx2-c1*d2rdy2);
  f7[0]=c2*rhop*(v0*(v0+1.0)+v1*(v1+1.0))+0.25*rhop*v0*v1+lambda*(0.375*(v0*drdx+v1*drdy)+0.25*(v1*drdx+v0*drdy))
       +c2*(pb-lbkappa*nabrp)-lbkappa*(c3*(d2rdx2+d2rdy2)-0.25*d2rdxdy);
  f8[0]=c0*rhop*v1*(1.0+v1)-c1*rhop*v0*v0+lambda*v1*drdy+c0*(pb-lbkappa*nabrp)+lbkappa*(c0*d2rdy2-c1*d2rdx2);
  return 0;
}

int fD2Q9VFInamuro(long tpos, long tpos1, int prop, double *uwall, double dx, double dy, double T)
{
  long spos = tpos * lbsitelength;
  int qdim = lbsy.nf+lbsy.nc+lbsy.nt;
  double drdx, drdy, dpdx, dpdy, nabr, nabp;
  double force[2*lbsy.nf], rho[lbsy.nf];

  // sort out forces at grid point and find density at neighbouring point
    
  fD2Q9BoundaryForceVelocity(force, tpos, tpos1, dx, dy, uwall, prop);

  if(interact==20) {
    drdx = lbft[4*lbsy.nf*tpos1  ];
    drdy = lbft[4*lbsy.nf*tpos1+1];
    dpdx = (lbsy.nf>1)?lbft[4*lbsy.nf*tpos1+4]:0.0;
    dpdy = (lbsy.nf>1)?lbft[4*lbsy.nf*tpos1+5]:0.0;
    nabr = lbft[4*lbsy.nf*tpos1+3];
    nabp = (lbsy.nf>1)?lbft[4*lbsy.nf*tpos1+3]:0.0;
  }
  else {
    drdx = 0.0;
    drdy = 0.0;
    dpdx = 0.0;
    dpdy = 0.0;
    nabr = 0.0;
    nabp = 0.0;
  }
    
  if(prop>30 && prop<35) {
    fGetAllMassSite(rho, &lbf[tpos1*lbsitelength]);
    if(interact==20) {
      rho[0] += (dx*drdx+dy*drdy);
      if(lbsy.nf>1)
        rho[1] += (dx*dpdx+dy*dpdy);
    }
  }
    
  if(interact==20) {
    switch (prop) {
      case CETF:
        fD2Q9VCESwiftInamuro(uwall[0], uwall[1], &force[0], &lbf[spos], &lbf[spos+1*qdim], &lbf[spos+2*qdim],
                             &lbf[spos+3*qdim], &lbf[spos+4*qdim], &lbf[spos+5*qdim], &lbf[spos+6*qdim],
                             &lbf[spos+7*qdim], &lbf[spos+8*qdim], drdx, drdy, dpdx, dpdy, nabr, nabp,
                             &lbomega[lbsy.nf*tpos], T);
        break;
      case CELF:
        fD2Q9VCESwiftInamuro(uwall[1], -uwall[0], &force[0], &lbf[spos], &lbf[spos+3*qdim], &lbf[spos+4*qdim],
                             &lbf[spos+5*qdim], &lbf[spos+6*qdim], &lbf[spos+7*qdim], &lbf[spos+8*qdim],
                             &lbf[spos+1*qdim], &lbf[spos+2*qdim], drdy, -drdx, dpdy, -dpdx, nabr, nabp,
                             &lbomega[lbsy.nf*tpos], T);
        break;
      case CEDF:
        fD2Q9VCESwiftInamuro(-uwall[0], -uwall[1], &force[0], &lbf[spos], &lbf[spos+5*qdim], &lbf[spos+6*qdim],
                             &lbf[spos+7*qdim], &lbf[spos+8*qdim], &lbf[spos+1*qdim], &lbf[spos+2*qdim],
                             &lbf[spos+3*qdim], &lbf[spos+4*qdim], -drdx, -drdy, -dpdx, -dpdy, nabr, nabp,
                             &lbomega[lbsy.nf*tpos], T);
        break;
      case CERF:
        fD2Q9VCESwiftInamuro(-uwall[1], uwall[0], &force[0], &lbf[spos], &lbf[spos+7*qdim], &lbf[spos+8*qdim],
                             &lbf[spos+1*qdim], &lbf[spos+2*qdim], &lbf[spos+3*qdim], &lbf[spos+4*qdim],
                             &lbf[spos+5*qdim], &lbf[spos+6*qdim], -drdy, drdx, -dpdy, dpdx, nabr, nabp,
                             &lbomega[lbsy.nf*tpos], T);
        break;
      case CCTRF:
        fD2Q9VCCSwiftInamuro(rho, uwall[0], uwall[1], &force[0], &lbf[spos], &lbf[spos+1*qdim], &lbf[spos+2*qdim],
                             &lbf[spos+3*qdim], &lbf[spos+4*qdim], &lbf[spos+5*qdim], &lbf[spos+6*qdim],
                             &lbf[spos+7*qdim], &lbf[spos+8*qdim], drdx, drdy, dpdx, dpdy, nabr, nabp,
                             &lbomega[lbsy.nf*tpos], T);
        break;
      case CCTLF:
        fD2Q9VCCSwiftInamuro(rho, uwall[1], -uwall[0], &force[0], &lbf[spos], &lbf[spos+3*qdim], &lbf[spos+4*qdim],
                             &lbf[spos+5*qdim], &lbf[spos+6*qdim], &lbf[spos+7*qdim], &lbf[spos+8*qdim],
                             &lbf[spos+1*qdim], &lbf[spos+2*qdim], drdy, -drdx, dpdy, -dpdx, nabr, nabp,
                             &lbomega[lbsy.nf*tpos], T);
        break;
      case CCDLF:
        fD2Q9VCCSwiftInamuro(rho, -uwall[0], -uwall[1], &force[0], &lbf[spos], &lbf[spos+5*qdim], &lbf[spos+6*qdim],
                             &lbf[spos+7*qdim], &lbf[spos+8*qdim], &lbf[spos+1*qdim], &lbf[spos+2*qdim],
                             &lbf[spos+3*qdim], &lbf[spos+4*qdim], -drdx, -drdy, -dpdx, -dpdy, nabr, nabp,
                             &lbomega[lbsy.nf*tpos], T);
        break;
      case CCDRF:
        fD2Q9VCCSwiftInamuro(rho, -uwall[1], uwall[0], &force[0], &lbf[spos], &lbf[spos+7*qdim], &lbf[spos+8*qdim],
                             &lbf[spos+1*qdim], &lbf[spos+2*qdim], &lbf[spos+3*qdim], &lbf[spos+4*qdim],
                             &lbf[spos+5*qdim], &lbf[spos+6*qdim], -drdy, drdx, -dpdy, dpdx, nabr, nabp,
                             &lbomega[lbsy.nf*tpos], T);
        break;
    }
  }
  else if(collide>11) {
    switch (prop) {
      case CETF:
        fD2Q9VCECLBEInamuro(uwall[0], uwall[1], &force[0], &lbf[spos], &lbf[spos+1*qdim], &lbf[spos+2*qdim],
                            &lbf[spos+3*qdim], &lbf[spos+4*qdim], &lbf[spos+5*qdim], &lbf[spos+6*qdim],
                            &lbf[spos+7*qdim], &lbf[spos+8*qdim]);
        break;
      case CELF:
        fD2Q9VCECLBEInamuro(uwall[1], -uwall[0], &force[0], &lbf[spos], &lbf[spos+3*qdim], &lbf[spos+4*qdim],
                            &lbf[spos+5*qdim], &lbf[spos+6*qdim], &lbf[spos+7*qdim], &lbf[spos+8*qdim],
                            &lbf[spos+1*qdim], &lbf[spos+2*qdim]);
        break;
      case CEDF:
        fD2Q9VCECLBEInamuro(-uwall[0], -uwall[1], &force[0], &lbf[spos], &lbf[spos+5*qdim], &lbf[spos+6*qdim],
                            &lbf[spos+7*qdim], &lbf[spos+8*qdim], &lbf[spos+1*qdim], &lbf[spos+2*qdim],
                            &lbf[spos+3*qdim], &lbf[spos+4*qdim]);
        break;
      case CERF:
        fD2Q9VCECLBEInamuro(-uwall[1], uwall[0], &force[0], &lbf[spos], &lbf[spos+7*qdim], &lbf[spos+8*qdim],
                            &lbf[spos+1*qdim], &lbf[spos+2*qdim], &lbf[spos+3*qdim], &lbf[spos+4*qdim],
                            &lbf[spos+5*qdim], &lbf[spos+6*qdim]);
        break;
      case CCTRF:
        fD2Q9VCCCLBEInamuro(rho, uwall[0], uwall[1], &force[0], &lbf[spos], &lbf[spos+1*qdim], &lbf[spos+2*qdim],
                            &lbf[spos+3*qdim], &lbf[spos+4*qdim], &lbf[spos+5*qdim], &lbf[spos+6*qdim],
                            &lbf[spos+7*qdim], &lbf[spos+8*qdim]);
        break;
      case CCTLF:
        fD2Q9VCCCLBEInamuro(rho, uwall[1], -uwall[0], &force[0], &lbf[spos], &lbf[spos+3*qdim], &lbf[spos+4*qdim],
                            &lbf[spos+5*qdim], &lbf[spos+6*qdim], &lbf[spos+7*qdim], &lbf[spos+8*qdim],
                            &lbf[spos+1*qdim], &lbf[spos+2*qdim]);
        break;
      case CCDLF:
        fD2Q9VCCCLBEInamuro(rho, -uwall[0], -uwall[1], &force[0], &lbf[spos], &lbf[spos+5*qdim], &lbf[spos+6*qdim],
                            &lbf[spos+7*qdim], &lbf[spos+8*qdim], &lbf[spos+1*qdim], &lbf[spos+2*qdim],
                            &lbf[spos+3*qdim], &lbf[spos+4*qdim]);
        break;
      case CCDRF:
        fD2Q9VCCCLBEInamuro(rho, -uwall[1], uwall[0], &force[0], &lbf[spos], &lbf[spos+7*qdim], &lbf[spos+8*qdim],
                            &lbf[spos+1*qdim], &lbf[spos+2*qdim], &lbf[spos+3*qdim], &lbf[spos+4*qdim],
                            &lbf[spos+5*qdim], &lbf[spos+6*qdim]);
        break;
    }
  }
  else {
    switch (prop) {
      case CETF:
        fD2Q9VCEInamuro(uwall[0], uwall[1], &force[0], &lbf[spos], &lbf[spos+1*qdim], &lbf[spos+2*qdim],
                        &lbf[spos+3*qdim], &lbf[spos+4*qdim], &lbf[spos+5*qdim], &lbf[spos+6*qdim],
                        &lbf[spos+7*qdim], &lbf[spos+8*qdim]);
        break;
      case CELF:
        fD2Q9VCEInamuro(uwall[1], -uwall[0], &force[0], &lbf[spos], &lbf[spos+3*qdim], &lbf[spos+4*qdim],
                        &lbf[spos+5*qdim], &lbf[spos+6*qdim], &lbf[spos+7*qdim], &lbf[spos+8*qdim],
                        &lbf[spos+1*qdim], &lbf[spos+2*qdim]);
        break;
      case CEDF:
        fD2Q9VCEInamuro(-uwall[0], -uwall[1], &force[0], &lbf[spos], &lbf[spos+5*qdim], &lbf[spos+6*qdim],
                        &lbf[spos+7*qdim], &lbf[spos+8*qdim], &lbf[spos+1*qdim], &lbf[spos+2*qdim],
                        &lbf[spos+3*qdim], &lbf[spos+4*qdim]);
        break;
      case CERF:
        fD2Q9VCEInamuro(-uwall[1], uwall[0], &force[0], &lbf[spos], &lbf[spos+7*qdim], &lbf[spos+8*qdim],
                        &lbf[spos+1*qdim], &lbf[spos+2*qdim], &lbf[spos+3*qdim], &lbf[spos+4*qdim],
                        &lbf[spos+5*qdim], &lbf[spos+6*qdim]);
        break;
      case CCTRF:
        fD2Q9VCCInamuro(rho, uwall[0], uwall[1], &force[0], &lbf[spos], &lbf[spos+1*qdim], &lbf[spos+2*qdim],
                        &lbf[spos+3*qdim], &lbf[spos+4*qdim], &lbf[spos+5*qdim], &lbf[spos+6*qdim],
                        &lbf[spos+7*qdim], &lbf[spos+8*qdim]);
        break;
      case CCTLF:
        fD2Q9VCCInamuro(rho, uwall[1], -uwall[0], &force[0], &lbf[spos], &lbf[spos+3*qdim], &lbf[spos+4*qdim],
                        &lbf[spos+5*qdim], &lbf[spos+6*qdim], &lbf[spos+7*qdim], &lbf[spos+8*qdim],
                        &lbf[spos+1*qdim], &lbf[spos+2*qdim]);
        break;
      case CCDLF:
        fD2Q9VCCInamuro(rho, -uwall[0], -uwall[1], &force[0], &lbf[spos], &lbf[spos+5*qdim], &lbf[spos+6*qdim],
                        &lbf[spos+7*qdim], &lbf[spos+8*qdim], &lbf[spos+1*qdim], &lbf[spos+2*qdim],
                        &lbf[spos+3*qdim], &lbf[spos+4*qdim]);
        break;
      case CCDRF:
        fD2Q9VCCInamuro(rho, -uwall[1], uwall[0], &force[0], &lbf[spos], &lbf[spos+7*qdim], &lbf[spos+8*qdim],
                        &lbf[spos+1*qdim], &lbf[spos+2*qdim], &lbf[spos+3*qdim], &lbf[spos+4*qdim],
                        &lbf[spos+5*qdim], &lbf[spos+6*qdim]);
        break;
    }
  }
  return 0;
}


int fD2Q9PCEInamuro(double *p, double *force, double *f0, double *f1, double *f2, double *f3,
	                double *f4, double *f5, double *f6, double *f7, double *f8, double &vel)
{

  // produce fixed density/pressure boundary for concave edge pointing upwards (PCETF)

  double rho0, rrho0, rhop, v0t, v, v1, mass=0.0;
  double c1=1.0/9.0,c2=1.0/36.0;
  vel = 0.0;
    
  if(!incompress) {
    for(int i=0; i<lbsy.nf; i++) {
      v = p[i]-(f0[i]+f2[i]+f6[i]+2.0*(f3[i]+f4[i]+f5[i]))+0.5*force[2*i+1];
      vel += v;
      mass += p[i];
    }
    v1 = vel*fReciprocal(mass);
    for(int i=0; i<lbsy.nf; i++) {
      v = p[i]-(f0[i]+f2[i]+f6[i]+2*(f3[i]+f4[i]+f5[i]));
      rhop = 6.0*(v+f3[i]+f4[i]+f5[i])/(1.0+3.0*v1*(1.0+v1));
      v0t = 6.0*(f2[i]+f3[i]-f5[i]-f6[i]-0.5*force[2*i  ])/(rhop*(1.0+3.0*v1));
      f1[i]=c2*rhop*(1.0+3.0*(v1*(1.0+v1)-v0t*(1.0-v0t))-9.0*v0t*v1);
      f7[i]=c2*rhop*(1.0+3.0*(v1*(1.0+v1)+v0t*(1.0+v0t))+9.0*v0t*v1);
      f8[i]=c1*rhop*(1.0+3.0*v1*(1.0+v1)-1.5*v0t*v0t);
    }
  }
  else {
    for(int i=0; i<lbsy.nf; i++) {
      v = p[i]-(f0[i]+f2[i]+f6[i]+2.0*(f3[i]+f4[i]+f5[i]))+0.5*force[2*i+1];
      vel += v;
      mass += lbincp[i];
    }
    v1 = vel*fReciprocal(mass);
    for(int i=0; i<lbsy.nf; i++) {
      rho0 = lbincp[i];
      rrho0 = fReciprocal(rho0);
      rhop = 6.0*(f3[i]+f4[i]+f5[i])+3.0*rho0*v1*(1.0-v1)-3.0*force[3*i+1];
      v0t = 6.0*(f2[i]+f3[i]-f5[i]-f6[i]-0.5*force[2*i  ])*rrho0/(1.0+3.0*v1);
      f1[i]=c2*(rhop+rho0*(3.0*(v1*(1.0+v1)-v0t*(1.0-v0t))-9.0*v0t*v1));
      f7[i]=c2*(rhop+rho0*(3.0*(v1*(1.0+v1)+v0t*(1.0+v0t))+9.0*v0t*v1));
      f8[i]=c1*(rhop+rho0*(3.0*v1*(1.0+v1)-1.5*v0t*v0t));
    }
  }
  vel = v1;
  return 0;
}

int fD2Q9PCECLBEInamuro(double *p, double *force, double *f0, double *f1, double *f2, double *f3,
                        double *f4, double *f5, double *f6, double *f7, double *f8, double &vel)
{

  // produce fixed density/pressure boundary for concave edge pointing upwards (PCETF)
  // using higher-order equilibrium distribution functions for CLBE collisions

  double rhop, v0t, v, v1, mass=0.0;
  double c1=1.0/9.0,c2=1.0/36.0;
  vel = 0.0;

  for(int i=0; i<lbsy.nf; i++) {
    v = p[i]-(f0[i]+f2[i]+f6[i]+2.0*(f3[i]+f4[i]+f5[i]))+0.5*force[2*i+1];
    vel += v;
    mass += p[i];
  }
  v1 = vel*fReciprocal(mass);
  for(int i=0; i<lbsy.nf; i++) {
    v = p[i]-(f0[i]+f2[i]+f6[i]+2*(f3[i]+f4[i]+f5[i]));
    rhop = 6.0*(v+f3[i]+f4[i]+f5[i])/(1.0+3.0*v1*(1.0+v1));
    v0t = 6.0*(f2[i]+f3[i]-f5[i]-f6[i]-0.5*force[2*i  ])/(rhop*(1.0+3.0*v1*(1.0+v1))); // v0t = v0 + v0s
    f1[i]=c2*rhop*(1.0+3.0*(v1*(1.0+v1)-v0t*(1.0-v0t))-9.0*v0t*v1*(1.0-v0t)*(1.0+v1));
    f7[i]=c2*rhop*(1.0+3.0*(v1*(1.0+v1)+v0t*(1.0+v0t))+9.0*v0t*v1*(1.0+v0t)*(1.0+v1));
    f8[i]=c1*rhop*(1.0+3.0*v1*(1.0+v1)-1.5*v0t*v0t*(1.0+3.0*v1*(1.0+v1)));
  }
  vel = v1;
  return 0;
}

int fD2Q9PCESwiftInamuro(double *p, double *force, double *f0, double *f1, double *f2, double *f3,
                         double *f4, double *f5, double *f6, double *f7, double *f8,
                         double drdx, double drdy, double dpdx, double dpdy, double nabr, double nabp,
                         double *omega, double T, double &vel)
{

  // produce fixed density/pressure boundary for concave edge pointing upwards (PCETF)
  // with Swift free-energy interactions

  double rho, phi, omegat, pb, mu, lambda, d2rdx2, d2rdy2, d2rdxdy, nabrp, rhop, phip, v0t, v1, v;
  double c0=1.0/3.0,c1=1.0/6.0,c2=1.0/12.0,c3=1.0/24.0;
  vel = 0.0;

  rho = p[0];
  v = p[0]-(f0[0]+f2[0]+f6[0]+2.0*(f3[0]+f4[0]+f5[0]));
  vel = (v+0.5*force[1])*fReciprocal(rho);
  v1 = vel;
  if(lbsy.nf>1) {
    phi = p[1];
    omegat = 0.5*(1.0+phi)*omega[0]+0.5*(1.0-phi)*omega[1];
    mu = lbfemob*fGetPotentialSwift(phi, nabp);
    d2rdx2 = (lbfeeos>0)?(drdx*drdx):0.0 + dpdx*dpdx;
    d2rdy2 = (lbfeeos>0)?(drdy*drdy):0.0 + dpdy*dpdy;
    d2rdxdy = (lbfeeos>0)?(drdx*drdy):0.0 + dpdx*dpdy;
    nabrp = (lbfeeos>0)?(rho*nabr):0.0 + phi*nabp;
    if(fCppAbs(v1)>0.0)
      phip = (2.0*(phi-f0[1]-f2[1]-f3[1]-f4[1]-f5[1]-f6[1])-mu)*fReciprocal(v1*(1.0+v1));
    else
      phip = phi;
    f1[1]=c2*(phip*v1*(v1+1.0)+mu);
    f7[1]=c2*(phip*v1*(v1+1.0)+mu);
    f8[1]=c0*(phip*v1*(v1+1.0)+mu);
  }
  else {
    phi = 0.0;
    omegat = omega[0];
    d2rdx2 = drdx*drdx;
    d2rdy2 = drdy*drdy;
    d2rdxdy = drdx*drdy;
    nabrp = rho*nabr;
  }
  pb = fGetBulkPressureSwift(rho, phi, T);
  lambda = fGetLambdaSwift(rho, omegat, T);
  rhop = (2.0*(v+f3[0]+f4[0]+f5[0])-pb+lbkappa*(nabrp+0.5*d2rdx2-0.5*d2rdy2)-3.5*lambda*v1*drdy)*fReciprocal(v1*(1.0+v1));
  if(rhop<lbevaplim)
    rhop = rho;
  v0t = (6.0*(f2[0]+f3[0]-f5[0]-f6[0])-3.0*force[0]-3.0*lambda*v1*drdx-3.0*lbkappa*d2rdxdy)*fReciprocal(rhop*(1.0+3.0*v1));
  f1[0]=c2*rhop*(v0t*(v0t-1.0)+v1*(v1+1.0))-0.25*rhop*v0t*v1+lambda*v1*(0.375*drdy-0.25*drdx)
       +c2*(pb-lbkappa*nabrp)-lbkappa*(c3*(d2rdx2+d2rdy2)+0.25*d2rdxdy);
  f7[0]=c2*rhop*(v0t*(v0t+1.0)+v1*(v1+1.0))+0.25*rhop*v0t*v1+lambda*v1*(0.375*drdy+0.25*drdx)
       +c2*(pb-lbkappa*nabrp)-lbkappa*(c3*(d2rdx2+d2rdy2)-0.25*d2rdxdy);
  f8[0]=c0*rhop*v1*(1.0+v1)-c1*rhop*v0t*v0t+lambda*v1*drdy+c0*(pb-lbkappa*nabrp)+lbkappa*(c0*d2rdy2-c1*d2rdx2);
  return 0;
}

int fD2Q9PFInamuro(long tpos, int prop, double *p0, double *uwall, double T)
{
  double moment;
  long spos = tpos * lbsitelength;
  int qdim = lbsy.nf+lbsy.nc+lbsy.nt;
  double drdx, drdy, dpdx, dpdy, nabr, nabp;
  double force[2*lbsy.nf];

  fD2Q9BoundaryForceDensity(force, tpos, p0, prop);

  if(interact==20) {
    drdx = lbft[4*lbsy.nf*tpos  ];
    drdy = lbft[4*lbsy.nf*tpos+1];
    nabr = lbft[4*lbsy.nf*tpos+3];
    dpdx = (lbsy.nf>1)?lbft[4*lbsy.nf*tpos+4]:0.0;
    dpdy = (lbsy.nf>1)?lbft[4*lbsy.nf*tpos+5]:0.0;
    nabp = (lbsy.nf>1)?lbft[4*lbsy.nf*tpos+7]:0.0;
    switch (prop) {
      case CETF:
        fD2Q9PCESwiftInamuro(p0, &force[0], &lbf[spos], &lbf[spos+1*qdim], &lbf[spos+2*qdim],
                             &lbf[spos+3*qdim], &lbf[spos+4*qdim], &lbf[spos+5*qdim], &lbf[spos+6*qdim],
                             &lbf[spos+7*qdim], &lbf[spos+8*qdim], drdx, drdy, dpdx, dpdy, nabr, nabp,
                             &lbomega[lbsy.nf*tpos], T, moment);
        uwall[1] += moment;
        break;
      case CELF:
        fD2Q9PCESwiftInamuro(p0, &force[0], &lbf[spos], &lbf[spos+3*qdim], &lbf[spos+4*qdim],
                             &lbf[spos+5*qdim], &lbf[spos+6*qdim], &lbf[spos+7*qdim], &lbf[spos+8*qdim],
                             &lbf[spos+1*qdim], &lbf[spos+2*qdim], drdy, -drdx, dpdy, -dpdx, nabr, nabp,
                             &lbomega[lbsy.nf*tpos], T, moment);
        uwall[0] -= moment;
        break;
      case CEDF:
        fD2Q9PCESwiftInamuro(p0, &force[0], &lbf[spos], &lbf[spos+5*qdim], &lbf[spos+6*qdim],
                             &lbf[spos+7*qdim], &lbf[spos+8*qdim], &lbf[spos+1*qdim], &lbf[spos+2*qdim],
                             &lbf[spos+3*qdim], &lbf[spos+4*qdim], -drdx, -drdy, -dpdx, -dpdy, nabr, nabp,
                             &lbomega[lbsy.nf*tpos], T, moment);
        uwall[1] -= moment;
        break;
      case CERF:
        fD2Q9PCESwiftInamuro(p0, &force[0], &lbf[spos], &lbf[spos+7*qdim], &lbf[spos+8*qdim],
                             &lbf[spos+1*qdim], &lbf[spos+2*qdim], &lbf[spos+3*qdim], &lbf[spos+4*qdim],
                             &lbf[spos+5*qdim], &lbf[spos+6*qdim], -drdy, drdx, -dpdy, dpdx, nabr, nabp,
                             &lbomega[lbsy.nf*tpos], T, moment);
        uwall[0] += moment;
        break;
      case CCTRF:
        fD2Q9VCCSwiftInamuro(p0, uwall[0], uwall[1], &force[0], &lbf[spos], &lbf[spos+1*qdim], &lbf[spos+2*qdim],
                             &lbf[spos+3*qdim], &lbf[spos+4*qdim], &lbf[spos+5*qdim], &lbf[spos+6*qdim],
                             &lbf[spos+7*qdim], &lbf[spos+8*qdim], drdx, drdy, dpdx, dpdy, nabr, nabp,
                             &lbomega[lbsy.nf*tpos], T);
        break;
      case CCTLF:
        fD2Q9VCCSwiftInamuro(p0, uwall[1], -uwall[0], &force[0], &lbf[spos], &lbf[spos+3*qdim], &lbf[spos+4*qdim],
                             &lbf[spos+5*qdim], &lbf[spos+6*qdim], &lbf[spos+7*qdim], &lbf[spos+8*qdim],
                             &lbf[spos+1*qdim], &lbf[spos+2*qdim], drdy, -drdx, dpdy, -dpdx, nabr, nabp,
                             &lbomega[lbsy.nf*tpos], T);
        break;
      case CCDLF:
        fD2Q9VCCSwiftInamuro(p0, -uwall[0], -uwall[1], &force[0], &lbf[spos], &lbf[spos+5*qdim], &lbf[spos+6*qdim],
                             &lbf[spos+7*qdim], &lbf[spos+8*qdim], &lbf[spos+1*qdim], &lbf[spos+2*qdim],
                             &lbf[spos+3*qdim], &lbf[spos+4*qdim], -drdx, -drdy, -dpdx, -dpdy, nabr, nabp,
                             &lbomega[lbsy.nf*tpos], T);
        break;
      case CCDRF:
        fD2Q9VCCSwiftInamuro(p0, -uwall[1], uwall[0], &force[0], &lbf[spos], &lbf[spos+7*qdim], &lbf[spos+8*qdim],
                             &lbf[spos+1*qdim], &lbf[spos+2*qdim], &lbf[spos+3*qdim], &lbf[spos+4*qdim],
                             &lbf[spos+5*qdim], &lbf[spos+6*qdim], -drdy, drdx, -dpdy, dpdx, nabr, nabp,
                             &lbomega[lbsy.nf*tpos], T);
        break;
    }
  }
  else if (collide>11) {
    switch (prop) {
      case CETF:
        fD2Q9PCECLBEInamuro(p0, &force[0], &lbf[spos], &lbf[spos+1*qdim], &lbf[spos+2*qdim],
                            &lbf[spos+3*qdim], &lbf[spos+4*qdim], &lbf[spos+5*qdim],
                            &lbf[spos+6*qdim], &lbf[spos+7*qdim], &lbf[spos+8*qdim], moment);
        uwall[1] += moment;
        break;
      case CELF:
        fD2Q9PCECLBEInamuro(p0, &force[0], &lbf[spos], &lbf[spos+3*qdim], &lbf[spos+4*qdim],
                            &lbf[spos+5*qdim], &lbf[spos+6*qdim], &lbf[spos+7*qdim],
                            &lbf[spos+8*qdim], &lbf[spos+1*qdim], &lbf[spos+2*qdim], moment);
        uwall[0] -= moment;
        break;
      case CEDF:
        fD2Q9PCECLBEInamuro(p0, &force[0], &lbf[spos], &lbf[spos+5*qdim], &lbf[spos+6*qdim],
                            &lbf[spos+7*qdim], &lbf[spos+8*qdim], &lbf[spos+1*qdim],
                            &lbf[spos+2*qdim], &lbf[spos+3*qdim], &lbf[spos+4*qdim], moment);
        uwall[1] -= moment;
        break;
      case CERF:
        fD2Q9PCECLBEInamuro(p0, &force[0], &lbf[spos], &lbf[spos+7*qdim], &lbf[spos+8*qdim],
                            &lbf[spos+1*qdim], &lbf[spos+2*qdim], &lbf[spos+3*qdim],
                            &lbf[spos+4*qdim], &lbf[spos+5*qdim], &lbf[spos+6*qdim], moment);
        uwall[0] += moment;
        break;
      case CCTRF:
        fD2Q9VCCCLBEInamuro(p0, uwall[0], uwall[1], &force[0], &lbf[spos], &lbf[spos+1*qdim], &lbf[spos+2*qdim],
                            &lbf[spos+3*qdim], &lbf[spos+4*qdim], &lbf[spos+5*qdim], &lbf[spos+6*qdim],
                            &lbf[spos+7*qdim], &lbf[spos+8*qdim]);
        break;
      case CCTLF:
        fD2Q9VCCCLBEInamuro(p0, uwall[1], -uwall[0], &force[0], &lbf[spos], &lbf[spos+3*qdim], &lbf[spos+4*qdim],
                            &lbf[spos+5*qdim], &lbf[spos+6*qdim], &lbf[spos+7*qdim], &lbf[spos+8*qdim],
                            &lbf[spos+1*qdim], &lbf[spos+2*qdim]);
        break;
      case CCDLF:
        fD2Q9VCCCLBEInamuro(p0, -uwall[0], -uwall[1], &force[0], &lbf[spos], &lbf[spos+5*qdim], &lbf[spos+6*qdim],
                            &lbf[spos+7*qdim], &lbf[spos+8*qdim], &lbf[spos+1*qdim], &lbf[spos+2*qdim],
                            &lbf[spos+3*qdim], &lbf[spos+4*qdim]);
        break;
      case CCDRF:
        fD2Q9VCCCLBEInamuro(p0, -uwall[1], uwall[0], &force[0], &lbf[spos], &lbf[spos+7*qdim], &lbf[spos+8*qdim],
                            &lbf[spos+1*qdim], &lbf[spos+2*qdim], &lbf[spos+3*qdim], &lbf[spos+4*qdim],
                            &lbf[spos+5*qdim], &lbf[spos+6*qdim]);
        break;
    }
  }
  else {
    switch (prop) {
      case CETF:
        fD2Q9PCEInamuro(p0, &force[0], &lbf[spos], &lbf[spos+1*qdim], &lbf[spos+2*qdim],
                        &lbf[spos+3*qdim], &lbf[spos+4*qdim], &lbf[spos+5*qdim],
                        &lbf[spos+6*qdim], &lbf[spos+7*qdim], &lbf[spos+8*qdim], moment);
        uwall[1] += moment;
        break;
      case CELF:
        fD2Q9PCEInamuro(p0, &force[0], &lbf[spos], &lbf[spos+3*qdim], &lbf[spos+4*qdim],
                        &lbf[spos+5*qdim], &lbf[spos+6*qdim], &lbf[spos+7*qdim],
                        &lbf[spos+8*qdim], &lbf[spos+1*qdim], &lbf[spos+2*qdim], moment);
        uwall[0] -= moment;
        break;
      case CEDF:
        fD2Q9PCEInamuro(p0, &force[0], &lbf[spos], &lbf[spos+5*qdim], &lbf[spos+6*qdim],
  	                    &lbf[spos+7*qdim], &lbf[spos+8*qdim], &lbf[spos+1*qdim],
	                    &lbf[spos+2*qdim], &lbf[spos+3*qdim], &lbf[spos+4*qdim], moment);
        uwall[1] -= moment;
        break;
      case CERF:
        fD2Q9PCEInamuro(p0, &force[0], &lbf[spos], &lbf[spos+7*qdim], &lbf[spos+8*qdim],
                        &lbf[spos+1*qdim], &lbf[spos+2*qdim], &lbf[spos+3*qdim],
                        &lbf[spos+4*qdim], &lbf[spos+5*qdim], &lbf[spos+6*qdim], moment);
        uwall[0] += moment;
        break;
      case CCTRF:
        fD2Q9VCCInamuro(p0, uwall[0], uwall[1], &force[0], &lbf[spos], &lbf[spos+1*qdim], &lbf[spos+2*qdim],
                        &lbf[spos+3*qdim], &lbf[spos+4*qdim], &lbf[spos+5*qdim], &lbf[spos+6*qdim],
                        &lbf[spos+7*qdim], &lbf[spos+8*qdim]);
        break;
      case CCTLF:
        fD2Q9VCCInamuro(p0, uwall[1], -uwall[0], &force[0], &lbf[spos], &lbf[spos+3*qdim], &lbf[spos+4*qdim],
                        &lbf[spos+5*qdim], &lbf[spos+6*qdim], &lbf[spos+7*qdim], &lbf[spos+8*qdim],
                        &lbf[spos+1*qdim], &lbf[spos+2*qdim]);
        break;
      case CCDLF:
        fD2Q9VCCInamuro(p0, -uwall[0], -uwall[1], &force[0], &lbf[spos], &lbf[spos+5*qdim], &lbf[spos+6*qdim],
                        &lbf[spos+7*qdim], &lbf[spos+8*qdim], &lbf[spos+1*qdim], &lbf[spos+2*qdim],
                        &lbf[spos+3*qdim], &lbf[spos+4*qdim]);
        break;
      case CCDRF:
        fD2Q9VCCInamuro(p0, -uwall[1], uwall[0], &force[0], &lbf[spos], &lbf[spos+7*qdim], &lbf[spos+8*qdim],
                        &lbf[spos+1*qdim], &lbf[spos+2*qdim], &lbf[spos+3*qdim], &lbf[spos+4*qdim],
                        &lbf[spos+5*qdim], &lbf[spos+6*qdim]);
        break;
    }
  }
  return 0;
}


int fD2Q9CCEInamuro(double *p, double v0, double v1, double *f0, double *f1, double *f2,
                    double *f3, double *f4, double *f5, double *f6, double *f7, double *f8)
{

  // produce fixed concentration boundary for concave edge (CCETF)

  double c1=1.0/9.0,c2=1.0/36.0;
  for(int i=0; i<lbsy.nc; i++) {
    double rho=6.0*(p[i]-f0[i]-f2[i]-f3[i]-f4[i]-f5[i]-f6[i])/(1.0+3.0*v1);
    f1[i]=c2*rho*(1.0-3.0*v0+3.0*v1);
    f7[i]=c2*rho*(1.0+3.0*v0+3.0*v1);
    f8[i]=c1*rho*(1.0+3.0*v1);
  }
  return 0;
}

int fD2Q9CCCInamuro(double *p, double v0, double v1, double *f0, double *f1, double *f2,
                    double *f3, double *f4, double *f5, double *f6, double *f7, double *f8)
{

  // produce fixed concentration boundary for concave corner (CCCTRF)

  double c1=1.0/9.0,c2=1.0/36.0;
  for(int i=0; i<lbsy.nc; i++) {
    double rho=36.0*(p[i]-f0[i]-f2[i]-f3[i]-f4[i])/(11.0+15.0*(v0+v1+v0*v0+v1*v1)-9.0*v0*v1);
    f1[i]=c2*rho*(1.0-3.0*v0+3.0*v1);
    f5[i]=c2*rho*(1.0+3.0*v0-3.0*v1);
    f6[i]=c1*rho*(1.0+3.0*v0);
    f7[i]=c2*rho*(1.0+3.0*v0+3.0*v1);
    f8[i]=c1*rho*(1.0+3.0*v1);
  }
  return 0;
}


int fD2Q9PCInamuro(long tpos, int prop, double *p0, double *uwall)
{
  long spos = tpos * lbsitelength + lbsy.nf;
  int qdim=lbsy.nf+lbsy.nc+lbsy.nt;
    
  switch (prop) {
    case CETF:
      fD2Q9CCEInamuro(p0, uwall[0], uwall[1], &lbf[spos], &lbf[spos+1*qdim],
                      &lbf[spos+2*qdim], &lbf[spos+3*qdim], &lbf[spos+4*qdim], &lbf[spos+5*qdim],
                      &lbf[spos+6*qdim], &lbf[spos+7*qdim], &lbf[spos+8*qdim]);
      break;
    case CELF:
      fD2Q9CCEInamuro(p0, uwall[1], -uwall[0], &lbf[spos], &lbf[spos+3*qdim],
                      &lbf[spos+4*qdim], &lbf[spos+5*qdim], &lbf[spos+6*qdim], &lbf[spos+7*qdim],
                      &lbf[spos+8*qdim], &lbf[spos+1*qdim], &lbf[spos+2*qdim]);
      break;
    case CEDF:
      fD2Q9CCEInamuro(p0, -uwall[0], -uwall[1], &lbf[spos], &lbf[spos+5*qdim],
                      &lbf[spos+6*qdim], &lbf[spos+7*qdim], &lbf[spos+8*qdim], &lbf[spos+1*qdim],
                      &lbf[spos+2*qdim], &lbf[spos+3*qdim], &lbf[spos+4*qdim]);
      break;
    case CERF:
      fD2Q9CCEInamuro(p0, -uwall[1], uwall[0], &lbf[spos], &lbf[spos+7*qdim],
                      &lbf[spos+8*qdim], &lbf[spos+1*qdim], &lbf[spos+2*qdim], &lbf[spos+3*qdim],
                      &lbf[spos+4*qdim], &lbf[spos+5*qdim], &lbf[spos+6*qdim]);
      break;
    case CCTRF:
      fD2Q9CCCInamuro(p0, uwall[0], uwall[1], &lbf[spos], &lbf[spos+1*qdim],
                      &lbf[spos+2*qdim], &lbf[spos+3*qdim], &lbf[spos+4*qdim], &lbf[spos+5*qdim],
                      &lbf[spos+6*qdim], &lbf[spos+7*qdim], &lbf[spos+8*qdim]);
      break;
    case CCTLF:
      fD2Q9CCCInamuro(p0, uwall[1], -uwall[0], &lbf[spos], &lbf[spos+3*qdim],
                      &lbf[spos+4*qdim], &lbf[spos+5*qdim], &lbf[spos+6*qdim], &lbf[spos+7*qdim],
                      &lbf[spos+8*qdim], &lbf[spos+1*qdim], &lbf[spos+2*qdim]);
      break;
    case CCDLF:
      fD2Q9CCCInamuro(p0, -uwall[0], -uwall[1], &lbf[spos], &lbf[spos+5*qdim],
                      &lbf[spos+6*qdim], &lbf[spos+7*qdim], &lbf[spos+8*qdim], &lbf[spos+1*qdim],
                      &lbf[spos+2*qdim], &lbf[spos+3*qdim], &lbf[spos+4*qdim]);
      break;
    case CCDRF:
      fD2Q9CCCInamuro(p0, -uwall[1], uwall[0], &lbf[spos], &lbf[spos+7*qdim],
                      &lbf[spos+8*qdim], &lbf[spos+1*qdim], &lbf[spos+2*qdim], &lbf[spos+3*qdim],
                      &lbf[spos+4*qdim], &lbf[spos+5*qdim], &lbf[spos+6*qdim]);
      break;
  }
  return 0;  
}


int fD2Q9TCEInamuro(double p, double v0, double v1, double *f0, double *f1, double *f2,
                    double *f3, double *f4, double *f5, double *f6, double *f7, double *f8)
{

  // produce fixed temperature for concave edge (TCETF)

  double c1=1.0/9.0,c2=1.0/36.0;
  double rho=6.0*(p-f0[0]-f2[0]-f3[0]-f4[0]-f5[0]-f6[0])/(1.0+3.0*v1);
  f1[0]=c2*rho*(1.0-3.0*v0+3.0*v1);
  f7[0]=c2*rho*(1.0+3.0*v0+3.0*v1);
  f8[0]=c1*rho*(1.0+3.0*v1);
  return 0;
}

int fD2Q9TCCInamuro(double p, double v0, double v1, double *f0, double *f1, double *f2,
                    double *f3, double *f4, double *f5, double *f6, double *f7, double *f8)
{

  // produce fixed temperature for concave corner (TCCTRF)

  double c1=1.0/9.0,c2=1.0/36.0;
  double rho=36.0*(p-f0[0]-f2[0]-f3[0]-f4[0])/(11.0+15.0*(v0+v1+v0*v0+v1*v1)-9.0*v0*v1);
  f1[0]=c2*rho*(1.0-3.0*v0+3.0*v1);
  f5[0]=c2*rho*(1.0+3.0*v0-3.0*v1);
  f6[0]=c1*rho*(1.0+3.0*v0);
  f7[0]=c2*rho*(1.0+3.0*v0+3.0*v1);
  f8[0]=c1*rho*(1.0+3.0*v1);
  return 0;
}


int fD2Q9PTInamuro(long tpos, int prop, double p0, double *uwall)
{
  long spos = tpos * lbsitelength + lbsy.nf + lbsy.nc;
  int qdim=lbsy.nf+lbsy.nc+lbsy.nt;

  switch (prop) {
    case CETF:
      fD2Q9TCEInamuro(p0, uwall[0], uwall[1], &lbf[spos], &lbf[spos+1*qdim],
                      &lbf[spos+2*qdim], &lbf[spos+3*qdim], &lbf[spos+4*qdim], &lbf[spos+5*qdim],
                      &lbf[spos+6*qdim], &lbf[spos+7*qdim], &lbf[spos+8*qdim]);
      break;
    case CELF:
      fD2Q9TCEInamuro(p0, uwall[1], -uwall[0], &lbf[spos], &lbf[spos+3*qdim],
                      &lbf[spos+4*qdim], &lbf[spos+5*qdim], &lbf[spos+6*qdim], &lbf[spos+7*qdim],
                      &lbf[spos+8*qdim], &lbf[spos+1*qdim], &lbf[spos+2*qdim]);
      break;
    case CEDF:
      fD2Q9TCEInamuro(p0, -uwall[0], -uwall[1], &lbf[spos], &lbf[spos+5*qdim],
                      &lbf[spos+6*qdim], &lbf[spos+7*qdim], &lbf[spos+8*qdim], &lbf[spos+1*qdim],
                      &lbf[spos+2*qdim], &lbf[spos+3*qdim], &lbf[spos+4*qdim]);
      break;
    case CERF:
      fD2Q9TCEInamuro(p0, -uwall[1], uwall[0], &lbf[spos], &lbf[spos+7*qdim],
                      &lbf[spos+8*qdim], &lbf[spos+1*qdim], &lbf[spos+2*qdim], &lbf[spos+3*qdim],
                      &lbf[spos+4*qdim], &lbf[spos+5*qdim], &lbf[spos+6*qdim]);
      break;
    case CCTRF:
      fD2Q9TCCInamuro(p0, uwall[0], uwall[1], &lbf[spos], &lbf[spos+1*qdim],
                      &lbf[spos+2*qdim], &lbf[spos+3*qdim], &lbf[spos+4*qdim], &lbf[spos+5*qdim],
                      &lbf[spos+6*qdim], &lbf[spos+7*qdim], &lbf[spos+8*qdim]);
      break;
    case CCTLF:
      fD2Q9TCCInamuro(p0, uwall[1], -uwall[0], &lbf[spos], &lbf[spos+3*qdim],
                      &lbf[spos+4*qdim], &lbf[spos+5*qdim], &lbf[spos+6*qdim], &lbf[spos+7*qdim],
                      &lbf[spos+8*qdim], &lbf[spos+1*qdim], &lbf[spos+2*qdim]);
      break;
    case CCDLF:
      fD2Q9TCCInamuro(p0, -uwall[0], -uwall[1], &lbf[spos], &lbf[spos+5*qdim],
                      &lbf[spos+6*qdim], &lbf[spos+7*qdim], &lbf[spos+8*qdim], &lbf[spos+1*qdim],
                      &lbf[spos+2*qdim], &lbf[spos+3*qdim], &lbf[spos+4*qdim]);
      break;
    case CCDRF:
      fD2Q9TCCInamuro(p0, -uwall[1], uwall[0], &lbf[spos], &lbf[spos+7*qdim],
                      &lbf[spos+8*qdim], &lbf[spos+1*qdim], &lbf[spos+2*qdim], &lbf[spos+3*qdim],
                      &lbf[spos+4*qdim], &lbf[spos+5*qdim], &lbf[spos+6*qdim]);
      break;
  }
  return 0;  
}


// D3Q15

int fD3Q15VPSInamuro(double v0, double v1, double v2, double *force,
                     double *f0, double *f1, double *f2, double *f3, double *f4,
                     double *f5, double *f6, double *f7, double *f8, double *f9,
                     double *f10, double *f11, double *f12, double *f13, double *f14)
{

  // produce fixed velocity at bottom boundary (VPST) for compressible/incompressible fluids

  double rho, rho0, rrho0, rhop, v0t, v2t;
  double c1=1.0/9.0,c2=1.0/72.0;
    
  if(!incompress) {
    for(int i=0; i<lbsy.nf; i++) {
      rho = (f0[i]+f1[i]+f3[i]+f8[i]+f10[i]+2.0*(f2[i]+f4[i]+f5[i]+f13[i]+f14[i])-0.5*force[3*i+1])/(1.0-v1);
      rhop = 6.0*(rho*v1+f2[i]+f4[i]+f5[i]+f13[i]+f14[i]-0.5*force[3*i+1])/(1.0+3.0*v1*(1.0+v1));
      v0t = 6.0*(rho*v0+f1[i]+f4[i]+f5[i]-f8[i]-f13[i]-f14[i]-0.5*force[3*i  ])/(rhop*(1.0+3.0*v1)); // v0t = v0 + v0s
      v2t = 6.0*(rho*v2+f3[i]+f4[i]-f5[i]-f10[i]-f13[i]+f14[i]-0.5*force[3*i+2])/(rhop*(1.0+3.0*v1)); // v2t = v2 + v2s
      f6[i]=c2*rhop*(1.0+3.0*(v1*(1.0+v1)-v0t*(1.0-v0t)-v2t*(1.0-v2t))-9.0*v1*(v0t+v2t)+9.0*v0t*v2t);
      f7[i]=c2*rhop*(1.0+3.0*(v1*(1.0+v1)-v0t*(1.0-v0t)+v2t*(1.0+v2t))-9.0*v1*(v0t-v2t)-9.0*v0t*v2t);
      f9[i]=c1*rhop*(1.0+3.0*v1*(1.0+v1)-1.5*(v0t*v0t+v2t*v2t));
      f11[i]=c2*rhop*(1.0+3.0*(v1*(1.0+v1)+v0t*(1.0+v0t)+v2t*(1.0+v2t))+9.0*v1*(v0t+v2t)+9.0*v0t*v2t);
      f12[i]=c2*rhop*(1.0+3.0*(v1*(1.0+v1)+v0t*(1.0+v0t)-v2t*(1.0-v2t))+9.0*v1*(v0t-v2t)-9.0*v0t*v2t);
    }
  }
  else {
    for(int i=0; i<lbsy.nf; i++) {
      rho0 = lbincp[i];
      rrho0 = fReciprocal(rho0);
      rhop = 6.0*(f2[i]+f4[i]+f5[i]+f13[i]+f14[i])+3.0*rho0*v1*(1.0-v1)-3.0*force[3*i+1];
      v0t = 6.0*(v0+(f1[i]+f4[i]+f5[i]-f8[i]-f13[i]-f14[i]-0.5*force[3*i  ])*rrho0)/(1.0+3.0*v1); // v0t = v0 + v0s
      v2t = 6.0*(v2+(f3[i]+f4[i]-f5[i]-f10[i]-f13[i]+f14[i]-0.5*force[3*i+2])*rrho0)/(1.0+3.0*v1); // v2t = v2 + v2s
      f6[i]=c2*(rhop+rho0*(3.0*(v1*(1.0+v1)-v0t*(1.0-v0t)-v2t*(1.0-v2t))-9.0*v1*(v0t+v2t)+9.0*v0t*v2t));
      f7[i]=c2*(rhop+rho0*(3.0*(v1*(1.0+v1)-v0t*(1.0-v0t)+v2t*(1.0+v2t))-9.0*v1*(v0t-v2t)-9.0*v0t*v2t));
      f9[i]=c1*(rhop+rho0*(3.0*v1*(1.0+v1)-1.5*(v0t*v0t+v2t*v2t)));
      f11[i]=c2*(rhop+rho0*(3.0*(v1*(1.0+v1)+v0t*(1.0+v0t)+v2t*(1.0+v2t))+9.0*v1*(v0t+v2t)+9.0*v0t*v2t));
      f12[i]=c2*(rhop+rho0*(3.0*(v1*(1.0+v1)+v0t*(1.0+v0t)-v2t*(1.0-v2t))+9.0*v1*(v0t-v2t)-9.0*v0t*v2t));
    }
  }
  return 0;
}

int fD3Q15VCEInamuro(double *p, double v0, double v1, double v2, double *force,
                     double *f0, double *f1, double *f2, double *f3, double *f4,
                     double *f5, double *f6, double *f7, double *f8, double *f9,
                     double *f10, double *f11, double *f12, double *f13, double *f14)
{

  // produce fixed velocity at bottom-left edge boundary (VCETR) for compressible/incompressible fluids

  double rho0, rrho0, rhop, v2t;
  double c1=1.0/9.0,c2=1.0/72.0;
    
  if(!incompress) {
    for(int i=0; i<lbsy.nf; i++) {
      rhop = 12.0*(p[i]*(1.0-0.5*v0-0.5*v1)-f0[i]-f3[i]-f10[i]-1.5*(f1[i]+f2[i])-2.0*(f4[i]+f5[i])+0.25*force[3*i]+0.25*force[3*i+1])/(2.0*(1.0+v0+v1)+3.0*(v0*v0+v1*v1)-6.0*v0*v1);
      v2t = 4.0*(p[i]*v2+f3[i]+f4[i]-f5[i]-f10[i]-0.5*force[3*i+2])/(rhop*(1.0+v0+v1)); // v2t = v2 + v2s
      f6[i]=c2*rhop*(1.0+3.0*(v1*(1.0+v1)-v0*(1.0-v0)-v2t*(1.0-v2t))-9.0*v1*(v0+v2t)+9.0*v0*v2t);
      f7[i]=c2*rhop*(1.0+3.0*(v1*(1.0+v1)-v0*(1.0-v0)+v2t*(1.0+v2t))-9.0*v1*(v0-v2t)-9.0*v0*v2t);
      f8[i]=c1*rhop*(1.0+3.0*v0*(1.0+v0)-1.5*(v1*v1+v2t*v2t));
      f9[i]=c1*rhop*(1.0+3.0*v1*(1.0+v1)-1.5*(v0*v0+v2t*v2t));
      f11[i]=c2*rhop*(1.0+3.0*(v1*(1.0+v1)+v0*(1.0+v0)+v2t*(1.0+v2t))+9.0*v1*(v0+v2t)+9.0*v0*v2t);
      f12[i]=c2*rhop*(1.0+3.0*(v1*(1.0+v1)+v0*(1.0+v0)-v2t*(1.0-v2t))+9.0*v1*(v0-v2t)-9.0*v0*v2t);
      f13[i]=c2*rhop*(1.0-3.0*(v1*(1.0-v1)-v0*(1.0+v0)-v2t*(1.0+v2t))-9.0*v1*(v0+v2t)+9.0*v0*v2t);
      f14[i]=c2*rhop*(1.0-3.0*(v1*(1.0-v1)-v0*(1.0+v0)+v2t*(1.0-v2t))-9.0*v1*(v0-v2t)-9.0*v0*v2t);
    }
  }
  else {
    for(int i=0; i<lbsy.nf; i++) {
      rho0 = lbincp[i];
      rrho0 = fReciprocal(rho0);
      rhop = 6.0*(p[i]-f0[i]-f3[i]-f10[i])-9.0*(f1[i]+f2[i])-12.0*(f4[i]+f5[i])-4.0*rho0*(v0+v1)-1.5*rho0*(v0*v0+v1*v1-2.0*v0*v1)+1.5*(force[3*i]+force[3*i+1]);
      v2t = 4.0*(v2+(f3[i]+f4[i]-f5[i]-f10[i]-0.5*force[3*i+2])*rrho0)/(1.0+v0+v1); // v2t = v2 + v2s
      f6[i]=c2*(rhop+rho0*(3.0*(v1*(1.0+v1)-v0*(1.0-v0)-v2t*(1.0-v2t))-9.0*v1*(v0+v2t)+9.0*v0*v2t));
      f7[i]=c2*(rhop+rho0*(3.0*(v1*(1.0+v1)-v0*(1.0-v0)+v2t*(1.0+v2t))-9.0*v1*(v0-v2t)-9.0*v0*v2t));
      f8[i]=c1*(rhop+rho0*(3.0*v0*(1.0+v0)-1.5*(v1*v1+v2t*v2t)));
      f9[i]=c1*(rhop+rho0*(3.0*v1*(1.0+v1)-1.5*(v0*v0+v2t*v2t)));
      f11[i]=c2*(rhop+rho0*( 3.0*(v1*(1.0+v1)+v0*(1.0+v0)+v2t*(1.0+v2t))+9.0*v1*(v0+v2t)+9.0*v0*v2t));
      f12[i]=c2*(rhop+rho0*( 3.0*(v1*(1.0+v1)+v0*(1.0+v0)-v2t*(1.0-v2t))+9.0*v1*(v0-v2t)-9.0*v0*v2t));
      f13[i]=c2*(rhop+rho0*(-3.0*(v1*(1.0-v1)-v0*(1.0+v0)-v2t*(1.0+v2t))-9.0*v1*(v0+v2t)+9.0*v0*v2t));
      f14[i]=c2*(rhop+rho0*(-3.0*(v1*(1.0-v1)-v0*(1.0+v0)+v2t*(1.0-v2t))-9.0*v1*(v0-v2t)-9.0*v0*v2t));
    }
  }
  return 0;
}

int fD3Q15VCCInamuro(double *p, double v0, double v1, double v2, double *force,
                     double *f0, double *f1, double *f2, double *f3, double *f4,
                     double *f5, double *f6, double *f7, double *f8, double *f9,
                     double *f10, double *f11, double *f12, double *f13, double *f14)
{

  // produce fixed velocity at bottom-left-back corner boundary (VCCTRF) for compressible/incompressible fluids

  double rho0, rhop;
  double c0=1.0/3.0,c1=1.0/9.0,c2=1.0/72.0,c3=2.0/3.0,c4=1.0/6.0;
    

  if(!incompress) {
    for(int i=0; i<lbsy.nf; i++) {
      rhop = 9.0*(p[i]*(1.0+c0*(v0+v1+v2))-f0[i]-c3*(f1[i]+f2[i]+f3[i])-c4*(force[3*i]+force[3*i+1]+force[3*i+2]))/(5.0*(1.0+v0+v1+v2)+3.0*(v0*v0+v1*v1+v2*v2));
      f5[i]=c2*rhop*(1.0-3.0*(v1*(1.0-v1)+v0*(1.0-v0)-v2*(1.0+v2))+9.0*v1*(v0-v2)-9.0*v0*v2);
      f6[i]=c2*rhop*(1.0+3.0*(v1*(1.0+v1)-v0*(1.0-v0)-v2*(1.0-v2))-9.0*v1*(v0+v2)+9.0*v0*v2);
      f7[i]=c2*rhop*(1.0+3.0*(v1*(1.0+v1)-v0*(1.0-v0)+v2*(1.0+v2))-9.0*v1*(v0-v2)-9.0*v0*v2);
      f8[i]=c1*rhop*(1.0+3.0*v0*(1.0+v0)-1.5*(v1*v1+v2*v2));
      f9[i]=c1*rhop*(1.0+3.0*v1*(1.0+v1)-1.5*(v0*v0+v2*v2));
      f10[i]=c1*rhop*(1.0+3.0*v2*(1.0+v2)-1.5*(v0*v0+v1*v1));
      f11[i]=c2*rhop*(1.0+3.0*(v1*(1.0+v1)+v0*(1.0+v0)+v2*(1.0+v2))+9.0*v1*(v0+v2)+9.0*v0*v2);
      f12[i]=c2*rhop*(1.0+3.0*(v1*(1.0+v1)+v0*(1.0+v0)-v2*(1.0-v2))+9.0*v1*(v0-v2)-9.0*v0*v2);
      f13[i]=c2*rhop*(1.0-3.0*(v1*(1.0-v1)-v0*(1.0+v0)-v2*(1.0+v2))-9.0*v1*(v0+v2)+9.0*v0*v2);
      f14[i]=c2*rhop*(1.0-3.0*(v1*(1.0-v1)-v0*(1.0+v0)+v2*(1.0-v2))-9.0*v1*(v0-v2)-9.0*v0*v2);
    }
  }
  else {
    for(int i=0; i<lbsy.nf; i++) {
      rho0 = lbincp[i];
      rhop = 1.8*(p[i]-f0[i])-1.2*(f1[i]+f2[i]+f3[i])-0.4*rho0*(v0+v1+v2)-0.6*rho0*(v0*v0+v1*v1+v2*v2)-0.3*(force[3*i]+force[3*i+1]+force[3*i+2]);
      f5[i]=c2*(rhop+rho0*(-3.0*(v1*(1.0-v1)+v0*(1.0-v0)-v2*(1.0+v2))+9.0*v1*(v0-v2)-9.0*v0*v2));
      f6[i]=c2*(rhop+rho0*( 3.0*(v1*(1.0+v1)-v0*(1.0-v0)-v2*(1.0-v2))-9.0*v1*(v0+v2)+9.0*v0*v2));
      f7[i]=c2*(rhop+rho0*( 3.0*(v1*(1.0+v1)-v0*(1.0-v0)+v2*(1.0+v2))-9.0*v1*(v0-v2)-9.0*v0*v2));
      f8[i]=c1*(rhop+rho0*(3.0*v0*(1.0+v0)-1.5*(v1*v1+v2*v2)));
      f9[i]=c1*(rhop+rho0*(3.0*v1*(1.0+v1)-1.5*(v0*v0+v2*v2)));
      f10[i]=c1*(rhop+rho0*(3.0*v2*(1.0+v2)-1.5*(v0*v0+v1*v1)));
      f11[i]=c2*(rhop+rho0*( 3.0*(v1*(1.0+v1)+v0*(1.0+v0)+v2*(1.0+v2))+9.0*v1*(v0+v2)+9.0*v0*v2));
      f12[i]=c2*(rhop+rho0*( 3.0*(v1*(1.0+v1)+v0*(1.0+v0)-v2*(1.0-v2))+9.0*v1*(v0-v2)-9.0*v0*v2));
      f13[i]=c2*(rhop+rho0*(-3.0*(v1*(1.0-v1)-v0*(1.0+v0)-v2*(1.0+v2))-9.0*v1*(v0+v2)+9.0*v0*v2));
      f14[i]=c2*(rhop+rho0*(-3.0*(v1*(1.0-v1)-v0*(1.0+v0)+v2*(1.0-v2))-9.0*v1*(v0-v2)-9.0*v0*v2));
    }
  }
  return 0;
}

int fD3Q15VPSSwiftInamuro(double v0, double v1, double v2, double *force,
                          double *f0, double *f1, double *f2, double *f3, double *f4,
                          double *f5, double *f6, double *f7, double *f8, double *f9,
                          double *f10, double *f11, double *f12, double *f13, double *f14,
	                      double drdx, double drdy, double drdz, double dpdx, double dpdy, double dpdz,
                          double nabr, double nabp, double *omega, double T)
{

  // produce fixed velocity at planar surface boundary for compressible fluids with Swift free-energy interactions:
  // expressed for bottom wall (VPST)
  
  double rho, phi, omegat, pb, mu, lambda, d2rdx2, d2rdy2, d2rdz2, d2rdxdy, d2rdxdz, d2rdydz, nabrp, rhop, phip, v0t, v2t;
  double c0=1.0/3.0,c1=1.0/6.0,c3=1.0/24.0,c4=1.0/48.0;

  rho = (f0[0]+f1[0]+f3[0]+f8[0]+f10[0]+2.0*(f2[0]+f4[0]+f5[0]+f13[0]+f14[0])-0.5*force[1])/(1.0-v1);
  if(lbsy.nf>1) {
    phi = (f0[1]+f1[1]+f3[1]+f8[1]+f10[1]+2.0*(f2[1]+f4[1]+f5[1]+f13[1]+f14[1]))/(1.0-v1);
    omegat = 0.5*(1.0+phi)*omega[0]+0.5*(1.0-phi)*omega[1];
    mu = lbfemob*fGetPotentialSwift(phi, nabp);
    d2rdx2 = (lbfeeos>0)?(drdx*drdx):0.0 + dpdx*dpdx;
    d2rdy2 = (lbfeeos>0)?(drdy*drdy):0.0 + dpdy*dpdy;
    d2rdz2 = (lbfeeos>0)?(drdz*drdz):0.0 + dpdz*dpdz;
    d2rdxdy = (lbfeeos>0)?(drdx*drdy):0.0 + dpdx*dpdy;
    d2rdxdz = (lbfeeos>0)?(drdx*drdz):0.0 + dpdx*dpdz;
    d2rdydz = (lbfeeos>0)?(drdy*drdz):0.0 + dpdy*dpdz;
    nabrp = (lbfeeos>0)?(rho*nabr):0.0 + phi*nabp;
    if(fCppAbs(v1)>0.0)
      phip = (2.0*(phi-f0[1]-f1[1]-f2[1]-f3[1]-f4[1]-f5[1]-f8[1]-f10[1]-f13[1]-f14[1])-mu)*fReciprocal(v1*(1.0+v1));
    else
      phip = phi;
    f6[1]=c3*phip*(v0*(v0-1.0)+v1*(v1+1.0)+v2*(v2-1.0))-0.125*phip*(v0*v1-v0*v2+v1*v2)+c3*mu;
    f7[1]=c3*phip*(v0*(v0-1.0)+v1*(v1+1.0)+v2*(v2+1.0))-0.125*phip*(v0*v1+v0*v2-v1*v2)+c3*mu;
    f9[1]=c0*phip*v1*(1.0+v1)-c1*phip*(v0*v0+v2*v2)+c0*mu;
    f11[1]=c3*phip*(v0*(v0+1.0)+v1*(v1+1.0)+v2*(v2+1.0))+0.125*phip*(v0*v1+v0*v2+v1*v2)+c3*mu;
    f12[1]=c3*phip*(v0*(v0+1.0)+v1*(v1+1.0)+v2*(v2-1.0))+0.125*phip*(v0*v1-v0*v2-v1*v2)+c3*mu;
  }
  else {
    phi = 0.0;
    omegat = omega[0];
    d2rdx2 = drdx*drdx;
    d2rdy2 = drdy*drdy;
    d2rdz2 = drdz*drdz;
    d2rdxdy = drdx*drdy;
    d2rdxdz = drdx*drdz;
    d2rdydz = drdy*drdz;
    nabrp = rho*nabr;
  }
  pb = fGetBulkPressureSwift(rho, phi, T);
  lambda = fGetLambdaSwift(rho, omegat, T);
  rhop = 2.0*(rho*v1+f2[0]+f4[0]+f5[0]+f13[0]+f14[0])-force[1]-pb+lbkappa*(nabrp+0.5*(d2rdx2-d2rdy2+d2rdz2))-lambda*(v0*drdx+3.0*v1*drdy+v2*drdz)*fReciprocal(v1*(1.0+v1));
  if(rhop<lbevaplim)
    rhop = rho;
  v0t = (6.0*(rho*v0+f1[0]+f4[0]+f5[0]-f8[0]-f13[0]-f14[0])-3.0*force[0]-3.0*lambda*(v1*drdx+v0*drdy)-3.0*lbkappa*d2rdxdy)*fReciprocal(rhop*(1.0+3.0*v1));
  v2t = (6.0*(rho*v2+f3[0]+f4[0]-f5[0]-f10[0]-f13[0]+f14[0])-3.0*force[2]-3.0*lambda*(v2*drdy+v1*drdz)-3.0*lbkappa*d2rdydz)*fReciprocal(rhop*(1.0+3.0*v1));
  f6[0]=c3*rhop*(v0t*(v0t-1.0)+v1*(v1+1.0)+v2t*(v2t-1.0))-0.125*rhop*(v0t*v1-v0t*v2t+v1*v2t)
       +lambda*(c3*(v0*drdx+v1*drdy+v2*drdz)-0.125*(v0*(drdy-drdz)-v1*(drdx+drdz)-v2*(drdx-drdy)))+c3*(pb-lbkappa*nabrp)
       -lbkappa*(c4*(d2rdx2+d2rdy2+d2rdz2)-0.125*(d2rdxdy-d2rdxdz+d2rdydz));
  f7[0]=c3*rhop*(v0t*(v0t-1.0)+v1*(v1+1.0)+v2t*(v2t+1.0))-0.125*rhop*(v0t*v1+v0t*v2t-v1*v2t)
       +lambda*(c3*(v0*drdx+v1*drdy+v2*drdz)-0.125*(v0*(drdy+drdz)+v1*(drdx-drdz)+v2*(drdx-drdy)))+c3*(pb-lbkappa*nabrp)
       -lbkappa*(c4*(d2rdx2+d2rdy2+d2rdz2)-0.125*(d2rdxdy+d2rdxdz-d2rdydz));
  f9[0]=rhop*(c0*v1*(v1+1.0)-c1*(v0t*v0t+v2t*v2t))+c0*lambda*(v0*drdx+4.0*v1*drdy+v2*drdz)+c0*(pb-lbkappa*nabrp)
       -lbkappa*(c1*d2rdx2-c0*d2rdy2+c1*d2rdz2);
  f11[0]=c3*rhop*(v0t*(v0t+1.0)+v1*(v1+1.0)+v2t*(v2t+1.0))+0.125*rhop*(v0t*v1+v0t*v2t+v1*v2t)
        +lambda*(c3*(v0*drdx+v1*drdy+v2*drdz)+0.125*(v0*(drdy+drdz)+v1*(drdx+drdz)+v2*(drdx+drdy)))+c3*(pb-lbkappa*nabrp)
        -lbkappa*(c4*(d2rdx2+d2rdy2+d2rdz2)+0.125*(d2rdxdy+d2rdxdz+d2rdydz));
  f12[0]=c3*rhop*(v0t*(v0t+1.0)+v1*(v1+1.0)+v2t*(v2t-1.0))+0.125*rhop*(v0t*v1-v0t*v2t-v1*v2t)
        +lambda*(c3*(v0*drdx+v1*drdy+v2*drdz)+0.125*(v0*(drdy-drdz)+v1*(drdx-drdz)-v2*(drdx+drdy)))+c3*(pb-lbkappa*nabrp)
        -lbkappa*(c4*(d2rdx2+d2rdy2+d2rdz2)+0.125*(d2rdxdy-d2rdxdz-d2rdydz));
  return 0;
}

int fD3Q15VCESwiftInamuro(double *p, double v0, double v1, double v2, double *force,
                          double *f0, double *f1, double *f2, double *f3, double *f4,
                          double *f5, double *f6, double *f7, double *f8, double *f9,
                          double *f10, double *f11, double *f12, double *f13, double *f14,
	                      double drdx, double drdy, double drdz, double dpdx, double dpdy, double dpdz,
                          double nabr, double nabp, double *omega, double T)
{

  // produce fixed velocity at concave edge boundary for compressible fluids with Swift free-energy interactions:
  // expressed for bottom-left edge (VCETR)

  double rho, phi, omegat, pb, mu, lambda, d2rdx2, d2rdy2, d2rdz2, d2rdxdy, d2rdxdz, d2rdydz, nabrp, rhop, phip, v2t;
  double c0=1.0/3.0,c1=1.0/6.0,c3=1.0/24.0,c4=1.0/48.0;

  rho = p[0];
  if(lbsy.nf>1) {
    phi = p[1];
    omegat = 0.5*(1.0+phi)*omega[0]+0.5*(1.0-phi)*omega[1];
    mu = lbfemob*fGetPotentialSwift(phi, nabp);
    d2rdx2 = (lbfeeos>0)?(drdx*drdx):0.0 + dpdx*dpdx;
    d2rdy2 = (lbfeeos>0)?(drdy*drdy):0.0 + dpdy*dpdy;
    d2rdz2 = (lbfeeos>0)?(drdz*drdz):0.0 + dpdz*dpdz;
    d2rdxdy = (lbfeeos>0)?(drdx*drdy):0.0 + dpdx*dpdy;
    d2rdxdz = (lbfeeos>0)?(drdx*drdz):0.0 + dpdx*dpdz;
    d2rdydz = (lbfeeos>0)?(drdy*drdz):0.0 + dpdy*dpdz;
    nabrp = (lbfeeos>0)?(rho*nabr):0.0 + phi*nabp;
    if(fCppAbs(v0)>0.0 || fCppAbs(v1)>0.0 || fCppAbs(v2)>0.0)
      phip = (12.0*(phi-f0[1]-f1[1]-f2[1]-f3[1]-f4[1]-f5[1]-f10[1])-11.0*mu)*fReciprocal(5.0*(v0+v1+v0*v0+v1*v1)-v2*v2-3.0*v0*v1);
    else
      phip = phi;
    f6[1]=c3*phip*(v0*(v0-1.0)+v1*(v1+1.0)+v2*(v2-1.0))-0.125*phip*(v0*v1-v0*v2+v1*v2)+c3*mu;
    f7[1]=c3*phip*(v0*(v0-1.0)+v1*(v1+1.0)+v2*(v2+1.0))-0.125*phip*(v0*v1+v0*v2-v1*v2)+c3*mu;
    f8[1]=c0*phip*v0*(1.0+v0)-c1*phip*(v1*v1+v2*v2)+c0*mu;
    f9[1]=c0*phip*v1*(1.0+v1)-c1*phip*(v0*v0+v2*v2)+c0*mu;
    f11[1]=c3*phip*(v0*(v0+1.0)+v1*(v1+1.0)+v2*(v2+1.0))+0.125*phip*(v0*v1+v0*v2+v1*v2)+c3*mu;
    f12[1]=c3*phip*(v0*(v0+1.0)+v1*(v1+1.0)+v2*(v2-1.0))+0.125*phip*(v0*v1-v0*v2-v1*v2)+c3*mu;
    f13[1]=c3*phip*(v0*(v0+1.0)+v1*(v1-1.0)+v2*(v2+1.0))-0.125*phip*(v0*v1-v0*v2+v1*v2)+c3*mu;
    f14[1]=c3*phip*(v0*(v0+1.0)+v1*(v1-1.0)+v2*(v2-1.0))-0.125*phip*(v0*v1+v0*v2-v1*v2)+c3*mu;
  }
  else {
    phi = 0.0;
    omegat = omega[0];
    d2rdx2 = drdx*drdx;
    d2rdy2 = drdy*drdy;
    d2rdz2 = drdz*drdz;
    d2rdxdy = drdx*drdy;
    d2rdxdz = drdx*drdz;
    d2rdydz = drdy*drdz;
    nabrp = rho*nabr;
  }
  pb = fGetBulkPressureSwift(rho, phi, T);
  lambda = fGetLambdaSwift(rho, omegat, T);
  rhop = 12.0*(rho*(1.0-0.5*(v0+v1))-f0[0]-f3[0]-f10[0]+0.25*(force[0]+force[1])-0.5*pb+lbkappa*(0.5*(nabrp+d2rdxdy)+0.25*d2rdz2)-lambda*(v0*drdx+v1*drdy+0.5*(v2*drdz-v0*drdy-v1*drdx)))*fReciprocal(2.0*(v0+v1)+3.0*(v0*v0+v1*v1-2.0*v0*v1));
  if(rhop<lbevaplim)
    rhop = rho;
  v2t = (4.0*(rho*v2+f3[0]+f4[0]-f5[0]-f10[0])-2.0*force[2]-lambda*(v2*(drdx+drdy)+drdz*(v0+v1))-lbkappa*(d2rdxdz+d2rdydz))*fReciprocal(rhop*(1.0+v0+v1));
  f6[0]=c3*rhop*(v0*(v0-1.0)+v1*(v1+1.0)+v2t*(v2t-1.0))-0.125*rhop*(v0*v1-v0*v2t+v1*v2t)
       +lambda*(c3*(v0*drdx+v1*drdy+v2*drdz)-0.125*(v0*(drdy-drdz)-v1*(drdx+drdz)-v2*(drdx-drdy)))+c3*(pb-lbkappa*nabrp)
       -lbkappa*(c4*(d2rdx2+d2rdy2+d2rdz2)-0.125*(d2rdxdy-d2rdxdz+d2rdydz));
  f7[0]=c3*rhop*(v0*(v0-1.0)+v1*(v1+1.0)+v2t*(v2t+1.0))-0.125*rhop*(v0*v1+v0*v2t-v1*v2t)
       +lambda*(c3*(v0*drdx+v1*drdy+v2*drdz)-0.125*(v0*(drdy+drdz)+v1*(drdx-drdz)+v2*(drdx-drdy)))+c3*(pb-lbkappa*nabrp)
       -lbkappa*(c4*(d2rdx2+d2rdy2+d2rdz2)-0.125*(d2rdxdy+d2rdxdz-d2rdydz));
  f8[0]=rhop*(c0*v0*(v0+1.0)-c1*(v1*v1+v2t*v2t))+c0*lambda*(4.0*v0*drdx+v1*drdy+v2*drdz)+c0*(pb-lbkappa*nabrp)
       +lbkappa*(c0*d2rdx2-c1*d2rdy2-c1*d2rdz2);
  f9[0]=rhop*(c0*v1*(v1+1.0)-c1*(v0*v0+v2t*v2t))+c0*lambda*(v0*drdx+4.0*v1*drdy+v2*drdz)+c0*(pb-lbkappa*nabrp)
       -lbkappa*(c1*d2rdx2-c0*d2rdy2+c1*d2rdz2);
  f11[0]=c3*rhop*(v0*(v0+1.0)+v1*(v1+1.0)+v2t*(v2t+1.0))+0.125*rhop*(v0*v1+v0*v2t+v1*v2t)
        +lambda*(c3*(v0*drdx+v1*drdy+v2*drdz)+0.125*(v0*(drdy+drdz)+v1*(drdx+drdz)+v2*(drdx+drdy)))+c3*(pb-lbkappa*nabrp)
        -lbkappa*(c4*(d2rdx2+d2rdy2+d2rdz2)+0.125*(d2rdxdy+d2rdxdz+d2rdydz));
  f12[0]=c3*rhop*(v0*(v0+1.0)+v1*(v1+1.0)+v2t*(v2t-1.0))+0.125*rhop*(v0*v1-v0*v2t-v1*v2t)
        +lambda*(c3*(v0*drdx+v1*drdy+v2*drdz)+0.125*(v0*(drdy-drdz)+v1*(drdx-drdz)-v2*(drdx+drdy)))+c3*(pb-lbkappa*nabrp)
        -lbkappa*(c4*(d2rdx2+d2rdy2+d2rdz2)+0.125*(d2rdxdy-d2rdxdz-d2rdydz));
  f13[0]=c3*rhop*(v0*(v0+1.0)+v1*(v1-1.0)+v2t*(v2t+1.0))-0.125*rhop*(v0*v1-v0*v2t+v1*v2t)
        +lambda*(c3*(v0*drdx+v1*drdy+v2*drdz)-0.125*(v0*(drdy-drdz)+v1*(drdx+drdz)-v2*(drdx-drdy)))+c3*(pb-lbkappa*nabrp)
        -lbkappa*(c4*(d2rdx2+d2rdy2+d2rdz2)-0.125*(d2rdxdy-d2rdxdz+d2rdydz));
  f14[0]=c3*rhop*(v0*(v0+1.0)+v1*(v1-1.0)+v2t*(v2t-1.0))-0.125*rhop*(v0*v1+v0*v2t-v1*v2t)
        +lambda*(c3*(v0*drdx+v1*drdy+v2*drdz)-0.125*(v0*(drdy+drdz)+v1*(drdx-drdz)+v2*(drdx-drdy)))+c3*(pb-lbkappa*nabrp)
        -lbkappa*(c4*(d2rdx2+d2rdy2+d2rdz2)-0.125*(d2rdxdy+d2rdxdz-d2rdydz));
  return 0;
}

int fD3Q15VCCSwiftInamuro(double *p, double v0, double v1, double v2, double *force,
                          double *f0, double *f1, double *f2, double *f3, double *f4,
                          double *f5, double *f6, double *f7, double *f8, double *f9,
                          double *f10, double *f11, double *f12, double *f13, double *f14,
	                      double drdx, double drdy, double drdz, double dpdx, double dpdy, double dpdz,
                          double nabr, double nabp, double *omega, double T)
{

  // produce fixed velocity at concave corner boundary for compressible fluids with Swift free-energy interactions:
  // expressed for bottom-left-back corner (VCCTRF)

  double rho, phi, omegat, pb, mu, lambda, d2rdx2, d2rdy2, d2rdz2, d2rdxdy, d2rdxdz, d2rdydz, nabrp, rhop, phip;
  double c0=1.0/3.0,c1=1.0/6.0,c3=1.0/24.0,c4=1.0/48.0;

  rho = p[0];
  if(lbsy.nf>1) {
    phi = p[1];
    omegat = 0.5*(1.0+phi)*omega[0]+0.5*(1.0-phi)*omega[1];
    mu = lbfemob*fGetPotentialSwift(phi, nabp);
    d2rdx2 = (lbfeeos>0)?(drdx*drdx):0.0 + dpdx*dpdx;
    d2rdy2 = (lbfeeos>0)?(drdy*drdy):0.0 + dpdy*dpdy;
    d2rdz2 = (lbfeeos>0)?(drdz*drdz):0.0 + dpdz*dpdz;
    d2rdxdy = (lbfeeos>0)?(drdx*drdy):0.0 + dpdx*dpdy;
    d2rdxdz = (lbfeeos>0)?(drdx*drdz):0.0 + dpdx*dpdz;
    d2rdydz = (lbfeeos>0)?(drdy*drdz):0.0 + dpdy*dpdz;
    nabrp = (lbfeeos>0)?(rho*nabr):0.0 + phi*nabp;
    if(fCppAbs(v0)>0.0 || fCppAbs(v1)>0.0 || fCppAbs(v2)>0.0)
      phip = (24.0*(phi-f0[1]-f1[1]-f2[1]-f3[1]-f4[1])-31.0*mu)*fReciprocal(9.0*(v0+v1+v2)+7.0*(v0*v0+v1*v1+v2*v2)-3.0*(v0*v1+v0*v2+v1*v2));
    else
      phip = phi;
    f5[1]=c3*phip*(v0*(v0-1.0)+v1*(v1-1.0)+v2*(v2+1.0))+0.125*phip*(v0*v1-v0*v2-v1*v2)+c3*mu;
    f6[1]=c3*phip*(v0*(v0-1.0)+v1*(v1+1.0)+v2*(v2-1.0))-0.125*phip*(v0*v1-v0*v2+v1*v2)+c3*mu;
    f7[1]=c3*phip*(v0*(v0-1.0)+v1*(v1+1.0)+v2*(v2+1.0))-0.125*phip*(v0*v1+v0*v2-v1*v2)+c3*mu;
    f8[1]=c0*phip*v0*(1.0+v0)-c1*phip*(v1*v1+v2*v2)+c0*mu;
    f9[1]=c0*phip*v1*(1.0+v1)-c1*phip*(v0*v0+v2*v2)+c0*mu;
    f10[1]=c0*phip*v2*(1.0+v2)-c1*phip*(v0*v0+v1*v1)+c0*mu;
    f11[1]=c3*phip*(v0*(v0+1.0)+v1*(v1+1.0)+v2*(v2+1.0))+0.125*phip*(v0*v1+v0*v2+v1*v2)+c3*mu;
    f12[1]=c3*phip*(v0*(v0+1.0)+v1*(v1+1.0)+v2*(v2-1.0))+0.125*phip*(v0*v1-v0*v2-v1*v2)+c3*mu;
    f13[1]=c3*phip*(v0*(v0+1.0)+v1*(v1-1.0)+v2*(v2+1.0))-0.125*phip*(v0*v1-v0*v2+v1*v2)+c3*mu;
    f14[1]=c3*phip*(v0*(v0+1.0)+v1*(v1-1.0)+v2*(v2-1.0))-0.125*phip*(v0*v1+v0*v2-v1*v2)+c3*mu;
  }
  else {
    phi = 0.0;
    omegat = omega[0];
    d2rdx2 = drdx*drdx;
    d2rdy2 = drdy*drdy;
    d2rdz2 = drdz*drdz;
    d2rdxdy = drdx*drdy;
    d2rdxdz = drdx*drdz;
    d2rdydz = drdy*drdz;
    nabrp = rho*nabr;
  }
  pb = fGetBulkPressureSwift(rho, phi, T);
  lambda = fGetLambdaSwift(rho, omegat, T);
  rhop = 9.0*(rho*(1.0+c0*(v0+v1+v2))-f0[0]-2.0*c0*(f1[0]+f2[0]+f3[0])-c1*(force[0]+force[1]+force[2])-5.0*c0*pb-lbkappa*(5.0*c0*nabrp-c1*(d2rdx2+d2rdy2+d2rdz2))-3.0*lambda*(v0*drdx+v1*drdy+v2*drdz))*fReciprocal(5.0*(v0+v1+v2)+3.0*(v0*v0+v1*v1+v2*v2));
  if(rhop<lbevaplim)
    rhop = rho;
  f6[0]=c3*rhop*(v0*(v0-1.0)+v1*(v1+1.0)+v2*(v2-1.0))-0.125*rhop*(v0*v1-v0*v2+v1*v2)
       +lambda*(c3*(v0*drdx+v1*drdy+v2*drdz)-0.125*(v0*(drdy-drdz)-v1*(drdx+drdz)-v2*(drdx-drdy)))+c3*(pb-lbkappa*nabrp)
       -lbkappa*(c4*(d2rdx2+d2rdy2+d2rdz2)-0.125*(d2rdxdy-d2rdxdz+d2rdydz));
  f7[0]=c3*rhop*(v0*(v0-1.0)+v1*(v1+1.0)+v2*(v2+1.0))-0.125*rhop*(v0*v1+v0*v2-v1*v2)
       +lambda*(c3*(v0*drdx+v1*drdy+v2*drdz)-0.125*(v0*(drdy+drdz)+v1*(drdx-drdz)+v2*(drdx-drdy)))+c3*(pb-lbkappa*nabrp)
       -lbkappa*(c4*(d2rdx2+d2rdy2+d2rdz2)-0.125*(d2rdxdy+d2rdxdz-d2rdydz));
  f8[0]=rhop*(c0*v0*(v0+1.0)-c1*(v1*v1+v2*v2))+c0*lambda*(4.0*v0*drdx+v1*drdy+v2*drdz)+c0*(pb-lbkappa*nabrp)
       +lbkappa*(c0*d2rdx2-c1*d2rdy2-c1*d2rdz2);
  f9[0]=rhop*(c0*v1*(v1+1.0)-c1*(v0*v0+v2*v2))+c0*lambda*(v0*drdx+4.0*v1*drdy+v2*drdz)+c0*(pb-lbkappa*nabrp)
       -lbkappa*(c1*d2rdx2-c0*d2rdy2+c1*d2rdz2);
  f10[0]=rhop*(c0*v2*(v2+1.0)-c1*(v0*v0+v1*v1))+c0*lambda*(v0*drdx+v1*drdy+4.0*v2*drdz)+c0*(pb-lbkappa*nabrp)
       -lbkappa*(c1*d2rdx2+c1*d2rdy2-c0*d2rdz2);
  f11[0]=c3*rhop*(v0*(v0+1.0)+v1*(v1+1.0)+v2*(v2+1.0))+0.125*rhop*(v0*v1+v0*v2+v1*v2)
        +lambda*(c3*(v0*drdx+v1*drdy+v2*drdz)+0.125*(v0*(drdy+drdz)+v1*(drdx+drdz)+v2*(drdx+drdy)))+c3*(pb-lbkappa*nabrp)
        -lbkappa*(c4*(d2rdx2+d2rdy2+d2rdz2)+0.125*(d2rdxdy+d2rdxdz+d2rdydz));
  f12[0]=c3*rhop*(v0*(v0+1.0)+v1*(v1+1.0)+v2*(v2-1.0))+0.125*rhop*(v0*v1-v0*v2-v1*v2)
        +lambda*(c3*(v0*drdx+v1*drdy+v2*drdz)+0.125*(v0*(drdy-drdz)+v1*(drdx-drdz)-v2*(drdx+drdy)))+c3*(pb-lbkappa*nabrp)
        -lbkappa*(c4*(d2rdx2+d2rdy2+d2rdz2)+0.125*(d2rdxdy-d2rdxdz-d2rdydz));
  f13[0]=c3*rhop*(v0*(v0+1.0)+v1*(v1-1.0)+v2*(v2+1.0))-0.125*rhop*(v0*v1-v0*v2+v1*v2)
        +lambda*(c3*(v0*drdx+v1*drdy+v2*drdz)-0.125*(v0*(drdy-drdz)+v1*(drdx+drdz)-v2*(drdx-drdy)))+c3*(pb-lbkappa*nabrp)
        -lbkappa*(c4*(d2rdx2+d2rdy2+d2rdz2)-0.125*(d2rdxdy-d2rdxdz+d2rdydz));
  f14[0]=c3*rhop*(v0*(v0+1.0)+v1*(v1-1.0)+v2*(v2-1.0))-0.125*rhop*(v0*v1+v0*v2-v1*v2)
        +lambda*(c3*(v0*drdx+v1*drdy+v2*drdz)-0.125*(v0*(drdy+drdz)+v1*(drdx-drdz)+v2*(drdx-drdy)))+c3*(pb-lbkappa*nabrp)
        -lbkappa*(c4*(d2rdx2+d2rdy2+d2rdz2)-0.125*(d2rdxdy+d2rdxdz-d2rdydz));
  return 0;
}

int fD3Q15VFInamuro(long tpos, long rpos, int prop, double *uwall, double dx, double dy, double dz, double T)
{
  long spos=tpos * lbsitelength;
  int qdim = lbsy.nf+lbsy.nc+lbsy.nt;
  double drdx, drdy, drdz, dpdx, dpdy, dpdz, nabr, nabp;
  double force[3*lbsy.nf], rho[lbsy.nf];

  fD3Q15BoundaryForceVelocity(force, tpos, rpos, dx, dy, dz, uwall, prop);
    
  if(interact==20) {
    drdx = lbft[4*lbsy.nf*rpos  ];
    drdy = lbft[4*lbsy.nf*rpos+1];
    drdz = lbft[4*lbsy.nf*rpos+2];
    nabr = lbft[4*lbsy.nf*tpos+3];
    dpdx = (lbsy.nf>1)?lbft[4*lbsy.nf*rpos+4]:0.0;
    dpdy = (lbsy.nf>1)?lbft[4*lbsy.nf*rpos+5]:0.0;
    dpdz = (lbsy.nf>1)?lbft[4*lbsy.nf*rpos+6]:0.0;
    nabp = (lbsy.nf>1)?lbft[4*lbsy.nf*tpos+7]:0.0;
  }
  else {
    drdx = 0.0;
    drdy = 0.0;
    drdz = 0.0;
    nabr = 0.0;
    dpdx = 0.0;
    dpdy = 0.0;
    dpdz = 0.0;
    nabp = 0.0;
  }
    
  if(prop>26) {
    fGetAllMassSite(rho, &lbf[rpos*lbsitelength]);
    if(interact==20) {
      rho[0] += (dx*drdx+dy*drdy+dz*drdz);
      if(lbsy.nf>1)
        rho[1] += (dx*dpdx+dy*dpdy+dz*dpdz);
    }
  }
    
  if(interact==20) {
    switch (prop) {
      case PST:
        fD3Q15VPSSwiftInamuro(uwall[0], uwall[1], uwall[2], &force[0], &lbf[spos], &lbf[spos+1*qdim],
                              &lbf[spos+2*qdim], &lbf[spos+3*qdim], &lbf[spos+4*qdim], &lbf[spos+5*qdim],
                              &lbf[spos+6*qdim], &lbf[spos+7*qdim], &lbf[spos+8*qdim], &lbf[spos+9*qdim],
                              &lbf[spos+10*qdim], &lbf[spos+11*qdim], &lbf[spos+12*qdim], &lbf[spos+13*qdim],
                              &lbf[spos+14*qdim], drdx, drdy, drdz, dpdx, dpdy, dpdz, nabr, nabp,
                              &lbomega[lbsy.nf*tpos], T);
        break;
      case PSD:
        fD3Q15VPSSwiftInamuro(-uwall[0], -uwall[1], -uwall[2], &force[0], &lbf[spos], &lbf[spos+8*qdim],
                              &lbf[spos+9*qdim], &lbf[spos+10*qdim], &lbf[spos+11*qdim], &lbf[spos+12*qdim],
                              &lbf[spos+13*qdim], &lbf[spos+14*qdim], &lbf[spos+1*qdim], &lbf[spos+2*qdim],
                              &lbf[spos+3*qdim], &lbf[spos+4*qdim], &lbf[spos+5*qdim], &lbf[spos+6*qdim],
                              &lbf[spos+7*qdim], -drdx, -drdy, -drdz, -dpdx, -dpdy, -dpdz, nabr, nabp,
                              &lbomega[lbsy.nf*tpos], T);
        break;
      case PSL:
        fD3Q15VPSSwiftInamuro(-uwall[2], -uwall[0], -uwall[1], &force[0], &lbf[spos], &lbf[spos+10*qdim],
                              &lbf[spos+8*qdim], &lbf[spos+9*qdim], &lbf[spos+11*qdim], &lbf[spos+13*qdim],
                              &lbf[spos+7*qdim], &lbf[spos+5*qdim], &lbf[spos+3*qdim], &lbf[spos+1*qdim],
                              &lbf[spos+2*qdim], &lbf[spos+4*qdim], &lbf[spos+6*qdim], &lbf[spos+14*qdim],
                              &lbf[spos+12*qdim], -drdz, -drdx, -drdy, -dpdz, -dpdx, -dpdy, nabr, nabp,
                              &lbomega[lbsy.nf*tpos], T);
        break;
      case PSR:
        fD3Q15VPSSwiftInamuro(uwall[2], uwall[0], uwall[1], &force[0], &lbf[spos], &lbf[spos+3*qdim],
                              &lbf[spos+1*qdim], &lbf[spos+2*qdim], &lbf[spos+4*qdim], &lbf[spos+6*qdim],
                              &lbf[spos+14*qdim], &lbf[spos+12*qdim], &lbf[spos+10*qdim], &lbf[spos+8*qdim],
                              &lbf[spos+9*qdim], &lbf[spos+11*qdim], &lbf[spos+13*qdim], &lbf[spos+7*qdim],
                              &lbf[spos+5*qdim], drdz, drdx, drdy, dpdz, dpdx, dpdy, nabr, nabp,
                              &lbomega[lbsy.nf*tpos], T);
        break;
      case PSF:
        fD3Q15VPSSwiftInamuro(-uwall[1], -uwall[2], -uwall[0], &force[0], &lbf[spos], &lbf[spos+9*qdim],
                              &lbf[spos+10*qdim], &lbf[spos+8*qdim], &lbf[spos+11*qdim], &lbf[spos+7*qdim],
                              &lbf[spos+12*qdim], &lbf[spos+6*qdim], &lbf[spos+2*qdim], &lbf[spos+3*qdim],
                              &lbf[spos+1*qdim], &lbf[spos+4*qdim], &lbf[spos+14*qdim], &lbf[spos+5*qdim],
                              &lbf[spos+13*qdim], -drdy, -drdz, -drdx, -dpdy, -dpdz, -dpdx, nabr, nabp,
                              &lbomega[lbsy.nf*tpos], T);
        break;
      case PSB:
        fD3Q15VPSSwiftInamuro(uwall[1], uwall[2], uwall[0], &force[0], &lbf[spos], &lbf[spos+2*qdim],
                              &lbf[spos+3*qdim], &lbf[spos+1*qdim], &lbf[spos+4*qdim], &lbf[spos+14*qdim],
                              &lbf[spos+5*qdim], &lbf[spos+13*qdim], &lbf[spos+9*qdim], &lbf[spos+10*qdim],
                              &lbf[spos+8*qdim], &lbf[spos+11*qdim], &lbf[spos+7*qdim], &lbf[spos+12*qdim],
                              &lbf[spos+6*qdim], drdy, drdz, drdx, dpdy, dpdz, dpdx, nabr, nabp,
                              &lbomega[lbsy.nf*tpos], T);
        break;
      case CCTRB:
        fD3Q15VCCSwiftInamuro(rho, uwall[0], uwall[1], -uwall[2], &force[0], &lbf[spos], &lbf[spos+1*qdim],
                              &lbf[spos+2*qdim], &lbf[spos+10*qdim], &lbf[spos+5*qdim], &lbf[spos+4*qdim],
                              &lbf[spos+7*qdim], &lbf[spos+6*qdim], &lbf[spos+8*qdim], &lbf[spos+9*qdim],
                              &lbf[spos+3*qdim], &lbf[spos+12*qdim], &lbf[spos+11*qdim], &lbf[spos+14*qdim],
                              &lbf[spos+13*qdim], drdx, drdy, -drdz, dpdx, dpdy, -dpdz, nabr, nabp,
                              &lbomega[lbsy.nf*tpos], T);
        break;
      case CCTLB:
        fD3Q15VCCSwiftInamuro(rho, -uwall[0], uwall[1], -uwall[2], &force[0], &lbf[spos], &lbf[spos+8*qdim],
                              &lbf[spos+2*qdim], &lbf[spos+10*qdim], &lbf[spos+13*qdim], &lbf[spos+14*qdim],
                              &lbf[spos+11*qdim], &lbf[spos+12*qdim], &lbf[spos+1*qdim], &lbf[spos+9*qdim],
                              &lbf[spos+3*qdim], &lbf[spos+6*qdim], &lbf[spos+7*qdim], &lbf[spos+4*qdim],
                              &lbf[spos+5*qdim], -drdx, drdy, -drdz, -dpdx, dpdy, -dpdz, nabr, nabp,
                              &lbomega[lbsy.nf*tpos], T);
        break;
      case CCDLB:
        fD3Q15VCCSwiftInamuro(rho, -uwall[0], -uwall[1], -uwall[2], &force[0], &lbf[spos], &lbf[spos+8*qdim],
                              &lbf[spos+9*qdim], &lbf[spos+10*qdim], &lbf[spos+11*qdim], &lbf[spos+12*qdim],
                              &lbf[spos+13*qdim], &lbf[spos+14*qdim], &lbf[spos+1*qdim], &lbf[spos+2*qdim],
                              &lbf[spos+3*qdim], &lbf[spos+4*qdim], &lbf[spos+5*qdim], &lbf[spos+6*qdim],
                              &lbf[spos+7*qdim], -drdx, -drdy, -drdz, -dpdx, -dpdy, -dpdz, nabr, nabp,
                              &lbomega[lbsy.nf*tpos], T);
        break;
      case CCDRB:
        fD3Q15VCCSwiftInamuro(rho, uwall[0], -uwall[1], -uwall[2], &force[0], &lbf[spos], &lbf[spos+1*qdim],
                              &lbf[spos+9*qdim], &lbf[spos+10*qdim], &lbf[spos+7*qdim], &lbf[spos+6*qdim],
                              &lbf[spos+5*qdim], &lbf[spos+4*qdim], &lbf[spos+8*qdim], &lbf[spos+2*qdim],
                              &lbf[spos+3*qdim], &lbf[spos+14*qdim], &lbf[spos+13*qdim], &lbf[spos+12*qdim],
                              &lbf[spos+11*qdim], drdx, -drdy, -drdz, dpdx, -dpdy, -dpdz, nabr, nabp,
                              &lbomega[lbsy.nf*tpos], T);
        break;
      case CCTRF:
        fD3Q15VCCSwiftInamuro(rho, uwall[0], uwall[1], uwall[2], &force[0], &lbf[spos], &lbf[spos+1*qdim],
                              &lbf[spos+2*qdim], &lbf[spos+3*qdim], &lbf[spos+4*qdim], &lbf[spos+5*qdim],
                              &lbf[spos+6*qdim], &lbf[spos+7*qdim], &lbf[spos+8*qdim], &lbf[spos+9*qdim],
                              &lbf[spos+10*qdim], &lbf[spos+11*qdim], &lbf[spos+12*qdim], &lbf[spos+13*qdim],
                              &lbf[spos+14*qdim], drdx, drdy, drdz, dpdx, dpdy, dpdz, nabr, nabp,
                              &lbomega[lbsy.nf*tpos], T);
        break;
      case CCTLF:
        fD3Q15VCCSwiftInamuro(rho, -uwall[0], uwall[1], uwall[2], &force[0], &lbf[spos], &lbf[spos+8*qdim],
                              &lbf[spos+2*qdim], &lbf[spos+3*qdim], &lbf[spos+14*qdim], &lbf[spos+13*qdim],
                              &lbf[spos+12*qdim], &lbf[spos+11*qdim], &lbf[spos+1*qdim], &lbf[spos+9*qdim],
                              &lbf[spos+10*qdim], &lbf[spos+7*qdim], &lbf[spos+6*qdim], &lbf[spos+5*qdim],
                              &lbf[spos+4*qdim], -drdx, drdy, drdz, -dpdx, dpdy, dpdz, nabr, nabp,
                              &lbomega[lbsy.nf*tpos], T);
        break;
      case CCDLF:
        fD3Q15VCCSwiftInamuro(rho, -uwall[0], -uwall[1], uwall[2], &force[0], &lbf[spos], &lbf[spos+8*qdim],
                              &lbf[spos+9*qdim], &lbf[spos+3*qdim], &lbf[spos+12*qdim], &lbf[spos+11*qdim],
                              &lbf[spos+14*qdim], &lbf[spos+13*qdim], &lbf[spos+1*qdim], &lbf[spos+2*qdim],
                              &lbf[spos+10*qdim], &lbf[spos+5*qdim], &lbf[spos+4*qdim], &lbf[spos+7*qdim],
                              &lbf[spos+6*qdim], -drdx, -drdy, drdz, -dpdx, -dpdy, dpdz, nabr, nabp,
                              &lbomega[lbsy.nf*tpos], T);
        break;
      case CCDRF:
        fD3Q15VCCSwiftInamuro(rho, uwall[0], -uwall[1], uwall[2], &force[0], &lbf[spos], &lbf[spos+1*qdim],
                              &lbf[spos+9*qdim], &lbf[spos+3*qdim], &lbf[spos+6*qdim], &lbf[spos+7*qdim],
                              &lbf[spos+4*qdim], &lbf[spos+5*qdim], &lbf[spos+8*qdim], &lbf[spos+2*qdim],
                              &lbf[spos+10*qdim], &lbf[spos+13*qdim], &lbf[spos+14*qdim], &lbf[spos+11*qdim],
                              &lbf[spos+12*qdim], drdx, -drdy, drdz, dpdx, -dpdy, dpdz, nabr, nabp,
                              &lbomega[lbsy.nf*tpos], T);
        break;
      case CETR:
        fD3Q15VCESwiftInamuro(rho, uwall[0], uwall[1], uwall[2], &force[0], &lbf[spos], &lbf[spos+1*qdim],
                              &lbf[spos+2*qdim], &lbf[spos+3*qdim], &lbf[spos+4*qdim], &lbf[spos+5*qdim],
                              &lbf[spos+6*qdim], &lbf[spos+7*qdim], &lbf[spos+8*qdim], &lbf[spos+9*qdim],
                              &lbf[spos+10*qdim], &lbf[spos+11*qdim], &lbf[spos+12*qdim], &lbf[spos+13*qdim],
                              &lbf[spos+14*qdim], drdx, drdy, drdz, dpdx, dpdy, dpdz, nabr, nabp,
                              &lbomega[lbsy.nf*tpos], T);
        break;
      case CETL:
        fD3Q15VCESwiftInamuro(rho, uwall[1], -uwall[0], uwall[2], &force[0], &lbf[spos], &lbf[spos+2*qdim],
                              &lbf[spos+8*qdim], &lbf[spos+3*qdim], &lbf[spos+14*qdim], &lbf[spos+13*qdim],
                              &lbf[spos+4*qdim], &lbf[spos+5*qdim], &lbf[spos+9*qdim], &lbf[spos+1*qdim],
                              &lbf[spos+10*qdim], &lbf[spos+7*qdim], &lbf[spos+6*qdim], &lbf[spos+11*qdim],
                              &lbf[spos+12*qdim], drdy, -drdx, drdz, dpdy, -dpdx, dpdz, nabr, nabp,
                              &lbomega[lbsy.nf*tpos], T);
        break;
      case CEDL:
        fD3Q15VCESwiftInamuro(rho, -uwall[0], -uwall[1], uwall[2], &force[0], &lbf[spos], &lbf[spos+8*qdim],
                              &lbf[spos+9*qdim], &lbf[spos+3*qdim], &lbf[spos+12*qdim], &lbf[spos+11*qdim],
                              &lbf[spos+14*qdim], &lbf[spos+13*qdim], &lbf[spos+1*qdim], &lbf[spos+2*qdim],
                              &lbf[spos+10*qdim], &lbf[spos+5*qdim], &lbf[spos+4*qdim], &lbf[spos+7*qdim],
                              &lbf[spos+6*qdim], -drdx, -drdy, drdz, -dpdx, -dpdy, dpdz, nabr, nabp,
                              &lbomega[lbsy.nf*tpos], T);
        break;
      case CEDR:
        fD3Q15VCESwiftInamuro(rho, -uwall[1], uwall[0], uwall[2], &force[0], &lbf[spos], &lbf[spos+9*qdim],
                              &lbf[spos+1*qdim], &lbf[spos+3*qdim], &lbf[spos+6*qdim], &lbf[spos+7*qdim],
                              &lbf[spos+12*qdim], &lbf[spos+11*qdim], &lbf[spos+2*qdim], &lbf[spos+8*qdim],
                              &lbf[spos+10*qdim], &lbf[spos+13*qdim], &lbf[spos+14*qdim], &lbf[spos+5*qdim],
                              &lbf[spos+4*qdim], -drdy, drdx, drdz, -dpdy, dpdx, dpdz, nabr, nabp,
                              &lbomega[lbsy.nf*tpos], T);
        break;
      case CETF:
        fD3Q15VCESwiftInamuro(rho, uwall[1], uwall[2], uwall[0], &force[0], &lbf[spos], &lbf[spos+2*qdim],
                              &lbf[spos+3*qdim], &lbf[spos+1*qdim], &lbf[spos+4*qdim], &lbf[spos+14*qdim],
                              &lbf[spos+5*qdim], &lbf[spos+13*qdim], &lbf[spos+9*qdim], &lbf[spos+10*qdim],
                              &lbf[spos+8*qdim], &lbf[spos+11*qdim], &lbf[spos+7*qdim], &lbf[spos+12*qdim],
                              &lbf[spos+6*qdim], drdy, drdz, drdx, dpdy, dpdz, dpdx, nabr, nabp,
                              &lbomega[lbsy.nf*tpos], T);
        break;
      case CELF:
        fD3Q15VCESwiftInamuro(rho, -uwall[0], uwall[2], uwall[1], &force[0], &lbf[spos], &lbf[spos+8*qdim],
                              &lbf[spos+3*qdim], &lbf[spos+2*qdim], &lbf[spos+14*qdim], &lbf[spos+12*qdim],
                              &lbf[spos+13*qdim], &lbf[spos+11*qdim], &lbf[spos+1*qdim], &lbf[spos+10*qdim],
                              &lbf[spos+9*qdim], &lbf[spos+7*qdim], &lbf[spos+5*qdim], &lbf[spos+6*qdim],
                              &lbf[spos+4*qdim], -drdx, drdz, drdy, -dpdx, dpdz, dpdy, nabr, nabp,
                              &lbomega[lbsy.nf*tpos], T);
        break;
      case CEDF:
        fD3Q15VCESwiftInamuro(rho, -uwall[1], uwall[2], uwall[0], &force[0], &lbf[spos], &lbf[spos+9*qdim],
                              &lbf[spos+3*qdim], &lbf[spos+1*qdim], &lbf[spos+6*qdim], &lbf[spos+12*qdim],
                              &lbf[spos+7*qdim], &lbf[spos+11*qdim], &lbf[spos+2*qdim], &lbf[spos+10*qdim],
                              &lbf[spos+8*qdim], &lbf[spos+13*qdim], &lbf[spos+5*qdim], &lbf[spos+14*qdim],
                              &lbf[spos+4*qdim], -drdy, drdz, drdx, -dpdy, dpdz, dpdx, nabr, nabp,
                              &lbomega[lbsy.nf*tpos], T);
        break;
      case CERF:
        fD3Q15VCESwiftInamuro(rho, uwall[0], uwall[2], uwall[1], &force[0], &lbf[spos], &lbf[spos+1*qdim],
                              &lbf[spos+3*qdim], &lbf[spos+2*qdim], &lbf[spos+4*qdim], &lbf[spos+6*qdim],
                              &lbf[spos+5*qdim], &lbf[spos+7*qdim], &lbf[spos+8*qdim], &lbf[spos+10*qdim],
                              &lbf[spos+9*qdim], &lbf[spos+11*qdim], &lbf[spos+13*qdim], &lbf[spos+12*qdim],
                              &lbf[spos+14*qdim], drdx, drdz, drdy, dpdx, dpdz, dpdy, nabr, nabp,
                              &lbomega[lbsy.nf*tpos], T);
        break;
      case CETB:
        fD3Q15VCESwiftInamuro(rho, uwall[1], -uwall[2], uwall[0], &force[0], &lbf[spos], &lbf[spos+2*qdim],
                              &lbf[spos+10*qdim], &lbf[spos+1*qdim], &lbf[spos+5*qdim], &lbf[spos+13*qdim],
                              &lbf[spos+4*qdim], &lbf[spos+14*qdim], &lbf[spos+9*qdim], &lbf[spos+3*qdim],
                              &lbf[spos+8*qdim], &lbf[spos+12*qdim], &lbf[spos+6*qdim], &lbf[spos+11*qdim],
                              &lbf[spos+7*qdim], drdy, -drdz, drdx, dpdy, -dpdz, dpdx, nabr, nabp,
                              &lbomega[lbsy.nf*tpos], T);
        break;
      case CELB:
        fD3Q15VCESwiftInamuro(rho, -uwall[0], -uwall[2], uwall[1], &force[0], &lbf[spos], &lbf[spos+8*qdim],
                              &lbf[spos+10*qdim], &lbf[spos+2*qdim], &lbf[spos+13*qdim], &lbf[spos+11*qdim],
                              &lbf[spos+14*qdim], &lbf[spos+12*qdim], &lbf[spos+1*qdim], &lbf[spos+3*qdim],
                              &lbf[spos+9*qdim], &lbf[spos+6*qdim], &lbf[spos+4*qdim], &lbf[spos+7*qdim],
                              &lbf[spos+5*qdim], -drdx, -drdz, drdy, -dpdx, -dpdz, dpdy, nabr, nabp,
                              &lbomega[lbsy.nf*tpos], T);
        break;
      case CEDB:
        fD3Q15VCESwiftInamuro(rho, -uwall[1], -uwall[2], uwall[0], &force[0], &lbf[spos], &lbf[spos+9*qdim],
                              &lbf[spos+10*qdim], &lbf[spos+1*qdim], &lbf[spos+7*qdim], &lbf[spos+11*qdim],
                              &lbf[spos+6*qdim], &lbf[spos+12*qdim], &lbf[spos+2*qdim], &lbf[spos+3*qdim],
                              &lbf[spos+8*qdim], &lbf[spos+14*qdim], &lbf[spos+4*qdim], &lbf[spos+13*qdim],
                              &lbf[spos+5*qdim], -drdy, -drdz, drdx, -dpdy, -dpdz, dpdx, nabr, nabp,
                              &lbomega[lbsy.nf*tpos], T);
        break;
      case CERB:
        fD3Q15VCESwiftInamuro(rho, uwall[0], -uwall[2], uwall[1], &force[0], &lbf[spos], &lbf[spos+1*qdim],
                              &lbf[spos+10*qdim], &lbf[spos+2*qdim], &lbf[spos+5*qdim], &lbf[spos+7*qdim],
                              &lbf[spos+4*qdim], &lbf[spos+6*qdim], &lbf[spos+8*qdim], &lbf[spos+3*qdim],
                              &lbf[spos+9*qdim], &lbf[spos+12*qdim], &lbf[spos+14*qdim], &lbf[spos+11*qdim],
                              &lbf[spos+13*qdim], drdx, -drdz, drdy, dpdx, -dpdz, dpdy, nabr, nabp,
                              &lbomega[lbsy.nf*tpos], T);
        break;
    }
  }
  else {
    switch (prop) {
      case PST:
        fD3Q15VPSInamuro(uwall[0], uwall[1], uwall[2], &force[0], &lbf[spos], &lbf[spos+1*qdim],
                         &lbf[spos+2*qdim], &lbf[spos+3*qdim], &lbf[spos+4*qdim], &lbf[spos+5*qdim],
                         &lbf[spos+6*qdim], &lbf[spos+7*qdim], &lbf[spos+8*qdim], &lbf[spos+9*qdim],
                         &lbf[spos+10*qdim], &lbf[spos+11*qdim], &lbf[spos+12*qdim], &lbf[spos+13*qdim],
                         &lbf[spos+14*qdim]);
        break;
      case PSD:
        fD3Q15VPSInamuro(-uwall[0], -uwall[1], -uwall[2], &force[0], &lbf[spos], &lbf[spos+8*qdim],
                         &lbf[spos+9*qdim], &lbf[spos+10*qdim], &lbf[spos+11*qdim], &lbf[spos+12*qdim],
                         &lbf[spos+13*qdim], &lbf[spos+14*qdim], &lbf[spos+1*qdim], &lbf[spos+2*qdim],
                         &lbf[spos+3*qdim], &lbf[spos+4*qdim], &lbf[spos+5*qdim], &lbf[spos+6*qdim],
                         &lbf[spos+7*qdim]);
        break;
      case PSL:
        fD3Q15VPSInamuro(-uwall[2], -uwall[0], -uwall[1], &force[0], &lbf[spos], &lbf[spos+10*qdim],
                         &lbf[spos+8*qdim], &lbf[spos+9*qdim], &lbf[spos+11*qdim], &lbf[spos+13*qdim],
                         &lbf[spos+7*qdim], &lbf[spos+5*qdim], &lbf[spos+3*qdim], &lbf[spos+1*qdim],
                         &lbf[spos+2*qdim], &lbf[spos+4*qdim], &lbf[spos+6*qdim], &lbf[spos+14*qdim],
                         &lbf[spos+12*qdim]);
        break;
      case PSR:
        fD3Q15VPSInamuro(uwall[2], uwall[0], uwall[1], &force[0], &lbf[spos], &lbf[spos+3*qdim],
                         &lbf[spos+1*qdim], &lbf[spos+2*qdim], &lbf[spos+4*qdim], &lbf[spos+6*qdim],
                         &lbf[spos+14*qdim], &lbf[spos+12*qdim], &lbf[spos+10*qdim], &lbf[spos+8*qdim],
                         &lbf[spos+9*qdim], &lbf[spos+11*qdim], &lbf[spos+13*qdim], &lbf[spos+7*qdim],
                         &lbf[spos+5*qdim]);
        break;
      case PSF:
        fD3Q15VPSInamuro(-uwall[1], -uwall[2], -uwall[0], &force[0], &lbf[spos], &lbf[spos+9*qdim],
                         &lbf[spos+10*qdim], &lbf[spos+8*qdim], &lbf[spos+11*qdim], &lbf[spos+7*qdim],
                         &lbf[spos+12*qdim], &lbf[spos+6*qdim], &lbf[spos+2*qdim], &lbf[spos+3*qdim],
                         &lbf[spos+1*qdim], &lbf[spos+4*qdim], &lbf[spos+14*qdim], &lbf[spos+5*qdim],
                         &lbf[spos+13*qdim]);
        break;
      case PSB:
        fD3Q15VPSInamuro(uwall[1], uwall[2], uwall[0], &force[0], &lbf[spos], &lbf[spos+2*qdim],
                         &lbf[spos+3*qdim], &lbf[spos+1*qdim], &lbf[spos+4*qdim], &lbf[spos+14*qdim],
                         &lbf[spos+5*qdim], &lbf[spos+13*qdim], &lbf[spos+9*qdim], &lbf[spos+10*qdim],
                         &lbf[spos+8*qdim], &lbf[spos+11*qdim], &lbf[spos+7*qdim], &lbf[spos+12*qdim],
                         &lbf[spos+6*qdim]);
        break;
      case CCTRB:
        fD3Q15VCCInamuro(rho, uwall[0], uwall[1], -uwall[2], &force[0], &lbf[spos], &lbf[spos+1*qdim],
                         &lbf[spos+2*qdim], &lbf[spos+10*qdim], &lbf[spos+5*qdim], &lbf[spos+4*qdim],
                         &lbf[spos+7*qdim], &lbf[spos+6*qdim], &lbf[spos+8*qdim], &lbf[spos+9*qdim],
                         &lbf[spos+3*qdim], &lbf[spos+12*qdim], &lbf[spos+11*qdim], &lbf[spos+14*qdim],
                         &lbf[spos+13*qdim]);
        break;
      case CCTLB:
        fD3Q15VCCInamuro(rho, -uwall[0], uwall[1], -uwall[2], &force[0], &lbf[spos], &lbf[spos+8*qdim],
                         &lbf[spos+2*qdim], &lbf[spos+10*qdim], &lbf[spos+13*qdim], &lbf[spos+14*qdim],
                         &lbf[spos+11*qdim], &lbf[spos+12*qdim], &lbf[spos+1*qdim], &lbf[spos+9*qdim],
                         &lbf[spos+3*qdim], &lbf[spos+6*qdim], &lbf[spos+7*qdim], &lbf[spos+4*qdim],
                         &lbf[spos+5*qdim]);
        break;
      case CCDLB:
        fD3Q15VCCInamuro(rho, -uwall[0], -uwall[1], -uwall[2], &force[0], &lbf[spos], &lbf[spos+8*qdim],
                         &lbf[spos+9*qdim], &lbf[spos+10*qdim], &lbf[spos+11*qdim], &lbf[spos+12*qdim],
                         &lbf[spos+13*qdim], &lbf[spos+14*qdim], &lbf[spos+1*qdim], &lbf[spos+2*qdim],
                         &lbf[spos+3*qdim], &lbf[spos+4*qdim], &lbf[spos+5*qdim], &lbf[spos+6*qdim],
                         &lbf[spos+7*qdim]);
        break;
      case CCDRB:
        fD3Q15VCCInamuro(rho, uwall[0], -uwall[1], -uwall[2], &force[0], &lbf[spos], &lbf[spos+1*qdim],
                         &lbf[spos+9*qdim], &lbf[spos+10*qdim], &lbf[spos+7*qdim], &lbf[spos+6*qdim],
                         &lbf[spos+5*qdim], &lbf[spos+4*qdim], &lbf[spos+8*qdim], &lbf[spos+2*qdim],
                         &lbf[spos+3*qdim], &lbf[spos+14*qdim], &lbf[spos+13*qdim], &lbf[spos+12*qdim],
                         &lbf[spos+11*qdim]);
        break;
      case CCTRF:
        fD3Q15VCCInamuro(rho, uwall[0], uwall[1], uwall[2], &force[0], &lbf[spos], &lbf[spos+1*qdim],
                         &lbf[spos+2*qdim], &lbf[spos+3*qdim], &lbf[spos+4*qdim], &lbf[spos+5*qdim],
                         &lbf[spos+6*qdim], &lbf[spos+7*qdim], &lbf[spos+8*qdim], &lbf[spos+9*qdim],
                         &lbf[spos+10*qdim], &lbf[spos+11*qdim], &lbf[spos+12*qdim], &lbf[spos+13*qdim],
                         &lbf[spos+14*qdim]);
        break;
      case CCTLF:
        fD3Q15VCCInamuro(rho, -uwall[0], uwall[1], uwall[2], &force[0], &lbf[spos], &lbf[spos+8*qdim],
                         &lbf[spos+2*qdim], &lbf[spos+3*qdim], &lbf[spos+14*qdim], &lbf[spos+13*qdim],
                         &lbf[spos+12*qdim], &lbf[spos+11*qdim], &lbf[spos+1*qdim], &lbf[spos+9*qdim],
                         &lbf[spos+10*qdim], &lbf[spos+7*qdim], &lbf[spos+6*qdim], &lbf[spos+5*qdim],
                         &lbf[spos+4*qdim]);
        break;
      case CCDLF:
        fD3Q15VCCInamuro(rho, -uwall[0], -uwall[1], uwall[2], &force[0], &lbf[spos], &lbf[spos+8*qdim],
                         &lbf[spos+9*qdim], &lbf[spos+3*qdim], &lbf[spos+12*qdim], &lbf[spos+11*qdim],
                         &lbf[spos+14*qdim], &lbf[spos+13*qdim], &lbf[spos+1*qdim], &lbf[spos+2*qdim],
                         &lbf[spos+10*qdim], &lbf[spos+5*qdim], &lbf[spos+4*qdim], &lbf[spos+7*qdim],
                         &lbf[spos+6*qdim]);
        break;
      case CCDRF:
        fD3Q15VCCInamuro(rho, uwall[0], -uwall[1], uwall[2], &force[0], &lbf[spos], &lbf[spos+1*qdim],
                         &lbf[spos+9*qdim], &lbf[spos+3*qdim], &lbf[spos+6*qdim], &lbf[spos+7*qdim],
                         &lbf[spos+4*qdim], &lbf[spos+5*qdim], &lbf[spos+8*qdim], &lbf[spos+2*qdim],
                         &lbf[spos+10*qdim], &lbf[spos+13*qdim], &lbf[spos+14*qdim], &lbf[spos+11*qdim],
                         &lbf[spos+12*qdim]);
        break;
      case CETR:
        fD3Q15VCEInamuro(rho, uwall[0], uwall[1], uwall[2], &force[0], &lbf[spos], &lbf[spos+1*qdim],
                         &lbf[spos+2*qdim], &lbf[spos+3*qdim], &lbf[spos+4*qdim], &lbf[spos+5*qdim],
                         &lbf[spos+6*qdim], &lbf[spos+7*qdim], &lbf[spos+8*qdim], &lbf[spos+9*qdim],
                         &lbf[spos+10*qdim], &lbf[spos+11*qdim], &lbf[spos+12*qdim], &lbf[spos+13*qdim],
                         &lbf[spos+14*qdim]);
        break;
      case CETL:
        fD3Q15VCEInamuro(rho, uwall[1], -uwall[0], uwall[2], &force[0], &lbf[spos], &lbf[spos+2*qdim],
                         &lbf[spos+8*qdim], &lbf[spos+3*qdim], &lbf[spos+14*qdim], &lbf[spos+13*qdim],
                         &lbf[spos+4*qdim], &lbf[spos+5*qdim], &lbf[spos+9*qdim], &lbf[spos+1*qdim],
                         &lbf[spos+10*qdim], &lbf[spos+7*qdim], &lbf[spos+6*qdim], &lbf[spos+11*qdim],
                         &lbf[spos+12*qdim]);
        break;
      case CEDL:
        fD3Q15VCEInamuro(rho, -uwall[0], -uwall[1], uwall[2], &force[0], &lbf[spos], &lbf[spos+8*qdim],
                         &lbf[spos+9*qdim], &lbf[spos+3*qdim], &lbf[spos+12*qdim], &lbf[spos+11*qdim],
                         &lbf[spos+14*qdim], &lbf[spos+13*qdim], &lbf[spos+1*qdim], &lbf[spos+2*qdim],
                         &lbf[spos+10*qdim], &lbf[spos+5*qdim], &lbf[spos+4*qdim], &lbf[spos+7*qdim],
                         &lbf[spos+6*qdim]);
        break;
      case CEDR:
        fD3Q15VCEInamuro(rho, -uwall[1], uwall[0], uwall[2], &force[0], &lbf[spos], &lbf[spos+9*qdim],
                         &lbf[spos+1*qdim], &lbf[spos+3*qdim], &lbf[spos+6*qdim], &lbf[spos+7*qdim],
                         &lbf[spos+12*qdim], &lbf[spos+11*qdim], &lbf[spos+2*qdim], &lbf[spos+8*qdim],
                         &lbf[spos+10*qdim], &lbf[spos+13*qdim], &lbf[spos+14*qdim], &lbf[spos+5*qdim],
                         &lbf[spos+4*qdim]);
        break;
      case CETF:
        fD3Q15VCEInamuro(rho, uwall[1], uwall[2], uwall[0], &force[0], &lbf[spos], &lbf[spos+2*qdim],
                         &lbf[spos+3*qdim], &lbf[spos+1*qdim], &lbf[spos+4*qdim], &lbf[spos+14*qdim],
                         &lbf[spos+5*qdim], &lbf[spos+13*qdim], &lbf[spos+9*qdim], &lbf[spos+10*qdim],
                         &lbf[spos+8*qdim], &lbf[spos+11*qdim], &lbf[spos+7*qdim], &lbf[spos+12*qdim],
                         &lbf[spos+6*qdim]);
        break;
      case CELF:
        fD3Q15VCEInamuro(rho, -uwall[0], uwall[2], uwall[1], &force[0], &lbf[spos], &lbf[spos+8*qdim],
                         &lbf[spos+3*qdim], &lbf[spos+2*qdim], &lbf[spos+14*qdim], &lbf[spos+12*qdim],
                         &lbf[spos+13*qdim], &lbf[spos+11*qdim], &lbf[spos+1*qdim], &lbf[spos+10*qdim],
                         &lbf[spos+9*qdim], &lbf[spos+7*qdim], &lbf[spos+5*qdim], &lbf[spos+6*qdim],
                         &lbf[spos+4*qdim]);
        break;
      case CEDF:
        fD3Q15VCEInamuro(rho, -uwall[1], uwall[2], uwall[0], &force[0], &lbf[spos], &lbf[spos+9*qdim],
                         &lbf[spos+3*qdim], &lbf[spos+1*qdim], &lbf[spos+6*qdim], &lbf[spos+12*qdim],
                         &lbf[spos+7*qdim], &lbf[spos+11*qdim], &lbf[spos+2*qdim], &lbf[spos+10*qdim],
                         &lbf[spos+8*qdim], &lbf[spos+13*qdim], &lbf[spos+5*qdim], &lbf[spos+14*qdim],
                         &lbf[spos+4*qdim]);
        break;
      case CERF:
        fD3Q15VCEInamuro(rho, uwall[0], uwall[2], uwall[1], &force[0], &lbf[spos], &lbf[spos+1*qdim],
                         &lbf[spos+3*qdim], &lbf[spos+2*qdim], &lbf[spos+4*qdim], &lbf[spos+6*qdim],
                         &lbf[spos+5*qdim], &lbf[spos+7*qdim], &lbf[spos+8*qdim], &lbf[spos+10*qdim],
                         &lbf[spos+9*qdim], &lbf[spos+11*qdim], &lbf[spos+13*qdim], &lbf[spos+12*qdim],
                         &lbf[spos+14*qdim]);
        break;
      case CETB:
        fD3Q15VCEInamuro(rho, uwall[1], -uwall[2], uwall[0], &force[0], &lbf[spos], &lbf[spos+2*qdim],
                         &lbf[spos+10*qdim], &lbf[spos+1*qdim], &lbf[spos+5*qdim], &lbf[spos+13*qdim],
                         &lbf[spos+4*qdim], &lbf[spos+14*qdim], &lbf[spos+9*qdim], &lbf[spos+3*qdim],
                         &lbf[spos+8*qdim], &lbf[spos+12*qdim], &lbf[spos+6*qdim], &lbf[spos+11*qdim],
                         &lbf[spos+7*qdim]);
        break;
      case CELB:
        fD3Q15VCEInamuro(rho, -uwall[0], -uwall[2], uwall[1], &force[0], &lbf[spos], &lbf[spos+8*qdim],
                         &lbf[spos+10*qdim], &lbf[spos+2*qdim], &lbf[spos+13*qdim], &lbf[spos+11*qdim],
                         &lbf[spos+14*qdim], &lbf[spos+12*qdim], &lbf[spos+1*qdim], &lbf[spos+3*qdim],
                         &lbf[spos+9*qdim], &lbf[spos+6*qdim], &lbf[spos+4*qdim], &lbf[spos+7*qdim],
                         &lbf[spos+5*qdim]);
        break;
      case CEDB:
        fD3Q15VCEInamuro(rho, -uwall[1], -uwall[2], uwall[0], &force[0], &lbf[spos], &lbf[spos+9*qdim],
                         &lbf[spos+10*qdim], &lbf[spos+1*qdim], &lbf[spos+7*qdim], &lbf[spos+11*qdim],
                         &lbf[spos+6*qdim], &lbf[spos+12*qdim], &lbf[spos+2*qdim], &lbf[spos+3*qdim],
                         &lbf[spos+8*qdim], &lbf[spos+14*qdim], &lbf[spos+4*qdim], &lbf[spos+13*qdim],
                         &lbf[spos+5*qdim]);
        break;
      case CERB:
        fD3Q15VCEInamuro(rho, uwall[0], -uwall[2], uwall[1], &force[0], &lbf[spos], &lbf[spos+1*qdim],
                         &lbf[spos+10*qdim], &lbf[spos+2*qdim], &lbf[spos+5*qdim], &lbf[spos+7*qdim],
                         &lbf[spos+4*qdim], &lbf[spos+6*qdim], &lbf[spos+8*qdim], &lbf[spos+3*qdim],
                         &lbf[spos+9*qdim], &lbf[spos+12*qdim], &lbf[spos+14*qdim], &lbf[spos+11*qdim],
                         &lbf[spos+13*qdim]);
        break;
    }
  }
  return 0;
  
}

int fD3Q15PPSInamuro(double *p, double *force, double *f0, double *f1,
	                 double *f2, double *f3, double *f4, double *f5,
	                 double *f6, double *f7, double *f8, double *f9,
	                 double *f10, double *f11, double *f12, double *f13,
	                 double *f14, double &vel)
{

  // produce fixed pressure/density at planar surface: expressed for bottom wall (PPST)

  double rho0, rrho0, rhop, v0t, v2t, v, v1, mass=0.0;
  double c1=1.0/9.0,c2=1.0/72.0;
  vel = 0.0;
    
  if(!incompress) {
    for(int i=0; i<lbsy.nf; i++) {
      v = p[i]-(f0[i]+f1[i]+f3[i]+f8[i]+f10[i]+2*(f2[i]+f4[i]+f5[i]+f13[i]+f14[i]))+0.5*force[3*i+1];
      vel += v;
      mass += p[i];
    }
    v1 = vel*fReciprocal(mass);
    for(int i=0; i<lbsy.nf; i++) {
      v = p[i]-(f0[i]+f1[i]+f3[i]+f8[i]+f10[i]+2*(f2[i]+f4[i]+f5[i]+f13[i]+f14[i]));
      rhop = 6.0*(v+f2[i]+f4[i]+f5[i]+f13[i]+f14[i])/(1.0+3.0*v1*(1.0+v1));
      v0t = 6.0*(f1[i]+f4[i]+f5[i]-f8[i]-f13[i]-f14[i]-0.5*force[3*i  ])/(rhop*(1.0+3.0*v1));
      v2t = 6.0*(f3[i]+f4[i]-f5[i]-f10[i]-f13[i]+f14[i]-0.5*force[3*i+2])/(rhop*(1.0+3.0*v1));
      f6[i]=c2*rhop*(1.0+3.0*(v1*(1.0+v1)-v0t*(1.0-v0t)-v2t*(1.0-v2t))-9.0*v1*(v0t+v2t)+9.0*v0t*v2t);
      f7[i]=c2*rhop*(1.0+3.0*(v1*(1.0+v1)-v0t*(1.0-v0t)+v2t*(1.0+v2t))-9.0*v1*(v0t-v2t)-9.0*v0t*v2t);
      f9[i]=c1*rhop*(1.0+3.0*v1*(1.0+v1)-1.5*(v0t*v0t+v2t*v2t));
      f11[i]=c2*rhop*(1.0+3.0*(v1*(1.0+v1)+v0t*(1.0+v0t)+v2t*(1.0+v2t))+9.0*v1*(v0t+v2t)+9.0*v0t*v2t);
      f12[i]=c2*rhop*(1.0+3.0*(v1*(1.0+v1)+v0t*(1.0+v0t)-v2t*(1.0-v2t))+9.0*v1*(v0t-v2t)-9.0*v0t*v2t);
    }
  }
  else {
    for(int i=0; i<lbsy.nf; i++) {
      v = p[i]-(f0[i]+f1[i]+f3[i]+f8[i]+f10[i]+2*(f2[i]+f4[i]+f5[i]+f13[i]+f14[i]))+0.5*force[3*i+1];
      vel += v;
      mass += lbincp[i];
    }
    v1 = vel*fReciprocal(mass);
    for(int i=0; i<lbsy.nf; i++) {
      rho0 = lbincp[i];
      rrho0 = fReciprocal(rho0);
      rhop = 6.0*(f2[i]+f4[i]+f5[i]+f13[i]+f14[i])+3.0*rho0*v1*(1.0-v1)-3.0*force[3*i+1];
      v0t = 6.0*(f1[i]+f4[i]+f5[i]-f8[i]-f13[i]-f14[i]-0.5*force[3*i  ])*rrho0/(1.0+3.0*v1);
      v2t = 6.0*(f3[i]+f4[i]-f5[i]-f10[i]-f13[i]+f14[i]-0.5*force[3*i+2])*rrho0/(1.0+3.0*v1);
      f6[i]=c2*(rho0+rhop*(3.0*(v1*(1.0+v1)-v0t*(1.0-v0t)-v2t*(1.0-v2t))-9.0*v1*(v0t+v2t)+9.0*v0t*v2t));
      f7[i]=c2*(rho0+rhop*(3.0*(v1*(1.0+v1)-v0t*(1.0-v0t)+v2t*(1.0+v2t))-9.0*v1*(v0t-v2t)-9.0*v0t*v2t));
      f9[i]=c1*(rho0+rhop*(3.0*v1*(1.0+v1)-1.5*(v0t*v0t+v2t*v2t)));
      f11[i]=c2*(rho0+rhop*(3.0*(v1*(1.0+v1)+v0t*(1.0+v0t)+v2t*(1.0+v2t))+9.0*v1*(v0t+v2t)+9.0*v0t*v2t));
      f12[i]=c2*(rho0+rhop*(3.0*(v1*(1.0+v1)+v0t*(1.0+v0t)-v2t*(1.0-v2t))+9.0*v1*(v0t-v2t)-9.0*v0t*v2t));
    }
  }
  vel *= fReciprocal(mass);
  return 0;
}

int fD3Q15PPSSwiftInamuro(double *p, double *force, double *f0, double *f1,
	                      double *f2, double *f3, double *f4, double *f5,
	                      double *f6, double *f7, double *f8, double *f9,
	                      double *f10, double *f11, double *f12, double *f13,
	                      double *f14, double drdx, double drdy, double drdz,
                          double dpdx, double dpdy, double dpdz, double nabr,
                          double nabp, double *omega, double T, double &vel)
{
  // produce fixed pressure/density at planar surface
  // for compressible fluids with Swift free-energy interactions:
  // expressed for bottom wall (PPST)
    
  double rho, phi, omegat, pb, mu, lambda, d2rdx2, d2rdy2, d2rdz2, d2rdxdy, d2rdxdz, d2rdydz, nabrp, rhop, phip, v0t, v2t, v1, v;
  double c0=1.0/3.0,c1=1.0/6.0,c3=1.0/24.0;
  vel = 0.0;

  rho = p[0];
  v = p[0]-(f0[0]+f2[0]+f6[0]+2*(f3[0]+f4[0]+f5[0]));
  vel = (v+0.5*force[1])*fReciprocal(rho);
  v1 = vel;
  if(lbsy.nf>1) {
    phi = p[1];
    omegat = 0.5*(1.0+phi)*omega[0]+0.5*(1.0-phi)*omega[1];
    mu = lbfemob*fGetPotentialSwift(phi, nabp);
    d2rdx2 = (lbfeeos>0)?(drdx*drdx):0.0 + dpdx*dpdx;
    d2rdy2 = (lbfeeos>0)?(drdy*drdy):0.0 + dpdy*dpdy;
    d2rdz2 = (lbfeeos>0)?(drdz*drdz):0.0 + dpdz*dpdz;
    d2rdxdy = (lbfeeos>0)?(drdx*drdy):0.0 + dpdx*dpdy;
    d2rdxdz = (lbfeeos>0)?(drdx*drdz):0.0 + dpdx*dpdz;
    d2rdydz = (lbfeeos>0)?(drdy*drdz):0.0 + dpdy*dpdz;
    nabrp = (lbfeeos>0)?(rho*nabr):0.0 + phi*nabp;
    if(fCppAbs(v1)>0.0)
      phip = (2.0*(phi-f0[1]-f1[1]-f2[1]-f3[1]-f4[1]-f5[1]-f8[1]-f10[1]-f13[1]-f14[1])-mu)/(v1*(1.0+v1));
    else
      phip = phi;
    f6[1]=c3*(phip*v1*(v1+1.0)+mu);
    f7[1]=c3*(phip*v1*(v1+1.0)+mu);
    f8[1]=c0*(phip*v1*(1.0+v1)+mu);
    f11[1]=c3*(phip*v1*(v1+1.0)+mu);
    f12[1]=c3*(phip*v1*(v1+1.0)+mu);
  }
  else {
    phi = 0.0;
    omegat = omega[0];
    d2rdx2 = drdx*drdx;
    d2rdy2 = drdy*drdy;
    d2rdz2 = drdz*drdz;
    d2rdxdy = drdx*drdy;
    d2rdxdz = drdx*drdz;
    d2rdydz = drdy*drdz;
    nabrp = rho*nabr;
  }
  pb = fGetBulkPressureSwift(rho, phi, T);
  lambda = fGetLambdaSwift(rho, omegat, T);
  rhop = (2.0*(v+f2[0]+f4[0]+f5[0]+f13[0]+f14[0])-pb+lbkappa*(nabrp+d2rdx2+d2rdz2)-3.0*lambda*v1*drdy)*fReciprocal(v1*(1.0+v1));
  if(rhop<lbevaplim)
    rhop = rho;
  v0t = (6.0*(f1[0]+f4[0]+f5[0]-f8[0]-f13[0]-f14[0])-3.0*force[0]-3.0*lambda*v1*drdx-3.0*lbkappa*d2rdxdy)/(rhop*(1.0+3.0*v1));
  v2t = (6.0*(f3[0]+f4[0]-f5[0]-f10[0]-f13[0]+f14[0])-3.0*force[2]-3.0*lambda*v1*drdz-3.0*lbkappa*d2rdydz)/(rhop*(1.0+3.0*v1));
  f6[0]=c3*rhop*(v0t*(v0t-1.0)+v1*(v1+1.0)+v2t*(v2t-1.0))-0.125*rhop*(v0t*v1-v0t*v2t+v1*v2t)
       +lambda*(5.0*c3*v1*drdy+0.125*v1*(drdx+drdz))+c3*(pb-lbkappa*nabrp)
       -lbkappa*(c3*(d2rdx2+d2rdy2+d2rdz2)-0.125*(d2rdxdy-d2rdxdz+d2rdydz));
  f7[0]=c3*rhop*(v0t*(v0t-1.0)+v1*(v1+1.0)+v2t*(v2t+1.0))-0.125*rhop*(v0t*v1+v0t*v2t-v1*v2t)
       +lambda*(5.0*c3*v1*drdy-0.125*v1*(drdx-drdz))+c3*(pb-lbkappa*nabrp)
       -lbkappa*(c3*(d2rdx2+d2rdy2+d2rdz2)-0.125*(d2rdxdy+d2rdxdz-d2rdydz));
  f9[0]=rhop*(c0*v1*(v1+1.0)-c1*(v0t*v0t+v2t*v2t))+3.0*c0*lambda*v1*drdy+c0*(pb-lbkappa*nabrp)
       -lbkappa*(c0*d2rdx2-c1*d2rdy2+c0*d2rdz2);
  f11[0]=c3*rhop*(v0t*(v0t+1.0)+v1*(v1+1.0)+v2t*(v2t+1.0))+0.125*rhop*(v0t*v1+v0t*v2t+v1*v2t)
        +lambda*(5.0*c3*v1*drdy+0.125*v1*(drdx+drdz))+c3*(pb-lbkappa*nabrp)
        -lbkappa*(c3*(d2rdx2+d2rdy2+d2rdz2)+0.125*(d2rdxdy+d2rdxdz+d2rdydz));
  f12[0]=c3*rhop*(v0t*(v0t+1.0)+v1*(v1+1.0)+v2t*(v2t-1.0))+0.125*rhop*(v0t*v1-v0t*v2t-v1*v2t)
        +lambda*(5.0*c3*v1*drdy+0.125*v1*(drdx-drdz))+c3*(pb-lbkappa*nabrp)
        -lbkappa*(c3*(d2rdx2+d2rdy2+d2rdz2)+0.125*(d2rdxdy-d2rdxdz-d2rdydz));
  return 0;
}

int fD3Q15PFInamuro(long tpos, int prop, double *p0, double *uwall, double T)
{
  double moment;
  double drdx, drdy, drdz, dpdx, dpdy, dpdz, nabr, nabp;
  long spos=tpos * lbsitelength;
  int qdim = lbsy.nf+lbsy.nc+lbsy.nt;
  double force[3*lbsy.nf];

  fD3Q15BoundaryForceDensity(force, tpos, p0, prop);
    
  if(interact==20) {
    drdx = lbft[4*lbsy.nf*tpos  ];
    drdy = lbft[4*lbsy.nf*tpos+1];
    drdz = lbft[4*lbsy.nf*tpos+2];
    nabr = lbft[4*lbsy.nf*tpos+3];
    dpdx = (lbsy.nf>1)?lbft[4*lbsy.nf*tpos+4]:0.0;
    dpdy = (lbsy.nf>1)?lbft[4*lbsy.nf*tpos+5]:0.0;
    dpdz = (lbsy.nf>1)?lbft[4*lbsy.nf*tpos+6]:0.0;
    nabp = (lbsy.nf>1)?lbft[4*lbsy.nf*tpos+7]:0.0;
    switch (prop) {
      case PST:
        fD3Q15PPSSwiftInamuro(p0, &force[0], &lbf[spos], &lbf[spos+1*qdim],
                              &lbf[spos+2*qdim], &lbf[spos+3*qdim], &lbf[spos+4*qdim], &lbf[spos+5*qdim],
                              &lbf[spos+6*qdim], &lbf[spos+7*qdim], &lbf[spos+8*qdim], &lbf[spos+9*qdim],
                              &lbf[spos+10*qdim], &lbf[spos+11*qdim], &lbf[spos+12*qdim], &lbf[spos+13*qdim],
                              &lbf[spos+14*qdim], drdx, drdy, drdz, dpdx, dpdy, dpdz, nabr, nabp,
                              &lbomega[lbsy.nf*tpos], T, moment);
        uwall[1] += moment;
        break;
      case PSD:
        fD3Q15PPSSwiftInamuro(p0, &force[0], &lbf[spos], &lbf[spos+8*qdim],
                              &lbf[spos+9*qdim], &lbf[spos+10*qdim], &lbf[spos+11*qdim], &lbf[spos+12*qdim],
                              &lbf[spos+13*qdim], &lbf[spos+14*qdim], &lbf[spos+1*qdim], &lbf[spos+2*qdim],
                              &lbf[spos+3*qdim], &lbf[spos+4*qdim], &lbf[spos+5*qdim], &lbf[spos+6*qdim],
                              &lbf[spos+7*qdim], -drdx, -drdy, -drdz, -dpdx, -dpdy, -dpdz, nabr, nabp,
                              &lbomega[lbsy.nf*tpos], T, moment);
        uwall[1] -= moment;
        break;
      case PSL:
        fD3Q15PPSSwiftInamuro(p0, &force[0], &lbf[spos], &lbf[spos+10*qdim],
                              &lbf[spos+8*qdim], &lbf[spos+9*qdim], &lbf[spos+11*qdim], &lbf[spos+13*qdim],
                              &lbf[spos+7*qdim], &lbf[spos+5*qdim], &lbf[spos+3*qdim], &lbf[spos+1*qdim],
                              &lbf[spos+2*qdim], &lbf[spos+4*qdim], &lbf[spos+6*qdim], &lbf[spos+14*qdim],
                              &lbf[spos+12*qdim], -drdz, -drdx, -drdy, -dpdz, -dpdx, -dpdy, nabr, nabp,
                              &lbomega[lbsy.nf*tpos], T, moment);
        uwall[0] -= moment;
        break;
      case PSR:
        fD3Q15PPSSwiftInamuro(p0, &force[0], &lbf[spos], &lbf[spos+3*qdim],
                              &lbf[spos+1*qdim], &lbf[spos+2*qdim], &lbf[spos+4*qdim], &lbf[spos+6*qdim],
                              &lbf[spos+14*qdim], &lbf[spos+12*qdim], &lbf[spos+10*qdim], &lbf[spos+8*qdim],
                              &lbf[spos+9*qdim], &lbf[spos+11*qdim], &lbf[spos+13*qdim], &lbf[spos+7*qdim],
                              &lbf[spos+5*qdim], drdz, drdx, drdy, dpdz, dpdx, dpdy, nabr, nabp,
                              &lbomega[lbsy.nf*tpos], T, moment);
        uwall[1] += moment;
        break;
      case PSF:
        fD3Q15PPSSwiftInamuro(p0, &force[0], &lbf[spos], &lbf[spos+9*qdim],
                              &lbf[spos+10*qdim], &lbf[spos+8*qdim], &lbf[spos+11*qdim], &lbf[spos+7*qdim],
                              &lbf[spos+12*qdim], &lbf[spos+6*qdim], &lbf[spos+2*qdim], &lbf[spos+3*qdim],
                              &lbf[spos+1*qdim], &lbf[spos+4*qdim], &lbf[spos+14*qdim], &lbf[spos+5*qdim],
                              &lbf[spos+13*qdim], -drdy, -drdz, -drdx, -dpdy, -dpdz, -dpdx, nabr, nabp,
                              &lbomega[lbsy.nf*tpos], T, moment);
        uwall[2] -= moment;
        break;
      case PSB:
        fD3Q15PPSSwiftInamuro(p0, &force[0], &lbf[spos], &lbf[spos+2*qdim],
                              &lbf[spos+3*qdim], &lbf[spos+1*qdim], &lbf[spos+4*qdim], &lbf[spos+14*qdim],
                              &lbf[spos+5*qdim], &lbf[spos+13*qdim], &lbf[spos+9*qdim], &lbf[spos+10*qdim],
                              &lbf[spos+8*qdim], &lbf[spos+11*qdim], &lbf[spos+7*qdim], &lbf[spos+12*qdim],
                              &lbf[spos+6*qdim], drdy, drdz, drdx, dpdy, dpdz, dpdx, nabr, nabp,
                              &lbomega[lbsy.nf*tpos], T, moment);
        uwall[2] += moment;
        break;
      case CCTRB:
        fD3Q15VCCSwiftInamuro(p0, uwall[0], uwall[1], -uwall[2], &force[0], &lbf[spos], &lbf[spos+1*qdim],
                              &lbf[spos+2*qdim], &lbf[spos+10*qdim], &lbf[spos+5*qdim], &lbf[spos+4*qdim],
                              &lbf[spos+7*qdim], &lbf[spos+6*qdim], &lbf[spos+8*qdim], &lbf[spos+9*qdim],
                              &lbf[spos+3*qdim], &lbf[spos+12*qdim], &lbf[spos+11*qdim], &lbf[spos+14*qdim],
                              &lbf[spos+13*qdim], drdx, drdy, -drdz, dpdx, dpdy, -dpdz, nabr, nabp,
                              &lbomega[lbsy.nf*tpos], T);
        break;
      case CCTLB:
        fD3Q15VCCSwiftInamuro(p0, -uwall[0], uwall[1], -uwall[2], &force[0], &lbf[spos], &lbf[spos+8*qdim],
                              &lbf[spos+2*qdim], &lbf[spos+10*qdim], &lbf[spos+13*qdim], &lbf[spos+14*qdim],
                              &lbf[spos+11*qdim], &lbf[spos+12*qdim], &lbf[spos+1*qdim], &lbf[spos+9*qdim],
                              &lbf[spos+3*qdim], &lbf[spos+6*qdim], &lbf[spos+7*qdim], &lbf[spos+4*qdim],
                              &lbf[spos+5*qdim], -drdx, drdy, -drdz, -dpdx, dpdy, -dpdz, nabr, nabp,
                              &lbomega[lbsy.nf*tpos], T);
        break;
      case CCDLB:
        fD3Q15VCCSwiftInamuro(p0, -uwall[0], -uwall[1], -uwall[2], &force[0], &lbf[spos], &lbf[spos+8*qdim],
                              &lbf[spos+9*qdim], &lbf[spos+10*qdim], &lbf[spos+11*qdim], &lbf[spos+12*qdim],
                              &lbf[spos+13*qdim], &lbf[spos+14*qdim], &lbf[spos+1*qdim], &lbf[spos+2*qdim],
                              &lbf[spos+3*qdim], &lbf[spos+4*qdim], &lbf[spos+5*qdim], &lbf[spos+6*qdim],
                              &lbf[spos+7*qdim], -drdx, -drdy, -drdz, -dpdx, -dpdy, -dpdz, nabr, nabp,
                              &lbomega[lbsy.nf*tpos], T);
        break;
      case CCDRB:
        fD3Q15VCCSwiftInamuro(p0, uwall[0], -uwall[1], -uwall[2], &force[0], &lbf[spos], &lbf[spos+1*qdim],
                              &lbf[spos+9*qdim], &lbf[spos+10*qdim], &lbf[spos+7*qdim], &lbf[spos+6*qdim],
                              &lbf[spos+5*qdim], &lbf[spos+4*qdim], &lbf[spos+8*qdim], &lbf[spos+2*qdim],
                              &lbf[spos+3*qdim], &lbf[spos+14*qdim], &lbf[spos+13*qdim], &lbf[spos+12*qdim],
                              &lbf[spos+11*qdim], drdx, -drdy, -drdz, dpdx, -dpdy, -dpdz, nabr, nabp,
                              &lbomega[lbsy.nf*tpos], T);
        break;
      case CCTRF:
        fD3Q15VCCSwiftInamuro(p0, uwall[0], uwall[1], uwall[2], &force[0], &lbf[spos], &lbf[spos+1*qdim],
                              &lbf[spos+2*qdim], &lbf[spos+3*qdim], &lbf[spos+4*qdim], &lbf[spos+5*qdim],
                              &lbf[spos+6*qdim], &lbf[spos+7*qdim], &lbf[spos+8*qdim], &lbf[spos+9*qdim],
                              &lbf[spos+10*qdim], &lbf[spos+11*qdim], &lbf[spos+12*qdim], &lbf[spos+13*qdim],
                              &lbf[spos+14*qdim], drdx, drdy, drdz, dpdx, dpdy, dpdz, nabr, nabp,
                              &lbomega[lbsy.nf*tpos], T);
        break;
      case CCTLF:
        fD3Q15VCCSwiftInamuro(p0, -uwall[0], uwall[1], uwall[2], &force[0], &lbf[spos], &lbf[spos+8*qdim],
                              &lbf[spos+2*qdim], &lbf[spos+3*qdim], &lbf[spos+14*qdim], &lbf[spos+13*qdim],
                              &lbf[spos+12*qdim], &lbf[spos+11*qdim], &lbf[spos+1*qdim], &lbf[spos+9*qdim],
                              &lbf[spos+10*qdim], &lbf[spos+7*qdim], &lbf[spos+6*qdim], &lbf[spos+5*qdim],
                              &lbf[spos+4*qdim], -drdx, drdy, drdz, -dpdx, dpdy, dpdz, nabr, nabp,
                              &lbomega[lbsy.nf*tpos], T);
        break;
      case CCDLF:
        fD3Q15VCCSwiftInamuro(p0, -uwall[0], -uwall[1], uwall[2], &force[0], &lbf[spos], &lbf[spos+8*qdim],
                              &lbf[spos+9*qdim], &lbf[spos+3*qdim], &lbf[spos+12*qdim], &lbf[spos+11*qdim],
                              &lbf[spos+14*qdim], &lbf[spos+13*qdim], &lbf[spos+1*qdim], &lbf[spos+2*qdim],
                              &lbf[spos+10*qdim], &lbf[spos+5*qdim], &lbf[spos+4*qdim], &lbf[spos+7*qdim],
                              &lbf[spos+6*qdim], -drdx, -drdy, drdz, -dpdx, -dpdy, dpdz, nabr, nabp,
                              &lbomega[lbsy.nf*tpos], T);
        break;
      case CCDRF:
        fD3Q15VCCSwiftInamuro(p0, uwall[0], -uwall[1], uwall[2], &force[0], &lbf[spos], &lbf[spos+1*qdim],
                              &lbf[spos+9*qdim], &lbf[spos+3*qdim], &lbf[spos+6*qdim], &lbf[spos+7*qdim],
                              &lbf[spos+4*qdim], &lbf[spos+5*qdim], &lbf[spos+8*qdim], &lbf[spos+2*qdim],
                              &lbf[spos+10*qdim], &lbf[spos+13*qdim], &lbf[spos+14*qdim], &lbf[spos+11*qdim],
                              &lbf[spos+12*qdim], drdx, -drdy, drdz, dpdx, -dpdy, dpdz, nabr, nabp,
                              &lbomega[lbsy.nf*tpos], T);
        break;
      case CETR:
        fD3Q15VCESwiftInamuro(p0, uwall[0], uwall[1], uwall[2], &force[0], &lbf[spos], &lbf[spos+1*qdim],
                              &lbf[spos+2*qdim], &lbf[spos+3*qdim], &lbf[spos+4*qdim], &lbf[spos+5*qdim],
                              &lbf[spos+6*qdim], &lbf[spos+7*qdim], &lbf[spos+8*qdim], &lbf[spos+9*qdim],
                              &lbf[spos+10*qdim], &lbf[spos+11*qdim], &lbf[spos+12*qdim], &lbf[spos+13*qdim],
                              &lbf[spos+14*qdim], drdx, drdy, drdz, dpdx, dpdy, dpdz, nabr, nabp,
                              &lbomega[lbsy.nf*tpos], T);
        break;
      case CETL:
        fD3Q15VCESwiftInamuro(p0, uwall[1], -uwall[0], uwall[2], &force[0], &lbf[spos], &lbf[spos+2*qdim],
                              &lbf[spos+8*qdim], &lbf[spos+3*qdim], &lbf[spos+14*qdim], &lbf[spos+13*qdim],
                              &lbf[spos+4*qdim], &lbf[spos+5*qdim], &lbf[spos+9*qdim], &lbf[spos+1*qdim],
                              &lbf[spos+10*qdim], &lbf[spos+7*qdim], &lbf[spos+6*qdim], &lbf[spos+11*qdim],
                              &lbf[spos+12*qdim], drdy, -drdx, drdz, dpdy, -dpdx, dpdz, nabr, nabp,
                              &lbomega[lbsy.nf*tpos], T);
        break;
      case CEDL:
        fD3Q15VCESwiftInamuro(p0, -uwall[0], -uwall[1], uwall[2], &force[0], &lbf[spos], &lbf[spos+8*qdim],
                              &lbf[spos+9*qdim], &lbf[spos+3*qdim], &lbf[spos+12*qdim], &lbf[spos+11*qdim],
                              &lbf[spos+14*qdim], &lbf[spos+13*qdim], &lbf[spos+1*qdim], &lbf[spos+2*qdim],
                              &lbf[spos+10*qdim], &lbf[spos+5*qdim], &lbf[spos+4*qdim], &lbf[spos+7*qdim],
                              &lbf[spos+6*qdim], -drdx, -drdy, drdz, -dpdx, -dpdy, dpdz, nabr, nabp,
                              &lbomega[lbsy.nf*tpos], T);
        break;
      case CEDR:
        fD3Q15VCESwiftInamuro(p0, -uwall[1], uwall[0], uwall[2], &force[0], &lbf[spos], &lbf[spos+9*qdim],
                              &lbf[spos+1*qdim], &lbf[spos+3*qdim], &lbf[spos+6*qdim], &lbf[spos+7*qdim],
                              &lbf[spos+12*qdim], &lbf[spos+11*qdim], &lbf[spos+2*qdim], &lbf[spos+8*qdim],
                              &lbf[spos+10*qdim], &lbf[spos+13*qdim], &lbf[spos+14*qdim], &lbf[spos+5*qdim],
                              &lbf[spos+4*qdim], -drdy, drdx, drdz, -dpdy, dpdx, dpdz, nabr, nabp,
                              &lbomega[lbsy.nf*tpos], T);
        break;
      case CETF:
        fD3Q15VCESwiftInamuro(p0, uwall[1], uwall[2], uwall[0], &force[0], &lbf[spos], &lbf[spos+2*qdim],
                              &lbf[spos+3*qdim], &lbf[spos+1*qdim], &lbf[spos+4*qdim], &lbf[spos+14*qdim],
                              &lbf[spos+5*qdim], &lbf[spos+13*qdim], &lbf[spos+9*qdim], &lbf[spos+10*qdim],
                              &lbf[spos+8*qdim], &lbf[spos+11*qdim], &lbf[spos+7*qdim], &lbf[spos+12*qdim],
                              &lbf[spos+6*qdim], drdy, drdz, drdx, dpdy, dpdz, dpdx, nabr, nabp,
                              &lbomega[lbsy.nf*tpos], T);
        break;
      case CELF:
        fD3Q15VCESwiftInamuro(p0, -uwall[0], uwall[2], uwall[1], &force[0], &lbf[spos], &lbf[spos+8*qdim],
                              &lbf[spos+3*qdim], &lbf[spos+2*qdim], &lbf[spos+14*qdim], &lbf[spos+12*qdim],
                              &lbf[spos+13*qdim], &lbf[spos+11*qdim], &lbf[spos+1*qdim], &lbf[spos+10*qdim],
                              &lbf[spos+9*qdim], &lbf[spos+7*qdim], &lbf[spos+5*qdim], &lbf[spos+6*qdim],
                              &lbf[spos+4*qdim], -drdx, drdz, drdy, -dpdx, dpdz, dpdy, nabr, nabp,
                              &lbomega[lbsy.nf*tpos], T);
        break;
      case CEDF:
        fD3Q15VCESwiftInamuro(p0, -uwall[1], uwall[2], uwall[0], &force[0], &lbf[spos], &lbf[spos+9*qdim],
                              &lbf[spos+3*qdim], &lbf[spos+1*qdim], &lbf[spos+6*qdim], &lbf[spos+12*qdim],
                              &lbf[spos+7*qdim], &lbf[spos+11*qdim], &lbf[spos+2*qdim], &lbf[spos+10*qdim],
                              &lbf[spos+8*qdim], &lbf[spos+13*qdim], &lbf[spos+5*qdim], &lbf[spos+14*qdim],
                              &lbf[spos+4*qdim], -drdy, drdz, drdx, -dpdy, dpdz, dpdx, nabr, nabp,
                              &lbomega[lbsy.nf*tpos], T);
        break;
      case CERF:
        fD3Q15VCESwiftInamuro(p0, uwall[0], uwall[2], uwall[1], &force[0], &lbf[spos], &lbf[spos+1*qdim],
                              &lbf[spos+3*qdim], &lbf[spos+2*qdim], &lbf[spos+4*qdim], &lbf[spos+6*qdim],
                              &lbf[spos+5*qdim], &lbf[spos+7*qdim], &lbf[spos+8*qdim], &lbf[spos+10*qdim],
                              &lbf[spos+9*qdim], &lbf[spos+11*qdim], &lbf[spos+13*qdim], &lbf[spos+12*qdim],
                              &lbf[spos+14*qdim], drdx, drdz, drdy, dpdx, dpdz, dpdy, nabr, nabp,
                              &lbomega[lbsy.nf*tpos], T);
        break;
      case CETB:
        fD3Q15VCESwiftInamuro(p0, uwall[1], -uwall[2], uwall[0], &force[0], &lbf[spos], &lbf[spos+2*qdim],
                              &lbf[spos+10*qdim], &lbf[spos+1*qdim], &lbf[spos+5*qdim], &lbf[spos+13*qdim],
                              &lbf[spos+4*qdim], &lbf[spos+14*qdim], &lbf[spos+9*qdim], &lbf[spos+3*qdim],
                              &lbf[spos+8*qdim], &lbf[spos+12*qdim], &lbf[spos+6*qdim], &lbf[spos+11*qdim],
                              &lbf[spos+7*qdim], drdy, -drdz, drdx, dpdy, -dpdz, dpdx, nabr, nabp,
                              &lbomega[lbsy.nf*tpos], T);
        break;
      case CELB:
        fD3Q15VCESwiftInamuro(p0, -uwall[0], -uwall[2], uwall[1], &force[0], &lbf[spos], &lbf[spos+8*qdim],
                              &lbf[spos+10*qdim], &lbf[spos+2*qdim], &lbf[spos+13*qdim], &lbf[spos+11*qdim],
                              &lbf[spos+14*qdim], &lbf[spos+12*qdim], &lbf[spos+1*qdim], &lbf[spos+3*qdim],
                              &lbf[spos+9*qdim], &lbf[spos+6*qdim], &lbf[spos+4*qdim], &lbf[spos+7*qdim],
                              &lbf[spos+5*qdim], -drdx, -drdz, drdy, -dpdx, -dpdz, dpdy, nabr, nabp,
                              &lbomega[lbsy.nf*tpos], T);
        break;
      case CEDB:
        fD3Q15VCESwiftInamuro(p0, -uwall[1], -uwall[2], uwall[0], &force[0], &lbf[spos], &lbf[spos+9*qdim],
                              &lbf[spos+10*qdim], &lbf[spos+1*qdim], &lbf[spos+7*qdim], &lbf[spos+11*qdim],
                              &lbf[spos+6*qdim], &lbf[spos+12*qdim], &lbf[spos+2*qdim], &lbf[spos+3*qdim],
                              &lbf[spos+8*qdim], &lbf[spos+14*qdim], &lbf[spos+4*qdim], &lbf[spos+13*qdim],
                              &lbf[spos+5*qdim], -drdy, -drdz, drdx, -dpdy, -dpdz, dpdx, nabr, nabp,
                              &lbomega[lbsy.nf*tpos], T);
        break;
      case CERB:
        fD3Q15VCESwiftInamuro(p0, uwall[0], -uwall[2], uwall[1], &force[0], &lbf[spos], &lbf[spos+1*qdim],
                              &lbf[spos+10*qdim], &lbf[spos+2*qdim], &lbf[spos+5*qdim], &lbf[spos+7*qdim],
                              &lbf[spos+4*qdim], &lbf[spos+6*qdim], &lbf[spos+8*qdim], &lbf[spos+3*qdim],
                              &lbf[spos+9*qdim], &lbf[spos+12*qdim], &lbf[spos+14*qdim], &lbf[spos+11*qdim],
                              &lbf[spos+13*qdim], drdx, -drdz, drdy, dpdx, -dpdz, dpdy, nabr, nabp,
                              &lbomega[lbsy.nf*tpos], T);
        break;
    }
  }
  else {
    switch (prop) {
      case PST:
        fD3Q15PPSInamuro(p0, &force[0], &lbf[spos], &lbf[spos+1*qdim],
                         &lbf[spos+2*qdim], &lbf[spos+3*qdim], &lbf[spos+4*qdim], &lbf[spos+5*qdim],
                         &lbf[spos+6*qdim], &lbf[spos+7*qdim], &lbf[spos+8*qdim], &lbf[spos+9*qdim],
                         &lbf[spos+10*qdim], &lbf[spos+11*qdim], &lbf[spos+12*qdim], &lbf[spos+13*qdim],
                         &lbf[spos+14*qdim], moment);
        uwall[1] += moment;
        break;
      case PSD:
        fD3Q15PPSInamuro(p0, &force[0], &lbf[spos], &lbf[spos+8*qdim],
                         &lbf[spos+9*qdim], &lbf[spos+10*qdim], &lbf[spos+11*qdim], &lbf[spos+12*qdim],
                         &lbf[spos+13*qdim], &lbf[spos+14*qdim], &lbf[spos+1*qdim], &lbf[spos+2*qdim],
                         &lbf[spos+3*qdim], &lbf[spos+4*qdim], &lbf[spos+5*qdim], &lbf[spos+6*qdim],
                         &lbf[spos+7*qdim], moment);
        uwall[1] -= moment;
        break;
      case PSL:
        fD3Q15PPSInamuro(p0, &force[0], &lbf[spos], &lbf[spos+10*qdim],
                         &lbf[spos+8*qdim], &lbf[spos+9*qdim], &lbf[spos+11*qdim], &lbf[spos+13*qdim],
                         &lbf[spos+7*qdim], &lbf[spos+5*qdim], &lbf[spos+3*qdim], &lbf[spos+1*qdim],
                         &lbf[spos+2*qdim], &lbf[spos+4*qdim], &lbf[spos+6*qdim], &lbf[spos+14*qdim],
                         &lbf[spos+12*qdim], moment);
        uwall[0] -= moment;
        break;
      case PSR:
        fD3Q15PPSInamuro(p0, &force[0], &lbf[spos], &lbf[spos+3*qdim],
                         &lbf[spos+1*qdim], &lbf[spos+2*qdim], &lbf[spos+4*qdim], &lbf[spos+6*qdim],
                         &lbf[spos+14*qdim], &lbf[spos+12*qdim], &lbf[spos+10*qdim], &lbf[spos+8*qdim],
                         &lbf[spos+9*qdim], &lbf[spos+11*qdim], &lbf[spos+13*qdim], &lbf[spos+7*qdim],
                         &lbf[spos+5*qdim], moment);
        uwall[1] += moment;
        break;
      case PSF:
        fD3Q15PPSInamuro(p0, &force[0], &lbf[spos], &lbf[spos+9*qdim],
                         &lbf[spos+10*qdim], &lbf[spos+8*qdim], &lbf[spos+11*qdim], &lbf[spos+7*qdim],
                         &lbf[spos+12*qdim], &lbf[spos+6*qdim], &lbf[spos+2*qdim], &lbf[spos+3*qdim],
                         &lbf[spos+1*qdim], &lbf[spos+4*qdim], &lbf[spos+14*qdim], &lbf[spos+5*qdim],
                         &lbf[spos+13*qdim], moment);
        uwall[2] -= moment;
        break;
      case PSB:
        fD3Q15PPSInamuro(p0, &force[0], &lbf[spos], &lbf[spos+2*qdim],
                         &lbf[spos+3*qdim], &lbf[spos+1*qdim], &lbf[spos+4*qdim], &lbf[spos+14*qdim],
                         &lbf[spos+5*qdim], &lbf[spos+13*qdim], &lbf[spos+9*qdim], &lbf[spos+10*qdim],
                         &lbf[spos+8*qdim], &lbf[spos+11*qdim], &lbf[spos+7*qdim], &lbf[spos+12*qdim],
                         &lbf[spos+6*qdim], moment);
        uwall[2] += moment;
        break;
      case CCTRB:
        fD3Q15VCCInamuro(p0, uwall[0], uwall[1], -uwall[2], &force[0], &lbf[spos], &lbf[spos+1*qdim],
                         &lbf[spos+2*qdim], &lbf[spos+10*qdim], &lbf[spos+5*qdim], &lbf[spos+4*qdim],
                         &lbf[spos+7*qdim], &lbf[spos+6*qdim], &lbf[spos+8*qdim], &lbf[spos+9*qdim],
                         &lbf[spos+3*qdim], &lbf[spos+12*qdim], &lbf[spos+11*qdim], &lbf[spos+14*qdim],
                         &lbf[spos+13*qdim]);
        break;
      case CCTLB:
        fD3Q15VCCInamuro(p0, -uwall[0], uwall[1], -uwall[2], &force[0], &lbf[spos], &lbf[spos+8*qdim],
                         &lbf[spos+2*qdim], &lbf[spos+10*qdim], &lbf[spos+13*qdim], &lbf[spos+14*qdim],
                         &lbf[spos+11*qdim], &lbf[spos+12*qdim], &lbf[spos+1*qdim], &lbf[spos+9*qdim],
                         &lbf[spos+3*qdim], &lbf[spos+6*qdim], &lbf[spos+7*qdim], &lbf[spos+4*qdim],
                         &lbf[spos+5*qdim]);
        break;
      case CCDLB:
        fD3Q15VCCInamuro(p0, -uwall[0], -uwall[1], -uwall[2], &force[0], &lbf[spos], &lbf[spos+8*qdim],
                         &lbf[spos+9*qdim], &lbf[spos+10*qdim], &lbf[spos+11*qdim], &lbf[spos+12*qdim],
                         &lbf[spos+13*qdim], &lbf[spos+14*qdim], &lbf[spos+1*qdim], &lbf[spos+2*qdim],
                         &lbf[spos+3*qdim], &lbf[spos+4*qdim], &lbf[spos+5*qdim], &lbf[spos+6*qdim],
                         &lbf[spos+7*qdim]);
        break;
      case CCDRB:
        fD3Q15VCCInamuro(p0, uwall[0], -uwall[1], -uwall[2], &force[0], &lbf[spos], &lbf[spos+1*qdim],
                         &lbf[spos+9*qdim], &lbf[spos+10*qdim], &lbf[spos+7*qdim], &lbf[spos+6*qdim],
                         &lbf[spos+5*qdim], &lbf[spos+4*qdim], &lbf[spos+8*qdim], &lbf[spos+2*qdim],
                         &lbf[spos+3*qdim], &lbf[spos+14*qdim], &lbf[spos+13*qdim], &lbf[spos+12*qdim],
                         &lbf[spos+11*qdim]);
        break;
      case CCTRF:
        fD3Q15VCCInamuro(p0, uwall[0], uwall[1], uwall[2], &force[0], &lbf[spos], &lbf[spos+1*qdim],
                         &lbf[spos+2*qdim], &lbf[spos+3*qdim], &lbf[spos+4*qdim], &lbf[spos+5*qdim],
                         &lbf[spos+6*qdim], &lbf[spos+7*qdim], &lbf[spos+8*qdim], &lbf[spos+9*qdim],
                         &lbf[spos+10*qdim], &lbf[spos+11*qdim], &lbf[spos+12*qdim], &lbf[spos+13*qdim],
                         &lbf[spos+14*qdim]);
        break;
      case CCTLF:
        fD3Q15VCCInamuro(p0, -uwall[0], uwall[1], uwall[2], &force[0], &lbf[spos], &lbf[spos+8*qdim],
                         &lbf[spos+2*qdim], &lbf[spos+3*qdim], &lbf[spos+14*qdim], &lbf[spos+13*qdim],
                         &lbf[spos+12*qdim], &lbf[spos+11*qdim], &lbf[spos+1*qdim], &lbf[spos+9*qdim],
                         &lbf[spos+10*qdim], &lbf[spos+7*qdim], &lbf[spos+6*qdim], &lbf[spos+5*qdim],
                         &lbf[spos+4*qdim]);
        break;
      case CCDLF:
        fD3Q15VCCInamuro(p0, -uwall[0], -uwall[1], uwall[2], &force[0], &lbf[spos], &lbf[spos+8*qdim],
                         &lbf[spos+9*qdim], &lbf[spos+3*qdim], &lbf[spos+12*qdim], &lbf[spos+11*qdim],
                         &lbf[spos+14*qdim], &lbf[spos+13*qdim], &lbf[spos+1*qdim], &lbf[spos+2*qdim],
                         &lbf[spos+10*qdim], &lbf[spos+5*qdim], &lbf[spos+4*qdim], &lbf[spos+7*qdim],
                         &lbf[spos+6*qdim]);
        break;
      case CCDRF:
        fD3Q15VCCInamuro(p0, uwall[0], -uwall[1], uwall[2], &force[0], &lbf[spos], &lbf[spos+1*qdim],
                         &lbf[spos+9*qdim], &lbf[spos+3*qdim], &lbf[spos+6*qdim], &lbf[spos+7*qdim],
                         &lbf[spos+4*qdim], &lbf[spos+5*qdim], &lbf[spos+8*qdim], &lbf[spos+2*qdim],
                         &lbf[spos+10*qdim], &lbf[spos+13*qdim], &lbf[spos+14*qdim], &lbf[spos+11*qdim],
                         &lbf[spos+12*qdim]);
        break;
      case CETR:
        fD3Q15VCEInamuro(p0, uwall[0], uwall[1], uwall[2], &force[0], &lbf[spos], &lbf[spos+1*qdim],
                         &lbf[spos+2*qdim], &lbf[spos+3*qdim], &lbf[spos+4*qdim], &lbf[spos+5*qdim],
                         &lbf[spos+6*qdim], &lbf[spos+7*qdim], &lbf[spos+8*qdim], &lbf[spos+9*qdim],
                         &lbf[spos+10*qdim], &lbf[spos+11*qdim], &lbf[spos+12*qdim], &lbf[spos+13*qdim],
                         &lbf[spos+14*qdim]);
        break;
      case CETL:
        fD3Q15VCEInamuro(p0, uwall[1], -uwall[0], uwall[2], &force[0], &lbf[spos], &lbf[spos+2*qdim],
                         &lbf[spos+8*qdim], &lbf[spos+3*qdim], &lbf[spos+14*qdim], &lbf[spos+13*qdim],
                         &lbf[spos+4*qdim], &lbf[spos+5*qdim], &lbf[spos+9*qdim], &lbf[spos+1*qdim],
                         &lbf[spos+10*qdim], &lbf[spos+7*qdim], &lbf[spos+6*qdim], &lbf[spos+11*qdim],
                         &lbf[spos+12*qdim]);
        break;
      case CEDL:
        fD3Q15VCEInamuro(p0, -uwall[0], -uwall[1], uwall[2], &force[0], &lbf[spos], &lbf[spos+8*qdim],
                         &lbf[spos+9*qdim], &lbf[spos+3*qdim], &lbf[spos+12*qdim], &lbf[spos+11*qdim],
                         &lbf[spos+14*qdim], &lbf[spos+13*qdim], &lbf[spos+1*qdim], &lbf[spos+2*qdim],
                         &lbf[spos+10*qdim], &lbf[spos+5*qdim], &lbf[spos+4*qdim], &lbf[spos+7*qdim],
                         &lbf[spos+6*qdim]);
        break;
      case CEDR:
        fD3Q15VCEInamuro(p0, -uwall[1], uwall[0], uwall[2], &force[0], &lbf[spos], &lbf[spos+9*qdim],
                         &lbf[spos+1*qdim], &lbf[spos+3*qdim], &lbf[spos+6*qdim], &lbf[spos+7*qdim],
                         &lbf[spos+12*qdim], &lbf[spos+11*qdim], &lbf[spos+2*qdim], &lbf[spos+8*qdim],
                         &lbf[spos+10*qdim], &lbf[spos+13*qdim], &lbf[spos+14*qdim], &lbf[spos+5*qdim],
                         &lbf[spos+4*qdim]);
        break;
      case CETF:
        fD3Q15VCEInamuro(p0, uwall[1], uwall[2], uwall[0], &force[0], &lbf[spos], &lbf[spos+2*qdim],
                         &lbf[spos+3*qdim], &lbf[spos+1*qdim], &lbf[spos+4*qdim], &lbf[spos+14*qdim],
                         &lbf[spos+5*qdim], &lbf[spos+13*qdim], &lbf[spos+9*qdim], &lbf[spos+10*qdim],
                         &lbf[spos+8*qdim], &lbf[spos+11*qdim], &lbf[spos+7*qdim], &lbf[spos+12*qdim],
                         &lbf[spos+6*qdim]);
        break;
      case CELF:
        fD3Q15VCEInamuro(p0, -uwall[0], uwall[2], uwall[1], &force[0], &lbf[spos], &lbf[spos+8*qdim],
                         &lbf[spos+3*qdim], &lbf[spos+2*qdim], &lbf[spos+14*qdim], &lbf[spos+12*qdim],
                         &lbf[spos+13*qdim], &lbf[spos+11*qdim], &lbf[spos+1*qdim], &lbf[spos+10*qdim],
                         &lbf[spos+9*qdim], &lbf[spos+7*qdim], &lbf[spos+5*qdim], &lbf[spos+6*qdim],
                         &lbf[spos+4*qdim]);
        break;
      case CEDF:
        fD3Q15VCEInamuro(p0, -uwall[1], uwall[2], uwall[0], &force[0], &lbf[spos], &lbf[spos+9*qdim],
                         &lbf[spos+3*qdim], &lbf[spos+1*qdim], &lbf[spos+6*qdim], &lbf[spos+12*qdim],
                         &lbf[spos+7*qdim], &lbf[spos+11*qdim], &lbf[spos+2*qdim], &lbf[spos+10*qdim],
                         &lbf[spos+8*qdim], &lbf[spos+13*qdim], &lbf[spos+5*qdim], &lbf[spos+14*qdim],
                         &lbf[spos+4*qdim]);
        break;
      case CERF:
        fD3Q15VCEInamuro(p0, uwall[0], uwall[2], uwall[1], &force[0], &lbf[spos], &lbf[spos+1*qdim],
                         &lbf[spos+3*qdim], &lbf[spos+2*qdim], &lbf[spos+4*qdim], &lbf[spos+6*qdim],
                         &lbf[spos+5*qdim], &lbf[spos+7*qdim], &lbf[spos+8*qdim], &lbf[spos+10*qdim],
                         &lbf[spos+9*qdim], &lbf[spos+11*qdim], &lbf[spos+13*qdim], &lbf[spos+12*qdim],
                         &lbf[spos+14*qdim]);
        break;
      case CETB:
        fD3Q15VCEInamuro(p0, uwall[1], -uwall[2], uwall[0], &force[0], &lbf[spos], &lbf[spos+2*qdim],
                         &lbf[spos+10*qdim], &lbf[spos+1*qdim], &lbf[spos+5*qdim], &lbf[spos+13*qdim],
                         &lbf[spos+4*qdim], &lbf[spos+14*qdim], &lbf[spos+9*qdim], &lbf[spos+3*qdim],
                         &lbf[spos+8*qdim], &lbf[spos+12*qdim], &lbf[spos+6*qdim], &lbf[spos+11*qdim],
                         &lbf[spos+7*qdim]);
        break;
      case CELB:
        fD3Q15VCEInamuro(p0, -uwall[0], -uwall[2], uwall[1], &force[0], &lbf[spos], &lbf[spos+8*qdim],
                         &lbf[spos+10*qdim], &lbf[spos+2*qdim], &lbf[spos+13*qdim], &lbf[spos+11*qdim],
                         &lbf[spos+14*qdim], &lbf[spos+12*qdim], &lbf[spos+1*qdim], &lbf[spos+3*qdim],
                         &lbf[spos+9*qdim], &lbf[spos+6*qdim], &lbf[spos+4*qdim], &lbf[spos+7*qdim],
                         &lbf[spos+5*qdim]);
        break;
      case CEDB:
        fD3Q15VCEInamuro(p0, -uwall[1], -uwall[2], uwall[0], &force[0], &lbf[spos], &lbf[spos+9*qdim],
                         &lbf[spos+10*qdim], &lbf[spos+1*qdim], &lbf[spos+7*qdim], &lbf[spos+11*qdim],
                         &lbf[spos+6*qdim], &lbf[spos+12*qdim], &lbf[spos+2*qdim], &lbf[spos+3*qdim],
                         &lbf[spos+8*qdim], &lbf[spos+14*qdim], &lbf[spos+4*qdim], &lbf[spos+13*qdim],
                         &lbf[spos+5*qdim]);
        break;
      case CERB:
        fD3Q15VCEInamuro(p0, uwall[0], -uwall[2], uwall[1], &force[0], &lbf[spos], &lbf[spos+1*qdim],
                         &lbf[spos+10*qdim], &lbf[spos+2*qdim], &lbf[spos+5*qdim], &lbf[spos+7*qdim],
                         &lbf[spos+4*qdim], &lbf[spos+6*qdim], &lbf[spos+8*qdim], &lbf[spos+3*qdim],
                         &lbf[spos+9*qdim], &lbf[spos+12*qdim], &lbf[spos+14*qdim], &lbf[spos+11*qdim],
                         &lbf[spos+13*qdim]);
        break;
    }
  }
  return 0;
}


int fD3Q15CPSInamuro(double *p, double v0, double v1, double v2, double *f0, double *f1,
	                 double *f2, double *f3, double *f4, double *f5, double *f6,
                     double *f7, double *f8, double *f9, double *f10, double *f11,
                     double *f12, double *f13, double *f14)
{

  // produce fixed concentration at planar surface: expressed for bottom wall (CPST)

  double rhop;
  double c1=1.0/9.0,c2=1.0/72.0;

  for(int i=0; i<lbsy.nc; i++) {
    rhop=6.0*(p[i]-f0[i]-f1[i]-f2[i]-f3[i]-f4[i]-f5[i]-f8[i]-f10[i]-f13[i]-f14[i])/(1.0+3.0*v1);
    f6[i]=c2*rhop*(1.0-3.0*v0+3.0*v1-3.0*v2);
    f7[i]=c2*rhop*(1.0-3.0*v0+3.0*v1+3.0*v2);
    f9[i]=c1*rhop*(1.0+3.0*v1);
    f11[i]=c2*rhop*(1.0+3.0*v0+3.0*v1+3.0*v2);
    f12[i]=c2*rhop*(1.0+3.0*v0+3.0*v1-3.0*v2);
  }
  return 0;
}

int fD3Q15CCEInamuro(double *p, double v0, double v1, double v2, double *f0, double *f1,
	                 double *f2, double *f3, double *f4, double *f5, double *f6,
                     double *f7, double *f8, double *f9, double *f10, double *f11,
                     double *f12, double *f13, double *f14)
{

  // produce fixed concentration at concave edge: expressed for bottom-left edge (CPSTR)

  double rhop;
  double c1=1.0/9.0,c2=1.0/72.0;

  for(int i=0; i<lbsy.nc; i++) {
    rhop=36.0*(p[i]-f0[i]-f1[i]-f2[i]-f3[i]-f4[i]-f5[i]-f10[i])/(11.0+15.0*(v0+v1));
    f6[i]=c2*rhop*(1.0-3.0*v0+3.0*v1-3.0*v2);
    f7[i]=c2*rhop*(1.0-3.0*v0+3.0*v1+3.0*v2);
    f8[i]=c1*rhop*(1.0+3.0*v0);
    f9[i]=c1*rhop*(1.0+3.0*v1);
    f11[i]=c2*rhop*(1.0+3.0*v0+3.0*v1+3.0*v2);
    f12[i]=c2*rhop*(1.0+3.0*v0+3.0*v1-3.0*v2);
    f13[i]=c2*rhop*(1.0+3.0*v0-3.0*v1+3.0*v2);
    f14[i]=c2*rhop*(1.0+3.0*v0-3.0*v1-3.0*v2);
  }
  return 0;
}

int fD3Q15CCCInamuro(double *p, double v0, double v1, double v2, double *f0, double *f1,
	                 double *f2, double *f3, double *f4, double *f5, double *f6,
                     double *f7, double *f8, double *f9, double *f10, double *f11,
                     double *f12, double *f13, double *f14)
{

  // produce fixed concentration at concave corner: expressed for bottom-left-back corner (CPSTRF)

  double rhop;
  double c1=1.0/9.0,c2=1.0/72.0;

  for(int i=0; i<lbsy.nc; i++) {
    rhop=72.0*(p[i]-f0[i]-f1[i]-f2[i]-f3[i]-f4[i])/(31.0+27.0*(v0+v1+v2));
    f5[i]=c2*rhop*(1.0-3.0*v0-3.0*v1+3.0*v2);
    f6[i]=c2*rhop*(1.0-3.0*v0+3.0*v1-3.0*v2);
    f7[i]=c2*rhop*(1.0-3.0*v0+3.0*v1+3.0*v2);
    f8[i]=c1*rhop*(1.0+3.0*v0);
    f9[i]=c1*rhop*(1.0+3.0*v1);
    f10[i]=c1*rhop*(1.0+3.0*v2);
    f11[i]=c2*rhop*(1.0+3.0*v0+3.0*v1+3.0*v2);
    f12[i]=c2*rhop*(1.0+3.0*v0+3.0*v1-3.0*v2);
    f13[i]=c2*rhop*(1.0+3.0*v0-3.0*v1+3.0*v2);
    f14[i]=c2*rhop*(1.0+3.0*v0-3.0*v1-3.0*v2);
  }
  return 0;
}


int fD3Q15PCInamuro(long tpos, int prop, double *p0, double *uwall)
{
  long spos=tpos * lbsitelength + lbsy.nf;
  int qdim=lbsy.nf+lbsy.nc+lbsy.nt;
    
  switch (prop) {
    case PST:
      fD3Q15CPSInamuro(p0, uwall[0], uwall[1], uwall[2], &lbf[spos], &lbf[spos+1*qdim],
                       &lbf[spos+2*qdim], &lbf[spos+3*qdim], &lbf[spos+4*qdim], &lbf[spos+5*qdim], &lbf[spos+6*qdim],
                       &lbf[spos+7*qdim], &lbf[spos+8*qdim], &lbf[spos+9*qdim], &lbf[spos+10*qdim], &lbf[spos+11*qdim],
                       &lbf[spos+12*qdim], &lbf[spos+13*qdim], &lbf[spos+14*qdim]);
      break;
    case PSD:
      fD3Q15CPSInamuro(p0, -uwall[0], -uwall[1], -uwall[2], &lbf[spos], &lbf[spos+8*qdim],
                       &lbf[spos+9*qdim], &lbf[spos+10*qdim], &lbf[spos+11*qdim], &lbf[spos+12*qdim], &lbf[spos+13*qdim],
                       &lbf[spos+14*qdim], &lbf[spos+1*qdim], &lbf[spos+2*qdim], &lbf[spos+3*qdim], &lbf[spos+4*qdim],
                       &lbf[spos+5*qdim], &lbf[spos+6*qdim], &lbf[spos+7*qdim]);
      break;
    case PSL:
      fD3Q15CPSInamuro(p0, -uwall[2], -uwall[0], -uwall[1], &lbf[spos], &lbf[spos+10*qdim],
                       &lbf[spos+8*qdim], &lbf[spos+9*qdim], &lbf[spos+11*qdim], &lbf[spos+13*qdim], &lbf[spos+7*qdim],
                       &lbf[spos+5*qdim], &lbf[spos+3*qdim], &lbf[spos+1*qdim], &lbf[spos+2*qdim], &lbf[spos+4*qdim],
                       &lbf[spos+6*qdim], &lbf[spos+14*qdim], &lbf[spos+12*qdim]);
      break;
    case PSR:
      fD3Q15CPSInamuro(p0, uwall[2], uwall[0], uwall[1], &lbf[spos], &lbf[spos+10*qdim],
		               &lbf[spos+8*qdim], &lbf[spos+9*qdim], &lbf[spos+11*qdim], &lbf[spos+13*qdim], &lbf[spos+7*qdim],
                       &lbf[spos+5*qdim], &lbf[spos+3*qdim], &lbf[spos+1*qdim], &lbf[spos+2*qdim], &lbf[spos+4*qdim],
                       &lbf[spos+6*qdim], &lbf[spos+14*qdim], &lbf[spos+12*qdim]);
      break;
    case PSF:
      fD3Q15CPSInamuro(p0, -uwall[1], -uwall[2], -uwall[0], &lbf[spos], &lbf[spos+9*qdim],
		               &lbf[spos+10*qdim], &lbf[spos+8*qdim], &lbf[spos+11*qdim], &lbf[spos+7*qdim], &lbf[spos+12*qdim],
                       &lbf[spos+6*qdim], &lbf[spos+2*qdim], &lbf[spos+3*qdim], &lbf[spos+1*qdim], &lbf[spos+4*qdim],
                       &lbf[spos+14*qdim], &lbf[spos+5*qdim], &lbf[spos+13*qdim]);
      break;
    case PSB:
      fD3Q15CPSInamuro(p0, uwall[1], uwall[2], uwall[0], &lbf[spos], &lbf[spos+2*qdim],
		               &lbf[spos+3*qdim], &lbf[spos+1*qdim], &lbf[spos+4*qdim], &lbf[spos+14*qdim], &lbf[spos+5*qdim],
                       &lbf[spos+13*qdim], &lbf[spos+9*qdim], &lbf[spos+10*qdim], &lbf[spos+8*qdim], &lbf[spos+11*qdim],
                       &lbf[spos+7*qdim], &lbf[spos+12*qdim], &lbf[spos+6*qdim]);
      break;
    case CCTRB:
      fD3Q15CCCInamuro(p0, uwall[0], uwall[1], -uwall[2], &lbf[spos], &lbf[spos+1*qdim],
                       &lbf[spos+2*qdim], &lbf[spos+10*qdim], &lbf[spos+5*qdim], &lbf[spos+4*qdim],
                       &lbf[spos+7*qdim], &lbf[spos+6*qdim], &lbf[spos+8*qdim], &lbf[spos+9*qdim],
                       &lbf[spos+3*qdim], &lbf[spos+12*qdim], &lbf[spos+11*qdim], &lbf[spos+14*qdim],
                       &lbf[spos+13*qdim]);
      break;
    case CCTLB:
      fD3Q15CCCInamuro(p0, -uwall[0], uwall[1], -uwall[2], &lbf[spos], &lbf[spos+8*qdim],
                       &lbf[spos+2*qdim], &lbf[spos+10*qdim], &lbf[spos+13*qdim], &lbf[spos+14*qdim],
                       &lbf[spos+11*qdim], &lbf[spos+12*qdim], &lbf[spos+1*qdim], &lbf[spos+9*qdim],
                       &lbf[spos+3*qdim], &lbf[spos+6*qdim], &lbf[spos+7*qdim], &lbf[spos+4*qdim],
                       &lbf[spos+5*qdim]);
      break;
    case CCDLB:
      fD3Q15CCCInamuro(p0, -uwall[0], -uwall[1], -uwall[2], &lbf[spos], &lbf[spos+8*qdim],
                       &lbf[spos+9*qdim], &lbf[spos+10*qdim], &lbf[spos+11*qdim], &lbf[spos+12*qdim],
                       &lbf[spos+13*qdim], &lbf[spos+14*qdim], &lbf[spos+1*qdim], &lbf[spos+2*qdim],
                       &lbf[spos+3*qdim], &lbf[spos+4*qdim], &lbf[spos+5*qdim], &lbf[spos+6*qdim],
                       &lbf[spos+7*qdim]);
      break;
    case CCDRB:
      fD3Q15CCCInamuro(p0, uwall[0], -uwall[1], -uwall[2], &lbf[spos], &lbf[spos+1*qdim],
                       &lbf[spos+9*qdim], &lbf[spos+10*qdim], &lbf[spos+7*qdim], &lbf[spos+6*qdim],
                       &lbf[spos+5*qdim], &lbf[spos+4*qdim], &lbf[spos+8*qdim], &lbf[spos+2*qdim],
                       &lbf[spos+3*qdim], &lbf[spos+14*qdim], &lbf[spos+13*qdim], &lbf[spos+12*qdim],
                       &lbf[spos+11*qdim]);
      break;
    case CCTRF:
      fD3Q15CCCInamuro(p0, uwall[0], uwall[1], uwall[2], &lbf[spos], &lbf[spos+1*qdim],
                       &lbf[spos+2*qdim], &lbf[spos+3*qdim], &lbf[spos+4*qdim], &lbf[spos+5*qdim],
                       &lbf[spos+6*qdim], &lbf[spos+7*qdim], &lbf[spos+8*qdim], &lbf[spos+9*qdim],
                       &lbf[spos+10*qdim], &lbf[spos+11*qdim], &lbf[spos+12*qdim], &lbf[spos+13*qdim],
                       &lbf[spos+14*qdim]);
      break;
    case CCTLF:
      fD3Q15CCCInamuro(p0, -uwall[0], uwall[1], uwall[2], &lbf[spos], &lbf[spos+8*qdim],
                       &lbf[spos+2*qdim], &lbf[spos+3*qdim], &lbf[spos+14*qdim], &lbf[spos+13*qdim],
                       &lbf[spos+12*qdim], &lbf[spos+11*qdim], &lbf[spos+1*qdim], &lbf[spos+9*qdim],
                       &lbf[spos+10*qdim], &lbf[spos+7*qdim], &lbf[spos+6*qdim], &lbf[spos+5*qdim],
                       &lbf[spos+4*qdim]);
      break;
    case CCDLF:
      fD3Q15CCCInamuro(p0, -uwall[0], -uwall[1], uwall[2], &lbf[spos], &lbf[spos+8*qdim],
                       &lbf[spos+9*qdim], &lbf[spos+3*qdim], &lbf[spos+12*qdim], &lbf[spos+11*qdim],
                       &lbf[spos+14*qdim], &lbf[spos+13*qdim], &lbf[spos+1*qdim], &lbf[spos+2*qdim],
                       &lbf[spos+10*qdim], &lbf[spos+5*qdim], &lbf[spos+4*qdim], &lbf[spos+7*qdim],
                       &lbf[spos+6*qdim]);
      break;
    case CCDRF:
      fD3Q15CCCInamuro(p0, uwall[0], -uwall[1], uwall[2], &lbf[spos], &lbf[spos+1*qdim],
                       &lbf[spos+9*qdim], &lbf[spos+3*qdim], &lbf[spos+6*qdim], &lbf[spos+7*qdim],
                       &lbf[spos+4*qdim], &lbf[spos+5*qdim], &lbf[spos+8*qdim], &lbf[spos+2*qdim],
                       &lbf[spos+10*qdim], &lbf[spos+13*qdim], &lbf[spos+14*qdim], &lbf[spos+11*qdim],
                       &lbf[spos+12*qdim]);
      break;
    case CETR:
      fD3Q15CCEInamuro(p0, uwall[0], uwall[1], uwall[2], &lbf[spos], &lbf[spos+1*qdim],
                       &lbf[spos+2*qdim], &lbf[spos+3*qdim], &lbf[spos+4*qdim], &lbf[spos+5*qdim],
                       &lbf[spos+6*qdim], &lbf[spos+7*qdim], &lbf[spos+8*qdim], &lbf[spos+9*qdim],
                       &lbf[spos+10*qdim], &lbf[spos+11*qdim], &lbf[spos+12*qdim], &lbf[spos+13*qdim],
                       &lbf[spos+14*qdim]);
      break;
    case CETL:
      fD3Q15CCEInamuro(p0, uwall[1], -uwall[0], uwall[2], &lbf[spos], &lbf[spos+2*qdim],
                       &lbf[spos+8*qdim], &lbf[spos+3*qdim], &lbf[spos+14*qdim], &lbf[spos+13*qdim],
                       &lbf[spos+4*qdim], &lbf[spos+5*qdim], &lbf[spos+9*qdim], &lbf[spos+1*qdim],
                       &lbf[spos+10*qdim], &lbf[spos+7*qdim], &lbf[spos+6*qdim], &lbf[spos+11*qdim],
                       &lbf[spos+12*qdim]);
      break;
    case CEDL:
      fD3Q15CCEInamuro(p0, -uwall[0], -uwall[1], uwall[2], &lbf[spos], &lbf[spos+8*qdim],
                       &lbf[spos+9*qdim], &lbf[spos+3*qdim], &lbf[spos+12*qdim], &lbf[spos+11*qdim],
                       &lbf[spos+14*qdim], &lbf[spos+13*qdim], &lbf[spos+1*qdim], &lbf[spos+2*qdim],
                       &lbf[spos+10*qdim], &lbf[spos+5*qdim], &lbf[spos+4*qdim], &lbf[spos+7*qdim],
                       &lbf[spos+6*qdim]);
      break;
    case CEDR:
      fD3Q15CCEInamuro(p0, -uwall[1], uwall[0], uwall[2], &lbf[spos], &lbf[spos+9*qdim],
                       &lbf[spos+1*qdim], &lbf[spos+3*qdim], &lbf[spos+6*qdim], &lbf[spos+7*qdim],
                       &lbf[spos+12*qdim], &lbf[spos+11*qdim], &lbf[spos+2*qdim], &lbf[spos+8*qdim],
                       &lbf[spos+10*qdim], &lbf[spos+13*qdim], &lbf[spos+14*qdim], &lbf[spos+5*qdim],
                       &lbf[spos+4*qdim]);
      break;
    case CETF:
      fD3Q15CCEInamuro(p0, uwall[1], uwall[2], uwall[0], &lbf[spos], &lbf[spos+2*qdim],
                       &lbf[spos+3*qdim], &lbf[spos+1*qdim], &lbf[spos+4*qdim], &lbf[spos+14*qdim],
                       &lbf[spos+5*qdim], &lbf[spos+13*qdim], &lbf[spos+9*qdim], &lbf[spos+10*qdim],
                       &lbf[spos+8*qdim], &lbf[spos+11*qdim], &lbf[spos+7*qdim], &lbf[spos+12*qdim],
                       &lbf[spos+6*qdim]);
      break;
    case CELF:
      fD3Q15CCEInamuro(p0, -uwall[0], uwall[2], uwall[1], &lbf[spos], &lbf[spos+8*qdim],
                       &lbf[spos+3*qdim], &lbf[spos+2*qdim], &lbf[spos+14*qdim], &lbf[spos+12*qdim],
                       &lbf[spos+13*qdim], &lbf[spos+11*qdim], &lbf[spos+1*qdim], &lbf[spos+10*qdim],
                       &lbf[spos+9*qdim], &lbf[spos+7*qdim], &lbf[spos+5*qdim], &lbf[spos+6*qdim],
                       &lbf[spos+4*qdim]);
      break;
    case CEDF:
      fD3Q15CCEInamuro(p0, -uwall[1], uwall[2], uwall[0], &lbf[spos], &lbf[spos+9*qdim],
                       &lbf[spos+3*qdim], &lbf[spos+1*qdim], &lbf[spos+6*qdim], &lbf[spos+12*qdim],
                       &lbf[spos+7*qdim], &lbf[spos+11*qdim], &lbf[spos+2*qdim], &lbf[spos+10*qdim],
                       &lbf[spos+8*qdim], &lbf[spos+13*qdim], &lbf[spos+5*qdim], &lbf[spos+14*qdim],
                       &lbf[spos+4*qdim]);
      break;
    case CERF:
      fD3Q15CCEInamuro(p0, uwall[0], uwall[2], uwall[1], &lbf[spos], &lbf[spos+1*qdim],
                       &lbf[spos+3*qdim], &lbf[spos+2*qdim], &lbf[spos+4*qdim], &lbf[spos+6*qdim],
                       &lbf[spos+5*qdim], &lbf[spos+7*qdim], &lbf[spos+8*qdim], &lbf[spos+10*qdim],
                       &lbf[spos+9*qdim], &lbf[spos+11*qdim], &lbf[spos+13*qdim], &lbf[spos+12*qdim],
                       &lbf[spos+14*qdim]);
      break;
    case CETB:
      fD3Q15CCEInamuro(p0, uwall[1], -uwall[2], uwall[0], &lbf[spos], &lbf[spos+2*qdim],
                       &lbf[spos+10*qdim], &lbf[spos+1*qdim], &lbf[spos+5*qdim], &lbf[spos+13*qdim],
                       &lbf[spos+4*qdim], &lbf[spos+14*qdim], &lbf[spos+9*qdim], &lbf[spos+3*qdim],
                       &lbf[spos+8*qdim], &lbf[spos+12*qdim], &lbf[spos+6*qdim], &lbf[spos+11*qdim],
                       &lbf[spos+7*qdim]);
      break;
    case CELB:
      fD3Q15CCEInamuro(p0, -uwall[0], -uwall[2], uwall[1], &lbf[spos], &lbf[spos+8*qdim],
                       &lbf[spos+10*qdim], &lbf[spos+2*qdim], &lbf[spos+13*qdim], &lbf[spos+11*qdim],
                       &lbf[spos+14*qdim], &lbf[spos+12*qdim], &lbf[spos+1*qdim], &lbf[spos+3*qdim],
                       &lbf[spos+9*qdim], &lbf[spos+6*qdim], &lbf[spos+4*qdim], &lbf[spos+7*qdim],
                       &lbf[spos+5*qdim]);
      break;
    case CEDB:
      fD3Q15CCEInamuro(p0, -uwall[1], -uwall[2], uwall[0], &lbf[spos], &lbf[spos+9*qdim],
                       &lbf[spos+10*qdim], &lbf[spos+1*qdim], &lbf[spos+7*qdim], &lbf[spos+11*qdim],
                       &lbf[spos+6*qdim], &lbf[spos+12*qdim], &lbf[spos+2*qdim], &lbf[spos+3*qdim],
                       &lbf[spos+8*qdim], &lbf[spos+14*qdim], &lbf[spos+4*qdim], &lbf[spos+13*qdim],
                       &lbf[spos+5*qdim]);
      break;
    case CERB:
      fD3Q15CCEInamuro(p0, uwall[0], -uwall[2], uwall[1], &lbf[spos], &lbf[spos+1*qdim],
                       &lbf[spos+10*qdim], &lbf[spos+2*qdim], &lbf[spos+5*qdim], &lbf[spos+7*qdim],
                       &lbf[spos+4*qdim], &lbf[spos+6*qdim], &lbf[spos+8*qdim], &lbf[spos+3*qdim],
                       &lbf[spos+9*qdim], &lbf[spos+12*qdim], &lbf[spos+14*qdim], &lbf[spos+11*qdim],
                       &lbf[spos+13*qdim]);
      break;
  }
  return 0;  
}


int fD3Q15TPSInamuro(double p, double v0, double v1, double v2, double *f0, double *f1,
	                 double *f2, double *f3, double *f4, double *f5, double *f6,
                     double *f7, double *f8, double *f9, double *f10, double *f11,
                     double *f12, double *f13, double *f14)
{

  // produce fixed temperature at planar surface: expressed for bottom wall (TPST)

  double rhop;
  double c1=1.0/9.0,c2=1.0/72.0;

  rhop=6.0*(p-f0[0]-f1[0]-f2[0]-f3[0]-f4[0]-f5[0]-f8[0]-f10[0]-f13[0]-f14[0])/(1.0+3.0*v1);
  f6[0]=c2*rhop*(1.0-3.0*v0+3.0*v1-3.0*v2);
  f7[0]=c2*rhop*(1.0-3.0*v0+3.0*v1+3.0*v2);
  f9[0]=c1*rhop*(1.0+3.0*v1);
  f11[0]=c2*rhop*(1.0+3.0*v0+3.0*v1+3.0*v2);
  f12[0]=c2*rhop*(1.0+3.0*v0+3.0*v1-3.0*v2);
  return 0;
}

int fD3Q15TCEInamuro(double p, double v0, double v1, double v2, double *f0, double *f1,
	                 double *f2, double *f3, double *f4, double *f5, double *f6,
                     double *f7, double *f8, double *f9, double *f10, double *f11,
                     double *f12, double *f13, double *f14)
{

  // produce fixed temperature at concave edge: expressed for bottom-left edge (TPSTR)

  double rhop;
  double c1=1.0/9.0,c2=1.0/72.0;

  rhop=36.0*(p-f0[0]-f1[0]-f2[0]-f3[0]-f4[0]-f5[0]-f10[0])/(11.0+15.0*(v0+v1));
  f6[0]=c2*rhop*(1.0-3.0*v0+3.0*v1-3.0*v2);
  f7[0]=c2*rhop*(1.0-3.0*v0+3.0*v1+3.0*v2);
  f8[0]=c1*rhop*(1.0+3.0*v0);
  f9[0]=c1*rhop*(1.0+3.0*v1);
  f11[0]=c2*rhop*(1.0+3.0*v0+3.0*v1+3.0*v2);
  f12[0]=c2*rhop*(1.0+3.0*v0+3.0*v1-3.0*v2);
  f13[0]=c2*rhop*(1.0+3.0*v0-3.0*v1+3.0*v2);
  f14[0]=c2*rhop*(1.0+3.0*v0-3.0*v1-3.0*v2);
  return 0;
}

int fD3Q15TCCInamuro(double p, double v0, double v1, double v2, double *f0, double *f1,
	                 double *f2, double *f3, double *f4, double *f5, double *f6,
                     double *f7, double *f8, double *f9, double *f10, double *f11,
                     double *f12, double *f13, double *f14)
{

  // produce fixed temperature at concave corner: expressed for bottom-left-back corner (TPSTRF)

  double rhop;
  double c1=1.0/9.0,c2=1.0/72.0;

  rhop=72.0*(p-f0[0]-f1[0]-f2[0]-f3[0]-f4[0])/(31.0+27.0*(v0+v1+v2));
  f5[0]=c2*rhop*(1.0-3.0*v0-3.0*v1+3.0*v2);
  f6[0]=c2*rhop*(1.0-3.0*v0+3.0*v1-3.0*v2);
  f7[0]=c2*rhop*(1.0-3.0*v0+3.0*v1+3.0*v2);
  f8[0]=c1*rhop*(1.0+3.0*v0);
  f9[0]=c1*rhop*(1.0+3.0*v1);
  f10[0]=c1*rhop*(1.0+3.0*v2);
  f11[0]=c2*rhop*(1.0+3.0*v0+3.0*v1+3.0*v2);
  f12[0]=c2*rhop*(1.0+3.0*v0+3.0*v1-3.0*v2);
  f13[0]=c2*rhop*(1.0+3.0*v0-3.0*v1+3.0*v2);
  f14[0]=c2*rhop*(1.0+3.0*v0-3.0*v1-3.0*v2);
  return 0;
}



int fD3Q15PTInamuro(long tpos, int prop, double p0, double *uwall)
{
  long spos=tpos * lbsitelength + lbsy.nf + lbsy.nc;
  int qdim = lbsy.nf+lbsy.nc+lbsy.nt;
    
  switch (prop) {
    case PST:
      fD3Q15TPSInamuro(p0, uwall[0], uwall[1], uwall[2], &lbf[spos], &lbf[spos+1*qdim],
                       &lbf[spos+2*qdim], &lbf[spos+3*qdim], &lbf[spos+4*qdim], &lbf[spos+5*qdim], &lbf[spos+6*qdim],
                       &lbf[spos+7*qdim], &lbf[spos+8*qdim], &lbf[spos+9*qdim], &lbf[spos+10*qdim], &lbf[spos+11*qdim],
                       &lbf[spos+12*qdim], &lbf[spos+13*qdim], &lbf[spos+14*qdim]);
      break;
    case PSD:
      fD3Q15TPSInamuro(p0, -uwall[0], -uwall[1], -uwall[2], &lbf[spos], &lbf[spos+8*qdim],
  	  	               &lbf[spos+9*qdim], &lbf[spos+10*qdim], &lbf[spos+11*qdim], &lbf[spos+12*qdim], &lbf[spos+13*qdim],
                       &lbf[spos+14*qdim], &lbf[spos+1*qdim], &lbf[spos+2*qdim], &lbf[spos+3*qdim], &lbf[spos+4*qdim],
                       &lbf[spos+5*qdim], &lbf[spos+6*qdim], &lbf[spos+7*qdim]);
      break;
    case PSL:
      fD3Q15TPSInamuro(p0, -uwall[2], -uwall[0], -uwall[1], &lbf[spos], &lbf[spos+10*qdim],
		               &lbf[spos+8*qdim], &lbf[spos+9*qdim], &lbf[spos+11*qdim], &lbf[spos+13*qdim], &lbf[spos+7*qdim],
                       &lbf[spos+5*qdim], &lbf[spos+3*qdim], &lbf[spos+1*qdim], &lbf[spos+2*qdim], &lbf[spos+4*qdim],
                       &lbf[spos+6*qdim], &lbf[spos+14*qdim], &lbf[spos+12*qdim]);
      break;
    case PSR:
      fD3Q15TPSInamuro(p0, uwall[2], uwall[0], uwall[1], &lbf[spos], &lbf[spos+10*qdim],
		               &lbf[spos+8*qdim], &lbf[spos+9*qdim], &lbf[spos+11*qdim], &lbf[spos+13*qdim], &lbf[spos+7*qdim],
                       &lbf[spos+5*qdim], &lbf[spos+3*qdim], &lbf[spos+1*qdim], &lbf[spos+2*qdim], &lbf[spos+4*qdim],
                       &lbf[spos+6*qdim], &lbf[spos+14*qdim], &lbf[spos+12*qdim]);
      break;
    case PSF:
      fD3Q15TPSInamuro(p0, -uwall[1], -uwall[2], -uwall[0], &lbf[spos], &lbf[spos+9*qdim],
		               &lbf[spos+10*qdim], &lbf[spos+8*qdim], &lbf[spos+11*qdim], &lbf[spos+7*qdim], &lbf[spos+12*qdim],
                       &lbf[spos+6*qdim], &lbf[spos+2*qdim], &lbf[spos+3*qdim], &lbf[spos+1*qdim], &lbf[spos+4*qdim],
                       &lbf[spos+14*qdim], &lbf[spos+5*qdim], &lbf[spos+13*qdim]);
      break;
    case PSB:
      fD3Q15TPSInamuro(p0, uwall[1], uwall[2], uwall[0], &lbf[spos], &lbf[spos+2*qdim],
		               &lbf[spos+3*qdim], &lbf[spos+1*qdim], &lbf[spos+4*qdim], &lbf[spos+14*qdim], &lbf[spos+5*qdim],
                       &lbf[spos+13*qdim], &lbf[spos+9*qdim], &lbf[spos+10*qdim], &lbf[spos+8*qdim], &lbf[spos+11*qdim],
                       &lbf[spos+7*qdim], &lbf[spos+12*qdim], &lbf[spos+6*qdim]);
      break;
    case CCTRB:
      fD3Q15TCCInamuro(p0, uwall[0], uwall[1], -uwall[2], &lbf[spos], &lbf[spos+1*qdim],
                       &lbf[spos+2*qdim], &lbf[spos+10*qdim], &lbf[spos+5*qdim], &lbf[spos+4*qdim],
                       &lbf[spos+7*qdim], &lbf[spos+6*qdim], &lbf[spos+8*qdim], &lbf[spos+9*qdim],
                       &lbf[spos+3*qdim], &lbf[spos+12*qdim], &lbf[spos+11*qdim], &lbf[spos+14*qdim],
                       &lbf[spos+13*qdim]);
      break;
    case CCTLB:
      fD3Q15TCCInamuro(p0, -uwall[0], uwall[1], -uwall[2], &lbf[spos], &lbf[spos+8*qdim],
                       &lbf[spos+2*qdim], &lbf[spos+10*qdim], &lbf[spos+13*qdim], &lbf[spos+14*qdim],
                       &lbf[spos+11*qdim], &lbf[spos+12*qdim], &lbf[spos+1*qdim], &lbf[spos+9*qdim],
                       &lbf[spos+3*qdim], &lbf[spos+6*qdim], &lbf[spos+7*qdim], &lbf[spos+4*qdim],
                       &lbf[spos+5*qdim]);
      break;
    case CCDLB:
      fD3Q15TCCInamuro(p0, -uwall[0], -uwall[1], -uwall[2], &lbf[spos], &lbf[spos+8*qdim],
                       &lbf[spos+9*qdim], &lbf[spos+10*qdim], &lbf[spos+11*qdim], &lbf[spos+12*qdim],
                       &lbf[spos+13*qdim], &lbf[spos+14*qdim], &lbf[spos+1*qdim], &lbf[spos+2*qdim],
                       &lbf[spos+3*qdim], &lbf[spos+4*qdim], &lbf[spos+5*qdim], &lbf[spos+6*qdim],
                       &lbf[spos+7*qdim]);
      break;
    case CCDRB:
      fD3Q15TCCInamuro(p0, uwall[0], -uwall[1], -uwall[2], &lbf[spos], &lbf[spos+1*qdim],
                       &lbf[spos+9*qdim], &lbf[spos+10*qdim], &lbf[spos+7*qdim], &lbf[spos+6*qdim],
                       &lbf[spos+5*qdim], &lbf[spos+4*qdim], &lbf[spos+8*qdim], &lbf[spos+2*qdim],
                       &lbf[spos+3*qdim], &lbf[spos+14*qdim], &lbf[spos+13*qdim], &lbf[spos+12*qdim],
                       &lbf[spos+11*qdim]);
      break;
    case CCTRF:
      fD3Q15TCCInamuro(p0, uwall[0], uwall[1], uwall[2], &lbf[spos], &lbf[spos+1*qdim],
                       &lbf[spos+2*qdim], &lbf[spos+3*qdim], &lbf[spos+4*qdim], &lbf[spos+5*qdim],
                       &lbf[spos+6*qdim], &lbf[spos+7*qdim], &lbf[spos+8*qdim], &lbf[spos+9*qdim],
                       &lbf[spos+10*qdim], &lbf[spos+11*qdim], &lbf[spos+12*qdim], &lbf[spos+13*qdim],
                       &lbf[spos+14*qdim]);
      break;
    case CCTLF:
      fD3Q15TCCInamuro(p0, -uwall[0], uwall[1], uwall[2], &lbf[spos], &lbf[spos+8*qdim],
                       &lbf[spos+2*qdim], &lbf[spos+3*qdim], &lbf[spos+14*qdim], &lbf[spos+13*qdim],
                       &lbf[spos+12*qdim], &lbf[spos+11*qdim], &lbf[spos+1*qdim], &lbf[spos+9*qdim],
                       &lbf[spos+10*qdim], &lbf[spos+7*qdim], &lbf[spos+6*qdim], &lbf[spos+5*qdim],
                       &lbf[spos+4*qdim]);
      break;
    case CCDLF:
      fD3Q15TCCInamuro(p0, -uwall[0], -uwall[1], uwall[2], &lbf[spos], &lbf[spos+8*qdim],
                       &lbf[spos+9*qdim], &lbf[spos+3*qdim], &lbf[spos+12*qdim], &lbf[spos+11*qdim],
                       &lbf[spos+14*qdim], &lbf[spos+13*qdim], &lbf[spos+1*qdim], &lbf[spos+2*qdim],
                       &lbf[spos+10*qdim], &lbf[spos+5*qdim], &lbf[spos+4*qdim], &lbf[spos+7*qdim],
                       &lbf[spos+6*qdim]);
      break;
    case CCDRF:
      fD3Q15TCCInamuro(p0, uwall[0], -uwall[1], uwall[2], &lbf[spos], &lbf[spos+1*qdim],
                       &lbf[spos+9*qdim], &lbf[spos+3*qdim], &lbf[spos+6*qdim], &lbf[spos+7*qdim],
                       &lbf[spos+4*qdim], &lbf[spos+5*qdim], &lbf[spos+8*qdim], &lbf[spos+2*qdim],
                       &lbf[spos+10*qdim], &lbf[spos+13*qdim], &lbf[spos+14*qdim], &lbf[spos+11*qdim],
                       &lbf[spos+12*qdim]);
      break;
    case CETR:
      fD3Q15TCEInamuro(p0, uwall[0], uwall[1], uwall[2], &lbf[spos], &lbf[spos+1*qdim],
                       &lbf[spos+2*qdim], &lbf[spos+3*qdim], &lbf[spos+4*qdim], &lbf[spos+5*qdim],
                       &lbf[spos+6*qdim], &lbf[spos+7*qdim], &lbf[spos+8*qdim], &lbf[spos+9*qdim],
                       &lbf[spos+10*qdim], &lbf[spos+11*qdim], &lbf[spos+12*qdim], &lbf[spos+13*qdim],
                       &lbf[spos+14*qdim]);
      break;
    case CETL:
      fD3Q15TCEInamuro(p0, uwall[1], -uwall[0], uwall[2], &lbf[spos], &lbf[spos+2*qdim],
                       &lbf[spos+8*qdim], &lbf[spos+3*qdim], &lbf[spos+14*qdim], &lbf[spos+13*qdim],
                       &lbf[spos+4*qdim], &lbf[spos+5*qdim], &lbf[spos+9*qdim], &lbf[spos+1*qdim],
                       &lbf[spos+10*qdim], &lbf[spos+7*qdim], &lbf[spos+6*qdim], &lbf[spos+11*qdim],
                       &lbf[spos+12*qdim]);
      break;
    case CEDL:
      fD3Q15TCEInamuro(p0, -uwall[0], -uwall[1], uwall[2], &lbf[spos], &lbf[spos+8*qdim],
                       &lbf[spos+9*qdim], &lbf[spos+3*qdim], &lbf[spos+12*qdim], &lbf[spos+11*qdim],
                       &lbf[spos+14*qdim], &lbf[spos+13*qdim], &lbf[spos+1*qdim], &lbf[spos+2*qdim],
                       &lbf[spos+10*qdim], &lbf[spos+5*qdim], &lbf[spos+4*qdim], &lbf[spos+7*qdim],
                       &lbf[spos+6*qdim]);
      break;
    case CEDR:
      fD3Q15TCEInamuro(p0, -uwall[1], uwall[0], uwall[2], &lbf[spos], &lbf[spos+9*qdim],
                       &lbf[spos+1*qdim], &lbf[spos+3*qdim], &lbf[spos+6*qdim], &lbf[spos+7*qdim],
                       &lbf[spos+12*qdim], &lbf[spos+11*qdim], &lbf[spos+2*qdim], &lbf[spos+8*qdim],
                       &lbf[spos+10*qdim], &lbf[spos+13*qdim], &lbf[spos+14*qdim], &lbf[spos+5*qdim],
                       &lbf[spos+4*qdim]);
      break;
    case CETF:
      fD3Q15TCEInamuro(p0, uwall[1], uwall[2], uwall[0], &lbf[spos], &lbf[spos+2*qdim],
                       &lbf[spos+3*qdim], &lbf[spos+1*qdim], &lbf[spos+4*qdim], &lbf[spos+14*qdim],
                       &lbf[spos+5*qdim], &lbf[spos+13*qdim], &lbf[spos+9*qdim], &lbf[spos+10*qdim],
                       &lbf[spos+8*qdim], &lbf[spos+11*qdim], &lbf[spos+7*qdim], &lbf[spos+12*qdim],
                       &lbf[spos+6*qdim]);
      break;
    case CELF:
      fD3Q15TCEInamuro(p0, -uwall[0], uwall[2], uwall[1], &lbf[spos], &lbf[spos+8*qdim],
                       &lbf[spos+3*qdim], &lbf[spos+2*qdim], &lbf[spos+14*qdim], &lbf[spos+12*qdim],
                       &lbf[spos+13*qdim], &lbf[spos+11*qdim], &lbf[spos+1*qdim], &lbf[spos+10*qdim],
                       &lbf[spos+9*qdim], &lbf[spos+7*qdim], &lbf[spos+5*qdim], &lbf[spos+6*qdim],
                       &lbf[spos+4*qdim]);
      break;
    case CEDF:
      fD3Q15TCEInamuro(p0, -uwall[1], uwall[2], uwall[0], &lbf[spos], &lbf[spos+9*qdim],
                       &lbf[spos+3*qdim], &lbf[spos+1*qdim], &lbf[spos+6*qdim], &lbf[spos+12*qdim],
                       &lbf[spos+7*qdim], &lbf[spos+11*qdim], &lbf[spos+2*qdim], &lbf[spos+10*qdim],
                       &lbf[spos+8*qdim], &lbf[spos+13*qdim], &lbf[spos+5*qdim], &lbf[spos+14*qdim],
                       &lbf[spos+4*qdim]);
      break;
    case CERF:
      fD3Q15TCEInamuro(p0, uwall[0], uwall[2], uwall[1], &lbf[spos], &lbf[spos+1*qdim],
                       &lbf[spos+3*qdim], &lbf[spos+2*qdim], &lbf[spos+4*qdim], &lbf[spos+6*qdim],
                       &lbf[spos+5*qdim], &lbf[spos+7*qdim], &lbf[spos+8*qdim], &lbf[spos+10*qdim],
                       &lbf[spos+9*qdim], &lbf[spos+11*qdim], &lbf[spos+13*qdim], &lbf[spos+12*qdim],
                       &lbf[spos+14*qdim]);
      break;
    case CETB:
      fD3Q15TCEInamuro(p0, uwall[1], -uwall[2], uwall[0], &lbf[spos], &lbf[spos+2*qdim],
                       &lbf[spos+10*qdim], &lbf[spos+1*qdim], &lbf[spos+5*qdim], &lbf[spos+13*qdim],
                       &lbf[spos+4*qdim], &lbf[spos+14*qdim], &lbf[spos+9*qdim], &lbf[spos+3*qdim],
                       &lbf[spos+8*qdim], &lbf[spos+12*qdim], &lbf[spos+6*qdim], &lbf[spos+11*qdim],
                       &lbf[spos+7*qdim]);
      break;
    case CELB:
      fD3Q15TCEInamuro(p0, -uwall[0], -uwall[2], uwall[1], &lbf[spos], &lbf[spos+8*qdim],
                       &lbf[spos+10*qdim], &lbf[spos+2*qdim], &lbf[spos+13*qdim], &lbf[spos+11*qdim],
                       &lbf[spos+14*qdim], &lbf[spos+12*qdim], &lbf[spos+1*qdim], &lbf[spos+3*qdim],
                       &lbf[spos+9*qdim], &lbf[spos+6*qdim], &lbf[spos+4*qdim], &lbf[spos+7*qdim],
                       &lbf[spos+5*qdim]);
      break;
    case CEDB:
      fD3Q15TCEInamuro(p0, -uwall[1], -uwall[2], uwall[0], &lbf[spos], &lbf[spos+9*qdim],
                       &lbf[spos+10*qdim], &lbf[spos+1*qdim], &lbf[spos+7*qdim], &lbf[spos+11*qdim],
                       &lbf[spos+6*qdim], &lbf[spos+12*qdim], &lbf[spos+2*qdim], &lbf[spos+3*qdim],
                       &lbf[spos+8*qdim], &lbf[spos+14*qdim], &lbf[spos+4*qdim], &lbf[spos+13*qdim],
                       &lbf[spos+5*qdim]);
      break;
    case CERB:
      fD3Q15TCEInamuro(p0, uwall[0], -uwall[2], uwall[1], &lbf[spos], &lbf[spos+1*qdim],
                       &lbf[spos+10*qdim], &lbf[spos+2*qdim], &lbf[spos+5*qdim], &lbf[spos+7*qdim],
                       &lbf[spos+4*qdim], &lbf[spos+6*qdim], &lbf[spos+8*qdim], &lbf[spos+3*qdim],
                       &lbf[spos+9*qdim], &lbf[spos+12*qdim], &lbf[spos+14*qdim], &lbf[spos+11*qdim],
                       &lbf[spos+13*qdim]);
      break;
  }
  return 0;  
}


// D3Q19

int fD3Q19VPSInamuro(double v0, double v1, double v2, double *force,
                     double *f0, double *f1, double *f2, double *f3, double *f4,
                     double *f5, double *f6, double *f7, double *f8, double *f9,
                     double *f10, double *f11, double *f12, double *f13, double *f14,
                     double *f15, double *f16, double *f17, double *f18)
{

  // produce fixed velocity for compressible/incompressible fluids at planar surface boundary:
  // expressed for bottom wall (VPST)
  double rho, rho0, rrho0, rhop, v0t, v2t;
  double c1=1.0/18.0,c2=1.0/36.0;
    
  if(!incompress) {
    for(int i=0; i<lbsy.nf; i++) {
      rho = (f0[i]+f1[i]+f3[i]+f6[i]+f7[i]+f10[i]+f12[i]+f15[i]+f16[i]+2.0*(f2[i]+f4[i]+f8[i]+f9[i]+f14[i])-0.5*force[3*i+1])/(1.0-v1);
      rhop = 6.0*(rho*v1+f2[i]+f4[i]+f8[i]+f9[i]+f14[i]-0.5*force[3*i+1])/(1.0+3.0*v1*(1.0+v1));
      v0t = 6.0*(rho*v0+f1[i]+f4[i]+f6[i]+f7[i]-f10[i]-f14[i]-f15[i]-f16[i]-0.5*force[3*i  ])/(rhop*(1.0+3.0*v1)); // v0t = v0 + v0s
      v2t = 6.0*(rho*v2+f3[i]+f6[i]-f7[i]+f8[i]-f9[i]-f12[i]-f15[i]+f16[i]-0.5*force[3*i+2])/(rhop*(1.0+3.0*v1)); // v2t = v2 + v2s
      f5[i]=c2*rhop*(1.0+3.0*(v1*(1.0+v1)-v0t*(1.0-v0t))-9.0*v0t*v1-1.5*v2t*v2t);
      f11[i]=c1*rhop*(1.0+3.0*v1*(1.0+v1)-1.5*(v0t*v0t+v2t*v2t));
      f13[i]=c2*rhop*(1.0+3.0*(v1*(1.0+v1)+v0t*(1.0+v0t))+9.0*v0t*v1-1.5*v2t*v2t);
      f17[i]=c2*rhop*(1.0+3.0*(v1*(1.0+v1)+v2t*(1.0+v2t))+9.0*v1*v2t-1.5*v0t*v0t);
      f18[i]=c2*rhop*(1.0+3.0*(v1*(1.0+v1)-v2t*(1.0-v2t))-9.0*v1*v2t-1.5*v0t*v0t);
    }
  }
  else {
    for(int i=0; i<lbsy.nf; i++) {
      rho0 = lbincp[i];
      rrho0 = fReciprocal(rho0);
      rhop = 6.0*(f2[i]+f4[i]+f8[i]+f9[i]+f14[i])+3.0*rho0*v1*(1.0-v1)-3.0*force[3*i+1];
      v0t = 6.0*(v0+(f1[i]+f4[i]+f6[i]+f7[i]-f10[i]-f14[i]-f15[i]-f16[i]-0.5*force[3*i  ])*rrho0)/(1.0+3.0*v1); // v0t = v0 + v0s
      v2t = 6.0*(v2+(f3[i]+f6[i]-f7[i]+f8[i]-f9[i]-f12[i]-f15[i]+f16[i]-0.5*force[3*i+2])*rrho0)/(1.0+3.0*v1); // v2t = v2 + v2s
      f5[i]=c2*(rhop+rho0*(3.0*(v1*(1.0+v1)-v0t*(1.0-v0t))-9.0*v0t*v1-1.5*v2t*v2t));
      f11[i]=c1*(rhop+rho0*(3.0*v1*(1.0+v1))-1.5*(v0t*v0t+v2t*v2t));
      f13[i]=c2*(rhop+rho0*(3.0*(v1*(1.0+v1)+v0t*(1.0+v0t))+9.0*v0t*v1-1.5*v2t*v2t));
      f17[i]=c2*(rhop+rho0*(3.0*(v1*(1.0+v1)+v2t*(1.0+v2t))+9.0*v1*v2t-1.5*v0t*v0t));
      f18[i]=c2*(rhop+rho0*(3.0*(v1*(1.0+v1)-v2t*(1.0-v2t))-9.0*v1*v2t-1.5*v0t*v0t));
    }
  }
  return 0;
}

int fD3Q19VCEInamuro(double *p, double v0, double v1, double v2, double *force,
                     double *f0, double *f1, double *f2, double *f3, double *f4,
                     double *f5, double *f6, double *f7, double *f8, double *f9,
                     double *f10, double *f11, double *f12, double *f13, double *f14,
                     double *f15, double *f16, double *f17, double *f18)
{

  // produce fixed velocity for compressible/incompressible fluids at concave edge boundary:
  // expressed for bottom left edge (VCETR)
  double rho0, rrho0, rhop, v2t;
  double c1=1.0/18.0,c2=1.0/36.0;

  if(!incompress) {
    for(int i=0; i<lbsy.nf; i++) {
      rhop = 12.0*(p[i]*(1.0-0.5*(v0+v1))-f0[i]-f3[i]-f12[i]-0.5*(f1[i]+f2[i]+f6[i]+f7[i]+f8[i]+f9[i])+0.25*(force[3*i]+force[3*i+1]))/(2.0*(1.0+v0+v1)+3.0*(v0*v0+v1*v1-2.0*v0*v1));
      v2t = 6.0*(p[i]*v2+f3[i]+f6[i]-f7[i]+f8[i]-f9[i]-f12[i]-0.5*force[3*i+2])*fReciprocal(rhop*(2.0+3.0*(v0+v1))); // v2t = v2 + v2s
      f5[i]=c2*rhop*(1.0-3.0*(v0*(1.0-v0)-v1*(1.0+v1))-9.0*v0*v1-1.5*v2t*v2t);
      f10[i]=c1*rhop*(1.0+3.0*v0*(1.0+v0)-1.5*(v1*v1+v2t*v2t));
      f11[i]=c1*rhop*(1.0+3.0*v1*(1.0+v1)-1.5*(v0*v0+v2t*v2t));
      f13[i]=c2*rhop*(1.0+3.0*(v0*(1.0+v0)+v1*(1.0+v1))+9.0*v0*v1-1.5*v2t*v2t);
      f14[i]=c2*rhop*(1.0+3.0*(v0*(1.0+v0)-v1*(1.0-v1))-9.0*v0*v1-1.5*v2t*v2t);
      f15[i]=c2*rhop*(1.0+3.0*(v0*(1.0+v0)+v2t*(1.0+v2t))+9.0*v0*v2t-1.5*v1*v1);
      f16[i]=c2*rhop*(1.0+3.0*(v0*(1.0+v0)-v2t*(1.0-v2t))-9.0*v0*v2t-1.5*v1*v1);
      f17[i]=c2*rhop*(1.0+3.0*(v1*(1.0+v1)+v2t*(1.0+v2t))+9.0*v1*v2t-1.5*v0*v0);
      f18[i]=c2*rhop*(1.0+3.0*(v1*(1.0+v1)-v2t*(1.0-v2t))-9.0*v1*v2t-1.5*v0*v0);
    }
  }
  else {
    for(int i=0; i<lbsy.nf; i++) {
      rho0 = lbincp[i];
      rrho0 = fReciprocal(rho0);
      rhop = 6.0*(p[i]-f0[i]-f3[i]-f12[i])-2.0*rho0*(v0+v1)-1.5*rho0*(v0*v0+v1*v1)+3.0*rho0*v0*v1-3.0*(f1[i]+f2[i]+f6[i]+f7[i]+f8[i]+f9[i])+1.5*(force[3*i]+force[3*i+1]);
      v2t = 3.0*(v2+(2.0*(f3[i]+f6[i]-f7[i]+f8[i]-f9[i]-f12[i])-force[3*i+2])*rrho0)/(2.0+3.0*(v0+v1)); // v2t = v2 + v2s
      f5[i]=c2*(rhop-rho0*(3.0*(v0*(1.0-v0)-v1*(1.0+v1))-9.0*v0*v1-1.5*v2t*v2t));
      f10[i]=c1*(rhop+rho0*(3.0*v0*(1.0+v0)-1.5*(v1*v1+v2t*v2t)));
      f11[i]=c1*(rhop+rho0*(3.0*v1*(1.0+v1)-1.5*(v0*v0+v2t*v2t)));
      f13[i]=c2*(rhop+rho0*(3.0*(v0*(1.0+v0)+v1*(1.0+v1))+9.0*v0*v1-1.5*v2t*v2t));
      f14[i]=c2*(rhop+rho0*(3.0*(v0*(1.0+v0)-v1*(1.0-v1))-9.0*v0*v1-1.5*v2t*v2t));
      f15[i]=c2*(rhop+rho0*(3.0*(v0*(1.0+v0)+v2t*(1.0+v2t))+9.0*v0*v2t-1.5*v1*v1));
      f16[i]=c2*(rhop+rho0*(3.0*(v0*(1.0+v0)-v2t*(1.0-v2t))-9.0*v0*v2t-1.5*v1*v1));
      f17[i]=c2*(rhop+rho0*(3.0*(v1*(1.0+v1)+v2t*(1.0+v2t))+9.0*v1*v2t-1.5*v0*v0));
      f18[i]=c2*(rhop+rho0*(3.0*(v1*(1.0+v1)-v2t*(1.0-v2t))-9.0*v1*v2t-1.5*v0*v0));
    }
  }
  return 0;
}

int fD3Q19VCCInamuro(double *p, double v0, double v1, double v2, double *force,
                     double *f0, double *f1, double *f2, double *f3, double *f4,
                     double *f5, double *f6, double *f7, double *f8, double *f9,
                     double *f10, double *f11, double *f12, double *f13, double *f14,
                     double *f15, double *f16, double *f17, double *f18)
{

  // produce fixed velocity for compressible/incompressible fluids at concave corner boundary:
  // expressed for bottom left back corner (VCETRF)
  double rho0, rhop;
  double c1=1.0/18.0,c2=1.0/36.0,c3=12.0/7.0,c4=6.0/7.0,c5=3.0/7.0,c6=1.0/7.0;

  if(!incompress) {
    for(int i=0; i<lbsy.nf; i++) {
      rhop = 12.0*(p[i]*(1.0+0.5*(v0+v1+v2))-f0[i]-0.5*(f1[i]+f2[i]+f3[i])-0.25*(force[3*i]+force[3*i+1]+force[3*i+2]))/(7.0*(1.0+v0+v1+v2)+6.0*(v0*v0+v1*v1+v2*v2));
      f5[i]=c2*rhop*(1.0-3.0*(v0*(1.0-v0)-v1*(1.0+v1))-9.0*v0*v1-1.5*v2*v2);
      f7[i]=c2*rhop*(1.0-3.0*(v0*(1.0-v0)-v2*(1.0+v2))-9.0*v0*v2-1.5*v1*v1);
      f9[i]=c2*rhop*(1.0-3.0*(v1*(1.0-v1)-v2*(1.0+v2))-9.0*v1*v2-1.5*v0*v0);
      f10[i]=c1*rhop*(1.0+3.0*v0*(1.0+v0)-1.5*(v1*v1+v2*v2));
      f11[i]=c1*rhop*(1.0+3.0*v1*(1.0+v1)-1.5*(v0*v0+v2*v2));
      f11[i]=c1*rhop*(1.0+3.0*v2*(1.0+v2)-1.5*(v0*v0+v1*v1));
      f13[i]=c2*rhop*(1.0+3.0*(v0*(1.0+v0)+v1*(1.0+v1))+9.0*v0*v1-1.5*v2*v2);
      f14[i]=c2*rhop*(1.0+3.0*(v0*(1.0+v0)-v1*(1.0-v1))-9.0*v0*v1-1.5*v2*v2);
      f15[i]=c2*rhop*(1.0+3.0*(v0*(1.0+v0)+v2*(1.0+v2))+9.0*v0*v2-1.5*v1*v1);
      f16[i]=c2*rhop*(1.0+3.0*(v0*(1.0+v0)-v2*(1.0-v2))-9.0*v0*v2-1.5*v1*v1);
      f17[i]=c2*rhop*(1.0+3.0*(v1*(1.0+v1)+v2*(1.0+v2))+9.0*v1*v2-1.5*v0*v0);
      f18[i]=c2*rhop*(1.0+3.0*(v1*(1.0+v1)-v2*(1.0-v2))-9.0*v1*v2-1.5*v0*v0);
    }
  }
  else {
    for(int i=0; i<lbsy.nf; i++) {
      rho0 = lbincp[i];
      rhop = c3*(p[i]-f0[i])-c6*rho0*(v0+v1+v2)-c4*rho0*(v0*v0+v1*v1+v2*v2)-c4*(f1[i]+f2[i]+f3[i])-c5*(force[3*i]+force[3*i+1]+force[3*i+2]);
      f5[i]=c2*(rhop-rho0*(3.0*(v0*(1.0-v0)-v1*(1.0+v1))-9.0*v0*v1-1.5*v2*v2));
      f7[i]=c2*(rhop-rho0*(3.0*(v0*(1.0-v0)-v2*(1.0+v2))-9.0*v0*v2-1.5*v1*v1));
      f9[i]=c2*(rhop-rho0*(3.0*(v1*(1.0-v1)-v2*(1.0+v2))-9.0*v1*v2-1.5*v0*v0));
      f10[i]=c1*(rhop+rho0*(3.0*v0*(1.0+v0)-1.5*(v1*v1+v2*v2)));
      f11[i]=c1*(rhop+rho0*(3.0*v1*(1.0+v1)-1.5*(v0*v0+v2*v2)));
      f12[i]=c1*(rhop+rho0*(3.0*v2*(1.0+v2)-1.5*(v0*v0+v1*v1)));
      f13[i]=c2*(rhop+rho0*(3.0*(v0*(1.0+v0)+v1*(1.0+v1))+9.0*v0*v1-1.5*v2*v2));
      f14[i]=c2*(rhop+rho0*(3.0*(v0*(1.0+v0)-v1*(1.0-v1))-9.0*v0*v1-1.5*v2*v2));
      f15[i]=c2*(rhop+rho0*(3.0*(v0*(1.0+v0)+v2*(1.0+v2))+9.0*v0*v2-1.5*v1*v1));
      f16[i]=c2*(rhop+rho0*(3.0*(v0*(1.0+v0)-v2*(1.0-v2))-9.0*v0*v2-1.5*v1*v1));
      f17[i]=c2*(rhop+rho0*(3.0*(v1*(1.0+v1)+v2*(1.0+v2))+9.0*v1*v2-1.5*v0*v0));
      f18[i]=c2*(rhop+rho0*(3.0*(v1*(1.0+v1)-v2*(1.0-v2))-9.0*v1*v2-1.5*v0*v0));
    }
  }
  return 0;
}

int fD3Q19VPSCLBEInamuro(double v0, double v1, double v2, double *force,
                         double *f0, double *f1, double *f2, double *f3, double *f4,
                         double *f5, double *f6, double *f7, double *f8, double *f9,
                         double *f10, double *f11, double *f12, double *f13, double *f14,
                         double *f15, double *f16, double *f17, double *f18)
{

  // produce fixed velocity for compressible fluids at planar surface boundary:
  // expressed for bottom wall (VPST) using higher-order equilibrium distribution
  // functions for CLBE collisions
  double rho, rhop, v0t, v2t;
  double c1=1.0/18.0,c2=1.0/36.0;
    
  for(int i=0; i<lbsy.nf; i++) {
    rho = (f0[i]+f1[i]+f3[i]+f6[i]+f7[i]+f10[i]+f12[i]+f15[i]+f16[i]+2.0*(f2[i]+f4[i]+f8[i]+f9[i]+f14[i])-0.5*force[3*i+1])/(1.0-v1);
    rhop = 6.0*(rho*v1+f2[i]+f4[i]+f8[i]+f9[i]+f14[i]-0.5*force[3*i+1])/(1.0+3.0*v1*(1.0+v1));
    v0t = 6.0*(rho*v0+f1[i]+f4[i]+f6[i]+f7[i]-f10[i]-f14[i]-f15[i]-f16[i]-0.5*force[3*i  ])/(rhop*(1.0+3.0*v1*(1.0+v1))); // v0t = v0 + v0s
    v2t = 6.0*(rho*v2+f3[i]+f6[i]-f7[i]+f8[i]-f9[i]-f12[i]-f15[i]+f16[i]-0.5*force[3*i+2])/(rhop*(1.0+3.0*v1*(1.0+v1))); // v2t = v2 + v2s
    f5[i]=c2*rhop*(1.0+3.0*(v1*(1.0+v1)-v0t*(1.0-v0t))-9.0*v0t*v1*(1.0-v0t)*(1.0+v1));
    f11[i]=c1*rhop*(1.0+3.0*v1-3.0*(v0t*v0t-v1*v1+v2t*v2t)-9.0*v1*(1.0+v1)*(v0t*v0t+v2t*v2t));
    f13[i]=c2*rhop*(1.0+3.0*(v1*(1.0+v1)+v0t*(1.0+v0t))+9.0*v0t*v1*(1.0+v0t)*(1.0+v1));
    f17[i]=c2*rhop*(1.0+3.0*(v1*(1.0+v1)+v2t*(1.0+v2t))+9.0*v1*v2t*(1.0+v1)*(1.0+v2t));
    f18[i]=c2*rhop*(1.0+3.0*(v1*(1.0+v1)-v2t*(1.0-v2t))-9.0*v1*v2t*(1.0+v1)*(1.0-v2t));
  }
  return 0;
}

int fD3Q19VCECLBEInamuro(double *p, double v0, double v1, double v2, double *force,
                         double *f0, double *f1, double *f2, double *f3, double *f4,
                         double *f5, double *f6, double *f7, double *f8, double *f9,
                         double *f10, double *f11, double *f12, double *f13, double *f14,
                         double *f15, double *f16, double *f17, double *f18)
{

  // produce fixed velocity for compressible fluids at concave edge boundary:
  // expressed for bottom left edge (VCETR) using higher-order equilibrium distribution
  // functions for CLBE collisions
  double rhop, v2t;
  double c1=1.0/18.0,c2=1.0/36.0;
    
  for(int i=0; i<lbsy.nf; i++) {
    rhop = 12.0*(p[i]*(1.0-0.5*(v0+v1))-f0[i]-f3[i]-f12[i]-0.5*(f1[i]+f2[i]+f6[i]+f7[i]+f8[i]+f9[i])+0.25*(force[3*i]+force[3*i+1]))/(2.0*(1.0+v0+v1)+3.0*(v0*v0*(1.0+v1)+v1*v1*(1.0+v0))-6.0*v0*v1*(1.0+v0*v1));
    v2t = 6.0*(p[i]*v2+f3[i]+f6[i]-f7[i]+f8[i]-f9[i]-f12[i]-0.5*force[3*i+2])*fReciprocal(rhop*(2.0+3.0*(v0+v1+v0*v0+v1*v1))); // v2t = v2 + v2s
    f5[i]=c2*rhop*(1.0-3.0*(v0*(1.0-v0)-v1*(1.0+v1))-9.0*v0*v1*(1.0-v0)*(1.0+v1));
    f10[i]=c1*rhop*(1.0+3.0*v0+3.0*(v0*v0-v1*v1-v2t*v2t)-9.0*v0*(1.0+v0)*(v1*v1+v2t*v2t));
    f11[i]=c1*rhop*(1.0+3.0*v1-3.0*(v0*v0-v1*v1+v2t*v2t)-9.0*v1*(1.0+v1)*(v0*v0+v2t*v2t));
    f13[i]=c2*rhop*(1.0+3.0*(v0*(1.0+v0)+v1*(1.0+v1))+9.0*v0*v1*(1.0+v0)*(1.0+v1));
    f14[i]=c2*rhop*(1.0+3.0*(v0*(1.0+v0)-v1*(1.0-v1))-9.0*v0*v1*(1.0+v0)*(1.0-v1));
    f15[i]=c2*rhop*(1.0+3.0*(v0*(1.0+v0)+v2t*(1.0+v2t))+9.0*v0*v2t*(1.0+v0)*(1.0+v2t));
    f16[i]=c2*rhop*(1.0+3.0*(v0*(1.0+v0)-v2t*(1.0-v2t))-9.0*v0*v2t*(1.0+v0)*(1.0-v2t));
    f17[i]=c2*rhop*(1.0+3.0*(v1*(1.0+v1)+v2t*(1.0+v2t))+9.0*v1*v2t*(1.0+v1)*(1.0+v2t));
    f18[i]=c2*rhop*(1.0+3.0*(v1*(1.0+v1)-v2t*(1.0-v2t))-9.0*v1*v2t*(1.0+v1)*(1.0-v2t));
  }
  return 0;
}

int fD3Q19VCCCLBEInamuro(double *p, double v0, double v1, double v2, double *force,
                         double *f0, double *f1, double *f2, double *f3, double *f4,
                         double *f5, double *f6, double *f7, double *f8, double *f9,
                         double *f10, double *f11, double *f12, double *f13, double *f14,
                         double *f15, double *f16, double *f17, double *f18)
{

  // produce fixed velocity for compressible fluids at concave corner boundary:
  // expressed for bottom left back corner (VCETRF) using higher-order equilibrium distribution
  // functions for CLBE collisions
  double rhop;
  double c1=1.0/18.0,c2=1.0/36.0;
    
  for(int i=0; i<lbsy.nf; i++) {
    rhop = 12.0*(p[i]*(1.0-0.5*(v0+v1+v2))-f0[i]-0.5*(f1[i]+f2[i]+f3[i])-0.25*(force[3*i]+force[3*i+1]+force[3*i+2]))/(7.0*(1.0+v0+v1+v2)+5.0*(v0*v0+v1*v1+v2*v2)-3.0*(v0*(v1*v1+v2*v2)+v1*(v0*v0+v2*v2)+v2*(v0*v0+v1*v1))-6.0*(v0*v0*(v1*v1+v2*v2)+v1*v1*v2*v2));
    f5[i]=c2*rhop*(1.0-3.0*(v0*(1.0-v0)-v1*(1.0+v1))-9.0*v0*v1*(1.0-v0)*(1.0+v1));
    f7[i]=c2*rhop*(1.0-3.0*(v0*(1.0-v0)-v2*(1.0+v2))-9.0*v0*v2*(1.0-v0)*(1.0+v2));
    f9[i]=c2*rhop*(1.0-3.0*(v1*(1.0-v1)-v2*(1.0+v2))-9.0*v1*v2*(1.0-v1)*(1.0+v2));
    f10[i]=c1*rhop*(1.0+3.0*v0+3.0*(v0*v0-v1*v1-v2*v2)-9.0*v0*(1.0+v0)*(v1*v1+v2*v2));
    f11[i]=c1*rhop*(1.0+3.0*v1-3.0*(v0*v0-v1*v1+v2*v2)-9.0*v1*(1.0+v1)*(v0*v0+v2*v2));
    f12[i]=c1*rhop*(1.0+3.0*v2-3.0*(v0*v0+v1*v1-v2*v2)-9.0*v2*(1.0+v2)*(v0*v0+v1*v1));
    f13[i]=c2*rhop*(1.0+3.0*(v0*(1.0+v0)+v1*(1.0+v1))+9.0*v0*v1*(1.0+v0)*(1.0+v1));
    f14[i]=c2*rhop*(1.0+3.0*(v0*(1.0+v0)-v1*(1.0-v1))-9.0*v0*v1*(1.0+v0)*(1.0-v1));
    f15[i]=c2*rhop*(1.0+3.0*(v0*(1.0+v0)+v2*(1.0+v2))+9.0*v0*v2*(1.0+v0)*(1.0+v2));
    f16[i]=c2*rhop*(1.0+3.0*(v0*(1.0+v0)-v2*(1.0-v2))-9.0*v0*v2*(1.0+v0)*(1.0-v2));
    f17[i]=c2*rhop*(1.0+3.0*(v1*(1.0+v1)+v2*(1.0+v2))+9.0*v1*v2*(1.0+v1)*(1.0+v2));
    f18[i]=c2*rhop*(1.0+3.0*(v1*(1.0+v1)-v2*(1.0-v2))-9.0*v1*v2*(1.0+v1)*(1.0-v2));
  }
  return 0;
}

int fD3Q19VPSSwiftInamuro(double v0, double v1, double v2, double *force,
                          double *f0, double *f1, double *f2, double *f3, double *f4,
                          double *f5, double *f6, double *f7, double *f8, double *f9,
                          double *f10, double *f11, double *f12, double *f13, double *f14,
                          double *f15, double *f16, double *f17, double *f18,
                          double drdx, double drdy, double drdz, double dpdx, double dpdy, double dpdz,
                          double nabr, double nabp, double *omega, double T)
{

  // produce fixed velocity for compressible/incompressible fluids at planar surface boundary:
  // expressed for bottom wall (VPST)

  double rho, phi, omegat, pb, mu, lambda, d2rdx2, d2rdy2, d2rdz2, d2rdxdy, d2rdydz, nabrp, rhop, phip, v0t, v2t;
  double c0=1.0/3.0,c1=1.0/6.0,c2=1.0/12.0,c3=1.0/24.0;

  rho = (f0[0]+f1[0]+f3[0]+f6[0]+f7[0]+f10[0]+f12[0]+f15[0]+f16[0]+2.0*(f2[0]+f4[0]+f8[0]+f9[0]+f14[0])-0.5*force[1])/(1.0-v1);
  if(lbsy.nf>1) {
    phi = (f0[1]+f1[1]+f3[1]+f6[1]+f7[1]+f10[1]+f12[1]+f15[1]+f16[1]+2.0*(f2[1]+f4[1]+f8[1]+f9[1]+f14[1]))/(1.0-v1);
    omegat = 0.5*(1.0+phi)*omega[0]+0.5*(1.0-phi)*omega[1];
    mu = lbfemob*fGetPotentialSwift(phi, nabp);
    d2rdx2 = (lbfeeos>0)?(drdx*drdx):0.0 + dpdx*dpdx;
    d2rdy2 = (lbfeeos>0)?(drdy*drdy):0.0 + dpdy*dpdy;
    d2rdz2 = (lbfeeos>0)?(drdz*drdz):0.0 + dpdz*dpdz;
    d2rdxdy = (lbfeeos>0)?(drdx*drdy):0.0 + dpdx*dpdy;
//  d2rdxdz = (lbfeeos>0)?(drdx*drdz):0.0 + dpdx*dpdz;   // this gradient not required for this boundary
    d2rdydz = (lbfeeos>0)?(drdy*drdz):0.0 + dpdy*dpdz;
    nabrp = (lbfeeos>0)?(rho*nabr):0.0 + phi*nabp;
    if(fCppAbs(v1)>0.0)
      phip = (2.0*(phi-f0[1]-f1[1]-f2[1]-f3[1]-f4[1]-f6[1]-f7[1]-f8[1]-f9[1]-f10[1]-f12[1]-f14[1]-f15[1]-f16[1])-mu)*fReciprocal(v1*(1.0+v1));
    else
      phip = phi;
    f5[1]=c2*phip*(v1*(1.0+v1)-v0*(1.0-v0))-c3*phip*v2*v2-0.25*phip*v0*v1+c2*mu;
    f11[1]=c1*phip*(v1*(1.0+v1))-c2*phip*(v0*v0+v2*v2)+c1*mu;
    f13[1]=c2*phip*(v1*(1.0+v1)+v0*(1.0+v0))-c3*phip*v2*v2+0.25*phip*v0*v1+c2*mu;
    f17[1]=c2*phip*(v1*(1.0+v1)+v2*(1.0+v2))-c3*phip*v0*v0+0.25*phip*v1*v2+c2*mu;
    f18[1]=c2*phip*(v1*(1.0+v1)-v2*(1.0-v2))-c3*phip*v0*v0-0.25*phip*v1*v2+c2*mu;
  }
  else {
    phi = 0.0;
    omegat = omega[0];
    d2rdx2 = drdx*drdx;
    d2rdy2 = drdy*drdy;
    d2rdz2 = drdz*drdz;
    d2rdxdy = drdx*drdy;
//  d2rdxdz = drdx*drdz;   // this gradient not required for this boundary
    d2rdydz = drdy*drdz;
    nabrp = rho*nabr;
  }
  pb = fGetBulkPressureSwift(rho, phi, T);
  lambda = fGetLambdaSwift(rho, omegat, T);
  rhop = (2.0*(rho*v1+f2[0]+f4[0]+f8[0]+f9[0]+f14[0])-force[1]-pb+lbkappa*(nabrp+0.5*(d2rdx2+d2rdz2-d2rdy2))-lambda*(2.0*v0*drdx+4.0*v1*drdy+2.0*v2*drdz))*fReciprocal(v1*(1.0+v1));
  if(rhop<lbevaplim)
    rhop = rho;
  v0t = (6.0*(rho*v0+f1[0]+f4[0]+f6[0]+f7[0]-f10[0]-f14[0]-f15[0]-f16[0])-3.0*force[0]-3.0*lambda*(v1*drdx+v0*drdy)-3.0*lbkappa*d2rdxdy)*fReciprocal(rhop*(1.0+3.0*v1));
  v2t = (6.0*(rho*v2+f3[0]+f6[0]-f7[0]+f8[0]-f9[0]-f12[0]-f15[0]+f16[0])-3.0*force[2]-3.0*lambda*(v2*drdy+v1*drdz)-3.0*lbkappa*d2rdydz)*fReciprocal(rhop*(1.0+3.0*v1));
  f5[0]=c2*rhop*(v0t*(v0t-1.0)+v1*(v1+1.0))-c3*rhop*v2t*v2t-0.25*rhop*v0t*v1
        +lambda*(0.375*(v0*drdx+v1*drdy)+0.125*v2*drdz-0.25*(v1*drdx+v0*drdy))+c2*(pb-lbkappa*nabrp)
        +lbkappa*(c2*d2rdz2-c3*(d2rdx2+d2rdy2)-0.25*d2rdxdy);
  f11[0]=c1*rhop*(v1*(v1+1.0))-c2*rhop*(v0t*v0t+v2t*v2t)+0.5*lambda*v1*drdy+c1*(pb-lbkappa*nabrp)
         +lbkappa*(5.0*c2*d2rdy2-c0*(d2rdx2+d2rdz2));
  f13[0]=c2*rhop*(v0t*(v0t+1.0)+v1*(v1+1.0))-c3*rhop*v2t*v2t+0.25*rhop*v0t*v1
         +lambda*(0.375*(v0*drdx+v1*drdy)+0.125*v2*drdz+0.25*(v1*drdx+v0*drdy))+c2*(pb-lbkappa*nabrp)
         +lbkappa*(c2*d2rdz2-c3*(d2rdx2+d2rdy2)+0.25*d2rdxdy);
  f17[0]=c2*rhop*(v1*(v1+1.0)+v2t*(v2t+1.0))-c3*rhop*v0t*v0t+0.25*rhop*v1*v2t
         +lambda*(0.375*(v1*drdy+v2*drdz)+0.125*v0*drdx+0.25*(v2*drdy+v1*drdz))+c2*(pb-lbkappa*nabrp)
         +lbkappa*(c2*d2rdx2-c3*(d2rdy2+d2rdz2)+0.25*d2rdydz);
  f18[0]=c2*rhop*(v1*(v1+1.0)+v2t*(v2t-1.0))-c3*rhop*v0t*v0t-0.25*rhop*v1*v2t
         +lambda*(0.375*(v1*drdy+v2*drdz)+0.125*v0*drdx-0.25*(v2*drdy+v1*drdz))+c2*(pb-lbkappa*nabrp)
         +lbkappa*(c2*d2rdx2-c3*(d2rdy2+d2rdz2)-0.25*d2rdydz);
  return 0;
}

int fD3Q19VCESwiftInamuro(double *p, double v0, double v1, double v2, double *force,
                          double *f0, double *f1, double *f2, double *f3, double *f4,
                          double *f5, double *f6, double *f7, double *f8, double *f9,
                          double *f10, double *f11, double *f12, double *f13, double *f14,
                          double *f15, double *f16, double *f17, double *f18,
                          double drdx, double drdy, double drdz, double dpdx, double dpdy, double dpdz,
                          double nabr, double nabp, double *omega, double T)
{

  // produce fixed velocity for compressible/incompressible fluids at concave edge boundary:
  // expressed for bottom left edge (VCETR)
  double rho, phi, omegat, pb, mu, lambda, d2rdx2, d2rdy2, d2rdz2, d2rdxdy, d2rdxdz, d2rdydz, nabrp, rhop, phip, v2t;
  double c0=1.0/3.0,c1=1.0/6.0,c2=1.0/12.0,c3=1.0/24.0;

  rho = p[0];
  if(lbsy.nf>1) {
    phi = p[1];
    omegat = 0.5*(1.0+phi)*omega[0]+0.5*(1.0-phi)*omega[1];
    mu = lbfemob*fGetPotentialSwift(phi, nabp);
    d2rdx2 = (lbfeeos>0)?(drdx*drdx):0.0 + dpdx*dpdx;
    d2rdy2 = (lbfeeos>0)?(drdy*drdy):0.0 + dpdy*dpdy;
    d2rdz2 = (lbfeeos>0)?(drdz*drdz):0.0 + dpdz*dpdz;
    d2rdxdy = (lbfeeos>0)?(drdx*drdy):0.0 + dpdx*dpdy;
    d2rdxdz = (lbfeeos>0)?(drdx*drdz):0.0 + dpdx*dpdz;
    d2rdydz = (lbfeeos>0)?(drdy*drdz):0.0 + dpdy*dpdz;
    nabrp = (lbfeeos>0)?(rho*nabr):0.0 + phi*nabp;
    if(fCppAbs(v0)>0.0 || fCppAbs(v1)>0.0 || fCppAbs(v2)>0.0)
      phip = (24.0*(phi-f0[1]-f1[1]-f2[1]-f3[1]-f4[1]-f6[1]-f7[1]-f8[1]-f9[1]-f10[1]-f12[1]-f14[1]-f15[1]-f16[1])-22.0*mu)*fReciprocal(10.0*(v0+v1+v0*v0+v1*v1)+v2*v2-6.0*v0*v1);
    else
      phip = phi;
    f5[1]=-c2*phip*(v0*(1.0-v0)-v1*(1.0+v1))-c3*phip*v2*v2-0.25*phip*v0*v1+c2*mu;
    f10[1]=c1*phip*(v0*(1.0+v0))-c2*phip*(v1*v1+v2*v2)+c1*mu;
    f11[1]=c1*phip*(v1*(1.0+v1))-c2*phip*(v0*v0+v2*v2)+c1*mu;
    f13[1]=c2*phip*(v0*(1.0+v0)+v1*(1.0+v1))-c3*phip*v2*v2+0.25*phip*v0*v1+c2*mu;
    f14[1]=c2*phip*(v0*(1.0+v0)-v1*(1.0-v1))-c3*phip*v2*v2-0.25*phip*v0*v1+c2*mu;
    f15[1]=c2*phip*(v0*(1.0+v0)+v2*(1.0+v2))-c3*phip*v1*v1+0.25*phip*v0*v2+c2*mu;
    f16[1]=c2*phip*(v0*(1.0+v0)-v2*(1.0-v2))-c3*phip*v1*v1-0.25*phip*v0*v2+c2*mu;
    f17[1]=c2*phip*(v1*(1.0+v1)+v2*(1.0+v2))-c3*phip*v0*v0+0.25*phip*v1*v2+c2*mu;
    f18[1]=c2*phip*(v1*(1.0+v1)-v2*(1.0-v2))-c3*phip*v0*v0-0.25*phip*v1*v2+c2*mu;
  }
  else {
    phi = 0.0;
    omegat = omega[0];
    d2rdx2 = drdx*drdx;
    d2rdy2 = drdy*drdy;
    d2rdz2 = drdz*drdz;
    d2rdxdy = drdx*drdy;
    d2rdxdz = drdx*drdz;
    d2rdydz = drdy*drdz;
    nabrp = rho*nabr;
  }
  pb = fGetBulkPressureSwift(rho, phi, T);
  lambda = fGetLambdaSwift(rho, omegat, T);
  rhop = (12.0*(rho*(1.0-0.5*(v0+v1))-f0[0]-f3[0]-f12[0]-0.5*(f1[0]+f2[0]+f6[0]+f7[0]+f8[0]+f9[0])+0.25*(force[0]+force[1])-0.5*(pb-lbkappa*nabrp)+lbkappa*(0.25*d2rdz2+0.5*d2rdxdy)-lambda*(1.5*v0*drdx+1.5*v1*drdy+v2*drdz-0.5*(v0*drdy+v1*drdx)))*fReciprocal(2.0*(v0+v1)+3.0*(v0*v0+v1*v1-2.0*v0*v1)));
  if(rhop<lbevaplim)
    rhop = rho;
  v2t = (6.0*(rho*v2+f3[0]+f6[0]-f7[0]+f8[0]-f9[0]-f12[0])-3.0*force[2]-3.0*lambda*(v2*(drdx+drdy)+(v0+v1)*drdz)-3.0*lbkappa*(d2rdxdz+d2rdydz))*fReciprocal(rhop*(2.0+3.0*(v0+v1)));
  f5[0]=c2*rhop*(v0*(v0-1.0)+v1*(v1+1.0))-c3*rhop*v2t*v2t-0.25*rhop*v0*v1
        +lambda*(0.375*(v0*drdx+v1*drdy)+0.125*v2*drdz-0.25*(v1*drdx+v0*drdy))+c2*(pb-lbkappa*nabrp)
        +lbkappa*(c2*d2rdz2-c3*(d2rdx2+d2rdy2)+0.25*d2rdxdy);
  f10[0]=c1*rhop*(v0*(v0+1.0))-c2*rhop*(v1*v1+v2t*v2t)+0.5*lambda*v0*drdx+c1*(pb-lbkappa*nabrp)
         +lbkappa*(5.0*c2*d2rdx2-c0*(d2rdy2+d2rdz2));
  f11[0]=c1*rhop*(v1*(v1+1.0))-c2*rhop*(v0*v0+v2t*v2t)+0.5*lambda*v1*drdy+c1*(pb-lbkappa*nabrp)
         +lbkappa*(5.0*c2*d2rdy2-c0*(d2rdx2+d2rdz2));
  f13[0]=c2*rhop*(v0*(v0+1.0)+v1*(v1+1.0))-c3*rhop*v2t*v2t+0.25*rhop*v0*v1
         +lambda*(0.375*(v0*drdx+v1*drdy)+0.125*v2*drdz+0.25*(v1*drdx+v0*drdy))+c2*(pb-lbkappa*nabrp)
         +lbkappa*(c2*d2rdz2-c3*(d2rdx2+d2rdy2)+0.25*d2rdxdy);
  f14[0]=c2*rhop*(v0*(v0+1.0)+v1*(v1-1.0))-c3*rhop*v2t*v2t-0.25*rhop*v0*v1
         +lambda*(0.375*(v0*drdx+v1*drdy)+0.125*v2*drdz-0.25*(v1*drdx+v0*drdy))+c2*(pb-lbkappa*nabrp)
         +lbkappa*(c2*d2rdz2-c3*(d2rdx2+d2rdy2)-0.25*d2rdxdy);
  f15[0]=c2*rhop*(v0*(v0+1.0)+v2t*(v2t+1.0))-c3*rhop*v1*v1+0.25*rhop*v0*v2t
         +lambda*(0.375*(v0*drdx+v2*drdz)+0.125*v1*drdy+0.25*(v2*drdx+v0*drdz))+c2*(pb-lbkappa*nabrp)
         +lbkappa*(c2*d2rdy2-c3*(d2rdx2+d2rdz2)+0.25*d2rdxdz);
  f16[0]=c2*rhop*(v0*(v0+1.0)+v2t*(v2t-1.0))-c3*rhop*v1*v1-0.25*rhop*v0*v2t
         +lambda*(0.375*(v0*drdx+v2*drdz)+0.125*v1*drdy-0.25*(v2*drdx+v0*drdz))+c2*(pb-lbkappa*nabrp)
         +lbkappa*(c2*d2rdy2-c3*(d2rdx2+d2rdz2)-0.25*d2rdxdz);
  f17[0]=c2*rhop*(v1*(v1+1.0)+v2t*(v2t+1.0))-c3*rhop*v0*v0+0.25*rhop*v1*v2t
         +lambda*(0.375*(v1*drdy+v2*drdz)+0.125*v0*drdx+0.25*(v2*drdy+v1*drdz))+c2*(pb-lbkappa*nabrp)
         +lbkappa*(c2*d2rdx2-c3*(d2rdy2+d2rdz2)+0.25*d2rdydz);
  f18[0]=c2*rhop*(v1*(v1+1.0)+v2t*(v2t-1.0))-c3*rhop*v0*v0-0.25*rhop*v1*v2t
         +lambda*(0.375*(v1*drdy+v2*drdz)+0.125*v0*drdx-0.25*(v2*drdy+v1*drdz))+c2*(pb-lbkappa*nabrp)
         +lbkappa*(c2*d2rdx2-c3*(d2rdy2+d2rdz2)-0.25*d2rdydz);
  return 0;
}

int fD3Q19VCCSwiftInamuro(double *p, double v0, double v1, double v2, double *force,
                          double *f0, double *f1, double *f2, double *f3, double *f4,
                          double *f5, double *f6, double *f7, double *f8, double *f9,
                          double *f10, double *f11, double *f12, double *f13, double *f14,
                          double *f15, double *f16, double *f17, double *f18,
                          double drdx, double drdy, double drdz, double dpdx, double dpdy, double dpdz,
                          double nabr, double nabp, double *omega, double T)
{

  // produce fixed velocity for compressible/incompressible fluids at concave corner boundary:
  // expressed for bottom left back corner (VCETRF)
  double rho, phi, omegat, pb, mu, lambda, d2rdx2, d2rdy2, d2rdz2, d2rdxdy, d2rdxdz, d2rdydz, nabrp, rhop, phip;
  double c0=1.0/3.0,c1=1.0/6.0,c2=1.0/12.0,c3=1.0/24.0;

  rho = p[0];
  if(lbsy.nf>1) {
    phi = p[1];
    omegat = 0.5*(1.0+phi)*omega[0]+0.5*(1.0-phi)*omega[1];
    mu = lbfemob*fGetPotentialSwift(phi, nabp);
    d2rdx2 = (lbfeeos>0)?(drdx*drdx):0.0 + dpdx*dpdx;
    d2rdy2 = (lbfeeos>0)?(drdy*drdy):0.0 + dpdy*dpdy;
    d2rdz2 = (lbfeeos>0)?(drdz*drdz):0.0 + dpdz*dpdz;
    d2rdxdy = (lbfeeos>0)?(drdx*drdy):0.0 + dpdx*dpdy;
    d2rdxdz = (lbfeeos>0)?(drdx*drdz):0.0 + dpdx*dpdz;
    d2rdydz = (lbfeeos>0)?(drdy*drdz):0.0 + dpdy*dpdz;
    nabrp = (lbfeeos>0)?(rho*nabr):0.0 + phi*nabp;
    if(fCppAbs(v0)>0.0 || fCppAbs(v1)>0.0 || fCppAbs(v2)>0.0)
      phip = (24.0*(phi-f0[1]-f1[1]-f2[1]-f3[1]-f4[1]-f6[1]-f8[1])-30.0*mu)*fReciprocal(8.0*(v0+v1+v2)+9.0*(v0*v0+v1*v1+v2*v2)-6.0*(v0*v1+v0*v2+v1*v2));
    else
      phip = phi;
    f5[1]=-c2*phip*(v0*(1.0-v0)-v1*(1.0+v1))-c3*phip*v2*v2-0.25*phip*v0*v1+c2*mu;
    f7[1]=-c2*phip*(v0*(1.0-v0)-v2*(1.0+v2))-c3*phip*v1*v1-0.25*phip*v0*v2+c2*mu;
    f9[1]=-c2*phip*(v1*(1.0-v1)-v2*(1.0+v2))-c3*phip*v0*v0-0.25*phip*v1*v2+c2*mu;
    f10[1]=c1*phip*(v0*(1.0+v0))-c2*phip*(v1*v1+v2*v2)+c1*mu;
    f11[1]=c1*phip*(v1*(1.0+v1))-c2*phip*(v0*v0+v2*v2)+c1*mu;
    f12[1]=c1*phip*(v2*(1.0+v2))-c2*phip*(v0*v0+v1*v1)+c1*mu;
    f13[1]=c2*phip*(v0*(1.0+v0)+v1*(1.0+v1))-c3*phip*v2*v2+0.25*phip*v0*v1+c2*mu;
    f14[1]=c2*phip*(v0*(1.0+v0)-v1*(1.0-v1))-c3*phip*v2*v2-0.25*phip*v0*v1+c2*mu;
    f15[1]=c2*phip*(v0*(1.0+v0)+v2*(1.0+v2))-c3*phip*v1*v1+0.25*phip*v0*v2+c2*mu;
    f16[1]=c2*phip*(v0*(1.0+v0)-v2*(1.0-v2))-c3*phip*v1*v1-0.25*phip*v0*v2+c2*mu;
    f17[1]=c2*phip*(v1*(1.0+v1)+v2*(1.0+v2))-c3*phip*v0*v0+0.25*phip*v1*v2+c2*mu;
    f18[1]=c2*phip*(v1*(1.0+v1)-v2*(1.0-v2))-c3*phip*v0*v0-0.25*phip*v1*v2+c2*mu;
  }
  else {
    phi = 0.0;
    omegat = omega[0];
    d2rdx2 = drdx*drdx;
    d2rdy2 = drdy*drdy;
    d2rdz2 = drdz*drdz;
    d2rdxdy = drdx*drdy;
    d2rdxdz = drdx*drdz;
    d2rdydz = drdy*drdz;
    nabrp = rho*nabr;
  }
  pb = fGetBulkPressureSwift(rho, phi, T);
  lambda = fGetLambdaSwift(rho, omegat, T);
  rhop = 12.0*(rho*(1.0+0.5*(v0+v1+v2))-f0[0]-c0*(f1[0]+f2[0]+f3[0])-0.25*(force[0]+force[1]+force[2])-1.75*(pb-lbkappa*nabrp)+0.375*lbkappa*(d2rdx2+d2rdy2+d2rdz2)-4.75*lambda*(v0*drdx+v1*drdy+v2*drdz))*fReciprocal(7.0*(v0+v1+v2)+6.0*(v0*v0+v1*v1+v2*v2));
  if(rhop<lbevaplim)
    rhop = rho;
  f5[0]=c2*rhop*(v0*(v0-1.0)+v1*(v1+1.0))-c3*rhop*v2*v2-0.25*rhop*v0*v1
        +lambda*(0.375*(v0*drdx+v1*drdy)+0.125*v2*drdz-0.25*(v1*drdx+v0*drdy))+c2*(pb-lbkappa*nabrp)
        +lbkappa*(c2*d2rdz2-c3*(d2rdx2+d2rdy2)+0.25*d2rdxdy);
  f7[0]=c2*rhop*(v0*(v0-1.0)+v2*(v2+1.0))-c3*rhop*v1*v1-0.25*rhop*v0*v2
        +lambda*(0.375*(v0*drdx+v2*drdz)+0.125*v1*drdy-0.25*(v2*drdx+v0*drdz))+c2*(pb-lbkappa*nabrp)
        +lbkappa*(c2*d2rdy2-c3*(d2rdx2+d2rdz2)+0.25*d2rdxdz);
  f9[0]=c2*rhop*(v1*(v1-1.0)+v2*(v2+1.0))-c3*rhop*v0*v0-0.25*rhop*v1*v2
        +lambda*(0.375*(v1*drdy+v2*drdz)+0.125*v0*drdx-0.25*(v2*drdy+v1*drdz))+c2*(pb-lbkappa*nabrp)
        +lbkappa*(c2*d2rdx2-c3*(d2rdy2+d2rdz2)+0.25*d2rdydz);
  f10[0]=c1*rhop*(v0*(v0+1.0))-c2*rhop*(v1*v1+v2*v2)+0.5*lambda*v0*drdx+c1*(pb-lbkappa*nabrp)
         +lbkappa*(5.0*c2*d2rdx2-c0*(d2rdy2+d2rdz2));
  f11[0]=c1*rhop*(v1*(v1+1.0))-c2*rhop*(v0*v0+v2*v2)+0.5*lambda*v1*drdy+c1*(pb-lbkappa*nabrp)
         +lbkappa*(5.0*c2*d2rdy2-c0*(d2rdx2+d2rdz2));
  f12[0]=c1*rhop*(v2*(v2+1.0))-c2*rhop*(v0*v0+v1*v1)+0.5*lambda*v2*drdz+c1*(pb-lbkappa*nabrp)
         +lbkappa*(5.0*c2*d2rdz2-c0*(d2rdx2+d2rdy2));
  f13[0]=c2*rhop*(v0*(v0+1.0)+v1*(v1+1.0))-c3*rhop*v2*v2+0.25*rhop*v0*v1
         +lambda*(0.375*(v0*drdx+v1*drdy)+0.125*v2*drdz+0.25*(v1*drdx+v0*drdy))+c2*(pb-lbkappa*nabrp)
         +lbkappa*(c2*d2rdz2-c3*(d2rdx2+d2rdy2)+0.25*d2rdxdy);
  f14[0]=c2*rhop*(v0*(v0+1.0)+v1*(v1-1.0))-c3*rhop*v2*v2-0.25*rhop*v0*v1
         +lambda*(0.375*(v0*drdx+v1*drdy)+0.125*v2*drdz-0.25*(v1*drdx+v0*drdy))+c2*(pb-lbkappa*nabrp)
         +lbkappa*(c2*d2rdz2-c3*(d2rdx2+d2rdy2)-0.25*d2rdxdy);
  f15[0]=c2*rhop*(v0*(v0+1.0)+v2*(v2+1.0))-c3*rhop*v1*v1+0.25*rhop*v0*v2
         +lambda*(0.375*(v0*drdx+v2*drdz)+0.125*v1*drdy+0.25*(v2*drdx+v0*drdz))+c2*(pb-lbkappa*nabrp)
         +lbkappa*(c2*d2rdy2-c3*(d2rdx2+d2rdz2)+0.25*d2rdxdz);
  f16[0]=c2*rhop*(v0*(v0+1.0)+v2*(v2-1.0))-c3*rhop*v1*v1-0.25*rhop*v0*v2
         +lambda*(0.375*(v0*drdx+v2*drdz)+0.125*v1*drdy-0.25*(v2*drdx+v0*drdz))+c2*(pb-lbkappa*nabrp)
         +lbkappa*(c2*d2rdy2-c3*(d2rdx2+d2rdz2)-0.25*d2rdxdz);
  f17[0]=c2*rhop*(v1*(v1+1.0)+v2*(v2+1.0))-c3*rhop*v0*v0+0.25*rhop*v1*v2
         +lambda*(0.375*(v1*drdy+v2*drdz)+0.125*v0*drdx+0.25*(v2*drdy+v1*drdz))+c2*(pb-lbkappa*nabrp)
         +lbkappa*(c2*d2rdx2-c3*(d2rdy2+d2rdz2)+0.25*d2rdydz);
  f18[0]=c2*rhop*(v1*(v1+1.0)+v2*(v2-1.0))-c3*rhop*v0*v0-0.25*rhop*v1*v2
         +lambda*(0.375*(v1*drdy+v2*drdz)+0.125*v0*drdx-0.25*(v2*drdy+v1*drdz))+c2*(pb-lbkappa*nabrp)
         +lbkappa*(c2*d2rdx2-c3*(d2rdy2+d2rdz2)-0.25*d2rdydz);
  return 0;
}

int fD3Q19VFInamuro(long tpos, long rpos, int prop, double *uwall, double dx, double dy, double dz, double T)
{
  long spos=tpos * lbsitelength;
  int qdim=lbsy.nf+lbsy.nc+lbsy.nt;
  double drdx, drdy, drdz, dpdx, dpdy, dpdz, nabr, nabp;
  double force[3*lbsy.nf], rho[lbsy.nf];

  fD3Q19BoundaryForceVelocity(force, tpos, rpos, dx, dy, dz, uwall, prop);
    
  if(interact==20) {
    drdx = lbft[4*lbsy.nf*rpos  ];
    drdy = lbft[4*lbsy.nf*rpos+1];
    drdz = lbft[4*lbsy.nf*rpos+2];
    nabr = lbft[4*lbsy.nf*tpos+3];
    dpdx = (lbsy.nf>1)?lbft[4*lbsy.nf*rpos+4]:0.0;
    dpdy = (lbsy.nf>1)?lbft[4*lbsy.nf*rpos+5]:0.0;
    dpdz = (lbsy.nf>1)?lbft[4*lbsy.nf*rpos+6]:0.0;
    nabp = (lbsy.nf>1)?lbft[4*lbsy.nf*tpos+7]:0.0;
  }
  else {
    drdx = 0.0;
    drdy = 0.0;
    drdz = 0.0;
    nabr = 0.0;
    dpdx = 0.0;
    dpdy = 0.0;
    dpdz = 0.0;
    nabp = 0.0;
  }
    
  if(prop>26) {
    fGetAllMassSite(rho, &lbf[rpos*lbsitelength]);
    if(interact==20) {
      rho[0] += (dx*drdx+dy*drdy+dz*drdz);
      if(lbsy.nf>1)
        rho[1] += (dx*dpdx+dy*dpdy+dz*dpdz);
    }
  }
    
  if(interact==20) {
    switch (prop) {
      case PST:
        fD3Q19VPSSwiftInamuro(uwall[0], uwall[1], uwall[2], &force[0], &lbf[spos], &lbf[spos+1*qdim],
                              &lbf[spos+2*qdim], &lbf[spos+3*qdim], &lbf[spos+4*qdim], &lbf[spos+5*qdim],
                              &lbf[spos+6*qdim], &lbf[spos+7*qdim], &lbf[spos+8*qdim], &lbf[spos+9*qdim],
                              &lbf[spos+10*qdim], &lbf[spos+11*qdim], &lbf[spos+12*qdim], &lbf[spos+13*qdim],
                              &lbf[spos+14*qdim], &lbf[spos+15*qdim], &lbf[spos+16*qdim], &lbf[spos+17*qdim],
                              &lbf[spos+18*qdim], drdx, drdy, drdz, dpdx, dpdy, dpdz, nabr, nabp,
                              &lbomega[lbsy.nf*tpos], T);
        break;
      case PSD:
        fD3Q19VPSSwiftInamuro(-uwall[0], -uwall[1], -uwall[2], &force[0], &lbf[spos], &lbf[spos+10*qdim],
                              &lbf[spos+11*qdim], &lbf[spos+12*qdim], &lbf[spos+13*qdim], &lbf[spos+14*qdim],
                              &lbf[spos+15*qdim], &lbf[spos+16*qdim], &lbf[spos+17*qdim], &lbf[spos+18*qdim],
                              &lbf[spos+1*qdim], &lbf[spos+2*qdim], &lbf[spos+3*qdim], &lbf[spos+4*qdim],
                              &lbf[spos+5*qdim], &lbf[spos+6*qdim], &lbf[spos+7*qdim], &lbf[spos+8*qdim],
                              &lbf[spos+9*qdim], -drdx, -drdy, -drdz, -dpdx, -dpdy, -dpdz, nabr, nabp,
                              &lbomega[lbsy.nf*tpos], T);
        break;
      case PSL:
        fD3Q19VPSSwiftInamuro(-uwall[2], -uwall[0], -uwall[1], &force[0], &lbf[spos], &lbf[spos+12*qdim],
                              &lbf[spos+10*qdim], &lbf[spos+11*qdim], &lbf[spos+15*qdim], &lbf[spos+7*qdim],
                              &lbf[spos+17*qdim], &lbf[spos+9*qdim], &lbf[spos+13*qdim], &lbf[spos+14*qdim],
                              &lbf[spos+3*qdim], &lbf[spos+1*qdim], &lbf[spos+2*qdim], &lbf[spos+6*qdim],
                              &lbf[spos+16*qdim], &lbf[spos+8*qdim], &lbf[spos+18*qdim], &lbf[spos+4*qdim],
                              &lbf[spos+5*qdim], -drdz, -drdx, -drdy, -dpdz, -dpdx, -dpdy, nabr, nabp,
                              &lbomega[lbsy.nf*tpos], T);
        break;
      case PSR:
        fD3Q19VPSSwiftInamuro(uwall[2], uwall[0], uwall[1], &force[0], &lbf[spos], &lbf[spos+3*qdim],
                              &lbf[spos+1*qdim], &lbf[spos+2*qdim], &lbf[spos+6*qdim], &lbf[spos+16*qdim],
                              &lbf[spos+8*qdim], &lbf[spos+18*qdim], &lbf[spos+4*qdim], &lbf[spos+5*qdim],
                              &lbf[spos+12*qdim], &lbf[spos+10*qdim], &lbf[spos+11*qdim], &lbf[spos+15*qdim],
                              &lbf[spos+7*qdim], &lbf[spos+17*qdim], &lbf[spos+9*qdim], &lbf[spos+13*qdim],
                              &lbf[spos+14*qdim], drdz, drdx, drdy, dpdz, dpdx, dpdy, nabr, nabp,
                              &lbomega[lbsy.nf*tpos], T);
        break;
      case PSF:
        fD3Q19VPSSwiftInamuro(-uwall[1], -uwall[2], -uwall[0], &force[0], &lbf[spos], &lbf[spos+11*qdim],
                              &lbf[spos+12*qdim], &lbf[spos+10*qdim], &lbf[spos+17*qdim], &lbf[spos+18*qdim],
                              &lbf[spos+13*qdim], &lbf[spos+5*qdim], &lbf[spos+15*qdim], &lbf[spos+7*qdim],
                              &lbf[spos+2*qdim], &lbf[spos+3*qdim], &lbf[spos+1*qdim], &lbf[spos+8*qdim],
                              &lbf[spos+9*qdim], &lbf[spos+4*qdim], &lbf[spos+14*qdim], &lbf[spos+6*qdim],
                              &lbf[spos+16*qdim], -drdy, -drdz, -drdx, -dpdy, -dpdz, -dpdx, nabr, nabp,
                              &lbomega[lbsy.nf*tpos], T);
        break;
      case PSB:
        fD3Q19VPSSwiftInamuro(uwall[1], uwall[2], uwall[0], &force[0], &lbf[spos], &lbf[spos+2*qdim],
                              &lbf[spos+3*qdim], &lbf[spos+1*qdim], &lbf[spos+8*qdim], &lbf[spos+9*qdim],
                              &lbf[spos+4*qdim], &lbf[spos+14*qdim], &lbf[spos+6*qdim], &lbf[spos+16*qdim],
                              &lbf[spos+11*qdim], &lbf[spos+12*qdim], &lbf[spos+10*qdim], &lbf[spos+17*qdim],
                              &lbf[spos+18*qdim], &lbf[spos+13*qdim], &lbf[spos+5*qdim], &lbf[spos+15*qdim],
                              &lbf[spos+7*qdim], drdy, drdz, drdx, dpdy, dpdz, dpdx, nabr, nabp,
                              &lbomega[lbsy.nf*tpos], T);
        break;
      case CCTRB:
        fD3Q19VCCSwiftInamuro(rho, uwall[0], uwall[1], -uwall[2], &force[0], &lbf[spos], &lbf[spos+1*qdim],
                              &lbf[spos+2*qdim], &lbf[spos+12*qdim], &lbf[spos+4*qdim], &lbf[spos+5*qdim],
                              &lbf[spos+7*qdim], &lbf[spos+6*qdim], &lbf[spos+9*qdim], &lbf[spos+8*qdim],
                              &lbf[spos+10*qdim], &lbf[spos+11*qdim], &lbf[spos+3*qdim], &lbf[spos+13*qdim],
                              &lbf[spos+14*qdim], &lbf[spos+16*qdim], &lbf[spos+15*qdim], &lbf[spos+18*qdim],
                              &lbf[spos+17*qdim], drdx, drdy, -drdz, dpdx, dpdy, -dpdz, nabr, nabp,
                              &lbomega[lbsy.nf*tpos], T);
        break;
      case CCTLB:
        fD3Q19VCCSwiftInamuro(rho, -uwall[0], uwall[1], -uwall[2], &force[0], &lbf[spos], &lbf[spos+10*qdim],
                              &lbf[spos+2*qdim], &lbf[spos+12*qdim], &lbf[spos+14*qdim], &lbf[spos+13*qdim],
                              &lbf[spos+15*qdim], &lbf[spos+16*qdim], &lbf[spos+9*qdim], &lbf[spos+8*qdim],
                              &lbf[spos+1*qdim], &lbf[spos+11*qdim], &lbf[spos+3*qdim], &lbf[spos+5*qdim],
                              &lbf[spos+4*qdim], &lbf[spos+6*qdim], &lbf[spos+7*qdim], &lbf[spos+18*qdim],
                              &lbf[spos+17*qdim], -drdx, drdy, -drdz, -dpdx, dpdy, -dpdz, nabr, nabp,
                              &lbomega[lbsy.nf*tpos], T);
        break;
      case CCDLB:
        fD3Q19VCCSwiftInamuro(rho, -uwall[0], -uwall[1], -uwall[2], &force[0], &lbf[spos], &lbf[spos+10*qdim],
                              &lbf[spos+11*qdim], &lbf[spos+12*qdim], &lbf[spos+13*qdim], &lbf[spos+14*qdim],
                              &lbf[spos+15*qdim], &lbf[spos+16*qdim], &lbf[spos+17*qdim], &lbf[spos+18*qdim],
                              &lbf[spos+1*qdim], &lbf[spos+2*qdim], &lbf[spos+3*qdim], &lbf[spos+4*qdim],
                              &lbf[spos+5*qdim], &lbf[spos+6*qdim], &lbf[spos+7*qdim], &lbf[spos+8*qdim],
                              &lbf[spos+9*qdim], -drdx, -drdy, -drdz, -dpdx, -dpdy, -dpdz, nabr, nabp,
                              &lbomega[lbsy.nf*tpos], T);
        break;
      case CCDRB:
        fD3Q19VCCSwiftInamuro(rho, uwall[0], -uwall[1], -uwall[2], &force[0], &lbf[spos], &lbf[spos+1*qdim],
                              &lbf[spos+11*qdim], &lbf[spos+12*qdim], &lbf[spos+5*qdim], &lbf[spos+4*qdim],
                              &lbf[spos+7*qdim], &lbf[spos+6*qdim], &lbf[spos+17*qdim], &lbf[spos+18*qdim],
                              &lbf[spos+10*qdim], &lbf[spos+2*qdim], &lbf[spos+3*qdim], &lbf[spos+14*qdim],
                              &lbf[spos+13*qdim], &lbf[spos+16*qdim], &lbf[spos+15*qdim], &lbf[spos+8*qdim],
                              &lbf[spos+9*qdim], drdx, -drdy, -drdz, dpdx, -dpdy, -dpdz, nabr, nabp,
                              &lbomega[lbsy.nf*tpos], T);
        break;
      case CCTRF:
        fD3Q19VCCSwiftInamuro(rho, uwall[0], uwall[1], uwall[2], &force[0], &lbf[spos], &lbf[spos+1*qdim],
                              &lbf[spos+2*qdim], &lbf[spos+3*qdim], &lbf[spos+4*qdim], &lbf[spos+5*qdim],
                              &lbf[spos+6*qdim], &lbf[spos+7*qdim], &lbf[spos+8*qdim], &lbf[spos+9*qdim],
                              &lbf[spos+10*qdim], &lbf[spos+11*qdim], &lbf[spos+12*qdim], &lbf[spos+13*qdim],
                              &lbf[spos+14*qdim], &lbf[spos+15*qdim], &lbf[spos+16*qdim], &lbf[spos+17*qdim],
                              &lbf[spos+18*qdim], drdx, drdy, drdz, dpdx, dpdy, dpdz, nabr, nabp,
                              &lbomega[lbsy.nf*tpos], T);
        break;
      case CCTLF:
        fD3Q19VCCSwiftInamuro(rho, -uwall[0], uwall[1], uwall[2], &force[0], &lbf[spos], &lbf[spos+10*qdim],
                              &lbf[spos+2*qdim], &lbf[spos+3*qdim], &lbf[spos+14*qdim], &lbf[spos+13*qdim],
                              &lbf[spos+16*qdim], &lbf[spos+15*qdim], &lbf[spos+8*qdim], &lbf[spos+9*qdim],
                              &lbf[spos+1*qdim], &lbf[spos+11*qdim], &lbf[spos+12*qdim], &lbf[spos+5*qdim],
                              &lbf[spos+4*qdim], &lbf[spos+7*qdim], &lbf[spos+6*qdim], &lbf[spos+17*qdim],
                              &lbf[spos+18*qdim], -drdx, drdy, drdz, -dpdx, dpdy, dpdz, nabr, nabp,
                              &lbomega[lbsy.nf*tpos], T);
        break;
      case CCDLF:
        fD3Q19VCCSwiftInamuro(rho, -uwall[0], -uwall[1], uwall[2], &force[0], &lbf[spos], &lbf[spos+10*qdim],
                              &lbf[spos+11*qdim], &lbf[spos+3*qdim], &lbf[spos+13*qdim], &lbf[spos+14*qdim],
                              &lbf[spos+16*qdim], &lbf[spos+15*qdim], &lbf[spos+18*qdim], &lbf[spos+17*qdim],
                              &lbf[spos+1*qdim], &lbf[spos+2*qdim], &lbf[spos+12*qdim], &lbf[spos+4*qdim],
                              &lbf[spos+5*qdim], &lbf[spos+7*qdim], &lbf[spos+6*qdim], &lbf[spos+9*qdim],
                              &lbf[spos+8*qdim], -drdx, -drdy, drdz, -dpdx, -dpdy, dpdz, nabr, nabp,
                              &lbomega[lbsy.nf*tpos], T);
        break;
      case CCDRF:
        fD3Q19VCCSwiftInamuro(rho, uwall[0], -uwall[1], uwall[2], &force[0], &lbf[spos], &lbf[spos+1*qdim],
                              &lbf[spos+11*qdim], &lbf[spos+3*qdim], &lbf[spos+5*qdim], &lbf[spos+4*qdim],
                              &lbf[spos+6*qdim], &lbf[spos+7*qdim], &lbf[spos+18*qdim], &lbf[spos+17*qdim],
                              &lbf[spos+10*qdim], &lbf[spos+2*qdim], &lbf[spos+12*qdim], &lbf[spos+14*qdim],
                              &lbf[spos+13*qdim], &lbf[spos+15*qdim], &lbf[spos+16*qdim], &lbf[spos+9*qdim],
                              &lbf[spos+8*qdim], drdx, -drdy, drdz, dpdx, -dpdy, dpdz, nabr, nabp,
                              &lbomega[lbsy.nf*tpos], T);
        break;
      case CETR:
        fD3Q19VCESwiftInamuro(rho, uwall[0], uwall[1], uwall[2], &force[0], &lbf[spos], &lbf[spos+1*qdim],
                              &lbf[spos+2*qdim], &lbf[spos+3*qdim], &lbf[spos+4*qdim], &lbf[spos+5*qdim],
                              &lbf[spos+6*qdim], &lbf[spos+7*qdim], &lbf[spos+8*qdim], &lbf[spos+9*qdim],
                              &lbf[spos+10*qdim], &lbf[spos+11*qdim], &lbf[spos+12*qdim], &lbf[spos+13*qdim],
                              &lbf[spos+14*qdim], &lbf[spos+15*qdim], &lbf[spos+16*qdim], &lbf[spos+17*qdim],
                              &lbf[spos+18*qdim], drdx, drdy, drdz, dpdx, dpdy, dpdz, nabr, nabp,
                              &lbomega[lbsy.nf*tpos], T);
        break;
      case CETL:
        fD3Q19VCESwiftInamuro(rho, uwall[1], -uwall[0], uwall[2], &force[0], &lbf[spos], &lbf[spos+2*qdim],
                              &lbf[spos+10*qdim], &lbf[spos+3*qdim], &lbf[spos+14*qdim], &lbf[spos+4*qdim],
                              &lbf[spos+8*qdim], &lbf[spos+9*qdim], &lbf[spos+16*qdim], &lbf[spos+15*qdim],
                              &lbf[spos+11*qdim], &lbf[spos+1*qdim], &lbf[spos+12*qdim], &lbf[spos+5*qdim],
                              &lbf[spos+13*qdim], &lbf[spos+17*qdim], &lbf[spos+18*qdim], &lbf[spos+7*qdim],
                              &lbf[spos+6*qdim], drdy, -drdx, drdz, dpdy, -dpdx, dpdz, nabr, nabp,
                              &lbomega[lbsy.nf*tpos], T);
        break;
      case CEDL:
        fD3Q19VCESwiftInamuro(rho, -uwall[0], -uwall[1], uwall[2], &force[0], &lbf[spos], &lbf[spos+10*qdim],
                              &lbf[spos+11*qdim], &lbf[spos+3*qdim], &lbf[spos+13*qdim], &lbf[spos+14*qdim],
                              &lbf[spos+16*qdim], &lbf[spos+15*qdim], &lbf[spos+18*qdim], &lbf[spos+17*qdim],
                              &lbf[spos+1*qdim], &lbf[spos+2*qdim], &lbf[spos+12*qdim], &lbf[spos+4*qdim],
                              &lbf[spos+5*qdim], &lbf[spos+7*qdim], &lbf[spos+6*qdim], &lbf[spos+9*qdim],
                              &lbf[spos+8*qdim], -drdx, -drdy, drdz, -dpdx, -dpdy, dpdz, nabr, nabp,
                              &lbomega[lbsy.nf*tpos], T);
        break;
      case CEDR:
        fD3Q19VCESwiftInamuro(rho, -uwall[1], uwall[0], uwall[2], &force[0], &lbf[spos], &lbf[spos+11*qdim],
                              &lbf[spos+1*qdim], &lbf[spos+3*qdim], &lbf[spos+5*qdim], &lbf[spos+13*qdim],
                              &lbf[spos+18*qdim], &lbf[spos+17*qdim], &lbf[spos+6*qdim], &lbf[spos+7*qdim],
                              &lbf[spos+2*qdim], &lbf[spos+10*qdim], &lbf[spos+12*qdim], &lbf[spos+14*qdim],
                              &lbf[spos+4*qdim], &lbf[spos+9*qdim], &lbf[spos+8*qdim], &lbf[spos+15*qdim],
                              &lbf[spos+16*qdim], -drdy, drdx, drdz, -dpdy, dpdx, dpdz, nabr, nabp,
                              &lbomega[lbsy.nf*tpos], T);
        break;
      case CETF:
        fD3Q19VCESwiftInamuro(rho, uwall[1], uwall[2], uwall[0], &force[0], &lbf[spos], &lbf[spos+2*qdim],
                              &lbf[spos+3*qdim], &lbf[spos+1*qdim], &lbf[spos+8*qdim], &lbf[spos+9*qdim],
                              &lbf[spos+4*qdim], &lbf[spos+14*qdim], &lbf[spos+6*qdim], &lbf[spos+16*qdim],
                              &lbf[spos+11*qdim], &lbf[spos+12*qdim], &lbf[spos+10*qdim], &lbf[spos+17*qdim],
                              &lbf[spos+18*qdim], &lbf[spos+13*qdim], &lbf[spos+5*qdim], &lbf[spos+15*qdim],
                              &lbf[spos+7*qdim], drdy, drdz, drdx, dpdy, dpdz, dpdx, nabr, nabp,
                              &lbomega[lbsy.nf*tpos], T);
        break;
      case CELF:
        fD3Q19VCESwiftInamuro(rho, -uwall[0], uwall[2], uwall[1], &force[0], &lbf[spos], &lbf[spos+10*qdim],
                              &lbf[spos+3*qdim], &lbf[spos+2*qdim], &lbf[spos+16*qdim], &lbf[spos+15*qdim],
                              &lbf[spos+14*qdim], &lbf[spos+13*qdim], &lbf[spos+8*qdim], &lbf[spos+18*qdim],
                              &lbf[spos+1*qdim], &lbf[spos+12*qdim], &lbf[spos+11*qdim], &lbf[spos+7*qdim],
                              &lbf[spos+6*qdim], &lbf[spos+5*qdim], &lbf[spos+4*qdim], &lbf[spos+17*qdim],
                              &lbf[spos+9*qdim], -drdx, drdz, drdy, -dpdx, dpdz, dpdy, nabr, nabp,
                              &lbomega[lbsy.nf*tpos], T);
        break;
      case CEDF:
        fD3Q19VCESwiftInamuro(rho, -uwall[1], uwall[2], uwall[0], &force[0], &lbf[spos], &lbf[spos+11*qdim],
                              &lbf[spos+3*qdim], &lbf[spos+1*qdim], &lbf[spos+18*qdim], &lbf[spos+17*qdim],
                              &lbf[spos+5*qdim], &lbf[spos+13*qdim], &lbf[spos+6*qdim], &lbf[spos+16*qdim],
                              &lbf[spos+2*qdim], &lbf[spos+12*qdim], &lbf[spos+10*qdim], &lbf[spos+9*qdim],
                              &lbf[spos+8*qdim], &lbf[spos+14*qdim], &lbf[spos+4*qdim], &lbf[spos+15*qdim],
                              &lbf[spos+7*qdim], -drdy, drdz, drdx, -dpdy, dpdz, dpdx, nabr, nabp,
                              &lbomega[lbsy.nf*tpos], T);
        break;
      case CERF:
        fD3Q19VCESwiftInamuro(rho, uwall[0], uwall[2], uwall[1], &force[0], &lbf[spos], &lbf[spos+1*qdim],
                              &lbf[spos+3*qdim], &lbf[spos+2*qdim], &lbf[spos+6*qdim], &lbf[spos+7*qdim],
                              &lbf[spos+4*qdim], &lbf[spos+5*qdim], &lbf[spos+8*qdim], &lbf[spos+18*qdim],
                              &lbf[spos+10*qdim], &lbf[spos+12*qdim], &lbf[spos+11*qdim], &lbf[spos+15*qdim],
                              &lbf[spos+16*qdim], &lbf[spos+13*qdim], &lbf[spos+14*qdim], &lbf[spos+17*qdim],
                              &lbf[spos+9*qdim], drdx, drdz, drdy, dpdx, dpdz, dpdy, nabr, nabp,
                              &lbomega[lbsy.nf*tpos], T);
        break;
      case CETB:
        fD3Q19VCESwiftInamuro(rho, uwall[1], -uwall[2], uwall[0], &force[0], &lbf[spos], &lbf[spos+2*qdim],
                              &lbf[spos+12*qdim], &lbf[spos+1*qdim], &lbf[spos+9*qdim], &lbf[spos+8*qdim],
                              &lbf[spos+4*qdim], &lbf[spos+14*qdim], &lbf[spos+7*qdim], &lbf[spos+15*qdim],
                              &lbf[spos+11*qdim], &lbf[spos+3*qdim], &lbf[spos+10*qdim], &lbf[spos+18*qdim],
                              &lbf[spos+17*qdim], &lbf[spos+13*qdim], &lbf[spos+5*qdim], &lbf[spos+16*qdim],
                              &lbf[spos+6*qdim], drdy, -drdz, drdx, dpdy, -dpdz, dpdx, nabr, nabp,
                              &lbomega[lbsy.nf*tpos], T);
        break;
      case CELB:
        fD3Q19VCESwiftInamuro(rho, -uwall[0], -uwall[2], uwall[1], &force[0], &lbf[spos], &lbf[spos+10*qdim],
                              &lbf[spos+12*qdim], &lbf[spos+2*qdim], &lbf[spos+15*qdim], &lbf[spos+16*qdim],
                              &lbf[spos+14*qdim], &lbf[spos+13*qdim], &lbf[spos+9*qdim], &lbf[spos+17*qdim],
                              &lbf[spos+1*qdim], &lbf[spos+3*qdim], &lbf[spos+11*qdim], &lbf[spos+6*qdim],
                              &lbf[spos+7*qdim], &lbf[spos+5*qdim], &lbf[spos+4*qdim], &lbf[spos+18*qdim],
                              &lbf[spos+8*qdim], -drdx, -drdz, drdy, -dpdx, -dpdz, dpdy, nabr, nabp,
                              &lbomega[lbsy.nf*tpos], T);
        break;
      case CEDB:
        fD3Q19VCESwiftInamuro(rho, -uwall[1], -uwall[2], uwall[0], &force[0], &lbf[spos], &lbf[spos+11*qdim],
                              &lbf[spos+12*qdim], &lbf[spos+1*qdim], &lbf[spos+17*qdim], &lbf[spos+18*qdim],
                              &lbf[spos+5*qdim], &lbf[spos+13*qdim], &lbf[spos+7*qdim], &lbf[spos+15*qdim],
                              &lbf[spos+2*qdim], &lbf[spos+3*qdim], &lbf[spos+10*qdim], &lbf[spos+8*qdim],
                              &lbf[spos+9*qdim], &lbf[spos+14*qdim], &lbf[spos+4*qdim], &lbf[spos+16*qdim],
                              &lbf[spos+6*qdim], -drdy, -drdz, drdx, -dpdy, -dpdz, dpdx, nabr, nabp,
                              &lbomega[lbsy.nf*tpos], T);
        break;
      case CERB:
        fD3Q19VCESwiftInamuro(rho, uwall[0], -uwall[2], uwall[1], &force[0], &lbf[spos], &lbf[spos+1*qdim],
                              &lbf[spos+12*qdim], &lbf[spos+2*qdim], &lbf[spos+7*qdim], &lbf[spos+6*qdim],
                              &lbf[spos+4*qdim], &lbf[spos+5*qdim], &lbf[spos+9*qdim], &lbf[spos+17*qdim],
                              &lbf[spos+10*qdim], &lbf[spos+3*qdim], &lbf[spos+11*qdim], &lbf[spos+16*qdim],
                              &lbf[spos+15*qdim], &lbf[spos+13*qdim], &lbf[spos+14*qdim], &lbf[spos+18*qdim],
                              &lbf[spos+8*qdim], drdx, -drdz, drdy, dpdx, -dpdz, dpdy, nabr, nabp,
                              &lbomega[lbsy.nf*tpos], T);
        break;
    }
  }
  else if (collide>11) {
    switch (prop) {
      case PST:
        fD3Q19VPSCLBEInamuro(uwall[0], uwall[1], uwall[2], &force[0], &lbf[spos], &lbf[spos+1*qdim],
                             &lbf[spos+2*qdim], &lbf[spos+3*qdim], &lbf[spos+4*qdim], &lbf[spos+5*qdim],
                             &lbf[spos+6*qdim], &lbf[spos+7*qdim], &lbf[spos+8*qdim], &lbf[spos+9*qdim],
                             &lbf[spos+10*qdim], &lbf[spos+11*qdim], &lbf[spos+12*qdim], &lbf[spos+13*qdim],
                             &lbf[spos+14*qdim], &lbf[spos+15*qdim], &lbf[spos+16*qdim], &lbf[spos+17*qdim],
                             &lbf[spos+18*qdim]);
        break;
      case PSD:
        fD3Q19VPSCLBEInamuro(-uwall[0], -uwall[1], -uwall[2], &force[0], &lbf[spos], &lbf[spos+10*qdim],
                             &lbf[spos+11*qdim], &lbf[spos+12*qdim], &lbf[spos+13*qdim], &lbf[spos+14*qdim],
                             &lbf[spos+15*qdim], &lbf[spos+16*qdim], &lbf[spos+17*qdim], &lbf[spos+18*qdim],
                             &lbf[spos+1*qdim], &lbf[spos+2*qdim], &lbf[spos+3*qdim], &lbf[spos+4*qdim],
                             &lbf[spos+5*qdim], &lbf[spos+6*qdim], &lbf[spos+7*qdim], &lbf[spos+8*qdim],
                             &lbf[spos+9*qdim]);
        break;
      case PSL:
        fD3Q19VPSCLBEInamuro(-uwall[2], -uwall[0], -uwall[1], &force[0], &lbf[spos], &lbf[spos+12*qdim],
                             &lbf[spos+10*qdim], &lbf[spos+11*qdim], &lbf[spos+15*qdim], &lbf[spos+7*qdim],
                             &lbf[spos+17*qdim], &lbf[spos+9*qdim], &lbf[spos+13*qdim], &lbf[spos+14*qdim],
                             &lbf[spos+3*qdim], &lbf[spos+1*qdim], &lbf[spos+2*qdim], &lbf[spos+6*qdim],
                             &lbf[spos+16*qdim], &lbf[spos+8*qdim], &lbf[spos+18*qdim], &lbf[spos+4*qdim],
                             &lbf[spos+5*qdim]);
        break;
      case PSR:
        fD3Q19VPSCLBEInamuro(uwall[2], uwall[0], uwall[1], &force[0], &lbf[spos], &lbf[spos+3*qdim],
                             &lbf[spos+1*qdim], &lbf[spos+2*qdim], &lbf[spos+6*qdim], &lbf[spos+16*qdim],
                             &lbf[spos+8*qdim], &lbf[spos+18*qdim], &lbf[spos+4*qdim], &lbf[spos+5*qdim],
                             &lbf[spos+12*qdim], &lbf[spos+10*qdim], &lbf[spos+11*qdim], &lbf[spos+15*qdim],
                             &lbf[spos+7*qdim], &lbf[spos+17*qdim], &lbf[spos+9*qdim], &lbf[spos+13*qdim],
                             &lbf[spos+14*qdim]);
        break;
      case PSF:
        fD3Q19VPSCLBEInamuro(-uwall[1], -uwall[2], -uwall[0], &force[0], &lbf[spos], &lbf[spos+11*qdim],
                             &lbf[spos+12*qdim], &lbf[spos+10*qdim], &lbf[spos+17*qdim], &lbf[spos+18*qdim],
                             &lbf[spos+13*qdim], &lbf[spos+5*qdim], &lbf[spos+15*qdim], &lbf[spos+7*qdim],
                             &lbf[spos+2*qdim], &lbf[spos+3*qdim], &lbf[spos+1*qdim], &lbf[spos+8*qdim],
                             &lbf[spos+9*qdim], &lbf[spos+4*qdim], &lbf[spos+14*qdim], &lbf[spos+6*qdim],
                             &lbf[spos+16*qdim]);
        break;
      case PSB:
        fD3Q19VPSCLBEInamuro(uwall[1], uwall[2], uwall[0], &force[0], &lbf[spos], &lbf[spos+2*qdim],
                             &lbf[spos+3*qdim], &lbf[spos+1*qdim], &lbf[spos+8*qdim], &lbf[spos+9*qdim],
                             &lbf[spos+4*qdim], &lbf[spos+14*qdim], &lbf[spos+6*qdim], &lbf[spos+16*qdim],
                             &lbf[spos+11*qdim], &lbf[spos+12*qdim], &lbf[spos+10*qdim], &lbf[spos+17*qdim],
                             &lbf[spos+18*qdim], &lbf[spos+13*qdim], &lbf[spos+5*qdim], &lbf[spos+15*qdim],
                             &lbf[spos+7*qdim]);
        break;
      case CCTRB:
        fD3Q19VCCCLBEInamuro(rho, uwall[0], uwall[1], -uwall[2], &force[0], &lbf[spos], &lbf[spos+1*qdim],
                             &lbf[spos+2*qdim], &lbf[spos+12*qdim], &lbf[spos+4*qdim], &lbf[spos+5*qdim],
                             &lbf[spos+7*qdim], &lbf[spos+6*qdim], &lbf[spos+9*qdim], &lbf[spos+8*qdim],
                             &lbf[spos+10*qdim], &lbf[spos+11*qdim], &lbf[spos+3*qdim], &lbf[spos+13*qdim],
                             &lbf[spos+14*qdim], &lbf[spos+16*qdim], &lbf[spos+15*qdim], &lbf[spos+18*qdim],
                             &lbf[spos+17*qdim]);
        break;
      case CCTLB:
        fD3Q19VCCCLBEInamuro(rho, -uwall[0], uwall[1], -uwall[2], &force[0], &lbf[spos], &lbf[spos+10*qdim],
                             &lbf[spos+2*qdim], &lbf[spos+12*qdim], &lbf[spos+14*qdim], &lbf[spos+13*qdim],
                             &lbf[spos+15*qdim], &lbf[spos+16*qdim], &lbf[spos+9*qdim], &lbf[spos+8*qdim],
                             &lbf[spos+1*qdim], &lbf[spos+11*qdim], &lbf[spos+3*qdim], &lbf[spos+5*qdim],
                             &lbf[spos+4*qdim], &lbf[spos+6*qdim], &lbf[spos+7*qdim], &lbf[spos+18*qdim],
                             &lbf[spos+17*qdim]);
        break;
      case CCDLB:
        fD3Q19VCCCLBEInamuro(rho, -uwall[0], -uwall[1], -uwall[2], &force[0], &lbf[spos], &lbf[spos+10*qdim],
                             &lbf[spos+11*qdim], &lbf[spos+12*qdim], &lbf[spos+13*qdim], &lbf[spos+14*qdim],
                             &lbf[spos+15*qdim], &lbf[spos+16*qdim], &lbf[spos+17*qdim], &lbf[spos+18*qdim],
                             &lbf[spos+1*qdim], &lbf[spos+2*qdim], &lbf[spos+3*qdim], &lbf[spos+4*qdim],
                             &lbf[spos+5*qdim], &lbf[spos+6*qdim], &lbf[spos+7*qdim], &lbf[spos+8*qdim],
                             &lbf[spos+9*qdim]);
        break;
      case CCDRB:
        fD3Q19VCCCLBEInamuro(rho, uwall[0], -uwall[1], -uwall[2], &force[0], &lbf[spos], &lbf[spos+1*qdim],
                             &lbf[spos+11*qdim], &lbf[spos+12*qdim], &lbf[spos+5*qdim], &lbf[spos+4*qdim],
                             &lbf[spos+7*qdim], &lbf[spos+6*qdim], &lbf[spos+17*qdim], &lbf[spos+18*qdim],
                             &lbf[spos+10*qdim], &lbf[spos+2*qdim], &lbf[spos+3*qdim], &lbf[spos+14*qdim],
                             &lbf[spos+13*qdim], &lbf[spos+16*qdim], &lbf[spos+15*qdim], &lbf[spos+8*qdim],
                             &lbf[spos+9*qdim]);
        break;
      case CCTRF:
        fD3Q19VCCCLBEInamuro(rho, uwall[0], uwall[1], uwall[2], &force[0], &lbf[spos], &lbf[spos+1*qdim],
                             &lbf[spos+2*qdim], &lbf[spos+3*qdim], &lbf[spos+4*qdim], &lbf[spos+5*qdim],
                             &lbf[spos+6*qdim], &lbf[spos+7*qdim], &lbf[spos+8*qdim], &lbf[spos+9*qdim],
                             &lbf[spos+10*qdim], &lbf[spos+11*qdim], &lbf[spos+12*qdim], &lbf[spos+13*qdim],
                             &lbf[spos+14*qdim], &lbf[spos+15*qdim], &lbf[spos+16*qdim], &lbf[spos+17*qdim],
                             &lbf[spos+18*qdim]);
        break;
      case CCTLF:
        fD3Q19VCCCLBEInamuro(rho, -uwall[0], uwall[1], uwall[2], &force[0], &lbf[spos], &lbf[spos+10*qdim],
                             &lbf[spos+2*qdim], &lbf[spos+3*qdim], &lbf[spos+14*qdim], &lbf[spos+13*qdim],
                             &lbf[spos+16*qdim], &lbf[spos+15*qdim], &lbf[spos+8*qdim], &lbf[spos+9*qdim],
                             &lbf[spos+1*qdim], &lbf[spos+11*qdim], &lbf[spos+12*qdim], &lbf[spos+5*qdim],
                             &lbf[spos+4*qdim], &lbf[spos+7*qdim], &lbf[spos+6*qdim], &lbf[spos+17*qdim],
                             &lbf[spos+18*qdim]);
        break;
      case CCDLF:
        fD3Q19VCCCLBEInamuro(rho, -uwall[0], -uwall[1], uwall[2], &force[0], &lbf[spos], &lbf[spos+10*qdim],
                             &lbf[spos+11*qdim], &lbf[spos+3*qdim], &lbf[spos+13*qdim], &lbf[spos+14*qdim],
                             &lbf[spos+16*qdim], &lbf[spos+15*qdim], &lbf[spos+18*qdim], &lbf[spos+17*qdim],
                             &lbf[spos+1*qdim], &lbf[spos+2*qdim], &lbf[spos+12*qdim], &lbf[spos+4*qdim],
                             &lbf[spos+5*qdim], &lbf[spos+7*qdim], &lbf[spos+6*qdim], &lbf[spos+9*qdim],
                             &lbf[spos+8*qdim]);
        break;
      case CCDRF:
        fD3Q19VCCCLBEInamuro(rho, uwall[0], -uwall[1], uwall[2], &force[0], &lbf[spos], &lbf[spos+1*qdim],
                             &lbf[spos+11*qdim], &lbf[spos+3*qdim], &lbf[spos+5*qdim], &lbf[spos+4*qdim],
                             &lbf[spos+6*qdim], &lbf[spos+7*qdim], &lbf[spos+18*qdim], &lbf[spos+17*qdim],
                             &lbf[spos+10*qdim], &lbf[spos+2*qdim], &lbf[spos+12*qdim], &lbf[spos+14*qdim],
                             &lbf[spos+13*qdim], &lbf[spos+15*qdim], &lbf[spos+16*qdim], &lbf[spos+9*qdim],
                             &lbf[spos+8*qdim]);
        break;
      case CETR:
        fD3Q19VCECLBEInamuro(rho, uwall[0], uwall[1], uwall[2], &force[0], &lbf[spos], &lbf[spos+1*qdim],
                             &lbf[spos+2*qdim], &lbf[spos+3*qdim], &lbf[spos+4*qdim], &lbf[spos+5*qdim],
                             &lbf[spos+6*qdim], &lbf[spos+7*qdim], &lbf[spos+8*qdim], &lbf[spos+9*qdim],
                             &lbf[spos+10*qdim], &lbf[spos+11*qdim], &lbf[spos+12*qdim], &lbf[spos+13*qdim],
                             &lbf[spos+14*qdim], &lbf[spos+15*qdim], &lbf[spos+16*qdim], &lbf[spos+17*qdim],
                             &lbf[spos+18*qdim]);
        break;
      case CETL:
        fD3Q19VCECLBEInamuro(rho, uwall[1], -uwall[0], uwall[2], &force[0], &lbf[spos], &lbf[spos+2*qdim],
                             &lbf[spos+10*qdim], &lbf[spos+3*qdim], &lbf[spos+14*qdim], &lbf[spos+4*qdim],
                             &lbf[spos+8*qdim], &lbf[spos+9*qdim], &lbf[spos+16*qdim], &lbf[spos+15*qdim],
                             &lbf[spos+11*qdim], &lbf[spos+1*qdim], &lbf[spos+12*qdim], &lbf[spos+5*qdim],
                             &lbf[spos+13*qdim], &lbf[spos+17*qdim], &lbf[spos+18*qdim], &lbf[spos+7*qdim],
                             &lbf[spos+6*qdim]);
        break;
      case CEDL:
        fD3Q19VCECLBEInamuro(rho, -uwall[0], -uwall[1], uwall[2], &force[0], &lbf[spos], &lbf[spos+10*qdim],
                             &lbf[spos+11*qdim], &lbf[spos+3*qdim], &lbf[spos+13*qdim], &lbf[spos+14*qdim],
                             &lbf[spos+16*qdim], &lbf[spos+15*qdim], &lbf[spos+18*qdim], &lbf[spos+17*qdim],
                             &lbf[spos+1*qdim], &lbf[spos+2*qdim], &lbf[spos+12*qdim], &lbf[spos+4*qdim],
                             &lbf[spos+5*qdim], &lbf[spos+7*qdim], &lbf[spos+6*qdim], &lbf[spos+9*qdim],
                             &lbf[spos+8*qdim]);
        break;
      case CEDR:
        fD3Q19VCECLBEInamuro(rho, -uwall[1], uwall[0], uwall[2], &force[0], &lbf[spos], &lbf[spos+11*qdim],
                             &lbf[spos+1*qdim], &lbf[spos+3*qdim], &lbf[spos+5*qdim], &lbf[spos+13*qdim],
                             &lbf[spos+18*qdim], &lbf[spos+17*qdim], &lbf[spos+6*qdim], &lbf[spos+7*qdim],
                             &lbf[spos+2*qdim], &lbf[spos+10*qdim], &lbf[spos+12*qdim], &lbf[spos+14*qdim],
                             &lbf[spos+4*qdim], &lbf[spos+9*qdim], &lbf[spos+8*qdim], &lbf[spos+15*qdim],
                             &lbf[spos+16*qdim]);
        break;
      case CETF:
        fD3Q19VCECLBEInamuro(rho, uwall[1], uwall[2], uwall[0], &force[0], &lbf[spos], &lbf[spos+2*qdim],
                             &lbf[spos+3*qdim], &lbf[spos+1*qdim], &lbf[spos+8*qdim], &lbf[spos+9*qdim],
                             &lbf[spos+4*qdim], &lbf[spos+14*qdim], &lbf[spos+6*qdim], &lbf[spos+16*qdim],
                             &lbf[spos+11*qdim], &lbf[spos+12*qdim], &lbf[spos+10*qdim], &lbf[spos+17*qdim],
                             &lbf[spos+18*qdim], &lbf[spos+13*qdim], &lbf[spos+5*qdim], &lbf[spos+15*qdim],
                             &lbf[spos+7*qdim]);
        break;
      case CELF:
        fD3Q19VCECLBEInamuro(rho, -uwall[0], uwall[2], uwall[1], &force[0], &lbf[spos], &lbf[spos+10*qdim],
                             &lbf[spos+3*qdim], &lbf[spos+2*qdim], &lbf[spos+16*qdim], &lbf[spos+15*qdim],
                             &lbf[spos+14*qdim], &lbf[spos+13*qdim], &lbf[spos+8*qdim], &lbf[spos+18*qdim],
                             &lbf[spos+1*qdim], &lbf[spos+12*qdim], &lbf[spos+11*qdim], &lbf[spos+7*qdim],
                             &lbf[spos+6*qdim], &lbf[spos+5*qdim], &lbf[spos+4*qdim], &lbf[spos+17*qdim],
                             &lbf[spos+9*qdim]);
        break;
      case CEDF:
        fD3Q19VCECLBEInamuro(rho, -uwall[1], uwall[2], uwall[0], &force[0], &lbf[spos], &lbf[spos+11*qdim],
                             &lbf[spos+3*qdim], &lbf[spos+1*qdim], &lbf[spos+18*qdim], &lbf[spos+17*qdim],
                             &lbf[spos+5*qdim], &lbf[spos+13*qdim], &lbf[spos+6*qdim], &lbf[spos+16*qdim],
                             &lbf[spos+2*qdim], &lbf[spos+12*qdim], &lbf[spos+10*qdim], &lbf[spos+9*qdim],
                             &lbf[spos+8*qdim], &lbf[spos+14*qdim], &lbf[spos+4*qdim], &lbf[spos+15*qdim],
                             &lbf[spos+7*qdim]);
        break;
      case CERF:
        fD3Q19VCECLBEInamuro(rho, uwall[0], uwall[2], uwall[1], &force[0], &lbf[spos], &lbf[spos+1*qdim],
                             &lbf[spos+3*qdim], &lbf[spos+2*qdim], &lbf[spos+6*qdim], &lbf[spos+7*qdim],
                             &lbf[spos+4*qdim], &lbf[spos+5*qdim], &lbf[spos+8*qdim], &lbf[spos+18*qdim],
                             &lbf[spos+10*qdim], &lbf[spos+12*qdim], &lbf[spos+11*qdim], &lbf[spos+15*qdim],
                             &lbf[spos+16*qdim], &lbf[spos+13*qdim], &lbf[spos+14*qdim], &lbf[spos+17*qdim],
                             &lbf[spos+9*qdim]);
        break;
      case CETB:
        fD3Q19VCECLBEInamuro(rho, uwall[1], -uwall[2], uwall[0], &force[0], &lbf[spos], &lbf[spos+2*qdim],
                             &lbf[spos+12*qdim], &lbf[spos+1*qdim], &lbf[spos+9*qdim], &lbf[spos+8*qdim],
                             &lbf[spos+4*qdim], &lbf[spos+14*qdim], &lbf[spos+7*qdim], &lbf[spos+15*qdim],
                             &lbf[spos+11*qdim], &lbf[spos+3*qdim], &lbf[spos+10*qdim], &lbf[spos+18*qdim],
                             &lbf[spos+17*qdim], &lbf[spos+13*qdim], &lbf[spos+5*qdim], &lbf[spos+16*qdim],
                             &lbf[spos+6*qdim]);
        break;
      case CELB:
        fD3Q19VCECLBEInamuro(rho, -uwall[0], -uwall[2], uwall[1], &force[0], &lbf[spos], &lbf[spos+10*qdim],
                             &lbf[spos+12*qdim], &lbf[spos+2*qdim], &lbf[spos+15*qdim], &lbf[spos+16*qdim],
                             &lbf[spos+14*qdim], &lbf[spos+13*qdim], &lbf[spos+9*qdim], &lbf[spos+17*qdim],
                             &lbf[spos+1*qdim], &lbf[spos+3*qdim], &lbf[spos+11*qdim], &lbf[spos+6*qdim],
                             &lbf[spos+7*qdim], &lbf[spos+5*qdim], &lbf[spos+4*qdim], &lbf[spos+18*qdim],
                             &lbf[spos+8*qdim]);
        break;
      case CEDB:
        fD3Q19VCECLBEInamuro(rho, -uwall[1], -uwall[2], uwall[0], &force[0], &lbf[spos], &lbf[spos+11*qdim],
                             &lbf[spos+12*qdim], &lbf[spos+1*qdim], &lbf[spos+17*qdim], &lbf[spos+18*qdim],
                             &lbf[spos+5*qdim], &lbf[spos+13*qdim], &lbf[spos+7*qdim], &lbf[spos+15*qdim],
                             &lbf[spos+2*qdim], &lbf[spos+3*qdim], &lbf[spos+10*qdim], &lbf[spos+8*qdim],
                             &lbf[spos+9*qdim], &lbf[spos+14*qdim], &lbf[spos+4*qdim], &lbf[spos+16*qdim],
                             &lbf[spos+6*qdim]);
        break;
      case CERB:
        fD3Q19VCECLBEInamuro(rho, uwall[0], -uwall[2], uwall[1], &force[0], &lbf[spos], &lbf[spos+1*qdim],
                             &lbf[spos+12*qdim], &lbf[spos+2*qdim], &lbf[spos+7*qdim], &lbf[spos+6*qdim],
                             &lbf[spos+4*qdim], &lbf[spos+5*qdim], &lbf[spos+9*qdim], &lbf[spos+17*qdim],
                             &lbf[spos+10*qdim], &lbf[spos+3*qdim], &lbf[spos+11*qdim], &lbf[spos+16*qdim],
                             &lbf[spos+15*qdim], &lbf[spos+13*qdim], &lbf[spos+14*qdim], &lbf[spos+18*qdim],
                             &lbf[spos+8*qdim]);
        break;
    }
  }
  else {
    switch (prop) {
      case PST:
        fD3Q19VPSInamuro(uwall[0], uwall[1], uwall[2], &force[0], &lbf[spos], &lbf[spos+1*qdim],
                         &lbf[spos+2*qdim], &lbf[spos+3*qdim], &lbf[spos+4*qdim], &lbf[spos+5*qdim],
                         &lbf[spos+6*qdim], &lbf[spos+7*qdim], &lbf[spos+8*qdim], &lbf[spos+9*qdim],
                         &lbf[spos+10*qdim], &lbf[spos+11*qdim], &lbf[spos+12*qdim], &lbf[spos+13*qdim],
                         &lbf[spos+14*qdim], &lbf[spos+15*qdim], &lbf[spos+16*qdim], &lbf[spos+17*qdim],
                         &lbf[spos+18*qdim]);
        break;
      case PSD:
        fD3Q19VPSInamuro(-uwall[0], -uwall[1], -uwall[2], &force[0], &lbf[spos], &lbf[spos+10*qdim],
                         &lbf[spos+11*qdim], &lbf[spos+12*qdim], &lbf[spos+13*qdim], &lbf[spos+14*qdim],
                         &lbf[spos+15*qdim], &lbf[spos+16*qdim], &lbf[spos+17*qdim], &lbf[spos+18*qdim],
                         &lbf[spos+1*qdim], &lbf[spos+2*qdim], &lbf[spos+3*qdim], &lbf[spos+4*qdim],
                         &lbf[spos+5*qdim], &lbf[spos+6*qdim], &lbf[spos+7*qdim], &lbf[spos+8*qdim],
                         &lbf[spos+9*qdim]);
        break;
      case PSL:
        fD3Q19VPSInamuro(-uwall[2], -uwall[0], -uwall[1], &force[0], &lbf[spos], &lbf[spos+12*qdim],
                         &lbf[spos+10*qdim], &lbf[spos+11*qdim], &lbf[spos+15*qdim], &lbf[spos+7*qdim],
                         &lbf[spos+17*qdim], &lbf[spos+9*qdim], &lbf[spos+13*qdim], &lbf[spos+14*qdim],
                         &lbf[spos+3*qdim], &lbf[spos+1*qdim], &lbf[spos+2*qdim], &lbf[spos+6*qdim],
                         &lbf[spos+16*qdim], &lbf[spos+8*qdim], &lbf[spos+18*qdim], &lbf[spos+4*qdim],
                         &lbf[spos+5*qdim]);
        break;
      case PSR:
        fD3Q19VPSInamuro(uwall[2], uwall[0], uwall[1], &force[0], &lbf[spos], &lbf[spos+3*qdim],
                         &lbf[spos+1*qdim], &lbf[spos+2*qdim], &lbf[spos+6*qdim], &lbf[spos+16*qdim],
                         &lbf[spos+8*qdim], &lbf[spos+18*qdim], &lbf[spos+4*qdim], &lbf[spos+5*qdim],
                         &lbf[spos+12*qdim], &lbf[spos+10*qdim], &lbf[spos+11*qdim], &lbf[spos+15*qdim],
                         &lbf[spos+7*qdim], &lbf[spos+17*qdim], &lbf[spos+9*qdim], &lbf[spos+13*qdim],
                         &lbf[spos+14*qdim]);
        break;
      case PSF:
        fD3Q19VPSInamuro(-uwall[1], -uwall[2], -uwall[0], &force[0], &lbf[spos], &lbf[spos+11*qdim],
                         &lbf[spos+12*qdim], &lbf[spos+10*qdim], &lbf[spos+17*qdim], &lbf[spos+18*qdim],
                         &lbf[spos+13*qdim], &lbf[spos+5*qdim], &lbf[spos+15*qdim], &lbf[spos+7*qdim],
                         &lbf[spos+2*qdim], &lbf[spos+3*qdim], &lbf[spos+1*qdim], &lbf[spos+8*qdim],
                         &lbf[spos+9*qdim], &lbf[spos+4*qdim], &lbf[spos+14*qdim], &lbf[spos+6*qdim],
                         &lbf[spos+16*qdim]);
        break;
      case PSB:
        fD3Q19VPSInamuro(uwall[1], uwall[2], uwall[0], &force[0], &lbf[spos], &lbf[spos+2*qdim],
                         &lbf[spos+3*qdim], &lbf[spos+1*qdim], &lbf[spos+8*qdim], &lbf[spos+9*qdim],
                         &lbf[spos+4*qdim], &lbf[spos+14*qdim], &lbf[spos+6*qdim], &lbf[spos+16*qdim],
                         &lbf[spos+11*qdim], &lbf[spos+12*qdim], &lbf[spos+10*qdim], &lbf[spos+17*qdim],
                         &lbf[spos+18*qdim], &lbf[spos+13*qdim], &lbf[spos+5*qdim], &lbf[spos+15*qdim],
                         &lbf[spos+7*qdim]);
        break;
      case CCTRB:
        fD3Q19VCCInamuro(rho, uwall[0], uwall[1], -uwall[2], &force[0], &lbf[spos], &lbf[spos+1*qdim],
                         &lbf[spos+2*qdim], &lbf[spos+12*qdim], &lbf[spos+4*qdim], &lbf[spos+5*qdim],
                         &lbf[spos+7*qdim], &lbf[spos+6*qdim], &lbf[spos+9*qdim], &lbf[spos+8*qdim],
                         &lbf[spos+10*qdim], &lbf[spos+11*qdim], &lbf[spos+3*qdim], &lbf[spos+13*qdim],
                         &lbf[spos+14*qdim], &lbf[spos+16*qdim], &lbf[spos+15*qdim], &lbf[spos+18*qdim],
                         &lbf[spos+17*qdim]);
        break;
      case CCTLB:
        fD3Q19VCCInamuro(rho, -uwall[0], uwall[1], -uwall[2], &force[0], &lbf[spos], &lbf[spos+10*qdim],
                         &lbf[spos+2*qdim], &lbf[spos+12*qdim], &lbf[spos+14*qdim], &lbf[spos+13*qdim],
                         &lbf[spos+15*qdim], &lbf[spos+16*qdim], &lbf[spos+9*qdim], &lbf[spos+8*qdim],
                         &lbf[spos+1*qdim], &lbf[spos+11*qdim], &lbf[spos+3*qdim], &lbf[spos+5*qdim],
                         &lbf[spos+4*qdim], &lbf[spos+6*qdim], &lbf[spos+7*qdim], &lbf[spos+18*qdim],
                         &lbf[spos+17*qdim]);
        break;
      case CCDLB:
        fD3Q19VCCInamuro(rho, -uwall[0], -uwall[1], -uwall[2], &force[0], &lbf[spos], &lbf[spos+10*qdim],
                         &lbf[spos+11*qdim], &lbf[spos+12*qdim], &lbf[spos+13*qdim], &lbf[spos+14*qdim],
                         &lbf[spos+15*qdim], &lbf[spos+16*qdim], &lbf[spos+17*qdim], &lbf[spos+18*qdim],
                         &lbf[spos+1*qdim], &lbf[spos+2*qdim], &lbf[spos+3*qdim], &lbf[spos+4*qdim],
                         &lbf[spos+5*qdim], &lbf[spos+6*qdim], &lbf[spos+7*qdim], &lbf[spos+8*qdim],
                         &lbf[spos+9*qdim]);
        break;
      case CCDRB:
        fD3Q19VCCInamuro(rho, uwall[0], -uwall[1], -uwall[2], &force[0], &lbf[spos], &lbf[spos+1*qdim],
                         &lbf[spos+11*qdim], &lbf[spos+12*qdim], &lbf[spos+5*qdim], &lbf[spos+4*qdim],
                         &lbf[spos+7*qdim], &lbf[spos+6*qdim], &lbf[spos+17*qdim], &lbf[spos+18*qdim],
                         &lbf[spos+10*qdim], &lbf[spos+2*qdim], &lbf[spos+3*qdim], &lbf[spos+14*qdim],
                         &lbf[spos+13*qdim], &lbf[spos+16*qdim], &lbf[spos+15*qdim], &lbf[spos+8*qdim],
                         &lbf[spos+9*qdim]);
        break;
      case CCTRF:
        fD3Q19VCCInamuro(rho, uwall[0], uwall[1], uwall[2], &force[0], &lbf[spos], &lbf[spos+1*qdim],
                         &lbf[spos+2*qdim], &lbf[spos+3*qdim], &lbf[spos+4*qdim], &lbf[spos+5*qdim],
                         &lbf[spos+6*qdim], &lbf[spos+7*qdim], &lbf[spos+8*qdim], &lbf[spos+9*qdim],
                         &lbf[spos+10*qdim], &lbf[spos+11*qdim], &lbf[spos+12*qdim], &lbf[spos+13*qdim],
                         &lbf[spos+14*qdim], &lbf[spos+15*qdim], &lbf[spos+16*qdim], &lbf[spos+17*qdim],
                         &lbf[spos+18*qdim]);
        break;
      case CCTLF:
        fD3Q19VCCInamuro(rho, -uwall[0], uwall[1], uwall[2], &force[0], &lbf[spos], &lbf[spos+10*qdim],
                         &lbf[spos+2*qdim], &lbf[spos+3*qdim], &lbf[spos+14*qdim], &lbf[spos+13*qdim],
                         &lbf[spos+16*qdim], &lbf[spos+15*qdim], &lbf[spos+8*qdim], &lbf[spos+9*qdim],
                         &lbf[spos+1*qdim], &lbf[spos+11*qdim], &lbf[spos+12*qdim], &lbf[spos+5*qdim],
                         &lbf[spos+4*qdim], &lbf[spos+7*qdim], &lbf[spos+6*qdim], &lbf[spos+17*qdim],
                         &lbf[spos+18*qdim]);
        break;
      case CCDLF:
        fD3Q19VCCInamuro(rho, -uwall[0], -uwall[1], uwall[2], &force[0], &lbf[spos], &lbf[spos+10*qdim],
                         &lbf[spos+11*qdim], &lbf[spos+3*qdim], &lbf[spos+13*qdim], &lbf[spos+14*qdim],
                         &lbf[spos+16*qdim], &lbf[spos+15*qdim], &lbf[spos+18*qdim], &lbf[spos+17*qdim],
                         &lbf[spos+1*qdim], &lbf[spos+2*qdim], &lbf[spos+12*qdim], &lbf[spos+4*qdim],
                         &lbf[spos+5*qdim], &lbf[spos+7*qdim], &lbf[spos+6*qdim], &lbf[spos+9*qdim],
                         &lbf[spos+8*qdim]);
        break;
      case CCDRF:
        fD3Q19VCCInamuro(rho, uwall[0], -uwall[1], uwall[2], &force[0], &lbf[spos], &lbf[spos+1*qdim],
                         &lbf[spos+11*qdim], &lbf[spos+3*qdim], &lbf[spos+5*qdim], &lbf[spos+4*qdim],
                         &lbf[spos+6*qdim], &lbf[spos+7*qdim], &lbf[spos+18*qdim], &lbf[spos+17*qdim],
                         &lbf[spos+10*qdim], &lbf[spos+2*qdim], &lbf[spos+12*qdim], &lbf[spos+14*qdim],
                         &lbf[spos+13*qdim], &lbf[spos+15*qdim], &lbf[spos+16*qdim], &lbf[spos+9*qdim],
                         &lbf[spos+8*qdim]);
        break;
      case CETR:
        fD3Q19VCEInamuro(rho, uwall[0], uwall[1], uwall[2], &force[0], &lbf[spos], &lbf[spos+1*qdim],
                         &lbf[spos+2*qdim], &lbf[spos+3*qdim], &lbf[spos+4*qdim], &lbf[spos+5*qdim],
                         &lbf[spos+6*qdim], &lbf[spos+7*qdim], &lbf[spos+8*qdim], &lbf[spos+9*qdim],
                         &lbf[spos+10*qdim], &lbf[spos+11*qdim], &lbf[spos+12*qdim], &lbf[spos+13*qdim],
                         &lbf[spos+14*qdim], &lbf[spos+15*qdim], &lbf[spos+16*qdim], &lbf[spos+17*qdim],
                         &lbf[spos+18*qdim]);
        break;
      case CETL:
        fD3Q19VCEInamuro(rho, uwall[1], -uwall[0], uwall[2], &force[0], &lbf[spos], &lbf[spos+2*qdim],
                         &lbf[spos+10*qdim], &lbf[spos+3*qdim], &lbf[spos+14*qdim], &lbf[spos+4*qdim],
                         &lbf[spos+8*qdim], &lbf[spos+9*qdim], &lbf[spos+16*qdim], &lbf[spos+15*qdim],
                         &lbf[spos+11*qdim], &lbf[spos+1*qdim], &lbf[spos+12*qdim], &lbf[spos+5*qdim],
                         &lbf[spos+13*qdim], &lbf[spos+17*qdim], &lbf[spos+18*qdim], &lbf[spos+7*qdim],
                         &lbf[spos+6*qdim]);
        break;
      case CEDL:
        fD3Q19VCEInamuro(rho, -uwall[0], -uwall[1], uwall[2], &force[0], &lbf[spos], &lbf[spos+10*qdim],
                         &lbf[spos+11*qdim], &lbf[spos+3*qdim], &lbf[spos+13*qdim], &lbf[spos+14*qdim],
                         &lbf[spos+16*qdim], &lbf[spos+15*qdim], &lbf[spos+18*qdim], &lbf[spos+17*qdim],
                         &lbf[spos+1*qdim], &lbf[spos+2*qdim], &lbf[spos+12*qdim], &lbf[spos+4*qdim],
                         &lbf[spos+5*qdim], &lbf[spos+7*qdim], &lbf[spos+6*qdim], &lbf[spos+9*qdim],
                         &lbf[spos+8*qdim]);
        break;
      case CEDR:
        fD3Q19VCEInamuro(rho, -uwall[1], uwall[0], uwall[2], &force[0], &lbf[spos], &lbf[spos+11*qdim],
                         &lbf[spos+1*qdim], &lbf[spos+3*qdim], &lbf[spos+5*qdim], &lbf[spos+13*qdim],
                         &lbf[spos+18*qdim], &lbf[spos+17*qdim], &lbf[spos+6*qdim], &lbf[spos+7*qdim],
                         &lbf[spos+2*qdim], &lbf[spos+10*qdim], &lbf[spos+12*qdim], &lbf[spos+14*qdim],
                         &lbf[spos+4*qdim], &lbf[spos+9*qdim], &lbf[spos+8*qdim], &lbf[spos+15*qdim],
                         &lbf[spos+16*qdim]);
        break;
      case CETF:
        fD3Q19VCEInamuro(rho, uwall[1], uwall[2], uwall[0], &force[0], &lbf[spos], &lbf[spos+2*qdim],
                         &lbf[spos+3*qdim], &lbf[spos+1*qdim], &lbf[spos+8*qdim], &lbf[spos+9*qdim],
                         &lbf[spos+4*qdim], &lbf[spos+14*qdim], &lbf[spos+6*qdim], &lbf[spos+16*qdim],
                         &lbf[spos+11*qdim], &lbf[spos+12*qdim], &lbf[spos+10*qdim], &lbf[spos+17*qdim],
                         &lbf[spos+18*qdim], &lbf[spos+13*qdim], &lbf[spos+5*qdim], &lbf[spos+15*qdim],
                         &lbf[spos+7*qdim]);
        break;
      case CELF:
        fD3Q19VCEInamuro(rho, -uwall[0], uwall[2], uwall[1], &force[0], &lbf[spos], &lbf[spos+10*qdim],
                         &lbf[spos+3*qdim], &lbf[spos+2*qdim], &lbf[spos+16*qdim], &lbf[spos+15*qdim],
                         &lbf[spos+14*qdim], &lbf[spos+13*qdim], &lbf[spos+8*qdim], &lbf[spos+18*qdim],
                         &lbf[spos+1*qdim], &lbf[spos+12*qdim], &lbf[spos+11*qdim], &lbf[spos+7*qdim],
                         &lbf[spos+6*qdim], &lbf[spos+5*qdim], &lbf[spos+4*qdim], &lbf[spos+17*qdim],
                         &lbf[spos+9*qdim]);
        break;
      case CEDF:
        fD3Q19VCEInamuro(rho, -uwall[1], uwall[2], uwall[0], &force[0], &lbf[spos], &lbf[spos+11*qdim],
                         &lbf[spos+3*qdim], &lbf[spos+1*qdim], &lbf[spos+18*qdim], &lbf[spos+17*qdim],
                         &lbf[spos+5*qdim], &lbf[spos+13*qdim], &lbf[spos+6*qdim], &lbf[spos+16*qdim],
                         &lbf[spos+2*qdim], &lbf[spos+12*qdim], &lbf[spos+10*qdim], &lbf[spos+9*qdim],
                         &lbf[spos+8*qdim], &lbf[spos+14*qdim], &lbf[spos+4*qdim], &lbf[spos+15*qdim],
                         &lbf[spos+7*qdim]);
        break;
      case CERF:
        fD3Q19VCEInamuro(rho, uwall[0], uwall[2], uwall[1], &force[0], &lbf[spos], &lbf[spos+1*qdim],
                         &lbf[spos+3*qdim], &lbf[spos+2*qdim], &lbf[spos+6*qdim], &lbf[spos+7*qdim],
                         &lbf[spos+4*qdim], &lbf[spos+5*qdim], &lbf[spos+8*qdim], &lbf[spos+18*qdim],
                         &lbf[spos+10*qdim], &lbf[spos+12*qdim], &lbf[spos+11*qdim], &lbf[spos+15*qdim],
                         &lbf[spos+16*qdim], &lbf[spos+13*qdim], &lbf[spos+14*qdim], &lbf[spos+17*qdim],
                         &lbf[spos+9*qdim]);
        break;
      case CETB:
        fD3Q19VCEInamuro(rho, uwall[1], -uwall[2], uwall[0], &force[0], &lbf[spos], &lbf[spos+2*qdim],
                         &lbf[spos+12*qdim], &lbf[spos+1*qdim], &lbf[spos+9*qdim], &lbf[spos+8*qdim],
                         &lbf[spos+4*qdim], &lbf[spos+14*qdim], &lbf[spos+7*qdim], &lbf[spos+15*qdim],
                         &lbf[spos+11*qdim], &lbf[spos+3*qdim], &lbf[spos+10*qdim], &lbf[spos+18*qdim],
                         &lbf[spos+17*qdim], &lbf[spos+13*qdim], &lbf[spos+5*qdim], &lbf[spos+16*qdim],
                         &lbf[spos+6*qdim]);
        break;
      case CELB:
        fD3Q19VCEInamuro(rho, -uwall[0], -uwall[2], uwall[1], &force[0], &lbf[spos], &lbf[spos+10*qdim],
                         &lbf[spos+12*qdim], &lbf[spos+2*qdim], &lbf[spos+15*qdim], &lbf[spos+16*qdim],
                         &lbf[spos+14*qdim], &lbf[spos+13*qdim], &lbf[spos+9*qdim], &lbf[spos+17*qdim],
                         &lbf[spos+1*qdim], &lbf[spos+3*qdim], &lbf[spos+11*qdim], &lbf[spos+6*qdim],
                         &lbf[spos+7*qdim], &lbf[spos+5*qdim], &lbf[spos+4*qdim], &lbf[spos+18*qdim],
                         &lbf[spos+8*qdim]);
        break;
      case CEDB:
        fD3Q19VCEInamuro(rho, -uwall[1], -uwall[2], uwall[0], &force[0], &lbf[spos], &lbf[spos+11*qdim],
                         &lbf[spos+12*qdim], &lbf[spos+1*qdim], &lbf[spos+17*qdim], &lbf[spos+18*qdim],
                         &lbf[spos+5*qdim], &lbf[spos+13*qdim], &lbf[spos+7*qdim], &lbf[spos+15*qdim],
                         &lbf[spos+2*qdim], &lbf[spos+3*qdim], &lbf[spos+10*qdim], &lbf[spos+8*qdim],
                         &lbf[spos+9*qdim], &lbf[spos+14*qdim], &lbf[spos+4*qdim], &lbf[spos+16*qdim],
                         &lbf[spos+6*qdim]);
        break;
      case CERB:
        fD3Q19VCEInamuro(rho, uwall[0], -uwall[2], uwall[1], &force[0], &lbf[spos], &lbf[spos+1*qdim],
                         &lbf[spos+12*qdim], &lbf[spos+2*qdim], &lbf[spos+7*qdim], &lbf[spos+6*qdim],
                         &lbf[spos+4*qdim], &lbf[spos+5*qdim], &lbf[spos+9*qdim], &lbf[spos+17*qdim],
                         &lbf[spos+10*qdim], &lbf[spos+3*qdim], &lbf[spos+11*qdim], &lbf[spos+16*qdim],
                         &lbf[spos+15*qdim], &lbf[spos+13*qdim], &lbf[spos+14*qdim], &lbf[spos+18*qdim],
                         &lbf[spos+8*qdim]);
        break;
    }
  }
  
  return 0;
  
}


int fD3Q19PPSInamuro(double *p, double *force, double *f0, double *f1,
	                 double *f2, double *f3, double *f4, double *f5,
	                 double *f6, double *f7, double *f8, double *f9,
	                 double *f10, double *f11, double *f12, double *f13,
	                 double *f14, double *f15, double *f16, double *f17,
	                 double *f18, double &vel)
{

  // produce fixed pressure/density at planar surface: expressed for bottom wall (PPST)

  double rho0, rrho0, rhop, v, v1, v0t, v2t, mass=0.0;
  double c1=1.0/18.0,c2=1.0/36.0;
  vel = 0.0;
    
  if(!incompress) {
    for(int i=0; i<lbsy.nf; i++) {
      v = p[i]-(f0[i]+f1[i]+f3[i]+f8[i]+f10[i]+2*(f2[i]+f4[i]+f5[i]+f13[i]+f14[i]))+0.5*force[3*i+1];
      vel += v;
      mass += p[i];
    }
    v1 = vel*fReciprocal(mass);
    for(int i=0; i<lbsy.nf; i++) {
      v = p[i]-(f0[i]+f1[i]+f3[i]+f8[i]+f10[i]+2*(f2[i]+f4[i]+f5[i]+f13[i]+f14[i]));
      rhop = 6.0*(v+f2[i]+f4[i]+f8[i]+f9[i]+f14[i])/(1.0+3.0*v1*(1.0+v1));
      v0t = 6.0*(f1[i]+f4[i]+f6[i]+f7[i]-f10[i]-f14[i]-f15[i]-f16[i]-0.5*force[3*i  ])/(rhop*(1.0+3.0*v1));
      v2t = 6.0*(f3[i]+f6[i]-f7[i]+f8[i]-f9[i]-f12[i]-f15[i]+f16[i]-0.5*force[3*i+2])/(rhop*(1.0+3.0*v1));
      f5[i]=c2*rhop*(1.0+3.0*(v1*(1.0+v1)-v0t*(1.0-v0t))-9.0*v0t*v1-1.5*v2t*v2t);
      f11[i]=c1*rhop*(1.0+3.0*v1-1.5*(v0t*v0t-v1*v1+v2t*v2t));
      f13[i]=c2*rhop*(1.0+3.0*(v1*(1.0+v1)+v0t*(1.0+v0t))+9.0*v0t*v1-1.5*v2t*v2t);
      f17[i]=c2*rhop*(1.0+3.0*(v1*(1.0+v1)+v2t*(1.0+v2t))+9.0*v1*v2t-1.5*v0t*v0t);
      f18[i]=c2*rhop*(1.0+3.0*(v1*(1.0+v1)-v2t*(1.0-v2t))-9.0*v1*v2t-1.5*v0t*v0t);
    }
  }
  else {
    for(int i=0; i<lbsy.nf; i++) {
      v = p[i]-(f0[i]+f1[i]+f3[i]+f8[i]+f10[i]+2*(f2[i]+f4[i]+f5[i]+f13[i]+f14[i]))+0.5*force[3*i+1];
      vel += v;
      mass += lbincp[i];
    }
    v1 = vel*fReciprocal(mass);
    for(int i=0; i<lbsy.nf; i++) {
      rho0 = lbincp[i];
      rrho0 = fReciprocal(rho0);
      rhop = 6.0*(f2[i]+f4[i]+f8[i]+f9[i]+f14[i])+3.0*rho0*v1*(1.0-v1)-3.0*force[3*i+1];
      v0t = 6.0*(f1[i]+f4[i]+f6[i]+f7[i]-f10[i]-f14[i]-f15[i]-f16[i]-0.5*force[3*i  ])*rrho0/(1.0+3.0*v1);
      v2t = 6.0*(f3[i]+f6[i]-f7[i]+f8[i]-f9[i]-f12[i]-f15[i]+f16[i]-0.5*force[3*i+2])*rrho0/(1.0+3.0*v1);
      f5[i]=c2*(rho0+rhop*(3.0*(v1*(1.0+v1)-v0t*(1.0-v0t))-9.0*v0t*v1-1.5*v2t*v2t));
      f11[i]=c1*(rho0+rhop*(3.0*v1-1.5*(v0t*v0t-v1*v1+v2t*v2t)));
      f13[i]=c2*(rho0+rhop*(3.0*(v1*(1.0+v1)+v0t*(1.0+v0t))+9.0*v0t*v1-1.5*v2t*v2t));
      f17[i]=c2*(rho0+rhop*(3.0*(v1*(1.0+v1)+v2t*(1.0+v2t))+9.0*v1*v2t-1.5*v0t*v0t));
      f18[i]=c2*(rho0+rhop*(3.0*(v1*(1.0+v1)-v2t*(1.0-v2t))-9.0*v1*v2t-1.5*v0t*v0t));
    }
  }
  vel *= fReciprocal(mass);
  return 0;
}

int fD3Q19PPSCLBEInamuro(double *p, double *force, double *f0, double *f1,
	                     double *f2, double *f3, double *f4, double *f5,
	                     double *f6, double *f7, double *f8, double *f9,
	                     double *f10, double *f11, double *f12, double *f13,
	                     double *f14, double *f15, double *f16, double *f17,
	                     double *f18, double &vel)
{

  // produce fixed pressure/density at planar surface: expressed for bottom wall (PPST)
  // with higher-order equilibrium distribution functions for CLBE collisions

  double rhop, v, v1, v0t, v2t, mass=0.0;
  double c1=1.0/18.0,c2=1.0/36.0;
  vel = 0.0;
    
  for(int i=0; i<lbsy.nf; i++) {
    v = p[i]-(f0[i]+f1[i]+f3[i]+f8[i]+f10[i]+2*(f2[i]+f4[i]+f5[i]+f13[i]+f14[i]))+0.5*force[3*i+1];
    vel += v;
    mass += p[i];
  }
  v1 = vel*fReciprocal(mass);
  for(int i=0; i<lbsy.nf; i++) {
    v = p[i]-(f0[i]+f1[i]+f3[i]+f8[i]+f10[i]+2*(f2[i]+f4[i]+f5[i]+f13[i]+f14[i]));
    rhop = 6.0*(v+f2[i]+f4[i]+f8[i]+f9[i]+f14[i])/(1.0+3.0*v1*(1.0+v1));
    v0t = 6.0*(f1[i]+f4[i]+f6[i]+f7[i]-f10[i]-f14[i]-f15[i]-f16[i]-0.5*force[3*i  ])/(rhop*(1.0+3.0*v1*(1.0+v1)));
    v2t = 6.0*(f3[i]+f6[i]-f7[i]+f8[i]-f9[i]-f12[i]-f15[i]+f16[i]-0.5*force[3*i+2])/(rhop*(1.0+3.0*v1*(1.0+v1)));
    f5[i]=c2*rhop*(1.0+3.0*(v1*(1.0+v1)-v0t*(1.0-v0t))-9.0*v0t*v1*(1.0-v0t)*(1.0+v1));
    f11[i]=c1*rhop*(1.0+3.0*v1-3.0*(v0t*v0t-v1*v1+v2t*v2t)-9.0*v1*(1.0+v1)*(v0t*v0t+v2t*v2t));
    f13[i]=c2*rhop*(1.0+3.0*(v1*(1.0+v1)+v0t*(1.0+v0t))+9.0*v0t*v1*(1.0+v0t)*(1.0+v1));
    f17[i]=c2*rhop*(1.0+3.0*(v1*(1.0+v1)+v2t*(1.0+v2t))+9.0*v1*v2t*(1.0+v1)*(1.0+v2t));
    f18[i]=c2*rhop*(1.0+3.0*(v1*(1.0+v1)-v2t*(1.0-v2t))-9.0*v1*v2t*(1.0+v1)*(1.0-v2t));
  }
  vel *= fReciprocal(mass);
  return 0;
}

int fD3Q19PPSSwiftInamuro(double *p, double *force, double *f0, double *f1,
	                      double *f2, double *f3, double *f4, double *f5,
	                      double *f6, double *f7, double *f8, double *f9,
	                      double *f10, double *f11, double *f12, double *f13,
	                      double *f14, double *f15, double *f16, double *f17,
	                      double *f18, double drdx, double drdy, double drdz,
                          double dpdx, double dpdy, double dpdz, double nabr,
                          double nabp, double *omega, double T, double &vel)
{

  // produce fixed pressure/density at planar surface: expressed for bottom wall (PPST)
  // with Swift free-energy interactions

  double rho, phi, omegat, pb, mu, lambda, d2rdx2, d2rdy2, d2rdz2, d2rdxdy, d2rdydz, nabrp, rhop, phip, v0t, v2t, v1, v;
  double c0=1.0/3.0,c1=1.0/6.0,c2=1.0/12.0,c3=1.0/24.0;

  rho = p[0];
  v = p[0]-(f0[0]+f1[0]+f3[0]+f6[0]+f7[0]+f10[0]+f12[0]+f15[0]+f16[0]+2.0*(f2[0]+f4[0]+f8[0]+f9[0]+f14[0]));
  vel = (v+0.5*force[1])*fReciprocal(rho);
  v1 = vel;
  if(lbsy.nf>1) {
    phi = p[1];
    omegat = 0.5*(1.0+phi)*omega[0]+0.5*(1.0-phi)*omega[1];
    mu = lbfemob*fGetPotentialSwift(phi, nabp);
    d2rdx2 = (lbfeeos>0)?(drdx*drdx):0.0 + dpdx*dpdx;
    d2rdy2 = (lbfeeos>0)?(drdy*drdy):0.0 + dpdy*dpdy;
    d2rdz2 = (lbfeeos>0)?(drdz*drdz):0.0 + dpdz*dpdz;
    d2rdxdy = (lbfeeos>0)?(drdx*drdy):0.0 + dpdx*dpdy;
//  d2rdxdz = (lbfeeos>0)?(drdx*drdz):0.0 + dpdx*dpdz;   // this gradient not required for this boundary
    d2rdydz = (lbfeeos>0)?(drdy*drdz):0.0 + dpdy*dpdz;
    nabrp = (lbfeeos>0)?(rho*nabr):0.0 + phi*nabp;
    if(fCppAbs(v1)>0.0)
      phip = (2.0*(phi-f0[1]-f1[1]-f2[1]-f3[1]-f4[1]-f6[1]-f7[1]-f8[1]-f9[1]-f10[1]-f12[1]-f14[1]-f15[1]-f16[1])-mu)/(v1*(1.0+v1));
    else
      phip = phi;
    f5[0]=c2*(phip*v1*(1.0+v1)+mu);
    f11[0]=c1*(phip*v1*(1.0+v1)+mu);
    f13[0]=c2*(phip*v1*(1.0+v1)+mu);
    f17[0]=c2*(phip*v1*(1.0+v1)+mu);
    f18[0]=c2*(phip*v1*(1.0+v1)+mu);
  }
  else {
    phi = 0.0;
    omegat = omega[0];
    d2rdx2 = drdx*drdx;
    d2rdy2 = drdy*drdy;
    d2rdz2 = drdz*drdz;
    d2rdxdy = drdx*drdy;
//  d2rdxdz = drdx*drdz;   // this gradient not required for this boundary
    d2rdydz = drdy*drdz;
    nabrp = rho*nabr;
  }
  pb = fGetBulkPressureSwift(rho, phi, T);
  lambda = fGetLambdaSwift(rho, omegat, T);
  rhop = (2.0*(v+f2[0]+f4[0]+f8[0]+f9[0]+f14[0])-pb+lbkappa*(nabrp+0.5*(d2rdx2+d2rdz2-d2rdy2))-4.0*v1*drdy*lambda)*fReciprocal(v1*(1.0+v1));
  if(rhop<lbevaplim)
    rhop = rho;
  v0t = (6.0*(f1[0]+f4[0]+f6[0]+f7[0]-f10[0]-f14[0]-f15[0]-f16[0])-3.0*force[0]-3.0*lambda*v1*drdx-3.0*lbkappa*d2rdxdy)/(rhop*(1.0+3.0*v1));
  v2t = (6.0*(f3[0]+f6[0]-f7[0]+f8[0]-f9[0]-f12[0]-f15[0]+f16[0])-3.0*force[2]-3.0*lambda*v1*drdz-3.0*lbkappa*d2rdydz)/(rhop*(1.0+3.0*v1));
  f5[0]=c2*rhop*(v0t*(v0t-1.0)+v1*(v1+1.0))-c3*rhop*v2t*v2t-0.25*rhop*v0t*v1
        +lambda*v1*(0.375*drdy-0.25*drdx)+c2*(pb-lbkappa*nabrp)
        +lbkappa*(c2*d2rdz2-c3*(d2rdx2+d2rdy2)+0.25*d2rdxdy);
  f11[0]=c1*rhop*(v1*(v1+1.0))-c2*rhop*(v0t*v0t+v2t*v2t)+0.5*lambda*v1*drdy+c1*(pb-lbkappa*nabrp)
         +lbkappa*(5.0*c2*d2rdy2-c0*(d2rdx2+d2rdz2));
  f13[0]=c2*rhop*(v0t*(v0t+1.0)+v1*(v1+1.0))-c3*rhop*v2t*v2t+0.25*rhop*v0t*v1
         +lambda*v1*(0.375*drdy+0.25*drdx)+c2*(pb-lbkappa*nabrp)
         +lbkappa*(c2*d2rdz2-c3*(d2rdx2+d2rdy2)-0.25*d2rdxdy);
  f17[0]=c2*rhop*(v1*(v1+1.0)+v2t*(v2t+1.0))-c3*rhop*v0t*v0t+0.25*rhop*v1*v2t
         +lambda*v1*(0.375*drdy+0.25*drdz)+c2*(pb-lbkappa*nabrp)
         +lbkappa*(c2*d2rdx2-c3*(d2rdy2+d2rdz2)+0.25*d2rdydz);
  f18[0]=c2*rhop*(v1*(v1+1.0)+v2t*(v2t-1.0))-c3*rhop*v0t*v0t-0.25*rhop*v1*v2t
         +lambda*v1*(0.375*drdy-0.25*drdz)+c2*(pb-lbkappa*nabrp)
         +lbkappa*(c2*d2rdx2-c3*(d2rdy2+d2rdz2)-0.25*d2rdydz);
  return 0;
}

int fD3Q19PFInamuro(long tpos, int prop, double *p0, double *uwall, double T)
{
  double moment, drdx, drdy, drdz, dpdx, dpdy, dpdz, nabr, nabp;
  long spos=tpos * lbsitelength;
  int qdim = lbsy.nf+lbsy.nc+lbsy.nt;
  double force[3*lbsy.nf];
  
  fD3Q19BoundaryForceDensity(force, tpos, p0, prop);
    
  if(interact==20) {
    drdx = lbft[4*lbsy.nf*tpos  ];
    drdy = lbft[4*lbsy.nf*tpos+1];
    drdz = lbft[4*lbsy.nf*tpos+2];
    nabr = lbft[4*lbsy.nf*tpos+3];
    dpdx = (lbsy.nf>1)?lbft[4*lbsy.nf*tpos+4]:0.0;
    dpdy = (lbsy.nf>1)?lbft[4*lbsy.nf*tpos+5]:0.0;
    dpdz = (lbsy.nf>1)?lbft[4*lbsy.nf*tpos+6]:0.0;
    nabp = (lbsy.nf>1)?lbft[4*lbsy.nf*tpos+7]:0.0;
    switch (prop) {
      case PST:
        fD3Q19PPSSwiftInamuro(p0, &force[0], &lbf[spos], &lbf[spos+1*qdim],
                              &lbf[spos+2*qdim], &lbf[spos+3*qdim], &lbf[spos+4*qdim], &lbf[spos+5*qdim],
                              &lbf[spos+6*qdim], &lbf[spos+7*qdim], &lbf[spos+8*qdim], &lbf[spos+9*qdim],
                              &lbf[spos+10*qdim], &lbf[spos+11*qdim], &lbf[spos+12*qdim], &lbf[spos+13*qdim],
                              &lbf[spos+14*qdim], &lbf[spos+15*qdim], &lbf[spos+16*qdim], &lbf[spos+17*qdim],
                              &lbf[spos+18*qdim], drdx, drdy, drdz, dpdx, dpdy, dpdz, nabr, nabp,
                              &lbomega[lbsy.nf*tpos], T, moment);
        uwall[1] += moment;
        break;
      case PSD:
        fD3Q19PPSSwiftInamuro(p0, &force[0], &lbf[spos], &lbf[spos+10*qdim],
                              &lbf[spos+11*qdim], &lbf[spos+12*qdim], &lbf[spos+13*qdim], &lbf[spos+14*qdim],
                              &lbf[spos+15*qdim], &lbf[spos+16*qdim], &lbf[spos+17*qdim], &lbf[spos+18*qdim],
                              &lbf[spos+1*qdim], &lbf[spos+2*qdim], &lbf[spos+3*qdim], &lbf[spos+4*qdim],
                              &lbf[spos+5*qdim], &lbf[spos+6*qdim], &lbf[spos+7*qdim], &lbf[spos+8*qdim],
                              &lbf[spos+9*qdim], -drdx, -drdy, -drdz, -dpdx, -dpdy, -dpdz, nabr, nabp,
                              &lbomega[lbsy.nf*tpos], T, moment);
        uwall[1] -= moment;
        break;
      case PSL:
        fD3Q19PPSSwiftInamuro(p0, &force[0], &lbf[spos], &lbf[spos+12*qdim],
                              &lbf[spos+10*qdim], &lbf[spos+11*qdim], &lbf[spos+15*qdim], &lbf[spos+7*qdim],
                              &lbf[spos+17*qdim], &lbf[spos+9*qdim], &lbf[spos+13*qdim], &lbf[spos+14*qdim],
                              &lbf[spos+3*qdim], &lbf[spos+1*qdim], &lbf[spos+2*qdim], &lbf[spos+6*qdim],
                              &lbf[spos+16*qdim], &lbf[spos+8*qdim], &lbf[spos+18*qdim], &lbf[spos+4*qdim],
                              &lbf[spos+5*qdim], -drdz, -drdx, -drdy, -dpdz, -dpdx, -dpdy, nabr, nabp,
                              &lbomega[lbsy.nf*tpos], T, moment);
        uwall[0] -= moment;
        break;
      case PSR:
        fD3Q19PPSSwiftInamuro(p0, &force[0], &lbf[spos], &lbf[spos+3*qdim],
                              &lbf[spos+1*qdim], &lbf[spos+2*qdim], &lbf[spos+6*qdim], &lbf[spos+16*qdim],
                              &lbf[spos+8*qdim], &lbf[spos+18*qdim], &lbf[spos+4*qdim], &lbf[spos+5*qdim],
                              &lbf[spos+12*qdim], &lbf[spos+10*qdim], &lbf[spos+11*qdim], &lbf[spos+15*qdim],
                              &lbf[spos+7*qdim], &lbf[spos+17*qdim], &lbf[spos+9*qdim], &lbf[spos+13*qdim],
                              &lbf[spos+14*qdim], drdz, drdx, drdy, dpdz, dpdx, dpdy, nabr, nabp,
                              &lbomega[lbsy.nf*tpos], T, moment);
        uwall[0] += moment;
        break;
      case PSF:
        fD3Q19PPSSwiftInamuro(p0, &force[0], &lbf[spos], &lbf[spos+11*qdim],
                              &lbf[spos+12*qdim], &lbf[spos+10*qdim], &lbf[spos+17*qdim], &lbf[spos+18*qdim],
                              &lbf[spos+13*qdim], &lbf[spos+5*qdim], &lbf[spos+15*qdim], &lbf[spos+7*qdim],
                              &lbf[spos+2*qdim], &lbf[spos+3*qdim], &lbf[spos+1*qdim], &lbf[spos+8*qdim],
                              &lbf[spos+9*qdim], &lbf[spos+4*qdim], &lbf[spos+14*qdim], &lbf[spos+6*qdim],
                              &lbf[spos+16*qdim], -drdy, -drdz, -drdx, -dpdy, -dpdz, -dpdx, nabr, nabp,
                              &lbomega[lbsy.nf*tpos], T, moment);
        uwall[2] -= moment;
        break;
      case PSB:
        fD3Q19PPSSwiftInamuro(p0, &force[0], &lbf[spos], &lbf[spos+2*qdim],
                              &lbf[spos+3*qdim], &lbf[spos+1*qdim], &lbf[spos+8*qdim], &lbf[spos+9*qdim],
                              &lbf[spos+4*qdim], &lbf[spos+14*qdim], &lbf[spos+6*qdim], &lbf[spos+16*qdim],
                              &lbf[spos+11*qdim], &lbf[spos+12*qdim], &lbf[spos+10*qdim], &lbf[spos+17*qdim],
                              &lbf[spos+18*qdim], &lbf[spos+13*qdim], &lbf[spos+5*qdim], &lbf[spos+15*qdim],
                              &lbf[spos+7*qdim], drdy, drdz, drdx, dpdy, dpdz, dpdx, nabr, nabp,
                              &lbomega[lbsy.nf*tpos], T, moment);
        uwall[2] += moment;
        break;
      case CCTRB:
        fD3Q19VCCSwiftInamuro(p0, uwall[0], uwall[1], -uwall[2], &force[0], &lbf[spos], &lbf[spos+1*qdim],
                              &lbf[spos+2*qdim], &lbf[spos+12*qdim], &lbf[spos+4*qdim], &lbf[spos+5*qdim],
                              &lbf[spos+7*qdim], &lbf[spos+6*qdim], &lbf[spos+9*qdim], &lbf[spos+8*qdim],
                              &lbf[spos+10*qdim], &lbf[spos+11*qdim], &lbf[spos+3*qdim], &lbf[spos+13*qdim],
                              &lbf[spos+14*qdim], &lbf[spos+16*qdim], &lbf[spos+15*qdim], &lbf[spos+18*qdim],
                              &lbf[spos+17*qdim], drdx, drdy, -drdz, dpdx, dpdy, -dpdz, nabr, nabp,
                              &lbomega[lbsy.nf*tpos], T);
        break;
      case CCTLB:
        fD3Q19VCCSwiftInamuro(p0, -uwall[0], uwall[1], -uwall[2], &force[0], &lbf[spos], &lbf[spos+10*qdim],
                              &lbf[spos+2*qdim], &lbf[spos+12*qdim], &lbf[spos+14*qdim], &lbf[spos+13*qdim],
                              &lbf[spos+15*qdim], &lbf[spos+16*qdim], &lbf[spos+9*qdim], &lbf[spos+8*qdim],
                              &lbf[spos+1*qdim], &lbf[spos+11*qdim], &lbf[spos+3*qdim], &lbf[spos+5*qdim],
                              &lbf[spos+4*qdim], &lbf[spos+6*qdim], &lbf[spos+7*qdim], &lbf[spos+18*qdim],
                              &lbf[spos+17*qdim], -drdx, drdy, -drdz, -dpdx, dpdy, -dpdz, nabr, nabp,
                              &lbomega[lbsy.nf*tpos], T);
        break;
      case CCDLB:
        fD3Q19VCCSwiftInamuro(p0, -uwall[0], -uwall[1], -uwall[2], &force[0], &lbf[spos], &lbf[spos+10*qdim],
                              &lbf[spos+11*qdim], &lbf[spos+12*qdim], &lbf[spos+13*qdim], &lbf[spos+14*qdim],
                              &lbf[spos+15*qdim], &lbf[spos+16*qdim], &lbf[spos+17*qdim], &lbf[spos+18*qdim],
                              &lbf[spos+1*qdim], &lbf[spos+2*qdim], &lbf[spos+3*qdim], &lbf[spos+4*qdim],
                              &lbf[spos+5*qdim], &lbf[spos+6*qdim], &lbf[spos+7*qdim], &lbf[spos+8*qdim],
                              &lbf[spos+9*qdim], -drdx, -drdy, -drdz, -dpdx, -dpdy, -dpdz, nabr, nabp,
                              &lbomega[lbsy.nf*tpos], T);
        break;
      case CCDRB:
        fD3Q19VCCSwiftInamuro(p0, uwall[0], -uwall[1], -uwall[2], &force[0], &lbf[spos], &lbf[spos+1*qdim],
                              &lbf[spos+11*qdim], &lbf[spos+12*qdim], &lbf[spos+5*qdim], &lbf[spos+4*qdim],
                              &lbf[spos+7*qdim], &lbf[spos+6*qdim], &lbf[spos+17*qdim], &lbf[spos+18*qdim],
                              &lbf[spos+10*qdim], &lbf[spos+2*qdim], &lbf[spos+3*qdim], &lbf[spos+14*qdim],
                              &lbf[spos+13*qdim], &lbf[spos+16*qdim], &lbf[spos+15*qdim], &lbf[spos+8*qdim],
                              &lbf[spos+9*qdim], drdx, -drdy, -drdz, dpdx, -dpdy, -dpdz, nabr, nabp,
                              &lbomega[lbsy.nf*tpos], T);
        break;
      case CCTRF:
        fD3Q19VCCSwiftInamuro(p0, uwall[0], uwall[1], uwall[2], &force[0], &lbf[spos], &lbf[spos+1*qdim],
                              &lbf[spos+2*qdim], &lbf[spos+3*qdim], &lbf[spos+4*qdim], &lbf[spos+5*qdim],
                              &lbf[spos+6*qdim], &lbf[spos+7*qdim], &lbf[spos+8*qdim], &lbf[spos+9*qdim],
                              &lbf[spos+10*qdim], &lbf[spos+11*qdim], &lbf[spos+12*qdim], &lbf[spos+13*qdim],
                              &lbf[spos+14*qdim], &lbf[spos+15*qdim], &lbf[spos+16*qdim], &lbf[spos+17*qdim],
                              &lbf[spos+18*qdim], drdx, drdy, drdz, dpdx, dpdy, dpdz, nabr, nabp,
                              &lbomega[lbsy.nf*tpos], T);
        break;
      case CCTLF:
        fD3Q19VCCSwiftInamuro(p0, -uwall[0], uwall[1], uwall[2], &force[0], &lbf[spos], &lbf[spos+10*qdim],
                              &lbf[spos+2*qdim], &lbf[spos+3*qdim], &lbf[spos+14*qdim], &lbf[spos+13*qdim],
                              &lbf[spos+16*qdim], &lbf[spos+15*qdim], &lbf[spos+8*qdim], &lbf[spos+9*qdim],
                              &lbf[spos+1*qdim], &lbf[spos+11*qdim], &lbf[spos+12*qdim], &lbf[spos+5*qdim],
                              &lbf[spos+4*qdim], &lbf[spos+7*qdim], &lbf[spos+6*qdim], &lbf[spos+17*qdim],
                              &lbf[spos+18*qdim], -drdx, drdy, drdz, -dpdx, dpdy, dpdz, nabr, nabp,
                              &lbomega[lbsy.nf*tpos], T);
        break;
      case CCDLF:
        fD3Q19VCCSwiftInamuro(p0, -uwall[0], -uwall[1], uwall[2], &force[0], &lbf[spos], &lbf[spos+10*qdim],
                              &lbf[spos+11*qdim], &lbf[spos+3*qdim], &lbf[spos+13*qdim], &lbf[spos+14*qdim],
                              &lbf[spos+16*qdim], &lbf[spos+15*qdim], &lbf[spos+18*qdim], &lbf[spos+17*qdim],
                              &lbf[spos+1*qdim], &lbf[spos+2*qdim], &lbf[spos+12*qdim], &lbf[spos+4*qdim],
                              &lbf[spos+5*qdim], &lbf[spos+7*qdim], &lbf[spos+6*qdim], &lbf[spos+9*qdim],
                              &lbf[spos+8*qdim], -drdx, -drdy, drdz, -dpdx, -dpdy, dpdz, nabr, nabp,
                              &lbomega[lbsy.nf*tpos], T);
        break;
      case CCDRF:
        fD3Q19VCCSwiftInamuro(p0, uwall[0], -uwall[1], uwall[2], &force[0], &lbf[spos], &lbf[spos+1*qdim],
                              &lbf[spos+11*qdim], &lbf[spos+3*qdim], &lbf[spos+5*qdim], &lbf[spos+4*qdim],
                              &lbf[spos+6*qdim], &lbf[spos+7*qdim], &lbf[spos+18*qdim], &lbf[spos+17*qdim],
                              &lbf[spos+10*qdim], &lbf[spos+2*qdim], &lbf[spos+12*qdim], &lbf[spos+14*qdim],
                              &lbf[spos+13*qdim], &lbf[spos+15*qdim], &lbf[spos+16*qdim], &lbf[spos+9*qdim],
                              &lbf[spos+8*qdim], drdx, -drdy, drdz, dpdx, -dpdy, dpdz, nabr, nabp,
                              &lbomega[lbsy.nf*tpos], T);
        break;
      case CETR:
        fD3Q19VCESwiftInamuro(p0, uwall[0], uwall[1], uwall[2], &force[0], &lbf[spos], &lbf[spos+1*qdim],
                              &lbf[spos+2*qdim], &lbf[spos+3*qdim], &lbf[spos+4*qdim], &lbf[spos+5*qdim],
                              &lbf[spos+6*qdim], &lbf[spos+7*qdim], &lbf[spos+8*qdim], &lbf[spos+9*qdim],
                              &lbf[spos+10*qdim], &lbf[spos+11*qdim], &lbf[spos+12*qdim], &lbf[spos+13*qdim],
                              &lbf[spos+14*qdim], &lbf[spos+15*qdim], &lbf[spos+16*qdim], &lbf[spos+17*qdim],
                              &lbf[spos+18*qdim], drdx, drdy, drdz, dpdx, dpdy, dpdz, nabr, nabp,
                              &lbomega[lbsy.nf*tpos], T);
        break;
      case CETL:
        fD3Q19VCESwiftInamuro(p0, uwall[1], -uwall[0], uwall[2], &force[0], &lbf[spos], &lbf[spos+2*qdim],
                              &lbf[spos+10*qdim], &lbf[spos+3*qdim], &lbf[spos+14*qdim], &lbf[spos+4*qdim],
                              &lbf[spos+8*qdim], &lbf[spos+9*qdim], &lbf[spos+16*qdim], &lbf[spos+15*qdim],
                              &lbf[spos+11*qdim], &lbf[spos+1*qdim], &lbf[spos+12*qdim], &lbf[spos+5*qdim],
                              &lbf[spos+13*qdim], &lbf[spos+17*qdim], &lbf[spos+18*qdim], &lbf[spos+7*qdim],
                              &lbf[spos+6*qdim], drdy, -drdx, drdz, dpdy, -dpdx, dpdz, nabr, nabp,
                              &lbomega[lbsy.nf*tpos], T);
        break;
      case CEDL:
        fD3Q19VCESwiftInamuro(p0, -uwall[0], -uwall[1], uwall[2], &force[0], &lbf[spos], &lbf[spos+10*qdim],
                              &lbf[spos+11*qdim], &lbf[spos+3*qdim], &lbf[spos+13*qdim], &lbf[spos+14*qdim],
                              &lbf[spos+16*qdim], &lbf[spos+15*qdim], &lbf[spos+18*qdim], &lbf[spos+17*qdim],
                              &lbf[spos+1*qdim], &lbf[spos+2*qdim], &lbf[spos+12*qdim], &lbf[spos+4*qdim],
                              &lbf[spos+5*qdim], &lbf[spos+7*qdim], &lbf[spos+6*qdim], &lbf[spos+9*qdim],
                              &lbf[spos+8*qdim], -drdx, -drdy, drdz, -dpdx, -dpdy, dpdz, nabr, nabp,
                              &lbomega[lbsy.nf*tpos], T);
        break;
      case CEDR:
        fD3Q19VCESwiftInamuro(p0, -uwall[1], uwall[0], uwall[2], &force[0], &lbf[spos], &lbf[spos+11*qdim],
                              &lbf[spos+1*qdim], &lbf[spos+3*qdim], &lbf[spos+5*qdim], &lbf[spos+13*qdim],
                              &lbf[spos+18*qdim], &lbf[spos+17*qdim], &lbf[spos+6*qdim], &lbf[spos+7*qdim],
                              &lbf[spos+2*qdim], &lbf[spos+10*qdim], &lbf[spos+12*qdim], &lbf[spos+14*qdim],
                              &lbf[spos+4*qdim], &lbf[spos+9*qdim], &lbf[spos+8*qdim], &lbf[spos+15*qdim],
                              &lbf[spos+16*qdim], -drdy, drdx, drdz, -dpdy, dpdx, dpdz, nabr, nabp,
                              &lbomega[lbsy.nf*tpos], T);
        break;
      case CETF:
        fD3Q19VCESwiftInamuro(p0, uwall[1], uwall[2], uwall[0], &force[0], &lbf[spos], &lbf[spos+2*qdim],
                              &lbf[spos+3*qdim], &lbf[spos+1*qdim], &lbf[spos+8*qdim], &lbf[spos+9*qdim],
                              &lbf[spos+4*qdim], &lbf[spos+14*qdim], &lbf[spos+6*qdim], &lbf[spos+16*qdim],
                              &lbf[spos+11*qdim], &lbf[spos+12*qdim], &lbf[spos+10*qdim], &lbf[spos+17*qdim],
                              &lbf[spos+18*qdim], &lbf[spos+13*qdim], &lbf[spos+5*qdim], &lbf[spos+15*qdim],
                              &lbf[spos+7*qdim], drdy, drdz, drdx, dpdy, dpdz, dpdx, nabr, nabp,
                              &lbomega[lbsy.nf*tpos], T);
        break;
      case CELF:
        fD3Q19VCESwiftInamuro(p0, -uwall[0], uwall[2], uwall[1], &force[0], &lbf[spos], &lbf[spos+10*qdim],
                              &lbf[spos+3*qdim], &lbf[spos+2*qdim], &lbf[spos+16*qdim], &lbf[spos+15*qdim],
                              &lbf[spos+14*qdim], &lbf[spos+13*qdim], &lbf[spos+8*qdim], &lbf[spos+18*qdim],
                              &lbf[spos+1*qdim], &lbf[spos+12*qdim], &lbf[spos+11*qdim], &lbf[spos+7*qdim],
                              &lbf[spos+6*qdim], &lbf[spos+5*qdim], &lbf[spos+4*qdim], &lbf[spos+17*qdim],
                              &lbf[spos+9*qdim], -drdx, drdz, drdy, -dpdx, dpdz, dpdy, nabr, nabp,
                              &lbomega[lbsy.nf*tpos], T);
        break;
      case CEDF:
        fD3Q19VCESwiftInamuro(p0, -uwall[1], uwall[2], uwall[0], &force[0], &lbf[spos], &lbf[spos+11*qdim],
                              &lbf[spos+3*qdim], &lbf[spos+1*qdim], &lbf[spos+18*qdim], &lbf[spos+17*qdim],
                              &lbf[spos+5*qdim], &lbf[spos+13*qdim], &lbf[spos+6*qdim], &lbf[spos+16*qdim],
                              &lbf[spos+2*qdim], &lbf[spos+12*qdim], &lbf[spos+10*qdim], &lbf[spos+9*qdim],
                              &lbf[spos+8*qdim], &lbf[spos+14*qdim], &lbf[spos+4*qdim], &lbf[spos+15*qdim],
                              &lbf[spos+7*qdim], -drdy, drdz, drdx, -dpdy, dpdz, dpdx, nabr, nabp,
                              &lbomega[lbsy.nf*tpos], T);
        break;
      case CERF:
        fD3Q19VCESwiftInamuro(p0, uwall[0], uwall[2], uwall[1], &force[0], &lbf[spos], &lbf[spos+1*qdim],
                              &lbf[spos+3*qdim], &lbf[spos+2*qdim], &lbf[spos+6*qdim], &lbf[spos+7*qdim],
                              &lbf[spos+4*qdim], &lbf[spos+5*qdim], &lbf[spos+8*qdim], &lbf[spos+18*qdim],
                              &lbf[spos+10*qdim], &lbf[spos+12*qdim], &lbf[spos+11*qdim], &lbf[spos+15*qdim],
                              &lbf[spos+16*qdim], &lbf[spos+13*qdim], &lbf[spos+14*qdim], &lbf[spos+17*qdim],
                              &lbf[spos+9*qdim], drdx, drdz, drdy, dpdx, dpdz, dpdy, nabr, nabp,
                              &lbomega[lbsy.nf*tpos], T);
        break;
      case CETB:
        fD3Q19VCESwiftInamuro(p0, uwall[1], -uwall[2], uwall[0], &force[0], &lbf[spos], &lbf[spos+2*qdim],
                              &lbf[spos+12*qdim], &lbf[spos+1*qdim], &lbf[spos+9*qdim], &lbf[spos+8*qdim],
                              &lbf[spos+4*qdim], &lbf[spos+14*qdim], &lbf[spos+7*qdim], &lbf[spos+15*qdim],
                              &lbf[spos+11*qdim], &lbf[spos+3*qdim], &lbf[spos+10*qdim], &lbf[spos+18*qdim],
                              &lbf[spos+17*qdim], &lbf[spos+13*qdim], &lbf[spos+5*qdim], &lbf[spos+16*qdim],
                              &lbf[spos+6*qdim], drdy, -drdz, drdx, dpdy, -dpdz, dpdx, nabr, nabp,
                              &lbomega[lbsy.nf*tpos], T);
        break;
      case CELB:
        fD3Q19VCESwiftInamuro(p0, -uwall[0], -uwall[2], uwall[1], &force[0], &lbf[spos], &lbf[spos+10*qdim],
                              &lbf[spos+12*qdim], &lbf[spos+2*qdim], &lbf[spos+15*qdim], &lbf[spos+16*qdim],
                              &lbf[spos+14*qdim], &lbf[spos+13*qdim], &lbf[spos+9*qdim], &lbf[spos+17*qdim],
                              &lbf[spos+1*qdim], &lbf[spos+3*qdim], &lbf[spos+11*qdim], &lbf[spos+6*qdim],
                              &lbf[spos+7*qdim], &lbf[spos+5*qdim], &lbf[spos+4*qdim], &lbf[spos+18*qdim],
                              &lbf[spos+8*qdim], -drdx, -drdz, drdy, -dpdx, -dpdz, dpdy, nabr, nabp,
                              &lbomega[lbsy.nf*tpos], T);
        break;
      case CEDB:
        fD3Q19VCESwiftInamuro(p0, -uwall[1], -uwall[2], uwall[0], &force[0], &lbf[spos], &lbf[spos+11*qdim],
                              &lbf[spos+12*qdim], &lbf[spos+1*qdim], &lbf[spos+17*qdim], &lbf[spos+18*qdim],
                              &lbf[spos+5*qdim], &lbf[spos+13*qdim], &lbf[spos+7*qdim], &lbf[spos+15*qdim],
                              &lbf[spos+2*qdim], &lbf[spos+3*qdim], &lbf[spos+10*qdim], &lbf[spos+8*qdim],
                              &lbf[spos+9*qdim], &lbf[spos+14*qdim], &lbf[spos+4*qdim], &lbf[spos+16*qdim],
                              &lbf[spos+6*qdim], -drdy, -drdz, drdx, -dpdy, -dpdz, dpdx, nabr, nabp,
                              &lbomega[lbsy.nf*tpos], T);
        break;
      case CERB:
        fD3Q19VCESwiftInamuro(p0, uwall[0], -uwall[2], uwall[1], &force[0], &lbf[spos], &lbf[spos+1*qdim],
                              &lbf[spos+12*qdim], &lbf[spos+2*qdim], &lbf[spos+7*qdim], &lbf[spos+6*qdim],
                              &lbf[spos+4*qdim], &lbf[spos+5*qdim], &lbf[spos+9*qdim], &lbf[spos+17*qdim],
                              &lbf[spos+10*qdim], &lbf[spos+3*qdim], &lbf[spos+11*qdim], &lbf[spos+16*qdim],
                              &lbf[spos+15*qdim], &lbf[spos+13*qdim], &lbf[spos+14*qdim], &lbf[spos+18*qdim],
                              &lbf[spos+8*qdim], drdx, -drdz, drdy, dpdx, -dpdz, dpdy, nabr, nabp,
                              &lbomega[lbsy.nf*tpos], T);
        break;
    }
  }
  else if(collide>11){
    switch (prop) {
      case PST:
        fD3Q19PPSCLBEInamuro(p0, &force[0], &lbf[spos], &lbf[spos+1*qdim],
                             &lbf[spos+2*qdim], &lbf[spos+3*qdim], &lbf[spos+4*qdim], &lbf[spos+5*qdim],
                             &lbf[spos+6*qdim], &lbf[spos+7*qdim], &lbf[spos+8*qdim], &lbf[spos+9*qdim],
                             &lbf[spos+10*qdim], &lbf[spos+11*qdim], &lbf[spos+12*qdim], &lbf[spos+13*qdim],
                             &lbf[spos+14*qdim], &lbf[spos+15*qdim], &lbf[spos+16*qdim], &lbf[spos+17*qdim],
                             &lbf[spos+18*qdim], moment);
        uwall[1] += moment;
        break;
      case PSD:
        fD3Q19PPSCLBEInamuro(p0, &force[0], &lbf[spos], &lbf[spos+10*qdim],
                             &lbf[spos+11*qdim], &lbf[spos+12*qdim], &lbf[spos+13*qdim], &lbf[spos+14*qdim],
                             &lbf[spos+15*qdim], &lbf[spos+16*qdim], &lbf[spos+17*qdim], &lbf[spos+18*qdim],
                             &lbf[spos+1*qdim], &lbf[spos+2*qdim], &lbf[spos+3*qdim], &lbf[spos+4*qdim],
                             &lbf[spos+5*qdim], &lbf[spos+6*qdim], &lbf[spos+7*qdim], &lbf[spos+8*qdim],
                             &lbf[spos+9*qdim], moment);
        uwall[1] -= moment;
        break;
      case PSL:
        fD3Q19PPSCLBEInamuro(p0, &force[0], &lbf[spos], &lbf[spos+12*qdim],
                             &lbf[spos+10*qdim], &lbf[spos+11*qdim], &lbf[spos+15*qdim], &lbf[spos+7*qdim],
                             &lbf[spos+17*qdim], &lbf[spos+9*qdim], &lbf[spos+13*qdim], &lbf[spos+14*qdim],
                             &lbf[spos+3*qdim], &lbf[spos+1*qdim], &lbf[spos+2*qdim], &lbf[spos+6*qdim],
                             &lbf[spos+16*qdim], &lbf[spos+8*qdim], &lbf[spos+18*qdim], &lbf[spos+4*qdim],
                             &lbf[spos+5*qdim], moment);
        uwall[0] -= moment;
        break;
      case PSR:
        fD3Q19PPSCLBEInamuro(p0, &force[0], &lbf[spos], &lbf[spos+3*qdim],
                             &lbf[spos+1*qdim], &lbf[spos+2*qdim], &lbf[spos+6*qdim], &lbf[spos+16*qdim],
                             &lbf[spos+8*qdim], &lbf[spos+18*qdim], &lbf[spos+4*qdim], &lbf[spos+5*qdim],
                             &lbf[spos+12*qdim], &lbf[spos+10*qdim], &lbf[spos+11*qdim], &lbf[spos+15*qdim],
                             &lbf[spos+7*qdim], &lbf[spos+17*qdim], &lbf[spos+9*qdim], &lbf[spos+13*qdim],
                             &lbf[spos+14*qdim], moment);
        uwall[0] += moment;
        break;
      case PSF:
        fD3Q19PPSCLBEInamuro(p0, &force[0], &lbf[spos], &lbf[spos+11*qdim],
                             &lbf[spos+12*qdim], &lbf[spos+10*qdim], &lbf[spos+17*qdim], &lbf[spos+18*qdim],
                             &lbf[spos+13*qdim], &lbf[spos+5*qdim], &lbf[spos+15*qdim], &lbf[spos+7*qdim],
                             &lbf[spos+2*qdim], &lbf[spos+3*qdim], &lbf[spos+1*qdim], &lbf[spos+8*qdim],
                             &lbf[spos+9*qdim], &lbf[spos+4*qdim], &lbf[spos+14*qdim], &lbf[spos+6*qdim],
                             &lbf[spos+16*qdim], moment);
        uwall[2] -= moment;
        break;
      case PSB:
        fD3Q19PPSCLBEInamuro(p0, &force[0], &lbf[spos], &lbf[spos+2*qdim],
                             &lbf[spos+3*qdim], &lbf[spos+1*qdim], &lbf[spos+8*qdim], &lbf[spos+9*qdim],
                             &lbf[spos+4*qdim], &lbf[spos+14*qdim], &lbf[spos+6*qdim], &lbf[spos+16*qdim],
                             &lbf[spos+11*qdim], &lbf[spos+12*qdim], &lbf[spos+10*qdim], &lbf[spos+17*qdim],
                             &lbf[spos+18*qdim], &lbf[spos+13*qdim], &lbf[spos+5*qdim], &lbf[spos+15*qdim],
                             &lbf[spos+7*qdim], moment);
        uwall[2] += moment;
        break;
      case CCTRB:
        fD3Q19VCCCLBEInamuro(p0, uwall[0], uwall[1], -uwall[2], &force[0], &lbf[spos], &lbf[spos+1*qdim],
                             &lbf[spos+2*qdim], &lbf[spos+12*qdim], &lbf[spos+4*qdim], &lbf[spos+5*qdim],
                             &lbf[spos+7*qdim], &lbf[spos+6*qdim], &lbf[spos+9*qdim], &lbf[spos+8*qdim],
                             &lbf[spos+10*qdim], &lbf[spos+11*qdim], &lbf[spos+3*qdim], &lbf[spos+13*qdim],
                             &lbf[spos+14*qdim], &lbf[spos+16*qdim], &lbf[spos+15*qdim], &lbf[spos+18*qdim],
                             &lbf[spos+17*qdim]);
        break;
      case CCTLB:
        fD3Q19VCCCLBEInamuro(p0, -uwall[0], uwall[1], -uwall[2], &force[0], &lbf[spos], &lbf[spos+10*qdim],
                             &lbf[spos+2*qdim], &lbf[spos+12*qdim], &lbf[spos+14*qdim], &lbf[spos+13*qdim],
                             &lbf[spos+15*qdim], &lbf[spos+16*qdim], &lbf[spos+9*qdim], &lbf[spos+8*qdim],
                             &lbf[spos+1*qdim], &lbf[spos+11*qdim], &lbf[spos+3*qdim], &lbf[spos+5*qdim],
                             &lbf[spos+4*qdim], &lbf[spos+6*qdim], &lbf[spos+7*qdim], &lbf[spos+18*qdim],
                             &lbf[spos+17*qdim]);
        break;
      case CCDLB:
        fD3Q19VCCCLBEInamuro(p0, -uwall[0], -uwall[1], -uwall[2], &force[0], &lbf[spos], &lbf[spos+10*qdim],
                             &lbf[spos+11*qdim], &lbf[spos+12*qdim], &lbf[spos+13*qdim], &lbf[spos+14*qdim],
                             &lbf[spos+15*qdim], &lbf[spos+16*qdim], &lbf[spos+17*qdim], &lbf[spos+18*qdim],
                             &lbf[spos+1*qdim], &lbf[spos+2*qdim], &lbf[spos+3*qdim], &lbf[spos+4*qdim],
                             &lbf[spos+5*qdim], &lbf[spos+6*qdim], &lbf[spos+7*qdim], &lbf[spos+8*qdim],
                             &lbf[spos+9*qdim]);
        break;
      case CCDRB:
        fD3Q19VCCCLBEInamuro(p0, uwall[0], -uwall[1], -uwall[2], &force[0], &lbf[spos], &lbf[spos+1*qdim],
                             &lbf[spos+11*qdim], &lbf[spos+12*qdim], &lbf[spos+5*qdim], &lbf[spos+4*qdim],
                             &lbf[spos+7*qdim], &lbf[spos+6*qdim], &lbf[spos+17*qdim], &lbf[spos+18*qdim],
                             &lbf[spos+10*qdim], &lbf[spos+2*qdim], &lbf[spos+3*qdim], &lbf[spos+14*qdim],
                             &lbf[spos+13*qdim], &lbf[spos+16*qdim], &lbf[spos+15*qdim], &lbf[spos+8*qdim],
                             &lbf[spos+9*qdim]);
        break;
      case CCTRF:
        fD3Q19VCCCLBEInamuro(p0, uwall[0], uwall[1], uwall[2], &force[0], &lbf[spos], &lbf[spos+1*qdim],
                             &lbf[spos+2*qdim], &lbf[spos+3*qdim], &lbf[spos+4*qdim], &lbf[spos+5*qdim],
                             &lbf[spos+6*qdim], &lbf[spos+7*qdim], &lbf[spos+8*qdim], &lbf[spos+9*qdim],
                             &lbf[spos+10*qdim], &lbf[spos+11*qdim], &lbf[spos+12*qdim], &lbf[spos+13*qdim],
                             &lbf[spos+14*qdim], &lbf[spos+15*qdim], &lbf[spos+16*qdim], &lbf[spos+17*qdim],
                             &lbf[spos+18*qdim]);
        break;
      case CCTLF:
        fD3Q19VCCCLBEInamuro(p0, -uwall[0], uwall[1], uwall[2], &force[0], &lbf[spos], &lbf[spos+10*qdim],
                             &lbf[spos+2*qdim], &lbf[spos+3*qdim], &lbf[spos+14*qdim], &lbf[spos+13*qdim],
                             &lbf[spos+16*qdim], &lbf[spos+15*qdim], &lbf[spos+8*qdim], &lbf[spos+9*qdim],
                             &lbf[spos+1*qdim], &lbf[spos+11*qdim], &lbf[spos+12*qdim], &lbf[spos+5*qdim],
                             &lbf[spos+4*qdim], &lbf[spos+7*qdim], &lbf[spos+6*qdim], &lbf[spos+17*qdim],
                             &lbf[spos+18*qdim]);
        break;
      case CCDLF:
        fD3Q19VCCCLBEInamuro(p0, -uwall[0], -uwall[1], uwall[2], &force[0], &lbf[spos], &lbf[spos+10*qdim],
                             &lbf[spos+11*qdim], &lbf[spos+3*qdim], &lbf[spos+13*qdim], &lbf[spos+14*qdim],
                             &lbf[spos+16*qdim], &lbf[spos+15*qdim], &lbf[spos+18*qdim], &lbf[spos+17*qdim],
                             &lbf[spos+1*qdim], &lbf[spos+2*qdim], &lbf[spos+12*qdim], &lbf[spos+4*qdim],
                             &lbf[spos+5*qdim], &lbf[spos+7*qdim], &lbf[spos+6*qdim], &lbf[spos+9*qdim],
                             &lbf[spos+8*qdim]);
        break;
      case CCDRF:
        fD3Q19VCCCLBEInamuro(p0, uwall[0], -uwall[1], uwall[2], &force[0], &lbf[spos], &lbf[spos+1*qdim],
                             &lbf[spos+11*qdim], &lbf[spos+3*qdim], &lbf[spos+5*qdim], &lbf[spos+4*qdim],
                             &lbf[spos+6*qdim], &lbf[spos+7*qdim], &lbf[spos+18*qdim], &lbf[spos+17*qdim],
                             &lbf[spos+10*qdim], &lbf[spos+2*qdim], &lbf[spos+12*qdim], &lbf[spos+14*qdim],
                             &lbf[spos+13*qdim], &lbf[spos+15*qdim], &lbf[spos+16*qdim], &lbf[spos+9*qdim],
                             &lbf[spos+8*qdim]);
        break;
      case CETR:
        fD3Q19VCECLBEInamuro(p0, uwall[0], uwall[1], uwall[2], &force[0], &lbf[spos], &lbf[spos+1*qdim],
                             &lbf[spos+2*qdim], &lbf[spos+3*qdim], &lbf[spos+4*qdim], &lbf[spos+5*qdim],
                             &lbf[spos+6*qdim], &lbf[spos+7*qdim], &lbf[spos+8*qdim], &lbf[spos+9*qdim],
                             &lbf[spos+10*qdim], &lbf[spos+11*qdim], &lbf[spos+12*qdim], &lbf[spos+13*qdim],
                             &lbf[spos+14*qdim], &lbf[spos+15*qdim], &lbf[spos+16*qdim], &lbf[spos+17*qdim],
                             &lbf[spos+18*qdim]);
        break;
      case CETL:
        fD3Q19VCECLBEInamuro(p0, uwall[1], -uwall[0], uwall[2], &force[0], &lbf[spos], &lbf[spos+2*qdim],
                             &lbf[spos+10*qdim], &lbf[spos+3*qdim], &lbf[spos+14*qdim], &lbf[spos+4*qdim],
                             &lbf[spos+8*qdim], &lbf[spos+9*qdim], &lbf[spos+16*qdim], &lbf[spos+15*qdim],
                             &lbf[spos+11*qdim], &lbf[spos+1*qdim], &lbf[spos+12*qdim], &lbf[spos+5*qdim],
                             &lbf[spos+13*qdim], &lbf[spos+17*qdim], &lbf[spos+18*qdim], &lbf[spos+7*qdim],
                             &lbf[spos+6*qdim]);
        break;
      case CEDL:
        fD3Q19VCECLBEInamuro(p0, -uwall[0], -uwall[1], uwall[2], &force[0], &lbf[spos], &lbf[spos+10*qdim],
                             &lbf[spos+11*qdim], &lbf[spos+3*qdim], &lbf[spos+13*qdim], &lbf[spos+14*qdim],
                             &lbf[spos+16*qdim], &lbf[spos+15*qdim], &lbf[spos+18*qdim], &lbf[spos+17*qdim],
                             &lbf[spos+1*qdim], &lbf[spos+2*qdim], &lbf[spos+12*qdim], &lbf[spos+4*qdim],
                             &lbf[spos+5*qdim], &lbf[spos+7*qdim], &lbf[spos+6*qdim], &lbf[spos+9*qdim],
                             &lbf[spos+8*qdim]);
        break;
      case CEDR:
        fD3Q19VCECLBEInamuro(p0, -uwall[1], uwall[0], uwall[2], &force[0], &lbf[spos], &lbf[spos+11*qdim],
                             &lbf[spos+1*qdim], &lbf[spos+3*qdim], &lbf[spos+5*qdim], &lbf[spos+13*qdim],
                             &lbf[spos+18*qdim], &lbf[spos+17*qdim], &lbf[spos+6*qdim], &lbf[spos+7*qdim],
                             &lbf[spos+2*qdim], &lbf[spos+10*qdim], &lbf[spos+12*qdim], &lbf[spos+14*qdim],
                             &lbf[spos+4*qdim], &lbf[spos+9*qdim], &lbf[spos+8*qdim], &lbf[spos+15*qdim],
                             &lbf[spos+16*qdim]);
        break;
      case CETF:
        fD3Q19VCECLBEInamuro(p0, uwall[1], uwall[2], uwall[0], &force[0], &lbf[spos], &lbf[spos+2*qdim],
                             &lbf[spos+3*qdim], &lbf[spos+1*qdim], &lbf[spos+8*qdim], &lbf[spos+9*qdim],
                             &lbf[spos+4*qdim], &lbf[spos+14*qdim], &lbf[spos+6*qdim], &lbf[spos+16*qdim],
                             &lbf[spos+11*qdim], &lbf[spos+12*qdim], &lbf[spos+10*qdim], &lbf[spos+17*qdim],
                             &lbf[spos+18*qdim], &lbf[spos+13*qdim], &lbf[spos+5*qdim], &lbf[spos+15*qdim],
                             &lbf[spos+7*qdim]);
        break;
      case CELF:
        fD3Q19VCECLBEInamuro(p0, -uwall[0], uwall[2], uwall[1], &force[0], &lbf[spos], &lbf[spos+10*qdim],
                             &lbf[spos+3*qdim], &lbf[spos+2*qdim], &lbf[spos+16*qdim], &lbf[spos+15*qdim],
                             &lbf[spos+14*qdim], &lbf[spos+13*qdim], &lbf[spos+8*qdim], &lbf[spos+18*qdim],
                             &lbf[spos+1*qdim], &lbf[spos+12*qdim], &lbf[spos+11*qdim], &lbf[spos+7*qdim],
                             &lbf[spos+6*qdim], &lbf[spos+5*qdim], &lbf[spos+4*qdim], &lbf[spos+17*qdim],
                             &lbf[spos+9*qdim]);
        break;
      case CEDF:
        fD3Q19VCECLBEInamuro(p0, -uwall[1], uwall[2], uwall[0], &force[0], &lbf[spos], &lbf[spos+11*qdim],
                             &lbf[spos+3*qdim], &lbf[spos+1*qdim], &lbf[spos+18*qdim], &lbf[spos+17*qdim],
                             &lbf[spos+5*qdim], &lbf[spos+13*qdim], &lbf[spos+6*qdim], &lbf[spos+16*qdim],
                             &lbf[spos+2*qdim], &lbf[spos+12*qdim], &lbf[spos+10*qdim], &lbf[spos+9*qdim],
                             &lbf[spos+8*qdim], &lbf[spos+14*qdim], &lbf[spos+4*qdim], &lbf[spos+15*qdim],
                             &lbf[spos+7*qdim]);
        break;
      case CERF:
        fD3Q19VCECLBEInamuro(p0, uwall[0], uwall[2], uwall[1], &force[0], &lbf[spos], &lbf[spos+1*qdim],
                             &lbf[spos+3*qdim], &lbf[spos+2*qdim], &lbf[spos+6*qdim], &lbf[spos+7*qdim],
                             &lbf[spos+4*qdim], &lbf[spos+5*qdim], &lbf[spos+8*qdim], &lbf[spos+18*qdim],
                             &lbf[spos+10*qdim], &lbf[spos+12*qdim], &lbf[spos+11*qdim], &lbf[spos+15*qdim],
                             &lbf[spos+16*qdim], &lbf[spos+13*qdim], &lbf[spos+14*qdim], &lbf[spos+17*qdim],
                             &lbf[spos+9*qdim]);
        break;
      case CETB:
        fD3Q19VCECLBEInamuro(p0, uwall[1], -uwall[2], uwall[0], &force[0], &lbf[spos], &lbf[spos+2*qdim],
                             &lbf[spos+12*qdim], &lbf[spos+1*qdim], &lbf[spos+9*qdim], &lbf[spos+8*qdim],
                             &lbf[spos+4*qdim], &lbf[spos+14*qdim], &lbf[spos+7*qdim], &lbf[spos+15*qdim],
                             &lbf[spos+11*qdim], &lbf[spos+3*qdim], &lbf[spos+10*qdim], &lbf[spos+18*qdim],
                             &lbf[spos+17*qdim], &lbf[spos+13*qdim], &lbf[spos+5*qdim], &lbf[spos+16*qdim],
                             &lbf[spos+6*qdim]);
        break;
      case CELB:
        fD3Q19VCECLBEInamuro(p0, -uwall[0], -uwall[2], uwall[1], &force[0], &lbf[spos], &lbf[spos+10*qdim],
                             &lbf[spos+12*qdim], &lbf[spos+2*qdim], &lbf[spos+15*qdim], &lbf[spos+16*qdim],
                             &lbf[spos+14*qdim], &lbf[spos+13*qdim], &lbf[spos+9*qdim], &lbf[spos+17*qdim],
                             &lbf[spos+1*qdim], &lbf[spos+3*qdim], &lbf[spos+11*qdim], &lbf[spos+6*qdim],
                             &lbf[spos+7*qdim], &lbf[spos+5*qdim], &lbf[spos+4*qdim], &lbf[spos+18*qdim],
                             &lbf[spos+8*qdim]);
        break;
      case CEDB:
        fD3Q19VCECLBEInamuro(p0, -uwall[1], -uwall[2], uwall[0], &force[0], &lbf[spos], &lbf[spos+11*qdim],
                             &lbf[spos+12*qdim], &lbf[spos+1*qdim], &lbf[spos+17*qdim], &lbf[spos+18*qdim],
                             &lbf[spos+5*qdim], &lbf[spos+13*qdim], &lbf[spos+7*qdim], &lbf[spos+15*qdim],
                             &lbf[spos+2*qdim], &lbf[spos+3*qdim], &lbf[spos+10*qdim], &lbf[spos+8*qdim],
                             &lbf[spos+9*qdim], &lbf[spos+14*qdim], &lbf[spos+4*qdim], &lbf[spos+16*qdim],
                             &lbf[spos+6*qdim]);
        break;
      case CERB:
        fD3Q19VCECLBEInamuro(p0, uwall[0], -uwall[2], uwall[1], &force[0], &lbf[spos], &lbf[spos+1*qdim],
                             &lbf[spos+12*qdim], &lbf[spos+2*qdim], &lbf[spos+7*qdim], &lbf[spos+6*qdim],
                             &lbf[spos+4*qdim], &lbf[spos+5*qdim], &lbf[spos+9*qdim], &lbf[spos+17*qdim],
                             &lbf[spos+10*qdim], &lbf[spos+3*qdim], &lbf[spos+11*qdim], &lbf[spos+16*qdim],
                             &lbf[spos+15*qdim], &lbf[spos+13*qdim], &lbf[spos+14*qdim], &lbf[spos+18*qdim],
                             &lbf[spos+8*qdim]);
        break;
    }
  }
  else {
    switch (prop) {
      case PST:
        fD3Q19PPSInamuro(p0, &force[0], &lbf[spos], &lbf[spos+1*qdim],
                         &lbf[spos+2*qdim], &lbf[spos+3*qdim], &lbf[spos+4*qdim], &lbf[spos+5*qdim],
                         &lbf[spos+6*qdim], &lbf[spos+7*qdim], &lbf[spos+8*qdim], &lbf[spos+9*qdim],
                         &lbf[spos+10*qdim], &lbf[spos+11*qdim], &lbf[spos+12*qdim], &lbf[spos+13*qdim],
                         &lbf[spos+14*qdim], &lbf[spos+15*qdim], &lbf[spos+16*qdim], &lbf[spos+17*qdim],
                         &lbf[spos+18*qdim], moment);
        uwall[1] += moment;
        break;
      case PSD:
        fD3Q19PPSInamuro(p0, &force[0], &lbf[spos], &lbf[spos+10*qdim],
                         &lbf[spos+11*qdim], &lbf[spos+12*qdim], &lbf[spos+13*qdim], &lbf[spos+14*qdim],
                         &lbf[spos+15*qdim], &lbf[spos+16*qdim], &lbf[spos+17*qdim], &lbf[spos+18*qdim],
                         &lbf[spos+1*qdim], &lbf[spos+2*qdim], &lbf[spos+3*qdim], &lbf[spos+4*qdim],
                         &lbf[spos+5*qdim], &lbf[spos+6*qdim], &lbf[spos+7*qdim], &lbf[spos+8*qdim],
                         &lbf[spos+9*qdim], moment);
        uwall[1] -= moment;
        break;
      case PSL:
        fD3Q19PPSInamuro(p0, &force[0], &lbf[spos], &lbf[spos+12*qdim],
                         &lbf[spos+10*qdim], &lbf[spos+11*qdim], &lbf[spos+15*qdim], &lbf[spos+7*qdim],
                         &lbf[spos+17*qdim], &lbf[spos+9*qdim], &lbf[spos+13*qdim], &lbf[spos+14*qdim],
                         &lbf[spos+3*qdim], &lbf[spos+1*qdim], &lbf[spos+2*qdim], &lbf[spos+6*qdim],
                         &lbf[spos+16*qdim], &lbf[spos+8*qdim], &lbf[spos+18*qdim], &lbf[spos+4*qdim],
                         &lbf[spos+5*qdim], moment);
        uwall[0] -= moment;
        break;
      case PSR:
        fD3Q19PPSInamuro(p0, &force[0], &lbf[spos], &lbf[spos+3*qdim],
                         &lbf[spos+1*qdim], &lbf[spos+2*qdim], &lbf[spos+6*qdim], &lbf[spos+16*qdim],
                         &lbf[spos+8*qdim], &lbf[spos+18*qdim], &lbf[spos+4*qdim], &lbf[spos+5*qdim],
                         &lbf[spos+12*qdim], &lbf[spos+10*qdim], &lbf[spos+11*qdim], &lbf[spos+15*qdim],
                         &lbf[spos+7*qdim], &lbf[spos+17*qdim], &lbf[spos+9*qdim], &lbf[spos+13*qdim],
                         &lbf[spos+14*qdim], moment);
        uwall[0] += moment;
        break;
      case PSF:
        fD3Q19PPSInamuro(p0, &force[0], &lbf[spos], &lbf[spos+11*qdim],
                         &lbf[spos+12*qdim], &lbf[spos+10*qdim], &lbf[spos+17*qdim], &lbf[spos+18*qdim],
                         &lbf[spos+13*qdim], &lbf[spos+5*qdim], &lbf[spos+15*qdim], &lbf[spos+7*qdim],
                         &lbf[spos+2*qdim], &lbf[spos+3*qdim], &lbf[spos+1*qdim], &lbf[spos+8*qdim],
                         &lbf[spos+9*qdim], &lbf[spos+4*qdim], &lbf[spos+14*qdim], &lbf[spos+6*qdim],
                         &lbf[spos+16*qdim], moment);
        uwall[2] -= moment;
        break;
      case PSB:
        fD3Q19PPSInamuro(p0, &force[0], &lbf[spos], &lbf[spos+2*qdim],
                         &lbf[spos+3*qdim], &lbf[spos+1*qdim], &lbf[spos+8*qdim], &lbf[spos+9*qdim],
                         &lbf[spos+4*qdim], &lbf[spos+14*qdim], &lbf[spos+6*qdim], &lbf[spos+16*qdim],
                         &lbf[spos+11*qdim], &lbf[spos+12*qdim], &lbf[spos+10*qdim], &lbf[spos+17*qdim],
                         &lbf[spos+18*qdim], &lbf[spos+13*qdim], &lbf[spos+5*qdim], &lbf[spos+15*qdim],
                         &lbf[spos+7*qdim], moment);
        uwall[2] += moment;
        break;
      case CCTRB:
        fD3Q19VCCInamuro(p0, uwall[0], uwall[1], -uwall[2], &force[0], &lbf[spos], &lbf[spos+1*qdim],
                         &lbf[spos+2*qdim], &lbf[spos+12*qdim], &lbf[spos+4*qdim], &lbf[spos+5*qdim],
                         &lbf[spos+7*qdim], &lbf[spos+6*qdim], &lbf[spos+9*qdim], &lbf[spos+8*qdim],
                         &lbf[spos+10*qdim], &lbf[spos+11*qdim], &lbf[spos+3*qdim], &lbf[spos+13*qdim],
                         &lbf[spos+14*qdim], &lbf[spos+16*qdim], &lbf[spos+15*qdim], &lbf[spos+18*qdim],
                         &lbf[spos+17*qdim]);
        break;
      case CCTLB:
        fD3Q19VCCInamuro(p0, -uwall[0], uwall[1], -uwall[2], &force[0], &lbf[spos], &lbf[spos+10*qdim],
                         &lbf[spos+2*qdim], &lbf[spos+12*qdim], &lbf[spos+14*qdim], &lbf[spos+13*qdim],
                         &lbf[spos+15*qdim], &lbf[spos+16*qdim], &lbf[spos+9*qdim], &lbf[spos+8*qdim],
                         &lbf[spos+1*qdim], &lbf[spos+11*qdim], &lbf[spos+3*qdim], &lbf[spos+5*qdim],
                         &lbf[spos+4*qdim], &lbf[spos+6*qdim], &lbf[spos+7*qdim], &lbf[spos+18*qdim],
                         &lbf[spos+17*qdim]);
        break;
      case CCDLB:
        fD3Q19VCCInamuro(p0, -uwall[0], -uwall[1], -uwall[2], &force[0], &lbf[spos], &lbf[spos+10*qdim],
                         &lbf[spos+11*qdim], &lbf[spos+12*qdim], &lbf[spos+13*qdim], &lbf[spos+14*qdim],
                         &lbf[spos+15*qdim], &lbf[spos+16*qdim], &lbf[spos+17*qdim], &lbf[spos+18*qdim],
                         &lbf[spos+1*qdim], &lbf[spos+2*qdim], &lbf[spos+3*qdim], &lbf[spos+4*qdim],
                         &lbf[spos+5*qdim], &lbf[spos+6*qdim], &lbf[spos+7*qdim], &lbf[spos+8*qdim],
                         &lbf[spos+9*qdim]);
        break;
      case CCDRB:
        fD3Q19VCCInamuro(p0, uwall[0], -uwall[1], -uwall[2], &force[0], &lbf[spos], &lbf[spos+1*qdim],
                         &lbf[spos+11*qdim], &lbf[spos+12*qdim], &lbf[spos+5*qdim], &lbf[spos+4*qdim],
                         &lbf[spos+7*qdim], &lbf[spos+6*qdim], &lbf[spos+17*qdim], &lbf[spos+18*qdim],
                         &lbf[spos+10*qdim], &lbf[spos+2*qdim], &lbf[spos+3*qdim], &lbf[spos+14*qdim],
                         &lbf[spos+13*qdim], &lbf[spos+16*qdim], &lbf[spos+15*qdim], &lbf[spos+8*qdim],
                         &lbf[spos+9*qdim]);
        break;
      case CCTRF:
        fD3Q19VCCInamuro(p0, uwall[0], uwall[1], uwall[2], &force[0], &lbf[spos], &lbf[spos+1*qdim],
                         &lbf[spos+2*qdim], &lbf[spos+3*qdim], &lbf[spos+4*qdim], &lbf[spos+5*qdim],
                         &lbf[spos+6*qdim], &lbf[spos+7*qdim], &lbf[spos+8*qdim], &lbf[spos+9*qdim],
                         &lbf[spos+10*qdim], &lbf[spos+11*qdim], &lbf[spos+12*qdim], &lbf[spos+13*qdim],
                         &lbf[spos+14*qdim], &lbf[spos+15*qdim], &lbf[spos+16*qdim], &lbf[spos+17*qdim],
                         &lbf[spos+18*qdim]);
        break;
      case CCTLF:
        fD3Q19VCCInamuro(p0, -uwall[0], uwall[1], uwall[2], &force[0], &lbf[spos], &lbf[spos+10*qdim],
                         &lbf[spos+2*qdim], &lbf[spos+3*qdim], &lbf[spos+14*qdim], &lbf[spos+13*qdim],
                         &lbf[spos+16*qdim], &lbf[spos+15*qdim], &lbf[spos+8*qdim], &lbf[spos+9*qdim],
                         &lbf[spos+1*qdim], &lbf[spos+11*qdim], &lbf[spos+12*qdim], &lbf[spos+5*qdim],
                         &lbf[spos+4*qdim], &lbf[spos+7*qdim], &lbf[spos+6*qdim], &lbf[spos+17*qdim],
                         &lbf[spos+18*qdim]);
        break;
      case CCDLF:
        fD3Q19VCCInamuro(p0, -uwall[0], -uwall[1], uwall[2], &force[0], &lbf[spos], &lbf[spos+10*qdim],
                         &lbf[spos+11*qdim], &lbf[spos+3*qdim], &lbf[spos+13*qdim], &lbf[spos+14*qdim],
                         &lbf[spos+16*qdim], &lbf[spos+15*qdim], &lbf[spos+18*qdim], &lbf[spos+17*qdim],
                         &lbf[spos+1*qdim], &lbf[spos+2*qdim], &lbf[spos+12*qdim], &lbf[spos+4*qdim],
                         &lbf[spos+5*qdim], &lbf[spos+7*qdim], &lbf[spos+6*qdim], &lbf[spos+9*qdim],
                         &lbf[spos+8*qdim]);
        break;
      case CCDRF:
        fD3Q19VCCInamuro(p0, uwall[0], -uwall[1], uwall[2], &force[0], &lbf[spos], &lbf[spos+1*qdim],
                         &lbf[spos+11*qdim], &lbf[spos+3*qdim], &lbf[spos+5*qdim], &lbf[spos+4*qdim],
                         &lbf[spos+6*qdim], &lbf[spos+7*qdim], &lbf[spos+18*qdim], &lbf[spos+17*qdim],
                         &lbf[spos+10*qdim], &lbf[spos+2*qdim], &lbf[spos+12*qdim], &lbf[spos+14*qdim],
                         &lbf[spos+13*qdim], &lbf[spos+15*qdim], &lbf[spos+16*qdim], &lbf[spos+9*qdim],
                         &lbf[spos+8*qdim]);
        break;
      case CETR:
        fD3Q19VCEInamuro(p0, uwall[0], uwall[1], uwall[2], &force[0], &lbf[spos], &lbf[spos+1*qdim],
                         &lbf[spos+2*qdim], &lbf[spos+3*qdim], &lbf[spos+4*qdim], &lbf[spos+5*qdim],
                         &lbf[spos+6*qdim], &lbf[spos+7*qdim], &lbf[spos+8*qdim], &lbf[spos+9*qdim],
                         &lbf[spos+10*qdim], &lbf[spos+11*qdim], &lbf[spos+12*qdim], &lbf[spos+13*qdim],
                         &lbf[spos+14*qdim], &lbf[spos+15*qdim], &lbf[spos+16*qdim], &lbf[spos+17*qdim],
                         &lbf[spos+18*qdim]);
        break;
      case CETL:
        fD3Q19VCEInamuro(p0, uwall[1], -uwall[0], uwall[2], &force[0], &lbf[spos], &lbf[spos+2*qdim],
                         &lbf[spos+10*qdim], &lbf[spos+3*qdim], &lbf[spos+14*qdim], &lbf[spos+4*qdim],
                         &lbf[spos+8*qdim], &lbf[spos+9*qdim], &lbf[spos+16*qdim], &lbf[spos+15*qdim],
                         &lbf[spos+11*qdim], &lbf[spos+1*qdim], &lbf[spos+12*qdim], &lbf[spos+5*qdim],
                         &lbf[spos+13*qdim], &lbf[spos+17*qdim], &lbf[spos+18*qdim], &lbf[spos+7*qdim],
                         &lbf[spos+6*qdim]);
        break;
      case CEDL:
        fD3Q19VCEInamuro(p0, -uwall[0], -uwall[1], uwall[2], &force[0], &lbf[spos], &lbf[spos+10*qdim],
                         &lbf[spos+11*qdim], &lbf[spos+3*qdim], &lbf[spos+13*qdim], &lbf[spos+14*qdim],
                         &lbf[spos+16*qdim], &lbf[spos+15*qdim], &lbf[spos+18*qdim], &lbf[spos+17*qdim],
                         &lbf[spos+1*qdim], &lbf[spos+2*qdim], &lbf[spos+12*qdim], &lbf[spos+4*qdim],
                         &lbf[spos+5*qdim], &lbf[spos+7*qdim], &lbf[spos+6*qdim], &lbf[spos+9*qdim],
                         &lbf[spos+8*qdim]);
        break;
      case CEDR:
        fD3Q19VCEInamuro(p0, -uwall[1], uwall[0], uwall[2], &force[0], &lbf[spos], &lbf[spos+11*qdim],
                         &lbf[spos+1*qdim], &lbf[spos+3*qdim], &lbf[spos+5*qdim], &lbf[spos+13*qdim],
                         &lbf[spos+18*qdim], &lbf[spos+17*qdim], &lbf[spos+6*qdim], &lbf[spos+7*qdim],
                         &lbf[spos+2*qdim], &lbf[spos+10*qdim], &lbf[spos+12*qdim], &lbf[spos+14*qdim],
                         &lbf[spos+4*qdim], &lbf[spos+9*qdim], &lbf[spos+8*qdim], &lbf[spos+15*qdim],
                         &lbf[spos+16*qdim]);
        break;
      case CETF:
        fD3Q19VCEInamuro(p0, uwall[1], uwall[2], uwall[0], &force[0], &lbf[spos], &lbf[spos+2*qdim],
                         &lbf[spos+3*qdim], &lbf[spos+1*qdim], &lbf[spos+8*qdim], &lbf[spos+9*qdim],
                         &lbf[spos+4*qdim], &lbf[spos+14*qdim], &lbf[spos+6*qdim], &lbf[spos+16*qdim],
                         &lbf[spos+11*qdim], &lbf[spos+12*qdim], &lbf[spos+10*qdim], &lbf[spos+17*qdim],
                         &lbf[spos+18*qdim], &lbf[spos+13*qdim], &lbf[spos+5*qdim], &lbf[spos+15*qdim],
                         &lbf[spos+7*qdim]);
        break;
      case CELF:
        fD3Q19VCEInamuro(p0, -uwall[0], uwall[2], uwall[1], &force[0], &lbf[spos], &lbf[spos+10*qdim],
                         &lbf[spos+3*qdim], &lbf[spos+2*qdim], &lbf[spos+16*qdim], &lbf[spos+15*qdim],
                         &lbf[spos+14*qdim], &lbf[spos+13*qdim], &lbf[spos+8*qdim], &lbf[spos+18*qdim],
                         &lbf[spos+1*qdim], &lbf[spos+12*qdim], &lbf[spos+11*qdim], &lbf[spos+7*qdim],
                         &lbf[spos+6*qdim], &lbf[spos+5*qdim], &lbf[spos+4*qdim], &lbf[spos+17*qdim],
                         &lbf[spos+9*qdim]);
        break;
      case CEDF:
        fD3Q19VCEInamuro(p0, -uwall[1], uwall[2], uwall[0], &force[0], &lbf[spos], &lbf[spos+11*qdim],
                         &lbf[spos+3*qdim], &lbf[spos+1*qdim], &lbf[spos+18*qdim], &lbf[spos+17*qdim],
                         &lbf[spos+5*qdim], &lbf[spos+13*qdim], &lbf[spos+6*qdim], &lbf[spos+16*qdim],
                         &lbf[spos+2*qdim], &lbf[spos+12*qdim], &lbf[spos+10*qdim], &lbf[spos+9*qdim],
                         &lbf[spos+8*qdim], &lbf[spos+14*qdim], &lbf[spos+4*qdim], &lbf[spos+15*qdim],
                         &lbf[spos+7*qdim]);
        break;
      case CERF:
        fD3Q19VCEInamuro(p0, uwall[0], uwall[2], uwall[1], &force[0], &lbf[spos], &lbf[spos+1*qdim],
                         &lbf[spos+3*qdim], &lbf[spos+2*qdim], &lbf[spos+6*qdim], &lbf[spos+7*qdim],
                         &lbf[spos+4*qdim], &lbf[spos+5*qdim], &lbf[spos+8*qdim], &lbf[spos+18*qdim],
                         &lbf[spos+10*qdim], &lbf[spos+12*qdim], &lbf[spos+11*qdim], &lbf[spos+15*qdim],
                         &lbf[spos+16*qdim], &lbf[spos+13*qdim], &lbf[spos+14*qdim], &lbf[spos+17*qdim],
                         &lbf[spos+9*qdim]);
        break;
      case CETB:
        fD3Q19VCEInamuro(p0, uwall[1], -uwall[2], uwall[0], &force[0], &lbf[spos], &lbf[spos+2*qdim],
                         &lbf[spos+12*qdim], &lbf[spos+1*qdim], &lbf[spos+9*qdim], &lbf[spos+8*qdim],
                         &lbf[spos+4*qdim], &lbf[spos+14*qdim], &lbf[spos+7*qdim], &lbf[spos+15*qdim],
                         &lbf[spos+11*qdim], &lbf[spos+3*qdim], &lbf[spos+10*qdim], &lbf[spos+18*qdim],
                         &lbf[spos+17*qdim], &lbf[spos+13*qdim], &lbf[spos+5*qdim], &lbf[spos+16*qdim],
                         &lbf[spos+6*qdim]);
        break;
      case CELB:
        fD3Q19VCEInamuro(p0, -uwall[0], -uwall[2], uwall[1], &force[0], &lbf[spos], &lbf[spos+10*qdim],
                         &lbf[spos+12*qdim], &lbf[spos+2*qdim], &lbf[spos+15*qdim], &lbf[spos+16*qdim],
                         &lbf[spos+14*qdim], &lbf[spos+13*qdim], &lbf[spos+9*qdim], &lbf[spos+17*qdim],
                         &lbf[spos+1*qdim], &lbf[spos+3*qdim], &lbf[spos+11*qdim], &lbf[spos+6*qdim],
                         &lbf[spos+7*qdim], &lbf[spos+5*qdim], &lbf[spos+4*qdim], &lbf[spos+18*qdim],
                         &lbf[spos+8*qdim]);
        break;
      case CEDB:
        fD3Q19VCEInamuro(p0, -uwall[1], -uwall[2], uwall[0], &force[0], &lbf[spos], &lbf[spos+11*qdim],
                         &lbf[spos+12*qdim], &lbf[spos+1*qdim], &lbf[spos+17*qdim], &lbf[spos+18*qdim],
                         &lbf[spos+5*qdim], &lbf[spos+13*qdim], &lbf[spos+7*qdim], &lbf[spos+15*qdim],
                         &lbf[spos+2*qdim], &lbf[spos+3*qdim], &lbf[spos+10*qdim], &lbf[spos+8*qdim],
                         &lbf[spos+9*qdim], &lbf[spos+14*qdim], &lbf[spos+4*qdim], &lbf[spos+16*qdim],
                         &lbf[spos+6*qdim]);
        break;
      case CERB:
        fD3Q19VCEInamuro(p0, uwall[0], -uwall[2], uwall[1], &force[0], &lbf[spos], &lbf[spos+1*qdim],
                         &lbf[spos+12*qdim], &lbf[spos+2*qdim], &lbf[spos+7*qdim], &lbf[spos+6*qdim],
                         &lbf[spos+4*qdim], &lbf[spos+5*qdim], &lbf[spos+9*qdim], &lbf[spos+17*qdim],
                         &lbf[spos+10*qdim], &lbf[spos+3*qdim], &lbf[spos+11*qdim], &lbf[spos+16*qdim],
                         &lbf[spos+15*qdim], &lbf[spos+13*qdim], &lbf[spos+14*qdim], &lbf[spos+18*qdim],
                         &lbf[spos+8*qdim]);
        break;
    }
  }
  return 0;
}


int fD3Q19CPSInamuro(double *p, double v0, double v1, double v2, double *f0, double *f1,
	                 double *f2, double *f3, double *f4, double *f5, double *f6,
                     double *f7, double *f8, double *f9, double *f10, double *f11,
                     double *f12, double *f13, double *f14, double *f15, double *f16,
                     double *f17, double *f18)
{

  // produce fixed concentration at planar surface: expressed for bottom wall (CPST)

  double rhop;
  double c1=1.0/18.0,c2=1.0/36.0;
  for(int i=0; i<lbsy.nc; i++) {
    rhop=6.0*(p[i]-f0[i]-f1[i]-f2[i]-f3[i]-f4[i]-f6[i]-f7[i]-f8[i]-f9[i]-f10[i]-f12[i]-f14[i]-f15[i]-f16[i])/(1.0+3.0*v1);
    f5[i]=c2*rhop*(1.0-3.0*v0+3.0*v1);
    f11[i]=c1*rhop*(1.0+3.0*v1);
    f13[i]=c2*rhop*(1.0+3.0*v0+3.0*v1);
    f17[i]=c2*rhop*(1.0+3.0*v1+3.0*v2);
    f18[i]=c2*rhop*(1.0+3.0*v1-3.0*v2);
  }
  return 0;
}

int fD3Q19CCEInamuro(double *p, double v0, double v1, double v2, double *f0, double *f1,
	                 double *f2, double *f3, double *f4, double *f5, double *f6,
                     double *f7, double *f8, double *f9, double *f10, double *f11,
                     double *f12, double *f13, double *f14, double *f15, double *f16,
                     double *f17, double *f18)
{

  // produce fixed concentration at concave edge: expressed for bottom left edge (CCETR)

  double rhop;
  double c1=1.0/18.0,c2=1.0/36.0;
  for(int i=0; i<lbsy.nc; i++) {
    rhop=36.0*(p[i]-f0[i]-f1[i]-f2[i]-f3[i]-f4[i]-f6[i]-f7[i]-f8[i]-f9[i]-f12[i])/(11.0+15.0*(v0+v1));
    f5[i]=c2*rhop*(1.0-3.0*v0+3.0*v1);
    f10[i]=c1*rhop*(1.0+3.0*v0);
    f11[i]=c1*rhop*(1.0+3.0*v1);
    f13[i]=c2*rhop*(1.0+3.0*v0+3.0*v1);
    f14[i]=c2*rhop*(1.0+3.0*v0-3.0*v1);
    f15[i]=c2*rhop*(1.0+3.0*v0+3.0*v2);
    f16[i]=c2*rhop*(1.0+3.0*v0-3.0*v2);
    f17[i]=c2*rhop*(1.0+3.0*v1+3.0*v2);
    f18[i]=c2*rhop*(1.0+3.0*v1-3.0*v2);
  }
  return 0;
}

int fD3Q19CCCInamuro(double *p, double v0, double v1, double v2, double *f0, double *f1,
	                 double *f2, double *f3, double *f4, double *f5, double *f6,
                     double *f7, double *f8, double *f9, double *f10, double *f11,
                     double *f12, double *f13, double *f14, double *f15, double *f16,
                     double *f17, double *f18)
{

  // produce fixed concentration at concave corner: expressed for bottom left back corner (CCCTRF)

  double rhop;
  double c1=1.0/18.0,c2=1.0/36.0;
  for(int i=0; i<lbsy.nc; i++) {
    rhop=24.0*(p[i]-f0[i]-f1[i]-f2[i]-f3[i]-f4[i]-f6[i]-f8[i])/(5.0+4.0*(v0+v1+v2));
    f5[i]=c2*rhop*(1.0-3.0*v0+3.0*v1);
    f7[i]=c2*rhop*(1.0-3.0*v0+3.0*v2);
    f9[i]=c2*rhop*(1.0-3.0*v1+3.0*v2);
    f10[i]=c1*rhop*(1.0+3.0*v0);
    f11[i]=c1*rhop*(1.0+3.0*v1);
    f12[i]=c1*rhop*(1.0+3.0*v2);
    f13[i]=c2*rhop*(1.0+3.0*v0+3.0*v1);
    f14[i]=c2*rhop*(1.0+3.0*v0-3.0*v1);
    f15[i]=c2*rhop*(1.0+3.0*v0+3.0*v2);
    f16[i]=c2*rhop*(1.0+3.0*v0-3.0*v2);
    f17[i]=c2*rhop*(1.0+3.0*v1+3.0*v2);
    f18[i]=c2*rhop*(1.0+3.0*v1-3.0*v2);
  }
  return 0;
}


int fD3Q19PCInamuro(long tpos, int prop, double *p0, double *uwall)
{
  long spos=tpos * lbsitelength + lbsy.nf;
  int qdim=lbsy.nf+lbsy.nc+lbsy.nt;
    
  switch (prop) {
    case PST:
      fD3Q19CPSInamuro(p0, uwall[0], uwall[1], uwall[2], &lbf[spos], &lbf[spos+1*qdim],
                       &lbf[spos+2*qdim], &lbf[spos+3*qdim], &lbf[spos+4*qdim], &lbf[spos+5*qdim], &lbf[spos+6*qdim],
                       &lbf[spos+7*qdim], &lbf[spos+8*qdim], &lbf[spos+9*qdim], &lbf[spos+10*qdim], &lbf[spos+11*qdim],
                       &lbf[spos+12*qdim], &lbf[spos+13*qdim], &lbf[spos+14*qdim], &lbf[spos+15*qdim], &lbf[spos+16*qdim],
                       &lbf[spos+17*qdim], &lbf[spos+18*qdim]);
      break;
    case PSD:
      fD3Q19CPSInamuro(p0, -uwall[0], -uwall[1], -uwall[2], &lbf[spos], &lbf[spos+10*qdim],
                       &lbf[spos+11*qdim], &lbf[spos+12*qdim], &lbf[spos+13*qdim], &lbf[spos+14*qdim], &lbf[spos+15*qdim],
                       &lbf[spos+16*qdim], &lbf[spos+17*qdim], &lbf[spos+18*qdim], &lbf[spos+1*qdim], &lbf[spos+2*qdim],
                       &lbf[spos+3*qdim], &lbf[spos+4*qdim], &lbf[spos+5*qdim], &lbf[spos+6*qdim], &lbf[spos+7*qdim],
                       &lbf[spos+8*qdim], &lbf[spos+9*qdim]);
      break;
    case PSL:
      fD3Q19CPSInamuro(p0, -uwall[2], -uwall[0], -uwall[1], &lbf[spos], &lbf[spos+12*qdim],
                       &lbf[spos+10*qdim], &lbf[spos+11*qdim], &lbf[spos+15*qdim], &lbf[spos+7*qdim], &lbf[spos+17*qdim],
                       &lbf[spos+9*qdim], &lbf[spos+13*qdim], &lbf[spos+14*qdim], &lbf[spos+3*qdim], &lbf[spos+1*qdim],
                       &lbf[spos+2*qdim], &lbf[spos+6*qdim], &lbf[spos+16*qdim], &lbf[spos+8*qdim], &lbf[spos+18*qdim],
                       &lbf[spos+4*qdim], &lbf[spos+5*qdim]);
      break;
    case PSR:
      fD3Q19CPSInamuro(p0, uwall[2], uwall[0], uwall[1], &lbf[spos], &lbf[spos+3*qdim],
                       &lbf[spos+1*qdim], &lbf[spos+2*qdim], &lbf[spos+6*qdim], &lbf[spos+16*qdim], &lbf[spos+8*qdim],
                       &lbf[spos+18*qdim], &lbf[spos+4*qdim], &lbf[spos+5*qdim], &lbf[spos+12*qdim], &lbf[spos+10*qdim],
                       &lbf[spos+11*qdim], &lbf[spos+15*qdim], &lbf[spos+7*qdim], &lbf[spos+17*qdim], &lbf[spos+9*qdim],
                       &lbf[spos+13*qdim], &lbf[spos+14*qdim]);
      break;
    case PSF:
      fD3Q19CPSInamuro(p0, -uwall[1], -uwall[2], -uwall[0], &lbf[spos], &lbf[spos+11*qdim],
                       &lbf[spos+12*qdim], &lbf[spos+10*qdim], &lbf[spos+17*qdim], &lbf[spos+18*qdim], &lbf[spos+13*qdim],
                       &lbf[spos+5*qdim], &lbf[spos+15*qdim], &lbf[spos+7*qdim], &lbf[spos+2*qdim], &lbf[spos+3*qdim],
                       &lbf[spos+1*qdim], &lbf[spos+8*qdim], &lbf[spos+9*qdim], &lbf[spos+4*qdim], &lbf[spos+14*qdim],
                       &lbf[spos+6*qdim], &lbf[spos+15*qdim]);
      break;
    case PSB:
      fD3Q19CPSInamuro(p0, uwall[1], uwall[2], uwall[0], &lbf[spos], &lbf[spos+2*qdim],
                       &lbf[spos+3*qdim], &lbf[spos+1*qdim], &lbf[spos+8*qdim], &lbf[spos+9*qdim], &lbf[spos+4*qdim],
                       &lbf[spos+14*qdim], &lbf[spos+6*qdim], &lbf[spos+16*qdim], &lbf[spos+11*qdim], &lbf[spos+12*qdim],
                       &lbf[spos+10*qdim], &lbf[spos+17*qdim], &lbf[spos+18*qdim], &lbf[spos+13*qdim], &lbf[spos+5*qdim],
                       &lbf[spos+15*qdim], &lbf[spos+7*qdim]);
      break;
    case CCTRB:
      fD3Q19CCCInamuro(p0, uwall[0], uwall[1], -uwall[2], &lbf[spos], &lbf[spos+1*qdim],
                       &lbf[spos+2*qdim], &lbf[spos+12*qdim], &lbf[spos+4*qdim], &lbf[spos+5*qdim],
                       &lbf[spos+7*qdim], &lbf[spos+6*qdim], &lbf[spos+9*qdim], &lbf[spos+8*qdim],
                       &lbf[spos+10*qdim], &lbf[spos+11*qdim], &lbf[spos+3*qdim], &lbf[spos+13*qdim],
                       &lbf[spos+14*qdim], &lbf[spos+16*qdim], &lbf[spos+15*qdim], &lbf[spos+18*qdim],
                       &lbf[spos+17*qdim]);
      break;
    case CCTLB:
      fD3Q19CCCInamuro(p0, -uwall[0], uwall[1], -uwall[2], &lbf[spos], &lbf[spos+10*qdim],
                       &lbf[spos+2*qdim], &lbf[spos+12*qdim], &lbf[spos+14*qdim], &lbf[spos+13*qdim],
                       &lbf[spos+15*qdim], &lbf[spos+16*qdim], &lbf[spos+9*qdim], &lbf[spos+8*qdim],
                       &lbf[spos+1*qdim], &lbf[spos+11*qdim], &lbf[spos+3*qdim], &lbf[spos+5*qdim],
                       &lbf[spos+4*qdim], &lbf[spos+6*qdim], &lbf[spos+7*qdim], &lbf[spos+18*qdim],
                       &lbf[spos+17*qdim]);
      break;
    case CCDLB:
      fD3Q19CCCInamuro(p0, -uwall[0], -uwall[1], -uwall[2], &lbf[spos], &lbf[spos+10*qdim],
                       &lbf[spos+11*qdim], &lbf[spos+12*qdim], &lbf[spos+13*qdim], &lbf[spos+14*qdim],
                       &lbf[spos+15*qdim], &lbf[spos+16*qdim], &lbf[spos+17*qdim], &lbf[spos+18*qdim],
                       &lbf[spos+1*qdim], &lbf[spos+2*qdim], &lbf[spos+3*qdim], &lbf[spos+4*qdim],
                       &lbf[spos+5*qdim], &lbf[spos+6*qdim], &lbf[spos+7*qdim], &lbf[spos+8*qdim],
                       &lbf[spos+9*qdim]);
      break;
    case CCDRB:
      fD3Q19CCCInamuro(p0, uwall[0], -uwall[1], -uwall[2], &lbf[spos], &lbf[spos+1*qdim],
                       &lbf[spos+11*qdim], &lbf[spos+12*qdim], &lbf[spos+5*qdim], &lbf[spos+4*qdim],
                       &lbf[spos+7*qdim], &lbf[spos+6*qdim], &lbf[spos+17*qdim], &lbf[spos+18*qdim],
                       &lbf[spos+10*qdim], &lbf[spos+2*qdim], &lbf[spos+3*qdim], &lbf[spos+14*qdim],
                       &lbf[spos+13*qdim], &lbf[spos+16*qdim], &lbf[spos+15*qdim], &lbf[spos+8*qdim],
                       &lbf[spos+9*qdim]);
      break;
    case CCTRF:
      fD3Q19CCCInamuro(p0, uwall[0], uwall[1], uwall[2], &lbf[spos], &lbf[spos+1*qdim],
                       &lbf[spos+2*qdim], &lbf[spos+3*qdim], &lbf[spos+4*qdim], &lbf[spos+5*qdim],
                       &lbf[spos+6*qdim], &lbf[spos+7*qdim], &lbf[spos+8*qdim], &lbf[spos+9*qdim],
                       &lbf[spos+10*qdim], &lbf[spos+11*qdim], &lbf[spos+12*qdim], &lbf[spos+13*qdim],
                       &lbf[spos+14*qdim], &lbf[spos+15*qdim], &lbf[spos+16*qdim], &lbf[spos+17*qdim],
                       &lbf[spos+18*qdim]);
      break;
    case CCTLF:
      fD3Q19CCCInamuro(p0, -uwall[0], uwall[1], uwall[2], &lbf[spos], &lbf[spos+10*qdim],
                       &lbf[spos+2*qdim], &lbf[spos+3*qdim], &lbf[spos+14*qdim], &lbf[spos+13*qdim],
                       &lbf[spos+16*qdim], &lbf[spos+15*qdim], &lbf[spos+8*qdim], &lbf[spos+9*qdim],
                       &lbf[spos+1*qdim], &lbf[spos+11*qdim], &lbf[spos+12*qdim], &lbf[spos+5*qdim],
                       &lbf[spos+4*qdim], &lbf[spos+7*qdim], &lbf[spos+6*qdim], &lbf[spos+17*qdim],
                       &lbf[spos+18*qdim]);
      break;
    case CCDLF:
      fD3Q19CCCInamuro(p0, -uwall[0], -uwall[1], uwall[2], &lbf[spos], &lbf[spos+10*qdim],
                       &lbf[spos+11*qdim], &lbf[spos+3*qdim], &lbf[spos+13*qdim], &lbf[spos+14*qdim],
                       &lbf[spos+16*qdim], &lbf[spos+15*qdim], &lbf[spos+18*qdim], &lbf[spos+17*qdim],
                       &lbf[spos+1*qdim], &lbf[spos+2*qdim], &lbf[spos+12*qdim], &lbf[spos+4*qdim],
                       &lbf[spos+5*qdim], &lbf[spos+7*qdim], &lbf[spos+6*qdim], &lbf[spos+9*qdim],
                       &lbf[spos+8*qdim]);
      break;
    case CCDRF:
      fD3Q19CCCInamuro(p0, uwall[0], -uwall[1], uwall[2], &lbf[spos], &lbf[spos+1*qdim],
                       &lbf[spos+11*qdim], &lbf[spos+3*qdim], &lbf[spos+5*qdim], &lbf[spos+4*qdim],
                       &lbf[spos+6*qdim], &lbf[spos+7*qdim], &lbf[spos+18*qdim], &lbf[spos+17*qdim],
                       &lbf[spos+10*qdim], &lbf[spos+2*qdim], &lbf[spos+12*qdim], &lbf[spos+14*qdim],
                       &lbf[spos+13*qdim], &lbf[spos+15*qdim], &lbf[spos+16*qdim], &lbf[spos+9*qdim],
                       &lbf[spos+8*qdim]);
      break;
    case CETR:
      fD3Q19CCEInamuro(p0, uwall[0], uwall[1], uwall[2], &lbf[spos], &lbf[spos+1*qdim],
                       &lbf[spos+2*qdim], &lbf[spos+3*qdim], &lbf[spos+4*qdim], &lbf[spos+5*qdim],
                       &lbf[spos+6*qdim], &lbf[spos+7*qdim], &lbf[spos+8*qdim], &lbf[spos+9*qdim],
                       &lbf[spos+10*qdim], &lbf[spos+11*qdim], &lbf[spos+12*qdim], &lbf[spos+13*qdim],
                       &lbf[spos+14*qdim], &lbf[spos+15*qdim], &lbf[spos+16*qdim], &lbf[spos+17*qdim],
                       &lbf[spos+18*qdim]);
      break;
    case CETL:
      fD3Q19CCEInamuro(p0, uwall[1], -uwall[0], uwall[2], &lbf[spos], &lbf[spos+2*qdim],
                       &lbf[spos+10*qdim], &lbf[spos+3*qdim], &lbf[spos+14*qdim], &lbf[spos+4*qdim],
                       &lbf[spos+8*qdim], &lbf[spos+9*qdim], &lbf[spos+16*qdim], &lbf[spos+15*qdim],
                       &lbf[spos+11*qdim], &lbf[spos+1*qdim], &lbf[spos+12*qdim], &lbf[spos+5*qdim],
                       &lbf[spos+13*qdim], &lbf[spos+17*qdim], &lbf[spos+18*qdim], &lbf[spos+7*qdim],
                       &lbf[spos+6*qdim]);
      break;
    case CEDL:
      fD3Q19CCEInamuro(p0, -uwall[0], -uwall[1], uwall[2], &lbf[spos], &lbf[spos+10*qdim],
                       &lbf[spos+11*qdim], &lbf[spos+3*qdim], &lbf[spos+13*qdim], &lbf[spos+14*qdim],
                       &lbf[spos+16*qdim], &lbf[spos+15*qdim], &lbf[spos+18*qdim], &lbf[spos+17*qdim],
                       &lbf[spos+1*qdim], &lbf[spos+2*qdim], &lbf[spos+12*qdim], &lbf[spos+4*qdim],
                       &lbf[spos+5*qdim], &lbf[spos+7*qdim], &lbf[spos+6*qdim], &lbf[spos+9*qdim],
                       &lbf[spos+8*qdim]);
      break;
    case CEDR:
      fD3Q19CCEInamuro(p0, -uwall[1], uwall[0], uwall[2], &lbf[spos], &lbf[spos+11*qdim],
                       &lbf[spos+1*qdim], &lbf[spos+3*qdim], &lbf[spos+5*qdim], &lbf[spos+13*qdim],
                       &lbf[spos+18*qdim], &lbf[spos+17*qdim], &lbf[spos+6*qdim], &lbf[spos+7*qdim],
                       &lbf[spos+2*qdim], &lbf[spos+10*qdim], &lbf[spos+12*qdim], &lbf[spos+14*qdim],
                       &lbf[spos+4*qdim], &lbf[spos+9*qdim], &lbf[spos+8*qdim], &lbf[spos+15*qdim],
                       &lbf[spos+16*qdim]);
      break;
    case CETF:
      fD3Q19CCEInamuro(p0, uwall[1], uwall[2], uwall[0], &lbf[spos], &lbf[spos+2*qdim],
                       &lbf[spos+3*qdim], &lbf[spos+1*qdim], &lbf[spos+8*qdim], &lbf[spos+9*qdim],
                       &lbf[spos+4*qdim], &lbf[spos+14*qdim], &lbf[spos+6*qdim], &lbf[spos+16*qdim],
                       &lbf[spos+11*qdim], &lbf[spos+12*qdim], &lbf[spos+10*qdim], &lbf[spos+17*qdim],
                       &lbf[spos+18*qdim], &lbf[spos+13*qdim], &lbf[spos+5*qdim], &lbf[spos+15*qdim],
                       &lbf[spos+7*qdim]);
      break;
    case CELF:
      fD3Q19CCEInamuro(p0, -uwall[0], uwall[2], uwall[1], &lbf[spos], &lbf[spos+10*qdim],
                       &lbf[spos+3*qdim], &lbf[spos+2*qdim], &lbf[spos+16*qdim], &lbf[spos+15*qdim],
                       &lbf[spos+14*qdim], &lbf[spos+13*qdim], &lbf[spos+8*qdim], &lbf[spos+18*qdim],
                       &lbf[spos+1*qdim], &lbf[spos+12*qdim], &lbf[spos+11*qdim], &lbf[spos+7*qdim],
                       &lbf[spos+6*qdim], &lbf[spos+5*qdim], &lbf[spos+4*qdim], &lbf[spos+17*qdim],
                       &lbf[spos+9*qdim]);
      break;
    case CEDF:
      fD3Q19CCEInamuro(p0, -uwall[1], uwall[2], uwall[0], &lbf[spos], &lbf[spos+11*qdim],
                       &lbf[spos+3*qdim], &lbf[spos+1*qdim], &lbf[spos+18*qdim], &lbf[spos+17*qdim],
                       &lbf[spos+5*qdim], &lbf[spos+13*qdim], &lbf[spos+6*qdim], &lbf[spos+16*qdim],
                       &lbf[spos+2*qdim], &lbf[spos+12*qdim], &lbf[spos+10*qdim], &lbf[spos+9*qdim],
                       &lbf[spos+8*qdim], &lbf[spos+14*qdim], &lbf[spos+4*qdim], &lbf[spos+15*qdim],
                       &lbf[spos+7*qdim]);
      break;
    case CERF:
      fD3Q19CCEInamuro(p0, uwall[0], uwall[2], uwall[1], &lbf[spos], &lbf[spos+1*qdim],
                       &lbf[spos+3*qdim], &lbf[spos+2*qdim], &lbf[spos+6*qdim], &lbf[spos+7*qdim],
                       &lbf[spos+4*qdim], &lbf[spos+5*qdim], &lbf[spos+8*qdim], &lbf[spos+18*qdim],
                       &lbf[spos+10*qdim], &lbf[spos+12*qdim], &lbf[spos+11*qdim], &lbf[spos+15*qdim],
                       &lbf[spos+16*qdim], &lbf[spos+13*qdim], &lbf[spos+14*qdim], &lbf[spos+17*qdim],
                       &lbf[spos+9*qdim]);
      break;
    case CETB:
      fD3Q19CCEInamuro(p0, uwall[1], -uwall[2], uwall[0], &lbf[spos], &lbf[spos+2*qdim],
                       &lbf[spos+12*qdim], &lbf[spos+1*qdim], &lbf[spos+9*qdim], &lbf[spos+8*qdim],
                       &lbf[spos+4*qdim], &lbf[spos+14*qdim], &lbf[spos+7*qdim], &lbf[spos+15*qdim],
                       &lbf[spos+11*qdim], &lbf[spos+3*qdim], &lbf[spos+10*qdim], &lbf[spos+18*qdim],
                       &lbf[spos+17*qdim], &lbf[spos+13*qdim], &lbf[spos+5*qdim], &lbf[spos+16*qdim],
                       &lbf[spos+6*qdim]);
      break;
    case CELB:
      fD3Q19CCEInamuro(p0, -uwall[0], -uwall[2], uwall[1], &lbf[spos], &lbf[spos+10*qdim],
                       &lbf[spos+12*qdim], &lbf[spos+2*qdim], &lbf[spos+15*qdim], &lbf[spos+16*qdim],
                       &lbf[spos+14*qdim], &lbf[spos+13*qdim], &lbf[spos+9*qdim], &lbf[spos+17*qdim],
                       &lbf[spos+1*qdim], &lbf[spos+3*qdim], &lbf[spos+11*qdim], &lbf[spos+6*qdim],
                       &lbf[spos+7*qdim], &lbf[spos+5*qdim], &lbf[spos+4*qdim], &lbf[spos+18*qdim],
                       &lbf[spos+8*qdim]);
      break;
    case CEDB:
      fD3Q19CCEInamuro(p0, -uwall[1], -uwall[2], uwall[0], &lbf[spos], &lbf[spos+11*qdim],
                       &lbf[spos+12*qdim], &lbf[spos+1*qdim], &lbf[spos+17*qdim], &lbf[spos+18*qdim],
                       &lbf[spos+5*qdim], &lbf[spos+13*qdim], &lbf[spos+7*qdim], &lbf[spos+15*qdim],
                       &lbf[spos+2*qdim], &lbf[spos+3*qdim], &lbf[spos+10*qdim], &lbf[spos+8*qdim],
                       &lbf[spos+9*qdim], &lbf[spos+14*qdim], &lbf[spos+4*qdim], &lbf[spos+16*qdim],
                       &lbf[spos+6*qdim]);
      break;
    case CERB:
      fD3Q19CCEInamuro(p0, uwall[0], -uwall[2], uwall[1], &lbf[spos], &lbf[spos+1*qdim],
                       &lbf[spos+12*qdim], &lbf[spos+2*qdim], &lbf[spos+7*qdim], &lbf[spos+6*qdim],
                       &lbf[spos+4*qdim], &lbf[spos+5*qdim], &lbf[spos+9*qdim], &lbf[spos+17*qdim],
                       &lbf[spos+10*qdim], &lbf[spos+3*qdim], &lbf[spos+11*qdim], &lbf[spos+16*qdim],
                       &lbf[spos+15*qdim], &lbf[spos+13*qdim], &lbf[spos+14*qdim], &lbf[spos+18*qdim],
                       &lbf[spos+8*qdim]);
      break;
  }
  return 0;
}

int fD3Q19TPSInamuro(double p, double v0, double v1, double v2, double *f0, double *f1,
	                 double *f2, double *f3, double *f4, double *f5, double *f6,
                     double *f7, double *f8, double *f9, double *f10, double *f11,
                     double *f12, double *f13, double *f14, double *f15, double *f16,
                     double *f17, double *f18)
{

  // produce fixed temperature at planar surface: expressed for bottom wall (TPST)

  double rhop;
  double c1=1.0/18.0,c2=1.0/36.0;
  rhop=6.0*(p-f0[0]-f1[0]-f2[0]-f3[0]-f4[0]-f6[0]-f7[0]-f8[0]-f9[0]-f10[0]-f12[0]-f14[0]-f15[0]-f16[0])/(1.0+3.0*v1);
  f5[0]=c2*rhop*(1.0-3.0*v0+3.0*v1);
  f11[0]=c1*rhop*(1.0+3.0*v1);
  f13[0]=c2*rhop*(1.0+3.0*v0+3.0*v1);
  f17[0]=c2*rhop*(1.0+3.0*v1+3.0*v2);
  f18[0]=c2*rhop*(1.0+3.0*v1-3.0*v2);
  return 0;
}

int fD3Q19TCEInamuro(double p, double v0, double v1, double v2, double *f0, double *f1,
	                 double *f2, double *f3, double *f4, double *f5, double *f6,
                     double *f7, double *f8, double *f9, double *f10, double *f11,
                     double *f12, double *f13, double *f14, double *f15, double *f16,
                     double *f17, double *f18)
{

  // produce fixed temperature at concave edge: expressed for bottom left edge (TCETR)

  double rhop;
  double c1=1.0/18.0,c2=1.0/36.0;
  rhop=36.0*(p-f0[0]-f1[0]-f2[0]-f3[0]-f4[0]-f6[0]-f7[0]-f8[0]-f9[0]-f12[0])/(11.0+15.0*(v0+v1));
  f5[0]=c2*rhop*(1.0-3.0*v0+3.0*v1);
  f10[0]=c1*rhop*(1.0+3.0*v0);
  f11[0]=c1*rhop*(1.0+3.0*v1);
  f13[0]=c2*rhop*(1.0+3.0*v0+3.0*v1);
  f14[0]=c2*rhop*(1.0+3.0*v0-3.0*v1);
  f15[0]=c2*rhop*(1.0+3.0*v0+3.0*v2);
  f16[0]=c2*rhop*(1.0+3.0*v0-3.0*v2);
  f17[0]=c2*rhop*(1.0+3.0*v1+3.0*v2);
  f18[0]=c2*rhop*(1.0+3.0*v1-3.0*v2);
  return 0;
}

int fD3Q19TCCInamuro(double p, double v0, double v1, double v2, double *f0, double *f1,
	                 double *f2, double *f3, double *f4, double *f5, double *f6,
                     double *f7, double *f8, double *f9, double *f10, double *f11,
                     double *f12, double *f13, double *f14, double *f15, double *f16,
                     double *f17, double *f18)
{

  // produce fixed temperature at concave corner: expressed for bottom left back corner (TCCTRF)

  double rhop;
  double c1=1.0/18.0,c2=1.0/36.0;
  rhop=24.0*(p-f0[0]-f1[0]-f2[0]-f3[0]-f4[0]-f6[0]-f8[0])/(5.0+4.0*(v0+v1+v2));
  f5[0]=c2*rhop*(1.0-3.0*v0+3.0*v1);
  f7[0]=c2*rhop*(1.0-3.0*v0+3.0*v2);
  f9[0]=c2*rhop*(1.0-3.0*v1+3.0*v2);
  f10[0]=c1*rhop*(1.0+3.0*v0);
  f11[0]=c1*rhop*(1.0+3.0*v1);
  f12[0]=c1*rhop*(1.0+3.0*v2);
  f13[0]=c2*rhop*(1.0+3.0*v0+3.0*v1);
  f14[0]=c2*rhop*(1.0+3.0*v0-3.0*v1);
  f15[0]=c2*rhop*(1.0+3.0*v0+3.0*v2);
  f16[0]=c2*rhop*(1.0+3.0*v0-3.0*v2);
  f17[0]=c2*rhop*(1.0+3.0*v1+3.0*v2);
  f18[0]=c2*rhop*(1.0+3.0*v1-3.0*v2);
  return 0;
}


int fD3Q19PTInamuro(long tpos, int prop, double p0, double *uwall)
{
  long spos=tpos * lbsitelength + (lbsy.nf + lbsy.nc);
  int qdim=lbsy.nf+lbsy.nc+lbsy.nt;
    
  switch (prop) {
    case PST:
      fD3Q19TPSInamuro(p0, uwall[0], uwall[1], uwall[2], &lbf[spos], &lbf[spos+1*qdim],
                       &lbf[spos+2*qdim], &lbf[spos+3*qdim], &lbf[spos+4*qdim], &lbf[spos+5*qdim], &lbf[spos+6*qdim],
                       &lbf[spos+7*qdim], &lbf[spos+8*qdim], &lbf[spos+9*qdim], &lbf[spos+10*qdim], &lbf[spos+11*qdim],
                       &lbf[spos+12*qdim], &lbf[spos+13*qdim], &lbf[spos+14*qdim], &lbf[spos+15*qdim], &lbf[spos+16*qdim],
                       &lbf[spos+17*qdim], &lbf[spos+18*qdim]);
      break;
    case PSD:
      fD3Q19TPSInamuro(p0, -uwall[0], -uwall[1], -uwall[2], &lbf[spos], &lbf[spos+10*qdim],
                       &lbf[spos+11*qdim], &lbf[spos+12*qdim], &lbf[spos+13*qdim], &lbf[spos+14*qdim], &lbf[spos+15*qdim],
                       &lbf[spos+16*qdim], &lbf[spos+17*qdim], &lbf[spos+18*qdim], &lbf[spos+1*qdim], &lbf[spos+2*qdim],
                       &lbf[spos+3*qdim], &lbf[spos+4*qdim], &lbf[spos+5*qdim], &lbf[spos+6*qdim], &lbf[spos+7*qdim],
                       &lbf[spos+8*qdim], &lbf[spos+9*qdim]);
      break;
    case PSL:
      fD3Q19TPSInamuro(p0, -uwall[2], -uwall[0], -uwall[1], &lbf[spos], &lbf[spos+12*qdim],
                       &lbf[spos+10*qdim], &lbf[spos+11*qdim], &lbf[spos+15*qdim], &lbf[spos+7*qdim], &lbf[spos+17*qdim],
                       &lbf[spos+9*qdim], &lbf[spos+13*qdim], &lbf[spos+14*qdim], &lbf[spos+3*qdim], &lbf[spos+1*qdim],
                       &lbf[spos+2*qdim], &lbf[spos+6*qdim], &lbf[spos+16*qdim], &lbf[spos+8*qdim], &lbf[spos+18*qdim],
                       &lbf[spos+4*qdim], &lbf[spos+5*qdim]);
      break;
    case PSR:
      fD3Q19TPSInamuro(p0, uwall[2], uwall[0], uwall[1], &lbf[spos], &lbf[spos+3*qdim],
                       &lbf[spos+1*qdim], &lbf[spos+2*qdim], &lbf[spos+6*qdim], &lbf[spos+16*qdim], &lbf[spos+8*qdim],
                       &lbf[spos+18*qdim], &lbf[spos+4*qdim], &lbf[spos+5*qdim], &lbf[spos+12*qdim], &lbf[spos+10*qdim],
                       &lbf[spos+11*qdim], &lbf[spos+15*qdim], &lbf[spos+7*qdim], &lbf[spos+17*qdim], &lbf[spos+9*qdim],
                       &lbf[spos+13*qdim], &lbf[spos+14*qdim]);
      break;
    case PSF:
      fD3Q19TPSInamuro(p0, -uwall[1], -uwall[2], -uwall[0], &lbf[spos], &lbf[spos+11*qdim],
                       &lbf[spos+12*qdim], &lbf[spos+10*qdim], &lbf[spos+17*qdim], &lbf[spos+18*qdim], &lbf[spos+13*qdim],
                       &lbf[spos+5*qdim], &lbf[spos+15*qdim], &lbf[spos+7*qdim], &lbf[spos+2*qdim], &lbf[spos+3*qdim],
                       &lbf[spos+1*qdim], &lbf[spos+8*qdim], &lbf[spos+9*qdim], &lbf[spos+4*qdim], &lbf[spos+14*qdim],
                       &lbf[spos+6*qdim], &lbf[spos+15*qdim]);
      break;
    case PSB:
      fD3Q19TPSInamuro(p0, uwall[1], uwall[2], uwall[0], &lbf[spos], &lbf[spos+2*qdim],
                       &lbf[spos+3*qdim], &lbf[spos+1*qdim], &lbf[spos+8*qdim], &lbf[spos+9*qdim], &lbf[spos+4*qdim],
                       &lbf[spos+14*qdim], &lbf[spos+6*qdim], &lbf[spos+16*qdim], &lbf[spos+11*qdim], &lbf[spos+12*qdim],
                       &lbf[spos+10*qdim], &lbf[spos+17*qdim], &lbf[spos+18*qdim], &lbf[spos+13*qdim], &lbf[spos+5*qdim],
                       &lbf[spos+15*qdim], &lbf[spos+7*qdim]);
      break;
    case CCTRB:
      fD3Q19TCCInamuro(p0, uwall[0], uwall[1], -uwall[2], &lbf[spos], &lbf[spos+1*qdim],
                       &lbf[spos+2*qdim], &lbf[spos+12*qdim], &lbf[spos+4*qdim], &lbf[spos+5*qdim],
                       &lbf[spos+7*qdim], &lbf[spos+6*qdim], &lbf[spos+9*qdim], &lbf[spos+8*qdim],
                       &lbf[spos+10*qdim], &lbf[spos+11*qdim], &lbf[spos+3*qdim], &lbf[spos+13*qdim],
                       &lbf[spos+14*qdim], &lbf[spos+16*qdim], &lbf[spos+15*qdim], &lbf[spos+18*qdim],
                       &lbf[spos+17*qdim]);
      break;
    case CCTLB:
      fD3Q19TCCInamuro(p0, -uwall[0], uwall[1], -uwall[2], &lbf[spos], &lbf[spos+10*qdim],
                       &lbf[spos+2*qdim], &lbf[spos+12*qdim], &lbf[spos+14*qdim], &lbf[spos+13*qdim],
                       &lbf[spos+15*qdim], &lbf[spos+16*qdim], &lbf[spos+9*qdim], &lbf[spos+8*qdim],
                       &lbf[spos+1*qdim], &lbf[spos+11*qdim], &lbf[spos+3*qdim], &lbf[spos+5*qdim],
                       &lbf[spos+4*qdim], &lbf[spos+6*qdim], &lbf[spos+7*qdim], &lbf[spos+18*qdim],
                       &lbf[spos+17*qdim]);
      break;
    case CCDLB:
      fD3Q19TCCInamuro(p0, -uwall[0], -uwall[1], -uwall[2], &lbf[spos], &lbf[spos+10*qdim],
                       &lbf[spos+11*qdim], &lbf[spos+12*qdim], &lbf[spos+13*qdim], &lbf[spos+14*qdim],
                       &lbf[spos+15*qdim], &lbf[spos+16*qdim], &lbf[spos+17*qdim], &lbf[spos+18*qdim],
                       &lbf[spos+1*qdim], &lbf[spos+2*qdim], &lbf[spos+3*qdim], &lbf[spos+4*qdim],
                       &lbf[spos+5*qdim], &lbf[spos+6*qdim], &lbf[spos+7*qdim], &lbf[spos+8*qdim],
                       &lbf[spos+9*qdim]);
      break;
    case CCDRB:
      fD3Q19TCCInamuro(p0, uwall[0], -uwall[1], -uwall[2], &lbf[spos], &lbf[spos+1*qdim],
                       &lbf[spos+11*qdim], &lbf[spos+12*qdim], &lbf[spos+5*qdim], &lbf[spos+4*qdim],
                       &lbf[spos+7*qdim], &lbf[spos+6*qdim], &lbf[spos+17*qdim], &lbf[spos+18*qdim],
                       &lbf[spos+10*qdim], &lbf[spos+2*qdim], &lbf[spos+3*qdim], &lbf[spos+14*qdim],
                       &lbf[spos+13*qdim], &lbf[spos+16*qdim], &lbf[spos+15*qdim], &lbf[spos+8*qdim],
                       &lbf[spos+9*qdim]);
      break;
    case CCTRF:
      fD3Q19TCCInamuro(p0, uwall[0], uwall[1], uwall[2], &lbf[spos], &lbf[spos+1*qdim],
                       &lbf[spos+2*qdim], &lbf[spos+3*qdim], &lbf[spos+4*qdim], &lbf[spos+5*qdim],
                       &lbf[spos+6*qdim], &lbf[spos+7*qdim], &lbf[spos+8*qdim], &lbf[spos+9*qdim],
                       &lbf[spos+10*qdim], &lbf[spos+11*qdim], &lbf[spos+12*qdim], &lbf[spos+13*qdim],
                       &lbf[spos+14*qdim], &lbf[spos+15*qdim], &lbf[spos+16*qdim], &lbf[spos+17*qdim],
                       &lbf[spos+18*qdim]);
      break;
    case CCTLF:
      fD3Q19TCCInamuro(p0, -uwall[0], uwall[1], uwall[2], &lbf[spos], &lbf[spos+10*qdim],
                       &lbf[spos+2*qdim], &lbf[spos+3*qdim], &lbf[spos+14*qdim], &lbf[spos+13*qdim],
                       &lbf[spos+16*qdim], &lbf[spos+15*qdim], &lbf[spos+8*qdim], &lbf[spos+9*qdim],
                       &lbf[spos+1*qdim], &lbf[spos+11*qdim], &lbf[spos+12*qdim], &lbf[spos+5*qdim],
                       &lbf[spos+4*qdim], &lbf[spos+7*qdim], &lbf[spos+6*qdim], &lbf[spos+17*qdim],
                       &lbf[spos+18*qdim]);
      break;
    case CCDLF:
      fD3Q19TCCInamuro(p0, -uwall[0], -uwall[1], uwall[2], &lbf[spos], &lbf[spos+10*qdim],
                       &lbf[spos+11*qdim], &lbf[spos+3*qdim], &lbf[spos+13*qdim], &lbf[spos+14*qdim],
                       &lbf[spos+16*qdim], &lbf[spos+15*qdim], &lbf[spos+18*qdim], &lbf[spos+17*qdim],
                       &lbf[spos+1*qdim], &lbf[spos+2*qdim], &lbf[spos+12*qdim], &lbf[spos+4*qdim],
                       &lbf[spos+5*qdim], &lbf[spos+7*qdim], &lbf[spos+6*qdim], &lbf[spos+9*qdim],
                       &lbf[spos+8*qdim]);
      break;
    case CCDRF:
      fD3Q19TCCInamuro(p0, uwall[0], -uwall[1], uwall[2], &lbf[spos], &lbf[spos+1*qdim],
                       &lbf[spos+11*qdim], &lbf[spos+3*qdim], &lbf[spos+5*qdim], &lbf[spos+4*qdim],
                       &lbf[spos+6*qdim], &lbf[spos+7*qdim], &lbf[spos+18*qdim], &lbf[spos+17*qdim],
                       &lbf[spos+10*qdim], &lbf[spos+2*qdim], &lbf[spos+12*qdim], &lbf[spos+14*qdim],
                       &lbf[spos+13*qdim], &lbf[spos+15*qdim], &lbf[spos+16*qdim], &lbf[spos+9*qdim],
                       &lbf[spos+8*qdim]);
      break;
    case CETR:
      fD3Q19TCEInamuro(p0, uwall[0], uwall[1], uwall[2], &lbf[spos], &lbf[spos+1*qdim],
                       &lbf[spos+2*qdim], &lbf[spos+3*qdim], &lbf[spos+4*qdim], &lbf[spos+5*qdim],
                       &lbf[spos+6*qdim], &lbf[spos+7*qdim], &lbf[spos+8*qdim], &lbf[spos+9*qdim],
                       &lbf[spos+10*qdim], &lbf[spos+11*qdim], &lbf[spos+12*qdim], &lbf[spos+13*qdim],
                       &lbf[spos+14*qdim], &lbf[spos+15*qdim], &lbf[spos+16*qdim], &lbf[spos+17*qdim],
                       &lbf[spos+18*qdim]);
      break;
    case CETL:
      fD3Q19TCEInamuro(p0, uwall[1], -uwall[0], uwall[2], &lbf[spos], &lbf[spos+2*qdim],
                       &lbf[spos+10*qdim], &lbf[spos+3*qdim], &lbf[spos+14*qdim], &lbf[spos+4*qdim],
                       &lbf[spos+8*qdim], &lbf[spos+9*qdim], &lbf[spos+16*qdim], &lbf[spos+15*qdim],
                       &lbf[spos+11*qdim], &lbf[spos+1*qdim], &lbf[spos+12*qdim], &lbf[spos+5*qdim],
                       &lbf[spos+13*qdim], &lbf[spos+17*qdim], &lbf[spos+18*qdim], &lbf[spos+7*qdim],
                       &lbf[spos+6*qdim]);
      break;
    case CEDL:
      fD3Q19TCEInamuro(p0, -uwall[0], -uwall[1], uwall[2], &lbf[spos], &lbf[spos+10*qdim],
                       &lbf[spos+11*qdim], &lbf[spos+3*qdim], &lbf[spos+13*qdim], &lbf[spos+14*qdim],
                       &lbf[spos+16*qdim], &lbf[spos+15*qdim], &lbf[spos+18*qdim], &lbf[spos+17*qdim],
                       &lbf[spos+1*qdim], &lbf[spos+2*qdim], &lbf[spos+12*qdim], &lbf[spos+4*qdim],
                       &lbf[spos+5*qdim], &lbf[spos+7*qdim], &lbf[spos+6*qdim], &lbf[spos+9*qdim],
                       &lbf[spos+8*qdim]);
      break;
    case CEDR:
      fD3Q19TCEInamuro(p0, -uwall[1], uwall[0], uwall[2], &lbf[spos], &lbf[spos+11*qdim],
                       &lbf[spos+1*qdim], &lbf[spos+3*qdim], &lbf[spos+5*qdim], &lbf[spos+13*qdim],
                       &lbf[spos+18*qdim], &lbf[spos+17*qdim], &lbf[spos+6*qdim], &lbf[spos+7*qdim],
                       &lbf[spos+2*qdim], &lbf[spos+10*qdim], &lbf[spos+12*qdim], &lbf[spos+14*qdim],
                       &lbf[spos+4*qdim], &lbf[spos+9*qdim], &lbf[spos+8*qdim], &lbf[spos+15*qdim],
                       &lbf[spos+16*qdim]);
      break;
    case CETF:
      fD3Q19TCEInamuro(p0, uwall[1], uwall[2], uwall[0], &lbf[spos], &lbf[spos+2*qdim],
                       &lbf[spos+3*qdim], &lbf[spos+1*qdim], &lbf[spos+8*qdim], &lbf[spos+9*qdim],
                       &lbf[spos+4*qdim], &lbf[spos+14*qdim], &lbf[spos+6*qdim], &lbf[spos+16*qdim],
                       &lbf[spos+11*qdim], &lbf[spos+12*qdim], &lbf[spos+10*qdim], &lbf[spos+17*qdim],
                       &lbf[spos+18*qdim], &lbf[spos+13*qdim], &lbf[spos+5*qdim], &lbf[spos+15*qdim],
                       &lbf[spos+7*qdim]);
      break;
    case CELF:
      fD3Q19TCEInamuro(p0, -uwall[0], uwall[2], uwall[1], &lbf[spos], &lbf[spos+10*qdim],
                       &lbf[spos+3*qdim], &lbf[spos+2*qdim], &lbf[spos+16*qdim], &lbf[spos+15*qdim],
                       &lbf[spos+14*qdim], &lbf[spos+13*qdim], &lbf[spos+8*qdim], &lbf[spos+18*qdim],
                       &lbf[spos+1*qdim], &lbf[spos+12*qdim], &lbf[spos+11*qdim], &lbf[spos+7*qdim],
                       &lbf[spos+6*qdim], &lbf[spos+5*qdim], &lbf[spos+4*qdim], &lbf[spos+17*qdim],
                       &lbf[spos+9*qdim]);
      break;
    case CEDF:
      fD3Q19TCEInamuro(p0, -uwall[1], uwall[2], uwall[0], &lbf[spos], &lbf[spos+11*qdim],
                       &lbf[spos+3*qdim], &lbf[spos+1*qdim], &lbf[spos+18*qdim], &lbf[spos+17*qdim],
                       &lbf[spos+5*qdim], &lbf[spos+13*qdim], &lbf[spos+6*qdim], &lbf[spos+16*qdim],
                       &lbf[spos+2*qdim], &lbf[spos+12*qdim], &lbf[spos+10*qdim], &lbf[spos+9*qdim],
                       &lbf[spos+8*qdim], &lbf[spos+14*qdim], &lbf[spos+4*qdim], &lbf[spos+15*qdim],
                       &lbf[spos+7*qdim]);
      break;
    case CERF:
      fD3Q19TCEInamuro(p0, uwall[0], uwall[2], uwall[1], &lbf[spos], &lbf[spos+1*qdim],
                       &lbf[spos+3*qdim], &lbf[spos+2*qdim], &lbf[spos+6*qdim], &lbf[spos+7*qdim],
                       &lbf[spos+4*qdim], &lbf[spos+5*qdim], &lbf[spos+8*qdim], &lbf[spos+18*qdim],
                       &lbf[spos+10*qdim], &lbf[spos+12*qdim], &lbf[spos+11*qdim], &lbf[spos+15*qdim],
                       &lbf[spos+16*qdim], &lbf[spos+13*qdim], &lbf[spos+14*qdim], &lbf[spos+17*qdim],
                       &lbf[spos+9*qdim]);
      break;
    case CETB:
      fD3Q19TCEInamuro(p0, uwall[1], -uwall[2], uwall[0], &lbf[spos], &lbf[spos+2*qdim],
                       &lbf[spos+12*qdim], &lbf[spos+1*qdim], &lbf[spos+9*qdim], &lbf[spos+8*qdim],
                       &lbf[spos+4*qdim], &lbf[spos+14*qdim], &lbf[spos+7*qdim], &lbf[spos+15*qdim],
                       &lbf[spos+11*qdim], &lbf[spos+3*qdim], &lbf[spos+10*qdim], &lbf[spos+18*qdim],
                       &lbf[spos+17*qdim], &lbf[spos+13*qdim], &lbf[spos+5*qdim], &lbf[spos+16*qdim],
                       &lbf[spos+6*qdim]);
      break;
    case CELB:
      fD3Q19TCEInamuro(p0, -uwall[0], -uwall[2], uwall[1], &lbf[spos], &lbf[spos+10*qdim],
                       &lbf[spos+12*qdim], &lbf[spos+2*qdim], &lbf[spos+15*qdim], &lbf[spos+16*qdim],
                       &lbf[spos+14*qdim], &lbf[spos+13*qdim], &lbf[spos+9*qdim], &lbf[spos+17*qdim],
                       &lbf[spos+1*qdim], &lbf[spos+3*qdim], &lbf[spos+11*qdim], &lbf[spos+6*qdim],
                       &lbf[spos+7*qdim], &lbf[spos+5*qdim], &lbf[spos+4*qdim], &lbf[spos+18*qdim],
                       &lbf[spos+8*qdim]);
      break;
    case CEDB:
      fD3Q19TCEInamuro(p0, -uwall[1], -uwall[2], uwall[0], &lbf[spos], &lbf[spos+11*qdim],
                       &lbf[spos+12*qdim], &lbf[spos+1*qdim], &lbf[spos+17*qdim], &lbf[spos+18*qdim],
                       &lbf[spos+5*qdim], &lbf[spos+13*qdim], &lbf[spos+7*qdim], &lbf[spos+15*qdim],
                       &lbf[spos+2*qdim], &lbf[spos+3*qdim], &lbf[spos+10*qdim], &lbf[spos+8*qdim],
                       &lbf[spos+9*qdim], &lbf[spos+14*qdim], &lbf[spos+4*qdim], &lbf[spos+16*qdim],
                       &lbf[spos+6*qdim]);
      break;
    case CERB:
      fD3Q19TCEInamuro(p0, uwall[0], -uwall[2], uwall[1], &lbf[spos], &lbf[spos+1*qdim],
                       &lbf[spos+12*qdim], &lbf[spos+2*qdim], &lbf[spos+7*qdim], &lbf[spos+6*qdim],
                       &lbf[spos+4*qdim], &lbf[spos+5*qdim], &lbf[spos+9*qdim], &lbf[spos+17*qdim],
                       &lbf[spos+10*qdim], &lbf[spos+3*qdim], &lbf[spos+11*qdim], &lbf[spos+16*qdim],
                       &lbf[spos+15*qdim], &lbf[spos+13*qdim], &lbf[spos+14*qdim], &lbf[spos+18*qdim],
                       &lbf[spos+8*qdim]);
      break;
  }
  return 0;
}


// D3Q27

int fD3Q27VPSInamuro(double v0, double v1, double v2, double *force,
                     double *f0, double *f1, double *f2, double *f3, double *f4,
                     double *f5, double *f6, double *f7, double *f8, double *f9,
                     double *f10, double *f11, double *f12, double *f13, double *f14,
                     double *f15, double *f16, double *f17, double *f18, double *f19,
                     double *f20, double *f21, double *f22, double *f23, double *f24,
                     double *f25, double *f26)
{

  // produce fixed velocity for compressible/incompressible fluids at planar surface boundary:
  // expressed for bottom wall (VPST)
  
  double rho, rho0, rrho0, rhop, v0t, v2t;
  double c1=2.0/27.0,c2=1.0/54.0,c3=1.0/216.0;

  if(!incompress) {
    for(int i=0; i<lbsy.nf; i++) {
      rho=(f0[i]+f1[i]+f3[i]+f6[i]+f7[i]+f14[i]+f16[i]+f19[i]+f20[i]+2.0*(f2[i]+f4[i]+f8[i]+f9[i]+f10[i]+f11[i]+f18[i]+f25[i]+f26[i])-0.5*force[3*i+1])/(1.0-v1);
      rhop=6.0*(rho*v1+f2[i]+f4[i]+f8[i]+f9[i]+f10[i]+f11[i]+f18[i]+f25[i]+f26[i]-0.5*force[3*i+1])/(1.0+3.0*v1*(1.0+v1));
      v0t=6.0*(rho*v0+f1[i]+f4[i]+f6[i]+f7[i]+f10[i]+f11[i]-f14[i]-f18[i]-f19[i]-f20[i]-f25[i]-f26[i]-0.5*force[3*i  ])/(rhop*(1.0+3.0*v1)); // v0t = v0 + v0s
      v2t=6.0*(rho*v2+f3[i]+f6[i]-f7[i]+f8[i]-f9[i]+f10[i]-f11[i]-f16[i]-f19[i]+f20[i]-f25[i]+f26[i]-0.5*force[3*i+2])/(rhop*(1.0+3.0*v1)); // v2t = v2 + v2ss
      f5[i]=c2*rhop*(1.0+3.0*(v0t*(v0t-1.0)+v1*(v1+1.0))-9.0*v0t*v1-1.5*v2t*v2t);
      f12[i]=c3*rhop*(1.0+3.0*(v0t*(v0t-1.0)+v1*(v1+1.0)+v2t*(v2t-1.0))-9.0*(v0t*v1-v0t*v2t+v1*v2t));
      f13[i]=c3*rhop*(1.0+3.0*(v0t*(v0t-1.0)+v1*(v1+1.0)+v2t*(v2t+1.0))-9.0*(v0t*v1+v0t*v2t-v1*v2t));
      f15[i]=c1*rhop*(1.0+3.0*v1*(v1+1.0)-1.5*(v0t*v0t+v2t*v2t));
      f17[i]=c2*rhop*(1.0+3.0*(v0t*(v0t+1.0)+v1*(v1+1.0))+9.0*v0t*v1-1.5*v2t*v2t);
      f21[i]=c2*rhop*(1.0+3.0*(v1*(v1+1.0)+v2t*(v2t+1.0))+9.0*v1*v2t-1.5*v0t*v0t);
      f22[i]=c2*rhop*(1.0+3.0*(v1*(v1+1.0)+v2t*(v2t-1.0))-9.0*v1*v2t-1.5*v0t*v0t);
      f23[i]=c3*rhop*(1.0+3.0*(v0t*(v0t+1.0)+v1*(v1+1.0)+v2t*(v2t+1.0))+9.0*(v0t*v1+v0t*v2t+v1*v2t));
      f24[i]=c3*rhop*(1.0+3.0*(v0t*(v0t+1.0)+v1*(v1+1.0)+v2t*(v2t-1.0))+9.0*(v0t*v1-v0t*v2t-v1*v2t));
    }
  }
  else {
    for(int i=0; i<lbsy.nf; i++) {
      rho0=lbincp[i];
      rrho0 = fReciprocal(rho0);
      rhop = 6.0*(f2[i]+f4[i]+f8[i]+f9[i]+f10[i]+f11[i]+f18[i]+f25[i]+f26[i])+3.0*rho0*v1*(1.0-v1)-3.0*force[3*i+1];
      v0t = 6.0*(v0+(f1[i]+f4[i]+f6[i]+f7[i]+f10[i]+f11[i]-f14[i]-f18[i]-f19[i]-f20[i]-f25[i]-f26[i]-0.5*force[3*i  ])*rrho0)/(1.0+3.0*v1); // v0t = v0 + v0s
      v2t = 6.0*(v2+(f3[i]+f6[i]-f7[i]+f8[i]-f9[i]+f10[i]-f11[i]-f16[i]-f19[i]+f20[i]-f25[i]+f26[i]-0.5*force[3*i+2])*rrho0)/(1.0+3.0*v1); // v2t = v2 + v2s
      f5[i]=c2*(rhop+rho0*(3.0*(v0t*(v0t-1.0)+v1*(v1+1.0))-9.0*v0t*v1-1.5*v2t*v2t));
      f12[i]=c3*(rhop+rho0*(3.0*(v0t*(v0t-1.0)+v1*(v1+1.0)+v2t*(v2t-1.0))-9.0*(v0t*v1-v0t*v2t+v1*v2t)));
      f13[i]=c3*(rhop+rho0*(3.0*(v0t*(v0t-1.0)+v1*(v1+1.0)+v2t*(v2t+1.0))-9.0*(v0t*v1+v0t*v2t-v1*v2t)));
      f15[i]=c1*(rhop+rho0*(3.0*v1*(v1+1.0)-1.5*(v0t*v0t+v2t*v2t)));
      f17[i]=c2*(rhop+rho0*(3.0*(v0t*(v0t+1.0)+v1*(v1+1.0))+9.0*v0t*v1-1.5*v2t*v2t));
      f21[i]=c2*(rhop+rho0*(3.0*(v1*(v1+1.0)+v2t*(v2t+1.0))+9.0*v1*v2t-1.5*v0t*v0t));
      f22[i]=c2*(rhop+rho0*(3.0*(v1*(v1+1.0)+v2t*(v2t-1.0))-9.0*v1*v2t-1.5*v0t*v0t));
      f23[i]=c3*(rhop+rho0*(3.0*(v0t*(v0t+1.0)+v1*(v1+1.0)+v2t*(v2t+1.0))+9.0*(v0t*v1+v0t*v2t+v1*v2t)));
      f24[i]=c3*(rhop+rho0*(3.0*(v0t*(v0t+1.0)+v1*(v1+1.0)+v2t*(v2t-1.0))+9.0*(v0t*v1-v0t*v2t-v1*v2t)));
    }
  }
  return 0;
}

int fD3Q27VCEInamuro(double *p, double v0, double v1, double v2, double *force,
                     double *f0, double *f1, double *f2, double *f3, double *f4,
                     double *f5, double *f6, double *f7, double *f8, double *f9,
                     double *f10, double *f11, double *f12, double *f13, double *f14,
                     double *f15, double *f16, double *f17, double *f18, double *f19,
                     double *f20, double *f21, double *f22, double *f23, double *f24,
                     double *f25, double *f26)
{

  // produce fixed velocity for compressible/incompressible fluids at concave edge boundary:
  // expressed for bottom left edge (VCETR)
  double rho0, rrho0, rhop, v2t;
  double c1=2.0/27.0,c2=1.0/54.0,c3=1.0/216.0;

  if(!incompress) {
    for(int i=0; i<lbsy.nf; i++) {
      rhop=36.0*(p[i]*(1.0+0.5*(v0+v1))-f0[i]-f3[i]-f16[i]-0.5*(f1[i]+f2[i]+f6[i]+f7[i]+f8[i]+f9[i])-0.25*(force[3*i]+force[3*i+1]))/(16.0+24.0*(v0+v1)+21.0*(v0*v0+v1*v1));
      v2t=36.0*(p[i]*v2+f3[i]+f6[i]-f7[i]+f8[i]-f9[i]+f10[i]-f11[i]-f16[i]-0.5*force[3*i+2])*fReciprocal(rhop*(11.0+15.0*(v0+v1))); // v2t = v2 + v2ss
      f5[i]=c2*rhop*(1.0+3.0*(v0*(v0-1.0)+v1*(v1+1.0))-9.0*v0*v1-1.5*v2t*v2t);
      f12[i]=c3*rhop*(1.0+3.0*(v0*(v0-1.0)+v1*(v1+1.0)+v2t*(v2t-1.0))-9.0*(v0*v1-v0*v2t+v1*v2t));
      f13[i]=c3*rhop*(1.0+3.0*(v0*(v0-1.0)+v1*(v1+1.0)+v2t*(v2t+1.0))-9.0*(v0*v1+v0*v2t-v1*v2t));
      f14[i]=c1*rhop*(1.0+3.0*v0*(v0+1.0)-1.5*(v1*v1+v2t*v2t));
      f15[i]=c1*rhop*(1.0+3.0*v1*(v1+1.0)-1.5*(v0*v0+v2t*v2t));
      f17[i]=c2*rhop*(1.0+3.0*(v0*(v0+1.0)+v1*(v1+1.0))+9.0*v0*v1-1.5*v2t*v2t);
      f18[i]=c2*rhop*(1.0+3.0*(v0*(v0+1.0)+v1*(v1-1.0))-9.0*v0*v1-1.5*v2t*v2t);
      f19[i]=c2*rhop*(1.0+3.0*(v0*(v0+1.0)+v2t*(v2t+1.0))+9.0*v0*v2t-1.5*v1*v1);
      f20[i]=c2*rhop*(1.0+3.0*(v0*(v0+1.0)+v2t*(v2t-1.0))-9.0*v0*v2t-1.5*v1*v1);
      f21[i]=c2*rhop*(1.0+3.0*(v1*(v1+1.0)+v2t*(v2t+1.0))+9.0*v1*v2t-1.5*v0*v0);
      f22[i]=c2*rhop*(1.0+3.0*(v1*(v1+1.0)+v2t*(v2t-1.0))-9.0*v1*v2t-1.5*v0*v0);
      f23[i]=c3*rhop*(1.0+3.0*(v0*(v0+1.0)+v1*(v1+1.0)+v2t*(v2t+1.0))+9.0*(v0*v1+v0*v2t+v1*v2t));
      f24[i]=c3*rhop*(1.0+3.0*(v0*(v0+1.0)+v1*(v1+1.0)+v2t*(v2t-1.0))+9.0*(v0*v1-v0*v2t-v1*v2t));
      f25[i]=c3*rhop*(1.0+3.0*(v0*(v0+1.0)+v1*(v1-1.0)+v2t*(v2t+1.0))-9.0*(v0*v1-v0*v2t+v1*v2t));
      f26[i]=c3*rhop*(1.0+3.0*(v0*(v0+1.0)+v1*(v1-1.0)+v2t*(v2t-1.0))-9.0*(v0*v1+v0*v2t-v1*v2t));
    }
  }
  else {
    for(int i=0; i<lbsy.nf; i++) {
      rho0=lbincp[i];
      rrho0 = fReciprocal(rho0);
      rhop = 2.25*(p[i]-f0[i]-f3[i]-f16[i])-1.125*(f1[i]+f2[i]+f6[i]+f7[i]+f8[i]+f9[i])-0.375*rho0*(v0+v1)-1.3125*rho0*(v0*v0+v1*v1)-0.5625*(force[3*i]+force[3*i+1]);
      v2t = 36.0*(v2+(f3[i]+f6[i]-f7[i]+f8[i]-f9[i]+f10[i]-f11[i]-f16[i]-0.5*force[3*i+2])*rrho0)/(11.0+15.0*(v0+v1)); // v2t = v2 + v2s
      f5[i]=c2*(rhop+rho0*(3.0*(v0*(v0-1.0)+v1*(v1+1.0))-9.0*v0*v1-1.5*v2t*v2t));
      f12[i]=c3*(rhop+rho0*(3.0*(v0*(v0-1.0)+v1*(v1+1.0)+v2t*(v2t-1.0))-9.0*(v0*v1-v0*v2t+v1*v2t)));
      f13[i]=c3*(rhop+rho0*(3.0*(v0*(v0-1.0)+v1*(v1+1.0)+v2t*(v2t+1.0))-9.0*(v0*v1+v0*v2t-v1*v2t)));
      f14[i]=c1*(rhop+rho0*(3.0*v0*(v0+1.0)-1.5*(v1*v1+v2t*v2t)));
      f15[i]=c1*(rhop+rho0*(3.0*v1*(v1+1.0)-1.5*(v0*v0+v2t*v2t)));
      f17[i]=c2*(rhop+rho0*(3.0*(v0*(v0+1.0)+v1*(v1+1.0))+9.0*v0*v1-1.5*v2t*v2t));
      f18[i]=c2*(rhop+rho0*(3.0*(v0*(v0+1.0)+v1*(v1-1.0))-9.0*v0*v1-1.5*v2t*v2t));
      f19[i]=c2*(rhop+rho0*(3.0*(v0*(v0+1.0)+v2t*(v2t+1.0))+9.0*v0*v2t-1.5*v1*v1));
      f20[i]=c2*(rhop+rho0*(3.0*(v0*(v0+1.0)+v2t*(v2t-1.0))-9.0*v0*v2t-1.5*v1*v1));
      f21[i]=c2*(rhop+rho0*(3.0*(v1*(v1+1.0)+v2t*(v2t+1.0))+9.0*v1*v2t-1.5*v0*v0));
      f22[i]=c2*(rhop+rho0*(3.0*(v1*(v1+1.0)+v2t*(v2t-1.0))-9.0*v1*v2t-1.5*v0*v0));
      f23[i]=c3*(rhop+rho0*(3.0*(v0*(v0+1.0)+v1*(v1+1.0)+v2t*(v2t+1.0))+9.0*(v0*v1+v0*v2t+v1*v2t)));
      f24[i]=c3*(rhop+rho0*(3.0*(v0*(v0+1.0)+v1*(v1+1.0)+v2t*(v2t-1.0))+9.0*(v0*v1-v0*v2t-v1*v2t)));
      f25[i]=c3*(rhop+rho0*(3.0*(v0*(v0+1.0)+v1*(v1-1.0)+v2t*(v2t+1.0))-9.0*(v0*v1-v0*v2t+v1*v2t)));
      f26[i]=c3*(rhop+rho0*(3.0*(v0*(v0+1.0)+v1*(v1-1.0)+v2t*(v2t-1.0))-9.0*(v0*v1+v0*v2t-v1*v2t)));
    }
  }
  return 0;
}

int fD3Q27VCCInamuro(double *p, double v0, double v1, double v2, double *force,
                     double *f0, double *f1, double *f2, double *f3, double *f4,
                     double *f5, double *f6, double *f7, double *f8, double *f9,
                     double *f10, double *f11, double *f12, double *f13, double *f14,
                     double *f15, double *f16, double *f17, double *f18, double *f19,
                     double *f20, double *f21, double *f22, double *f23, double *f24,
                     double *f25, double *f26)
{

  // produce fixed velocity for compressible/incompressible fluids at concave corner boundary:
  // expressed for bottom left back corner (VCCTRF)
  double rho0, rhop;
  double c1=2.0/27.0,c2=1.0/54.0,c3=1.0/216.0,c4=1.0/688.0;

  if(!incompress) {
    for(int i=0; i<lbsy.nf; i++) {
      rhop=108.0*(11.0*(p[i]-f0[i])-6.0*(f1[i]+f2[i]+f3[i])-f4[i]-f6[i]-f8[i]+4.0*f10[i]+5.0*p[i]*(v0+v1+v2)-2.5*(force[3*i]+force[3*i+1]+force[3*i+2]))/(688.0+690.0*(v0+v1+v2)+525.0*(v0*v0+v1*v1+v2*v2));
      f5[i]=c2*rhop*(1.0+3.0*(v0*(v0-1.0)+v1*(v1+1.0))-9.0*v0*v1-1.5*v2*v2);
      f7[i]=c2*rhop*(1.0+3.0*(v0*(v0-1.0)+v2*(v2+1.0))-9.0*v0*v2-1.5*v1*v1);
      f9[i]=c2*rhop*(1.0+3.0*(v1*(v1-1.0)+v2*(v2+1.0))-9.0*v1*v2-1.5*v0*v0);
      f11[i]=c3*rhop*(1.0+3.0*(v0*(v0-1.0)+v1*(v1-1.0)+v2*(v2+1.0))-9.0*(v0*v1-v0*v2+v1*v2));
      f12[i]=c3*rhop*(1.0+3.0*(v0*(v0-1.0)+v1*(v1+1.0)+v2*(v2-1.0))-9.0*(v0*v1-v0*v2+v1*v2));
      f13[i]=c3*rhop*(1.0+3.0*(v0*(v0-1.0)+v1*(v1+1.0)+v2*(v2+1.0))-9.0*(v0*v1+v0*v2-v1*v2));
      f14[i]=c1*rhop*(1.0+3.0*v0*(v0+1.0)-1.5*(v1*v1+v2*v2));
      f15[i]=c1*rhop*(1.0+3.0*v1*(v1+1.0)-1.5*(v0*v0+v2*v2));
      f16[i]=c1*rhop*(1.0+3.0*v2*(v2+1.0)-1.5*(v0*v0+v1*v1));
      f17[i]=c2*rhop*(1.0+3.0*(v0*(v0+1.0)+v1*(v1+1.0))+9.0*v0*v1-1.5*v2*v2);
      f18[i]=c2*rhop*(1.0+3.0*(v0*(v0+1.0)+v1*(v1-1.0))-9.0*v0*v1-1.5*v2*v2);
      f19[i]=c2*rhop*(1.0+3.0*(v0*(v0+1.0)+v2*(v2+1.0))+9.0*v0*v2-1.5*v1*v1);
      f20[i]=c2*rhop*(1.0+3.0*(v0*(v0+1.0)+v2*(v2-1.0))-9.0*v0*v2-1.5*v1*v1);
      f21[i]=c2*rhop*(1.0+3.0*(v1*(v1+1.0)+v2*(v2+1.0))+9.0*v1*v2-1.5*v0*v0);
      f22[i]=c2*rhop*(1.0+3.0*(v1*(v1+1.0)+v2*(v2-1.0))-9.0*v1*v2-1.5*v0*v0);
      f23[i]=c3*rhop*(1.0+3.0*(v0*(v0+1.0)+v1*(v1+1.0)+v2*(v2+1.0))+9.0*(v0*v1+v0*v2+v1*v2));
      f24[i]=c3*rhop*(1.0+3.0*(v0*(v0+1.0)+v1*(v1+1.0)+v2*(v2-1.0))+9.0*(v0*v1-v0*v2-v1*v2));
      f25[i]=c3*rhop*(1.0+3.0*(v0*(v0+1.0)+v1*(v1-1.0)+v2*(v2+1.0))-9.0*(v0*v1-v0*v2+v1*v2));
      f26[i]=c3*rhop*(1.0+3.0*(v0*(v0+1.0)+v1*(v1-1.0)+v2*(v2-1.0))-9.0*(v0*v1+v0*v2-v1*v2));
    }
  }
  else {
    for(int i=0; i<lbsy.nf; i++) {
      rho0=lbincp[i];
      rhop = c4*(1188.0*(p[i]-f0[i])-648.0*(f1[i]+f2[i]+f3[i])-108.0*(f4[i]+f6[i]+f8[i])+432.0*f10[i]-150.0*rho0*(v0+v1+v2)-525.0*rho0*(v0*v0+v1*v1+v2*v2)-270.0*(force[3*i]+force[3*i+1]+force[3*i+2]));
      f5[i]=c2*(rhop+rho0*(3.0*(v0*(v0-1.0)+v1*(v1+1.0))-9.0*v0*v1-1.5*v2*v2));
      f7[i]=c2*(rhop+rho0*(3.0*(v0*(v0-1.0)+v2*(v2+1.0))-9.0*v0*v2-1.5*v1*v1));
      f9[i]=c2*(rhop+rho0*(3.0*(v1*(v1-1.0)+v2*(v2+1.0))-9.0*v1*v2-1.5*v0*v0));
      f11[i]=c3*(rhop+rho0*(3.0*(v0*(v0-1.0)+v1*(v1-1.0)+v2*(v2+1.0))-9.0*(v0*v1-v0*v2+v1*v2)));
      f12[i]=c3*(rhop+rho0*(3.0*(v0*(v0-1.0)+v1*(v1+1.0)+v2*(v2-1.0))-9.0*(v0*v1-v0*v2+v1*v2)));
      f13[i]=c3*(rhop+rho0*(3.0*(v0*(v0-1.0)+v1*(v1+1.0)+v2*(v2+1.0))-9.0*(v0*v1+v0*v2-v1*v2)));
      f14[i]=c1*(rhop+rho0*(3.0*v0*(v0+1.0)-1.5*(v1*v1+v2*v2)));
      f15[i]=c1*(rhop+rho0*(3.0*v1*(v1+1.0)-1.5*(v0*v0+v2*v2)));
      f16[i]=c1*(rhop+rho0*(3.0*v2*(v2+1.0)-1.5*(v0*v0+v1*v1)));
      f17[i]=c2*(rhop+rho0*(3.0*(v0*(v0+1.0)+v1*(v1+1.0))+9.0*v0*v1-1.5*v2*v2));
      f18[i]=c2*(rhop+rho0*(3.0*(v0*(v0+1.0)+v1*(v1-1.0))-9.0*v0*v1-1.5*v2*v2));
      f19[i]=c2*(rhop+rho0*(3.0*(v0*(v0+1.0)+v2*(v2+1.0))+9.0*v0*v2-1.5*v1*v1));
      f20[i]=c2*(rhop+rho0*(3.0*(v0*(v0+1.0)+v2*(v2-1.0))-9.0*v0*v2-1.5*v1*v1));
      f21[i]=c2*(rhop+rho0*(3.0*(v1*(v1+1.0)+v2*(v2+1.0))+9.0*v1*v2-1.5*v0*v0));
      f22[i]=c2*(rhop+rho0*(3.0*(v1*(v1+1.0)+v2*(v2-1.0))-9.0*v1*v2-1.5*v0*v0));
      f23[i]=c3*(rhop+rho0*(3.0*(v0*(v0+1.0)+v1*(v1+1.0)+v2*(v2+1.0))+9.0*(v0*v1+v0*v2+v1*v2)));
      f24[i]=c3*(rhop+rho0*(3.0*(v0*(v0+1.0)+v1*(v1+1.0)+v2*(v2-1.0))+9.0*(v0*v1-v0*v2-v1*v2)));
      f25[i]=c3*(rhop+rho0*(3.0*(v0*(v0+1.0)+v1*(v1-1.0)+v2*(v2+1.0))-9.0*(v0*v1-v0*v2+v1*v2)));
      f26[i]=c3*(rhop+rho0*(3.0*(v0*(v0+1.0)+v1*(v1-1.0)+v2*(v2-1.0))-9.0*(v0*v1+v0*v2-v1*v2)));
    }
  }
  return 0;
}

int fD3Q27VPSCLBEInamuro(double v0, double v1, double v2, double *force,
                         double *f0, double *f1, double *f2, double *f3, double *f4,
                         double *f5, double *f6, double *f7, double *f8, double *f9,
                         double *f10, double *f11, double *f12, double *f13, double *f14,
                         double *f15, double *f16, double *f17, double *f18, double *f19,
                         double *f20, double *f21, double *f22, double *f23, double *f24,
                         double *f25, double *f26)
{

  // produce fixed velocity for compressible fluids at planar surface boundary:
  // expressed for bottom wall (VPST) using higher-order equilibrium distribution functions for CLBE collisions
  
  double rho, rhop, v0t, v2t;
  double c1=2.0/27.0,c2=1.0/54.0,c3=1.0/216.0;

  for(int i=0; i<lbsy.nf; i++) {
    rho=(f0[i]+f1[i]+f3[i]+f6[i]+f7[i]+f14[i]+f16[i]+f19[i]+f20[i]+2.0*(f2[i]+f4[i]+f8[i]+f9[i]+f10[i]+f11[i]+f18[i]+f25[i]+f26[i])-0.5*force[3*i+1])/(1.0-v1);
    rhop=6.0*(rho*v1+f2[i]+f4[i]+f8[i]+f9[i]+f10[i]+f11[i]+f18[i]+f25[i]+f26[i]-0.5*force[3*i+1])/(1.0+3.0*v1*(1.0+v1));
    v0t=6.0*(rho*v0+f1[i]+f4[i]+f6[i]+f7[i]+f10[i]+f11[i]-f14[i]-f18[i]-f19[i]-f20[i]-f25[i]-f26[i]-0.5*force[3*i  ])/(rhop*(1.0+3.0*v1*(1.0+v1))); // v0t = v0 + v0s
    v2t=6.0*(rho*v2+f3[i]+f6[i]-f7[i]+f8[i]-f9[i]+f10[i]-f11[i]-f16[i]-f19[i]+f20[i]-f25[i]+f26[i]-0.5*force[3*i+2])/(rhop*(1.0+3.0*v1*(1.0+v1))); // v2t = v2 + v2s
    f5[i]=c2*rhop*(1.0+3.0*(v0t*(v0t-1.0)+v1*(v1+1.0))-9.0*v0t*v1*(1.0-v0t)*(1.0+v1))*(1.0-1.5*v2t*v2t);
    f12[i]=c3*rhop*(1.0*3.0*(v0t*(v0t-1.0)+v1*(v1+1.0)+v2t*(v2t-1.0))-9.0*(v0t*v1*(1.0-v0t)*(1.0+v1)-v0t*v2t*(1.0-v0t)*(1.0-v2t)+v1*v2t*(1.0+v1)*(1.0-v2t)+3.0*v0t*v1*v2t*(1.0-v0t)*(1.0+v1)*(1.0-v2t)));
    f13[i]=c3*rhop*(1.0*3.0*(v0t*(v0t-1.0)+v1*(v1+1.0)+v2t*(v2t+1.0))-9.0*(v0t*v1*(1.0-v0t)*(1.0+v1)+v0t*v2t*(1.0-v0t)*(1.0+v2t)-v1*v2t*(1.0+v1)*(1.0+v2t)-3.0*v0t*v1*v2t*(1.0-v0t)*(1.0+v1)*(1.0+v2t)));
    f15[i]=c1*rhop*(1.0+3.0*v1*(v1+1.0))*(1.0-1.5*v0t*v0t)*(1.0-1.5*v2t*v2t);
    f17[i]=c2*rhop*(1.0+3.0*(v0t*(v0t+1.0)+v1*(v1+1.0))+9.0*v0t*v1*(1.0+v0t)*(1.0+v1))*(1.0-1.5*v2t*v2t);
    f21[i]=c2*rhop*(1.0+3.0*(v1*(v1+1.0)+v2t*(v2t+1.0))+9.0*v1*v2t*(1.0+v1)*(1.0+v2t))*(1.0-1.5*v0t*v0t);
    f22[i]=c2*rhop*(1.0+3.0*(v1*(v1+1.0)+v2t*(v2t-1.0))-9.0*v1*v2t*(1.0+v1)*(1.0-v2t))*(1.0-1.5*v0t*v0t);
    f23[i]=c3*rhop*(1.0*3.0*(v0t*(v0t+1.0)+v1*(v1+1.0)+v2t*(v2t+1.0))+9.0*(v0t*v1*(1.0+v0t)*(1.0+v1)+v0t*v2t*(1.0+v0t)*(1.0+v2t)+v1*v2t*(1.0+v1)*(1.0+v2t)+3.0*v0t*v1*v2t*(1.0+v0t)*(1.0+v1)*(1.0+v2t)));
    f24[i]=c3*rhop*(1.0*3.0*(v0t*(v0t+1.0)+v1*(v1+1.0)+v2t*(v2t-1.0))+9.0*(v0t*v1*(1.0+v0t)*(1.0+v1)-v0t*v2t*(1.0+v0t)*(1.0-v2t)-v1*v2t*(1.0+v1)*(1.0-v2t)-3.0*v0t*v1*v2t*(1.0+v0t)*(1.0+v1)*(1.0-v2t)));
  }
  return 0;
}

int fD3Q27VCECLBEInamuro(double *p, double v0, double v1, double v2, double *force,
                         double *f0, double *f1, double *f2, double *f3, double *f4,
                         double *f5, double *f6, double *f7, double *f8, double *f9,
                         double *f10, double *f11, double *f12, double *f13, double *f14,
                         double *f15, double *f16, double *f17, double *f18, double *f19,
                         double *f20, double *f21, double *f22, double *f23, double *f24,
                         double *f25, double *f26)
{

  // produce fixed velocity for compressible fluids at concave edge boundary:
  // expressed for bottom left edge (VCETR) using higher-order equilibrium distribution functions for CLBE collisions
  double rhop, v2t;
  double c1=2.0/27.0,c2=1.0/54.0,c3=1.0/216.0;

  for(int i=0; i<lbsy.nf; i++) {
    rhop=36.0*(p[i]*(1.0+0.5*(v0+v1))-f0[i]-f3[i]-f16[i]-0.5*(f1[i]+f2[i]+f6[i]+f7[i]+f8[i]+f9[i])-0.25*(force[3*i]+force[3*i+1]))/(16.0+24.0*(v0+v1)+21.0*(v0*v0+v1*v1)-9.0*v0*v1*(v0+v1+v0*v1));
    v2t=36.0*(p[i]*v2+f3[i]+f6[i]-f7[i]+f8[i]-f9[i]+f10[i]-f11[i]-f16[i]-0.5*force[3*i+2])*fReciprocal(rhop*(11.0+15.0*(v0+v1+v0*v0+v1*v1)-9.0*v0*v1*(1.0+v0+v1+v0*v1))); // v2t = v2 + v2s
    f5[i]=c2*rhop*(1.0+3.0*(v0*(v0-1.0)+v1*(v1+1.0))-9.0*v0*v1*(1.0-v0)*(1.0+v1))*(1.0-1.5*v2t*v2t);
    f12[i]=c3*rhop*(1.0*3.0*(v0*(v0-1.0)+v1*(v1+1.0)+v2t*(v2t-1.0))-9.0*(v0*v1*(1.0-v0)*(1.0+v1)-v0*v2t*(1.0-v0)*(1.0-v2t)+v1*v2t*(1.0+v1)*(1.0-v2t)+3.0*v0*v1*v2t*(1.0-v0)*(1.0+v1)*(1.0-v2t)));
    f13[i]=c3*rhop*(1.0*3.0*(v0*(v0-1.0)+v1*(v1+1.0)+v2t*(v2t+1.0))-9.0*(v0*v1*(1.0-v0)*(1.0+v1)+v0*v2t*(1.0-v0)*(1.0+v2t)-v1*v2t*(1.0+v1)*(1.0+v2t)-3.0*v0*v1*v2t*(1.0-v0)*(1.0+v1)*(1.0+v2t)));
    f14[i]=c1*rhop*(1.0+3.0*v0*(v0+1.0))*(1.0-1.5*v1*v1)*(1.0-1.5*v2t*v2t);
    f15[i]=c1*rhop*(1.0+3.0*v1*(v1+1.0))*(1.0-1.5*v0*v0)*(1.0-1.5*v2t*v2t);
    f17[i]=c2*rhop*(1.0+3.0*(v0*(v0+1.0)+v1*(v1+1.0))+9.0*v0*v1*(1.0+v0)*(1.0+v1))*(1.0-1.5*v2t*v2t);
    f18[i]=c2*rhop*(1.0+3.0*(v0*(v0+1.0)+v1*(v1-1.0))-9.0*v0*v1*(1.0+v0)*(1.0-v1))*(1.0-1.5*v2t*v2t);
    f19[i]=c2*rhop*(1.0+3.0*(v0*(v0+1.0)+v2t*(v2t+1.0))+9.0*v0*v2t*(1.0+v0)*(1.0+v2t))*(1.0-1.5*v1*v1);
    f20[i]=c2*rhop*(1.0+3.0*(v0*(v0+1.0)+v2t*(v2t-1.0))-9.0*v0*v2t*(1.0+v0)*(1.0-v2t))*(1.0-1.5*v1*v1);
    f21[i]=c2*rhop*(1.0+3.0*(v1*(v1+1.0)+v2t*(v2t+1.0))+9.0*v1*v2t*(1.0+v1)*(1.0+v2t))*(1.0-1.5*v0*v0);
    f22[i]=c2*rhop*(1.0+3.0*(v1*(v1+1.0)+v2t*(v2t-1.0))-9.0*v1*v2t*(1.0+v1)*(1.0-v2t))*(1.0-1.5*v0*v0);
    f23[i]=c3*rhop*(1.0*3.0*(v0*(v0+1.0)+v1*(v1+1.0)+v2t*(v2t+1.0))+9.0*(v0*v1*(1.0+v0)*(1.0+v1)+v0*v2t*(1.0+v0)*(1.0+v2t)+v1*v2t*(1.0+v1)*(1.0+v2t)+3.0*v0*v1*v2t*(1.0+v0)*(1.0+v1)*(1.0+v2t)));
    f24[i]=c3*rhop*(1.0*3.0*(v0*(v0+1.0)+v1*(v1+1.0)+v2t*(v2t-1.0))+9.0*(v0*v1*(1.0+v0)*(1.0+v1)-v0*v2t*(1.0+v0)*(1.0-v2t)-v1*v2t*(1.0+v1)*(1.0-v2t)-3.0*v0*v1*v2t*(1.0+v0)*(1.0+v1)*(1.0-v2t)));
    f25[i]=c3*rhop*(1.0*3.0*(v0*(v0+1.0)+v1*(v1-1.0)+v2t*(v2t+1.0))-9.0*(v0*v1*(1.0+v0)*(1.0-v1)-v0*v2t*(1.0+v0)*(1.0+v2t)+v1*v2t*(1.0-v1)*(1.0+v2t)-3.0*v0*v1*v2t*(1.0+v0)*(1.0-v1)*(1.0+v2t)));
    f26[i]=c3*rhop*(1.0*3.0*(v0*(v0+1.0)+v1*(v1-1.0)+v2t*(v2t-1.0))-9.0*(v0*v1*(1.0+v0)*(1.0-v1)+v0*v2t*(1.0+v0)*(1.0-v2t)-v1*v2t*(1.0-v1)*(1.0-v2t)+3.0*v0*v1*v2t*(1.0+v0)*(1.0-v1)*(1.0-v2t)));
  }
  return 0;
}

int fD3Q27VCCCLBEInamuro(double *p, double v0, double v1, double v2, double *force,
                         double *f0, double *f1, double *f2, double *f3, double *f4,
                         double *f5, double *f6, double *f7, double *f8, double *f9,
                         double *f10, double *f11, double *f12, double *f13, double *f14,
                         double *f15, double *f16, double *f17, double *f18, double *f19,
                         double *f20, double *f21, double *f22, double *f23, double *f24,
                         double *f25, double *f26)
{

  // produce fixed velocity for compressible fluids at concave corner boundary:
  // expressed for bottom left back corner (VCCTRF) using higher-order equilibrium distribution functions for CLBE collisions
  double rhop;
  double c1=2.0/27.0,c2=1.0/54.0,c3=1.0/216.0;

  double v0v0 = v0*v0;
  double v1v1 = v1*v1;
  double v2v2 = v2*v2;
  for(int i=0; i<lbsy.nf; i++) {
    rhop=108.0*(11.0*(p[i]-f0[i])-6.0*(f1[i]+f2[i]+f3[i])-f4[i]-f6[i]-f8[i]+4.0*f10[i]+5.0*p[i]*(v0+v1+v2)-2.5*(force[3*i]+force[3*i+1]+force[3*i+2]))/(688.0+690.0*(v0+v1+v2)+525.0*(v0v0+v1v1+v2v2)-225.0*(v0*(v1v1+v2v2)+v1*(v0v0+v2v2)+v2*(v0v0+v1v1))-54.0*v0*v1*v2-450.0*(v0v0*v1v1+v0v0*v2v2+v1v1*v2v2)+81.0*v0*v1*v2*(v0+v1+v2)+216.0*v0*v1*v2*(v0v0*v1v1+v0v0*v2v2+v1v1*v2v2)+351.0*v0v0*v1v1*v2v2);
    f5[i]=c2*rhop*(1.0+3.0*(v0*(v0-1.0)+v1*(v1+1.0))-9.0*v0*v1*(1.0-v0)*(1.0+v1))*(1.0-1.5*v2*v2);
    f7[i]=c2*rhop*(1.0+3.0*(v0*(v0-1.0)+v2*(v2+1.0))-9.0*v0*v2*(1.0-v0)*(1.0+v2))*(1.0-1.5*v1*v1);
    f9[i]=c2*rhop*(1.0+3.0*(v1*(v1-1.0)+v2*(v2+1.0))-9.0*v1*v2*(1.0-v1)*(1.0+v2))*(1.0-1.5*v0*v0);
    f11[i]=c3*rhop*(1.0*3.0*(v0*(v0-1.0)+v1*(v1-1.0)+v2*(v2+1.0))+9.0*(v0*v1*(1.0-v0)*(1.0-v1)-v0*v2*(1.0-v0)*(1.0+v2)-v1*v2*(1.0-v1)*(1.0+v2)+3.0*v0*v1*v2*(1.0-v0)*(1.0-v1)*(1.0+v2)));
    f12[i]=c3*rhop*(1.0*3.0*(v0*(v0-1.0)+v1*(v1+1.0)+v2*(v2-1.0))-9.0*(v0*v1*(1.0-v0)*(1.0+v1)-v0*v2*(1.0-v0)*(1.0-v2)+v1*v2*(1.0+v1)*(1.0-v2)+3.0*v0*v1*v2*(1.0-v0)*(1.0+v1)*(1.0-v2)));
    f13[i]=c3*rhop*(1.0*3.0*(v0*(v0-1.0)+v1*(v1+1.0)+v2*(v2+1.0))-9.0*(v0*v1*(1.0-v0)*(1.0+v1)+v0*v2*(1.0-v0)*(1.0+v2)-v1*v2*(1.0+v1)*(1.0+v2)-3.0*v0*v1*v2*(1.0-v0)*(1.0+v1)*(1.0+v2)));
    f14[i]=c1*rhop*(1.0+3.0*v0*(v0+1.0))*(1.0-1.5*v1*v1)*(1.0-1.5*v2*v2);
    f15[i]=c1*rhop*(1.0+3.0*v1*(v1+1.0))*(1.0-1.5*v0*v0)*(1.0-1.5*v2*v2);
    f16[i]=c1*rhop*(1.0+3.0*v2*(v2+1.0))*(1.0-1.5*v0*v0)*(1.0-1.5*v1*v1);
    f17[i]=c2*rhop*(1.0+3.0*(v0*(v0+1.0)+v1*(v1+1.0))+9.0*v0*v1*(1.0+v0)*(1.0+v1))*(1.0-1.5*v2*v2);
    f18[i]=c2*rhop*(1.0+3.0*(v0*(v0+1.0)+v1*(v1-1.0))-9.0*v0*v1*(1.0+v0)*(1.0-v1))*(1.0-1.5*v2*v2);
    f19[i]=c2*rhop*(1.0+3.0*(v0*(v0+1.0)+v2*(v2+1.0))+9.0*v0*v2*(1.0+v0)*(1.0+v2))*(1.0-1.5*v1*v1);
    f20[i]=c2*rhop*(1.0+3.0*(v0*(v0+1.0)+v2*(v2-1.0))-9.0*v0*v2*(1.0+v0)*(1.0-v2))*(1.0-1.5*v1*v1);
    f21[i]=c2*rhop*(1.0+3.0*(v1*(v1+1.0)+v2*(v2+1.0))+9.0*v1*v2*(1.0+v1)*(1.0+v2))*(1.0-1.5*v0*v0);
    f22[i]=c2*rhop*(1.0+3.0*(v1*(v1+1.0)+v2*(v2-1.0))-9.0*v1*v2*(1.0+v1)*(1.0-v2))*(1.0-1.5*v0*v0);
    f23[i]=c3*rhop*(1.0*3.0*(v0*(v0+1.0)+v1*(v1+1.0)+v2*(v2+1.0))+9.0*(v0*v1*(1.0+v0)*(1.0+v1)+v0*v2*(1.0+v0)*(1.0+v2)+v1*v2*(1.0+v1)*(1.0+v2)+3.0*v0*v1*v2*(1.0+v0)*(1.0+v1)*(1.0+v2)));
    f24[i]=c3*rhop*(1.0*3.0*(v0*(v0+1.0)+v1*(v1+1.0)+v2*(v2-1.0))+9.0*(v0*v1*(1.0+v0)*(1.0+v1)-v0*v2*(1.0+v0)*(1.0-v2)-v1*v2*(1.0+v1)*(1.0-v2)-3.0*v0*v1*v2*(1.0+v0)*(1.0+v1)*(1.0-v2)));
    f25[i]=c3*rhop*(1.0*3.0*(v0*(v0+1.0)+v1*(v1-1.0)+v2*(v2+1.0))-9.0*(v0*v1*(1.0+v0)*(1.0-v1)-v0*v2*(1.0+v0)*(1.0+v2)+v1*v2*(1.0-v1)*(1.0+v2)-3.0*v0*v1*v2*(1.0+v0)*(1.0-v1)*(1.0+v2)));
    f26[i]=c3*rhop*(1.0*3.0*(v0*(v0+1.0)+v1*(v1-1.0)+v2*(v2-1.0))-9.0*(v0*v1*(1.0+v0)*(1.0-v1)+v0*v2*(1.0+v0)*(1.0-v2)-v1*v2*(1.0-v1)*(1.0-v2)+3.0*v0*v1*v2*(1.0+v0)*(1.0-v1)*(1.0-v2)));
  }
  return 0;
}

int fD3Q27VFInamuro(long tpos, long rpos, int prop, double *uwall)
{
  long spos=tpos * lbsitelength;
  int qdim=lbsy.nf+lbsy.nc+lbsy.nt;
  double force[3*lbsy.nf], rho[lbsy.nf];

  fD3Q27BoundaryForceVelocity(force, tpos, rpos, uwall, prop);
    
  if(prop>26)
    fGetAllMassSite(rho, &lbf[rpos*lbsitelength]);
    
  if (collide>11) {
    switch (prop) {
      case PST:
        fD3Q27VPSCLBEInamuro(uwall[0], uwall[1], uwall[2], &force[0], &lbf[spos], &lbf[spos+1*qdim],
                             &lbf[spos+2*qdim], &lbf[spos+3*qdim], &lbf[spos+4*qdim], &lbf[spos+5*qdim],
                             &lbf[spos+6*qdim], &lbf[spos+7*qdim], &lbf[spos+8*qdim], &lbf[spos+9*qdim],
                             &lbf[spos+10*qdim], &lbf[spos+11*qdim], &lbf[spos+12*qdim], &lbf[spos+13*qdim],
                             &lbf[spos+14*qdim], &lbf[spos+15*qdim], &lbf[spos+16*qdim], &lbf[spos+17*qdim],
                             &lbf[spos+18*qdim], &lbf[spos+19*qdim], &lbf[spos+20*qdim], &lbf[spos+21*qdim],
                             &lbf[spos+22*qdim], &lbf[spos+23*qdim], &lbf[spos+24*qdim], &lbf[spos+25*qdim],
                             &lbf[spos+26*qdim]);
        break;
      case PSD:
        fD3Q27VPSCLBEInamuro(-uwall[0], -uwall[1], -uwall[2], &force[0], &lbf[spos], &lbf[spos+14*qdim],
                             &lbf[spos+15*qdim], &lbf[spos+16*qdim], &lbf[spos+17*qdim], &lbf[spos+18*qdim],
                             &lbf[spos+19*qdim], &lbf[spos+20*qdim], &lbf[spos+21*qdim], &lbf[spos+22*qdim],
                             &lbf[spos+23*qdim], &lbf[spos+24*qdim], &lbf[spos+25*qdim], &lbf[spos+26*qdim],
                             &lbf[spos+1*qdim], &lbf[spos+2*qdim], &lbf[spos+3*qdim], &lbf[spos+4*qdim],
                             &lbf[spos+5*qdim], &lbf[spos+6*qdim], &lbf[spos+7*qdim], &lbf[spos+8*qdim],
                             &lbf[spos+9*qdim], &lbf[spos+10*qdim], &lbf[spos+11*qdim], &lbf[spos+12*qdim],
                             &lbf[spos+13*qdim]);
        break;
      case PSL:
        fD3Q27VPSCLBEInamuro(-uwall[2], -uwall[0], -uwall[1], &force[0], &lbf[spos], &lbf[spos+16*qdim],
                             &lbf[spos+14*qdim], &lbf[spos+15*qdim], &lbf[spos+19*qdim], &lbf[spos+7*qdim],
                             &lbf[spos+21*qdim], &lbf[spos+9*qdim], &lbf[spos+17*qdim], &lbf[spos+18*qdim],
                             &lbf[spos+23*qdim], &lbf[spos+25*qdim], &lbf[spos+13*qdim], &lbf[spos+11*qdim],
                             &lbf[spos+3*qdim], &lbf[spos+1*qdim], &lbf[spos+2*qdim], &lbf[spos+6*qdim],
                             &lbf[spos+20*qdim], &lbf[spos+8*qdim], &lbf[spos+22*qdim], &lbf[spos+4*qdim],
                             &lbf[spos+5*qdim], &lbf[spos+10*qdim], &lbf[spos+12*qdim], &lbf[spos+26*qdim],
                             &lbf[spos+24*qdim]);
        break;
      case PSR:
        fD3Q27VPSCLBEInamuro(uwall[2], uwall[0], uwall[1], &force[0], &lbf[spos], &lbf[spos+3*qdim],
                             &lbf[spos+1*qdim], &lbf[spos+2*qdim], &lbf[spos+6*qdim], &lbf[spos+20*qdim],
                             &lbf[spos+8*qdim], &lbf[spos+22*qdim], &lbf[spos+4*qdim], &lbf[spos+5*qdim],
                             &lbf[spos+10*qdim], &lbf[spos+12*qdim], &lbf[spos+26*qdim], &lbf[spos+24*qdim],
                             &lbf[spos+16*qdim], &lbf[spos+14*qdim], &lbf[spos+15*qdim], &lbf[spos+19*qdim],
                             &lbf[spos+7*qdim], &lbf[spos+21*qdim], &lbf[spos+9*qdim], &lbf[spos+17*qdim],
                             &lbf[spos+18*qdim], &lbf[spos+23*qdim], &lbf[spos+25*qdim], &lbf[spos+13*qdim],
                             &lbf[spos+11*qdim]);
        break;
      case PSF:
        fD3Q27VPSCLBEInamuro(-uwall[1], -uwall[2], -uwall[0], &force[0], &lbf[spos], &lbf[spos+15*qdim],
                             &lbf[spos+16*qdim], &lbf[spos+14*qdim], &lbf[spos+21*qdim], &lbf[spos+22*qdim],
                             &lbf[spos+17*qdim], &lbf[spos+5*qdim], &lbf[spos+19*qdim], &lbf[spos+7*qdim],
                             &lbf[spos+23*qdim], &lbf[spos+13*qdim], &lbf[spos+24*qdim], &lbf[spos+12*qdim],
                             &lbf[spos+2*qdim], &lbf[spos+3*qdim], &lbf[spos+1*qdim], &lbf[spos+8*qdim],
                             &lbf[spos+9*qdim], &lbf[spos+4*qdim], &lbf[spos+18*qdim], &lbf[spos+6*qdim],
                             &lbf[spos+20*qdim], &lbf[spos+10*qdim], &lbf[spos+26*qdim], &lbf[spos+11*qdim],
                             &lbf[spos+25*qdim]);
        break;
      case PSB:
        fD3Q27VPSCLBEInamuro(uwall[1], uwall[2], uwall[0], &force[0], &lbf[spos], &lbf[spos+2*qdim],
                             &lbf[spos+3*qdim], &lbf[spos+1*qdim], &lbf[spos+8*qdim], &lbf[spos+9*qdim],
                             &lbf[spos+4*qdim], &lbf[spos+18*qdim], &lbf[spos+6*qdim], &lbf[spos+20*qdim],
                             &lbf[spos+10*qdim], &lbf[spos+26*qdim], &lbf[spos+11*qdim], &lbf[spos+25*qdim],
                             &lbf[spos+15*qdim], &lbf[spos+16*qdim], &lbf[spos+14*qdim], &lbf[spos+21*qdim],
                             &lbf[spos+22*qdim], &lbf[spos+17*qdim], &lbf[spos+5*qdim], &lbf[spos+19*qdim],
                             &lbf[spos+7*qdim], &lbf[spos+23*qdim], &lbf[spos+13*qdim], &lbf[spos+24*qdim],
                             &lbf[spos+12*qdim]);
        break;
      case CCTRB:
        fD3Q27VCCCLBEInamuro(rho, uwall[0], uwall[1], -uwall[2], &force[0], &lbf[spos], &lbf[spos+1*qdim],
                             &lbf[spos+2*qdim], &lbf[spos+16*qdim], &lbf[spos+4*qdim], &lbf[spos+5*qdim],
                             &lbf[spos+7*qdim], &lbf[spos+6*qdim], &lbf[spos+9*qdim], &lbf[spos+8*qdim],
                             &lbf[spos+11*qdim], &lbf[spos+10*qdim], &lbf[spos+13*qdim], &lbf[spos+12*qdim],
                             &lbf[spos+14*qdim], &lbf[spos+15*qdim], &lbf[spos+3*qdim], &lbf[spos+17*qdim],
                             &lbf[spos+18*qdim], &lbf[spos+20*qdim], &lbf[spos+19*qdim], &lbf[spos+22*qdim],
                             &lbf[spos+21*qdim], &lbf[spos+24*qdim], &lbf[spos+23*qdim], &lbf[spos+26*qdim],
                             &lbf[spos+25*qdim]);
        break;
      case CCTLB:
        fD3Q27VCCCLBEInamuro(rho, -uwall[0], uwall[1], -uwall[2], &force[0], &lbf[spos], &lbf[spos+14*qdim],
                             &lbf[spos+2*qdim], &lbf[spos+16*qdim], &lbf[spos+18*qdim], &lbf[spos+17*qdim],
                             &lbf[spos+19*qdim], &lbf[spos+20*qdim], &lbf[spos+9*qdim], &lbf[spos+8*qdim],
                             &lbf[spos+25*qdim], &lbf[spos+26*qdim], &lbf[spos+23*qdim], &lbf[spos+24*qdim],
                             &lbf[spos+1*qdim], &lbf[spos+15*qdim], &lbf[spos+3*qdim], &lbf[spos+5*qdim],
                             &lbf[spos+4*qdim], &lbf[spos+6*qdim], &lbf[spos+7*qdim], &lbf[spos+22*qdim],
                             &lbf[spos+21*qdim], &lbf[spos+12*qdim], &lbf[spos+13*qdim], &lbf[spos+10*qdim],
                             &lbf[spos+11*qdim]);
        break;
      case CCDLB:
        fD3Q27VCCCLBEInamuro(rho, -uwall[0], -uwall[1], -uwall[2], &force[0], &lbf[spos], &lbf[spos+14*qdim],
                             &lbf[spos+15*qdim], &lbf[spos+16*qdim], &lbf[spos+17*qdim], &lbf[spos+18*qdim],
                             &lbf[spos+19*qdim], &lbf[spos+20*qdim], &lbf[spos+21*qdim], &lbf[spos+22*qdim],
                             &lbf[spos+23*qdim], &lbf[spos+24*qdim], &lbf[spos+25*qdim], &lbf[spos+26*qdim],
                             &lbf[spos+1*qdim], &lbf[spos+2*qdim], &lbf[spos+3*qdim], &lbf[spos+4*qdim],
                             &lbf[spos+5*qdim], &lbf[spos+6*qdim], &lbf[spos+7*qdim], &lbf[spos+8*qdim],
                             &lbf[spos+9*qdim], &lbf[spos+10*qdim], &lbf[spos+11*qdim], &lbf[spos+12*qdim],
                             &lbf[spos+13*qdim]);
        break;
      case CCDRB:
        fD3Q27VCCCLBEInamuro(rho, uwall[0], -uwall[1], -uwall[2], &force[0], &lbf[spos], &lbf[spos+1*qdim],
                             &lbf[spos+15*qdim], &lbf[spos+16*qdim], &lbf[spos+5*qdim], &lbf[spos+4*qdim],
                             &lbf[spos+7*qdim], &lbf[spos+6*qdim], &lbf[spos+21*qdim], &lbf[spos+22*qdim],
                             &lbf[spos+13*qdim], &lbf[spos+12*qdim], &lbf[spos+11*qdim], &lbf[spos+10*qdim],
                             &lbf[spos+14*qdim], &lbf[spos+2*qdim], &lbf[spos+3*qdim], &lbf[spos+18*qdim],
                             &lbf[spos+17*qdim], &lbf[spos+20*qdim], &lbf[spos+19*qdim], &lbf[spos+8*qdim],
                             &lbf[spos+9*qdim], &lbf[spos+26*qdim], &lbf[spos+25*qdim], &lbf[spos+24*qdim],
                             &lbf[spos+23*qdim]);
        break;
      case CCTRF:
        fD3Q27VCCCLBEInamuro(rho, uwall[0], uwall[1], uwall[2], &force[0], &lbf[spos], &lbf[spos+1*qdim],
                             &lbf[spos+2*qdim], &lbf[spos+3*qdim], &lbf[spos+4*qdim], &lbf[spos+5*qdim],
                             &lbf[spos+6*qdim], &lbf[spos+7*qdim], &lbf[spos+8*qdim], &lbf[spos+9*qdim],
                             &lbf[spos+10*qdim], &lbf[spos+11*qdim], &lbf[spos+12*qdim], &lbf[spos+13*qdim],
                             &lbf[spos+14*qdim], &lbf[spos+15*qdim], &lbf[spos+16*qdim], &lbf[spos+17*qdim],
                             &lbf[spos+18*qdim], &lbf[spos+19*qdim], &lbf[spos+20*qdim], &lbf[spos+21*qdim],
                             &lbf[spos+22*qdim], &lbf[spos+23*qdim], &lbf[spos+24*qdim], &lbf[spos+25*qdim],
                             &lbf[spos+26*qdim]);
        break;
      case CCTLF:
        fD3Q27VCCCLBEInamuro(rho, -uwall[0], uwall[1], uwall[2], &force[0], &lbf[spos], &lbf[spos+14*qdim],
                             &lbf[spos+2*qdim], &lbf[spos+3*qdim], &lbf[spos+18*qdim], &lbf[spos+17*qdim],
                             &lbf[spos+20*qdim], &lbf[spos+19*qdim], &lbf[spos+8*qdim], &lbf[spos+9*qdim],
                             &lbf[spos+26*qdim], &lbf[spos+25*qdim], &lbf[spos+24*qdim], &lbf[spos+23*qdim],
                             &lbf[spos+1*qdim], &lbf[spos+15*qdim], &lbf[spos+16*qdim], &lbf[spos+5*qdim],
                             &lbf[spos+4*qdim], &lbf[spos+7*qdim], &lbf[spos+6*qdim], &lbf[spos+21*qdim],
                             &lbf[spos+22*qdim], &lbf[spos+13*qdim], &lbf[spos+12*qdim], &lbf[spos+11*qdim],
                             &lbf[spos+10*qdim]);
        break;
      case CCDLF:
        fD3Q27VCCCLBEInamuro(rho, -uwall[0], -uwall[1], uwall[2], &force[0], &lbf[spos], &lbf[spos+14*qdim],
                             &lbf[spos+15*qdim], &lbf[spos+3*qdim], &lbf[spos+17*qdim], &lbf[spos+18*qdim],
                             &lbf[spos+20*qdim], &lbf[spos+19*qdim], &lbf[spos+22*qdim], &lbf[spos+21*qdim],
                             &lbf[spos+24*qdim], &lbf[spos+23*qdim], &lbf[spos+26*qdim], &lbf[spos+25*qdim],
                             &lbf[spos+1*qdim], &lbf[spos+2*qdim], &lbf[spos+16*qdim], &lbf[spos+4*qdim],
                             &lbf[spos+5*qdim], &lbf[spos+7*qdim], &lbf[spos+6*qdim], &lbf[spos+9*qdim],
                             &lbf[spos+8*qdim], &lbf[spos+11*qdim], &lbf[spos+10*qdim], &lbf[spos+13*qdim],
                             &lbf[spos+12*qdim]);
        break;
      case CCDRF:
        fD3Q27VCCCLBEInamuro(rho, uwall[0], -uwall[1], uwall[2], &force[0], &lbf[spos], &lbf[spos+1*qdim],
                             &lbf[spos+15*qdim], &lbf[spos+3*qdim], &lbf[spos+5*qdim], &lbf[spos+4*qdim],
                             &lbf[spos+6*qdim], &lbf[spos+7*qdim], &lbf[spos+22*qdim], &lbf[spos+21*qdim],
                             &lbf[spos+12*qdim], &lbf[spos+13*qdim], &lbf[spos+10*qdim], &lbf[spos+11*qdim],
                             &lbf[spos+14*qdim], &lbf[spos+2*qdim], &lbf[spos+16*qdim], &lbf[spos+18*qdim],
                             &lbf[spos+17*qdim], &lbf[spos+19*qdim], &lbf[spos+20*qdim], &lbf[spos+9*qdim],
                             &lbf[spos+8*qdim], &lbf[spos+25*qdim], &lbf[spos+26*qdim], &lbf[spos+23*qdim],
                             &lbf[spos+24*qdim]);
        break;
      case CETR:
        fD3Q27VCECLBEInamuro(rho, uwall[0], uwall[1], uwall[2], &force[0], &lbf[spos], &lbf[spos+1*qdim],
                             &lbf[spos+2*qdim], &lbf[spos+3*qdim], &lbf[spos+4*qdim], &lbf[spos+5*qdim],
                             &lbf[spos+6*qdim], &lbf[spos+7*qdim], &lbf[spos+8*qdim], &lbf[spos+9*qdim],
                             &lbf[spos+10*qdim], &lbf[spos+11*qdim], &lbf[spos+12*qdim], &lbf[spos+13*qdim],
                             &lbf[spos+14*qdim], &lbf[spos+15*qdim], &lbf[spos+16*qdim], &lbf[spos+17*qdim],
                             &lbf[spos+18*qdim], &lbf[spos+19*qdim], &lbf[spos+20*qdim], &lbf[spos+21*qdim],
                             &lbf[spos+22*qdim], &lbf[spos+23*qdim], &lbf[spos+24*qdim], &lbf[spos+25*qdim],
                             &lbf[spos+26*qdim]);
        break;
      case CETL:
        fD3Q27VCECLBEInamuro(rho, uwall[1], -uwall[0], uwall[2], &force[0], &lbf[spos], &lbf[spos+2*qdim],
                             &lbf[spos+14*qdim], &lbf[spos+3*qdim], &lbf[spos+18*qdim], &lbf[spos+4*qdim],
                             &lbf[spos+8*qdim], &lbf[spos+9*qdim], &lbf[spos+20*qdim], &lbf[spos+19*qdim],
                             &lbf[spos+26*qdim], &lbf[spos+25*qdim], &lbf[spos+10*qdim], &lbf[spos+11*qdim],
                             &lbf[spos+15*qdim], &lbf[spos+1*qdim], &lbf[spos+16*qdim], &lbf[spos+5*qdim],
                             &lbf[spos+17*qdim], &lbf[spos+21*qdim], &lbf[spos+22*qdim], &lbf[spos+7*qdim],
                             &lbf[spos+6*qdim], &lbf[spos+13*qdim], &lbf[spos+12*qdim], &lbf[spos+23*qdim],
                             &lbf[spos+24*qdim]);
        break;
      case CEDL:
        fD3Q27VCECLBEInamuro(rho, -uwall[0], -uwall[1], uwall[2], &force[0], &lbf[spos], &lbf[spos+14*qdim],
                             &lbf[spos+15*qdim], &lbf[spos+3*qdim], &lbf[spos+17*qdim], &lbf[spos+18*qdim],
                             &lbf[spos+20*qdim], &lbf[spos+19*qdim], &lbf[spos+22*qdim], &lbf[spos+21*qdim],
                             &lbf[spos+24*qdim], &lbf[spos+23*qdim], &lbf[spos+26*qdim], &lbf[spos+25*qdim],
                             &lbf[spos+1*qdim], &lbf[spos+2*qdim], &lbf[spos+16*qdim], &lbf[spos+4*qdim],
                             &lbf[spos+5*qdim], &lbf[spos+7*qdim], &lbf[spos+6*qdim], &lbf[spos+9*qdim],
                             &lbf[spos+8*qdim], &lbf[spos+11*qdim], &lbf[spos+10*qdim], &lbf[spos+13*qdim],
                             &lbf[spos+12*qdim]);
        break;
      case CEDR:
        fD3Q27VCECLBEInamuro(rho, -uwall[1], uwall[0], uwall[2], &force[0], &lbf[spos], &lbf[spos+15*qdim],
                             &lbf[spos+1*qdim], &lbf[spos+3*qdim], &lbf[spos+5*qdim], &lbf[spos+17*qdim],
                             &lbf[spos+22*qdim], &lbf[spos+21*qdim], &lbf[spos+6*qdim], &lbf[spos+7*qdim],
                             &lbf[spos+12*qdim], &lbf[spos+13*qdim], &lbf[spos+24*qdim], &lbf[spos+23*qdim],
                             &lbf[spos+2*qdim], &lbf[spos+14*qdim], &lbf[spos+16*qdim], &lbf[spos+18*qdim],
                             &lbf[spos+4*qdim], &lbf[spos+9*qdim], &lbf[spos+8*qdim], &lbf[spos+19*qdim],
                             &lbf[spos+20*qdim], &lbf[spos+25*qdim], &lbf[spos+26*qdim], &lbf[spos+11*qdim],
                             &lbf[spos+10*qdim]);
        break;
      case CETF:
        fD3Q27VCECLBEInamuro(rho, uwall[1], uwall[2], uwall[0], &force[0], &lbf[spos], &lbf[spos+2*qdim],
                             &lbf[spos+3*qdim], &lbf[spos+1*qdim], &lbf[spos+8*qdim], &lbf[spos+9*qdim],
                             &lbf[spos+4*qdim], &lbf[spos+18*qdim], &lbf[spos+6*qdim], &lbf[spos+20*qdim],
                             &lbf[spos+10*qdim], &lbf[spos+26*qdim], &lbf[spos+11*qdim], &lbf[spos+25*qdim],
                             &lbf[spos+15*qdim], &lbf[spos+16*qdim], &lbf[spos+14*qdim], &lbf[spos+21*qdim],
                             &lbf[spos+22*qdim], &lbf[spos+17*qdim], &lbf[spos+5*qdim], &lbf[spos+19*qdim],
                             &lbf[spos+7*qdim], &lbf[spos+23*qdim], &lbf[spos+13*qdim], &lbf[spos+24*qdim],
                             &lbf[spos+12*qdim]);
        break;
      case CELF:
        fD3Q27VCECLBEInamuro(rho, -uwall[0], uwall[1], uwall[2], &force[0], &lbf[spos], &lbf[spos+14*qdim],
                             &lbf[spos+3*qdim], &lbf[spos+2*qdim], &lbf[spos+20*qdim], &lbf[spos+19*qdim],
                             &lbf[spos+18*qdim], &lbf[spos+17*qdim], &lbf[spos+8*qdim], &lbf[spos+22*qdim],
                             &lbf[spos+26*qdim], &lbf[spos+24*qdim], &lbf[spos+25*qdim], &lbf[spos+23*qdim],
                             &lbf[spos+1*qdim], &lbf[spos+16*qdim], &lbf[spos+15*qdim], &lbf[spos+7*qdim],
                             &lbf[spos+6*qdim], &lbf[spos+5*qdim], &lbf[spos+4*qdim], &lbf[spos+21*qdim],
                             &lbf[spos+9*qdim], &lbf[spos+13*qdim], &lbf[spos+11*qdim], &lbf[spos+12*qdim],
                             &lbf[spos+10*qdim]);
        break;
      case CEDF:
        fD3Q27VCECLBEInamuro(rho, -uwall[1], uwall[2], uwall[0], &force[0], &lbf[spos], &lbf[spos+15*qdim],
                             &lbf[spos+3*qdim], &lbf[spos+1*qdim], &lbf[spos+22*qdim], &lbf[spos+21*qdim],
                             &lbf[spos+5*qdim], &lbf[spos+17*qdim], &lbf[spos+6*qdim], &lbf[spos+20*qdim],
                             &lbf[spos+12*qdim], &lbf[spos+24*qdim], &lbf[spos+13*qdim], &lbf[spos+23*qdim],
                             &lbf[spos+2*qdim], &lbf[spos+16*qdim], &lbf[spos+14*qdim], &lbf[spos+9*qdim],
                             &lbf[spos+8*qdim], &lbf[spos+18*qdim], &lbf[spos+4*qdim], &lbf[spos+19*qdim],
                             &lbf[spos+7*qdim], &lbf[spos+25*qdim], &lbf[spos+11*qdim], &lbf[spos+26*qdim],
                             &lbf[spos+10*qdim]);
        break;
      case CERF:
        fD3Q27VCECLBEInamuro(rho, uwall[0], uwall[2], uwall[2], &force[0], &lbf[spos], &lbf[spos+1*qdim],
                             &lbf[spos+3*qdim], &lbf[spos+2*qdim], &lbf[spos+6*qdim], &lbf[spos+7*qdim],
                             &lbf[spos+4*qdim], &lbf[spos+5*qdim], &lbf[spos+8*qdim], &lbf[spos+22*qdim],
                             &lbf[spos+10*qdim], &lbf[spos+12*qdim], &lbf[spos+11*qdim], &lbf[spos+13*qdim],
                             &lbf[spos+14*qdim], &lbf[spos+16*qdim], &lbf[spos+15*qdim], &lbf[spos+19*qdim],
                             &lbf[spos+20*qdim], &lbf[spos+17*qdim], &lbf[spos+18*qdim], &lbf[spos+21*qdim],
                             &lbf[spos+9*qdim], &lbf[spos+23*qdim], &lbf[spos+25*qdim], &lbf[spos+24*qdim],
                             &lbf[spos+26*qdim]);
        break;
      case CETB:
        fD3Q27VCECLBEInamuro(rho, uwall[1], -uwall[2], uwall[0], &force[0], &lbf[spos], &lbf[spos+2*qdim],
                             &lbf[spos+16*qdim], &lbf[spos+1*qdim], &lbf[spos+9*qdim], &lbf[spos+8*qdim],
                             &lbf[spos+4*qdim], &lbf[spos+18*qdim], &lbf[spos+7*qdim], &lbf[spos+19*qdim],
                             &lbf[spos+11*qdim], &lbf[spos+25*qdim], &lbf[spos+10*qdim], &lbf[spos+26*qdim],
                             &lbf[spos+15*qdim], &lbf[spos+3*qdim], &lbf[spos+14*qdim], &lbf[spos+22*qdim],
                             &lbf[spos+21*qdim], &lbf[spos+17*qdim], &lbf[spos+5*qdim], &lbf[spos+20*qdim],
                             &lbf[spos+6*qdim], &lbf[spos+24*qdim], &lbf[spos+12*qdim], &lbf[spos+23*qdim],
                             &lbf[spos+13*qdim]);
        break;
      case CELB:
        fD3Q27VCECLBEInamuro(rho, -uwall[0], -uwall[2], uwall[1], &force[0], &lbf[spos], &lbf[spos+14*qdim],
                             &lbf[spos+16*qdim], &lbf[spos+2*qdim], &lbf[spos+19*qdim], &lbf[spos+20*qdim],
                             &lbf[spos+18*qdim], &lbf[spos+17*qdim], &lbf[spos+9*qdim], &lbf[spos+21*qdim],
                             &lbf[spos+25*qdim], &lbf[spos+23*qdim], &lbf[spos+26*qdim], &lbf[spos+24*qdim],
                             &lbf[spos+1*qdim], &lbf[spos+3*qdim], &lbf[spos+15*qdim], &lbf[spos+6*qdim],
                             &lbf[spos+7*qdim], &lbf[spos+5*qdim], &lbf[spos+4*qdim], &lbf[spos+22*qdim],
                             &lbf[spos+8*qdim], &lbf[spos+12*qdim], &lbf[spos+10*qdim], &lbf[spos+13*qdim],
                             &lbf[spos+11*qdim]);
        break;
      case CEDB:
        fD3Q27VCECLBEInamuro(rho, -uwall[1], -uwall[2], uwall[0], &force[0], &lbf[spos], &lbf[spos+15*qdim],
                             &lbf[spos+16*qdim], &lbf[spos+1*qdim], &lbf[spos+21*qdim], &lbf[spos+22*qdim],
                             &lbf[spos+5*qdim], &lbf[spos+17*qdim], &lbf[spos+7*qdim], &lbf[spos+19*qdim],
                             &lbf[spos+13*qdim], &lbf[spos+23*qdim], &lbf[spos+12*qdim], &lbf[spos+24*qdim],
                             &lbf[spos+2*qdim], &lbf[spos+3*qdim], &lbf[spos+14*qdim], &lbf[spos+8*qdim],
                             &lbf[spos+9*qdim], &lbf[spos+18*qdim], &lbf[spos+4*qdim], &lbf[spos+20*qdim],
                             &lbf[spos+6*qdim], &lbf[spos+26*qdim], &lbf[spos+10*qdim], &lbf[spos+25*qdim],
                             &lbf[spos+11*qdim]);
        break;
      case CERB:
        fD3Q27VCECLBEInamuro(rho, uwall[0], -uwall[2], uwall[1], &force[0], &lbf[spos], &lbf[spos+1*qdim],
                             &lbf[spos+16*qdim], &lbf[spos+2*qdim], &lbf[spos+7*qdim], &lbf[spos+6*qdim],
                             &lbf[spos+4*qdim], &lbf[spos+5*qdim], &lbf[spos+9*qdim], &lbf[spos+21*qdim],
                             &lbf[spos+11*qdim], &lbf[spos+13*qdim], &lbf[spos+10*qdim], &lbf[spos+12*qdim],
                             &lbf[spos+14*qdim], &lbf[spos+3*qdim], &lbf[spos+15*qdim], &lbf[spos+20*qdim],
                             &lbf[spos+19*qdim], &lbf[spos+17*qdim], &lbf[spos+18*qdim], &lbf[spos+22*qdim],
                             &lbf[spos+8*qdim], &lbf[spos+24*qdim], &lbf[spos+26*qdim], &lbf[spos+23*qdim],
                             &lbf[spos+25*qdim]);
        break;
    }
  }
  else {
    switch (prop) {
      case PST:
        fD3Q27VPSInamuro(uwall[0], uwall[1], uwall[2], &force[0], &lbf[spos], &lbf[spos+1*qdim],
                         &lbf[spos+2*qdim], &lbf[spos+3*qdim], &lbf[spos+4*qdim], &lbf[spos+5*qdim],
                         &lbf[spos+6*qdim], &lbf[spos+7*qdim], &lbf[spos+8*qdim], &lbf[spos+9*qdim],
                         &lbf[spos+10*qdim], &lbf[spos+11*qdim], &lbf[spos+12*qdim], &lbf[spos+13*qdim],
                         &lbf[spos+14*qdim], &lbf[spos+15*qdim], &lbf[spos+16*qdim], &lbf[spos+17*qdim],
                         &lbf[spos+18*qdim], &lbf[spos+19*qdim], &lbf[spos+20*qdim], &lbf[spos+21*qdim],
                         &lbf[spos+22*qdim], &lbf[spos+23*qdim], &lbf[spos+24*qdim], &lbf[spos+25*qdim],
                         &lbf[spos+26*qdim]);
        break;
      case PSD:
        fD3Q27VPSInamuro(-uwall[0], -uwall[1], -uwall[2], &force[0], &lbf[spos], &lbf[spos+14*qdim],
                         &lbf[spos+15*qdim], &lbf[spos+16*qdim], &lbf[spos+17*qdim], &lbf[spos+18*qdim],
                         &lbf[spos+19*qdim], &lbf[spos+20*qdim], &lbf[spos+21*qdim], &lbf[spos+22*qdim],
                         &lbf[spos+23*qdim], &lbf[spos+24*qdim], &lbf[spos+25*qdim], &lbf[spos+26*qdim],
                         &lbf[spos+1*qdim], &lbf[spos+2*qdim], &lbf[spos+3*qdim], &lbf[spos+4*qdim],
                         &lbf[spos+5*qdim], &lbf[spos+6*qdim], &lbf[spos+7*qdim], &lbf[spos+8*qdim],
                         &lbf[spos+9*qdim], &lbf[spos+10*qdim], &lbf[spos+11*qdim], &lbf[spos+12*qdim],
                         &lbf[spos+13*qdim]);
        break;
      case PSL:
        fD3Q27VPSInamuro(-uwall[2], -uwall[0], -uwall[1], &force[0], &lbf[spos], &lbf[spos+16*qdim],
                         &lbf[spos+14*qdim], &lbf[spos+15*qdim], &lbf[spos+19*qdim], &lbf[spos+7*qdim],
                         &lbf[spos+21*qdim], &lbf[spos+9*qdim], &lbf[spos+17*qdim], &lbf[spos+18*qdim],
                         &lbf[spos+23*qdim], &lbf[spos+25*qdim], &lbf[spos+13*qdim], &lbf[spos+11*qdim],
                         &lbf[spos+3*qdim], &lbf[spos+1*qdim], &lbf[spos+2*qdim], &lbf[spos+6*qdim],
                         &lbf[spos+20*qdim], &lbf[spos+8*qdim], &lbf[spos+22*qdim], &lbf[spos+4*qdim],
                         &lbf[spos+5*qdim], &lbf[spos+10*qdim], &lbf[spos+12*qdim], &lbf[spos+26*qdim],
                         &lbf[spos+24*qdim]);
        break;
      case PSR:
        fD3Q27VPSInamuro(uwall[2], uwall[0], uwall[1], &force[0], &lbf[spos], &lbf[spos+3*qdim],
                         &lbf[spos+1*qdim], &lbf[spos+2*qdim], &lbf[spos+6*qdim], &lbf[spos+20*qdim],
                         &lbf[spos+8*qdim], &lbf[spos+22*qdim], &lbf[spos+4*qdim], &lbf[spos+5*qdim],
                         &lbf[spos+10*qdim], &lbf[spos+12*qdim], &lbf[spos+26*qdim], &lbf[spos+24*qdim],
                         &lbf[spos+16*qdim], &lbf[spos+14*qdim], &lbf[spos+15*qdim], &lbf[spos+19*qdim],
                         &lbf[spos+7*qdim], &lbf[spos+21*qdim], &lbf[spos+9*qdim], &lbf[spos+17*qdim],
                         &lbf[spos+18*qdim], &lbf[spos+23*qdim], &lbf[spos+25*qdim], &lbf[spos+13*qdim],
                         &lbf[spos+11*qdim]);
        break;
      case PSF:
        fD3Q27VPSInamuro(-uwall[1], -uwall[2], -uwall[0], &force[0], &lbf[spos], &lbf[spos+15*qdim],
                         &lbf[spos+16*qdim], &lbf[spos+14*qdim], &lbf[spos+21*qdim], &lbf[spos+22*qdim],
                         &lbf[spos+17*qdim], &lbf[spos+5*qdim], &lbf[spos+19*qdim], &lbf[spos+7*qdim],
                         &lbf[spos+23*qdim], &lbf[spos+13*qdim], &lbf[spos+24*qdim], &lbf[spos+12*qdim],
                         &lbf[spos+2*qdim], &lbf[spos+3*qdim], &lbf[spos+1*qdim], &lbf[spos+8*qdim],
                         &lbf[spos+9*qdim], &lbf[spos+4*qdim], &lbf[spos+18*qdim], &lbf[spos+6*qdim],
                         &lbf[spos+20*qdim], &lbf[spos+10*qdim], &lbf[spos+26*qdim], &lbf[spos+11*qdim],
                         &lbf[spos+25*qdim]);
        break;
      case PSB:
        fD3Q27VPSInamuro(uwall[1], uwall[2], uwall[0], &force[0], &lbf[spos], &lbf[spos+2*qdim],
                         &lbf[spos+3*qdim], &lbf[spos+1*qdim], &lbf[spos+8*qdim], &lbf[spos+9*qdim],
                         &lbf[spos+4*qdim], &lbf[spos+18*qdim], &lbf[spos+6*qdim], &lbf[spos+20*qdim],
                         &lbf[spos+10*qdim], &lbf[spos+26*qdim], &lbf[spos+11*qdim], &lbf[spos+25*qdim],
                         &lbf[spos+15*qdim], &lbf[spos+16*qdim], &lbf[spos+14*qdim], &lbf[spos+21*qdim],
                         &lbf[spos+22*qdim], &lbf[spos+17*qdim], &lbf[spos+5*qdim], &lbf[spos+19*qdim],
                         &lbf[spos+7*qdim], &lbf[spos+23*qdim], &lbf[spos+13*qdim], &lbf[spos+24*qdim],
                         &lbf[spos+12*qdim]);
        break;
      case CCTRB:
        fD3Q27VCCInamuro(rho, uwall[0], uwall[1], -uwall[2], &force[0], &lbf[spos], &lbf[spos+1*qdim],
                         &lbf[spos+2*qdim], &lbf[spos+16*qdim], &lbf[spos+4*qdim], &lbf[spos+5*qdim],
                         &lbf[spos+7*qdim], &lbf[spos+6*qdim], &lbf[spos+9*qdim], &lbf[spos+8*qdim],
                         &lbf[spos+11*qdim], &lbf[spos+10*qdim], &lbf[spos+13*qdim], &lbf[spos+12*qdim],
                         &lbf[spos+14*qdim], &lbf[spos+15*qdim], &lbf[spos+3*qdim], &lbf[spos+17*qdim],
                         &lbf[spos+18*qdim], &lbf[spos+20*qdim], &lbf[spos+19*qdim], &lbf[spos+22*qdim],
                         &lbf[spos+21*qdim], &lbf[spos+24*qdim], &lbf[spos+23*qdim], &lbf[spos+26*qdim],
                         &lbf[spos+25*qdim]);
        break;
      case CCTLB:
        fD3Q27VCCInamuro(rho, -uwall[0], uwall[1], -uwall[2], &force[0], &lbf[spos], &lbf[spos+14*qdim],
                         &lbf[spos+2*qdim], &lbf[spos+16*qdim], &lbf[spos+18*qdim], &lbf[spos+17*qdim],
                         &lbf[spos+19*qdim], &lbf[spos+20*qdim], &lbf[spos+9*qdim], &lbf[spos+8*qdim],
                         &lbf[spos+25*qdim], &lbf[spos+26*qdim], &lbf[spos+23*qdim], &lbf[spos+24*qdim],
                         &lbf[spos+1*qdim], &lbf[spos+15*qdim], &lbf[spos+3*qdim], &lbf[spos+5*qdim],
                         &lbf[spos+4*qdim], &lbf[spos+6*qdim], &lbf[spos+7*qdim], &lbf[spos+22*qdim],
                         &lbf[spos+21*qdim], &lbf[spos+12*qdim], &lbf[spos+13*qdim], &lbf[spos+10*qdim],
                         &lbf[spos+11*qdim]);
        break;
      case CCDLB:
        fD3Q27VCCInamuro(rho, -uwall[0], -uwall[1], -uwall[2], &force[0], &lbf[spos], &lbf[spos+14*qdim],
                         &lbf[spos+15*qdim], &lbf[spos+16*qdim], &lbf[spos+17*qdim], &lbf[spos+18*qdim],
                         &lbf[spos+19*qdim], &lbf[spos+20*qdim], &lbf[spos+21*qdim], &lbf[spos+22*qdim],
                         &lbf[spos+23*qdim], &lbf[spos+24*qdim], &lbf[spos+25*qdim], &lbf[spos+26*qdim],
                         &lbf[spos+1*qdim], &lbf[spos+2*qdim], &lbf[spos+3*qdim], &lbf[spos+4*qdim],
                         &lbf[spos+5*qdim], &lbf[spos+6*qdim], &lbf[spos+7*qdim], &lbf[spos+8*qdim],
                         &lbf[spos+9*qdim], &lbf[spos+10*qdim], &lbf[spos+11*qdim], &lbf[spos+12*qdim],
                         &lbf[spos+13*qdim]);
        break;
      case CCDRB:
        fD3Q27VCCInamuro(rho, uwall[0], -uwall[1], -uwall[2], &force[0], &lbf[spos], &lbf[spos+1*qdim],
                         &lbf[spos+15*qdim], &lbf[spos+16*qdim], &lbf[spos+5*qdim], &lbf[spos+4*qdim],
                         &lbf[spos+7*qdim], &lbf[spos+6*qdim], &lbf[spos+21*qdim], &lbf[spos+22*qdim],
                         &lbf[spos+13*qdim], &lbf[spos+12*qdim], &lbf[spos+11*qdim], &lbf[spos+10*qdim],
                         &lbf[spos+14*qdim], &lbf[spos+2*qdim], &lbf[spos+3*qdim], &lbf[spos+18*qdim],
                         &lbf[spos+17*qdim], &lbf[spos+20*qdim], &lbf[spos+19*qdim], &lbf[spos+8*qdim],
                         &lbf[spos+9*qdim], &lbf[spos+26*qdim], &lbf[spos+25*qdim], &lbf[spos+24*qdim],
                         &lbf[spos+23*qdim]);
        break;
      case CCTRF:
        fD3Q27VCCInamuro(rho, uwall[0], uwall[1], uwall[2], &force[0], &lbf[spos], &lbf[spos+1*qdim],
                         &lbf[spos+2*qdim], &lbf[spos+3*qdim], &lbf[spos+4*qdim], &lbf[spos+5*qdim],
                         &lbf[spos+6*qdim], &lbf[spos+7*qdim], &lbf[spos+8*qdim], &lbf[spos+9*qdim],
                         &lbf[spos+10*qdim], &lbf[spos+11*qdim], &lbf[spos+12*qdim], &lbf[spos+13*qdim],
                         &lbf[spos+14*qdim], &lbf[spos+15*qdim], &lbf[spos+16*qdim], &lbf[spos+17*qdim],
                         &lbf[spos+18*qdim], &lbf[spos+19*qdim], &lbf[spos+20*qdim], &lbf[spos+21*qdim],
                         &lbf[spos+22*qdim], &lbf[spos+23*qdim], &lbf[spos+24*qdim], &lbf[spos+25*qdim],
                         &lbf[spos+26*qdim]);
        break;
      case CCTLF:
        fD3Q27VCCInamuro(rho, -uwall[0], uwall[1], uwall[2], &force[0], &lbf[spos], &lbf[spos+14*qdim],
                         &lbf[spos+2*qdim], &lbf[spos+3*qdim], &lbf[spos+18*qdim], &lbf[spos+17*qdim],
                         &lbf[spos+20*qdim], &lbf[spos+19*qdim], &lbf[spos+8*qdim], &lbf[spos+9*qdim],
                         &lbf[spos+26*qdim], &lbf[spos+25*qdim], &lbf[spos+24*qdim], &lbf[spos+23*qdim],
                         &lbf[spos+1*qdim], &lbf[spos+15*qdim], &lbf[spos+16*qdim], &lbf[spos+5*qdim],
                         &lbf[spos+4*qdim], &lbf[spos+7*qdim], &lbf[spos+6*qdim], &lbf[spos+21*qdim],
                         &lbf[spos+22*qdim], &lbf[spos+13*qdim], &lbf[spos+12*qdim], &lbf[spos+11*qdim],
                         &lbf[spos+10*qdim]);
        break;
      case CCDLF:
        fD3Q27VCCInamuro(rho, -uwall[0], -uwall[1], uwall[2], &force[0], &lbf[spos], &lbf[spos+14*qdim],
                         &lbf[spos+15*qdim], &lbf[spos+3*qdim], &lbf[spos+17*qdim], &lbf[spos+18*qdim],
                         &lbf[spos+20*qdim], &lbf[spos+19*qdim], &lbf[spos+22*qdim], &lbf[spos+21*qdim],
                         &lbf[spos+24*qdim], &lbf[spos+23*qdim], &lbf[spos+26*qdim], &lbf[spos+25*qdim],
                         &lbf[spos+1*qdim], &lbf[spos+2*qdim], &lbf[spos+16*qdim], &lbf[spos+4*qdim],
                         &lbf[spos+5*qdim], &lbf[spos+7*qdim], &lbf[spos+6*qdim], &lbf[spos+9*qdim],
                         &lbf[spos+8*qdim], &lbf[spos+11*qdim], &lbf[spos+10*qdim], &lbf[spos+13*qdim],
                         &lbf[spos+12*qdim]);
        break;
      case CCDRF:
        fD3Q27VCCInamuro(rho, uwall[0], -uwall[1], uwall[2], &force[0], &lbf[spos], &lbf[spos+1*qdim],
                         &lbf[spos+15*qdim], &lbf[spos+3*qdim], &lbf[spos+5*qdim], &lbf[spos+4*qdim],
                         &lbf[spos+6*qdim], &lbf[spos+7*qdim], &lbf[spos+22*qdim], &lbf[spos+21*qdim],
                         &lbf[spos+12*qdim], &lbf[spos+13*qdim], &lbf[spos+10*qdim], &lbf[spos+11*qdim],
                         &lbf[spos+14*qdim], &lbf[spos+2*qdim], &lbf[spos+16*qdim], &lbf[spos+18*qdim],
                         &lbf[spos+17*qdim], &lbf[spos+19*qdim], &lbf[spos+20*qdim], &lbf[spos+9*qdim],
                         &lbf[spos+8*qdim], &lbf[spos+25*qdim], &lbf[spos+26*qdim], &lbf[spos+23*qdim],
                         &lbf[spos+24*qdim]);
        break;
      case CETR:
        fD3Q27VCEInamuro(rho, uwall[0], uwall[1], uwall[2], &force[0], &lbf[spos], &lbf[spos+1*qdim],
                         &lbf[spos+2*qdim], &lbf[spos+3*qdim], &lbf[spos+4*qdim], &lbf[spos+5*qdim],
                         &lbf[spos+6*qdim], &lbf[spos+7*qdim], &lbf[spos+8*qdim], &lbf[spos+9*qdim],
                         &lbf[spos+10*qdim], &lbf[spos+11*qdim], &lbf[spos+12*qdim], &lbf[spos+13*qdim],
                         &lbf[spos+14*qdim], &lbf[spos+15*qdim], &lbf[spos+16*qdim], &lbf[spos+17*qdim],
                         &lbf[spos+18*qdim], &lbf[spos+19*qdim], &lbf[spos+20*qdim], &lbf[spos+21*qdim],
                         &lbf[spos+22*qdim], &lbf[spos+23*qdim], &lbf[spos+24*qdim], &lbf[spos+25*qdim],
                         &lbf[spos+26*qdim]);
        break;
      case CETL:
        fD3Q27VCEInamuro(rho, uwall[1], -uwall[0], uwall[2], &force[0], &lbf[spos], &lbf[spos+2*qdim],
                         &lbf[spos+14*qdim], &lbf[spos+3*qdim], &lbf[spos+18*qdim], &lbf[spos+4*qdim],
                         &lbf[spos+8*qdim], &lbf[spos+9*qdim], &lbf[spos+20*qdim], &lbf[spos+19*qdim],
                         &lbf[spos+26*qdim], &lbf[spos+25*qdim], &lbf[spos+10*qdim], &lbf[spos+11*qdim],
                         &lbf[spos+15*qdim], &lbf[spos+1*qdim], &lbf[spos+16*qdim], &lbf[spos+5*qdim],
                         &lbf[spos+17*qdim], &lbf[spos+21*qdim], &lbf[spos+22*qdim], &lbf[spos+7*qdim],
                         &lbf[spos+6*qdim], &lbf[spos+13*qdim], &lbf[spos+12*qdim], &lbf[spos+23*qdim],
                         &lbf[spos+24*qdim]);
        break;
      case CEDL:
        fD3Q27VCEInamuro(rho, -uwall[0], -uwall[1], uwall[2], &force[0], &lbf[spos], &lbf[spos+14*qdim],
                         &lbf[spos+15*qdim], &lbf[spos+3*qdim], &lbf[spos+17*qdim], &lbf[spos+18*qdim],
                         &lbf[spos+20*qdim], &lbf[spos+19*qdim], &lbf[spos+22*qdim], &lbf[spos+21*qdim],
                         &lbf[spos+24*qdim], &lbf[spos+23*qdim], &lbf[spos+26*qdim], &lbf[spos+25*qdim],
                         &lbf[spos+1*qdim], &lbf[spos+2*qdim], &lbf[spos+16*qdim], &lbf[spos+4*qdim],
                         &lbf[spos+5*qdim], &lbf[spos+7*qdim], &lbf[spos+6*qdim], &lbf[spos+9*qdim],
                         &lbf[spos+8*qdim], &lbf[spos+11*qdim], &lbf[spos+10*qdim], &lbf[spos+13*qdim],
                         &lbf[spos+12*qdim]);
        break;
      case CEDR:
        fD3Q27VCEInamuro(rho, -uwall[1], uwall[0], uwall[2], &force[0], &lbf[spos], &lbf[spos+15*qdim],
                         &lbf[spos+1*qdim], &lbf[spos+3*qdim], &lbf[spos+5*qdim], &lbf[spos+17*qdim],
                         &lbf[spos+22*qdim], &lbf[spos+21*qdim], &lbf[spos+6*qdim], &lbf[spos+7*qdim],
                         &lbf[spos+12*qdim], &lbf[spos+13*qdim], &lbf[spos+24*qdim], &lbf[spos+23*qdim],
                         &lbf[spos+2*qdim], &lbf[spos+14*qdim], &lbf[spos+16*qdim], &lbf[spos+18*qdim],
                         &lbf[spos+4*qdim], &lbf[spos+9*qdim], &lbf[spos+8*qdim], &lbf[spos+19*qdim],
                         &lbf[spos+20*qdim], &lbf[spos+25*qdim], &lbf[spos+26*qdim], &lbf[spos+11*qdim],
                         &lbf[spos+10*qdim]);
        break;
      case CETF:
        fD3Q27VCEInamuro(rho, uwall[1], uwall[2], uwall[0], &force[0], &lbf[spos], &lbf[spos+2*qdim],
                         &lbf[spos+3*qdim], &lbf[spos+1*qdim], &lbf[spos+8*qdim], &lbf[spos+9*qdim],
                         &lbf[spos+4*qdim], &lbf[spos+18*qdim], &lbf[spos+6*qdim], &lbf[spos+20*qdim],
                         &lbf[spos+10*qdim], &lbf[spos+26*qdim], &lbf[spos+11*qdim], &lbf[spos+25*qdim],
                         &lbf[spos+15*qdim], &lbf[spos+16*qdim], &lbf[spos+14*qdim], &lbf[spos+21*qdim],
                         &lbf[spos+22*qdim], &lbf[spos+17*qdim], &lbf[spos+5*qdim], &lbf[spos+19*qdim],
                         &lbf[spos+7*qdim], &lbf[spos+23*qdim], &lbf[spos+13*qdim], &lbf[spos+24*qdim],
                         &lbf[spos+12*qdim]);
        break;
      case CELF:
        fD3Q27VCEInamuro(rho, -uwall[0], uwall[1], uwall[2], &force[0], &lbf[spos], &lbf[spos+14*qdim],
                         &lbf[spos+3*qdim], &lbf[spos+2*qdim], &lbf[spos+20*qdim], &lbf[spos+19*qdim],
                         &lbf[spos+18*qdim], &lbf[spos+17*qdim], &lbf[spos+8*qdim], &lbf[spos+22*qdim],
                         &lbf[spos+26*qdim], &lbf[spos+24*qdim], &lbf[spos+25*qdim], &lbf[spos+23*qdim],
                         &lbf[spos+1*qdim], &lbf[spos+16*qdim], &lbf[spos+15*qdim], &lbf[spos+7*qdim],
                         &lbf[spos+6*qdim], &lbf[spos+5*qdim], &lbf[spos+4*qdim], &lbf[spos+21*qdim],
                         &lbf[spos+9*qdim], &lbf[spos+13*qdim], &lbf[spos+11*qdim], &lbf[spos+12*qdim],
                         &lbf[spos+10*qdim]);
        break;
      case CEDF:
        fD3Q27VCEInamuro(rho, -uwall[1], uwall[2], uwall[0], &force[0], &lbf[spos], &lbf[spos+15*qdim],
                         &lbf[spos+3*qdim], &lbf[spos+1*qdim], &lbf[spos+22*qdim], &lbf[spos+21*qdim],
                         &lbf[spos+5*qdim], &lbf[spos+17*qdim], &lbf[spos+6*qdim], &lbf[spos+20*qdim],
                         &lbf[spos+12*qdim], &lbf[spos+24*qdim], &lbf[spos+13*qdim], &lbf[spos+23*qdim],
                         &lbf[spos+2*qdim], &lbf[spos+16*qdim], &lbf[spos+14*qdim], &lbf[spos+9*qdim],
                         &lbf[spos+8*qdim], &lbf[spos+18*qdim], &lbf[spos+4*qdim], &lbf[spos+19*qdim],
                         &lbf[spos+7*qdim], &lbf[spos+25*qdim], &lbf[spos+11*qdim], &lbf[spos+26*qdim],
                         &lbf[spos+10*qdim]);
        break;
      case CERF:
        fD3Q27VCEInamuro(rho, uwall[0], uwall[2], uwall[2], &force[0], &lbf[spos], &lbf[spos+1*qdim],
                         &lbf[spos+3*qdim], &lbf[spos+2*qdim], &lbf[spos+6*qdim], &lbf[spos+7*qdim],
                         &lbf[spos+4*qdim], &lbf[spos+5*qdim], &lbf[spos+8*qdim], &lbf[spos+22*qdim],
                         &lbf[spos+10*qdim], &lbf[spos+12*qdim], &lbf[spos+11*qdim], &lbf[spos+13*qdim],
                         &lbf[spos+14*qdim], &lbf[spos+16*qdim], &lbf[spos+15*qdim], &lbf[spos+19*qdim],
                         &lbf[spos+20*qdim], &lbf[spos+17*qdim], &lbf[spos+18*qdim], &lbf[spos+21*qdim],
                         &lbf[spos+9*qdim], &lbf[spos+23*qdim], &lbf[spos+25*qdim], &lbf[spos+24*qdim],
                         &lbf[spos+26*qdim]);
        break;
      case CETB:
        fD3Q27VCEInamuro(rho, uwall[1], -uwall[2], uwall[0], &force[0], &lbf[spos], &lbf[spos+2*qdim],
                         &lbf[spos+16*qdim], &lbf[spos+1*qdim], &lbf[spos+9*qdim], &lbf[spos+8*qdim],
                         &lbf[spos+4*qdim], &lbf[spos+18*qdim], &lbf[spos+7*qdim], &lbf[spos+19*qdim],
                         &lbf[spos+11*qdim], &lbf[spos+25*qdim], &lbf[spos+10*qdim], &lbf[spos+26*qdim],
                         &lbf[spos+15*qdim], &lbf[spos+3*qdim], &lbf[spos+14*qdim], &lbf[spos+22*qdim],
                         &lbf[spos+21*qdim], &lbf[spos+17*qdim], &lbf[spos+5*qdim], &lbf[spos+20*qdim],
                         &lbf[spos+6*qdim], &lbf[spos+24*qdim], &lbf[spos+12*qdim], &lbf[spos+23*qdim],
                         &lbf[spos+13*qdim]);
        break;
      case CELB:
        fD3Q27VCEInamuro(rho, -uwall[0], -uwall[2], uwall[1], &force[0], &lbf[spos], &lbf[spos+14*qdim],
                         &lbf[spos+16*qdim], &lbf[spos+2*qdim], &lbf[spos+19*qdim], &lbf[spos+20*qdim],
                         &lbf[spos+18*qdim], &lbf[spos+17*qdim], &lbf[spos+9*qdim], &lbf[spos+21*qdim],
                         &lbf[spos+25*qdim], &lbf[spos+23*qdim], &lbf[spos+26*qdim], &lbf[spos+24*qdim],
                         &lbf[spos+1*qdim], &lbf[spos+3*qdim], &lbf[spos+15*qdim], &lbf[spos+6*qdim],
                         &lbf[spos+7*qdim], &lbf[spos+5*qdim], &lbf[spos+4*qdim], &lbf[spos+22*qdim],
                         &lbf[spos+8*qdim], &lbf[spos+12*qdim], &lbf[spos+10*qdim], &lbf[spos+13*qdim],
                         &lbf[spos+11*qdim]);
        break;
      case CEDB:
        fD3Q27VCEInamuro(rho, -uwall[1], -uwall[2], uwall[0], &force[0], &lbf[spos], &lbf[spos+15*qdim],
                         &lbf[spos+16*qdim], &lbf[spos+1*qdim], &lbf[spos+21*qdim], &lbf[spos+22*qdim],
                         &lbf[spos+5*qdim], &lbf[spos+17*qdim], &lbf[spos+7*qdim], &lbf[spos+19*qdim],
                         &lbf[spos+13*qdim], &lbf[spos+23*qdim], &lbf[spos+12*qdim], &lbf[spos+24*qdim],
                         &lbf[spos+2*qdim], &lbf[spos+3*qdim], &lbf[spos+14*qdim], &lbf[spos+8*qdim],
                         &lbf[spos+9*qdim], &lbf[spos+18*qdim], &lbf[spos+4*qdim], &lbf[spos+20*qdim],
                         &lbf[spos+6*qdim], &lbf[spos+26*qdim], &lbf[spos+10*qdim], &lbf[spos+25*qdim],
                         &lbf[spos+11*qdim]);
        break;
      case CERB:
        fD3Q27VCEInamuro(rho, uwall[0], -uwall[2], uwall[1], &force[0], &lbf[spos], &lbf[spos+1*qdim],
                         &lbf[spos+16*qdim], &lbf[spos+2*qdim], &lbf[spos+7*qdim], &lbf[spos+6*qdim],
                         &lbf[spos+4*qdim], &lbf[spos+5*qdim], &lbf[spos+9*qdim], &lbf[spos+21*qdim],
                         &lbf[spos+11*qdim], &lbf[spos+13*qdim], &lbf[spos+10*qdim], &lbf[spos+12*qdim],
                         &lbf[spos+14*qdim], &lbf[spos+3*qdim], &lbf[spos+15*qdim], &lbf[spos+20*qdim],
                         &lbf[spos+19*qdim], &lbf[spos+17*qdim], &lbf[spos+18*qdim], &lbf[spos+22*qdim],
                         &lbf[spos+8*qdim], &lbf[spos+24*qdim], &lbf[spos+26*qdim], &lbf[spos+23*qdim],
                         &lbf[spos+25*qdim]);
        break;
    }
  }

  return 0;
  
}

int fD3Q27PPSInamuro(double *p, double *force, double *f0, double *f1,
                     double *f2, double *f3, double *f4, double *f5,
                     double *f6, double *f7, double *f8, double *f9,
                     double *f10, double *f11, double *f12, double *f13,
                     double *f14, double *f15, double *f16, double *f17,
                     double *f18, double *f19, double *f20, double *f21,
                     double *f22, double *f23, double *f24, double *f25,
                     double *f26, double &vel)
{

  // produce fixed pressure/density at planar surface: expressed for bottom wall (PPST)

  double rho0, rhop, v, v1, v0t, v2t, mass=0.0;
  double c1=2.0/27.0,c2=1.0/54.0,c3=1.0/216.0;
  vel = 0.0;

  if(!incompress) {
    for(int i=0; i<lbsy.nf; i++) {
      v = p[i]-(f0[i]+f1[i]+f3[i]+f6[i]+f7[i]+f14[i]+f16[i]+f19[i]+f20[i]+2.0*(f2[i]+f4[i]+f8[i]+f9[i]+f10[i]+f11[i]+f18[i]+f25[i]+f26[i])+0.5*force[3*i+1]);
      vel += v;
      mass += p[i];
    }
    v1 = vel*fReciprocal(mass);
    for(int i=0; i<lbsy.nf; i++) {
      v = p[i]-(f0[i]+f1[i]+f3[i]+f6[i]+f7[i]+f14[i]+f16[i]+f19[i]+f20[i]+2.0*(f2[i]+f4[i]+f8[i]+f9[i]+f10[i]+f11[i]+f18[i]+f25[i]+f26[i]));
      rhop=6.0*(v+f2[i]+f4[i]+f8[i]+f9[i]+f10[i]+f11[i]+f18[i]+f25[i]+f26[i])/(1.0+3.0*v1*(1.0+v1));
      v0t = 6.0*(f1[i]+f4[i]+f6[i]+f7[i]+f10[i]+f11[i]-f14[i]-f18[i]-f19[i]-f20[i]-f25[i]-f26[i]-0.5*force[3*i  ])/(rhop*(1.0+3.0*v1));
      v2t = 6.0*(f3[i]+f6[i]-f7[i]+f8[i]-f9[i]+f10[i]-f11[i]-f16[i]-f19[i]+f20[i]-f25[i]+f26[i]-0.5*force[3*i+2])/(rhop*(1.0+3.0*v1));
      f5[i]=c2*rhop*(1.0+3.0*(v0t*(v0t-1.0)+v1*(v1+1.0))-9.0*v0t*v1-1.5*v2t*v2t);
      f12[i]=c3*rhop*(1.0+3.0*(v0t*(v0t-1.0)+v1*(v1+1.0)+v2t*(v2t-1.0))-9.0*(v0t*v1-v0t*v2t+v1*v2t));
      f13[i]=c3*rhop*(1.0+3.0*(v0t*(v0t-1.0)+v1*(v1+1.0)+v2t*(v2t+1.0))-9.0*(v0t*v1+v0t*v2t-v1*v2t));
      f15[i]=c1*rhop*(1.0+3.0*v1*(v1+1)-1.5*(v0t*v0t+v2t*v2t));
      f17[i]=c2*rhop*(1.0+3.0*(v0t*(v0t+1.0)+v1*(v1+1.0))+9.0*v0t*v1-1.5*v2t*v2t);
      f21[i]=c2*rhop*(1.0+3.0*(v1*(v1+1.0)+v2t*(v2t+1.0))+9.0*v1*v2t-1.5*v0t*v0t);
      f22[i]=c2*rhop*(1.0+3.0*(v1*(v1+1.0)+v2t*(v2t-1.0))-9.0*v1*v2t-1.5*v0t*v0t);
      f23[i]=c3*rhop*(1.0+3.0*(v0t*(v0t+1.0)+v1*(v1+1.0)+v2t*(v2t+1.0))+9.0*(v0t*v1+v0t*v2t+v1*v2t));
      f24[i]=c3*rhop*(1.0+3.0*(v0t*(v0t+1.0)+v1*(v1+1.0)+v2t*(v2t-1.0))+9.0*(v0t*v1-v0t*v2t-v1*v2t));
    }
  }
  else {
    for(int i=0; i<lbsy.nf; i++) {
      v = p[i]-(f0[i]+f1[i]+f3[i]+f6[i]+f7[i]+f14[i]+f16[i]+f19[i]+f20[i]+2.0*(f2[i]+f4[i]+f8[i]+f9[i]+f10[i]+f11[i]+f18[i]+f25[i]+f26[i]))+0.5*force[3*i+1];
      vel += v;
      mass += lbincp[i];
    }
    v1 = vel*fReciprocal(mass);
    for(int i=0; i<lbsy.nf; i++) {
      rho0 = lbincp[i];
      rhop = 6.0*(f2[i]+f4[i]+f8[i]+f9[i]+f10[i]+f11[i]+f18[i]+f25[i]+f26[i])+3.0*rho0*v1*(1.0-v1)-3.0*force[3*i+1];
      v0t = 6.0*(f1[i]+f4[i]+f6[i]+f7[i]+f10[i]+f11[i]-f14[i]-f18[i]-f19[i]-f20[i]-f25[i]-f26[i]-0.5*force[3*i  ])/(rho0*(1.0+3.0*v1));
      v2t = 6.0*(f3[i]+f6[i]-f7[i]+f8[i]-f9[i]+f10[i]-f11[i]-f16[i]-f19[i]+f20[i]-f25[i]+f26[i]-0.5*force[3*i+2])/(rho0*(1.0+3.0*v1));
      f5[i]=c2*(rhop+rho0*(3.0*(v0t*(v0t-1.0)+v1*(v1+1.0))-9.0*v0t*v1-1.5*v2t*v2t));
      f12[i]=c3*(rhop+rho0*(3.0*(v0t*(v0t-1.0)+v1*(v1+1.0)+v2t*(v2t-1.0))-9.0*(v0t*v1-v0t*v2t+v1*v2t)));
      f13[i]=c3*(rhop+rho0*(3.0*(v0t*(v0t-1.0)+v1*(v1+1.0)+v2t*(v2t+1.0))-9.0*(v0t*v1+v0t*v2t-v1*v2t)));
      f15[i]=c1*(rhop+rho0*(3.0*v1*(v1+1)-1.5*(v0t*v0t+v2t*v2t)));
      f17[i]=c2*(rhop+rho0*(3.0*(v0t*(v0t+1.0)+v1*(v1+1.0))+9.0*v0t*v1-1.5*v2t*v2t));
      f21[i]=c2*(rhop+rho0*(3.0*(v1*(v1+1.0)+v2t*(v2t+1.0))+9.0*v1*v2t-1.5*v0t*v0t));
      f22[i]=c2*(rhop+rho0*(3.0*(v1*(v1+1.0)+v2t*(v2t-1.0))-9.0*v1*v2t-1.5*v0t*v0t));
      f23[i]=c3*(rhop+rho0*(3.0*(v0t*(v0t+1.0)+v1*(v1+1.0)+v2t*(v2t+1.0))+9.0*(v0t*v1+v0t*v2t+v1*v2t)));
      f24[i]=c3*(rhop+rho0*(3.0*(v0t*(v0t+1.0)+v1*(v1+1.0)+v2t*(v2t-1.0))+9.0*(v0t*v1-v0t*v2t-v1*v2t)));
    }
  }
  vel *= fReciprocal(mass);
  return 0;
}


int fD3Q27PPSCLBEInamuro(double *p, double *force, double *f0, double *f1,
                         double *f2, double *f3, double *f4, double *f5,
                         double *f6, double *f7, double *f8, double *f9,
                         double *f10, double *f11, double *f12, double *f13,
                         double *f14, double *f15, double *f16, double *f17,
                         double *f18, double *f19, double *f20, double *f21,
                         double *f22, double *f23, double *f24, double *f25,
                         double *f26, double &vel)
{

  // produce fixed pressure/density at planar surface: expressed for bottom wall (PPST)
  // using higher-order equilibrium distribution functions for CLBE collisions

  double rhop, v, v1, v0t, v2t, mass=0.0;
  double c1=2.0/27.0,c2=1.0/54.0,c3=1.0/216.0;
  vel = 0.0;

  for(int i=0; i<lbsy.nf; i++) {
    v = p[i]-(f0[i]+f1[i]+f3[i]+f6[i]+f7[i]+f14[i]+f16[i]+f19[i]+f20[i]+2.0*(f2[i]+f4[i]+f8[i]+f9[i]+f10[i]+f11[i]+f18[i]+f25[i]+f26[i]))+0.5*force[3*i+1];
    vel += v;
    mass += p[i];
  }
  v1 = vel*fReciprocal(mass);
  for(int i=0; i<lbsy.nf; i++) {
    v = p[i]-(f0[i]+f1[i]+f3[i]+f6[i]+f7[i]+f14[i]+f16[i]+f19[i]+f20[i]+2.0*(f2[i]+f4[i]+f8[i]+f9[i]+f10[i]+f11[i]+f18[i]+f25[i]+f26[i]));
    rhop=6.0*(v+f2[i]+f4[i]+f8[i]+f9[i]+f10[i]+f11[i]+f18[i]+f25[i]+f26[i])/(1.0+3.0*v1*(1.0+v1));
    v0t=6.0*(f1[i]+f4[i]+f6[i]+f7[i]+f10[i]+f11[i]-f14[i]-f18[i]-f19[i]-f20[i]-f25[i]-f26[i]-0.5*force[3*i  ])/(rhop*(1.0+3.0*v1*(1.0+v1))); // v0t = v0 + v0s
    v2t=6.0*(f3[i]+f6[i]-f7[i]+f8[i]-f9[i]+f10[i]-f11[i]-f16[i]-f19[i]+f20[i]-f25[i]+f26[i]-0.5*force[3*i+2])/(rhop*(1.0+3.0*v1*(1.0+v1))); // v2t = v2 + v2ss
    f5[i]=c2*rhop*(1.0+3.0*(v0t*(v0t-1.0)+v1*(v1+1.0))-9.0*v0t*v1*(1.0-v0t)*(1.0+v1))*(1.0-1.5*v2t*v2t);
    f12[i]=c3*rhop*(1.0*3.0*(v0t*(v0t-1.0)+v1*(v1+1.0)+v2t*(v2t-1.0))-9.0*(v0t*v1*(1.0-v0t)*(1.0+v1)-v0t*v2t*(1.0-v0t)*(1.0-v2t)+v1*v2t*(1.0+v1)*(1.0-v2t)-3.0*v0t*v1*v2t*(1.0-v0t)*(1.0+v1)*(1.0-v2t)));
    f13[i]=c3*rhop*(1.0*3.0*(v0t*(v0t-1.0)+v1*(v1+1.0)+v2t*(v2t+1.0))-9.0*(v0t*v1*(1.0-v0t)*(1.0+v1)+v0t*v2t*(1.0-v0t)*(1.0+v2t)-v1*v2t*(1.0+v1)*(1.0+v2t)+3.0*v0t*v1*v2t*(1.0-v0t)*(1.0+v1)*(1.0+v2t)));
    f15[i]=c1*rhop*(1.0+3.0*v1*(v1+1.0))*(1.0-1.5*v0t*v0t)*(1.0-1.5*v2t*v2t);
    f17[i]=c2*rhop*(1.0+3.0*(v0t*(v0t+1.0)+v1*(v1+1.0))+9.0*v0t*v1*(1.0+v0t)*(1.0+v1))*(1.0-1.5*v2t*v2t);
    f21[i]=c2*rhop*(1.0+3.0*(v1*(v1+1.0)+v2t*(v2t+1.0))+9.0*v1*v2t*(1.0+v1)*(1.0+v2t))*(1.0-1.5*v0t*v0t);
    f22[i]=c2*rhop*(1.0+3.0*(v1*(v1+1.0)+v2t*(v2t-1.0))-9.0*v1*v2t*(1.0+v1)*(1.0-v2t))*(1.0-1.5*v0t*v0t);
    f23[i]=c3*rhop*(1.0*3.0*(v0t*(v0t+1.0)+v1*(v1+1.0)+v2t*(v2t+1.0))+9.0*(v0t*v1*(1.0+v0t)*(1.0+v1)+v0t*v2t*(1.0+v0t)*(1.0+v2t)+v1*v2t*(1.0+v1)*(1.0+v2t)+3.0*v0t*v1*v2t*(1.0+v0t)*(1.0+v1)*(1.0+v2t)));
    f24[i]=c3*rhop*(1.0*3.0*(v0t*(v0t+1.0)+v1*(v1+1.0)+v2t*(v2t-1.0))+9.0*(v0t*v1*(1.0+v0t)*(1.0+v1)-v0t*v2t*(1.0+v0t)*(1.0-v2t)-v1*v2t*(1.0+v1)*(1.0-v2t)-3.0*v0t*v1*v2t*(1.0+v0t)*(1.0+v1)*(1.0-v2t)));
  }
  vel *= fReciprocal(mass);
  return 0;
}

int fD3Q27PFInamuro(long tpos, int prop, double *p0, double *uwall)
{
  double moment;
  long spos=tpos * lbsitelength;
  int qdim=lbsy.nf+lbsy.nc+lbsy.nt;
  double force[3*lbsy.nf];

  fD3Q27BoundaryForceDensity(force, tpos, p0, prop);
    
  if (collide>11) {
    switch (prop) {
      case PST:
        fD3Q27PPSCLBEInamuro(p0, &force[0], &lbf[spos], &lbf[spos+1*qdim],
                             &lbf[spos+2*qdim], &lbf[spos+3*qdim], &lbf[spos+4*qdim], &lbf[spos+5*qdim],
                             &lbf[spos+6*qdim], &lbf[spos+7*qdim], &lbf[spos+8*qdim], &lbf[spos+9*qdim],
                             &lbf[spos+10*qdim], &lbf[spos+11*qdim], &lbf[spos+12*qdim], &lbf[spos+13*qdim],
                             &lbf[spos+14*qdim], &lbf[spos+15*qdim], &lbf[spos+16*qdim], &lbf[spos+17*qdim],
                             &lbf[spos+18*qdim], &lbf[spos+19*qdim], &lbf[spos+20*qdim], &lbf[spos+21*qdim],
                             &lbf[spos+22*qdim], &lbf[spos+23*qdim], &lbf[spos+24*qdim], &lbf[spos+25*qdim],
                             &lbf[spos+26*qdim], moment);
        uwall[1] += moment;
        break;
      case PSD:
        fD3Q27PPSCLBEInamuro(p0, &force[0], &lbf[spos], &lbf[spos+14*qdim],
                             &lbf[spos+15*qdim], &lbf[spos+16*qdim], &lbf[spos+17*qdim], &lbf[spos+18*qdim],
                             &lbf[spos+19*qdim], &lbf[spos+20*qdim], &lbf[spos+21*qdim], &lbf[spos+22*qdim],
                             &lbf[spos+23*qdim], &lbf[spos+24*qdim], &lbf[spos+25*qdim], &lbf[spos+26*qdim],
                             &lbf[spos+1*qdim], &lbf[spos+2*qdim], &lbf[spos+3*qdim], &lbf[spos+4*qdim],
                             &lbf[spos+5*qdim], &lbf[spos+6*qdim], &lbf[spos+7*qdim], &lbf[spos+8*qdim],
                             &lbf[spos+9*qdim], &lbf[spos+10*qdim], &lbf[spos+11*qdim], &lbf[spos+12*qdim],
                             &lbf[spos+13*qdim], moment);
        uwall[1] -= moment;
        break;
      case PSL:
        fD3Q27PPSCLBEInamuro(p0, &force[0], &lbf[spos], &lbf[spos+16*qdim],
                             &lbf[spos+14*qdim], &lbf[spos+15*qdim], &lbf[spos+19*qdim], &lbf[spos+7*qdim],
                             &lbf[spos+21*qdim], &lbf[spos+9*qdim], &lbf[spos+17*qdim], &lbf[spos+18*qdim],
                             &lbf[spos+23*qdim], &lbf[spos+25*qdim], &lbf[spos+13*qdim], &lbf[spos+11*qdim],
                             &lbf[spos+3*qdim], &lbf[spos+1*qdim], &lbf[spos+2*qdim], &lbf[spos+6*qdim],
                             &lbf[spos+20*qdim], &lbf[spos+8*qdim], &lbf[spos+22*qdim], &lbf[spos+4*qdim],
                             &lbf[spos+5*qdim], &lbf[spos+10*qdim], &lbf[spos+12*qdim], &lbf[spos+26*qdim],
                             &lbf[spos+24*qdim], moment);
        uwall[0] -= moment;
        break;
      case PSR:
        fD3Q27PPSCLBEInamuro(p0, &force[0], &lbf[spos], &lbf[spos+3*qdim],
                             &lbf[spos+1*qdim], &lbf[spos+2*qdim], &lbf[spos+6*qdim], &lbf[spos+20*qdim],
                             &lbf[spos+8*qdim], &lbf[spos+22*qdim], &lbf[spos+4*qdim], &lbf[spos+5*qdim],
                             &lbf[spos+10*qdim], &lbf[spos+12*qdim], &lbf[spos+26*qdim], &lbf[spos+24*qdim],
                             &lbf[spos+16*qdim], &lbf[spos+14*qdim], &lbf[spos+15*qdim], &lbf[spos+19*qdim],
                             &lbf[spos+7*qdim], &lbf[spos+21*qdim], &lbf[spos+9*qdim], &lbf[spos+17*qdim],
                             &lbf[spos+18*qdim], &lbf[spos+23*qdim], &lbf[spos+25*qdim], &lbf[spos+13*qdim],
                             &lbf[spos+11*qdim], moment);
        uwall[0] += moment;
        break;
      case PSF:
        fD3Q27PPSCLBEInamuro(p0, &force[0], &lbf[spos], &lbf[spos+15*qdim],
                             &lbf[spos+16*qdim], &lbf[spos+14*qdim], &lbf[spos+21*qdim], &lbf[spos+22*qdim],
                             &lbf[spos+17*qdim], &lbf[spos+5*qdim], &lbf[spos+19*qdim], &lbf[spos+7*qdim],
                             &lbf[spos+23*qdim], &lbf[spos+13*qdim], &lbf[spos+24*qdim], &lbf[spos+12*qdim],
                             &lbf[spos+2*qdim], &lbf[spos+3*qdim], &lbf[spos+1*qdim], &lbf[spos+8*qdim],
                             &lbf[spos+9*qdim], &lbf[spos+4*qdim], &lbf[spos+18*qdim], &lbf[spos+6*qdim],
                             &lbf[spos+20*qdim], &lbf[spos+10*qdim], &lbf[spos+26*qdim], &lbf[spos+11*qdim],
                             &lbf[spos+25*qdim], moment);
        uwall[2] -= moment;
        break;
      case PSB:
        fD3Q27PPSCLBEInamuro(p0, &force[0], &lbf[spos], &lbf[spos+2*qdim],
                             &lbf[spos+3*qdim], &lbf[spos+1*qdim], &lbf[spos+8*qdim], &lbf[spos+9*qdim],
                             &lbf[spos+4*qdim], &lbf[spos+18*qdim], &lbf[spos+6*qdim], &lbf[spos+20*qdim],
                             &lbf[spos+10*qdim], &lbf[spos+26*qdim], &lbf[spos+11*qdim], &lbf[spos+25*qdim],
                             &lbf[spos+15*qdim], &lbf[spos+16*qdim], &lbf[spos+14*qdim], &lbf[spos+21*qdim],
                             &lbf[spos+22*qdim], &lbf[spos+17*qdim], &lbf[spos+5*qdim], &lbf[spos+19*qdim],
                             &lbf[spos+7*qdim], &lbf[spos+23*qdim], &lbf[spos+13*qdim], &lbf[spos+24*qdim],
                             &lbf[spos+12*qdim], moment);
        uwall[2] += moment;
        break;
      case CCTRB:
        fD3Q27VCCCLBEInamuro(p0, uwall[0], uwall[1], -uwall[2], &force[0], &lbf[spos], &lbf[spos+1*qdim],
                             &lbf[spos+2*qdim], &lbf[spos+16*qdim], &lbf[spos+4*qdim], &lbf[spos+5*qdim],
                             &lbf[spos+7*qdim], &lbf[spos+6*qdim], &lbf[spos+9*qdim], &lbf[spos+8*qdim],
                             &lbf[spos+11*qdim], &lbf[spos+10*qdim], &lbf[spos+13*qdim], &lbf[spos+12*qdim],
                             &lbf[spos+14*qdim], &lbf[spos+15*qdim], &lbf[spos+3*qdim], &lbf[spos+17*qdim],
                             &lbf[spos+18*qdim], &lbf[spos+20*qdim], &lbf[spos+19*qdim], &lbf[spos+22*qdim],
                             &lbf[spos+21*qdim], &lbf[spos+24*qdim], &lbf[spos+23*qdim], &lbf[spos+26*qdim],
                             &lbf[spos+25*qdim]);
        break;
      case CCTLB:
        fD3Q27VCCCLBEInamuro(p0, -uwall[0], uwall[1], -uwall[2], &force[0], &lbf[spos], &lbf[spos+14*qdim],
                             &lbf[spos+2*qdim], &lbf[spos+16*qdim], &lbf[spos+18*qdim], &lbf[spos+17*qdim],
                             &lbf[spos+19*qdim], &lbf[spos+20*qdim], &lbf[spos+9*qdim], &lbf[spos+8*qdim],
                             &lbf[spos+25*qdim], &lbf[spos+26*qdim], &lbf[spos+23*qdim], &lbf[spos+24*qdim],
                             &lbf[spos+1*qdim], &lbf[spos+15*qdim], &lbf[spos+3*qdim], &lbf[spos+5*qdim],
                             &lbf[spos+4*qdim], &lbf[spos+6*qdim], &lbf[spos+7*qdim], &lbf[spos+22*qdim],
                             &lbf[spos+21*qdim], &lbf[spos+12*qdim], &lbf[spos+13*qdim], &lbf[spos+10*qdim],
                             &lbf[spos+11*qdim]);
        break;
      case CCDLB:
        fD3Q27VCCCLBEInamuro(p0, -uwall[0], -uwall[1], -uwall[2], &force[0], &lbf[spos], &lbf[spos+14*qdim],
                             &lbf[spos+15*qdim], &lbf[spos+16*qdim], &lbf[spos+17*qdim], &lbf[spos+18*qdim],
                             &lbf[spos+19*qdim], &lbf[spos+20*qdim], &lbf[spos+21*qdim], &lbf[spos+22*qdim],
                             &lbf[spos+23*qdim], &lbf[spos+24*qdim], &lbf[spos+25*qdim], &lbf[spos+26*qdim],
                             &lbf[spos+1*qdim], &lbf[spos+2*qdim], &lbf[spos+3*qdim], &lbf[spos+4*qdim],
                             &lbf[spos+5*qdim], &lbf[spos+6*qdim], &lbf[spos+7*qdim], &lbf[spos+8*qdim],
                             &lbf[spos+9*qdim], &lbf[spos+10*qdim], &lbf[spos+11*qdim], &lbf[spos+12*qdim],
                             &lbf[spos+13*qdim]);
        break;
      case CCDRB:
        fD3Q27VCCCLBEInamuro(p0, uwall[0], -uwall[1], -uwall[2], &force[0], &lbf[spos], &lbf[spos+1*qdim],
                             &lbf[spos+15*qdim], &lbf[spos+16*qdim], &lbf[spos+5*qdim], &lbf[spos+4*qdim],
                             &lbf[spos+7*qdim], &lbf[spos+6*qdim], &lbf[spos+21*qdim], &lbf[spos+22*qdim],
                             &lbf[spos+13*qdim], &lbf[spos+12*qdim], &lbf[spos+11*qdim], &lbf[spos+10*qdim],
                             &lbf[spos+14*qdim], &lbf[spos+2*qdim], &lbf[spos+3*qdim], &lbf[spos+18*qdim],
                             &lbf[spos+17*qdim], &lbf[spos+20*qdim], &lbf[spos+19*qdim], &lbf[spos+8*qdim],
                             &lbf[spos+9*qdim], &lbf[spos+26*qdim], &lbf[spos+25*qdim], &lbf[spos+24*qdim],
                             &lbf[spos+23*qdim]);
        break;
      case CCTRF:
        fD3Q27VCCCLBEInamuro(p0, uwall[0], uwall[1], uwall[2], &force[0], &lbf[spos], &lbf[spos+1*qdim],
                             &lbf[spos+2*qdim], &lbf[spos+3*qdim], &lbf[spos+4*qdim], &lbf[spos+5*qdim],
                             &lbf[spos+6*qdim], &lbf[spos+7*qdim], &lbf[spos+8*qdim], &lbf[spos+9*qdim],
                             &lbf[spos+10*qdim], &lbf[spos+11*qdim], &lbf[spos+12*qdim], &lbf[spos+13*qdim],
                             &lbf[spos+14*qdim], &lbf[spos+15*qdim], &lbf[spos+16*qdim], &lbf[spos+17*qdim],
                             &lbf[spos+18*qdim], &lbf[spos+19*qdim], &lbf[spos+20*qdim], &lbf[spos+21*qdim],
                             &lbf[spos+22*qdim], &lbf[spos+23*qdim], &lbf[spos+24*qdim], &lbf[spos+25*qdim],
                             &lbf[spos+26*qdim]);
        break;
      case CCTLF:
        fD3Q27VCCCLBEInamuro(p0, -uwall[0], uwall[1], uwall[2], &force[0], &lbf[spos], &lbf[spos+14*qdim],
                             &lbf[spos+2*qdim], &lbf[spos+3*qdim], &lbf[spos+18*qdim], &lbf[spos+17*qdim],
                             &lbf[spos+20*qdim], &lbf[spos+19*qdim], &lbf[spos+8*qdim], &lbf[spos+9*qdim],
                             &lbf[spos+26*qdim], &lbf[spos+25*qdim], &lbf[spos+24*qdim], &lbf[spos+23*qdim],
                             &lbf[spos+1*qdim], &lbf[spos+15*qdim], &lbf[spos+16*qdim], &lbf[spos+5*qdim],
                             &lbf[spos+4*qdim], &lbf[spos+7*qdim], &lbf[spos+6*qdim], &lbf[spos+21*qdim],
                             &lbf[spos+22*qdim], &lbf[spos+13*qdim], &lbf[spos+12*qdim], &lbf[spos+11*qdim],
                             &lbf[spos+10*qdim]);
        break;
      case CCDLF:
        fD3Q27VCCCLBEInamuro(p0, -uwall[0], -uwall[1], uwall[2], &force[0], &lbf[spos], &lbf[spos+14*qdim],
                             &lbf[spos+15*qdim], &lbf[spos+3*qdim], &lbf[spos+17*qdim], &lbf[spos+18*qdim],
                             &lbf[spos+20*qdim], &lbf[spos+19*qdim], &lbf[spos+22*qdim], &lbf[spos+21*qdim],
                             &lbf[spos+24*qdim], &lbf[spos+23*qdim], &lbf[spos+26*qdim], &lbf[spos+25*qdim],
                             &lbf[spos+1*qdim], &lbf[spos+2*qdim], &lbf[spos+16*qdim], &lbf[spos+4*qdim],
                             &lbf[spos+5*qdim], &lbf[spos+7*qdim], &lbf[spos+6*qdim], &lbf[spos+9*qdim],
                             &lbf[spos+8*qdim], &lbf[spos+11*qdim], &lbf[spos+10*qdim], &lbf[spos+13*qdim],
                             &lbf[spos+12*qdim]);
        break;
      case CCDRF:
        fD3Q27VCCCLBEInamuro(p0, uwall[0], -uwall[1], uwall[2], &force[0], &lbf[spos], &lbf[spos+1*qdim],
                             &lbf[spos+15*qdim], &lbf[spos+3*qdim], &lbf[spos+5*qdim], &lbf[spos+4*qdim],
                             &lbf[spos+6*qdim], &lbf[spos+7*qdim], &lbf[spos+22*qdim], &lbf[spos+21*qdim],
                             &lbf[spos+12*qdim], &lbf[spos+13*qdim], &lbf[spos+10*qdim], &lbf[spos+11*qdim],
                             &lbf[spos+14*qdim], &lbf[spos+2*qdim], &lbf[spos+16*qdim], &lbf[spos+18*qdim],
                             &lbf[spos+17*qdim], &lbf[spos+19*qdim], &lbf[spos+20*qdim], &lbf[spos+9*qdim],
                             &lbf[spos+8*qdim], &lbf[spos+25*qdim], &lbf[spos+26*qdim], &lbf[spos+23*qdim],
                             &lbf[spos+24*qdim]);
        break;
      case CETR:
        fD3Q27VCECLBEInamuro(p0, uwall[0], uwall[1], uwall[2], &force[0], &lbf[spos], &lbf[spos+1*qdim],
                             &lbf[spos+2*qdim], &lbf[spos+3*qdim], &lbf[spos+4*qdim], &lbf[spos+5*qdim],
                             &lbf[spos+6*qdim], &lbf[spos+7*qdim], &lbf[spos+8*qdim], &lbf[spos+9*qdim],
                             &lbf[spos+10*qdim], &lbf[spos+11*qdim], &lbf[spos+12*qdim], &lbf[spos+13*qdim],
                             &lbf[spos+14*qdim], &lbf[spos+15*qdim], &lbf[spos+16*qdim], &lbf[spos+17*qdim],
                             &lbf[spos+18*qdim], &lbf[spos+19*qdim], &lbf[spos+20*qdim], &lbf[spos+21*qdim],
                             &lbf[spos+22*qdim], &lbf[spos+23*qdim], &lbf[spos+24*qdim], &lbf[spos+25*qdim],
                             &lbf[spos+26*qdim]);
        break;
      case CETL:
        fD3Q27VCECLBEInamuro(p0, uwall[1], -uwall[0], uwall[2], &force[0], &lbf[spos], &lbf[spos+2*qdim],
                             &lbf[spos+14*qdim], &lbf[spos+3*qdim], &lbf[spos+18*qdim], &lbf[spos+4*qdim],
                             &lbf[spos+8*qdim], &lbf[spos+9*qdim], &lbf[spos+20*qdim], &lbf[spos+19*qdim],
                             &lbf[spos+26*qdim], &lbf[spos+25*qdim], &lbf[spos+10*qdim], &lbf[spos+11*qdim],
                             &lbf[spos+15*qdim], &lbf[spos+1*qdim], &lbf[spos+16*qdim], &lbf[spos+5*qdim],
                             &lbf[spos+17*qdim], &lbf[spos+21*qdim], &lbf[spos+22*qdim], &lbf[spos+7*qdim],
                             &lbf[spos+6*qdim], &lbf[spos+13*qdim], &lbf[spos+12*qdim], &lbf[spos+23*qdim],
                             &lbf[spos+24*qdim]);
        break;
      case CEDL:
        fD3Q27VCECLBEInamuro(p0, -uwall[0], -uwall[1], uwall[2], &force[0], &lbf[spos], &lbf[spos+14*qdim],
                             &lbf[spos+15*qdim], &lbf[spos+3*qdim], &lbf[spos+17*qdim], &lbf[spos+18*qdim],
                             &lbf[spos+20*qdim], &lbf[spos+19*qdim], &lbf[spos+22*qdim], &lbf[spos+21*qdim],
                             &lbf[spos+24*qdim], &lbf[spos+23*qdim], &lbf[spos+26*qdim], &lbf[spos+25*qdim],
                             &lbf[spos+1*qdim], &lbf[spos+2*qdim], &lbf[spos+16*qdim], &lbf[spos+4*qdim],
                             &lbf[spos+5*qdim], &lbf[spos+7*qdim], &lbf[spos+6*qdim], &lbf[spos+9*qdim],
                             &lbf[spos+8*qdim], &lbf[spos+11*qdim], &lbf[spos+10*qdim], &lbf[spos+13*qdim],
                             &lbf[spos+12*qdim]);
        break;
      case CEDR:
        fD3Q27VCECLBEInamuro(p0, -uwall[1], uwall[0], uwall[2], &force[0], &lbf[spos], &lbf[spos+15*qdim],
                             &lbf[spos+1*qdim], &lbf[spos+3*qdim], &lbf[spos+5*qdim], &lbf[spos+17*qdim],
                             &lbf[spos+22*qdim], &lbf[spos+21*qdim], &lbf[spos+6*qdim], &lbf[spos+7*qdim],
                             &lbf[spos+12*qdim], &lbf[spos+13*qdim], &lbf[spos+24*qdim], &lbf[spos+23*qdim],
                             &lbf[spos+2*qdim], &lbf[spos+14*qdim], &lbf[spos+16*qdim], &lbf[spos+18*qdim],
                             &lbf[spos+4*qdim], &lbf[spos+9*qdim], &lbf[spos+8*qdim], &lbf[spos+19*qdim],
                             &lbf[spos+20*qdim], &lbf[spos+25*qdim], &lbf[spos+26*qdim], &lbf[spos+11*qdim],
                             &lbf[spos+10*qdim]);
        break;
      case CETF:
        fD3Q27VCECLBEInamuro(p0, uwall[1], uwall[2], uwall[0], &force[0], &lbf[spos], &lbf[spos+2*qdim],
                             &lbf[spos+3*qdim], &lbf[spos+1*qdim], &lbf[spos+8*qdim], &lbf[spos+9*qdim],
                             &lbf[spos+4*qdim], &lbf[spos+18*qdim], &lbf[spos+6*qdim], &lbf[spos+20*qdim],
                             &lbf[spos+10*qdim], &lbf[spos+26*qdim], &lbf[spos+11*qdim], &lbf[spos+25*qdim],
                             &lbf[spos+15*qdim], &lbf[spos+16*qdim], &lbf[spos+14*qdim], &lbf[spos+21*qdim],
                             &lbf[spos+22*qdim], &lbf[spos+17*qdim], &lbf[spos+5*qdim], &lbf[spos+19*qdim],
                             &lbf[spos+7*qdim], &lbf[spos+23*qdim], &lbf[spos+13*qdim], &lbf[spos+24*qdim],
                             &lbf[spos+12*qdim]);
        break;
      case CELF:
        fD3Q27VCECLBEInamuro(p0, -uwall[0], uwall[1], uwall[2], &force[0], &lbf[spos], &lbf[spos+14*qdim],
                             &lbf[spos+3*qdim], &lbf[spos+2*qdim], &lbf[spos+20*qdim], &lbf[spos+19*qdim],
                             &lbf[spos+18*qdim], &lbf[spos+17*qdim], &lbf[spos+8*qdim], &lbf[spos+22*qdim],
                             &lbf[spos+26*qdim], &lbf[spos+24*qdim], &lbf[spos+25*qdim], &lbf[spos+23*qdim],
                             &lbf[spos+1*qdim], &lbf[spos+16*qdim], &lbf[spos+15*qdim], &lbf[spos+7*qdim],
                             &lbf[spos+6*qdim], &lbf[spos+5*qdim], &lbf[spos+4*qdim], &lbf[spos+21*qdim],
                             &lbf[spos+9*qdim], &lbf[spos+13*qdim], &lbf[spos+11*qdim], &lbf[spos+12*qdim],
                             &lbf[spos+10*qdim]);
        break;
      case CEDF:
        fD3Q27VCECLBEInamuro(p0, -uwall[1], uwall[2], uwall[0], &force[0], &lbf[spos], &lbf[spos+15*qdim],
                             &lbf[spos+3*qdim], &lbf[spos+1*qdim], &lbf[spos+22*qdim], &lbf[spos+21*qdim],
                             &lbf[spos+5*qdim], &lbf[spos+17*qdim], &lbf[spos+6*qdim], &lbf[spos+20*qdim],
                             &lbf[spos+12*qdim], &lbf[spos+24*qdim], &lbf[spos+13*qdim], &lbf[spos+23*qdim],
                             &lbf[spos+2*qdim], &lbf[spos+16*qdim], &lbf[spos+14*qdim], &lbf[spos+9*qdim],
                             &lbf[spos+8*qdim], &lbf[spos+18*qdim], &lbf[spos+4*qdim], &lbf[spos+19*qdim],
                             &lbf[spos+7*qdim], &lbf[spos+25*qdim], &lbf[spos+11*qdim], &lbf[spos+26*qdim],
                             &lbf[spos+10*qdim]);
        break;
      case CERF:
        fD3Q27VCECLBEInamuro(p0, uwall[0], uwall[2], uwall[2], &force[0], &lbf[spos], &lbf[spos+1*qdim],
                             &lbf[spos+3*qdim], &lbf[spos+2*qdim], &lbf[spos+6*qdim], &lbf[spos+7*qdim],
                             &lbf[spos+4*qdim], &lbf[spos+5*qdim], &lbf[spos+8*qdim], &lbf[spos+22*qdim],
                             &lbf[spos+10*qdim], &lbf[spos+12*qdim], &lbf[spos+11*qdim], &lbf[spos+13*qdim],
                             &lbf[spos+14*qdim], &lbf[spos+16*qdim], &lbf[spos+15*qdim], &lbf[spos+19*qdim],
                             &lbf[spos+20*qdim], &lbf[spos+17*qdim], &lbf[spos+18*qdim], &lbf[spos+21*qdim],
                             &lbf[spos+9*qdim], &lbf[spos+23*qdim], &lbf[spos+25*qdim], &lbf[spos+24*qdim],
                             &lbf[spos+26*qdim]);
        break;
      case CETB:
        fD3Q27VCECLBEInamuro(p0, uwall[1], -uwall[2], uwall[0], &force[0], &lbf[spos], &lbf[spos+2*qdim],
                             &lbf[spos+16*qdim], &lbf[spos+1*qdim], &lbf[spos+9*qdim], &lbf[spos+8*qdim],
                             &lbf[spos+4*qdim], &lbf[spos+18*qdim], &lbf[spos+7*qdim], &lbf[spos+19*qdim],
                             &lbf[spos+11*qdim], &lbf[spos+25*qdim], &lbf[spos+10*qdim], &lbf[spos+26*qdim],
                             &lbf[spos+15*qdim], &lbf[spos+3*qdim], &lbf[spos+14*qdim], &lbf[spos+22*qdim],
                             &lbf[spos+21*qdim], &lbf[spos+17*qdim], &lbf[spos+5*qdim], &lbf[spos+20*qdim],
                             &lbf[spos+6*qdim], &lbf[spos+24*qdim], &lbf[spos+12*qdim], &lbf[spos+23*qdim],
                             &lbf[spos+13*qdim]);
        break;
      case CELB:
        fD3Q27VCECLBEInamuro(p0, -uwall[0], -uwall[2], uwall[1], &force[0], &lbf[spos], &lbf[spos+14*qdim],
                             &lbf[spos+16*qdim], &lbf[spos+2*qdim], &lbf[spos+19*qdim], &lbf[spos+20*qdim],
                             &lbf[spos+18*qdim], &lbf[spos+17*qdim], &lbf[spos+9*qdim], &lbf[spos+21*qdim],
                             &lbf[spos+25*qdim], &lbf[spos+23*qdim], &lbf[spos+26*qdim], &lbf[spos+24*qdim],
                             &lbf[spos+1*qdim], &lbf[spos+3*qdim], &lbf[spos+15*qdim], &lbf[spos+6*qdim],
                             &lbf[spos+7*qdim], &lbf[spos+5*qdim], &lbf[spos+4*qdim], &lbf[spos+22*qdim],
                             &lbf[spos+8*qdim], &lbf[spos+12*qdim], &lbf[spos+10*qdim], &lbf[spos+13*qdim],
                             &lbf[spos+11*qdim]);
        break;
      case CEDB:
        fD3Q27VCECLBEInamuro(p0, -uwall[1], -uwall[2], uwall[0], &force[0], &lbf[spos], &lbf[spos+15*qdim],
                             &lbf[spos+16*qdim], &lbf[spos+1*qdim], &lbf[spos+21*qdim], &lbf[spos+22*qdim],
                             &lbf[spos+5*qdim], &lbf[spos+17*qdim], &lbf[spos+7*qdim], &lbf[spos+19*qdim],
                             &lbf[spos+13*qdim], &lbf[spos+23*qdim], &lbf[spos+12*qdim], &lbf[spos+24*qdim],
                             &lbf[spos+2*qdim], &lbf[spos+3*qdim], &lbf[spos+14*qdim], &lbf[spos+8*qdim],
                             &lbf[spos+9*qdim], &lbf[spos+18*qdim], &lbf[spos+4*qdim], &lbf[spos+20*qdim],
                             &lbf[spos+6*qdim], &lbf[spos+26*qdim], &lbf[spos+10*qdim], &lbf[spos+25*qdim],
                             &lbf[spos+11*qdim]);
        break;
      case CERB:
        fD3Q27VCECLBEInamuro(p0, uwall[0], -uwall[2], uwall[1], &force[0], &lbf[spos], &lbf[spos+1*qdim],
                             &lbf[spos+16*qdim], &lbf[spos+2*qdim], &lbf[spos+7*qdim], &lbf[spos+6*qdim],
                             &lbf[spos+4*qdim], &lbf[spos+5*qdim], &lbf[spos+9*qdim], &lbf[spos+21*qdim],
                             &lbf[spos+11*qdim], &lbf[spos+13*qdim], &lbf[spos+10*qdim], &lbf[spos+12*qdim],
                             &lbf[spos+14*qdim], &lbf[spos+3*qdim], &lbf[spos+15*qdim], &lbf[spos+20*qdim],
                             &lbf[spos+19*qdim], &lbf[spos+17*qdim], &lbf[spos+18*qdim], &lbf[spos+22*qdim],
                             &lbf[spos+8*qdim], &lbf[spos+24*qdim], &lbf[spos+26*qdim], &lbf[spos+23*qdim],
                             &lbf[spos+25*qdim]);
        break;
    }
  }
  else {
    switch (prop) {
      case PST:
        fD3Q27PPSInamuro(p0, &force[0], &lbf[spos], &lbf[spos+1*qdim],
                         &lbf[spos+2*qdim], &lbf[spos+3*qdim], &lbf[spos+4*qdim], &lbf[spos+5*qdim],
                         &lbf[spos+6*qdim], &lbf[spos+7*qdim], &lbf[spos+8*qdim], &lbf[spos+9*qdim],
                         &lbf[spos+10*qdim], &lbf[spos+11*qdim], &lbf[spos+12*qdim], &lbf[spos+13*qdim],
                         &lbf[spos+14*qdim], &lbf[spos+15*qdim], &lbf[spos+16*qdim], &lbf[spos+17*qdim],
                         &lbf[spos+18*qdim], &lbf[spos+19*qdim], &lbf[spos+20*qdim], &lbf[spos+21*qdim],
                         &lbf[spos+22*qdim], &lbf[spos+23*qdim], &lbf[spos+24*qdim], &lbf[spos+25*qdim],
                         &lbf[spos+26*qdim], moment);
        uwall[1] += moment;
        break;
      case PSD:
        fD3Q27PPSInamuro(p0, &force[0], &lbf[spos], &lbf[spos+14*qdim],
                         &lbf[spos+15*qdim], &lbf[spos+16*qdim], &lbf[spos+17*qdim], &lbf[spos+18*qdim],
                         &lbf[spos+19*qdim], &lbf[spos+20*qdim], &lbf[spos+21*qdim], &lbf[spos+22*qdim],
                         &lbf[spos+23*qdim], &lbf[spos+24*qdim], &lbf[spos+25*qdim], &lbf[spos+26*qdim],
                         &lbf[spos+1*qdim], &lbf[spos+2*qdim], &lbf[spos+3*qdim], &lbf[spos+4*qdim],
                         &lbf[spos+5*qdim], &lbf[spos+6*qdim], &lbf[spos+7*qdim], &lbf[spos+8*qdim],
                         &lbf[spos+9*qdim], &lbf[spos+10*qdim], &lbf[spos+11*qdim], &lbf[spos+12*qdim],
                         &lbf[spos+13*qdim], moment);
        uwall[1] -= moment;
        break;
      case PSL:
        fD3Q27PPSInamuro(p0, &force[0], &lbf[spos], &lbf[spos+16*qdim],
                         &lbf[spos+14*qdim], &lbf[spos+15*qdim], &lbf[spos+19*qdim], &lbf[spos+7*qdim],
                         &lbf[spos+21*qdim], &lbf[spos+9*qdim], &lbf[spos+17*qdim], &lbf[spos+18*qdim],
                         &lbf[spos+23*qdim], &lbf[spos+25*qdim], &lbf[spos+13*qdim], &lbf[spos+11*qdim],
                         &lbf[spos+3*qdim], &lbf[spos+1*qdim], &lbf[spos+2*qdim], &lbf[spos+6*qdim],
                         &lbf[spos+20*qdim], &lbf[spos+8*qdim], &lbf[spos+22*qdim], &lbf[spos+4*qdim],
                         &lbf[spos+5*qdim], &lbf[spos+10*qdim], &lbf[spos+12*qdim], &lbf[spos+26*qdim],
                         &lbf[spos+24*qdim], moment);
        uwall[0] -= moment;
        break;
      case PSR:
        fD3Q27PPSInamuro(p0, &force[0], &lbf[spos], &lbf[spos+3*qdim],
                         &lbf[spos+1*qdim], &lbf[spos+2*qdim], &lbf[spos+6*qdim], &lbf[spos+20*qdim],
                         &lbf[spos+8*qdim], &lbf[spos+22*qdim], &lbf[spos+4*qdim], &lbf[spos+5*qdim],
                         &lbf[spos+10*qdim], &lbf[spos+12*qdim], &lbf[spos+26*qdim], &lbf[spos+24*qdim],
                         &lbf[spos+16*qdim], &lbf[spos+14*qdim], &lbf[spos+15*qdim], &lbf[spos+19*qdim],
                         &lbf[spos+7*qdim], &lbf[spos+21*qdim], &lbf[spos+9*qdim], &lbf[spos+17*qdim],
                         &lbf[spos+18*qdim], &lbf[spos+23*qdim], &lbf[spos+25*qdim], &lbf[spos+13*qdim],
                         &lbf[spos+11*qdim], moment);
        uwall[0] += moment;
        break;
      case PSF:
        fD3Q27PPSInamuro(p0, &force[0], &lbf[spos], &lbf[spos+15*qdim],
                         &lbf[spos+16*qdim], &lbf[spos+14*qdim], &lbf[spos+21*qdim], &lbf[spos+22*qdim],
                         &lbf[spos+17*qdim], &lbf[spos+5*qdim], &lbf[spos+19*qdim], &lbf[spos+7*qdim],
                         &lbf[spos+23*qdim], &lbf[spos+13*qdim], &lbf[spos+24*qdim], &lbf[spos+12*qdim],
                         &lbf[spos+2*qdim], &lbf[spos+3*qdim], &lbf[spos+1*qdim], &lbf[spos+8*qdim],
                         &lbf[spos+9*qdim], &lbf[spos+4*qdim], &lbf[spos+18*qdim], &lbf[spos+6*qdim],
                         &lbf[spos+20*qdim], &lbf[spos+10*qdim], &lbf[spos+26*qdim], &lbf[spos+11*qdim],
                         &lbf[spos+25*qdim], moment);
        uwall[2] -= moment;
        break;
      case PSB:
        fD3Q27PPSInamuro(p0, &force[0], &lbf[spos], &lbf[spos+2*qdim],
                         &lbf[spos+3*qdim], &lbf[spos+1*qdim], &lbf[spos+8*qdim], &lbf[spos+9*qdim],
                         &lbf[spos+4*qdim], &lbf[spos+18*qdim], &lbf[spos+6*qdim], &lbf[spos+20*qdim],
                         &lbf[spos+10*qdim], &lbf[spos+26*qdim], &lbf[spos+11*qdim], &lbf[spos+25*qdim],
                         &lbf[spos+15*qdim], &lbf[spos+16*qdim], &lbf[spos+14*qdim], &lbf[spos+21*qdim],
                         &lbf[spos+22*qdim], &lbf[spos+17*qdim], &lbf[spos+5*qdim], &lbf[spos+19*qdim],
                         &lbf[spos+7*qdim], &lbf[spos+23*qdim], &lbf[spos+13*qdim], &lbf[spos+24*qdim],
                         &lbf[spos+12*qdim], moment);
        uwall[2] += moment;
        break;
      case CCTRB:
        fD3Q27VCCInamuro(p0, uwall[0], uwall[1], -uwall[2], &force[0], &lbf[spos], &lbf[spos+1*qdim],
                         &lbf[spos+2*qdim], &lbf[spos+16*qdim], &lbf[spos+4*qdim], &lbf[spos+5*qdim],
                         &lbf[spos+7*qdim], &lbf[spos+6*qdim], &lbf[spos+9*qdim], &lbf[spos+8*qdim],
                         &lbf[spos+11*qdim], &lbf[spos+10*qdim], &lbf[spos+13*qdim], &lbf[spos+12*qdim],
                         &lbf[spos+14*qdim], &lbf[spos+15*qdim], &lbf[spos+3*qdim], &lbf[spos+17*qdim],
                         &lbf[spos+18*qdim], &lbf[spos+20*qdim], &lbf[spos+19*qdim], &lbf[spos+22*qdim],
                         &lbf[spos+21*qdim], &lbf[spos+24*qdim], &lbf[spos+23*qdim], &lbf[spos+26*qdim],
                         &lbf[spos+25*qdim]);
        break;
      case CCTLB:
        fD3Q27VCCInamuro(p0, -uwall[0], uwall[1], -uwall[2], &force[0], &lbf[spos], &lbf[spos+14*qdim],
                         &lbf[spos+2*qdim], &lbf[spos+16*qdim], &lbf[spos+18*qdim], &lbf[spos+17*qdim],
                         &lbf[spos+19*qdim], &lbf[spos+20*qdim], &lbf[spos+9*qdim], &lbf[spos+8*qdim],
                         &lbf[spos+25*qdim], &lbf[spos+26*qdim], &lbf[spos+23*qdim], &lbf[spos+24*qdim],
                         &lbf[spos+1*qdim], &lbf[spos+15*qdim], &lbf[spos+3*qdim], &lbf[spos+5*qdim],
                         &lbf[spos+4*qdim], &lbf[spos+6*qdim], &lbf[spos+7*qdim], &lbf[spos+22*qdim],
                         &lbf[spos+21*qdim], &lbf[spos+12*qdim], &lbf[spos+13*qdim], &lbf[spos+10*qdim],
                         &lbf[spos+11*qdim]);
        break;
      case CCDLB:
        fD3Q27VCCInamuro(p0, -uwall[0], -uwall[1], -uwall[2], &force[0], &lbf[spos], &lbf[spos+14*qdim],
                         &lbf[spos+15*qdim], &lbf[spos+16*qdim], &lbf[spos+17*qdim], &lbf[spos+18*qdim],
                         &lbf[spos+19*qdim], &lbf[spos+20*qdim], &lbf[spos+21*qdim], &lbf[spos+22*qdim],
                         &lbf[spos+23*qdim], &lbf[spos+24*qdim], &lbf[spos+25*qdim], &lbf[spos+26*qdim],
                         &lbf[spos+1*qdim], &lbf[spos+2*qdim], &lbf[spos+3*qdim], &lbf[spos+4*qdim],
                         &lbf[spos+5*qdim], &lbf[spos+6*qdim], &lbf[spos+7*qdim], &lbf[spos+8*qdim],
                         &lbf[spos+9*qdim], &lbf[spos+10*qdim], &lbf[spos+11*qdim], &lbf[spos+12*qdim],
                         &lbf[spos+13*qdim]);
        break;
      case CCDRB:
        fD3Q27VCCInamuro(p0, uwall[0], -uwall[1], -uwall[2], &force[0], &lbf[spos], &lbf[spos+1*qdim],
                         &lbf[spos+15*qdim], &lbf[spos+16*qdim], &lbf[spos+5*qdim], &lbf[spos+4*qdim],
                         &lbf[spos+7*qdim], &lbf[spos+6*qdim], &lbf[spos+21*qdim], &lbf[spos+22*qdim],
                         &lbf[spos+13*qdim], &lbf[spos+12*qdim], &lbf[spos+11*qdim], &lbf[spos+10*qdim],
                         &lbf[spos+14*qdim], &lbf[spos+2*qdim], &lbf[spos+3*qdim], &lbf[spos+18*qdim],
                         &lbf[spos+17*qdim], &lbf[spos+20*qdim], &lbf[spos+19*qdim], &lbf[spos+8*qdim],
                         &lbf[spos+9*qdim], &lbf[spos+26*qdim], &lbf[spos+25*qdim], &lbf[spos+24*qdim],
                         &lbf[spos+23*qdim]);
        break;
      case CCTRF:
        fD3Q27VCCInamuro(p0, uwall[0], uwall[1], uwall[2], &force[0], &lbf[spos], &lbf[spos+1*qdim],
                         &lbf[spos+2*qdim], &lbf[spos+3*qdim], &lbf[spos+4*qdim], &lbf[spos+5*qdim],
                         &lbf[spos+6*qdim], &lbf[spos+7*qdim], &lbf[spos+8*qdim], &lbf[spos+9*qdim],
                         &lbf[spos+10*qdim], &lbf[spos+11*qdim], &lbf[spos+12*qdim], &lbf[spos+13*qdim],
                         &lbf[spos+14*qdim], &lbf[spos+15*qdim], &lbf[spos+16*qdim], &lbf[spos+17*qdim],
                         &lbf[spos+18*qdim], &lbf[spos+19*qdim], &lbf[spos+20*qdim], &lbf[spos+21*qdim],
                         &lbf[spos+22*qdim], &lbf[spos+23*qdim], &lbf[spos+24*qdim], &lbf[spos+25*qdim],
                         &lbf[spos+26*qdim]);
        break;
      case CCTLF:
        fD3Q27VCCInamuro(p0, -uwall[0], uwall[1], uwall[2], &force[0], &lbf[spos], &lbf[spos+14*qdim],
                         &lbf[spos+2*qdim], &lbf[spos+3*qdim], &lbf[spos+18*qdim], &lbf[spos+17*qdim],
                         &lbf[spos+20*qdim], &lbf[spos+19*qdim], &lbf[spos+8*qdim], &lbf[spos+9*qdim],
                         &lbf[spos+26*qdim], &lbf[spos+25*qdim], &lbf[spos+24*qdim], &lbf[spos+23*qdim],
                         &lbf[spos+1*qdim], &lbf[spos+15*qdim], &lbf[spos+16*qdim], &lbf[spos+5*qdim],
                         &lbf[spos+4*qdim], &lbf[spos+7*qdim], &lbf[spos+6*qdim], &lbf[spos+21*qdim],
                         &lbf[spos+22*qdim], &lbf[spos+13*qdim], &lbf[spos+12*qdim], &lbf[spos+11*qdim],
                         &lbf[spos+10*qdim]);
        break;
      case CCDLF:
        fD3Q27VCCInamuro(p0, -uwall[0], -uwall[1], uwall[2], &force[0], &lbf[spos], &lbf[spos+14*qdim],
                         &lbf[spos+15*qdim], &lbf[spos+3*qdim], &lbf[spos+17*qdim], &lbf[spos+18*qdim],
                         &lbf[spos+20*qdim], &lbf[spos+19*qdim], &lbf[spos+22*qdim], &lbf[spos+21*qdim],
                         &lbf[spos+24*qdim], &lbf[spos+23*qdim], &lbf[spos+26*qdim], &lbf[spos+25*qdim],
                         &lbf[spos+1*qdim], &lbf[spos+2*qdim], &lbf[spos+16*qdim], &lbf[spos+4*qdim],
                         &lbf[spos+5*qdim], &lbf[spos+7*qdim], &lbf[spos+6*qdim], &lbf[spos+9*qdim],
                         &lbf[spos+8*qdim], &lbf[spos+11*qdim], &lbf[spos+10*qdim], &lbf[spos+13*qdim],
                         &lbf[spos+12*qdim]);
        break;
      case CCDRF:
        fD3Q27VCCInamuro(p0, uwall[0], -uwall[1], uwall[2], &force[0], &lbf[spos], &lbf[spos+1*qdim],
                         &lbf[spos+15*qdim], &lbf[spos+3*qdim], &lbf[spos+5*qdim], &lbf[spos+4*qdim],
                         &lbf[spos+6*qdim], &lbf[spos+7*qdim], &lbf[spos+22*qdim], &lbf[spos+21*qdim],
                         &lbf[spos+12*qdim], &lbf[spos+13*qdim], &lbf[spos+10*qdim], &lbf[spos+11*qdim],
                         &lbf[spos+14*qdim], &lbf[spos+2*qdim], &lbf[spos+16*qdim], &lbf[spos+18*qdim],
                         &lbf[spos+17*qdim], &lbf[spos+19*qdim], &lbf[spos+20*qdim], &lbf[spos+9*qdim],
                         &lbf[spos+8*qdim], &lbf[spos+25*qdim], &lbf[spos+26*qdim], &lbf[spos+23*qdim],
                         &lbf[spos+24*qdim]);
        break;
      case CETR:
        fD3Q27VCEInamuro(p0, uwall[0], uwall[1], uwall[2], &force[0], &lbf[spos], &lbf[spos+1*qdim],
                         &lbf[spos+2*qdim], &lbf[spos+3*qdim], &lbf[spos+4*qdim], &lbf[spos+5*qdim],
                         &lbf[spos+6*qdim], &lbf[spos+7*qdim], &lbf[spos+8*qdim], &lbf[spos+9*qdim],
                         &lbf[spos+10*qdim], &lbf[spos+11*qdim], &lbf[spos+12*qdim], &lbf[spos+13*qdim],
                         &lbf[spos+14*qdim], &lbf[spos+15*qdim], &lbf[spos+16*qdim], &lbf[spos+17*qdim],
                         &lbf[spos+18*qdim], &lbf[spos+19*qdim], &lbf[spos+20*qdim], &lbf[spos+21*qdim],
                         &lbf[spos+22*qdim], &lbf[spos+23*qdim], &lbf[spos+24*qdim], &lbf[spos+25*qdim],
                         &lbf[spos+26*qdim]);
        break;
      case CETL:
        fD3Q27VCEInamuro(p0, uwall[1], -uwall[0], uwall[2], &force[0], &lbf[spos], &lbf[spos+2*qdim],
                         &lbf[spos+14*qdim], &lbf[spos+3*qdim], &lbf[spos+18*qdim], &lbf[spos+4*qdim],
                         &lbf[spos+8*qdim], &lbf[spos+9*qdim], &lbf[spos+20*qdim], &lbf[spos+19*qdim],
                         &lbf[spos+26*qdim], &lbf[spos+25*qdim], &lbf[spos+10*qdim], &lbf[spos+11*qdim],
                         &lbf[spos+15*qdim], &lbf[spos+1*qdim], &lbf[spos+16*qdim], &lbf[spos+5*qdim],
                         &lbf[spos+17*qdim], &lbf[spos+21*qdim], &lbf[spos+22*qdim], &lbf[spos+7*qdim],
                         &lbf[spos+6*qdim], &lbf[spos+13*qdim], &lbf[spos+12*qdim], &lbf[spos+23*qdim],
                         &lbf[spos+24*qdim]);
        break;
      case CEDL:
        fD3Q27VCEInamuro(p0, -uwall[0], -uwall[1], uwall[2], &force[0], &lbf[spos], &lbf[spos+14*qdim],
                         &lbf[spos+15*qdim], &lbf[spos+3*qdim], &lbf[spos+17*qdim], &lbf[spos+18*qdim],
                         &lbf[spos+20*qdim], &lbf[spos+19*qdim], &lbf[spos+22*qdim], &lbf[spos+21*qdim],
                         &lbf[spos+24*qdim], &lbf[spos+23*qdim], &lbf[spos+26*qdim], &lbf[spos+25*qdim],
                         &lbf[spos+1*qdim], &lbf[spos+2*qdim], &lbf[spos+16*qdim], &lbf[spos+4*qdim],
                         &lbf[spos+5*qdim], &lbf[spos+7*qdim], &lbf[spos+6*qdim], &lbf[spos+9*qdim],
                         &lbf[spos+8*qdim], &lbf[spos+11*qdim], &lbf[spos+10*qdim], &lbf[spos+13*qdim],
                         &lbf[spos+12*qdim]);
        break;
      case CEDR:
        fD3Q27VCEInamuro(p0, -uwall[1], uwall[0], uwall[2], &force[0], &lbf[spos], &lbf[spos+15*qdim],
                         &lbf[spos+1*qdim], &lbf[spos+3*qdim], &lbf[spos+5*qdim], &lbf[spos+17*qdim],
                         &lbf[spos+22*qdim], &lbf[spos+21*qdim], &lbf[spos+6*qdim], &lbf[spos+7*qdim],
                         &lbf[spos+12*qdim], &lbf[spos+13*qdim], &lbf[spos+24*qdim], &lbf[spos+23*qdim],
                         &lbf[spos+2*qdim], &lbf[spos+14*qdim], &lbf[spos+16*qdim], &lbf[spos+18*qdim],
                         &lbf[spos+4*qdim], &lbf[spos+9*qdim], &lbf[spos+8*qdim], &lbf[spos+19*qdim],
                         &lbf[spos+20*qdim], &lbf[spos+25*qdim], &lbf[spos+26*qdim], &lbf[spos+11*qdim],
                         &lbf[spos+10*qdim]);
        break;
      case CETF:
        fD3Q27VCEInamuro(p0, uwall[1], uwall[2], uwall[0], &force[0], &lbf[spos], &lbf[spos+2*qdim],
                         &lbf[spos+3*qdim], &lbf[spos+1*qdim], &lbf[spos+8*qdim], &lbf[spos+9*qdim],
                         &lbf[spos+4*qdim], &lbf[spos+18*qdim], &lbf[spos+6*qdim], &lbf[spos+20*qdim],
                         &lbf[spos+10*qdim], &lbf[spos+26*qdim], &lbf[spos+11*qdim], &lbf[spos+25*qdim],
                         &lbf[spos+15*qdim], &lbf[spos+16*qdim], &lbf[spos+14*qdim], &lbf[spos+21*qdim],
                         &lbf[spos+22*qdim], &lbf[spos+17*qdim], &lbf[spos+5*qdim], &lbf[spos+19*qdim],
                         &lbf[spos+7*qdim], &lbf[spos+23*qdim], &lbf[spos+13*qdim], &lbf[spos+24*qdim],
                         &lbf[spos+12*qdim]);
        break;
      case CELF:
        fD3Q27VCEInamuro(p0, -uwall[0], uwall[1], uwall[2], &force[0], &lbf[spos], &lbf[spos+14*qdim],
                         &lbf[spos+3*qdim], &lbf[spos+2*qdim], &lbf[spos+20*qdim], &lbf[spos+19*qdim],
                         &lbf[spos+18*qdim], &lbf[spos+17*qdim], &lbf[spos+8*qdim], &lbf[spos+22*qdim],
                         &lbf[spos+26*qdim], &lbf[spos+24*qdim], &lbf[spos+25*qdim], &lbf[spos+23*qdim],
                         &lbf[spos+1*qdim], &lbf[spos+16*qdim], &lbf[spos+15*qdim], &lbf[spos+7*qdim],
                         &lbf[spos+6*qdim], &lbf[spos+5*qdim], &lbf[spos+4*qdim], &lbf[spos+21*qdim],
                         &lbf[spos+9*qdim], &lbf[spos+13*qdim], &lbf[spos+11*qdim], &lbf[spos+12*qdim],
                         &lbf[spos+10*qdim]);
        break;
      case CEDF:
        fD3Q27VCEInamuro(p0, -uwall[1], uwall[2], uwall[0], &force[0], &lbf[spos], &lbf[spos+15*qdim],
                         &lbf[spos+3*qdim], &lbf[spos+1*qdim], &lbf[spos+22*qdim], &lbf[spos+21*qdim],
                         &lbf[spos+5*qdim], &lbf[spos+17*qdim], &lbf[spos+6*qdim], &lbf[spos+20*qdim],
                         &lbf[spos+12*qdim], &lbf[spos+24*qdim], &lbf[spos+13*qdim], &lbf[spos+23*qdim],
                         &lbf[spos+2*qdim], &lbf[spos+16*qdim], &lbf[spos+14*qdim], &lbf[spos+9*qdim],
                         &lbf[spos+8*qdim], &lbf[spos+18*qdim], &lbf[spos+4*qdim], &lbf[spos+19*qdim],
                         &lbf[spos+7*qdim], &lbf[spos+25*qdim], &lbf[spos+11*qdim], &lbf[spos+26*qdim],
                         &lbf[spos+10*qdim]);
        break;
      case CERF:
        fD3Q27VCEInamuro(p0, uwall[0], uwall[2], uwall[2], &force[0], &lbf[spos], &lbf[spos+1*qdim],
                         &lbf[spos+3*qdim], &lbf[spos+2*qdim], &lbf[spos+6*qdim], &lbf[spos+7*qdim],
                         &lbf[spos+4*qdim], &lbf[spos+5*qdim], &lbf[spos+8*qdim], &lbf[spos+22*qdim],
                         &lbf[spos+10*qdim], &lbf[spos+12*qdim], &lbf[spos+11*qdim], &lbf[spos+13*qdim],
                         &lbf[spos+14*qdim], &lbf[spos+16*qdim], &lbf[spos+15*qdim], &lbf[spos+19*qdim],
                         &lbf[spos+20*qdim], &lbf[spos+17*qdim], &lbf[spos+18*qdim], &lbf[spos+21*qdim],
                         &lbf[spos+9*qdim], &lbf[spos+23*qdim], &lbf[spos+25*qdim], &lbf[spos+24*qdim],
                         &lbf[spos+26*qdim]);
        break;
      case CETB:
        fD3Q27VCEInamuro(p0, uwall[1], -uwall[2], uwall[0], &force[0], &lbf[spos], &lbf[spos+2*qdim],
                         &lbf[spos+16*qdim], &lbf[spos+1*qdim], &lbf[spos+9*qdim], &lbf[spos+8*qdim],
                         &lbf[spos+4*qdim], &lbf[spos+18*qdim], &lbf[spos+7*qdim], &lbf[spos+19*qdim],
                         &lbf[spos+11*qdim], &lbf[spos+25*qdim], &lbf[spos+10*qdim], &lbf[spos+26*qdim],
                         &lbf[spos+15*qdim], &lbf[spos+3*qdim], &lbf[spos+14*qdim], &lbf[spos+22*qdim],
                         &lbf[spos+21*qdim], &lbf[spos+17*qdim], &lbf[spos+5*qdim], &lbf[spos+20*qdim],
                         &lbf[spos+6*qdim], &lbf[spos+24*qdim], &lbf[spos+12*qdim], &lbf[spos+23*qdim],
                         &lbf[spos+13*qdim]);
        break;
      case CELB:
        fD3Q27VCEInamuro(p0, -uwall[0], -uwall[2], uwall[1], &force[0], &lbf[spos], &lbf[spos+14*qdim],
                         &lbf[spos+16*qdim], &lbf[spos+2*qdim], &lbf[spos+19*qdim], &lbf[spos+20*qdim],
                         &lbf[spos+18*qdim], &lbf[spos+17*qdim], &lbf[spos+9*qdim], &lbf[spos+21*qdim],
                         &lbf[spos+25*qdim], &lbf[spos+23*qdim], &lbf[spos+26*qdim], &lbf[spos+24*qdim],
                         &lbf[spos+1*qdim], &lbf[spos+3*qdim], &lbf[spos+15*qdim], &lbf[spos+6*qdim],
                         &lbf[spos+7*qdim], &lbf[spos+5*qdim], &lbf[spos+4*qdim], &lbf[spos+22*qdim],
                         &lbf[spos+8*qdim], &lbf[spos+12*qdim], &lbf[spos+10*qdim], &lbf[spos+13*qdim],
                         &lbf[spos+11*qdim]);
        break;
      case CEDB:
        fD3Q27VCEInamuro(p0, -uwall[1], -uwall[2], uwall[0], &force[0], &lbf[spos], &lbf[spos+15*qdim],
                         &lbf[spos+16*qdim], &lbf[spos+1*qdim], &lbf[spos+21*qdim], &lbf[spos+22*qdim],
                         &lbf[spos+5*qdim], &lbf[spos+17*qdim], &lbf[spos+7*qdim], &lbf[spos+19*qdim],
                         &lbf[spos+13*qdim], &lbf[spos+23*qdim], &lbf[spos+12*qdim], &lbf[spos+24*qdim],
                         &lbf[spos+2*qdim], &lbf[spos+3*qdim], &lbf[spos+14*qdim], &lbf[spos+8*qdim],
                         &lbf[spos+9*qdim], &lbf[spos+18*qdim], &lbf[spos+4*qdim], &lbf[spos+20*qdim],
                         &lbf[spos+6*qdim], &lbf[spos+26*qdim], &lbf[spos+10*qdim], &lbf[spos+25*qdim],
                         &lbf[spos+11*qdim]);
        break;
      case CERB:
        fD3Q27VCEInamuro(p0, uwall[0], -uwall[2], uwall[1], &force[0], &lbf[spos], &lbf[spos+1*qdim],
                         &lbf[spos+16*qdim], &lbf[spos+2*qdim], &lbf[spos+7*qdim], &lbf[spos+6*qdim],
                         &lbf[spos+4*qdim], &lbf[spos+5*qdim], &lbf[spos+9*qdim], &lbf[spos+21*qdim],
                         &lbf[spos+11*qdim], &lbf[spos+13*qdim], &lbf[spos+10*qdim], &lbf[spos+12*qdim],
                         &lbf[spos+14*qdim], &lbf[spos+3*qdim], &lbf[spos+15*qdim], &lbf[spos+20*qdim],
                         &lbf[spos+19*qdim], &lbf[spos+17*qdim], &lbf[spos+18*qdim], &lbf[spos+22*qdim],
                         &lbf[spos+8*qdim], &lbf[spos+24*qdim], &lbf[spos+26*qdim], &lbf[spos+23*qdim],
                         &lbf[spos+25*qdim]);
        break;
    }
  }
  return 0;
}


int fD3Q27CPSInamuro(double *p, double v0, double v1, double v2, double *f0, double *f1,
                     double *f2, double *f3, double *f4, double *f5, double *f6,
                     double *f7, double *f8, double *f9, double *f10, double *f11,
                     double *f12, double *f13, double *f14, double *f15, double *f16,
                     double *f17, double *f18, double *f19, double *f20, double *f21,
                     double *f22, double *f23, double *f24, double *f25, double *f26)
{

  // produce fixed concentration at planar surface: expressed for bottom wall (CPST)

  double rhop;
  double c1=2.0/27.0,c2=1.0/54.0,c3=1.0/216.0;
  for(int i=0; i<lbsy.nc; i++) {
    rhop=6.0*(p[i]-f0[i]-f1[i]-f2[i]-f3[i]-f4[i]-f6[i]-f7[i]-f8[i]-f9[i]-f10[i]-f11[i]-f14[i]-f16[i]-f18[i]-f19[i]-f20[i]-f25[i]-f26[i])/(1.0+3.0*v1);
    f5[i]=c2*rhop*(1.0-3.0*v0+3.0*v1);
    f12[i]=c3*rhop*(1.0-3.0*v0+3.0*v1-3.0*v2);
    f13[i]=c3*rhop*(1.0-3.0*v0+3.0*v1+3.0*v2);
    f15[i]=c1*rhop*(1.0+3.0*v1);
    f17[i]=c2*rhop*(1.0+3.0*v0+3.0*v1);
    f21[i]=c2*rhop*(1.0+3.0*v1+3.0*v2);
    f22[i]=c2*rhop*(1.0+3.0*v1-3.0*v2);
    f23[i]=c3*rhop*(1.0+3.0*v0+3.0*v1+3.0*v2);
    f24[i]=c3*rhop*(1.0+3.0*v0+3.0*v1-3.0*v2);
  }
  return 0;
}

int fD3Q27CCEInamuro(double *p, double v0, double v1, double v2, double *f0, double *f1,
                     double *f2, double *f3, double *f4, double *f5, double *f6,
                     double *f7, double *f8, double *f9, double *f10, double *f11,
                     double *f12, double *f13, double *f14, double *f15, double *f16,
                     double *f17, double *f18, double *f19, double *f20, double *f21,
                     double *f22, double *f23, double *f24, double *f25, double *f26)
{

  // produce fixed concentration at concave edge: expressed for bottom left edge (CCETR)

  double rhop;
  double c1=2.0/27.0,c2=1.0/54.0,c3=1.0/216.0;
  for(int i=0; i<lbsy.nc; i++) {
    rhop=36.0*(p[i]-f0[i]-f1[i]-f2[i]-f3[i]-f4[i]-f6[i]-f7[i]-f8[i]-f9[i]-f10[i]-f11[i]-f16[i])/(11.0+15.0*(v0+v1));
    f5[i]=c2*rhop*(1.0-3.0*v0+3.0*v1);
    f12[i]=c3*rhop*(1.0-3.0*v0+3.0*v1-3.0*v2);
    f13[i]=c3*rhop*(1.0-3.0*v0+3.0*v1+3.0*v2);
    f14[i]=c1*rhop*(1.0+3.0*v0);
    f15[i]=c1*rhop*(1.0+3.0*v1);
    f17[i]=c2*rhop*(1.0+3.0*v0+3.0*v1);
    f18[i]=c2*rhop*(1.0+3.0*v0-3.0*v1);
    f19[i]=c2*rhop*(1.0+3.0*v0+3.0*v2);
    f20[i]=c2*rhop*(1.0+3.0*v0-3.0*v2);
    f21[i]=c2*rhop*(1.0+3.0*v1+3.0*v2);
    f22[i]=c2*rhop*(1.0+3.0*v1-3.0*v2);
    f23[i]=c3*rhop*(1.0+3.0*v0+3.0*v1+3.0*v2);
    f24[i]=c3*rhop*(1.0+3.0*v0+3.0*v1-3.0*v2);
    f25[i]=c3*rhop*(1.0+3.0*v0-3.0*v1+3.0*v2);
    f26[i]=c3*rhop*(1.0+3.0*v0-3.0*v1-3.0*v2);
  }
  return 0;
}

int fD3Q27CCCInamuro(double *p, double v0, double v1, double v2, double *f0, double *f1,
                     double *f2, double *f3, double *f4, double *f5, double *f6,
                     double *f7, double *f8, double *f9, double *f10, double *f11,
                     double *f12, double *f13, double *f14, double *f15, double *f16,
                     double *f17, double *f18, double *f19, double *f20, double *f21,
                     double *f22, double *f23, double *f24, double *f25, double *f26)
{

  // produce fixed concentration at concave corner: expressed for bottom left back corner (CCCTRF)

  double rhop;
  double c1=2.0/27.0,c2=1.0/54.0,c3=1.0/216.0;
  for(int i=0; i<lbsy.nc; i++) {
    rhop=216.0*(p[i]-f0[i]-f1[i]-f2[i]-f3[i]-f4[i]-f6[i]-f8[i]-f10[i])/(91.0+75.0*(v0+v1+v2));
    f5[i]=c2*rhop*(1.0-3.0*v0+3.0*v1);
    f7[i]=c2*rhop*(1.0-3.0*v0+3.0*v2);
    f9[i]=c2*rhop*(1.0-3.0*v1+3.0*v2);
    f11[i]=c3*rhop*(1.0-3.0*v0-3.0*v1+3.0*v2);
    f12[i]=c3*rhop*(1.0-3.0*v0+3.0*v1-3.0*v2);
    f13[i]=c3*rhop*(1.0-3.0*v0+3.0*v1+3.0*v2);
    f14[i]=c1*rhop*(1.0+3.0*v0);
    f15[i]=c1*rhop*(1.0+3.0*v1);
    f16[i]=c1*rhop*(1.0+3.0*v2);
    f17[i]=c2*rhop*(1.0+3.0*v0+3.0*v1);
    f18[i]=c2*rhop*(1.0+3.0*v0-3.0*v1);
    f19[i]=c2*rhop*(1.0+3.0*v0+3.0*v2);
    f20[i]=c2*rhop*(1.0+3.0*v0-3.0*v2);
    f21[i]=c2*rhop*(1.0+3.0*v1+3.0*v2);
    f22[i]=c2*rhop*(1.0+3.0*v1-3.0*v2);
    f23[i]=c3*rhop*(1.0+3.0*v0+3.0*v1+3.0*v2);
    f24[i]=c3*rhop*(1.0+3.0*v0+3.0*v1-3.0*v2);
    f25[i]=c3*rhop*(1.0+3.0*v0-3.0*v1+3.0*v2);
    f26[i]=c3*rhop*(1.0+3.0*v0-3.0*v1-3.0*v2);
  }
  return 0;
}


int fD3Q27PCInamuro(long tpos, int prop, double *p0, double *uwall)
{
  long spos=tpos * lbsitelength + lbsy.nf;
  int qdim=lbsy.nf+lbsy.nc+lbsy.nt;
    
  switch (prop) {
    case PST:
      fD3Q27CPSInamuro(p0, uwall[0], uwall[1], uwall[2], &lbf[spos], &lbf[spos+1*qdim],
                       &lbf[spos+2*qdim], &lbf[spos+3*qdim], &lbf[spos+4*qdim], &lbf[spos+5*qdim], &lbf[spos+6*qdim],
                       &lbf[spos+7*qdim], &lbf[spos+8*qdim], &lbf[spos+9*qdim], &lbf[spos+10*qdim], &lbf[spos+11*qdim],
                       &lbf[spos+12*qdim], &lbf[spos+13*qdim], &lbf[spos+14*qdim], &lbf[spos+15*qdim], &lbf[spos+16*qdim],
                       &lbf[spos+17*qdim], &lbf[spos+18*qdim], &lbf[spos+19*qdim], &lbf[spos+20*qdim], &lbf[spos+21*qdim],
                       &lbf[spos+22*qdim], &lbf[spos+23*qdim], &lbf[spos+24*qdim], &lbf[spos+25*qdim], &lbf[spos+26*qdim]);
      break;
    case PSD:
      fD3Q27CPSInamuro(p0, -uwall[0], -uwall[1], -uwall[2], &lbf[spos], &lbf[spos+14*qdim],
                       &lbf[spos+15*qdim], &lbf[spos+16*qdim], &lbf[spos+17*qdim], &lbf[spos+18*qdim], &lbf[spos+19*qdim],
                       &lbf[spos+20*qdim], &lbf[spos+21*qdim], &lbf[spos+22*qdim], &lbf[spos+23*qdim], &lbf[spos+24*qdim],
                       &lbf[spos+25*qdim], &lbf[spos+26*qdim], &lbf[spos+1*qdim], &lbf[spos+2*qdim], &lbf[spos+3*qdim],
                       &lbf[spos+4*qdim], &lbf[spos+5*qdim], &lbf[spos+6*qdim], &lbf[spos+7*qdim], &lbf[spos+8*qdim],
                       &lbf[spos+9*qdim], &lbf[spos+10*qdim], &lbf[spos+11*qdim], &lbf[spos+12*qdim], &lbf[spos+13*qdim]);
      break;
    case PSL:
      fD3Q27CPSInamuro(p0, -uwall[2], -uwall[0], -uwall[1], &lbf[spos], &lbf[spos+16*qdim],
                       &lbf[spos+14*qdim], &lbf[spos+15*qdim], &lbf[spos+19*qdim], &lbf[spos+7*qdim], &lbf[spos+21*qdim],
                       &lbf[spos+9*qdim], &lbf[spos+17*qdim], &lbf[spos+18*qdim], &lbf[spos+23*qdim], &lbf[spos+25*qdim],
                       &lbf[spos+13*qdim], &lbf[spos+11*qdim], &lbf[spos+3*qdim], &lbf[spos+1*qdim], &lbf[spos+2*qdim],
                       &lbf[spos+6*qdim], &lbf[spos+20*qdim], &lbf[spos+8*qdim], &lbf[spos+22*qdim], &lbf[spos+4*qdim],
                       &lbf[spos+5*qdim], &lbf[spos+10*qdim], &lbf[spos+12*qdim], &lbf[spos+26*qdim], &lbf[spos+24*qdim]);
      break;
    case PSR:
      fD3Q27CPSInamuro(p0, uwall[2], uwall[0], uwall[1], &lbf[spos], &lbf[spos+3*qdim],
                       &lbf[spos+1*qdim], &lbf[spos+2*qdim], &lbf[spos+6*qdim], &lbf[spos+20*qdim], &lbf[spos+8*qdim],
                       &lbf[spos+22*qdim], &lbf[spos+4*qdim], &lbf[spos+5*qdim], &lbf[spos+10*qdim], &lbf[spos+12*qdim],
                       &lbf[spos+26*qdim], &lbf[spos+24*qdim], &lbf[spos+16*qdim], &lbf[spos+14*qdim], &lbf[spos+15*qdim],
                       &lbf[spos+19*qdim], &lbf[spos+7*qdim], &lbf[spos+21*qdim], &lbf[spos+9*qdim], &lbf[spos+17*qdim],
                       &lbf[spos+18*qdim], &lbf[spos+23*qdim], &lbf[spos+25*qdim], &lbf[spos+13*qdim], &lbf[spos+11*qdim]);
      break;
    case PSF:
      fD3Q27CPSInamuro(p0, -uwall[1], -uwall[2], -uwall[0], &lbf[spos], &lbf[spos+15*qdim],
                       &lbf[spos+16*qdim], &lbf[spos+14*qdim], &lbf[spos+21*qdim], &lbf[spos+22*qdim], &lbf[spos+17*qdim],
                       &lbf[spos+5*qdim], &lbf[spos+19*qdim], &lbf[spos+7*qdim], &lbf[spos+23*qdim], &lbf[spos+13*qdim],
                       &lbf[spos+24*qdim], &lbf[spos+12*qdim], &lbf[spos+2*qdim], &lbf[spos+3*qdim], &lbf[spos+1*qdim],
                       &lbf[spos+8*qdim], &lbf[spos+9*qdim], &lbf[spos+4*qdim], &lbf[spos+18*qdim], &lbf[spos+6*qdim],
                       &lbf[spos+20*qdim], &lbf[spos+10*qdim], &lbf[spos+26*qdim], &lbf[spos+11*qdim], &lbf[spos+25*qdim]);
      break;
    case PSB:
      fD3Q27CPSInamuro(p0, uwall[1], uwall[2], uwall[0], &lbf[spos], &lbf[spos+2*qdim],
                       &lbf[spos+3*qdim], &lbf[spos+1*qdim], &lbf[spos+8*qdim], &lbf[spos+9*qdim], &lbf[spos+4*qdim],
                       &lbf[spos+18*qdim], &lbf[spos+6*qdim], &lbf[spos+20*qdim], &lbf[spos+10*qdim], &lbf[spos+26*qdim],
                       &lbf[spos+11*qdim], &lbf[spos+25*qdim], &lbf[spos+15*qdim], &lbf[spos+16*qdim], &lbf[spos+14*qdim],
                       &lbf[spos+21*qdim], &lbf[spos+22*qdim], &lbf[spos+17*qdim], &lbf[spos+5*qdim], &lbf[spos+19*qdim],
                       &lbf[spos+7*qdim], &lbf[spos+23*qdim], &lbf[spos+13*qdim], &lbf[spos+24*qdim], &lbf[spos+12*qdim]);
      break;
    case CCTRB:
      fD3Q27CCCInamuro(p0, uwall[0], uwall[1], -uwall[2], &lbf[spos], &lbf[spos+1*qdim],
                       &lbf[spos+2*qdim], &lbf[spos+16*qdim], &lbf[spos+4*qdim], &lbf[spos+5*qdim],
                       &lbf[spos+7*qdim], &lbf[spos+6*qdim], &lbf[spos+9*qdim], &lbf[spos+8*qdim],
                       &lbf[spos+11*qdim], &lbf[spos+10*qdim], &lbf[spos+13*qdim], &lbf[spos+12*qdim],
                       &lbf[spos+14*qdim], &lbf[spos+15*qdim], &lbf[spos+3*qdim], &lbf[spos+17*qdim],
                       &lbf[spos+18*qdim], &lbf[spos+20*qdim], &lbf[spos+19*qdim], &lbf[spos+22*qdim],
                       &lbf[spos+21*qdim], &lbf[spos+24*qdim], &lbf[spos+23*qdim], &lbf[spos+26*qdim],
                       &lbf[spos+25*qdim]);
      break;
    case CCTLB:
      fD3Q27CCCInamuro(p0, -uwall[0], uwall[1], -uwall[2], &lbf[spos], &lbf[spos+14*qdim],
                       &lbf[spos+2*qdim], &lbf[spos+16*qdim], &lbf[spos+18*qdim], &lbf[spos+17*qdim],
                       &lbf[spos+19*qdim], &lbf[spos+20*qdim], &lbf[spos+9*qdim], &lbf[spos+8*qdim],
                       &lbf[spos+25*qdim], &lbf[spos+26*qdim], &lbf[spos+23*qdim], &lbf[spos+24*qdim],
                       &lbf[spos+1*qdim], &lbf[spos+15*qdim], &lbf[spos+3*qdim], &lbf[spos+5*qdim],
                       &lbf[spos+4*qdim], &lbf[spos+6*qdim], &lbf[spos+7*qdim], &lbf[spos+22*qdim],
                       &lbf[spos+21*qdim], &lbf[spos+12*qdim], &lbf[spos+13*qdim], &lbf[spos+10*qdim],
                       &lbf[spos+11*qdim]);
      break;
    case CCDLB:
      fD3Q27CCCInamuro(p0, -uwall[0], -uwall[1], -uwall[2], &lbf[spos], &lbf[spos+14*qdim],
                       &lbf[spos+15*qdim], &lbf[spos+16*qdim], &lbf[spos+17*qdim], &lbf[spos+18*qdim],
                       &lbf[spos+19*qdim], &lbf[spos+20*qdim], &lbf[spos+21*qdim], &lbf[spos+22*qdim],
                       &lbf[spos+23*qdim], &lbf[spos+24*qdim], &lbf[spos+25*qdim], &lbf[spos+26*qdim],
                       &lbf[spos+1*qdim], &lbf[spos+2*qdim], &lbf[spos+3*qdim], &lbf[spos+4*qdim],
                       &lbf[spos+5*qdim], &lbf[spos+6*qdim], &lbf[spos+7*qdim], &lbf[spos+8*qdim],
                       &lbf[spos+9*qdim], &lbf[spos+10*qdim], &lbf[spos+11*qdim], &lbf[spos+12*qdim],
                       &lbf[spos+13*qdim]);
      break;
    case CCDRB:
      fD3Q27CCCInamuro(p0, uwall[0], -uwall[1], -uwall[2], &lbf[spos], &lbf[spos+1*qdim],
                       &lbf[spos+15*qdim], &lbf[spos+16*qdim], &lbf[spos+5*qdim], &lbf[spos+4*qdim],
                       &lbf[spos+7*qdim], &lbf[spos+6*qdim], &lbf[spos+21*qdim], &lbf[spos+22*qdim],
                       &lbf[spos+13*qdim], &lbf[spos+12*qdim], &lbf[spos+11*qdim], &lbf[spos+10*qdim],
                       &lbf[spos+14*qdim], &lbf[spos+2*qdim], &lbf[spos+3*qdim], &lbf[spos+18*qdim],
                       &lbf[spos+17*qdim], &lbf[spos+20*qdim], &lbf[spos+19*qdim], &lbf[spos+8*qdim],
                       &lbf[spos+9*qdim], &lbf[spos+26*qdim], &lbf[spos+25*qdim], &lbf[spos+24*qdim],
                       &lbf[spos+23*qdim]);
      break;
    case CCTRF:
      fD3Q27CCCInamuro(p0, uwall[0], uwall[1], uwall[2], &lbf[spos], &lbf[spos+1*qdim],
                       &lbf[spos+2*qdim], &lbf[spos+3*qdim], &lbf[spos+4*qdim], &lbf[spos+5*qdim],
                       &lbf[spos+6*qdim], &lbf[spos+7*qdim], &lbf[spos+8*qdim], &lbf[spos+9*qdim],
                       &lbf[spos+10*qdim], &lbf[spos+11*qdim], &lbf[spos+12*qdim], &lbf[spos+13*qdim],
                       &lbf[spos+14*qdim], &lbf[spos+15*qdim], &lbf[spos+16*qdim], &lbf[spos+17*qdim],
                       &lbf[spos+18*qdim], &lbf[spos+19*qdim], &lbf[spos+20*qdim], &lbf[spos+21*qdim],
                       &lbf[spos+22*qdim], &lbf[spos+23*qdim], &lbf[spos+24*qdim], &lbf[spos+25*qdim],
                       &lbf[spos+26*qdim]);
      break;
    case CCTLF:
      fD3Q27CCCInamuro(p0, -uwall[0], uwall[1], uwall[2], &lbf[spos], &lbf[spos+14*qdim],
                       &lbf[spos+2*qdim], &lbf[spos+3*qdim], &lbf[spos+18*qdim], &lbf[spos+17*qdim],
                       &lbf[spos+20*qdim], &lbf[spos+19*qdim], &lbf[spos+8*qdim], &lbf[spos+9*qdim],
                       &lbf[spos+26*qdim], &lbf[spos+25*qdim], &lbf[spos+24*qdim], &lbf[spos+23*qdim],
                       &lbf[spos+1*qdim], &lbf[spos+15*qdim], &lbf[spos+16*qdim], &lbf[spos+5*qdim],
                       &lbf[spos+4*qdim], &lbf[spos+7*qdim], &lbf[spos+6*qdim], &lbf[spos+21*qdim],
                       &lbf[spos+22*qdim], &lbf[spos+13*qdim], &lbf[spos+12*qdim], &lbf[spos+11*qdim],
                       &lbf[spos+10*qdim]);
      break;
    case CCDLF:
      fD3Q27CCCInamuro(p0, -uwall[0], -uwall[1], uwall[2], &lbf[spos], &lbf[spos+14*qdim],
                       &lbf[spos+15*qdim], &lbf[spos+3*qdim], &lbf[spos+17*qdim], &lbf[spos+18*qdim],
                       &lbf[spos+20*qdim], &lbf[spos+19*qdim], &lbf[spos+22*qdim], &lbf[spos+21*qdim],
                       &lbf[spos+24*qdim], &lbf[spos+23*qdim], &lbf[spos+26*qdim], &lbf[spos+25*qdim],
                       &lbf[spos+1*qdim], &lbf[spos+2*qdim], &lbf[spos+16*qdim], &lbf[spos+4*qdim],
                       &lbf[spos+5*qdim], &lbf[spos+7*qdim], &lbf[spos+6*qdim], &lbf[spos+9*qdim],
                       &lbf[spos+8*qdim], &lbf[spos+11*qdim], &lbf[spos+10*qdim], &lbf[spos+13*qdim],
                       &lbf[spos+12*qdim]);
      break;
    case CCDRF:
      fD3Q27CCCInamuro(p0, uwall[0], -uwall[1], uwall[2], &lbf[spos], &lbf[spos+1*qdim],
                       &lbf[spos+15*qdim], &lbf[spos+3*qdim], &lbf[spos+5*qdim], &lbf[spos+4*qdim],
                       &lbf[spos+6*qdim], &lbf[spos+7*qdim], &lbf[spos+22*qdim], &lbf[spos+21*qdim],
                       &lbf[spos+12*qdim], &lbf[spos+13*qdim], &lbf[spos+10*qdim], &lbf[spos+11*qdim],
                       &lbf[spos+14*qdim], &lbf[spos+2*qdim], &lbf[spos+16*qdim], &lbf[spos+18*qdim],
                       &lbf[spos+17*qdim], &lbf[spos+19*qdim], &lbf[spos+20*qdim], &lbf[spos+9*qdim],
                       &lbf[spos+8*qdim], &lbf[spos+25*qdim], &lbf[spos+26*qdim], &lbf[spos+23*qdim],
                       &lbf[spos+24*qdim]);
      break;
    case CETR:
      fD3Q27CCEInamuro(p0, uwall[0], uwall[1], uwall[2], &lbf[spos], &lbf[spos+1*qdim],
                       &lbf[spos+2*qdim], &lbf[spos+3*qdim], &lbf[spos+4*qdim], &lbf[spos+5*qdim],
                       &lbf[spos+6*qdim], &lbf[spos+7*qdim], &lbf[spos+8*qdim], &lbf[spos+9*qdim],
                       &lbf[spos+10*qdim], &lbf[spos+11*qdim], &lbf[spos+12*qdim], &lbf[spos+13*qdim],
                       &lbf[spos+14*qdim], &lbf[spos+15*qdim], &lbf[spos+16*qdim], &lbf[spos+17*qdim],
                       &lbf[spos+18*qdim], &lbf[spos+19*qdim], &lbf[spos+20*qdim], &lbf[spos+21*qdim],
                       &lbf[spos+22*qdim], &lbf[spos+23*qdim], &lbf[spos+24*qdim], &lbf[spos+25*qdim],
                       &lbf[spos+26*qdim]);
      break;
    case CETL:
      fD3Q27CCEInamuro(p0, uwall[1], -uwall[0], uwall[2], &lbf[spos], &lbf[spos+2*qdim],
                       &lbf[spos+14*qdim], &lbf[spos+3*qdim], &lbf[spos+18*qdim], &lbf[spos+4*qdim],
                       &lbf[spos+8*qdim], &lbf[spos+9*qdim], &lbf[spos+20*qdim], &lbf[spos+19*qdim],
                       &lbf[spos+26*qdim], &lbf[spos+25*qdim], &lbf[spos+10*qdim], &lbf[spos+11*qdim],
                       &lbf[spos+15*qdim], &lbf[spos+1*qdim], &lbf[spos+16*qdim], &lbf[spos+5*qdim],
                       &lbf[spos+17*qdim], &lbf[spos+21*qdim], &lbf[spos+22*qdim], &lbf[spos+7*qdim],
                       &lbf[spos+6*qdim], &lbf[spos+13*qdim], &lbf[spos+12*qdim], &lbf[spos+23*qdim],
                       &lbf[spos+24*qdim]);
      break;
    case CEDL:
      fD3Q27CCEInamuro(p0, -uwall[0], -uwall[1], uwall[2], &lbf[spos], &lbf[spos+14*qdim],
                       &lbf[spos+15*qdim], &lbf[spos+3*qdim], &lbf[spos+17*qdim], &lbf[spos+18*qdim],
                       &lbf[spos+20*qdim], &lbf[spos+19*qdim], &lbf[spos+22*qdim], &lbf[spos+21*qdim],
                       &lbf[spos+24*qdim], &lbf[spos+23*qdim], &lbf[spos+26*qdim], &lbf[spos+25*qdim],
                       &lbf[spos+1*qdim], &lbf[spos+2*qdim], &lbf[spos+16*qdim], &lbf[spos+4*qdim],
                       &lbf[spos+5*qdim], &lbf[spos+7*qdim], &lbf[spos+6*qdim], &lbf[spos+9*qdim],
                       &lbf[spos+8*qdim], &lbf[spos+11*qdim], &lbf[spos+10*qdim], &lbf[spos+13*qdim],
                       &lbf[spos+12*qdim]);
      break;
    case CEDR:
      fD3Q27CCEInamuro(p0, -uwall[1], uwall[0], uwall[2], &lbf[spos], &lbf[spos+15*qdim],
                       &lbf[spos+1*qdim], &lbf[spos+3*qdim], &lbf[spos+5*qdim], &lbf[spos+17*qdim],
                       &lbf[spos+22*qdim], &lbf[spos+21*qdim], &lbf[spos+6*qdim], &lbf[spos+7*qdim],
                       &lbf[spos+12*qdim], &lbf[spos+13*qdim], &lbf[spos+24*qdim], &lbf[spos+23*qdim],
                       &lbf[spos+2*qdim], &lbf[spos+14*qdim], &lbf[spos+16*qdim], &lbf[spos+18*qdim],
                       &lbf[spos+4*qdim], &lbf[spos+9*qdim], &lbf[spos+8*qdim], &lbf[spos+19*qdim],
                       &lbf[spos+20*qdim], &lbf[spos+25*qdim], &lbf[spos+26*qdim], &lbf[spos+11*qdim],
                       &lbf[spos+10*qdim]);
      break;
    case CETF:
      fD3Q27CCEInamuro(p0, uwall[1], uwall[2], uwall[0], &lbf[spos], &lbf[spos+2*qdim],
                       &lbf[spos+3*qdim], &lbf[spos+1*qdim], &lbf[spos+8*qdim], &lbf[spos+9*qdim],
                       &lbf[spos+4*qdim], &lbf[spos+18*qdim], &lbf[spos+6*qdim], &lbf[spos+20*qdim],
                       &lbf[spos+10*qdim], &lbf[spos+26*qdim], &lbf[spos+11*qdim], &lbf[spos+25*qdim],
                       &lbf[spos+15*qdim], &lbf[spos+16*qdim], &lbf[spos+14*qdim], &lbf[spos+21*qdim],
                       &lbf[spos+22*qdim], &lbf[spos+17*qdim], &lbf[spos+5*qdim], &lbf[spos+19*qdim],
                       &lbf[spos+7*qdim], &lbf[spos+23*qdim], &lbf[spos+13*qdim], &lbf[spos+24*qdim],
                       &lbf[spos+12*qdim]);
      break;
    case CELF:
      fD3Q27CCEInamuro(p0, -uwall[0], uwall[1], uwall[2], &lbf[spos], &lbf[spos+14*qdim],
                       &lbf[spos+3*qdim], &lbf[spos+2*qdim], &lbf[spos+20*qdim], &lbf[spos+19*qdim],
                       &lbf[spos+18*qdim], &lbf[spos+17*qdim], &lbf[spos+8*qdim], &lbf[spos+22*qdim],
                       &lbf[spos+26*qdim], &lbf[spos+24*qdim], &lbf[spos+25*qdim], &lbf[spos+23*qdim],
                       &lbf[spos+1*qdim], &lbf[spos+16*qdim], &lbf[spos+15*qdim], &lbf[spos+7*qdim],
                       &lbf[spos+6*qdim], &lbf[spos+5*qdim], &lbf[spos+4*qdim], &lbf[spos+21*qdim],
                       &lbf[spos+9*qdim], &lbf[spos+13*qdim], &lbf[spos+11*qdim], &lbf[spos+12*qdim],
                       &lbf[spos+10*qdim]);
      break;
    case CEDF:
      fD3Q27CCEInamuro(p0, -uwall[1], uwall[2], uwall[0], &lbf[spos], &lbf[spos+15*qdim],
                       &lbf[spos+3*qdim], &lbf[spos+1*qdim], &lbf[spos+22*qdim], &lbf[spos+21*qdim],
                       &lbf[spos+5*qdim], &lbf[spos+17*qdim], &lbf[spos+6*qdim], &lbf[spos+20*qdim],
                       &lbf[spos+12*qdim], &lbf[spos+24*qdim], &lbf[spos+13*qdim], &lbf[spos+23*qdim],
                       &lbf[spos+2*qdim], &lbf[spos+16*qdim], &lbf[spos+14*qdim], &lbf[spos+9*qdim],
                       &lbf[spos+8*qdim], &lbf[spos+18*qdim], &lbf[spos+4*qdim], &lbf[spos+19*qdim],
                       &lbf[spos+7*qdim], &lbf[spos+25*qdim], &lbf[spos+11*qdim], &lbf[spos+26*qdim],
                       &lbf[spos+10*qdim]);
      break;
    case CERF:
      fD3Q27CCEInamuro(p0, uwall[0], uwall[2], uwall[2], &lbf[spos], &lbf[spos+1*qdim],
                       &lbf[spos+3*qdim], &lbf[spos+2*qdim], &lbf[spos+6*qdim], &lbf[spos+7*qdim],
                       &lbf[spos+4*qdim], &lbf[spos+5*qdim], &lbf[spos+8*qdim], &lbf[spos+22*qdim],
                       &lbf[spos+10*qdim], &lbf[spos+12*qdim], &lbf[spos+11*qdim], &lbf[spos+13*qdim],
                       &lbf[spos+14*qdim], &lbf[spos+16*qdim], &lbf[spos+15*qdim], &lbf[spos+19*qdim],
                       &lbf[spos+20*qdim], &lbf[spos+17*qdim], &lbf[spos+18*qdim], &lbf[spos+21*qdim],
                       &lbf[spos+9*qdim], &lbf[spos+23*qdim], &lbf[spos+25*qdim], &lbf[spos+24*qdim],
                       &lbf[spos+26*qdim]);
      break;
    case CETB:
      fD3Q27CCEInamuro(p0, uwall[1], -uwall[2], uwall[0], &lbf[spos], &lbf[spos+2*qdim],
                       &lbf[spos+16*qdim], &lbf[spos+1*qdim], &lbf[spos+9*qdim], &lbf[spos+8*qdim],
                       &lbf[spos+4*qdim], &lbf[spos+18*qdim], &lbf[spos+7*qdim], &lbf[spos+19*qdim],
                       &lbf[spos+11*qdim], &lbf[spos+25*qdim], &lbf[spos+10*qdim], &lbf[spos+26*qdim],
                       &lbf[spos+15*qdim], &lbf[spos+3*qdim], &lbf[spos+14*qdim], &lbf[spos+22*qdim],
                       &lbf[spos+21*qdim], &lbf[spos+17*qdim], &lbf[spos+5*qdim], &lbf[spos+20*qdim],
                       &lbf[spos+6*qdim], &lbf[spos+24*qdim], &lbf[spos+12*qdim], &lbf[spos+23*qdim],
                       &lbf[spos+13*qdim]);
      break;
    case CELB:
      fD3Q27CCEInamuro(p0, -uwall[0], -uwall[2], uwall[1], &lbf[spos], &lbf[spos+14*qdim],
                       &lbf[spos+16*qdim], &lbf[spos+2*qdim], &lbf[spos+19*qdim], &lbf[spos+20*qdim],
                       &lbf[spos+18*qdim], &lbf[spos+17*qdim], &lbf[spos+9*qdim], &lbf[spos+21*qdim],
                       &lbf[spos+25*qdim], &lbf[spos+23*qdim], &lbf[spos+26*qdim], &lbf[spos+24*qdim],
                       &lbf[spos+1*qdim], &lbf[spos+3*qdim], &lbf[spos+15*qdim], &lbf[spos+6*qdim],
                       &lbf[spos+7*qdim], &lbf[spos+5*qdim], &lbf[spos+4*qdim], &lbf[spos+22*qdim],
                       &lbf[spos+8*qdim], &lbf[spos+12*qdim], &lbf[spos+10*qdim], &lbf[spos+13*qdim],
                       &lbf[spos+11*qdim]);
      break;
    case CEDB:
      fD3Q27CCEInamuro(p0, -uwall[1], -uwall[2], uwall[0], &lbf[spos], &lbf[spos+15*qdim],
                       &lbf[spos+16*qdim], &lbf[spos+1*qdim], &lbf[spos+21*qdim], &lbf[spos+22*qdim],
                       &lbf[spos+5*qdim], &lbf[spos+17*qdim], &lbf[spos+7*qdim], &lbf[spos+19*qdim],
                       &lbf[spos+13*qdim], &lbf[spos+23*qdim], &lbf[spos+12*qdim], &lbf[spos+24*qdim],
                       &lbf[spos+2*qdim], &lbf[spos+3*qdim], &lbf[spos+14*qdim], &lbf[spos+8*qdim],
                       &lbf[spos+9*qdim], &lbf[spos+18*qdim], &lbf[spos+4*qdim], &lbf[spos+20*qdim],
                       &lbf[spos+6*qdim], &lbf[spos+26*qdim], &lbf[spos+10*qdim], &lbf[spos+25*qdim],
                       &lbf[spos+11*qdim]);
      break;
    case CERB:
      fD3Q27CCEInamuro(p0, uwall[0], -uwall[2], uwall[1], &lbf[spos], &lbf[spos+1*qdim],
                       &lbf[spos+16*qdim], &lbf[spos+2*qdim], &lbf[spos+7*qdim], &lbf[spos+6*qdim],
                       &lbf[spos+4*qdim], &lbf[spos+5*qdim], &lbf[spos+9*qdim], &lbf[spos+21*qdim],
                       &lbf[spos+11*qdim], &lbf[spos+13*qdim], &lbf[spos+10*qdim], &lbf[spos+12*qdim],
                       &lbf[spos+14*qdim], &lbf[spos+3*qdim], &lbf[spos+15*qdim], &lbf[spos+20*qdim],
                       &lbf[spos+19*qdim], &lbf[spos+17*qdim], &lbf[spos+18*qdim], &lbf[spos+22*qdim],
                       &lbf[spos+8*qdim], &lbf[spos+24*qdim], &lbf[spos+26*qdim], &lbf[spos+23*qdim],
                       &lbf[spos+25*qdim]);
      break;
  }
  return 0;
}



int fD3Q27TPSInamuro(double p, double v0, double v1, double v2, double *f0, double *f1,
                     double *f2, double *f3, double *f4, double *f5, double *f6,
                     double *f7, double *f8, double *f9, double *f10, double *f11,
                     double *f12, double *f13, double *f14, double *f15, double *f16,
                     double *f17, double *f18, double *f19, double *f20, double *f21,
                     double *f22, double *f23, double *f24, double *f25, double *f26)
{

  // produce fixed temperature at planar surface: expressed for bottom wall

  double rhop;
  double c1=2.0/27.0,c2=1.0/54.0,c3=1.0/216.0;
  rhop=6.0*(p-f0[0]-f1[0]-f2[0]-f3[0]-f4[0]-f6[0]-f7[0]-f8[0]-f9[0]-f10[0]-f11[0]-f14[0]-f16[0]-f18[0]-f19[0]-f20[0]-f25[0]-f26[0])/(1.0+3.0*v1);
  f5[0]=c2*rhop*(1.0-3.0*v0+3.0*v1);
  f12[0]=c3*rhop*(1.0-3.0*v0+3.0*v1-3.0*v2);
  f13[0]=c3*rhop*(1.0-3.0*v0+3.0*v1+3.0*v2);
  f15[0]=c1*rhop*(1.0+3.0*v1);
  f17[0]=c2*rhop*(1.0+3.0*v0+3.0*v1);
  f21[0]=c2*rhop*(1.0+3.0*v1+3.0*v2);
  f22[0]=c2*rhop*(1.0+3.0*v1-3.0*v2);
  f23[0]=c3*rhop*(1.0+3.0*v0+3.0*v1+3.0*v2);
  f24[0]=c3*rhop*(1.0+3.0*v0+3.0*v1-3.0*v2);
  return 0;
}

int fD3Q27TCEInamuro(double p, double v0, double v1, double v2, double *f0, double *f1,
                     double *f2, double *f3, double *f4, double *f5, double *f6,
                     double *f7, double *f8, double *f9, double *f10, double *f11,
                     double *f12, double *f13, double *f14, double *f15, double *f16,
                     double *f17, double *f18, double *f19, double *f20, double *f21,
                     double *f22, double *f23, double *f24, double *f25, double *f26)
{

  // produce fixed temperature at concave edge: expressed for bottom left edge (TCETR)

  double rhop;
  double c1=2.0/27.0,c2=1.0/54.0,c3=1.0/216.0;
  rhop=36.0*(p-f0[0]-f1[0]-f2[0]-f3[0]-f4[0]-f6[0]-f7[0]-f8[0]-f9[0]-f10[0]-f11[0]-f16[0])/(11.0+15.0*(v0+v1));
  f5[0]=c2*rhop*(1.0-3.0*v0+3.0*v1);
  f12[0]=c3*rhop*(1.0-3.0*v0+3.0*v1-3.0*v2);
  f13[0]=c3*rhop*(1.0-3.0*v0+3.0*v1+3.0*v2);
  f14[0]=c1*rhop*(1.0+3.0*v0);
  f15[0]=c1*rhop*(1.0+3.0*v1);
  f17[0]=c2*rhop*(1.0+3.0*v0+3.0*v1);
  f18[0]=c2*rhop*(1.0+3.0*v0-3.0*v1);
  f19[0]=c2*rhop*(1.0+3.0*v0+3.0*v2);
  f20[0]=c2*rhop*(1.0+3.0*v0-3.0*v2);
  f21[0]=c2*rhop*(1.0+3.0*v1+3.0*v2);
  f22[0]=c2*rhop*(1.0+3.0*v1-3.0*v2);
  f23[0]=c3*rhop*(1.0+3.0*v0+3.0*v1+3.0*v2);
  f24[0]=c3*rhop*(1.0+3.0*v0+3.0*v1-3.0*v2);
  f25[0]=c3*rhop*(1.0+3.0*v0-3.0*v1+3.0*v2);
  f26[0]=c3*rhop*(1.0+3.0*v0-3.0*v1-3.0*v2);
  return 0;
}

int fD3Q27TCCInamuro(double p, double v0, double v1, double v2, double *f0, double *f1,
                     double *f2, double *f3, double *f4, double *f5, double *f6,
                     double *f7, double *f8, double *f9, double *f10, double *f11,
                     double *f12, double *f13, double *f14, double *f15, double *f16,
                     double *f17, double *f18, double *f19, double *f20, double *f21,
                     double *f22, double *f23, double *f24, double *f25, double *f26)
{

  // produce fixed temperature at concave corner: expressed for bottom left back corner (TCCTRF)

  double rhop;
  double c1=2.0/27.0,c2=1.0/54.0,c3=1.0/216.0;
  rhop=216.0*(p-f0[0]-f1[0]-f2[0]-f3[0]-f4[0]-f6[0]-f8[0]-f10[0])/(91.0+75.0*(v0+v1+v2));
  f5[0]=c2*rhop*(1.0-3.0*v0+3.0*v1);
  f7[0]=c2*rhop*(1.0-3.0*v0+3.0*v2);
  f9[0]=c2*rhop*(1.0-3.0*v1+3.0*v2);
  f11[0]=c3*rhop*(1.0-3.0*v0-3.0*v1+3.0*v2);
  f12[0]=c3*rhop*(1.0-3.0*v0+3.0*v1-3.0*v2);
  f13[0]=c3*rhop*(1.0-3.0*v0+3.0*v1+3.0*v2);
  f14[0]=c1*rhop*(1.0+3.0*v0);
  f15[0]=c1*rhop*(1.0+3.0*v1);
  f16[0]=c1*rhop*(1.0+3.0*v2);
  f17[0]=c2*rhop*(1.0+3.0*v0+3.0*v1);
  f18[0]=c2*rhop*(1.0+3.0*v0-3.0*v1);
  f19[0]=c2*rhop*(1.0+3.0*v0+3.0*v2);
  f20[0]=c2*rhop*(1.0+3.0*v0-3.0*v2);
  f21[0]=c2*rhop*(1.0+3.0*v1+3.0*v2);
  f22[0]=c2*rhop*(1.0+3.0*v1-3.0*v2);
  f23[0]=c3*rhop*(1.0+3.0*v0+3.0*v1+3.0*v2);
  f24[0]=c3*rhop*(1.0+3.0*v0+3.0*v1-3.0*v2);
  f25[0]=c3*rhop*(1.0+3.0*v0-3.0*v1+3.0*v2);
  f26[0]=c3*rhop*(1.0+3.0*v0-3.0*v1-3.0*v2);
  return 0;
}


int fD3Q27PTInamuro(long tpos, int prop, double p0, double *uwall)
{
  long spos=tpos * lbsitelength + (lbsy.nf + lbsy.nc);
  int qdim=lbsy.nf+lbsy.nc+lbsy.nt;
    
  switch (prop) {
    case PST:
      fD3Q27TPSInamuro(p0, uwall[0], uwall[1], uwall[2], &lbf[spos], &lbf[spos+1*qdim],
                       &lbf[spos+2*qdim], &lbf[spos+3*qdim], &lbf[spos+4*qdim], &lbf[spos+5*qdim], &lbf[spos+6*qdim],
                       &lbf[spos+7*qdim], &lbf[spos+8*qdim], &lbf[spos+9*qdim], &lbf[spos+10*qdim], &lbf[spos+11*qdim],
                       &lbf[spos+12*qdim], &lbf[spos+13*qdim], &lbf[spos+14*qdim], &lbf[spos+15*qdim], &lbf[spos+16*qdim],
                       &lbf[spos+17*qdim], &lbf[spos+18*qdim], &lbf[spos+19*qdim], &lbf[spos+20*qdim], &lbf[spos+21*qdim],
                       &lbf[spos+22*qdim], &lbf[spos+23*qdim], &lbf[spos+24*qdim], &lbf[spos+25*qdim], &lbf[spos+26*qdim]);
      break;
    case PSD:
      fD3Q27TPSInamuro(p0, -uwall[0], -uwall[1], -uwall[2], &lbf[spos], &lbf[spos+14*qdim],
                       &lbf[spos+15*qdim], &lbf[spos+16*qdim], &lbf[spos+17*qdim], &lbf[spos+18*qdim], &lbf[spos+19*qdim],
                       &lbf[spos+20*qdim], &lbf[spos+21*qdim], &lbf[spos+22*qdim], &lbf[spos+23*qdim], &lbf[spos+24*qdim],
                       &lbf[spos+25*qdim], &lbf[spos+26*qdim], &lbf[spos+1*qdim], &lbf[spos+2*qdim], &lbf[spos+3*qdim],
                       &lbf[spos+4*qdim], &lbf[spos+5*qdim], &lbf[spos+6*qdim], &lbf[spos+7*qdim], &lbf[spos+8*qdim],
                       &lbf[spos+9*qdim], &lbf[spos+10*qdim], &lbf[spos+11*qdim], &lbf[spos+12*qdim], &lbf[spos+13*qdim]);
      break;
    case PSL:
      fD3Q27TPSInamuro(p0, -uwall[2], -uwall[0], -uwall[1], &lbf[spos], &lbf[spos+16*qdim],
                       &lbf[spos+14*qdim], &lbf[spos+15*qdim], &lbf[spos+19*qdim], &lbf[spos+7*qdim], &lbf[spos+21*qdim],
                       &lbf[spos+9*qdim], &lbf[spos+17*qdim], &lbf[spos+18*qdim], &lbf[spos+23*qdim], &lbf[spos+25*qdim],
                       &lbf[spos+13*qdim], &lbf[spos+11*qdim], &lbf[spos+3*qdim], &lbf[spos+1*qdim], &lbf[spos+2*qdim],
                       &lbf[spos+6*qdim], &lbf[spos+20*qdim], &lbf[spos+8*qdim], &lbf[spos+22*qdim], &lbf[spos+4*qdim],
                       &lbf[spos+5*qdim], &lbf[spos+10*qdim], &lbf[spos+12*qdim], &lbf[spos+26*qdim], &lbf[spos+24*qdim]);
      break;
    case PSR:
      fD3Q27TPSInamuro(p0, uwall[2], uwall[0], uwall[1], &lbf[spos], &lbf[spos+3*qdim],
                       &lbf[spos+1*qdim], &lbf[spos+2*qdim], &lbf[spos+6*qdim], &lbf[spos+20*qdim], &lbf[spos+8*qdim],
                       &lbf[spos+22*qdim], &lbf[spos+4*qdim], &lbf[spos+5*qdim], &lbf[spos+10*qdim], &lbf[spos+12*qdim],
                       &lbf[spos+26*qdim], &lbf[spos+24*qdim], &lbf[spos+16*qdim], &lbf[spos+14*qdim], &lbf[spos+15*qdim],
                       &lbf[spos+19*qdim], &lbf[spos+7*qdim], &lbf[spos+21*qdim], &lbf[spos+9*qdim], &lbf[spos+17*qdim],
                       &lbf[spos+18*qdim], &lbf[spos+23*qdim], &lbf[spos+25*qdim], &lbf[spos+13*qdim], &lbf[spos+11*qdim]);
      break;
    case PSF:
      fD3Q27TPSInamuro(p0, -uwall[1], -uwall[2], -uwall[0], &lbf[spos], &lbf[spos+15*qdim],
                       &lbf[spos+16*qdim], &lbf[spos+14*qdim], &lbf[spos+21*qdim], &lbf[spos+22*qdim], &lbf[spos+17*qdim],
                       &lbf[spos+5*qdim], &lbf[spos+19*qdim], &lbf[spos+7*qdim], &lbf[spos+23*qdim], &lbf[spos+13*qdim],
                       &lbf[spos+24*qdim], &lbf[spos+12*qdim], &lbf[spos+2*qdim], &lbf[spos+3*qdim], &lbf[spos+1*qdim],
                       &lbf[spos+8*qdim], &lbf[spos+9*qdim], &lbf[spos+4*qdim], &lbf[spos+18*qdim], &lbf[spos+6*qdim],
                       &lbf[spos+20*qdim], &lbf[spos+10*qdim], &lbf[spos+26*qdim], &lbf[spos+11*qdim], &lbf[spos+25*qdim]);
      break;
    case PSB:
      fD3Q27TPSInamuro(p0, uwall[1], uwall[2], uwall[0], &lbf[spos], &lbf[spos+2*qdim],
                       &lbf[spos+3*qdim], &lbf[spos+1*qdim], &lbf[spos+8*qdim], &lbf[spos+9*qdim], &lbf[spos+4*qdim],
                       &lbf[spos+18*qdim], &lbf[spos+6*qdim], &lbf[spos+20*qdim], &lbf[spos+10*qdim], &lbf[spos+26*qdim],
                       &lbf[spos+11*qdim], &lbf[spos+25*qdim], &lbf[spos+15*qdim], &lbf[spos+16*qdim], &lbf[spos+14*qdim],
                       &lbf[spos+21*qdim], &lbf[spos+22*qdim], &lbf[spos+17*qdim], &lbf[spos+5*qdim], &lbf[spos+19*qdim],
                       &lbf[spos+7*qdim], &lbf[spos+23*qdim], &lbf[spos+13*qdim], &lbf[spos+24*qdim], &lbf[spos+12*qdim]);
      break;
    case CCTRB:
      fD3Q27TCCInamuro(p0, uwall[0], uwall[1], -uwall[2], &lbf[spos], &lbf[spos+1*qdim],
                       &lbf[spos+2*qdim], &lbf[spos+16*qdim], &lbf[spos+4*qdim], &lbf[spos+5*qdim],
                       &lbf[spos+7*qdim], &lbf[spos+6*qdim], &lbf[spos+9*qdim], &lbf[spos+8*qdim],
                       &lbf[spos+11*qdim], &lbf[spos+10*qdim], &lbf[spos+13*qdim], &lbf[spos+12*qdim],
                       &lbf[spos+14*qdim], &lbf[spos+15*qdim], &lbf[spos+3*qdim], &lbf[spos+17*qdim],
                       &lbf[spos+18*qdim], &lbf[spos+20*qdim], &lbf[spos+19*qdim], &lbf[spos+22*qdim],
                       &lbf[spos+21*qdim], &lbf[spos+24*qdim], &lbf[spos+23*qdim], &lbf[spos+26*qdim],
                       &lbf[spos+25*qdim]);
      break;
    case CCTLB:
      fD3Q27TCCInamuro(p0, -uwall[0], uwall[1], -uwall[2], &lbf[spos], &lbf[spos+14*qdim],
                       &lbf[spos+2*qdim], &lbf[spos+16*qdim], &lbf[spos+18*qdim], &lbf[spos+17*qdim],
                       &lbf[spos+19*qdim], &lbf[spos+20*qdim], &lbf[spos+9*qdim], &lbf[spos+8*qdim],
                       &lbf[spos+25*qdim], &lbf[spos+26*qdim], &lbf[spos+23*qdim], &lbf[spos+24*qdim],
                       &lbf[spos+1*qdim], &lbf[spos+15*qdim], &lbf[spos+3*qdim], &lbf[spos+5*qdim],
                       &lbf[spos+4*qdim], &lbf[spos+6*qdim], &lbf[spos+7*qdim], &lbf[spos+22*qdim],
                       &lbf[spos+21*qdim], &lbf[spos+12*qdim], &lbf[spos+13*qdim], &lbf[spos+10*qdim],
                       &lbf[spos+11*qdim]);
      break;
    case CCDLB:
      fD3Q27TCCInamuro(p0, -uwall[0], -uwall[1], -uwall[2], &lbf[spos], &lbf[spos+14*qdim],
                       &lbf[spos+15*qdim], &lbf[spos+16*qdim], &lbf[spos+17*qdim], &lbf[spos+18*qdim],
                       &lbf[spos+19*qdim], &lbf[spos+20*qdim], &lbf[spos+21*qdim], &lbf[spos+22*qdim],
                       &lbf[spos+23*qdim], &lbf[spos+24*qdim], &lbf[spos+25*qdim], &lbf[spos+26*qdim],
                       &lbf[spos+1*qdim], &lbf[spos+2*qdim], &lbf[spos+3*qdim], &lbf[spos+4*qdim],
                       &lbf[spos+5*qdim], &lbf[spos+6*qdim], &lbf[spos+7*qdim], &lbf[spos+8*qdim],
                       &lbf[spos+9*qdim], &lbf[spos+10*qdim], &lbf[spos+11*qdim], &lbf[spos+12*qdim],
                       &lbf[spos+13*qdim]);
      break;
    case CCDRB:
      fD3Q27TCCInamuro(p0, uwall[0], -uwall[1], -uwall[2], &lbf[spos], &lbf[spos+1*qdim],
                       &lbf[spos+15*qdim], &lbf[spos+16*qdim], &lbf[spos+5*qdim], &lbf[spos+4*qdim],
                       &lbf[spos+7*qdim], &lbf[spos+6*qdim], &lbf[spos+21*qdim], &lbf[spos+22*qdim],
                       &lbf[spos+13*qdim], &lbf[spos+12*qdim], &lbf[spos+11*qdim], &lbf[spos+10*qdim],
                       &lbf[spos+14*qdim], &lbf[spos+2*qdim], &lbf[spos+3*qdim], &lbf[spos+18*qdim],
                       &lbf[spos+17*qdim], &lbf[spos+20*qdim], &lbf[spos+19*qdim], &lbf[spos+8*qdim],
                       &lbf[spos+9*qdim], &lbf[spos+26*qdim], &lbf[spos+25*qdim], &lbf[spos+24*qdim],
                       &lbf[spos+23*qdim]);
      break;
    case CCTRF:
      fD3Q27TCCInamuro(p0, uwall[0], uwall[1], uwall[2], &lbf[spos], &lbf[spos+1*qdim],
                       &lbf[spos+2*qdim], &lbf[spos+3*qdim], &lbf[spos+4*qdim], &lbf[spos+5*qdim],
                       &lbf[spos+6*qdim], &lbf[spos+7*qdim], &lbf[spos+8*qdim], &lbf[spos+9*qdim],
                       &lbf[spos+10*qdim], &lbf[spos+11*qdim], &lbf[spos+12*qdim], &lbf[spos+13*qdim],
                       &lbf[spos+14*qdim], &lbf[spos+15*qdim], &lbf[spos+16*qdim], &lbf[spos+17*qdim],
                       &lbf[spos+18*qdim], &lbf[spos+19*qdim], &lbf[spos+20*qdim], &lbf[spos+21*qdim],
                       &lbf[spos+22*qdim], &lbf[spos+23*qdim], &lbf[spos+24*qdim], &lbf[spos+25*qdim],
                       &lbf[spos+26*qdim]);
      break;
    case CCTLF:
      fD3Q27TCCInamuro(p0, -uwall[0], uwall[1], uwall[2], &lbf[spos], &lbf[spos+14*qdim],
                       &lbf[spos+2*qdim], &lbf[spos+3*qdim], &lbf[spos+18*qdim], &lbf[spos+17*qdim],
                       &lbf[spos+20*qdim], &lbf[spos+19*qdim], &lbf[spos+8*qdim], &lbf[spos+9*qdim],
                       &lbf[spos+26*qdim], &lbf[spos+25*qdim], &lbf[spos+24*qdim], &lbf[spos+23*qdim],
                       &lbf[spos+1*qdim], &lbf[spos+15*qdim], &lbf[spos+16*qdim], &lbf[spos+5*qdim],
                       &lbf[spos+4*qdim], &lbf[spos+7*qdim], &lbf[spos+6*qdim], &lbf[spos+21*qdim],
                       &lbf[spos+22*qdim], &lbf[spos+13*qdim], &lbf[spos+12*qdim], &lbf[spos+11*qdim],
                       &lbf[spos+10*qdim]);
      break;
    case CCDLF:
      fD3Q27TCCInamuro(p0, -uwall[0], -uwall[1], uwall[2], &lbf[spos], &lbf[spos+14*qdim],
                       &lbf[spos+15*qdim], &lbf[spos+3*qdim], &lbf[spos+17*qdim], &lbf[spos+18*qdim],
                       &lbf[spos+20*qdim], &lbf[spos+19*qdim], &lbf[spos+22*qdim], &lbf[spos+21*qdim],
                       &lbf[spos+24*qdim], &lbf[spos+23*qdim], &lbf[spos+26*qdim], &lbf[spos+25*qdim],
                       &lbf[spos+1*qdim], &lbf[spos+2*qdim], &lbf[spos+16*qdim], &lbf[spos+4*qdim],
                       &lbf[spos+5*qdim], &lbf[spos+7*qdim], &lbf[spos+6*qdim], &lbf[spos+9*qdim],
                       &lbf[spos+8*qdim], &lbf[spos+11*qdim], &lbf[spos+10*qdim], &lbf[spos+13*qdim],
                       &lbf[spos+12*qdim]);
      break;
    case CCDRF:
      fD3Q27TCCInamuro(p0, uwall[0], -uwall[1], uwall[2], &lbf[spos], &lbf[spos+1*qdim],
                       &lbf[spos+15*qdim], &lbf[spos+3*qdim], &lbf[spos+5*qdim], &lbf[spos+4*qdim],
                       &lbf[spos+6*qdim], &lbf[spos+7*qdim], &lbf[spos+22*qdim], &lbf[spos+21*qdim],
                       &lbf[spos+12*qdim], &lbf[spos+13*qdim], &lbf[spos+10*qdim], &lbf[spos+11*qdim],
                       &lbf[spos+14*qdim], &lbf[spos+2*qdim], &lbf[spos+16*qdim], &lbf[spos+18*qdim],
                       &lbf[spos+17*qdim], &lbf[spos+19*qdim], &lbf[spos+20*qdim], &lbf[spos+9*qdim],
                       &lbf[spos+8*qdim], &lbf[spos+25*qdim], &lbf[spos+26*qdim], &lbf[spos+23*qdim],
                       &lbf[spos+24*qdim]);
      break;
    case CETR:
      fD3Q27TCEInamuro(p0, uwall[0], uwall[1], uwall[2], &lbf[spos], &lbf[spos+1*qdim],
                       &lbf[spos+2*qdim], &lbf[spos+3*qdim], &lbf[spos+4*qdim], &lbf[spos+5*qdim],
                       &lbf[spos+6*qdim], &lbf[spos+7*qdim], &lbf[spos+8*qdim], &lbf[spos+9*qdim],
                       &lbf[spos+10*qdim], &lbf[spos+11*qdim], &lbf[spos+12*qdim], &lbf[spos+13*qdim],
                       &lbf[spos+14*qdim], &lbf[spos+15*qdim], &lbf[spos+16*qdim], &lbf[spos+17*qdim],
                       &lbf[spos+18*qdim], &lbf[spos+19*qdim], &lbf[spos+20*qdim], &lbf[spos+21*qdim],
                       &lbf[spos+22*qdim], &lbf[spos+23*qdim], &lbf[spos+24*qdim], &lbf[spos+25*qdim],
                       &lbf[spos+26*qdim]);
      break;
    case CETL:
      fD3Q27TCEInamuro(p0, uwall[1], -uwall[0], uwall[2], &lbf[spos], &lbf[spos+2*qdim],
                       &lbf[spos+14*qdim], &lbf[spos+3*qdim], &lbf[spos+18*qdim], &lbf[spos+4*qdim],
                       &lbf[spos+8*qdim], &lbf[spos+9*qdim], &lbf[spos+20*qdim], &lbf[spos+19*qdim],
                       &lbf[spos+26*qdim], &lbf[spos+25*qdim], &lbf[spos+10*qdim], &lbf[spos+11*qdim],
                       &lbf[spos+15*qdim], &lbf[spos+1*qdim], &lbf[spos+16*qdim], &lbf[spos+5*qdim],
                       &lbf[spos+17*qdim], &lbf[spos+21*qdim], &lbf[spos+22*qdim], &lbf[spos+7*qdim],
                       &lbf[spos+6*qdim], &lbf[spos+13*qdim], &lbf[spos+12*qdim], &lbf[spos+23*qdim],
                       &lbf[spos+24*qdim]);
      break;
    case CEDL:
      fD3Q27TCEInamuro(p0, -uwall[0], -uwall[1], uwall[2], &lbf[spos], &lbf[spos+14*qdim],
                       &lbf[spos+15*qdim], &lbf[spos+3*qdim], &lbf[spos+17*qdim], &lbf[spos+18*qdim],
                       &lbf[spos+20*qdim], &lbf[spos+19*qdim], &lbf[spos+22*qdim], &lbf[spos+21*qdim],
                       &lbf[spos+24*qdim], &lbf[spos+23*qdim], &lbf[spos+26*qdim], &lbf[spos+25*qdim],
                       &lbf[spos+1*qdim], &lbf[spos+2*qdim], &lbf[spos+16*qdim], &lbf[spos+4*qdim],
                       &lbf[spos+5*qdim], &lbf[spos+7*qdim], &lbf[spos+6*qdim], &lbf[spos+9*qdim],
                       &lbf[spos+8*qdim], &lbf[spos+11*qdim], &lbf[spos+10*qdim], &lbf[spos+13*qdim],
                       &lbf[spos+12*qdim]);
      break;
    case CEDR:
      fD3Q27TCEInamuro(p0, -uwall[1], uwall[0], uwall[2], &lbf[spos], &lbf[spos+15*qdim],
                       &lbf[spos+1*qdim], &lbf[spos+3*qdim], &lbf[spos+5*qdim], &lbf[spos+17*qdim],
                       &lbf[spos+22*qdim], &lbf[spos+21*qdim], &lbf[spos+6*qdim], &lbf[spos+7*qdim],
                       &lbf[spos+12*qdim], &lbf[spos+13*qdim], &lbf[spos+24*qdim], &lbf[spos+23*qdim],
                       &lbf[spos+2*qdim], &lbf[spos+14*qdim], &lbf[spos+16*qdim], &lbf[spos+18*qdim],
                       &lbf[spos+4*qdim], &lbf[spos+9*qdim], &lbf[spos+8*qdim], &lbf[spos+19*qdim],
                       &lbf[spos+20*qdim], &lbf[spos+25*qdim], &lbf[spos+26*qdim], &lbf[spos+11*qdim],
                       &lbf[spos+10*qdim]);
      break;
    case CETF:
      fD3Q27TCEInamuro(p0, uwall[1], uwall[2], uwall[0], &lbf[spos], &lbf[spos+2*qdim],
                       &lbf[spos+3*qdim], &lbf[spos+1*qdim], &lbf[spos+8*qdim], &lbf[spos+9*qdim],
                       &lbf[spos+4*qdim], &lbf[spos+18*qdim], &lbf[spos+6*qdim], &lbf[spos+20*qdim],
                       &lbf[spos+10*qdim], &lbf[spos+26*qdim], &lbf[spos+11*qdim], &lbf[spos+25*qdim],
                       &lbf[spos+15*qdim], &lbf[spos+16*qdim], &lbf[spos+14*qdim], &lbf[spos+21*qdim],
                       &lbf[spos+22*qdim], &lbf[spos+17*qdim], &lbf[spos+5*qdim], &lbf[spos+19*qdim],
                       &lbf[spos+7*qdim], &lbf[spos+23*qdim], &lbf[spos+13*qdim], &lbf[spos+24*qdim],
                       &lbf[spos+12*qdim]);
      break;
    case CELF:
      fD3Q27TCEInamuro(p0, -uwall[0], uwall[1], uwall[2], &lbf[spos], &lbf[spos+14*qdim],
                       &lbf[spos+3*qdim], &lbf[spos+2*qdim], &lbf[spos+20*qdim], &lbf[spos+19*qdim],
                       &lbf[spos+18*qdim], &lbf[spos+17*qdim], &lbf[spos+8*qdim], &lbf[spos+22*qdim],
                       &lbf[spos+26*qdim], &lbf[spos+24*qdim], &lbf[spos+25*qdim], &lbf[spos+23*qdim],
                       &lbf[spos+1*qdim], &lbf[spos+16*qdim], &lbf[spos+15*qdim], &lbf[spos+7*qdim],
                       &lbf[spos+6*qdim], &lbf[spos+5*qdim], &lbf[spos+4*qdim], &lbf[spos+21*qdim],
                       &lbf[spos+9*qdim], &lbf[spos+13*qdim], &lbf[spos+11*qdim], &lbf[spos+12*qdim],
                       &lbf[spos+10*qdim]);
      break;
    case CEDF:
      fD3Q27TCEInamuro(p0, -uwall[1], uwall[2], uwall[0], &lbf[spos], &lbf[spos+15*qdim],
                       &lbf[spos+3*qdim], &lbf[spos+1*qdim], &lbf[spos+22*qdim], &lbf[spos+21*qdim],
                       &lbf[spos+5*qdim], &lbf[spos+17*qdim], &lbf[spos+6*qdim], &lbf[spos+20*qdim],
                       &lbf[spos+12*qdim], &lbf[spos+24*qdim], &lbf[spos+13*qdim], &lbf[spos+23*qdim],
                       &lbf[spos+2*qdim], &lbf[spos+16*qdim], &lbf[spos+14*qdim], &lbf[spos+9*qdim],
                       &lbf[spos+8*qdim], &lbf[spos+18*qdim], &lbf[spos+4*qdim], &lbf[spos+19*qdim],
                       &lbf[spos+7*qdim], &lbf[spos+25*qdim], &lbf[spos+11*qdim], &lbf[spos+26*qdim],
                       &lbf[spos+10*qdim]);
      break;
    case CERF:
      fD3Q27TCEInamuro(p0, uwall[0], uwall[2], uwall[2], &lbf[spos], &lbf[spos+1*qdim],
                       &lbf[spos+3*qdim], &lbf[spos+2*qdim], &lbf[spos+6*qdim], &lbf[spos+7*qdim],
                       &lbf[spos+4*qdim], &lbf[spos+5*qdim], &lbf[spos+8*qdim], &lbf[spos+22*qdim],
                       &lbf[spos+10*qdim], &lbf[spos+12*qdim], &lbf[spos+11*qdim], &lbf[spos+13*qdim],
                       &lbf[spos+14*qdim], &lbf[spos+16*qdim], &lbf[spos+15*qdim], &lbf[spos+19*qdim],
                       &lbf[spos+20*qdim], &lbf[spos+17*qdim], &lbf[spos+18*qdim], &lbf[spos+21*qdim],
                       &lbf[spos+9*qdim], &lbf[spos+23*qdim], &lbf[spos+25*qdim], &lbf[spos+24*qdim],
                       &lbf[spos+26*qdim]);
      break;
    case CETB:
      fD3Q27TCEInamuro(p0, uwall[1], -uwall[2], uwall[0], &lbf[spos], &lbf[spos+2*qdim],
                       &lbf[spos+16*qdim], &lbf[spos+1*qdim], &lbf[spos+9*qdim], &lbf[spos+8*qdim],
                       &lbf[spos+4*qdim], &lbf[spos+18*qdim], &lbf[spos+7*qdim], &lbf[spos+19*qdim],
                       &lbf[spos+11*qdim], &lbf[spos+25*qdim], &lbf[spos+10*qdim], &lbf[spos+26*qdim],
                       &lbf[spos+15*qdim], &lbf[spos+3*qdim], &lbf[spos+14*qdim], &lbf[spos+22*qdim],
                       &lbf[spos+21*qdim], &lbf[spos+17*qdim], &lbf[spos+5*qdim], &lbf[spos+20*qdim],
                       &lbf[spos+6*qdim], &lbf[spos+24*qdim], &lbf[spos+12*qdim], &lbf[spos+23*qdim],
                       &lbf[spos+13*qdim]);
      break;
    case CELB:
      fD3Q27TCEInamuro(p0, -uwall[0], -uwall[2], uwall[1], &lbf[spos], &lbf[spos+14*qdim],
                       &lbf[spos+16*qdim], &lbf[spos+2*qdim], &lbf[spos+19*qdim], &lbf[spos+20*qdim],
                       &lbf[spos+18*qdim], &lbf[spos+17*qdim], &lbf[spos+9*qdim], &lbf[spos+21*qdim],
                       &lbf[spos+25*qdim], &lbf[spos+23*qdim], &lbf[spos+26*qdim], &lbf[spos+24*qdim],
                       &lbf[spos+1*qdim], &lbf[spos+3*qdim], &lbf[spos+15*qdim], &lbf[spos+6*qdim],
                       &lbf[spos+7*qdim], &lbf[spos+5*qdim], &lbf[spos+4*qdim], &lbf[spos+22*qdim],
                       &lbf[spos+8*qdim], &lbf[spos+12*qdim], &lbf[spos+10*qdim], &lbf[spos+13*qdim],
                       &lbf[spos+11*qdim]);
      break;
    case CEDB:
      fD3Q27TCEInamuro(p0, -uwall[1], -uwall[2], uwall[0], &lbf[spos], &lbf[spos+15*qdim],
                       &lbf[spos+16*qdim], &lbf[spos+1*qdim], &lbf[spos+21*qdim], &lbf[spos+22*qdim],
                       &lbf[spos+5*qdim], &lbf[spos+17*qdim], &lbf[spos+7*qdim], &lbf[spos+19*qdim],
                       &lbf[spos+13*qdim], &lbf[spos+23*qdim], &lbf[spos+12*qdim], &lbf[spos+24*qdim],
                       &lbf[spos+2*qdim], &lbf[spos+3*qdim], &lbf[spos+14*qdim], &lbf[spos+8*qdim],
                       &lbf[spos+9*qdim], &lbf[spos+18*qdim], &lbf[spos+4*qdim], &lbf[spos+20*qdim],
                       &lbf[spos+6*qdim], &lbf[spos+26*qdim], &lbf[spos+10*qdim], &lbf[spos+25*qdim],
                       &lbf[spos+11*qdim]);
      break;
    case CERB:
      fD3Q27TCEInamuro(p0, uwall[0], -uwall[2], uwall[1], &lbf[spos], &lbf[spos+1*qdim],
                       &lbf[spos+16*qdim], &lbf[spos+2*qdim], &lbf[spos+7*qdim], &lbf[spos+6*qdim],
                       &lbf[spos+4*qdim], &lbf[spos+5*qdim], &lbf[spos+9*qdim], &lbf[spos+21*qdim],
                       &lbf[spos+11*qdim], &lbf[spos+13*qdim], &lbf[spos+10*qdim], &lbf[spos+12*qdim],
                       &lbf[spos+14*qdim], &lbf[spos+3*qdim], &lbf[spos+15*qdim], &lbf[spos+20*qdim],
                       &lbf[spos+19*qdim], &lbf[spos+17*qdim], &lbf[spos+18*qdim], &lbf[spos+22*qdim],
                       &lbf[spos+8*qdim], &lbf[spos+24*qdim], &lbf[spos+26*qdim], &lbf[spos+23*qdim],
                       &lbf[spos+25*qdim]);
      break;
  }
  return 0;  
}


