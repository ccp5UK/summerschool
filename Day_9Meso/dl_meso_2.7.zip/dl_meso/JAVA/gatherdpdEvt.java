import javax.swing.*;
import java.util.*;
import java.lang.*;
import java.io.*;
import java.awt.*;
import java.awt.event.*;
import java.awt.geom.*;
import java.awt.image.*;
/*
 *     DL_MESO_GUI
 *     author: R. S. Qin, M. A. Seaton
 *     copyright: UKRI STFC Daresbury Laboratory and CCP5
 *     2005, 2018
 */
class gatherdpdEvt implements ItemListener, ActionListener{
    gatherdpd gui;
    static String ostype,utilcmd,species,molecule,rcmd="gather-file";
    static int levcfg=0,lcx=1,lcy=1,lcz=1,fftbins=1024,afbins=1,ninsert=500,sstat=1,rnseed=0,hframe=1;
    static boolean septraj=false,fft=false,ranmol=false,lframe=false;
    static double dx=0.25,sigma=0.4,dr=0.02,cutoff=2.0;
    private static String OS = System.getProperty("os.name").toLowerCase();
    public gatherdpdEvt(gatherdpd in){
        gui = in;
    }

    public void actionPerformed(ActionEvent event) {
        String cmd =event.getActionCommand();
        if (cmd == "Process data"){
            try {
                if (isWindows ()) {
                    ostype="";
                } else if (isMac ()) {
                    ostype="./";
                } else if (isUnix ()) {
                    ostype="./";
                }
                int selind = gui.command.getSelectedIndex();
                switch (selind) {
                    case 0:     break;
                    case 1:     rcmd=ostype+"traject_vtf.exe";
                                septraj = gui.checkchoice.isSelected();
                                if(septraj)
                                    rcmd=rcmd+" -b";
                                break;
                    case 2:     rcmd=ostype+"traject_xml.exe";
                                break;
                    case 3:     rcmd=ostype+"isosurfaces.exe";
                                species = (String)gui.species.getSelectedItem();
                                dx = Double.parseDouble(gui.number1.getText());
                                sigma = Double.parseDouble(gui.number2.getText());
                                rcmd=rcmd+" -b "+species;
                                if(dx!=0.25)
                                    rcmd=rcmd+" -p "+dx;
                                if(sigma!=0.4)
                                    rcmd=rcmd+" -s "+sigma;
                                break;
                    case 4:     rcmd=ostype+"radius.exe";
                                dr = Double.parseDouble(gui.number1.getText());
                                cutoff = Double.parseDouble(gui.number2.getText());
                                if(dr!=0.02)
                                    rcmd=rcmd+" -d "+dr;
                                if(cutoff!=2.0)
                                    rcmd=rcmd+" -c "+cutoff;
                                break;
                    case 5:     rcmd=ostype+"rdf.exe";
                                dr = Double.parseDouble(gui.number1.getText());
                                cutoff = Double.parseDouble(gui.number2.getText());
                                fftbins = Integer.parseInt(gui.number3.getText());
                                fft = gui.checkchoice.isSelected();
                                if(dr!=0.02)
                                    rcmd=rcmd+" -d "+dr;
                                if(cutoff!=2.0)
                                    rcmd=rcmd+" -c "+cutoff;
                                if(fft)
                                    rcmd=rcmd+" -fft";
                                if(fft && fftbins!=500)
                                    rcmd=rcmd+" -fc "+fftbins;
                                break;
                    case 6:     rcmd=ostype+"local.exe";
                                lcx = Integer.parseInt(gui.number1.getText());
                                lcy = Integer.parseInt(gui.number2.getText());
                                lcz = Integer.parseInt(gui.number3.getText());
                                rcmd=rcmd+" -nx "+lcx+" -ny "+lcy+" -nz "+lcz;
                                break;
                    case 7:     rcmd=ostype+"export_image_vtf.exe";
                                break;
                    case 8:     rcmd=ostype+"export_image_xml.exe";
                                break;
                    case 9:     rcmd=ostype+"widom.exe";
                                ninsert = Integer.parseInt(gui.number1.getText());
                                sstat = Integer.parseInt(gui.number1.getText());
                                rnseed = Integer.parseInt(gui.number1.getText());
                                species = (String)gui.species.getSelectedItem();
                                molecule = (String)gui.moltype.getSelectedItem();
                                int bm = gui.choice.getSelectedIndex();
                                ranmol = gui.checkchoice.isSelected();
                                if(bm==0)
                                    rcmd=rcmd+" -p "+species;
                                else
                                    rcmd=rcmd+" -m "+molecule;
                                if(bm>0 && ranmol)
                                    rcmd=rcmd+" -rm";
                                rcmd=rcmd+" -n "+ninsert;
                                if(sstat>1)
                                    rcmd=rcmd+" -sf "+sstat;
                                if(rnseed>0)
                                    rcmd=rcmd+" -r "+rnseed;
                                break;
                    case 10:    rcmd=ostype+"dipole.exe";
                                afbins = Integer.parseInt(gui.number1.getText());
                                fftbins = Integer.parseInt(gui.number2.getText());
                                fft = gui.checkchoice.isSelected();
                                rcmd=rcmd+" -n "+afbins;
                                if(fft)
                                    rcmd=rcmd+" -fft";
                                if(fft && fftbins!=500)
                                    rcmd=rcmd+" -fc "+fftbins;
                                break;
                    case 11:    rcmd=ostype+"history_config.exe";
                                levcfg = gui.config.getSelectedIndex();
                                hframe = Integer.parseInt(gui.number1.getText());
                                lframe = gui.checkchoice.isSelected();
                                int su = gui.choice.getSelectedIndex();
                                rcmd=rcmd+" -k "+levcfg;
                                if(lframe)
                                    rcmd=rcmd+" -l";
                                else
                                    rcmd=rcmd+" -f "+hframe;
                                if(su==0)
                                    rcmd=rcmd+" -s";
                                break;
                    case 12:    rcmd=ostype+"export_config.exe";
                                levcfg = gui.config.getSelectedIndex();
                                int sue = gui.choice.getSelectedIndex();
                                rcmd=rcmd+" -k "+levcfg;
                                if(sue==0)
                                    rcmd=rcmd+" -s";
                                break;
                        
                }
                Process p2 = Runtime.getRuntime().exec(rcmd);
                BufferedReader ou2 = new BufferedReader
                    (new InputStreamReader(p2.getInputStream()));
                String line2;
                while ((line2 = ou2.readLine()) != null)
                    System.out.println(line2);
            } catch (IOException e1) {
                    System.out.println(e1);
            }
        }
    }
    public void itemStateChanged(ItemEvent event) {
        int selind=gui.command.getSelectedIndex();
        Object item=event.getItem();
        String answer=item.toString();
        switch (selind) {
            case 0:     utilcmd="";
                        gui.configlabel.setEnabled(false);
                        gui.config.setEnabled(false);
                        gui.number1label.setEnabled(false);
                        gui.number1label.setText("");
                        gui.number1.setEnabled(false);
                        gui.number1.setEditable(false);
                        gui.number2label.setEnabled(false);
                        gui.number2label.setText("");
                        gui.number2.setEnabled(false);
                        gui.number2.setEditable(false);
                        gui.number3label.setEnabled(false);
                        gui.number3label.setText("");
                        gui.number3.setEnabled(false);
                        gui.number3.setEditable(false);
                        gui.specieslabel.setEnabled(false);
                        gui.species.setEnabled(false);
                        gui.moltypelabel.setEnabled(false);
                        gui.moltype.setEnabled(false);
                        gui.choicelabel.setEnabled(false);
                        gui.choicelabel.setText("");
                        gui.choice.setEnabled(false);
                        gui.choice.removeAllItems();
                        gui.checkchoice.setEnabled(false);
                        gui.checkchoice.setText("");
                        gui.runbutton.setEnabled(false);
                        break;
            case 1:     utilcmd="traject_vtf.exe";
                        gui.configlabel.setEnabled(false);
                        gui.config.setEnabled(false);
                        gui.number1label.setEnabled(false);
                        gui.number1label.setText("");
                        gui.number1.setEnabled(false);
                        gui.number1.setEditable(false);
                        gui.number2label.setEnabled(false);
                        gui.number2label.setText("");
                        gui.number2.setEnabled(false);
                        gui.number2.setEditable(false);
                        gui.number3label.setEnabled(false);
                        gui.number3.setEnabled(false);
                        gui.number3.setEditable(false);
                        gui.specieslabel.setEnabled(false);
                        gui.species.setEnabled(false);
                        gui.moltypelabel.setEnabled(false);
                        gui.moltype.setEnabled(false);
                        gui.choicelabel.setEnabled(false);
                        gui.choicelabel.setText("");
                        gui.choice.setEnabled(false);
                        gui.choice.removeAllItems();
                        gui.checkchoice.setEnabled(true);
                        gui.checkchoice.setSelected(septraj);
                        gui.checkchoice.setText("separate files");
                        gui.runbutton.setEnabled(true);
                        break;
            case 2:     utilcmd="traject_xml.exe";
                        gui.configlabel.setEnabled(false);
                        gui.config.setEnabled(false);
                        gui.number1label.setEnabled(false);
                        gui.number1label.setText("");
                        gui.number1.setEnabled(false);
                        gui.number1.setEditable(false);
                        gui.number2label.setEnabled(false);
                        gui.number2label.setText("");
                        gui.number2.setEnabled(false);
                        gui.number2.setEditable(false);
                        gui.number3label.setEnabled(false);
                        gui.number3.setEnabled(false);
                        gui.number3.setEditable(false);
                        gui.specieslabel.setEnabled(false);
                        gui.species.setEnabled(false);
                        gui.moltypelabel.setEnabled(false);
                        gui.moltype.setEnabled(false);
                        gui.choicelabel.setEnabled(false);
                        gui.choicelabel.setText("");
                        gui.choice.setEnabled(false);
                        gui.choice.removeAllItems();
                        gui.checkchoice.setEnabled(false);
                        gui.checkchoice.setSelected(false);
                        gui.checkchoice.setText("");
                        gui.runbutton.setEnabled(true);
                        break;
            case 3:     utilcmd="isosurfaces.exe";
                        gui.configlabel.setEnabled(false);
                        gui.config.setEnabled(false);
                        gui.number1label.setEnabled(true);
                        gui.number1label.setText("grid spacing:");
                        gui.number1.setEnabled(true);
                        gui.number1.setText(Double.toString(dx));
                        gui.number1.setEditable(true);
                        gui.number2label.setEnabled(true);
                        gui.number2label.setText("Gaussian sigma:");
                        gui.number2.setEnabled(true);
                        gui.number2.setText(Double.toString(sigma));
                        gui.number2.setEditable(true);
                        gui.number3label.setEnabled(false);
                        gui.number3label.setText("");
                        gui.number3.setEnabled(false);
                        gui.number3.setEditable(false);
                        gui.specieslabel.setEnabled(true);
                        gui.species.setEnabled(true);
                        gui.moltypelabel.setEnabled(false);
                        gui.moltype.setEnabled(false);
                        gui.choicelabel.setEnabled(false);
                        gui.choice.setEnabled(false);
                        gui.choice.removeAllItems();
                        gui.checkchoice.setEnabled(false);
                        gui.checkchoice.setText("");
                        gui.runbutton.setEnabled(true);
                        break;
            case 4:     utilcmd="radius.exe";
                        gui.configlabel.setEnabled(false);
                        gui.config.setEnabled(false);
                        gui.number1label.setEnabled(true);
                        gui.number1label.setText("grid spacing:");
                        gui.number1.setEnabled(true);
                        gui.number1.setText(Double.toString(dr));
                        gui.number1.setEditable(true);
                        gui.number2label.setEnabled(true);
                        gui.number2label.setText("maximum distance:");
                        gui.number2.setEnabled(true);
                        gui.number2.setText(Double.toString(cutoff));
                        gui.number2.setEditable(true);
                        gui.number3label.setEnabled(false);
                        gui.number3label.setText("");
                        gui.number3.setEnabled(false);
                        gui.number3.setEditable(false);
                        gui.specieslabel.setEnabled(false);
                        gui.species.setEnabled(false);
                        gui.moltypelabel.setEnabled(false);
                        gui.moltype.setEnabled(false);
                        gui.choicelabel.setEnabled(false);
                        gui.choicelabel.setText("");
                        gui.choice.setEnabled(false);
                        gui.choice.removeAllItems();
                        gui.checkchoice.setEnabled(false);
                        gui.checkchoice.setText("");
                        gui.runbutton.setEnabled(true);
                        break;
            case 5:     utilcmd="rdf.exe";
                        gui.configlabel.setEnabled(false);
                        gui.config.setEnabled(false);
                        gui.number1label.setEnabled(true);
                        gui.number1label.setText("grid spacing:");
                        gui.number1.setEnabled(true);
                        gui.number1.setText(Double.toString(dr));
                        gui.number1.setEditable(true);
                        gui.number2label.setEnabled(true);
                        gui.number2label.setText("maximum distance:");
                        gui.number2.setEnabled(true);
                        gui.number2.setText(Double.toString(cutoff));
                        gui.number2.setEditable(true);
                        gui.number3label.setEnabled(true);
                        gui.number3label.setText("number of FFT bins:");
                        gui.number3.setEnabled(true);
                        gui.number3.setText(Integer.toString(fftbins));
                        gui.number3.setEditable(true);
                        gui.specieslabel.setEnabled(false);
                        gui.species.setEnabled(false);
                        gui.moltypelabel.setEnabled(false);
                        gui.moltype.setEnabled(false);
                        gui.choicelabel.setEnabled(false);
                        gui.choicelabel.setText("");
                        gui.choice.setEnabled(false);
                        gui.choice.removeAllItems();
                        gui.checkchoice.setEnabled(true);
                        gui.checkchoice.setSelected(fft);
                        gui.checkchoice.setText("Fourier transforms");
                        gui.runbutton.setEnabled(true);
                        break;
            case 6:     utilcmd="local.exe";
                        gui.configlabel.setEnabled(false);
                        gui.config.setEnabled(false);
                        gui.number1label.setEnabled(true);
                        gui.number1label.setText("division of volume (x):");
                        gui.number1.setEnabled(true);
                        gui.number1.setText(Integer.toString(lcx));
                        gui.number1.setEditable(true);
                        gui.number2label.setEnabled(true);
                        gui.number2label.setText("division of volume (y):");
                        gui.number2.setEnabled(true);
                        gui.number2.setText(Integer.toString(lcy));
                        gui.number2.setEditable(true);
                        gui.number3label.setEnabled(true);
                        gui.number3label.setText("division of volume (z):");
                        gui.number3.setEnabled(true);
                        gui.number3.setText(Integer.toString(lcz));
                        gui.number3.setEditable(true);
                        gui.specieslabel.setEnabled(false);
                        gui.species.setEnabled(false);
                        gui.moltypelabel.setEnabled(false);
                        gui.moltype.setEnabled(false);
                        gui.choicelabel.setEnabled(false);
                        gui.choicelabel.setText("");
                        gui.choice.setEnabled(false);
                        gui.choice.removeAllItems();
                        gui.checkchoice.setEnabled(false);
                        gui.checkchoice.setText("");
                        gui.runbutton.setEnabled(true);
                        break;
            case 7:     utilcmd="export_image_vtf.exe";
                        gui.configlabel.setEnabled(false);
                        gui.config.setEnabled(false);
                        gui.number1label.setEnabled(false);
                        gui.number1label.setText("");
                        gui.number1.setEnabled(false);
                        gui.number1.setEditable(false);
                        gui.number2label.setEnabled(false);
                        gui.number2label.setText("");
                        gui.number2.setEnabled(false);
                        gui.number2.setEditable(false);
                        gui.number3label.setEnabled(false);
                        gui.number3.setEnabled(false);
                        gui.number3label.setText("");
                        gui.number3.setEditable(false);
                        gui.specieslabel.setEnabled(false);
                        gui.species.setEnabled(false);
                        gui.moltypelabel.setEnabled(false);
                        gui.moltype.setEnabled(false);
                        gui.choicelabel.setEnabled(false);
                        gui.choicelabel.setText("");
                        gui.choice.setEnabled(false);
                        gui.choice.removeAllItems();
                        gui.checkchoice.setEnabled(false);
                        gui.checkchoice.setText("");
                        gui.runbutton.setEnabled(true);
                        break;
            case 8:     utilcmd="export_image_xml.exe";
                        gui.configlabel.setEnabled(false);
                        gui.config.setEnabled(false);
                        gui.number1label.setEnabled(false);
                        gui.number1label.setText("");
                        gui.number1.setEnabled(false);
                        gui.number1.setEditable(false);
                        gui.number2label.setEnabled(false);
                        gui.number2label.setText("");
                        gui.number2.setEnabled(false);
                        gui.number2.setEditable(false);
                        gui.number3label.setEnabled(false);
                        gui.number3.setEnabled(false);
                        gui.number3label.setText("");
                        gui.number3.setEditable(false);
                        gui.specieslabel.setEnabled(false);
                        gui.species.setEnabled(false);
                        gui.moltypelabel.setEnabled(false);
                        gui.moltype.setEnabled(false);
                        gui.choicelabel.setEnabled(false);
                        gui.choicelabel.setText("");
                        gui.choice.setEnabled(false);
                        gui.choice.removeAllItems();
                        gui.checkchoice.setEnabled(false);
                        gui.checkchoice.setText("");
                        gui.runbutton.setEnabled(true);
                        break;
            case 9:     utilcmd="widom.exe";
                        gui.configlabel.setEnabled(false);
                        gui.config.setEnabled(false);
                        gui.number1label.setEnabled(true);
                        gui.number1label.setText("no. of insertions:");
                        gui.number1.setEnabled(true);
                        gui.number1.setText(Integer.toString(ninsert));
                        gui.number1.setEditable(true);
                        gui.number2label.setEnabled(true);
                        gui.number2label.setText("first statistics frame:");
                        gui.number2.setEnabled(true);
                        gui.number2.setText(Integer.toString(sstat));
                        gui.number2.setEditable(true);
                        gui.number3label.setEnabled(true);
                        gui.number3label.setText("random number seed:");
                        gui.number3.setEnabled(true);
                        gui.number3.setText(Integer.toString(rnseed));
                        gui.number3.setEditable(true);
                        gui.specieslabel.setEnabled(true);
                        gui.species.setEnabled(true);
                        if(gui.moltype.getItemCount()>0) {
                            gui.moltypelabel.setEnabled(true);
                            gui.moltype.setEnabled(true);
                            gui.choicelabel.setEnabled(true);
                            gui.choicelabel.setText("bead or molecule:");
                            gui.choice.setEnabled(true);
                            gui.choice.removeAllItems();
                            gui.choice.addItem("bead");
                            gui.choice.addItem("molecule");
                            gui.checkchoice.setEnabled(true);
                            gui.checkchoice.setText("random molecule");
                            gui.checkchoice.setSelected(ranmol);
                        }
                        else {
                            gui.moltypelabel.setEnabled(false);
                            gui.moltype.setEnabled(false);
                            gui.choicelabel.setEnabled(true);
                            gui.choicelabel.setText("bead or molecule:");
                            gui.choice.setEnabled(false);
                            gui.choice.removeAllItems();
                            gui.choice.addItem("bead");
                            gui.checkchoice.setEnabled(false);
                            gui.checkchoice.setText("random molecule");
                            gui.checkchoice.setSelected(ranmol);
                        }
                        gui.runbutton.setEnabled(true);
                        break;
            case 10:    utilcmd="dipole.exe";
                        gui.configlabel.setEnabled(false);
                        gui.config.setEnabled(false);
                        gui.number1label.setEnabled(true);
                        gui.number1label.setText("no. of autocorrelation bins:");
                        gui.number1.setEnabled(true);
                        gui.number1.setText(Integer.toString(afbins));
                        gui.number1.setEditable(true);
                        gui.number2label.setEnabled(true);
                        gui.number2label.setText("number of fft bins:");
                        gui.number2.setEnabled(true);
                        gui.number2.setText(Integer.toString(fftbins));
                        gui.number2.setEditable(true);
                        gui.number3label.setEnabled(false);
                        gui.number3label.setText("");
                        gui.number3.setEnabled(false);
                        gui.number3.setEditable(false);
                        gui.specieslabel.setEnabled(false);
                        gui.species.setEnabled(false);
                        gui.moltypelabel.setEnabled(false);
                        gui.moltype.setEnabled(false);
                        gui.choicelabel.setEnabled(false);
                        gui.choicelabel.setText("");
                        gui.choice.setEnabled(false);
                        gui.choice.removeAllItems();
                        gui.checkchoice.setEnabled(true);
                        gui.checkchoice.setSelected(fft);
                        gui.checkchoice.setText("Fourier transforms");
                        gui.runbutton.setEnabled(true);
                        break;
            case 11:    utilcmd="history_config.exe";
                        gui.configlabel.setEnabled(true);
                        gui.config.setEnabled(true);
                        gui.number1label.setEnabled(true);
                        gui.number1label.setText("frame number:");
                        gui.number1.setEnabled(true);
                        gui.number1.setText(Integer.toString(hframe));
                        gui.number1.setEditable(true);
                        gui.number2label.setEnabled(false);
                        gui.number2label.setText("");
                        gui.number2.setEnabled(false);
                        gui.number2.setEditable(false);
                        gui.number3label.setEnabled(false);
                        gui.number3.setEnabled(false);
                        gui.number3label.setText("");
                        gui.number3.setEditable(false);
                        gui.specieslabel.setEnabled(false);
                        gui.species.setEnabled(false);
                        gui.moltypelabel.setEnabled(false);
                        gui.moltype.setEnabled(false);
                        gui.choicelabel.setEnabled(true);
                        gui.choicelabel.setText("sorted/unsorted:");
                        gui.choice.setEnabled(true);
                        gui.choice.removeAllItems();
                        gui.choice.addItem("sorted");
                        gui.choice.addItem("unsorted");
                        gui.checkchoice.setEnabled(true);
                        gui.checkchoice.setText("last frame");
                        gui.checkchoice.setSelected(lframe);
                        gui.runbutton.setEnabled(true);
                        break;
            case 12:    utilcmd="export_config.exe";
                        gui.configlabel.setEnabled(true);
                        gui.config.setEnabled(true);
                        gui.number1label.setEnabled(false);
                        gui.number1label.setText("");
                        gui.number1.setEnabled(false);
                        gui.number1.setEditable(false);
                        gui.number2label.setEnabled(false);
                        gui.number2label.setText("");
                        gui.number2.setEnabled(false);
                        gui.number2.setEditable(false);
                        gui.number3label.setEnabled(false);
                        gui.number3.setEnabled(false);
                        gui.number3label.setText("");
                        gui.number3.setEditable(false);
                        gui.specieslabel.setEnabled(false);
                        gui.species.setEnabled(false);
                        gui.moltypelabel.setEnabled(false);
                        gui.moltype.setEnabled(false);
                        gui.choicelabel.setEnabled(true);
                        gui.choicelabel.setText("sorted/unsorted:");
                        gui.choice.setEnabled(true);
                        gui.choice.removeAllItems();
                        gui.choice.addItem("sorted");
                        gui.choice.addItem("unsorted");
                        gui.checkchoice.setEnabled(false);
                        gui.checkchoice.setText("");
                        gui.runbutton.setEnabled(true);
                        break;
        }
    }

    void ierr(String errinfo) {
      msgPanel fcer=new msgPanel(errinfo);	
    }

    public static boolean isWindows() {
        return (OS.indexOf("win") >= 0);
    }
    
    public static boolean isMac() {
        return (OS.indexOf("mac") >= 0);
    }
    
    public static boolean isUnix() {
        return (OS.indexOf("nix") >= 0 || OS.indexOf("nux") >= 0 || OS.indexOf("aix") >= 0 || OS.indexOf("sunos") >= 0 );
    }

}
