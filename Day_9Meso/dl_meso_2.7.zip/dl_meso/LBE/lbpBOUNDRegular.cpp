/***************************************************
 *   DL_MESO       Version 2.7                     *
 *   Authors   :   R. S. Qin, M. A. Seaton         *
 *   Copyright :   UKRI STFC Daresbury Laboratory  *
 *             :   09/12/2018                      *
 ***************************************************/

// D2Q9

int fD2Q9VCERegular(double v0, double v1, double *force,
                    double *f0, double *f1, double *f2,
	                double *f3, double *f4, double *f5,
                    double *f6, double *f7, double *f8)
{

  // produce fixed velocity at bottom boundary (VCETF) for compressible/incompressible fluids

  double rho, rho0, modv, pi_xx, pi_yy, pi_xy, v0v0, v0v1, v1v1;
  double c1=1.0/3.0,c2=2.0/3.0,c3=1.0/6.0,c4=1.0/12.0;
    
  v0v0 = v0*v0;
  v0v1 = v0*v1;
  v1v1 = v1*v1;
  modv = v0v0 + v1v1;
  if(!incompress) {
    for(int i=0; i<lbsy.nf; i++) {
      rho = (f0[i]+f2[i]+f6[i]+2*(f3[i]+f4[i]+f5[i])-0.5*force[2*i+1])/(1.0-v1);
      pi_xx = f2[i]+f6[i]+2.0*(f3[i]+f5[i])+rho*(c1*(v1-1.0)-v0v0)+v0*force[2*i  ];
      pi_yy = 2.0*(f3[i]+f4[i]+f5[i])+rho*(v1-v1v1-c1)+v1*force[2*i+1];
      pi_xy = 2.0*(f3[i]-f5[i])+rho*(c1*v0-v0v1)+0.5*(v1*force[2*i  ]+v0*force[2*i+1]);
      f0[i]=rho*lbw[0]*(1.0                     -1.5*modv)-c2*(pi_xx+   pi_yy);
      f1[i]=rho*lbw[1]*(1.0-3.0*(v0-v1)-9.0*v0v1+3.0*modv)+c4*(pi_xx+   pi_yy)-0.25*pi_xy;
      f2[i]=rho*lbw[2]*(1.0-3.0* v0    +4.5*v0v0-1.5*modv)+c1* pi_xx-c3*pi_yy;
      f3[i]=rho*lbw[3]*(1.0-3.0*(v0+v1)+9.0*v0v1+3.0*modv)+c4*(pi_xx+   pi_yy)+0.25*pi_xy;
      f4[i]=rho*lbw[4]*(1.0-3.0* v1    +4.5*v1v1-1.5*modv)-c3* pi_xx+c1*pi_yy;
      f5[i]=rho*lbw[5]*(1.0+3.0*(v0-v1)-9.0*v0v1+3.0*modv)+c4*(pi_xx+   pi_yy)-0.25*pi_xy;
      f6[i]=rho*lbw[6]*(1.0+3.0* v0    +4.5*v0v0-1.5*modv)+c1* pi_xx-c3*pi_yy;
      f7[i]=rho*lbw[7]*(1.0+3.0*(v0+v1)-9.0*v0v1+3.0*modv)+c4*(pi_xx+   pi_yy)+0.25*pi_xy;
      f8[i]=rho*lbw[8]*(1.0+3.0* v1    +4.5*v1v1-1.5*modv)-c3* pi_xx+c1*pi_yy;
    }
  }
  else {
    for(int i=0; i<lbsy.nf; i++) {
      rho0 = lbincp[i];
      rho = f0[i]+f2[i]+f6[i]+2*(f3[i]+f4[i]+f5[i])+rho0*v1-0.5*force[2*i+1];
      pi_xx = f2[i]+f6[i]+2.0*(f3[i]+f5[i])+rho0*(c1*v1-v0v0)-c1*rho+v0*force[2*i  ];
      pi_yy = 2.0*(f3[i]+f4[i]+f5[i])+rho0*(v1-v1v1)-c1*rho+v1*force[2*i+1];
      pi_xy = 2.0*(f3[i]-f5[i])+rho0*(c1*v0-v0v1)+0.5*(v1*force[2*i  ]+v0*force[2*i+1]);
      f0[i]=lbw[0]*(rho-rho0*                       1.5*modv) -c2*(pi_xx   +pi_yy);
      f1[i]=lbw[1]*(rho+rho0*(-3.0*(v0-v1)-9.0*v0v1+3.0*modv))+c4*(pi_xx   +pi_yy)-0.25*pi_xy;
      f2[i]=lbw[2]*(rho+rho0*(-3.0* v0    +4.5*v0v0-1.5*modv))+c1* pi_xx-c3*pi_yy;
      f3[i]=lbw[3]*(rho+rho0*(-3.0*(v0+v1)+9.0*v0v1+3.0*modv))+c4*(pi_xx   +pi_yy)+0.25*pi_xy;
      f4[i]=lbw[4]*(rho+rho0*(-3.0* v1    +4.5*v1v1-1.5*modv))-c3* pi_xx+c1*pi_yy;
      f5[i]=lbw[5]*(rho+rho0*( 3.0*(v0-v1)-9.0*v0v1+3.0*modv))+c4*(pi_xx   +pi_yy)-0.25*pi_xy;
      f6[i]=lbw[6]*(rho+rho0*( 3.0* v0    +4.5*v0v0-1.5*modv))+c1* pi_xx-c3*pi_yy;
      f7[i]=lbw[7]*(rho+rho0*( 3.0*(v0+v1)-9.0*v0v1+3.0*modv))+c4*(pi_xx   +pi_yy)+0.25*pi_xy;
      f8[i]=lbw[8]*(rho+rho0*( 3.0* v1    +4.5*v1v1-1.5*modv))-c3* pi_xx+c1*pi_yy;
    }
  }
  return 0;
}

int fD2Q9VCCRegular(double *p, double v0, double v1, double *force,
                    double *f0, double *f1, double *f2,
	                double *f3, double *f4, double *f5,
                    double *f6, double *f7, double *f8)
{

  // produce fixed velocity at bottom left corner (VCCTRF) for compressible/incompressible fluids

  double rho0, modv, pi_xx, pi_yy, pi_xy, v0v0, v0v1, v1v1;
  double c1=1.0/3.0,c2=2.0/3.0,c3=1.0/6.0,c4=1.0/12.0;
    
  v0v0 = v0*v0;
  v0v1 = v0*v1;
  v1v1 = v1*v1;
  modv = v0v0 + v1v1;
  if(!incompress) {
    for(int i=0; i<lbsy.nf; i++) {
      pi_xx = -f0[i]-2.0*f4[i]+p[i]*(c2-c2*v1-v0v0)+v0*force[2*i  ];
      pi_yy = -f0[i]-2.0*f2[i]+p[i]*(c2-c2*v0-v1v1)+v1*force[2*i+1];
      pi_xy = f0[i]+2.0*(f2[i]+f4[i])+4.0*f3[i]-p[i]*(1.0-v0)*(1.0-v1)+0.5*(v1*force[2*i  ]+v0*force[2*i+1]);
      f0[i]=p[i]*lbw[0]*(1.0                     -1.5*modv)-c2*(pi_xx+   pi_yy);
      f1[i]=p[i]*lbw[1]*(1.0-3.0*(v0-v1)-9.0*v0v1+3.0*modv)+c4*(pi_xx+   pi_yy)-0.25*pi_xy;
      f2[i]=p[i]*lbw[2]*(1.0-3.0* v0    +4.5*v0v0-1.5*modv)+c1* pi_xx-c3*pi_yy;
      f3[i]=p[i]*lbw[3]*(1.0-3.0*(v0+v1)+9.0*v0v1+3.0*modv)+c4*(pi_xx+   pi_yy)+0.25*pi_xy;
      f4[i]=p[i]*lbw[4]*(1.0-3.0* v1    +4.5*v1v1-1.5*modv)-c3* pi_xx+c1*pi_yy;
      f5[i]=p[i]*lbw[5]*(1.0+3.0*(v0-v1)-9.0*v0v1+3.0*modv)+c4*(pi_xx+   pi_yy)-0.25*pi_xy;
      f6[i]=p[i]*lbw[6]*(1.0+3.0* v0    +4.5*v0v0-1.5*modv)+c1* pi_xx-c3*pi_yy;
      f7[i]=p[i]*lbw[7]*(1.0+3.0*(v0+v1)-9.0*v0v1+3.0*modv)+c4*(pi_xx+   pi_yy)+0.25*pi_xy;
      f8[i]=p[i]*lbw[8]*(1.0+3.0* v1    +4.5*v1v1-1.5*modv)-c3* pi_xx+c1*pi_yy;
    }
  }
  else {
    for(int i=0; i<lbsy.nf; i++) {
      rho0 = lbincp[i];
      pi_xx = -f0[i]-2.0*f4[i]+c2*p[i]-rho0*(c2*v1+v0v0)+v0*force[2*i  ];
      pi_yy = -f0[i]-2.0*f2[i]+c2*p[i]-rho0*(c2*v0+v1v1)+v1*force[2*i+1];
      pi_xy = f0[i]+2.0*(f2[i]+f4[i])+4.0*f3[i]-p[i]-rho0*(v0v1-v0-v1)+0.5*(v1*force[2*i  ]+v0*force[2*i+1]);
      f0[i]=lbw[0]*(p[i]-rho0*                       1.5*modv) -c2*(pi_xx   +pi_yy);
      f1[i]=lbw[1]*(p[i]+rho0*(-3.0*(v0-v1)-9.0*v0v1+3.0*modv))+c4*(pi_xx   +pi_yy)-0.25*pi_xy;
      f2[i]=lbw[2]*(p[i]+rho0*(-3.0* v0    +4.5*v0v0-1.5*modv))+c1* pi_xx-c3*pi_yy;
      f3[i]=lbw[3]*(p[i]+rho0*(-3.0*(v0+v1)+9.0*v0v1+3.0*modv))+c4*(pi_xx   +pi_yy)+0.25*pi_xy;
      f4[i]=lbw[4]*(p[i]+rho0*(-3.0* v1    +4.5*v1v1-1.5*modv))-c3* pi_xx+c1*pi_yy;
      f5[i]=lbw[5]*(p[i]+rho0*( 3.0*(v0-v1)-9.0*v0v1+3.0*modv))+c4*(pi_xx   +pi_yy)-0.25*pi_xy;
      f6[i]=lbw[6]*(p[i]+rho0*( 3.0* v0    +4.5*v0v0-1.5*modv))+c1* pi_xx-c3*pi_yy;
      f7[i]=lbw[7]*(p[i]+rho0*( 3.0*(v0+v1)-9.0*v0v1+3.0*modv))+c4*(pi_xx   +pi_yy)+0.25*pi_xy;
      f8[i]=lbw[8]*(p[i]+rho0*( 3.0* v1    +4.5*v1v1-1.5*modv))-c3* pi_xx+c1*pi_yy;
    }
  }
  return 0;
}

int fD2Q9VCECLBERegular(double v0, double v1, double *force,
                        double *f0, double *f1, double *f2,
                        double *f3, double *f4, double *f5,
                        double *f6, double *f7, double *f8)
{

  // produce fixed velocity at bottom boundary (VCETF) for compressible fluids
  // using higher-order equilibrium distribution functions for CLBE collisions

  double rho, modv, pi_xx, pi_yy, pi_xy, v0v0, v0v1, v1v1;
  double c1=1.0/3.0,c2=2.0/3.0,c3=1.0/6.0,c4=1.0/12.0;
    
  v0v0 = v0*v0;
  v0v1 = v0*v1;
  v1v1 = v1*v1;
  modv = v0v0 + v1v1;

  for(int i=0; i<lbsy.nf; i++) {
    rho = (f0[i]+f2[i]+f6[i]+2*(f3[i]+f4[i]+f5[i])-0.5*force[2*i+1])/(1.0-v1);
    pi_xx = f2[i]+f6[i]+2.0*(f3[i]+f5[i])+rho*(v1-1.0)*(c1+v0v0)+v0*force[2*i  ];
    pi_yy = 2.0*(f3[i]+f4[i]+f5[i])+rho*(v1-v1v1-c1)+v1*force[2*i+1];
    pi_xy = 2.0*(f3[i]-f5[i])+rho*(v0*(c1+v1v1)-v0v1)+0.5*(v1*force[2*i  ]+v0*force[2*i+1]);
    f0[i]=rho*lbw[0]*(1.0                                  -1.5*modv+2.25*v0v0*v1v1)-c2*(pi_xx+   pi_yy);
    f1[i]=rho*lbw[1]*(1.0-3.0*(v0-v1)-9.0* v0v1*(1.0-v0+v1)+3.0*modv +9.0*v0v0*v1v1)+c4*(pi_xx+   pi_yy)-0.25*pi_xy;
    f2[i]=rho*lbw[2]*(1.0-3.0* v0    +4.5*(v0v0+v0v1*v1)   -1.5*modv -4.5*v0v0*v1v1)+c1* pi_xx-c3*pi_yy;
    f3[i]=rho*lbw[3]*(1.0-3.0*(v0+v1)+9.0* v0v1*(1.0-v0-v1)+3.0*modv +9.0*v0v0*v1v1)+c4*(pi_xx+   pi_yy)+0.25*pi_xy;
    f4[i]=rho*lbw[4]*(1.0-3.0* v1    +4.5*(v1v1+v0v1*v0)   -1.5*modv -4.5*v0v0*v1v1)-c3* pi_xx+c1*pi_yy;
    f5[i]=rho*lbw[5]*(1.0+3.0*(v0-v1)-9.0* v0v1*(1.0+v0-v1)+3.0*modv +9.0*v0v0*v1v1)+c4*(pi_xx+   pi_yy)-0.25*pi_xy;
    f6[i]=rho*lbw[6]*(1.0+3.0* v0    +4.5*(v0v0-v0v1*v1)   -1.5*modv -4.5*v0v0*v1v1)+c1* pi_xx-c3*pi_yy;
    f7[i]=rho*lbw[7]*(1.0+3.0*(v0+v1)+9.0* v0v1*(1.0+v0+v1)+3.0*modv +9.0*v0v0*v1v1)+c4*(pi_xx+   pi_yy)+0.25*pi_xy;
    f8[i]=rho*lbw[8]*(1.0+3.0* v1    +4.5*(v1v1-v0v1*v0)   -1.5*modv -4.5*v0v0*v1v1)-c3* pi_xx+c1*pi_yy;
  }
  return 0;
}

int fD2Q9VCCCLBERegular(double *p, double v0, double v1, double *force,
                        double *f0, double *f1, double *f2,
                        double *f3, double *f4, double *f5,
                        double *f6, double *f7, double *f8)
{

  // produce fixed velocity at bottom left corner (VCCTRF) for compressible fluids
  // using higher-order equilibrium distribution functions for CLBE collisions

  double modv, pi_xx, pi_yy, pi_xy, v0v0, v0v1, v1v1;
  double c1=1.0/3.0,c2=2.0/3.0,c3=1.0/6.0,c4=1.0/12.0;
    
  v0v0 = v0*v0;
  v0v1 = v0*v1;
  v1v1 = v1*v1;
  modv = v0v0 + v1v1;

  for(int i=0; i<lbsy.nf; i++) {
    pi_xx = -f0[i]-2.0*f4[i]+p[i]*(c2-c2*v1-v0v0+0.5*(v0v0*v1-v0*v1v1))+v0*force[2*i  ];
    pi_yy = -f0[i]-2.0*f2[i]+p[i]*(c2-c2*v0-v1v1+0.5*(v0*v1v1-v0v0*v1))+v1*force[2*i+1];
    pi_xy = f0[i]+2.0*(f2[i]+f4[i])+4.0*f3[i]-p[i]*(1.0-v0)*(1.0-v1)+0.5*p[i]*v0v1*(v0+v1)+0.5*(v1*force[2*i  ]+v0*force[2*i+1]);
    f0[i]=p[i]*lbw[0]*(1.0                                  -1.5*modv+2.25*v0v0*v1v1)-c2*(pi_xx+   pi_yy);
    f1[i]=p[i]*lbw[1]*(1.0-3.0*(v0-v1)-9.0* v0v1*(1.0-v0+v1)+3.0*modv +9.0*v0v0*v1v1)+c4*(pi_xx+   pi_yy)-0.25*pi_xy;
    f2[i]=p[i]*lbw[2]*(1.0-3.0* v0    +4.5*(v0v0+v0v1*v1)   -1.5*modv -4.5*v0v0*v1v1)+c1* pi_xx-c3*pi_yy;
    f3[i]=p[i]*lbw[3]*(1.0-3.0*(v0+v1)+9.0* v0v1*(1.0-v0-v1)+3.0*modv +9.0*v0v0*v1v1)+c4*(pi_xx+   pi_yy)+0.25*pi_xy;
    f4[i]=p[i]*lbw[4]*(1.0-3.0* v1    +4.5*(v1v1+v0v1*v0)   -1.5*modv -4.5*v0v0*v1v1)-c3* pi_xx+c1*pi_yy;
    f5[i]=p[i]*lbw[5]*(1.0+3.0*(v0-v1)-9.0* v0v1*(1.0+v0-v1)+3.0*modv +9.0*v0v0*v1v1)+c4*(pi_xx+   pi_yy)-0.25*pi_xy;
    f6[i]=p[i]*lbw[6]*(1.0+3.0* v0    +4.5*(v0v0-v0v1*v1)   -1.5*modv -4.5*v0v0*v1v1)+c1* pi_xx-c3*pi_yy;
    f7[i]=p[i]*lbw[7]*(1.0+3.0*(v0+v1)+9.0* v0v1*(1.0+v0+v1)+3.0*modv +9.0*v0v0*v1v1)+c4*(pi_xx+   pi_yy)+0.25*pi_xy;
    f8[i]=p[i]*lbw[8]*(1.0+3.0* v1    +4.5*(v1v1-v0v1*v0)   -1.5*modv -4.5*v0v0*v1v1)-c3* pi_xx+c1*pi_yy;
  }
  return 0;
}

int fD2Q9VCESwiftRegular(double v0, double v1, double *force, double *f0, double *f1, double *f2,
	                     double *f3, double *f4, double *f5, double *f6, double *f7, double *f8,
 	                     double drdx, double drdy, double dpdx, double dpdy, double nabr, double nabp,
                         double *omega, double T)
{

  // produce fixed velocity at bottom boundary (VCETF) for compressible/incompressible fluids

  double rho, phi, omegat, pb, mu, lambda, d2rdx2, d2rdy2, d2rdxdy, nabrp, modv, v0v0, v0v1, v1v1, udr;
  double pi_xx, pi_yy, pi_xy, pic_xx, pic_yy, pic_xy;
  double c3=1.0/3.0,c4=2.0/3.0,c5=1.0/6.0,c6=1.0/12.0;
    
  v0v0 = v0*v0;
  v0v1 = v0*v1;
  v1v1 = v1*v1;
  modv = v0v0 + v1v1;
  rho = (f0[0]+f2[0]+f6[0]+2*(f3[0]+f4[0]+f5[0])-0.5*force[1])/(1.0-v1);
  if(lbsy.nf>1) {
    phi = (f0[1]+f2[1]+f6[1]+2*(f3[1]+f4[1]+f5[1]))/(1.0-v1);
    omegat = 0.5*(1.0+phi)*omega[0]+0.5*(1.0-phi)*omega[1];
    mu = lbfemob*fGetPotentialSwift(phi, nabp);
    d2rdx2 = (lbfeeos>0)?(drdx*drdx):0.0 + dpdx*dpdx;
    d2rdy2 = (lbfeeos>0)?(drdy*drdy):0.0 + dpdy*dpdy;
    d2rdxdy = (lbfeeos>0)?(drdx*drdy):0.0 + dpdx*dpdy;
    nabrp = (lbfeeos>0)?(rho*nabr):0.0 + phi*nabp;
    pic_xx = f2[1]+f6[1]+2.0*(f3[1]+f5[1])+phi*(c3*v1-v0v0)-mu;
    pic_yy = 2.0*(f3[1]+f4[1]+f5[1])+phi*(v1-v1v1)-mu;
    pic_xy = 2.0*(f3[1]-f5[1])+phi*(c3*v0-v0v1);
    f0[1]=mu*lbwpt[0]+phi*        (1.0-    0.5*lbwi[0]*modv)-c4*(pic_xx   +pic_yy);
    f1[1]=mu*lbwpt[1]+phi*lbwi[1]*(-v0+v1-3.0*v0v1    +modv)+c6*(pic_xx   +pic_yy)-0.25*pic_xy;
    f2[1]=mu*lbwpt[2]+phi*lbwi[2]*(-v0   +1.5*v0v0-0.5*modv)+c3* pic_xx-c5*pic_yy;
    f3[1]=mu*lbwpt[3]+phi*lbwi[3]*(-v0-v1+3.0*v0v1    +modv)+c6*(pic_xx   +pic_yy)+0.25*pic_xy;
    f4[1]=mu*lbwpt[4]+phi*lbwi[4]*(-v1   +1.5*v1v1-0.5*modv)-c5* pic_xx+c3*pic_yy;
    f5[1]=mu*lbwpt[5]+phi*lbwi[5]*( v0-v1-3.0*v0v1    +modv)+c6*(pic_xx   +pic_yy)-0.25*pic_xy;
    f6[1]=mu*lbwpt[6]+phi*lbwi[6]*( v0   +1.5*v0v0-0.5*modv)+c3* pic_xx-c5*pic_yy;
    f7[1]=mu*lbwpt[7]+phi*lbwi[7]*( v0+v1+3.0*v0v1    +modv)+c6*(pic_xx   +pic_yy)+0.25*pic_xy;
    f8[1]=mu*lbwpt[8]+phi*lbwi[8]*( v1   +1.5*v1v1-0.5*modv)-c5* pic_xx+c3*pic_yy;
  }
  else {
    phi = 0.0;
    omegat = omega[0];
    d2rdx2 = drdx*drdx;
    d2rdy2 = drdy*drdy;
    d2rdxdy = drdx*drdy;
    nabrp = rho*nabr;
  }
  pb = fGetBulkPressureSwift(rho, phi, T);
  lambda = fGetLambdaSwift(rho, omegat, T);
  udr = drdx*v0 + drdy*v1;
  pi_xx = f2[0]+f6[0]+2.0*(f3[0]+f5[0])+rho*(c3*v1-v0v0)+v0*force[0]-pb+lbkappa*nabrp-0.5*lbkappa*(d2rdx2-d2rdy2)-0.5*lambda*(7.0*v0*drdx+3.0*v1*drdy);
  pi_yy = 2.0*(f3[0]+f4[0]+f5[0])+rho*(v1-v1v1)+v1*force[1]-pb+lbkappa*nabrp+0.5*lbkappa*(d2rdx2-d2rdy2)-0.5*lambda*(3.0*v0*drdx+7.0*v1*drdy);
  pi_xy = 2.0*(f3[0]-f5[0])+rho*(c3*v0-v0v1)+0.5*(v1*force[0]+v0*force[1])-lambda*(v1*drdx+v0*drdy)-lbkappa*d2rdxdy;
    
  f0[0]=rho*(1.0-             0.5*lbwi[0]*modv)+lambda*lbwi[0]*lbwdel[0]*udr
       +lbwpt[0]*(pb-lbkappa*nabrp)+lbkappa*(lbwxx[0]*d2rdx2+lbwyy[0]*d2rdy2                 )-c4*(pi_xx   +pi_yy);
  f1[0]=lbwi[1]*(rho*(-v0+v1-3.0*v0v1    +modv)+lambda*(4.5*udr-3.0*v0*drdy-3.0*v1*drdx))
       +lbwpt[1]*(pb-lbkappa*nabrp)+lbkappa*(lbwxx[1]*d2rdx2+lbwyy[1]*d2rdy2+lbwxy[1]*d2rdxdy)+c6*(pi_xx   +pi_yy)-0.25*pi_xy;
  f2[0]=lbwi[2]*(rho*(-v0   +1.5*v0v0-0.5*modv)+lambda*(                    3.0*v0*drdx))
       +lbwpt[2]*(pb-lbkappa*nabrp)+lbkappa*(lbwxx[2]*d2rdx2+lbwyy[2]*d2rdy2                 )+c3* pi_xx-c5*pi_yy;
  f3[0]=lbwi[3]*(rho*(-v0-v1-3.0*v0v1    +modv)+lambda*(4.5*udr+3.0*v0*drdy+3.0*v1*drdx))
       +lbwpt[3]*(pb-lbkappa*nabrp)+lbkappa*(lbwxx[3]*d2rdx2+lbwyy[3]*d2rdy2+lbwxy[3]*d2rdxdy)+c6*(pi_xx   +pi_yy)+0.25*pi_xy;
  f4[0]=lbwi[4]*(rho*(-v1   +1.5*v1v1-0.5*modv)+lambda*(                    3.0*v1*drdy))
       +lbwpt[4]*(pb-lbkappa*nabrp)+lbkappa*(lbwxx[4]*d2rdx2+lbwyy[4]*d2rdy2                 )-c5* pi_xx+c3*pi_yy;
  f5[0]=lbwi[5]*(rho*( v0-v1-3.0*v0v1    +modv)+lambda*(4.5*udr-3.0*v0*drdy-3.0*v1*drdx))
       +lbwpt[5]*(pb-lbkappa*nabrp)+lbkappa*(lbwxx[5]*d2rdx2+lbwyy[5]*d2rdy2+lbwxy[5]*d2rdxdy)+c6*(pi_xx   +pi_yy)-0.25*pi_xy;
  f6[0]=lbwi[6]*(rho*( v0   +1.5*v0v0-0.5*modv)+lambda*(                   3.0*v0*drdx))
       +lbwpt[6]*(pb-lbkappa*nabrp)+lbkappa*(lbwxx[6]*d2rdx2+lbwyy[6]*d2rdy2                 )+c3* pi_xx-c5*pi_yy;
  f7[0]=lbwi[7]*(rho*( v0+v1-3.0*v0v1    +modv)+lambda*(4.5*udr+3.0*v0*drdy+3.0*v1*drdx))
       +lbwpt[7]*(pb-lbkappa*nabrp)+lbkappa*(lbwxx[7]*d2rdx2+lbwyy[7]*d2rdy2+lbwxy[7]*d2rdxdy)+c6*(pi_xx   +pi_yy)+0.25*pi_xy;
  f8[0]=lbwi[8]*(rho*( v1   +1.5*v1v1-0.5*modv)+lambda*(                    3.0*v1*drdy))
       +lbwpt[8]*(pb-lbkappa*nabrp)+lbkappa*(lbwxx[8]*d2rdx2+lbwyy[8]*d2rdy2                 )-c5* pi_xx+c3*pi_yy;
  return 0;
}

int fD2Q9VCCSwiftRegular(double *p, double v0, double v1, double *force, double *f0, double *f1, double *f2,
	                     double *f3, double *f4, double *f5, double *f6, double *f7, double *f8,
 	                     double drdx, double drdy, double dpdx, double dpdy, double nabr, double nabp,
                         double *omega, double T)
{

  // produce fixed velocity at bottom left corner (VCCTRF) for compressible/incompressible fluids

  double rho, phi, omegat, pb, mu, lambda, d2rdx2, d2rdy2, d2rdxdy, nabrp, modv, v0v0, v0v1, v1v1, udr;
  double pi_xx, pi_yy, pi_xy, pic_xx, pic_yy, pic_xy;
  double c3=1.0/3.0,c4=2.0/3.0,c5=1.0/6.0,c6=1.0/12.0;
    
  v0v0 = v0*v0;
  v0v1 = v0*v1;
  v1v1 = v1*v1;
  modv = v0v0 + v1v1;
  rho = p[0];
  if(lbsy.nf>1) {
    phi = p[1];
    omegat = 0.5*(1.0+phi)*omega[0]+0.5*(1.0-phi)*omega[1];
    mu = lbfemob*fGetPotentialSwift(phi, nabp);
    d2rdx2 = (lbfeeos>0)?(drdx*drdx):0.0 + dpdx*dpdx;
    d2rdy2 = (lbfeeos>0)?(drdy*drdy):0.0 + dpdy*dpdy;
    d2rdxdy = (lbfeeos>0)?(drdx*drdy):0.0 + dpdx*dpdy;
    nabrp = (lbfeeos>0)?(rho*nabr):0.0 + phi*nabp;
    pic_xx = -f0[1]-2.0*f4[1]+phi*(1.0-c4*v1-v0v0)-mu;
    pic_yy = -f0[1]-2.0*f2[1]+phi*(1.0-c4*v0-v1v1)-mu;
    pic_xy = f0[1]+2.0*(f2[1]+f4[1])+4.0*f3[1]-phi*(1.0-v0)*(1.0-v1);
    f0[1]=mu*lbwpt[0]+phi*        (1.0-    0.5*lbwi[0]*modv)-c4*(pic_xx   +pic_yy);
    f1[1]=mu*lbwpt[1]+phi*lbwi[1]*(-v0+v1-3.0*v0v1    +modv)+c6*(pic_xx   +pic_yy)-0.25*pic_xy;
    f2[1]=mu*lbwpt[2]+phi*lbwi[2]*(-v0   +1.5*v0v0-0.5*modv)+c3* pic_xx-c5*pic_yy;
    f3[1]=mu*lbwpt[3]+phi*lbwi[3]*(-v0-v1+3.0*v0v1    +modv)+c6*(pic_xx   +pic_yy)+0.25*pic_xy;
    f4[1]=mu*lbwpt[4]+phi*lbwi[4]*(-v1   +1.5*v1v1-0.5*modv)-c5* pic_xx+c3*pic_yy;
    f5[1]=mu*lbwpt[5]+phi*lbwi[5]*( v0-v1-3.0*v0v1    +modv)+c6*(pic_xx   +pic_yy)-0.25*pic_xy;
    f6[1]=mu*lbwpt[6]+phi*lbwi[6]*( v0   +1.5*v0v0-0.5*modv)+c3* pic_xx-c5*pic_yy;
    f7[1]=mu*lbwpt[7]+phi*lbwi[7]*( v0+v1+3.0*v0v1    +modv)+c6*(pic_xx   +pic_yy)+0.25*pic_xy;
    f8[1]=mu*lbwpt[8]+phi*lbwi[8]*( v1   +1.5*v1v1-0.5*modv)-c5* pic_xx+c3*pic_yy;
  }
  else {
    phi = 0.0;
    omegat = omega[0];
    d2rdx2 = drdx*drdx;
    d2rdy2 = drdy*drdy;
    d2rdxdy = drdx*drdy;
    nabrp = rho*nabr;
  }
  pb = fGetBulkPressureSwift(rho, phi, T);
  lambda = fGetLambdaSwift(rho, omegat, T);
  udr = drdx*v0 + drdy*v1;
  pi_xx = -f0[0]-2.0*f4[0]+rho*(1.0-c4*v1-v0v0)+v0*force[0]-pb+lbkappa*nabrp-0.5*lbkappa*(d2rdx2-d2rdy2)-0.5*lambda*(7.0*v0*drdx+3.0*v1*drdy);
  pi_yy = -f0[0]-2.0*f2[0]+rho*(1.0-c4*v0-v1v1)+v1*force[1]-pb+lbkappa*nabrp+0.5*lbkappa*(d2rdx2-d2rdy2)-0.5*lambda*(3.0*v0*drdx+7.0*v1*drdy);
  pi_xy = f0[0]+2.0*(f2[0]+f4[0])+4.0*f3[0]-rho*(1.0-v0)*(1.0-v1)+0.5*(v1*force[0]+v0*force[1])-lambda*(v1*drdx+v0*drdy)-lbkappa*d2rdxdy;
    
  f0[0]=rho*(1.0-             0.5*lbwi[0]*modv)+lambda*lbwi[0]*lbwdel[0]*udr
       +lbwpt[0]*(pb-lbkappa*nabrp)+lbkappa*(lbwxx[0]*d2rdx2+lbwyy[0]*d2rdy2                 )-c4*(pi_xx   +pi_yy);
  f1[0]=lbwi[1]*(rho*(-v0+v1-3.0*v0v1    +modv)+lambda*(4.5*udr-3.0*v0*drdy-3.0*v1*drdx))
       +lbwpt[1]*(pb-lbkappa*nabrp)+lbkappa*(lbwxx[1]*d2rdx2+lbwyy[1]*d2rdy2+lbwxy[1]*d2rdxdy)+c6*(pi_xx   +pi_yy)-0.25*pi_xy;
  f2[0]=lbwi[2]*(rho*(-v0   +1.5*v0v0-0.5*modv)+lambda*(                    3.0*v0*drdx))
       +lbwpt[2]*(pb-lbkappa*nabrp)+lbkappa*(lbwxx[2]*d2rdx2+lbwyy[2]*d2rdy2                 )+c3* pi_xx-c5*pi_yy;
  f3[0]=lbwi[3]*(rho*(-v0-v1-3.0*v0v1    +modv)+lambda*(4.5*udr+3.0*v0*drdy+3.0*v1*drdx))
       +lbwpt[3]*(pb-lbkappa*nabrp)+lbkappa*(lbwxx[3]*d2rdx2+lbwyy[3]*d2rdy2+lbwxy[3]*d2rdxdy)+c6*(pi_xx   +pi_yy)+0.25*pi_xy;
  f4[0]=lbwi[4]*(rho*(-v1   +1.5*v1v1-0.5*modv)+lambda*(                    3.0*v1*drdy))
       +lbwpt[4]*(pb-lbkappa*nabrp)+lbkappa*(lbwxx[4]*d2rdx2+lbwyy[4]*d2rdy2                 )-c5* pi_xx+c3*pi_yy;
  f5[0]=lbwi[5]*(rho*( v0-v1-3.0*v0v1    +modv)+lambda*(4.5*udr-3.0*v0*drdy-3.0*v1*drdx))
       +lbwpt[5]*(pb-lbkappa*nabrp)+lbkappa*(lbwxx[5]*d2rdx2+lbwyy[5]*d2rdy2+lbwxy[5]*d2rdxdy)+c6*(pi_xx   +pi_yy)-0.25*pi_xy;
  f6[0]=lbwi[6]*(rho*( v0   +1.5*v0v0-0.5*modv)+lambda*(                   3.0*v0*drdx))
       +lbwpt[6]*(pb-lbkappa*nabrp)+lbkappa*(lbwxx[6]*d2rdx2+lbwyy[6]*d2rdy2                 )+c3* pi_xx-c5*pi_yy;
  f7[0]=lbwi[7]*(rho*( v0+v1-3.0*v0v1    +modv)+lambda*(4.5*udr+3.0*v0*drdy+3.0*v1*drdx))
       +lbwpt[7]*(pb-lbkappa*nabrp)+lbkappa*(lbwxx[7]*d2rdx2+lbwyy[7]*d2rdy2+lbwxy[7]*d2rdxdy)+c6*(pi_xx   +pi_yy)+0.25*pi_xy;
  f8[0]=lbwi[8]*(rho*( v1   +1.5*v1v1-0.5*modv)+lambda*(                    3.0*v1*drdy))
       +lbwpt[8]*(pb-lbkappa*nabrp)+lbkappa*(lbwxx[8]*d2rdx2+lbwyy[8]*d2rdy2                 )-c5* pi_xx+c3*pi_yy;
  return 0;
}

int fD2Q9VFRegular(long tpos, long tpos1, int prop, double *uwall, double dx, double dy, double T)
{
  long spos = tpos * lbsitelength;
  int qdim = lbsy.nf+lbsy.nc+lbsy.nt;
  double drdx, drdy, dpdx, dpdy, nabr, nabp;
  double force[2*lbsy.nf],rho[lbsy.nf];
  
  fD2Q9BoundaryForceVelocity(force, tpos, tpos1, dx, dy, uwall, prop);

  if(interact==20) {
    drdx = lbft[4*lbsy.nf*tpos1  ];
    drdy = lbft[4*lbsy.nf*tpos1+1];
    nabr = lbft[4*lbsy.nf*tpos1+3];
    dpdx = (lbsy.nf>1)?lbft[4*lbsy.nf*tpos1+4]:0.0;
    dpdy = (lbsy.nf>1)?lbft[4*lbsy.nf*tpos1+5]:0.0;
    nabp = (lbsy.nf>1)?lbft[4*lbsy.nf*tpos1+3]:0.0;
  }
  else {
    drdx = 0.0;
    drdy = 0.0;
    nabr = 0.0;
    dpdx = 0.0;
    dpdy = 0.0;
    nabp = 0.0;
  }
    
  if(prop>30 && prop<35) {
    fGetAllMassSite(rho, &lbf[tpos1*lbsitelength]);
    if(interact==20) {
      rho[0] += (dx*drdx+dy*drdy);
      if(lbsy.nf>1)
        rho[1] += (dx*dpdx+dy*dpdy);
    }
  }

  if(interact==20) {
    switch (prop) {
      case CETF:
        fD2Q9VCESwiftRegular(uwall[0], uwall[1], &force[0], &lbf[spos], &lbf[spos+1*qdim], &lbf[spos+2*qdim],
                             &lbf[spos+3*qdim], &lbf[spos+4*qdim], &lbf[spos+5*qdim], &lbf[spos+6*qdim],
                             &lbf[spos+7*qdim], &lbf[spos+8*qdim], drdx, drdy, dpdx, dpdy, nabr, nabp,
                             &lbomega[lbsy.nf*tpos], T);
        break;
      case CELF:
        fD2Q9VCESwiftRegular(uwall[1], -uwall[0], &force[0], &lbf[spos], &lbf[spos+3*qdim], &lbf[spos+4*qdim],
                             &lbf[spos+5*qdim], &lbf[spos+6*qdim], &lbf[spos+7*qdim], &lbf[spos+8*qdim],
                             &lbf[spos+1*qdim], &lbf[spos+2*qdim], drdy, -drdx, dpdy, -dpdx, nabr, nabp,
                             &lbomega[lbsy.nf*tpos], T);
        break;
      case CEDF:
        fD2Q9VCESwiftRegular(-uwall[0], -uwall[1], &force[0], &lbf[spos], &lbf[spos+5*qdim], &lbf[spos+6*qdim],
                             &lbf[spos+7*qdim], &lbf[spos+8*qdim], &lbf[spos+1*qdim], &lbf[spos+2*qdim],
                             &lbf[spos+3*qdim], &lbf[spos+4*qdim], -drdx, -drdy, -dpdx, -dpdy, nabr, nabp,
                             &lbomega[lbsy.nf*tpos], T);
        break;
      case CERF:
        fD2Q9VCESwiftRegular(-uwall[1], uwall[0], &force[0], &lbf[spos], &lbf[spos+7*qdim], &lbf[spos+8*qdim],
                             &lbf[spos+1*qdim], &lbf[spos+2*qdim], &lbf[spos+3*qdim], &lbf[spos+4*qdim],
                             &lbf[spos+5*qdim], &lbf[spos+6*qdim], -drdy, drdx, -dpdy, dpdx, nabr, nabp,
                             &lbomega[lbsy.nf*tpos], T);
        break;
      case CCTRF:
        fD2Q9VCCSwiftRegular(rho, uwall[0], uwall[1], &force[0], &lbf[spos], &lbf[spos+1*qdim], &lbf[spos+2*qdim],
                             &lbf[spos+3*qdim], &lbf[spos+4*qdim], &lbf[spos+5*qdim], &lbf[spos+6*qdim],
                             &lbf[spos+7*qdim], &lbf[spos+8*qdim], drdx, drdy, dpdx, dpdy, nabr, nabp,
                             &lbomega[lbsy.nf*tpos], T);
        break;
      case CCTLF:
        fD2Q9VCCSwiftRegular(rho, uwall[1], -uwall[0], &force[0], &lbf[spos], &lbf[spos+3*qdim], &lbf[spos+4*qdim],
                             &lbf[spos+5*qdim], &lbf[spos+6*qdim], &lbf[spos+7*qdim], &lbf[spos+8*qdim],
                             &lbf[spos+1*qdim], &lbf[spos+2*qdim], drdy, -drdx, dpdy, -dpdx, nabr, nabp,
                             &lbomega[lbsy.nf*tpos], T);
        break;
      case CCDLF:
        fD2Q9VCCSwiftRegular(rho, -uwall[0], -uwall[1], &force[0], &lbf[spos], &lbf[spos+5*qdim], &lbf[spos+6*qdim],
                             &lbf[spos+7*qdim], &lbf[spos+8*qdim], &lbf[spos+1*qdim], &lbf[spos+2*qdim],
                             &lbf[spos+3*qdim], &lbf[spos+4*qdim], -drdx, -drdy, -dpdx, -dpdy, nabr, nabp,
                             &lbomega[lbsy.nf*tpos], T);
        break;
      case CCDRF:
        fD2Q9VCCSwiftRegular(rho, -uwall[1], uwall[0], &force[0], &lbf[spos], &lbf[spos+7*qdim], &lbf[spos+8*qdim],
                             &lbf[spos+1*qdim], &lbf[spos+2*qdim], &lbf[spos+3*qdim], &lbf[spos+4*qdim],
                             &lbf[spos+5*qdim], &lbf[spos+6*qdim], -drdy, drdx, -dpdy, dpdx, nabr, nabp,
                             &lbomega[lbsy.nf*tpos], T);
        break;
    }
  }
  else if(collide>11) {
    switch (prop) {
      case CETF:
        fD2Q9VCECLBERegular(uwall[0], uwall[1], &force[0], &lbf[spos], &lbf[spos+1*qdim], &lbf[spos+2*qdim],
                            &lbf[spos+3*qdim], &lbf[spos+4*qdim], &lbf[spos+5*qdim], &lbf[spos+6*qdim],
                            &lbf[spos+7*qdim], &lbf[spos+8*qdim]);
        break;
      case CELF:
        fD2Q9VCECLBERegular(uwall[1], -uwall[0], &force[0], &lbf[spos], &lbf[spos+3*qdim], &lbf[spos+4*qdim],
                            &lbf[spos+5*qdim], &lbf[spos+6*qdim], &lbf[spos+7*qdim], &lbf[spos+8*qdim],
                            &lbf[spos+1*qdim], &lbf[spos+2*qdim]);
        break;
      case CEDF:
        fD2Q9VCECLBERegular(-uwall[0], -uwall[1], &force[0], &lbf[spos], &lbf[spos+5*qdim], &lbf[spos+6*qdim],
                            &lbf[spos+7*qdim], &lbf[spos+8*qdim], &lbf[spos+1*qdim], &lbf[spos+2*qdim],
                            &lbf[spos+3*qdim], &lbf[spos+4*qdim]);
        break;
      case CERF:
        fD2Q9VCECLBERegular(-uwall[1], uwall[0], &force[0], &lbf[spos], &lbf[spos+7*qdim], &lbf[spos+8*qdim],
                            &lbf[spos+1*qdim], &lbf[spos+2*qdim], &lbf[spos+3*qdim], &lbf[spos+4*qdim],
                            &lbf[spos+5*qdim], &lbf[spos+6*qdim]);
        break;
      case CCTRF:
        fD2Q9VCCCLBERegular(rho, uwall[0], uwall[1], &force[0], &lbf[spos], &lbf[spos+1*qdim], &lbf[spos+2*qdim],
                            &lbf[spos+3*qdim], &lbf[spos+4*qdim], &lbf[spos+5*qdim], &lbf[spos+6*qdim],
                            &lbf[spos+7*qdim], &lbf[spos+8*qdim]);
        break;
      case CCTLF:
        fD2Q9VCCCLBERegular(rho, uwall[1], -uwall[0], &force[0], &lbf[spos], &lbf[spos+3*qdim], &lbf[spos+4*qdim],
                            &lbf[spos+5*qdim], &lbf[spos+6*qdim], &lbf[spos+7*qdim], &lbf[spos+8*qdim],
                            &lbf[spos+1*qdim], &lbf[spos+2*qdim]);
        break;
      case CCDLF:
        fD2Q9VCCCLBERegular(rho, -uwall[0], -uwall[1], &force[0], &lbf[spos], &lbf[spos+5*qdim], &lbf[spos+6*qdim],
                            &lbf[spos+7*qdim], &lbf[spos+8*qdim], &lbf[spos+1*qdim], &lbf[spos+2*qdim],
                            &lbf[spos+3*qdim], &lbf[spos+4*qdim]);
        break;
      case CCDRF:
        fD2Q9VCCCLBERegular(rho, -uwall[1], uwall[0], &force[0], &lbf[spos], &lbf[spos+7*qdim], &lbf[spos+8*qdim],
                            &lbf[spos+1*qdim], &lbf[spos+2*qdim], &lbf[spos+3*qdim], &lbf[spos+4*qdim],
                            &lbf[spos+5*qdim], &lbf[spos+6*qdim]);
        break;
    }
  }
  else {
    switch (prop) {
      case CETF:
        fD2Q9VCERegular(uwall[0], uwall[1], &force[0], &lbf[spos], &lbf[spos+1*qdim], &lbf[spos+2*qdim],
                        &lbf[spos+3*qdim], &lbf[spos+4*qdim], &lbf[spos+5*qdim], &lbf[spos+6*qdim],
                        &lbf[spos+7*qdim], &lbf[spos+8*qdim]);
        break;
      case CELF:
        fD2Q9VCERegular(uwall[1], -uwall[0], &force[0], &lbf[spos], &lbf[spos+3*qdim], &lbf[spos+4*qdim],
                        &lbf[spos+5*qdim], &lbf[spos+6*qdim], &lbf[spos+7*qdim], &lbf[spos+8*qdim],
                        &lbf[spos+1*qdim], &lbf[spos+2*qdim]);
        break;
      case CEDF:
        fD2Q9VCERegular(-uwall[0], -uwall[1], &force[0], &lbf[spos], &lbf[spos+5*qdim], &lbf[spos+6*qdim],
                        &lbf[spos+7*qdim], &lbf[spos+8*qdim], &lbf[spos+1*qdim], &lbf[spos+2*qdim],
                        &lbf[spos+3*qdim], &lbf[spos+4*qdim]);
        break;
      case CERF:
        fD2Q9VCERegular(-uwall[1], uwall[0], &force[0], &lbf[spos], &lbf[spos+7*qdim], &lbf[spos+8*qdim],
                        &lbf[spos+1*qdim], &lbf[spos+2*qdim], &lbf[spos+3*qdim], &lbf[spos+4*qdim],
                        &lbf[spos+5*qdim], &lbf[spos+6*qdim]);
        break;
      case CCTRF:
        fD2Q9VCCRegular(rho, uwall[0], uwall[1], &force[0], &lbf[spos], &lbf[spos+1*qdim], &lbf[spos+2*qdim],
                        &lbf[spos+3*qdim], &lbf[spos+4*qdim], &lbf[spos+5*qdim], &lbf[spos+6*qdim],
                        &lbf[spos+7*qdim], &lbf[spos+8*qdim]);
        break;
      case CCTLF:
        fD2Q9VCCRegular(rho, uwall[1], -uwall[0], &force[0], &lbf[spos], &lbf[spos+3*qdim], &lbf[spos+4*qdim],
                        &lbf[spos+5*qdim], &lbf[spos+6*qdim], &lbf[spos+7*qdim], &lbf[spos+8*qdim],
                        &lbf[spos+1*qdim], &lbf[spos+2*qdim]);
        break;
      case CCDLF:
        fD2Q9VCCRegular(rho, -uwall[0], -uwall[1], &force[0], &lbf[spos], &lbf[spos+5*qdim], &lbf[spos+6*qdim],
                        &lbf[spos+7*qdim], &lbf[spos+8*qdim], &lbf[spos+1*qdim], &lbf[spos+2*qdim],
                        &lbf[spos+3*qdim], &lbf[spos+4*qdim]);
        break;
      case CCDRF:
        fD2Q9VCCRegular(rho, -uwall[1], uwall[0], &force[0], &lbf[spos], &lbf[spos+7*qdim], &lbf[spos+8*qdim],
                        &lbf[spos+1*qdim], &lbf[spos+2*qdim], &lbf[spos+3*qdim], &lbf[spos+4*qdim],
                        &lbf[spos+5*qdim], &lbf[spos+6*qdim]);
        break;
    }
  }
  return 0;
}


int fD2Q9PCERegular(double *p, double *force, double *f0, double *f1, double *f2, double *f3,
	                double *f4, double *f5, double *f6, double *f7, double *f8, double &vel)
{

  // produce fixed density/pressure boundary for concave edge pointing upwards (PCETF)

  double rho, rho0, pi_xx, pi_yy, pi_xy, v1v1, v, v1, mass=0.0;
  double c1=1.0/3.0,c2=2.0/3.0,c3=1.0/6.0,c4=1.0/12.0;
    
  vel = 0.0;
  if(!incompress) {
    for(int i=0; i<lbsy.nf; i++) {
      v = p[i]-(f0[i]+f2[i]+f6[i]+2*(f3[i]+f4[i]+f5[i]))+0.5*force[2*i+1];
      vel += v;
      mass += p[i];
    }
    vel *= fReciprocal(mass);
    v1 = vel;
    v1v1 = v1*v1;
    for(int i=0; i<lbsy.nf; i++) {
      rho = p[i];
      pi_xx = f2[i]+f6[i]+2.0*(f3[i]+f5[i])+c1*rho*(v1-1.0);
      pi_yy = 2.0*(f3[i]+f4[i]+f5[i])+rho*(v1-v1v1-c1)+v1*force[2*i+1];
      pi_xy = 2.0*(f3[i]-f5[i])+0.5*v1*force[2*i  ];
      f0[i]=rho*lbw[0]*(1.0       -1.5*v1v1)-c2*(pi_xx+   pi_yy);
      f1[i]=rho*lbw[1]*(1.0+3.0*v1+3.0*v1v1)+c4*(pi_xx+   pi_yy)-0.25*pi_xy;
      f2[i]=rho*lbw[2]*(1.0       -1.5*v1v1)+c1* pi_xx-c3*pi_yy;
      f3[i]=rho*lbw[3]*(1.0-3.0*v1+3.0*v1v1)+c4*(pi_xx+   pi_yy)+0.25*pi_xy;
      f4[i]=rho*lbw[4]*(1.0-3.0*v1+3.0*v1v1)-c3* pi_xx+c1*pi_yy;
      f5[i]=rho*lbw[5]*(1.0-3.0*v1+3.0*v1v1)+c4*(pi_xx+   pi_yy)-0.25*pi_xy;
      f6[i]=rho*lbw[6]*(1.0       -1.5*v1v1)+c1* pi_xx-c3*pi_yy;
      f7[i]=rho*lbw[7]*(1.0+3.0*v1+3.0*v1v1)+c4*(pi_xx+   pi_yy)+0.25*pi_xy;
      f8[i]=rho*lbw[8]*(1.0+3.0*v1+3.0*v1v1)-c3* pi_xx+c1*pi_yy;
    }
  }
  else {
    for(int i=0; i<lbsy.nf; i++) {
      v = p[i]-(f0[i]+f2[i]+f6[i]+2*(f3[i]+f4[i]+f5[i]))+0.5*force[2*i+1];
      vel += v;
      mass += lbincp[i];
    }
    vel *= fReciprocal(mass);
    v1 = vel;
    v1v1 = v1*v1;
    for(int i=0; i<lbsy.nf; i++) {
      rho0 = lbincp[i];
      rho = p[i];
      pi_xx = f2[i]+f6[i]+2.0*(f3[i]+f5[i])+c1*(rho0*v1-rho);
      pi_yy = 2.0*(f3[i]+f4[i]+f5[i])+rho0*(v1-v1v1)-c1*rho+v1*force[2*i+1];
      pi_xy = 2.0*(f3[i]-f5[i])+0.5*v1*force[2*i  ];
      f0[i]=lbw[0]*(rho-rho0*         1.5*v1v1) -c2*(pi_xx   +pi_yy);
      f1[i]=lbw[1]*(rho+rho0*( 3.0*v1+3.0*v1v1))+c4*(pi_xx   +pi_yy)-0.25*pi_xy;
      f2[i]=lbw[2]*(rho+rho0*(       -1.5*v1v1))+c1* pi_xx-c3*pi_yy;
      f3[i]=lbw[3]*(rho+rho0*(-3.0*v1+3.0*v1v1))+c4*(pi_xx   +pi_yy)+0.25*pi_xy;
      f4[i]=lbw[4]*(rho+rho0*(-3.0*v1+3.0*v1v1))-c3* pi_xx+c1*pi_yy;
      f5[i]=lbw[5]*(rho+rho0*(-3.0*v1+3.0*v1v1))+c4*(pi_xx   +pi_yy)-0.25*pi_xy;
      f6[i]=lbw[6]*(rho+rho0*(       -1.5*v1v1))+c1* pi_xx-c3*pi_yy;
      f7[i]=lbw[7]*(rho+rho0*( 3.0*v1+3.0*v1v1))+c4*(pi_xx   +pi_yy)+0.25*pi_xy;
      f8[i]=lbw[8]*(rho+rho0*( 3.0*v1+3.0*v1v1))-c3* pi_xx+c1*pi_yy;
    }
  }
  return 0;
}


int fD2Q9PCESwiftRegular(double *p, double *force, double *f0, double *f1, double *f2, double *f3,
                         double *f4, double *f5, double *f6, double *f7, double *f8,
                         double drdx, double drdy, double dpdx, double dpdy, double nabr, double nabp,
                         double *omega, double T, double &vel)
{

  // produce fixed density/pressure boundary for concave edge pointing upwards (PCETF)
  // with Swift free-energy interactions
    
  double rho, phi, omegat, pb, mu, lambda, d2rdx2, d2rdy2, d2rdxdy, nabrp, v1v1, v, v1;
  double pi_xx, pi_yy, pi_xy, pic_xx, pic_yy, pic_xy;
  double c3=1.0/3.0,c4=2.0/3.0,c5=1.0/6.0,c6=1.0/12.0;
    
  rho = p[0];
  v = p[0]-(f0[0]+f2[0]+f6[0]+2*(f3[0]+f4[0]+f5[0]))+0.5*force[1];
  vel = v*fReciprocal(rho);
  v1 = vel;
  v1v1 = v1*v1;
  if(lbsy.nf>1) {
    phi = p[1];
    omegat = 0.5*(1.0+phi)*omega[0]+0.5*(1.0-phi)*omega[1];
    mu = lbfemob*fGetPotentialSwift(phi, nabp);
    d2rdx2 = (lbfeeos>0)?(drdx*drdx):0.0 + dpdx*dpdx;
    d2rdy2 = (lbfeeos>0)?(drdy*drdy):0.0 + dpdy*dpdy;
    d2rdxdy = (lbfeeos>0)?(drdx*drdy):0.0 + dpdx*dpdy;
    nabrp = (lbfeeos>0)?(rho*nabr):0.0 + phi*nabp;
    pic_xx = f2[1]+f6[1]+2.0*(f3[1]+f5[1])+phi*c3*v1-mu;
    pic_yy = 2.0*(f3[1]+f4[1]+f5[1])+phi*v1*(1.0-v1)-mu;
    pic_xy = 2.0*(f3[1]-f5[1]);
    f0[1]=mu*lbwpt[0]+phi*(1.0    -0.5*lbwi[0]*v1v1)-c4*(pic_xx   +pic_yy);
    f1[1]=mu*lbwpt[1]+phi* lbwi[1]*( v1       +v1v1)+c6*(pic_xx   +pic_yy)-0.25*pic_xy;
    f2[1]=mu*lbwpt[2]+phi* lbwi[2]*(      -0.5*v1v1)+c3* pic_xx-c5*pic_yy;
    f3[1]=mu*lbwpt[3]+phi* lbwi[3]*(-v1       +v1v1)+c6*(pic_xx   +pic_yy)+0.25*pic_xy;
    f4[1]=mu*lbwpt[4]+phi* lbwi[4]*(-v1       +v1v1)-c5* pic_xx+c3*pic_yy;
    f5[1]=mu*lbwpt[5]+phi* lbwi[5]*(-v1       +v1v1)+c6*(pic_xx   +pic_yy)-0.25*pic_xy;
    f6[1]=mu*lbwpt[6]+phi* lbwi[6]*(      -0.5*v1v1)+c3* pic_xx-c5*pic_yy;
    f7[1]=mu*lbwpt[7]+phi* lbwi[7]*( v1       +v1v1)+c6*(pic_xx   +pic_yy)+0.25*pic_xy;
    f8[1]=mu*lbwpt[8]+phi* lbwi[8]*( v1       +v1v1)-c5* pic_xx+c3*pic_yy;
  }
  else {
    phi = 0.0;
    omegat = omega[0];
    d2rdx2 = drdx*drdx;
    d2rdy2 = drdy*drdy;
    d2rdxdy = drdx*drdy;
    nabrp = rho*nabr;
  }
  pb = fGetBulkPressureSwift(rho, phi, T);
  lambda = fGetLambdaSwift(rho, omegat, T);
  pi_xx = f2[0]+f6[0]+2.0*(f3[0]+f5[0])+c3*rho*v1-pb+lbkappa*nabrp-0.5*lbkappa*(d2rdx2-d2rdy2)-1.5*lambda*v1*drdy;
  pi_yy = 2.0*(f3[0]+f4[0]+f5[0])+rho*(v1-v1v1)+v1*force[1]-pb+lbkappa*nabrp+0.5*lbkappa*(d2rdx2-d2rdy2)-3.5*lambda*v1*drdy;
  pi_xy = 2.0*(f3[0]-f5[0])+0.5*v1*force[0]-lambda*v1*drdx-lbkappa*d2rdxdy;
    
  f0[0]=rho*(1.0- 0.5*lbwi[0]*v1v1)+lambda*lbwi[0]*lbwdel[0]*drdy*v1
       +lbwpt[0]*(pb-lbkappa*nabrp)+lbkappa*(lbwxx[0]*d2rdx2+lbwyy[0]*d2rdy2                 )-c4*(pi_xx   +pi_yy);
  f1[0]=lbwi[1]*(rho*( v1    +v1v1)+v1*lambda*(4.5*drdy-3.0*drdx))
       +lbwpt[1]*(pb-lbkappa*nabrp)+lbkappa*(lbwxx[1]*d2rdx2+lbwyy[1]*d2rdy2+lbwxy[1]*d2rdxdy)+c6*(pi_xx   +pi_yy)-0.25*pi_xy;
  f2[0]=lbwi[2]* rho*(   -0.5*v1v1)
       +lbwpt[2]*(pb-lbkappa*nabrp)+lbkappa*(lbwxx[2]*d2rdx2+lbwyy[2]*d2rdy2                 )+c3* pi_xx-c5*pi_yy;
  f3[0]=lbwi[3]*(rho*(-v1    +v1v1)+v1*lambda*(4.5*drdy+3.0*drdx))
       +lbwpt[3]*(pb-lbkappa*nabrp)+lbkappa*(lbwxx[3]*d2rdx2+lbwyy[3]*d2rdy2+lbwxy[3]*d2rdxdy)+c6*(pi_xx   +pi_yy)+0.25*pi_xy;
  f4[0]=lbwi[4]*(rho*(-v1    +v1v1)+v1*lambda*(3.0*drdy         ))
       +lbwpt[4]*(pb-lbkappa*nabrp)+lbkappa*(lbwxx[4]*d2rdx2+lbwyy[4]*d2rdy2                 )-c5* pi_xx+c3*pi_yy;
  f5[0]=lbwi[5]*(rho*(-v1    +v1v1)+v1*lambda*(4.5*drdy-3.0*drdx))
       +lbwpt[5]*(pb-lbkappa*nabrp)+lbkappa*(lbwxx[5]*d2rdx2+lbwyy[5]*d2rdy2+lbwxy[5]*d2rdxdy)+c6*(pi_xx   +pi_yy)-0.25*pi_xy;
  f6[0]=lbwi[6]* rho*(   -0.5*v1v1)
       +lbwpt[6]*(pb-lbkappa*nabrp)+lbkappa*(lbwxx[6]*d2rdx2+lbwyy[6]*d2rdy2                 )+c3* pi_xx-c5*pi_yy;
  f7[0]=lbwi[7]*(rho*( v1    +v1v1)+v1*lambda*(4.5*drdy+3.0*drdx))
       +lbwpt[7]*(pb-lbkappa*nabrp)+lbkappa*(lbwxx[7]*d2rdx2+lbwyy[7]*d2rdy2+lbwxy[7]*d2rdxdy)+c6*(pi_xx   +pi_yy)+0.25*pi_xy;
  f8[0]=lbwi[8]*(rho*( v1    +v1v1)+v1*lambda*(3.0*drdy         ))
       +lbwpt[8]*(pb-lbkappa*nabrp)+lbkappa*(lbwxx[8]*d2rdx2+lbwyy[8]*d2rdy2                 )-c5* pi_xx+c3*pi_yy;
  return 0;
}


int fD2Q9PFRegular(long tpos, int prop, double *p0, double *uwall, double T)
{
  double moment;
  long spos = tpos * lbsitelength;
  int qdim = lbsy.nf+lbsy.nc+lbsy.nt;
  double drdx, drdy, dpdx, dpdy, nabr, nabp;
  double force[2*lbsy.nf];
    
  fD2Q9BoundaryForceDensity(force, tpos, p0, prop);
    
  if(interact==20) {
    drdx = lbft[4*lbsy.nf*tpos  ];
    drdy = lbft[4*lbsy.nf*tpos+1];
    nabr = lbft[4*lbsy.nf*tpos+3];
    dpdx = (lbsy.nf>1)?lbft[4*lbsy.nf*tpos+4]:0.0;
    dpdy = (lbsy.nf>1)?lbft[4*lbsy.nf*tpos+5]:0.0;
    nabp = (lbsy.nf>1)?lbft[4*lbsy.nf*tpos+7]:0.0;
    switch (prop) {
      case CETF:
        fD2Q9PCESwiftRegular(p0, &force[0], &lbf[spos], &lbf[spos+1*qdim], &lbf[spos+2*qdim],
                             &lbf[spos+3*qdim], &lbf[spos+4*qdim], &lbf[spos+5*qdim], &lbf[spos+6*qdim],
                             &lbf[spos+7*qdim], &lbf[spos+8*qdim], drdx, drdy, dpdx, dpdy, nabr, nabp,
                             &lbomega[lbsy.nf*tpos], T, moment);
        uwall[1] += moment;
        break;
      case CELF:
        fD2Q9PCESwiftRegular(p0, &force[0], &lbf[spos], &lbf[spos+3*qdim], &lbf[spos+4*qdim],
                             &lbf[spos+5*qdim], &lbf[spos+6*qdim], &lbf[spos+7*qdim], &lbf[spos+8*qdim],
                             &lbf[spos+1*qdim], &lbf[spos+2*qdim], drdy, -drdx, dpdy, -dpdx, nabr, nabp,
                             &lbomega[lbsy.nf*tpos], T, moment);
        uwall[0] -= moment;
        break;
      case CEDF:
        fD2Q9PCESwiftRegular(p0, &force[0], &lbf[spos], &lbf[spos+5*qdim], &lbf[spos+6*qdim],
                             &lbf[spos+7*qdim], &lbf[spos+8*qdim], &lbf[spos+1*qdim], &lbf[spos+2*qdim],
                             &lbf[spos+3*qdim], &lbf[spos+4*qdim], -drdx, -drdy, -dpdx, -dpdy, nabr, nabp,
                             &lbomega[lbsy.nf*tpos], T, moment);
        uwall[1] -= moment;
        break;
      case CERF:
        fD2Q9PCESwiftRegular(p0, &force[0], &lbf[spos], &lbf[spos+7*qdim], &lbf[spos+8*qdim],
                             &lbf[spos+1*qdim], &lbf[spos+2*qdim], &lbf[spos+3*qdim], &lbf[spos+4*qdim],
                             &lbf[spos+5*qdim], &lbf[spos+6*qdim], -drdy, drdx, -dpdy, dpdx, nabr, nabp,
                             &lbomega[lbsy.nf*tpos], T, moment);
        uwall[0] += moment;
        break;
      case CCTRF:
        fD2Q9VCCSwiftRegular(p0, uwall[0], uwall[1], &force[0], &lbf[spos], &lbf[spos+1*qdim], &lbf[spos+2*qdim],
                             &lbf[spos+3*qdim], &lbf[spos+4*qdim], &lbf[spos+5*qdim], &lbf[spos+6*qdim],
                             &lbf[spos+7*qdim], &lbf[spos+8*qdim], drdx, drdy, dpdx, dpdy, nabr, nabp,
                             &lbomega[lbsy.nf*tpos], T);
        break;
      case CCTLF:
        fD2Q9VCCSwiftRegular(p0, uwall[1], -uwall[0], &force[0], &lbf[spos], &lbf[spos+3*qdim], &lbf[spos+4*qdim],
                             &lbf[spos+5*qdim], &lbf[spos+6*qdim], &lbf[spos+7*qdim], &lbf[spos+8*qdim],
                             &lbf[spos+1*qdim], &lbf[spos+2*qdim], drdy, -drdx, dpdy, -dpdx, nabr, nabp,
                             &lbomega[lbsy.nf*tpos], T);
        break;
      case CCDLF:
        fD2Q9VCCSwiftRegular(p0, -uwall[0], -uwall[1], &force[0], &lbf[spos], &lbf[spos+5*qdim], &lbf[spos+6*qdim],
                             &lbf[spos+7*qdim], &lbf[spos+8*qdim], &lbf[spos+1*qdim], &lbf[spos+2*qdim],
                             &lbf[spos+3*qdim], &lbf[spos+4*qdim], -drdx, -drdy, -dpdx, -dpdy, nabr, nabp,
                             &lbomega[lbsy.nf*tpos], T);
        break;
      case CCDRF:
        fD2Q9VCCSwiftRegular(p0, -uwall[1], uwall[0], &force[0], &lbf[spos], &lbf[spos+7*qdim], &lbf[spos+8*qdim],
                             &lbf[spos+1*qdim], &lbf[spos+2*qdim], &lbf[spos+3*qdim], &lbf[spos+4*qdim],
                             &lbf[spos+5*qdim], &lbf[spos+6*qdim], -drdy, drdx, -dpdy, dpdx, nabr, nabp,
                             &lbomega[lbsy.nf*tpos], T);
        break;
    }
  }
  else if(collide>11){
    switch (prop) {
      case CETF:
        fD2Q9PCERegular(p0, &force[0], &lbf[spos], &lbf[spos+1*qdim], &lbf[spos+2*qdim],
                        &lbf[spos+3*qdim], &lbf[spos+4*qdim], &lbf[spos+5*qdim],
                        &lbf[spos+6*qdim], &lbf[spos+7*qdim], &lbf[spos+8*qdim], moment);
        uwall[1] += moment;
        break;
      case CELF:
        fD2Q9PCERegular(p0, &force[0], &lbf[spos], &lbf[spos+3*qdim], &lbf[spos+4*qdim],
                        &lbf[spos+5*qdim], &lbf[spos+6*qdim], &lbf[spos+7*qdim],
                        &lbf[spos+8*qdim], &lbf[spos+1*qdim], &lbf[spos+2*qdim], moment);
        uwall[0] -= moment;
        break;
      case CEDF:
        fD2Q9PCERegular(p0, &force[0], &lbf[spos], &lbf[spos+5*qdim], &lbf[spos+6*qdim],
  	                    &lbf[spos+7*qdim], &lbf[spos+8*qdim], &lbf[spos+1*qdim],
	                    &lbf[spos+2*qdim], &lbf[spos+3*qdim], &lbf[spos+4*qdim], moment);
        uwall[1] -= moment;
        break;
      case CERF:
        fD2Q9PCERegular(p0, &force[0], &lbf[spos], &lbf[spos+7*qdim], &lbf[spos+8*qdim],
                        &lbf[spos+1*qdim], &lbf[spos+2*qdim], &lbf[spos+3*qdim],
                        &lbf[spos+4*qdim], &lbf[spos+5*qdim], &lbf[spos+6*qdim], moment);
        uwall[0] += moment;
        break;
      case CCTRF:
        fD2Q9VCCCLBERegular(p0, uwall[0], uwall[1], &force[0], &lbf[spos], &lbf[spos+1*qdim], &lbf[spos+2*qdim],
                            &lbf[spos+3*qdim], &lbf[spos+4*qdim], &lbf[spos+5*qdim], &lbf[spos+6*qdim],
                            &lbf[spos+7*qdim], &lbf[spos+8*qdim]);
        break;
      case CCTLF:
        fD2Q9VCCCLBERegular(p0, uwall[1], -uwall[0], &force[0], &lbf[spos], &lbf[spos+3*qdim], &lbf[spos+4*qdim],
                            &lbf[spos+5*qdim], &lbf[spos+6*qdim], &lbf[spos+7*qdim], &lbf[spos+8*qdim],
                            &lbf[spos+1*qdim], &lbf[spos+2*qdim]);
        break;
      case CCDLF:
        fD2Q9VCCCLBERegular(p0, -uwall[0], -uwall[1], &force[0], &lbf[spos], &lbf[spos+5*qdim], &lbf[spos+6*qdim],
                            &lbf[spos+7*qdim], &lbf[spos+8*qdim], &lbf[spos+1*qdim], &lbf[spos+2*qdim],
                            &lbf[spos+3*qdim], &lbf[spos+4*qdim]);
        break;
      case CCDRF:
        fD2Q9VCCCLBERegular(p0, -uwall[1], uwall[0], &force[0], &lbf[spos], &lbf[spos+7*qdim], &lbf[spos+8*qdim],
                            &lbf[spos+1*qdim], &lbf[spos+2*qdim], &lbf[spos+3*qdim], &lbf[spos+4*qdim],
                            &lbf[spos+5*qdim], &lbf[spos+6*qdim]);
        break;
    }
  }
  else {
    switch (prop) {
      case CETF:
        fD2Q9PCERegular(p0, &force[0], &lbf[spos], &lbf[spos+1*qdim], &lbf[spos+2*qdim],
                        &lbf[spos+3*qdim], &lbf[spos+4*qdim], &lbf[spos+5*qdim],
                        &lbf[spos+6*qdim], &lbf[spos+7*qdim], &lbf[spos+8*qdim], moment);
        uwall[1] += moment;
        break;
      case CELF:
        fD2Q9PCERegular(p0, &force[0], &lbf[spos], &lbf[spos+3*qdim], &lbf[spos+4*qdim],
                        &lbf[spos+5*qdim], &lbf[spos+6*qdim], &lbf[spos+7*qdim],
                        &lbf[spos+8*qdim], &lbf[spos+1*qdim], &lbf[spos+2*qdim], moment);
        uwall[0] -= moment;
        break;
      case CEDF:
        fD2Q9PCERegular(p0, &force[0], &lbf[spos], &lbf[spos+5*qdim], &lbf[spos+6*qdim],
  	                    &lbf[spos+7*qdim], &lbf[spos+8*qdim], &lbf[spos+1*qdim],
	                    &lbf[spos+2*qdim], &lbf[spos+3*qdim], &lbf[spos+4*qdim], moment);
        uwall[1] -= moment;
        break;
      case CERF:
        fD2Q9PCERegular(p0, &force[0], &lbf[spos], &lbf[spos+7*qdim], &lbf[spos+8*qdim],
                        &lbf[spos+1*qdim], &lbf[spos+2*qdim], &lbf[spos+3*qdim],
                        &lbf[spos+4*qdim], &lbf[spos+5*qdim], &lbf[spos+6*qdim], moment);
        uwall[0] += moment;
        break;
      case CCTRF:
        fD2Q9VCCRegular(p0, uwall[0], uwall[1], &force[0], &lbf[spos], &lbf[spos+1*qdim], &lbf[spos+2*qdim],
                        &lbf[spos+3*qdim], &lbf[spos+4*qdim], &lbf[spos+5*qdim], &lbf[spos+6*qdim],
                        &lbf[spos+7*qdim], &lbf[spos+8*qdim]);
        break;
      case CCTLF:
        fD2Q9VCCRegular(p0, uwall[1], -uwall[0], &force[0], &lbf[spos], &lbf[spos+3*qdim], &lbf[spos+4*qdim],
                        &lbf[spos+5*qdim], &lbf[spos+6*qdim], &lbf[spos+7*qdim], &lbf[spos+8*qdim],
                        &lbf[spos+1*qdim], &lbf[spos+2*qdim]);
        break;
      case CCDLF:
        fD2Q9VCCRegular(p0, -uwall[0], -uwall[1], &force[0], &lbf[spos], &lbf[spos+5*qdim], &lbf[spos+6*qdim],
                        &lbf[spos+7*qdim], &lbf[spos+8*qdim], &lbf[spos+1*qdim], &lbf[spos+2*qdim],
                        &lbf[spos+3*qdim], &lbf[spos+4*qdim]);
        break;
      case CCDRF:
        fD2Q9VCCRegular(p0, -uwall[1], uwall[0], &force[0], &lbf[spos], &lbf[spos+7*qdim], &lbf[spos+8*qdim],
                        &lbf[spos+1*qdim], &lbf[spos+2*qdim], &lbf[spos+3*qdim], &lbf[spos+4*qdim],
                        &lbf[spos+5*qdim], &lbf[spos+6*qdim]);
        break;
    }
  }
  return 0;
}


// D3Q15

int fD3Q15VPSRegular(double v0, double v1, double v2, double *force, double *f0, double *f1, double *f2,
                     double *f3, double *f4, double *f5, double *f6, double *f7, double *f8,
                     double *f9, double *f10, double *f11, double *f12, double *f13, double *f14)
{

  // produce fixed velocity at bottom boundary (VPST) for compressible/incompressible fluids
    
  double rho, rho0, modv, pi_xx, pi_yy, pi_zz, pi_xy, pi_xz, pi_yz, v0v0, v0v1, v0v2, v1v1, v1v2, v2v2;
  double c1=1.0/3.0,c2=1.0/6.0,c3=1.0/24.0;

  v0v0 = v0*v0;
  v0v1 = v0*v1;
  v0v2 = v0*v2;
  v1v1 = v1*v1;
  v1v2 = v1*v2;
  v2v2 = v2*v2;
  modv = v0v0+v1v1+v2v2;
    
  if(!incompress) {
    for(int i=0; i<lbsy.nf; i++) {
      rho = (f0[i]+f1[i]+f3[i]+f8[i]+f10[i]+2*(f2[i]+f4[i]+f5[i]+f13[i]+f14[i])-0.5*force[3*i+1])/(1.0-v1);
      pi_xx = f1[i]+f8[i]+2.0*(f4[i]+f5[i]+f13[i]+f14[i])+rho*(c1*(v1-1.0)-v0v0)+v0*force[3*i  ];
      pi_yy = 2.0*(f2[i]+f4[i]+f5[i]+f13[i]+f14[i])+rho*(v1-v1v1-c1)+v1*force[3*i+1];
      pi_zz = f3[i]+f10[i]+2.0*(f4[i]+f5[i]+f13[i]+f14[i])+rho*(c1*(v1-1.0)-v2v2)+v2*force[3*i+2];
      pi_xy = 2.0*(f4[i]+f5[i]-f13[i]-f14[i])+rho*(c1*v0-v0v1)+0.5*(v1*force[3*i  ]+v0*force[3*i+1]);
      pi_xz = 2.0*(f4[i]-f5[i]+f13[i]-f14[i])-rho*v0v2+0.5*(v2*force[3*i  ]+v0*force[3*i+2]);
      pi_yz = 2.0*(f4[i]-f5[i]-f13[i]+f14[i])+rho*(c1*v2-v1v2)+0.5*(v2*force[3*i+1]+v1*force[3*i+2]);
      f0[i] =rho*lbw[0] *(1.0                                    -1.5*modv)-c1*(pi_xx+   pi_yy+   pi_zz);
      f1[i] =rho*lbw[1] *(1.0-3.0*v0        +4.5* v0v0           -1.5*modv)+c1* pi_xx-c2*pi_yy-c2*pi_zz;
      f2[i] =rho*lbw[2] *(1.0-3.0*v1        +4.5* v1v1           -1.5*modv)-c2* pi_xx+c1*pi_yy-c2*pi_zz;
      f3[i] =rho*lbw[3] *(1.0-3.0*v2        +4.5* v2v2           -1.5*modv)-c2* pi_xx-c2*pi_yy+c1*pi_zz;
      f4[i] =rho*lbw[4] *(1.0-3.0*(v0+v1+v2)+9.0*(v0v1+v0v2+v1v2)+3.0*modv)+c3*(pi_xx+   pi_yy+   pi_zz)+0.125*(pi_xy+pi_xz+pi_yz);
      f5[i] =rho*lbw[5] *(1.0-3.0*(v0+v1-v2)+9.0*(v0v1-v0v2-v1v2)+3.0*modv)+c3*(pi_xx+   pi_yy+   pi_zz)+0.125*(pi_xy-pi_xz-pi_yz);
      f6[i] =rho*lbw[6] *(1.0-3.0*(v0-v1+v2)-9.0*(v0v1-v0v2+v1v2)+3.0*modv)+c3*(pi_xx+   pi_yy+   pi_zz)-0.125*(pi_xy-pi_xz+pi_yz);
      f7[i] =rho*lbw[7] *(1.0-3.0*(v0-v1-v2)-9.0*(v0v1+v0v2-v1v2)+3.0*modv)+c3*(pi_xx+   pi_yy+   pi_zz)-0.125*(pi_xy+pi_xz-pi_yz);
      f8[i] =rho*lbw[8] *(1.0+3.0*v0        +4.5* v0v0           -1.5*modv)+c1* pi_xx-c2*pi_yy-c2*pi_zz;
      f9[i] =rho*lbw[9] *(1.0+3.0*v1        +4.5* v1v1           -1.5*modv)-c2* pi_xx+c1*pi_yy-c2*pi_zz;
      f10[i]=rho*lbw[10]*(1.0+3.0*v2        +4.5* v2v2           -1.5*modv)-c2* pi_xx-c2*pi_yy+c1*pi_zz;
      f11[i]=rho*lbw[11]*(1.0+3.0*(v0+v1+v2)+9.0*(v0v1+v0v2+v1v2)+3.0*modv)+c3*(pi_xx+   pi_yy+   pi_zz)+0.125*(pi_xy+pi_xz+pi_yz);
      f12[i]=rho*lbw[12]*(1.0+3.0*(v0+v1-v2)+9.0*(v0v1-v0v2-v1v2)+3.0*modv)+c3*(pi_xx+   pi_yy+   pi_zz)+0.125*(pi_xy-pi_xz-pi_yz);
      f13[i]=rho*lbw[13]*(1.0+3.0*(v0-v1+v2)-9.0*(v0v1-v0v2+v1v2)+3.0*modv)+c3*(pi_xx+   pi_yy+   pi_zz)-0.125*(pi_xy-pi_xz+pi_yz);
      f14[i]=rho*lbw[14]*(1.0+3.0*(v0-v1-v2)-9.0*(v0v1+v0v2-v1v2)+3.0*modv)+c3*(pi_xx+   pi_yy+   pi_zz)-0.125*(pi_xy+pi_xz-pi_yz);
    }
  }
  else {
    for(int i=0; i<lbsy.nf; i++) {
      rho0 = lbincp[i];
      rho = f0[i]+f1[i]+f3[i]+f8[i]+f10[i]+2*(f2[i]+f4[i]+f5[i]+f13[i]+f14[i])+rho0*v1-0.5*force[3*i+1];
      pi_xx = f1[i]+f8[i]+2.0*(f4[i]+f5[i]+f13[i]+f14[i])+rho0*(c1*v1-v0v0)-c1*rho+v0*force[3*i  ];
      pi_yy = 2.0*(f2[i]+f4[i]+f5[i]+f13[i]+f14[i])+rho0*(v1-v1v1)-c1*rho+v1*force[3*i+1];
      pi_zz = f3[i]+f10[i]+2.0*(f4[i]+f5[i]+f13[i]+f14[i])+rho0*(c1*v1-v2v2)-c1*rho+v2*force[3*i+2];
      pi_xy = 2.0*(f4[i]+f5[i]-f13[i]-f14[i])+rho0*(c1*v0-v0v1)+0.5*(v1*force[3*i  ]+v0*force[3*i+1]);
      pi_xz = 2.0*(f4[i]-f5[i]+f13[i]-f14[i])-rho0*v0v2+0.5*(v2*force[3*i  ]+v0*force[3*i+2]);
      pi_yz = 2.0*(f4[i]-f5[i]-f13[i]+f14[i])+rho0*(c1*v2-v1v2)+0.5*(v2*force[3*i+1]+v1*force[3*i+2]);
      f0[i] =lbw[0] *(rho+rho0*(                                    -1.5*modv))-c1*(pi_xx+   pi_yy+   pi_zz);
      f1[i] =lbw[1] *(rho+rho0*(-3.0*v0        +4.5* v0v0           -1.5*modv))+c1* pi_xx-c2*pi_yy-c2*pi_zz;
      f2[i] =lbw[2] *(rho+rho0*(-3.0*v1        +4.5* v1v1           -1.5*modv))-c2* pi_xx+c1*pi_yy-c2*pi_zz;
      f3[i] =lbw[3] *(rho+rho0*(-3.0*v2        +4.5* v2v2           -1.5*modv))-c2* pi_xx-c2*pi_yy+c1*pi_zz;
      f4[i] =lbw[4] *(rho+rho0*(-3.0*(v0+v1+v2)+9.0*(v0v1+v0v2+v1v2)+3.0*modv))+c3*(pi_xx+   pi_yy+   pi_zz)+0.125*(pi_xy+pi_xz+pi_yz);
      f5[i] =lbw[5] *(rho+rho0*(-3.0*(v0+v1-v2)+9.0*(v0v1-v0v2-v1v2)+3.0*modv))+c3*(pi_xx+   pi_yy+   pi_zz)+0.125*(pi_xy-pi_xz-pi_yz);
      f6[i] =lbw[6] *(rho+rho0*(-3.0*(v0-v1+v2)-9.0*(v0v1-v0v2+v1v2)+3.0*modv))+c3*(pi_xx+   pi_yy+   pi_zz)-0.125*(pi_xy-pi_xz+pi_yz);
      f7[i] =lbw[7] *(rho+rho0*(-3.0*(v0-v1-v2)-9.0*(v0v1+v0v2-v1v2)+3.0*modv))+c3*(pi_xx+   pi_yy+   pi_zz)-0.125*(pi_xy+pi_xz-pi_yz);
      f8[i] =lbw[8] *(rho+rho0*( 3.0*v0        +4.5* v0v0           -1.5*modv))+c1* pi_xx-c2*pi_yy-c2*pi_zz;
      f9[i] =lbw[9] *(rho+rho0*( 3.0*v1        +4.5* v1v1           -1.5*modv))-c2* pi_xx+c1*pi_yy-c2*pi_zz;
      f10[i]=lbw[10]*(rho+rho0*( 3.0*v2        +4.5* v2v2           -1.5*modv))-c2* pi_xx-c2*pi_yy+c1*pi_zz;
      f11[i]=lbw[11]*(rho+rho0*( 3.0*(v0+v1+v2)+9.0*(v0v1+v0v2+v1v2)+3.0*modv))+c3*(pi_xx+   pi_yy+   pi_zz)+0.125*(pi_xy+pi_xz+pi_yz);
      f12[i]=lbw[12]*(rho+rho0*( 3.0*(v0+v1-v2)+9.0*(v0v1-v0v2-v1v2)+3.0*modv))+c3*(pi_xx+   pi_yy+   pi_zz)+0.125*(pi_xy-pi_xz-pi_yz);
      f13[i]=lbw[13]*(rho+rho0*( 3.0*(v0-v1+v2)-9.0*(v0v1-v0v2+v1v2)+3.0*modv))+c3*(pi_xx+   pi_yy+   pi_zz)-0.125*(pi_xy-pi_xz+pi_yz);
      f14[i]=lbw[14]*(rho+rho0*( 3.0*(v0-v1-v2)-9.0*(v0v1+v0v2-v1v2)+3.0*modv))+c3*(pi_xx+   pi_yy+   pi_zz)-0.125*(pi_xy+pi_xz-pi_yz);
    }
  }
  return 0;
}

int fD3Q15VCERegular(double *p, double v0, double v1, double v2, double *force, double *f0, double *f1, double *f2,
                     double *f3, double *f4, double *f5, double *f6, double *f7, double *f8,
                     double *f9, double *f10, double *f11, double *f12, double *f13, double *f14)
{

  // produce fixed velocity at bottom left edge (VCETR) for compressible/incompressible fluids
    
  double rho0, modv, pi_xx, pi_yy, pi_zz, pi_xy, pi_xz, pi_yz, v0v0, v0v1, v0v2, v1v1, v1v2, v2v2;
  double c1=1.0/3.0,c2=1.0/6.0,c3=1.0/24.0,c4=2.0/3.0;

  v0v0 = v0*v0;
  v0v1 = v0*v1;
  v0v2 = v0*v2;
  v1v1 = v1*v1;
  v1v2 = v1*v2;
  v2v2 = v2*v2;
  modv = v0v0+v1v1+v2v2;
    
  if(!incompress) {
    for(int i=0; i<lbsy.nf; i++) {
      pi_xx = -f0[i]-f3[i]-f10[i]-2.0*f2[i]+p[i]*(c4-c4*v1-v0v0)+v0*force[3*i  ];
      pi_yy = -f0[i]-f3[i]-f10[i]-2.0*f1[i]+p[i]*(c4-c4*v0-v1v1)+v1*force[3*i+1];
      pi_zz = -f0[i]-2.0*(f1[i]+f2[i])+p[i]*(c4-c4*(v0+v1)-v2v2)+v2*force[3*i+2];
      pi_xy = f0[i]+f3[i]+f10[i]+2.0*(f1[i]+f2[i])+4.0*(f4[i]+f5[i])-p[i]*(1.0-v0)*(1.0-v1)+0.5*(v1*force[3*i  ]+v0*force[3*i+1]);
      pi_xz = 2.0*(f4[i]-f5[i])+p[i]*v2*(c2-v0)+0.5*(v2*force[3*i  ]+v0*force[3*i+2]);
      pi_yz = 2.0*(f4[i]-f5[i])+p[i]*v2*(c2-v1)+0.5*(v2*force[3*i+1]+v1*force[3*i+2]);
      f0[i] =p[i]*lbw[0] *(1.0                                    -1.5*modv)-c1*(pi_xx+   pi_yy+   pi_zz);
      f1[i] =p[i]*lbw[1] *(1.0-3.0*v0        +4.5* v0v0           -1.5*modv)+c1* pi_xx-c2*pi_yy-c2*pi_zz;
      f2[i] =p[i]*lbw[2] *(1.0-3.0*v1        +4.5* v1v1           -1.5*modv)-c2* pi_xx+c1*pi_yy-c2*pi_zz;
      f3[i] =p[i]*lbw[3] *(1.0-3.0*v2        +4.5* v2v2           -1.5*modv)-c2* pi_xx-c2*pi_yy+c1*pi_zz;
      f4[i] =p[i]*lbw[4] *(1.0-3.0*(v0+v1+v2)+9.0*(v0v1+v0v2+v1v2)+3.0*modv)+c3*(pi_xx+   pi_yy+   pi_zz)+0.125*(pi_xy+pi_xz+pi_yz);
      f5[i] =p[i]*lbw[5] *(1.0-3.0*(v0+v1-v2)+9.0*(v0v1-v0v2-v1v2)+3.0*modv)+c3*(pi_xx+   pi_yy+   pi_zz)+0.125*(pi_xy-pi_xz-pi_yz);
      f6[i] =p[i]*lbw[6] *(1.0-3.0*(v0-v1+v2)-9.0*(v0v1-v0v2+v1v2)+3.0*modv)+c3*(pi_xx+   pi_yy+   pi_zz)-0.125*(pi_xy-pi_xz+pi_yz);
      f7[i] =p[i]*lbw[7] *(1.0-3.0*(v0-v1-v2)-9.0*(v0v1+v0v2-v1v2)+3.0*modv)+c3*(pi_xx+   pi_yy+   pi_zz)-0.125*(pi_xy+pi_xz-pi_yz);
      f8[i] =p[i]*lbw[8] *(1.0+3.0*v0        +4.5* v0v0           -1.5*modv)+c1* pi_xx-c2*pi_yy-c2*pi_zz;
      f9[i] =p[i]*lbw[9] *(1.0+3.0*v1        +4.5* v1v1           -1.5*modv)-c2* pi_xx+c1*pi_yy-c2*pi_zz;
      f10[i]=p[i]*lbw[10]*(1.0+3.0*v2        +4.5* v2v2           -1.5*modv)-c2* pi_xx-c2*pi_yy+c1*pi_zz;
      f11[i]=p[i]*lbw[11]*(1.0+3.0*(v0+v1+v2)+9.0*(v0v1+v0v2+v1v2)+3.0*modv)+c3*(pi_xx+   pi_yy+   pi_zz)+0.125*(pi_xy+pi_xz+pi_yz);
      f12[i]=p[i]*lbw[12]*(1.0+3.0*(v0+v1-v2)+9.0*(v0v1-v0v2-v1v2)+3.0*modv)+c3*(pi_xx+   pi_yy+   pi_zz)+0.125*(pi_xy-pi_xz-pi_yz);
      f13[i]=p[i]*lbw[13]*(1.0+3.0*(v0-v1+v2)-9.0*(v0v1-v0v2+v1v2)+3.0*modv)+c3*(pi_xx+   pi_yy+   pi_zz)-0.125*(pi_xy-pi_xz+pi_yz);
      f14[i]=p[i]*lbw[14]*(1.0+3.0*(v0-v1-v2)-9.0*(v0v1+v0v2-v1v2)+3.0*modv)+c3*(pi_xx+   pi_yy+   pi_zz)-0.125*(pi_xy+pi_xz-pi_yz);
    }
  }
  else {
    for(int i=0; i<lbsy.nf; i++) {
      rho0 = lbincp[i];
      pi_xx = -f0[i]-f3[i]-f10[i]-2.0*f2[i]+c4*p[i]-rho0*(c4*v1+v0v0)+v0*force[3*i  ];
      pi_yy = -f0[i]-f3[i]-f10[i]-2.0*f1[i]+c4*p[i]-rho0*(c4*v0+v1v1)+v1*force[3*i+1];
      pi_zz = -f0[i]-2.0*(f1[i]+f2[i])+c4*p[i]-rho0*(c4*(v0+v1)+v2v2)+v2*force[3*i+2];
      pi_xy = f0[i]+f3[i]+f10[i]+2.0*(f1[i]+f2[i])+4.0*(f4[i]+f5[i])-p[i]+rho0*(v0+v1-v0v1)+0.5*(v1*force[3*i  ]+v0*force[3*i+1]);
      pi_xz = 2.0*(f4[i]-f5[i])+rho0*v2*(c2-v0)+0.5*(v2*force[3*i  ]+v0*force[3*i+2]);
      pi_yz = 2.0*(f4[i]-f5[i])+rho0*v2*(c2-v1)+0.5*(v2*force[3*i+1]+v1*force[3*i+2]);
      f0[i] =lbw[0] *(p[i]+rho0*(                                    -1.5*modv))-c1*(pi_xx+   pi_yy+   pi_zz);
      f1[i] =lbw[1] *(p[i]+rho0*(-3.0*v0        +4.5* v0v0           -1.5*modv))+c1* pi_xx-c2*pi_yy-c2*pi_zz;
      f2[i] =lbw[2] *(p[i]+rho0*(-3.0*v1        +4.5* v1v1           -1.5*modv))-c2* pi_xx+c1*pi_yy-c2*pi_zz;
      f3[i] =lbw[3] *(p[i]+rho0*(-3.0*v2        +4.5* v2v2           -1.5*modv))-c2* pi_xx-c2*pi_yy+c1*pi_zz;
      f4[i] =lbw[4] *(p[i]+rho0*(-3.0*(v0+v1+v2)+9.0*(v0v1+v0v2+v1v2)+3.0*modv))+c3*(pi_xx+   pi_yy+   pi_zz)+0.125*(pi_xy+pi_xz+pi_yz);
      f5[i] =lbw[5] *(p[i]+rho0*(-3.0*(v0+v1-v2)+9.0*(v0v1-v0v2-v1v2)+3.0*modv))+c3*(pi_xx+   pi_yy+   pi_zz)+0.125*(pi_xy-pi_xz-pi_yz);
      f6[i] =lbw[6] *(p[i]+rho0*(-3.0*(v0-v1+v2)-9.0*(v0v1-v0v2+v1v2)+3.0*modv))+c3*(pi_xx+   pi_yy+   pi_zz)-0.125*(pi_xy-pi_xz+pi_yz);
      f7[i] =lbw[7] *(p[i]+rho0*(-3.0*(v0-v1-v2)-9.0*(v0v1+v0v2-v1v2)+3.0*modv))+c3*(pi_xx+   pi_yy+   pi_zz)-0.125*(pi_xy+pi_xz-pi_yz);
      f8[i] =lbw[8] *(p[i]+rho0*( 3.0*v0        +4.5* v0v0           -1.5*modv))+c1* pi_xx-c2*pi_yy-c2*pi_zz;
      f9[i] =lbw[9] *(p[i]+rho0*( 3.0*v1        +4.5* v1v1           -1.5*modv))-c2* pi_xx+c1*pi_yy-c2*pi_zz;
      f10[i]=lbw[10]*(p[i]+rho0*( 3.0*v2        +4.5* v2v2           -1.5*modv))-c2* pi_xx-c2*pi_yy+c1*pi_zz;
      f11[i]=lbw[11]*(p[i]+rho0*( 3.0*(v0+v1+v2)+9.0*(v0v1+v0v2+v1v2)+3.0*modv))+c3*(pi_xx+   pi_yy+   pi_zz)+0.125*(pi_xy+pi_xz+pi_yz);
      f12[i]=lbw[12]*(p[i]+rho0*( 3.0*(v0+v1-v2)+9.0*(v0v1-v0v2-v1v2)+3.0*modv))+c3*(pi_xx+   pi_yy+   pi_zz)+0.125*(pi_xy-pi_xz-pi_yz);
      f13[i]=lbw[13]*(p[i]+rho0*( 3.0*(v0-v1+v2)-9.0*(v0v1-v0v2+v1v2)+3.0*modv))+c3*(pi_xx+   pi_yy+   pi_zz)-0.125*(pi_xy-pi_xz+pi_yz);
      f14[i]=lbw[14]*(p[i]+rho0*( 3.0*(v0-v1-v2)-9.0*(v0v1+v0v2-v1v2)+3.0*modv))+c3*(pi_xx+   pi_yy+   pi_zz)-0.125*(pi_xy+pi_xz-pi_yz);
    }
  }
  return 0;
}

int fD3Q15VCCRegular(double *p, double v0, double v1, double v2, double *force, double *f0, double *f1, double *f2,
                     double *f3, double *f4, double *f5, double *f6, double *f7, double *f8,
                     double *f9, double *f10, double *f11, double *f12, double *f13, double *f14)
{

  // produce fixed velocity at bottom left back corner (VCCTRF) for compressible/incompressible fluids
    
  double rho0, modv, pi_xx, pi_yy, pi_zz, pi_xy, pi_xz, pi_yz, v0v0, v0v1, v0v2, v1v1, v1v2, v2v2;
  double c1=1.0/3.0,c2=1.0/6.0,c3=1.0/24.0,c4=2.0/3.0,c5=8.0/3.0;

  v0v0 = v0*v0;
  v0v1 = v0*v1;
  v0v2 = v0*v2;
  v1v1 = v1*v1;
  v1v2 = v1*v2;
  v2v2 = v2*v2;
  modv = v0v0+v1v1+v2v2;
    
  if(!incompress) {
    for(int i=0; i<lbsy.nf; i++) {
      pi_xx = -f0[i]-2.0*(f2[i]+f3[i])+p[i]*(c4-c4*(v1+v2)-v0v0)+v0*force[3*i  ];
      pi_yy = -f0[i]-2.0*(f1[i]+f3[i])+p[i]*(c4-c4*(v0+v2)-v1v1)+v1*force[3*i+1];
      pi_zz = -f0[i]-2.0*(f1[i]+f2[i])+p[i]*(c4-c4*(v0+v1)-v2v2)+v2*force[3*i+2];
      pi_xy = c1*f0[i]+c4*(f1[i]+f2[i]+f3[i])+c5*f4[i]-c1*p[i]*(1.0-v0-v1-v2+3.0*v0v1)+0.5*(v1*force[3*i  ]+v0*force[3*i+1]);
      pi_xz = c1*f0[i]+c4*(f1[i]+f2[i]+f3[i])+c5*f4[i]-c1*p[i]*(1.0-v0-v1-v2+3.0*v0v2)+0.5*(v2*force[3*i  ]+v0*force[3*i+2]);
      pi_yz = c1*f0[i]+c4*(f1[i]+f2[i]+f3[i])+c5*f4[i]-c1*p[i]*(1.0-v0-v1-v2+3.0*v1v2)+0.5*(v2*force[3*i+1]+v1*force[3*i+2]);
      f0[i] =p[i]*lbw[0] *(1.0                                    -1.5*modv)-c1*(pi_xx+   pi_yy+   pi_zz);
      f1[i] =p[i]*lbw[1] *(1.0-3.0*v0        +4.5* v0v0           -1.5*modv)+c1* pi_xx-c2*pi_yy-c2*pi_zz;
      f2[i] =p[i]*lbw[2] *(1.0-3.0*v1        +4.5* v1v1           -1.5*modv)-c2* pi_xx+c1*pi_yy-c2*pi_zz;
      f3[i] =p[i]*lbw[3] *(1.0-3.0*v2        +4.5* v2v2           -1.5*modv)-c2* pi_xx-c2*pi_yy+c1*pi_zz;
      f4[i] =p[i]*lbw[4] *(1.0-3.0*(v0+v1+v2)+9.0*(v0v1+v0v2+v1v2)+3.0*modv)+c3*(pi_xx+   pi_yy+   pi_zz)+0.125*(pi_xy+pi_xz+pi_yz);
      f5[i] =p[i]*lbw[5] *(1.0-3.0*(v0+v1-v2)+9.0*(v0v1-v0v2-v1v2)+3.0*modv)+c3*(pi_xx+   pi_yy+   pi_zz)+0.125*(pi_xy-pi_xz-pi_yz);
      f6[i] =p[i]*lbw[6] *(1.0-3.0*(v0-v1+v2)-9.0*(v0v1-v0v2+v1v2)+3.0*modv)+c3*(pi_xx+   pi_yy+   pi_zz)-0.125*(pi_xy-pi_xz+pi_yz);
      f7[i] =p[i]*lbw[7] *(1.0-3.0*(v0-v1-v2)-9.0*(v0v1+v0v2-v1v2)+3.0*modv)+c3*(pi_xx+   pi_yy+   pi_zz)-0.125*(pi_xy+pi_xz-pi_yz);
      f8[i] =p[i]*lbw[8] *(1.0+3.0*v0        +4.5* v0v0           -1.5*modv)+c1* pi_xx-c2*pi_yy-c2*pi_zz;
      f9[i] =p[i]*lbw[9] *(1.0+3.0*v1        +4.5* v1v1           -1.5*modv)-c2* pi_xx+c1*pi_yy-c2*pi_zz;
      f10[i]=p[i]*lbw[10]*(1.0+3.0*v2        +4.5* v2v2           -1.5*modv)-c2* pi_xx-c2*pi_yy+c1*pi_zz;
      f11[i]=p[i]*lbw[11]*(1.0+3.0*(v0+v1+v2)+9.0*(v0v1+v0v2+v1v2)+3.0*modv)+c3*(pi_xx+   pi_yy+   pi_zz)+0.125*(pi_xy+pi_xz+pi_yz);
      f12[i]=p[i]*lbw[12]*(1.0+3.0*(v0+v1-v2)+9.0*(v0v1-v0v2-v1v2)+3.0*modv)+c3*(pi_xx+   pi_yy+   pi_zz)+0.125*(pi_xy-pi_xz-pi_yz);
      f13[i]=p[i]*lbw[13]*(1.0+3.0*(v0-v1+v2)-9.0*(v0v1-v0v2+v1v2)+3.0*modv)+c3*(pi_xx+   pi_yy+   pi_zz)-0.125*(pi_xy-pi_xz+pi_yz);
      f14[i]=p[i]*lbw[14]*(1.0+3.0*(v0-v1-v2)-9.0*(v0v1+v0v2-v1v2)+3.0*modv)+c3*(pi_xx+   pi_yy+   pi_zz)-0.125*(pi_xy+pi_xz-pi_yz);
    }
  }
  else {
    for(int i=0; i<lbsy.nf; i++) {
      rho0 = lbincp[i];
      pi_xx = -f0[i]-2.0*(f2[i]+f3[i])+c4*p[i]-rho0*(c4*(v1+v2)+v0v0)+v0*force[3*i  ];
      pi_yy = -f0[i]-2.0*(f1[i]+f3[i])+c4*p[i]-rho0*(c4*(v0+v2)+v1v1)+v1*force[3*i+1];
      pi_zz = -f0[i]-2.0*(f1[i]+f2[i])+c4*p[i]-rho0*(c4*(v0+v1)+v2v2)+v2*force[3*i+2];
      pi_xy = c1*f0[i]+c4*(f1[i]+f2[i]+f3[i])+c5*f4[i]-c1*p[i]+rho0*(v0+v1+v2-3.0*v0v1)+0.5*(v1*force[3*i  ]+v0*force[3*i+1]);
      pi_xz = c1*f0[i]+c4*(f1[i]+f2[i]+f3[i])+c5*f4[i]-c1*p[i]+rho0*(v0+v1+v2-3.0*v0v2)+0.5*(v2*force[3*i  ]+v0*force[3*i+2]);
      pi_yz = c1*f0[i]+c4*(f1[i]+f2[i]+f3[i])+c5*f4[i]-c1*p[i]+rho0*(v0+v1+v2-3.0*v1v2)+0.5*(v2*force[3*i+1]+v1*force[3*i+2]);
      f0[i] =lbw[0] *(p[i]+rho0*(                                    -1.5*modv))-c1*(pi_xx+   pi_yy+   pi_zz);
      f1[i] =lbw[1] *(p[i]+rho0*(-3.0*v0        +4.5* v0v0           -1.5*modv))+c1* pi_xx-c2*pi_yy-c2*pi_zz;
      f2[i] =lbw[2] *(p[i]+rho0*(-3.0*v1        +4.5* v1v1           -1.5*modv))-c2* pi_xx+c1*pi_yy-c2*pi_zz;
      f3[i] =lbw[3] *(p[i]+rho0*(-3.0*v2        +4.5* v2v2           -1.5*modv))-c2* pi_xx-c2*pi_yy+c1*pi_zz;
      f4[i] =lbw[4] *(p[i]+rho0*(-3.0*(v0+v1+v2)+9.0*(v0v1+v0v2+v1v2)+3.0*modv))+c3*(pi_xx+   pi_yy+   pi_zz)+0.125*(pi_xy+pi_xz+pi_yz);
      f5[i] =lbw[5] *(p[i]+rho0*(-3.0*(v0+v1-v2)+9.0*(v0v1-v0v2-v1v2)+3.0*modv))+c3*(pi_xx+   pi_yy+   pi_zz)+0.125*(pi_xy-pi_xz-pi_yz);
      f6[i] =lbw[6] *(p[i]+rho0*(-3.0*(v0-v1+v2)-9.0*(v0v1-v0v2+v1v2)+3.0*modv))+c3*(pi_xx+   pi_yy+   pi_zz)-0.125*(pi_xy-pi_xz+pi_yz);
      f7[i] =lbw[7] *(p[i]+rho0*(-3.0*(v0-v1-v2)-9.0*(v0v1+v0v2-v1v2)+3.0*modv))+c3*(pi_xx+   pi_yy+   pi_zz)-0.125*(pi_xy+pi_xz-pi_yz);
      f8[i] =lbw[8] *(p[i]+rho0*( 3.0*v0        +4.5* v0v0           -1.5*modv))+c1* pi_xx-c2*pi_yy-c2*pi_zz;
      f9[i] =lbw[9] *(p[i]+rho0*( 3.0*v1        +4.5* v1v1           -1.5*modv))-c2* pi_xx+c1*pi_yy-c2*pi_zz;
      f10[i]=lbw[10]*(p[i]+rho0*( 3.0*v2        +4.5* v2v2           -1.5*modv))-c2* pi_xx-c2*pi_yy+c1*pi_zz;
      f11[i]=lbw[11]*(p[i]+rho0*( 3.0*(v0+v1+v2)+9.0*(v0v1+v0v2+v1v2)+3.0*modv))+c3*(pi_xx+   pi_yy+   pi_zz)+0.125*(pi_xy+pi_xz+pi_yz);
      f12[i]=lbw[12]*(p[i]+rho0*( 3.0*(v0+v1-v2)+9.0*(v0v1-v0v2-v1v2)+3.0*modv))+c3*(pi_xx+   pi_yy+   pi_zz)+0.125*(pi_xy-pi_xz-pi_yz);
      f13[i]=lbw[13]*(p[i]+rho0*( 3.0*(v0-v1+v2)-9.0*(v0v1-v0v2+v1v2)+3.0*modv))+c3*(pi_xx+   pi_yy+   pi_zz)-0.125*(pi_xy-pi_xz+pi_yz);
      f14[i]=lbw[14]*(p[i]+rho0*( 3.0*(v0-v1-v2)-9.0*(v0v1+v0v2-v1v2)+3.0*modv))+c3*(pi_xx+   pi_yy+   pi_zz)-0.125*(pi_xy+pi_xz-pi_yz);
    }
  }
  return 0;
}

int fD3Q15VPSSwiftRegular(double v0, double v1, double v2, double *force, double *f0, double *f1, double *f2,
                          double *f3, double *f4, double *f5, double *f6, double *f7, double *f8,
                          double *f9, double *f10, double *f11, double *f12, double *f13, double *f14,
	                      double drdx, double drdy, double drdz, double dpdx, double dpdy, double dpdz,
                          double nabr, double nabp, double *omega, double T)
{

  // produce fixed velocity at planar surface boundary for compressible fluids with Swift free-energy interactions:
  // expressed for bottom wall (VPST)

  double rho, phi, omegat, pb, mu, lambda, d2rdx2, d2rdy2, d2rdz2, d2rdxdy, d2rdxdz, d2rdydz, nabrp, modv;
  double v0v0, v0v1, v0v2, v1v1, v1v2, v2v2, udr;
  double pi_xx, pi_yy, pi_zz, pi_xy, pi_xz, pi_yz, pic_xx, pic_yy, pic_zz, pic_xy, pic_xz, pic_yz;
  double c1=1.0/3.0,c2=1.0/6.0,c3=1.0/24.0;

  v0v0 = v0*v0;
  v0v1 = v0*v1;
  v0v2 = v0*v2;
  v1v1 = v1*v1;
  v1v2 = v1*v2;
  v2v2 = v2*v2;
  modv = v0v0 + v1v1 + v2v2;
  rho = (f0[0]+f1[0]+f3[0]+f8[0]+f10[0]+2*(f2[0]+f4[0]+f5[0]+f13[0]+f14[0])-0.5*force[1])/(1.0-v1);
  if(lbsy.nf>1) {
    phi = (f0[1]+f1[1]+f3[1]+f8[1]+f10[1]+2*(f2[1]+f4[1]+f5[1]+f13[1]+f14[1]))/(1.0-v1);
    omegat = 0.5*(1.0+phi)*omega[0]+0.5*(1.0-phi)*omega[1];
    mu = lbfemob*fGetPotentialSwift(phi, nabp);
    d2rdx2 = (lbfeeos>0)?(drdx*drdx):0.0 + dpdx*dpdx;
    d2rdy2 = (lbfeeos>0)?(drdy*drdy):0.0 + dpdy*dpdy;
    d2rdz2 = (lbfeeos>0)?(drdz*drdz):0.0 + dpdz*dpdz;
    d2rdxdy = (lbfeeos>0)?(drdx*drdy):0.0 + dpdx*dpdy;
    d2rdxdz = (lbfeeos>0)?(drdx*drdz):0.0 + dpdx*dpdz;
    d2rdydz = (lbfeeos>0)?(drdy*drdz):0.0 + dpdy*dpdz;
    nabrp = (lbfeeos>0)?(rho*nabr):0.0 + phi*nabp;

    pic_xx = f1[1]+f8[1]+2.0*(f4[1]+f5[1]+f13[1]+f14[1])+phi*(c1*v1-v0v0)-mu;
    pic_yy = 2.0*(f2[1]+f4[1]+f5[1]+f13[1]+f14[1])+phi*(v1-v1v1)-mu;
    pic_zz = f3[1]+f10[1]+2.0*(f4[1]+f5[1]+f13[1]+f14[1])+phi*(c1*v1-v2v2)-mu;
    pic_xy = 2.0*(f4[1]+f5[1]-f13[1]-f14[1])+phi*(c1*v0-v0v1);
    pic_xz = 2.0*(f4[1]-f5[1]+f13[1]-f14[1])-phi*v0v2;
    pic_yz = 2.0*(f4[1]-f5[1]-f13[1]+f14[1])+phi*(c1*v2-v1v2);
      
    f0[1] =mu*lbwpt[0] +phi*         (1.0-                   0.5*lbwi[0]*modv)-c1*(pic_xx+   pic_yy+   pic_zz);
    f1[1] =mu*lbwpt[1] +phi*lbwi[1] *(-v0      +1.5*v0v0            -0.5*modv)+c1* pic_xx-c2*pic_yy-c2*pic_zz;
    f2[1] =mu*lbwpt[2] +phi*lbwi[2] *(-v1      +1.5*v1v1            -0.5*modv)-c2* pic_xx+c1*pic_yy-c2*pic_zz;
    f3[1] =mu*lbwpt[3] +phi*lbwi[3] *(-v2      +1.5*v2v2            -0.5*modv)-c2* pic_xx-c2*pic_yy+c1*pic_zz;
    f4[1] =mu*lbwpt[4] +phi*lbwi[4] *(-v0-v1-v2+3.0*(v0v1+v0v2+v1v2)    +modv)+c3*(pic_xx+   pic_yy+   pic_zz)+0.125*(pic_xy+pic_xz+pic_yz);
    f5[1] =mu*lbwpt[5] +phi*lbwi[5] *(-v0-v1+v2+3.0*(v0v1-v0v2-v1v2)    +modv)+c3*(pic_xx+   pic_yy+   pic_zz)+0.125*(pic_xy-pic_xz-pic_yz);
    f6[1] =mu*lbwpt[6] +phi*lbwi[6] *(-v0+v1-v2-3.0*(v0v1-v0v2+v1v2)    +modv)+c3*(pic_xx+   pic_yy+   pic_zz)-0.125*(pic_xy-pic_xz+pic_yz);
    f7[1] =mu*lbwpt[7] +phi*lbwi[7] *(-v0+v1+v2-3.0*(v0v1+v0v2-v1v2)    +modv)+c3*(pic_xx+   pic_yy+   pic_zz)-0.125*(pic_xy+pic_xz-pic_yz);
    f8[1] =mu*lbwpt[8] +phi*lbwi[8] *( v0      +1.5*v0v0            -0.5*modv)+c1* pic_xx-c2*pic_yy-c2*pic_zz;
    f9[1] =mu*lbwpt[9] +phi*lbwi[9] *( v1      +1.5*v1v1            -0.5*modv)-c2* pic_xx+c1*pic_yy-c2*pic_zz;
    f10[1]=mu*lbwpt[10]+phi*lbwi[10]*( v2      +1.5*v2v2            -0.5*modv)-c2* pic_xx-c2*pic_yy+c1*pic_zz;
    f11[1]=mu*lbwpt[11]+phi*lbwi[11]*( v0+v1+v2+3.0*(v0v1+v0v2+v1v2)    +modv)+c3*(pic_xx+   pic_yy+   pic_zz)+0.125*(pic_xy+pic_xz+pic_yz);
    f12[1]=mu*lbwpt[12]+phi*lbwi[12]*( v0+v1-v2+3.0*(v0v1-v0v2-v1v2)    +modv)+c3*(pic_xx+   pic_yy+   pic_zz)+0.125*(pic_xy-pic_xz-pic_yz);
    f13[1]=mu*lbwpt[13]+phi*lbwi[13]*( v0-v1+v2-3.0*(v0v1-v0v2+v1v2)    +modv)+c3*(pic_xx+   pic_yy+   pic_zz)-0.125*(pic_xy-pic_xz+pic_yz);
    f14[1]=mu*lbwpt[14]+phi*lbwi[14]*( v0-v1-v2-3.0*(v0v1+v0v2-v1v2)    +modv)+c3*(pic_xx+   pic_yy+   pic_zz)-0.125*(pic_xy+pic_xz-pic_yz);
  }
  else {
    phi = 0.0;
    omegat = omega[0];
    d2rdx2 = drdx*drdx;
    d2rdy2 = drdy*drdy;
    d2rdz2 = drdz*drdz;
    d2rdxdy = drdx*drdy;
    d2rdxdz = drdx*drdz;
    d2rdydz = drdy*drdz;
    nabrp = rho*nabr;
  }
  pb = fGetBulkPressureSwift(rho, phi, T);
  lambda = fGetLambdaSwift(rho, omegat, T);
  udr = drdx*v0 + drdy*v1 + drdz*v2;
  pi_xx = f1[0]+f8[0]+2.0*(f4[0]+f5[0]+f13[0]+f14[0])+rho*(c1*v1-v0v0)+v0*force[0]-pb+lbkappa*nabrp+lbkappa*(d2rdy2+d2rdz2)-lambda*(3.0*v0*drdx+v1*drdy+v2*drdz);
  pi_yy = 2.0*(f2[0]+f4[0]+f5[0]+f13[0]+f14[0])+rho*(v1-v1v1)+v1*force[1]-pb+lbkappa*nabrp+lbkappa*(d2rdx2+d2rdz2)-lambda*(v0*drdx+3.0*v1*drdy+v2*drdz);
  pi_zz = f3[0]+f10[0]+2.0*(f4[0]+f5[0]+f13[0]+f14[0])+rho*(c1*v1-v2v2)+v2*force[2]-pb+lbkappa*nabrp+lbkappa*(d2rdx2+d2rdy2)-lambda*(v0*drdx+v1*drdy+3.0*v2*drdz);
  pi_xy = 2.0*(f4[0]+f5[0]-f13[0]-f14[0])+rho*(c1*v0-v0v1)+0.5*(v1*force[0]+v0*force[1])-lbkappa*d2rdxdy-lambda*(v1*drdx+v0*drdy);
  pi_xz = 2.0*(f4[0]-f5[0]+f13[0]-f14[0])-rho*v0v2+0.5*(v2*force[0]+v0*force[2])-lbkappa*d2rdxdz-lambda*(v2*drdx+v0*drdz);
  pi_yz = 2.0*(f4[0]-f5[0]-f13[0]+f14[0])+rho*(c1*v2-v1v2)+0.5*(v2*force[1]+v1*force[2])-lbkappa*d2rdydz-lambda*(v2*drdy+v1*drdz);
    
  f0[0] =rho*(lbw0[0]-0.5*lbwi[0]*modv)+lambda*lbwi[0]*lbwdel[0]*udr
        +lbwpt[0] *(pb-lbkappa*nabrp)+lbkappa*(lbwxx[0] *d2rdx2+lbwyy[0] *d2rdy2+lbwzz[0] *d2rdz2)
        -c1*(pi_xx+   pi_yy+   pi_zz);
  f1[0] =lbwi [1] *(rho*(-v0      +1.5* v0v0       -0.5*modv)+lambda*(udr+3.0*drdx*v0))
        +lbwpt[1] *(pb-lbkappa*nabrp)+lbkappa*(lbwxx[1] *d2rdx2+lbwyy[1] *d2rdy2+lbwzz[1] *d2rdz2)
        +c1* pi_xx-c2*pi_yy-c2*pi_zz;
  f2[0] =lbwi [2] *(rho*(-v1      +1.5* v1v1       -0.5*modv)+lambda*(udr+3.0*drdy*v1))
        +lbwpt[2] *(pb-lbkappa*nabrp)+lbkappa*(lbwxx[2] *d2rdx2+lbwyy[2] *d2rdy2+lbwzz[2] *d2rdz2)
        -c2* pi_xx+c1*pi_yy-c2*pi_zz;
  f3[0] =lbwi [3] *(rho*(-v2      +1.5* v2v2       -0.5*modv)+lambda*(udr+3.0*drdz*v2))
        +lbwpt[3] *(pb-lbkappa*nabrp)+lbkappa*(lbwxx[3] *d2rdx2+lbwyy[3] *d2rdy2+lbwzz[3] *d2rdz2)
        -c2* pi_xx-c2*pi_yy+c1*pi_zz;
  f4[0] =lbwi [4] *(rho*(-v0-v1-v2+3.0*(v0v1+v0v2+v1v2)+modv)+lambda*(udr+3.0*(drdx*( v1+v2)+drdy*(v0+v2)+drdz*(v0+v1))))
        +lbwpt[4] *(pb-lbkappa*nabrp)+lbkappa*(lbwxx[4] *d2rdx2+lbwyy[4] *d2rdy2+lbwzz[4] *d2rdz2+lbwxy[4] *d2rdxdy+lbwxz[4] *d2rdxdz+lbwyz[4] *d2rdydz)
        +c3*(pi_xx+   pi_yy+   pi_zz)+0.125*(pi_xy+pi_xz+pi_yz);
  f5[0] =lbwi [5] *(rho*(-v0-v1+v2+3.0*(v0v1-v0v2-v1v2)+modv)+lambda*(udr+3.0*(drdx*( v1-v2)+drdy*(v0-v2)-drdz*(v0+v1))))
        +lbwpt[5] *(pb-lbkappa*nabrp)+lbkappa*(lbwxx[5] *d2rdx2+lbwyy[5] *d2rdy2+lbwzz[5] *d2rdz2+lbwxy[5] *d2rdxdy+lbwxz[5] *d2rdxdz+lbwyz[5] *d2rdydz)
        +c3*(pi_xx+   pi_yy+   pi_zz)+0.125*(pi_xy-pi_xz-pi_yz);
  f6[0] =lbwi [6] *(rho*(-v0+v1-v2-3.0*(v0v1-v0v2+v1v2)+modv)+lambda*(udr+3.0*(drdx*(-v1+v2)-drdy*(v0+v2)+drdz*(v0-v1))))
        +lbwpt[6] *(pb-lbkappa*nabrp)+lbkappa*(lbwxx[6] *d2rdx2+lbwyy[6] *d2rdy2+lbwzz[6] *d2rdz2+lbwxy[6] *d2rdxdy+lbwxz[6] *d2rdxdz+lbwyz[6] *d2rdydz)
        +c3*(pi_xx+   pi_yy+   pi_zz)-0.125*(pi_xy-pi_xz+pi_yz);
  f7[0] =lbwi [7] *(rho*(-v0+v1+v2+3.0*(v0v1+v0v2-v1v2)+modv)+lambda*(udr+3.0*(drdx*(-v1-v2)-drdy*(v0-v2)-drdz*(v0-v1))))
        +lbwpt[7] *(pb-lbkappa*nabrp)+lbkappa*(lbwxx[7] *d2rdx2+lbwyy[7] *d2rdy2+lbwzz[7] *d2rdz2+lbwxy[7] *d2rdxdy+lbwxz[7] *d2rdxdz+lbwyz[7] *d2rdydz)
        +c3*(pi_xx+   pi_yy+   pi_zz)-0.125*(pi_xy+pi_xz-pi_yz);
  f8[0] =lbwi [8] *(rho*( v0      +1.5*v0v0        -0.5*modv)+lambda*(udr+3.0*drdx*v0))
        +lbwpt[8] *(pb-lbkappa*nabrp)+lbkappa*(lbwxx[8] *d2rdx2+lbwyy[8] *d2rdy2+lbwzz[8] *d2rdz2)
        +c1* pi_xx-c2*pi_yy-c2*pi_zz;
  f9[0] =lbwi [9] *(rho*( v1      +1.5*v1v1        -0.5*modv)+lambda*(udr+3.0*drdy*v1))
        +lbwpt[9] *(pb-lbkappa*nabrp)+lbkappa*(lbwxx[9] *d2rdx2+lbwyy[9] *d2rdy2+lbwzz[9] *d2rdz2)
        -c2* pi_xx+c1*pi_yy-c2*pi_zz;
  f10[0]=lbwi [10]*(rho*( v2      +1.5*v2v2        -0.5*modv)+lambda*(udr+3.0*drdz*v2))
        +lbwpt[10]*(pb-lbkappa*nabrp)+lbkappa*(lbwxx[10]*d2rdx2+lbwyy[10]*d2rdy2+lbwzz[10]*d2rdz2)
        -c2* pi_xx-c2*pi_yy+c1*pi_zz;
  f11[0]=lbwi [11]*(rho*( v0+v1+v2+3.0*(v0v1+v0v2+v1v2)+modv)+lambda*(udr+3.0*(drdx*( v1+v2)+drdy*(v0+v2)+drdz*(v0+v1))))
        +lbwpt[11]*(pb-lbkappa*nabrp)+lbkappa*(lbwxx[11]*d2rdx2+lbwyy[11]*d2rdy2+lbwzz[11]*d2rdz2+lbwxy[11]*d2rdxdy+lbwxz[11]*d2rdxdz+lbwyz[11]*d2rdydz)
        +c3*(pi_xx+   pi_yy+   pi_zz)+0.125*(pi_xy+pi_xz+pi_yz);
  f12[0]=lbwi [12]*(rho*( v0+v1-v2+3.0*(v0v1-v0v2-v1v2)+modv)+lambda*(udr+3.0*(drdx*( v1-v2)+drdy*(v0-v2)-drdz*(v0+v1))))
        +lbwpt[12]*(pb-lbkappa*nabrp)+lbkappa*(lbwxx[12]*d2rdx2+lbwyy[12]*d2rdy2+lbwzz[12]*d2rdz2+lbwxy[12]*d2rdxdy+lbwxz[12]*d2rdxdz+lbwyz[12]*d2rdydz)
        +c3*(pi_xx+   pi_yy+   pi_zz)+0.125*(pi_xy-pi_xz-pi_yz);
  f13[0]=lbwi [13]*(rho*( v0-v1+v2-3.0*(v0v1-v0v2+v1v2)+modv)+lambda*(udr+3.0*(drdx*(-v1+v2)-drdy*(v0+v2)+drdz*(v0-v1))))
        +lbwpt[13]*(pb-lbkappa*nabrp)+lbkappa*(lbwxx[13]*d2rdx2+lbwyy[13]*d2rdy2+lbwzz[13]*d2rdz2+lbwxy[13]*d2rdxdy+lbwxz[13]*d2rdxdz+lbwyz[13]*d2rdydz)
        +c3*(pi_xx+   pi_yy+   pi_zz)-0.125*(pi_xy-pi_xz+pi_yz);
  f14[0]=lbwi [14]*(rho*( v0-v1-v2+3.0*(v0v1+v0v2-v1v2)+modv)+lambda*(udr+3.0*(drdx*(-v1-v2)-drdy*(v0-v2)-drdz*(v0-v1))))
        +lbwpt[14]*(pb-lbkappa*nabrp)+lbkappa*(lbwxx[14]*d2rdx2+lbwyy[14]*d2rdy2+lbwzz[14]*d2rdz2+lbwxy[14]*d2rdxdy+lbwxz[14]*d2rdxdz+lbwyz[14]*d2rdydz)
        +c3*(pi_xx+   pi_yy+   pi_zz)-0.125*(pi_xy+pi_xz-pi_yz);
  return 0;
}

int fD3Q15VCESwiftRegular(double *p, double v0, double v1, double v2, double *force, double *f0, double *f1, double *f2,
                          double *f3, double *f4, double *f5, double *f6, double *f7, double *f8,
                          double *f9, double *f10, double *f11, double *f12, double *f13, double *f14,
	                      double drdx, double drdy, double drdz, double dpdx, double dpdy, double dpdz,
                          double nabr, double nabp, double *omega, double T)
{

  // produce fixed velocity at concave edge boundary for compressible fluids with Swift free-energy interactions:
  // expressed for bottom left edge (VCETR)

  double rho, phi, omegat, pb, mu, lambda, d2rdx2, d2rdy2, d2rdz2, d2rdxdy, d2rdxdz, d2rdydz, nabrp, modv;
  double v0v0, v0v1, v0v2, v1v1, v1v2, v2v2, udr;
  double pi_xx, pi_yy, pi_zz, pi_xy, pi_xz, pi_yz, pic_xx, pic_yy, pic_zz, pic_xy, pic_xz, pic_yz;
  double c1=1.0/3.0,c2=1.0/6.0,c3=1.0/24.0,c4=2.0/3.0;

  v0v0 = v0*v0;
  v0v1 = v0*v1;
  v0v2 = v0*v2;
  v1v1 = v1*v1;
  v1v2 = v1*v2;
  v2v2 = v2*v2;
  modv = v0v0 + v1v1 + v2v2;
  rho = p[0];
  if(lbsy.nf>1) {
    phi = p[1];
    omegat = 0.5*(1.0+phi)*omega[0]+0.5*(1.0-phi)*omega[1];
    mu = lbfemob*fGetPotentialSwift(phi, nabp);
    d2rdx2 = (lbfeeos>0)?(drdx*drdx):0.0 + dpdx*dpdx;
    d2rdy2 = (lbfeeos>0)?(drdy*drdy):0.0 + dpdy*dpdy;
    d2rdz2 = (lbfeeos>0)?(drdz*drdz):0.0 + dpdz*dpdz;
    d2rdxdy = (lbfeeos>0)?(drdx*drdy):0.0 + dpdx*dpdy;
    d2rdxdz = (lbfeeos>0)?(drdx*drdz):0.0 + dpdx*dpdz;
    d2rdydz = (lbfeeos>0)?(drdy*drdz):0.0 + dpdy*dpdz;
    nabrp = (lbfeeos>0)?(rho*nabr):0.0 + phi*nabp;

    pic_xx = -f0[1]-f3[1]-f10[1]-2.0*f2[1]+phi*(1.0-c4*v1-v0v0)-mu;
    pic_yy = -f0[1]-f3[1]-f10[1]-2.0*f1[1]+phi*(1.0-c4*v0-v1v1)-mu;
    pic_zz = -f0[1]-2.0*(f1[1]+f2[1])+phi*(1.0-c4*(v0+v1)-v2v2)-mu;
    pic_xy = f0[1]+f3[1]+f10[1]+2.0*(f1[1]+f2[1])+4.0*(f4[1]+f5[1])-phi*(1.0-v0)*(1.0-v1);
    pic_xz = 2.0*(f4[1]-f5[1])+phi*v2*(c2-v0);
    pic_yz = 2.0*(f4[1]-f5[1])+phi*v2*(c2-v1);

    f0[1] =mu*lbwpt[0] +phi*         (1.0-                   0.5*lbwi[0]*modv)-c1*(pic_xx+   pic_yy+   pic_zz);
    f1[1] =mu*lbwpt[1] +phi*lbwi[1] *(-v0      +1.5*v0v0            -0.5*modv)+c1* pic_xx-c2*pic_yy-c2*pic_zz;
    f2[1] =mu*lbwpt[2] +phi*lbwi[2] *(-v1      +1.5*v1v1            -0.5*modv)-c2* pic_xx+c1*pic_yy-c2*pic_zz;
    f3[1] =mu*lbwpt[3] +phi*lbwi[3] *(-v2      +1.5*v2v2            -0.5*modv)-c2* pic_xx-c2*pic_yy+c1*pic_zz;
    f4[1] =mu*lbwpt[4] +phi*lbwi[4] *(-v0-v1-v2+3.0*(v0v1+v0v2+v1v2)    +modv)+c3*(pic_xx+   pic_yy+   pic_zz)+0.125*(pic_xy+pic_xz+pic_yz);
    f5[1] =mu*lbwpt[5] +phi*lbwi[5] *(-v0-v1+v2+3.0*(v0v1-v0v2-v1v2)    +modv)+c3*(pic_xx+   pic_yy+   pic_zz)+0.125*(pic_xy-pic_xz-pic_yz);
    f6[1] =mu*lbwpt[6] +phi*lbwi[6] *(-v0+v1-v2-3.0*(v0v1-v0v2+v1v2)    +modv)+c3*(pic_xx+   pic_yy+   pic_zz)-0.125*(pic_xy-pic_xz+pic_yz);
    f7[1] =mu*lbwpt[7] +phi*lbwi[7] *(-v0+v1+v2-3.0*(v0v1+v0v2-v1v2)    +modv)+c3*(pic_xx+   pic_yy+   pic_zz)-0.125*(pic_xy+pic_xz-pic_yz);
    f8[1] =mu*lbwpt[8] +phi*lbwi[8] *( v0      +1.5*v0v0            -0.5*modv)+c1* pic_xx-c2*pic_yy-c2*pic_zz;
    f9[1] =mu*lbwpt[9] +phi*lbwi[9] *( v1      +1.5*v1v1            -0.5*modv)-c2* pic_xx+c1*pic_yy-c2*pic_zz;
    f10[1]=mu*lbwpt[10]+phi*lbwi[10]*( v2      +1.5*v2v2            -0.5*modv)-c2* pic_xx-c2*pic_yy+c1*pic_zz;
    f11[1]=mu*lbwpt[11]+phi*lbwi[11]*( v0+v1+v2+3.0*(v0v1+v0v2+v1v2)    +modv)+c3*(pic_xx+   pic_yy+   pic_zz)+0.125*(pic_xy+pic_xz+pic_yz);
    f12[1]=mu*lbwpt[12]+phi*lbwi[12]*( v0+v1-v2+3.0*(v0v1-v0v2-v1v2)    +modv)+c3*(pic_xx+   pic_yy+   pic_zz)+0.125*(pic_xy-pic_xz-pic_yz);
    f13[1]=mu*lbwpt[13]+phi*lbwi[13]*( v0-v1+v2-3.0*(v0v1-v0v2+v1v2)    +modv)+c3*(pic_xx+   pic_yy+   pic_zz)-0.125*(pic_xy-pic_xz+pic_yz);
    f14[1]=mu*lbwpt[14]+phi*lbwi[14]*( v0-v1-v2-3.0*(v0v1+v0v2-v1v2)    +modv)+c3*(pic_xx+   pic_yy+   pic_zz)-0.125*(pic_xy+pic_xz-pic_yz);
  }
  else {
    phi = 0.0;
    omegat = omega[0];
    d2rdx2 = drdx*drdx;
    d2rdy2 = drdy*drdy;
    d2rdz2 = drdz*drdz;
    d2rdxdy = drdx*drdy;
    d2rdxdz = drdx*drdz;
    d2rdydz = drdy*drdz;
    nabrp = rho*nabr;
  }
  pb = fGetBulkPressureSwift(rho, phi, T);
  lambda = fGetLambdaSwift(rho, omegat, T);
  udr = drdx*v0 + drdy*v1 + drdz*v2;

  pi_xx = -f0[0]-f3[0]-f10[0]-2.0*f2[0]+rho*(1.0-c4*v1-v0v0)+v0*force[0]-pb+lbkappa*nabrp+lbkappa*(d2rdy2+d2rdz2)-lambda*(3.0*v0*drdx+v1*drdy+v2*drdz);
  pi_yy = -f0[0]-f3[0]-f10[0]-2.0*f1[0]+rho*(1.0-c4*v0-v1v1)+v1*force[1]-pb+lbkappa*nabrp+lbkappa*(d2rdx2+d2rdz2)-lambda*(v0*drdx+3.0*v1*drdy+v2*drdz);
  pi_zz = -f0[0]-2.0*(f1[0]+f2[0])+rho*(1.0-c4*(v0+v1)-v2v2)+v2*force[2]-pb+lbkappa*nabrp+lbkappa*(d2rdx2+d2rdy2)-lambda*(v0*drdx+v1*drdy+3.0*v2*drdz);
  pi_xy = f0[0]+f3[0]+f10[0]+2.0*(f1[0]+f2[0])+4.0*(f4[0]+f5[0])-rho*(1.0-v0)*(1.0-v1)+0.5*(v1*force[0]+v0*force[1])-lbkappa*d2rdxdy-lambda*(v1*drdx+v0*drdy);
  pi_xz = 2.0*(f4[0]-f5[0])+rho*v2*(c2-v0)+0.5*(v2*force[0]+v0*force[2])-lbkappa*d2rdxdz-lambda*(v2*drdx+v0*drdz);
  pi_yz = 2.0*(f4[0]-f5[0])+rho*v2*(c2-v1)+0.5*(v2*force[1]+v1*force[2])-lbkappa*d2rdydz-lambda*(v2*drdy+v1*drdz);
    
  f0[0] =rho*(lbw0[0]-0.5*lbwi[0]*modv)+lambda*lbwi[0]*lbwdel[0]*udr
        +lbwpt[0] *(pb-lbkappa*nabrp)+lbkappa*(lbwxx[0] *d2rdx2+lbwyy[0] *d2rdy2+lbwzz[0] *d2rdz2)
        -c1*(pi_xx+   pi_yy+   pi_zz);
  f1[0] =lbwi [1] *(rho*(-v0      +1.5* v0v0       -0.5*modv)+lambda*(udr+3.0*drdx*v0))
        +lbwpt[1] *(pb-lbkappa*nabrp)+lbkappa*(lbwxx[1] *d2rdx2+lbwyy[1] *d2rdy2+lbwzz[1] *d2rdz2)
        +c1* pi_xx-c2*pi_yy-c2*pi_zz;
  f2[0] =lbwi [2] *(rho*(-v1      +1.5* v1v1       -0.5*modv)+lambda*(udr+3.0*drdy*v1))
        +lbwpt[2] *(pb-lbkappa*nabrp)+lbkappa*(lbwxx[2] *d2rdx2+lbwyy[2] *d2rdy2+lbwzz[2] *d2rdz2)
        -c2* pi_xx+c1*pi_yy-c2*pi_zz;
  f3[0] =lbwi [3] *(rho*(-v2      +1.5* v2v2       -0.5*modv)+lambda*(udr+3.0*drdz*v2))
        +lbwpt[3] *(pb-lbkappa*nabrp)+lbkappa*(lbwxx[3] *d2rdx2+lbwyy[3] *d2rdy2+lbwzz[3] *d2rdz2)
        -c2* pi_xx-c2*pi_yy+c1*pi_zz;
  f4[0] =lbwi [4] *(rho*(-v0-v1-v2+3.0*(v0v1+v0v2+v1v2)+modv)+lambda*(udr+3.0*(drdx*( v1+v2)+drdy*(v0+v2)+drdz*(v0+v1))))
        +lbwpt[4] *(pb-lbkappa*nabrp)+lbkappa*(lbwxx[4] *d2rdx2+lbwyy[4] *d2rdy2+lbwzz[4] *d2rdz2+lbwxy[4] *d2rdxdy+lbwxz[4] *d2rdxdz+lbwyz[4] *d2rdydz)
        +c3*(pi_xx+   pi_yy+   pi_zz)+0.125*(pi_xy+pi_xz+pi_yz);
  f5[0] =lbwi [5] *(rho*(-v0-v1+v2+3.0*(v0v1-v0v2-v1v2)+modv)+lambda*(udr+3.0*(drdx*( v1-v2)+drdy*(v0-v2)-drdz*(v0+v1))))
        +lbwpt[5] *(pb-lbkappa*nabrp)+lbkappa*(lbwxx[5] *d2rdx2+lbwyy[5] *d2rdy2+lbwzz[5] *d2rdz2+lbwxy[5] *d2rdxdy+lbwxz[5] *d2rdxdz+lbwyz[5] *d2rdydz)
        +c3*(pi_xx+   pi_yy+   pi_zz)+0.125*(pi_xy-pi_xz-pi_yz);
  f6[0] =lbwi [6] *(rho*(-v0+v1-v2-3.0*(v0v1-v0v2+v1v2)+modv)+lambda*(udr+3.0*(drdx*(-v1+v2)-drdy*(v0+v2)+drdz*(v0-v1))))
        +lbwpt[6] *(pb-lbkappa*nabrp)+lbkappa*(lbwxx[6] *d2rdx2+lbwyy[6] *d2rdy2+lbwzz[6] *d2rdz2+lbwxy[6] *d2rdxdy+lbwxz[6] *d2rdxdz+lbwyz[6] *d2rdydz)
        +c3*(pi_xx+   pi_yy+   pi_zz)-0.125*(pi_xy-pi_xz+pi_yz);
  f7[0] =lbwi [7] *(rho*(-v0+v1+v2+3.0*(v0v1+v0v2-v1v2)+modv)+lambda*(udr+3.0*(drdx*(-v1-v2)-drdy*(v0-v2)-drdz*(v0-v1))))
        +lbwpt[7] *(pb-lbkappa*nabrp)+lbkappa*(lbwxx[7] *d2rdx2+lbwyy[7] *d2rdy2+lbwzz[7] *d2rdz2+lbwxy[7] *d2rdxdy+lbwxz[7] *d2rdxdz+lbwyz[7] *d2rdydz)
        +c3*(pi_xx+   pi_yy+   pi_zz)-0.125*(pi_xy+pi_xz-pi_yz);
  f8[0] =lbwi [8] *(rho*( v0      +1.5*v0v0        -0.5*modv)+lambda*(udr+3.0*drdx*v0))
        +lbwpt[8] *(pb-lbkappa*nabrp)+lbkappa*(lbwxx[8] *d2rdx2+lbwyy[8] *d2rdy2+lbwzz[8] *d2rdz2)
        +c1* pi_xx-c2*pi_yy-c2*pi_zz;
  f9[0] =lbwi [9] *(rho*( v1      +1.5*v1v1        -0.5*modv)+lambda*(udr+3.0*drdy*v1))
        +lbwpt[9] *(pb-lbkappa*nabrp)+lbkappa*(lbwxx[9] *d2rdx2+lbwyy[9] *d2rdy2+lbwzz[9] *d2rdz2)
        -c2* pi_xx+c1*pi_yy-c2*pi_zz;
  f10[0]=lbwi [10]*(rho*( v2      +1.5*v2v2        -0.5*modv)+lambda*(udr+3.0*drdz*v2))
        +lbwpt[10]*(pb-lbkappa*nabrp)+lbkappa*(lbwxx[10]*d2rdx2+lbwyy[10]*d2rdy2+lbwzz[10]*d2rdz2)
        -c2* pi_xx-c2*pi_yy+c1*pi_zz;
  f11[0]=lbwi [11]*(rho*( v0+v1+v2+3.0*(v0v1+v0v2+v1v2)+modv)+lambda*(udr+3.0*(drdx*( v1+v2)+drdy*(v0+v2)+drdz*(v0+v1))))
        +lbwpt[11]*(pb-lbkappa*nabrp)+lbkappa*(lbwxx[11]*d2rdx2+lbwyy[11]*d2rdy2+lbwzz[11]*d2rdz2+lbwxy[11]*d2rdxdy+lbwxz[11]*d2rdxdz+lbwyz[11]*d2rdydz)
        +c3*(pi_xx+   pi_yy+   pi_zz)+0.125*(pi_xy+pi_xz+pi_yz);
  f12[0]=lbwi [12]*(rho*( v0+v1-v2+3.0*(v0v1-v0v2-v1v2)+modv)+lambda*(udr+3.0*(drdx*( v1-v2)+drdy*(v0-v2)-drdz*(v0+v1))))
        +lbwpt[12]*(pb-lbkappa*nabrp)+lbkappa*(lbwxx[12]*d2rdx2+lbwyy[12]*d2rdy2+lbwzz[12]*d2rdz2+lbwxy[12]*d2rdxdy+lbwxz[12]*d2rdxdz+lbwyz[12]*d2rdydz)
        +c3*(pi_xx+   pi_yy+   pi_zz)+0.125*(pi_xy-pi_xz-pi_yz);
  f13[0]=lbwi [13]*(rho*( v0-v1+v2-3.0*(v0v1-v0v2+v1v2)+modv)+lambda*(udr+3.0*(drdx*(-v1+v2)-drdy*(v0+v2)+drdz*(v0-v1))))
        +lbwpt[13]*(pb-lbkappa*nabrp)+lbkappa*(lbwxx[13]*d2rdx2+lbwyy[13]*d2rdy2+lbwzz[13]*d2rdz2+lbwxy[13]*d2rdxdy+lbwxz[13]*d2rdxdz+lbwyz[13]*d2rdydz)
        +c3*(pi_xx+   pi_yy+   pi_zz)-0.125*(pi_xy-pi_xz+pi_yz);
  f14[0]=lbwi [14]*(rho*( v0-v1-v2+3.0*(v0v1+v0v2-v1v2)+modv)+lambda*(udr+3.0*(drdx*(-v1-v2)-drdy*(v0-v2)-drdz*(v0-v1))))
        +lbwpt[14]*(pb-lbkappa*nabrp)+lbkappa*(lbwxx[14]*d2rdx2+lbwyy[14]*d2rdy2+lbwzz[14]*d2rdz2+lbwxy[14]*d2rdxdy+lbwxz[14]*d2rdxdz+lbwyz[14]*d2rdydz)
        +c3*(pi_xx+   pi_yy+   pi_zz)-0.125*(pi_xy+pi_xz-pi_yz);
  return 0;
}

int fD3Q15VCCSwiftRegular(double *p, double v0, double v1, double v2, double *force, double *f0, double *f1, double *f2,
                          double *f3, double *f4, double *f5, double *f6, double *f7, double *f8,
                          double *f9, double *f10, double *f11, double *f12, double *f13, double *f14,
	                      double drdx, double drdy, double drdz, double dpdx, double dpdy, double dpdz,
                          double nabr, double nabp, double *omega, double T)
{

  // produce fixed velocity at concave corner boundary for compressible fluids with Swift free-energy interactions:
  // expressed for bottom left back corner (VCCTRF)

  double rho, phi, omegat, pb, mu, lambda, d2rdx2, d2rdy2, d2rdz2, d2rdxdy, d2rdxdz, d2rdydz, nabrp, modv;
  double v0v0, v0v1, v0v2, v1v1, v1v2, v2v2, udr;
  double pi_xx, pi_yy, pi_zz, pi_xy, pi_xz, pi_yz, pic_xx, pic_yy, pic_zz, pic_xy, pic_xz, pic_yz;
  double c1=1.0/3.0,c2=1.0/6.0,c3=1.0/24.0,c4=2.0/3.0,c5=8.0/3.0;

  v0v0 = v0*v0;
  v0v1 = v0*v1;
  v0v2 = v0*v2;
  v1v1 = v1*v1;
  v1v2 = v1*v2;
  v2v2 = v2*v2;
  modv = v0v0 + v1v1 + v2v2;
  rho = p[0];
  if(lbsy.nf>1) {
    phi = p[1];
    omegat = 0.5*(1.0+phi)*omega[0]+0.5*(1.0-phi)*omega[1];
    mu = lbfemob*fGetPotentialSwift(phi, nabp);
    d2rdx2 = (lbfeeos>0)?(drdx*drdx):0.0 + dpdx*dpdx;
    d2rdy2 = (lbfeeos>0)?(drdy*drdy):0.0 + dpdy*dpdy;
    d2rdz2 = (lbfeeos>0)?(drdz*drdz):0.0 + dpdz*dpdz;
    d2rdxdy = (lbfeeos>0)?(drdx*drdy):0.0 + dpdx*dpdy;
    d2rdxdz = (lbfeeos>0)?(drdx*drdz):0.0 + dpdx*dpdz;
    d2rdydz = (lbfeeos>0)?(drdy*drdz):0.0 + dpdy*dpdz;
    nabrp = (lbfeeos>0)?(rho*nabr):0.0 + phi*nabp;

    pic_xx = -f0[1]-2.0*(f2[1]+f3[1])+phi*(1.0-c4*(v1+v2)-v0v0)-mu;
    pic_yy = -f0[1]-2.0*(f1[1]+f3[1])+phi*(1.0-c4*(v0+v2)-v1v1)-mu;
    pic_zz = -f0[1]-2.0*(f1[1]+f2[1])+phi*(1.0-c4*(v0+v1)-v2v2)-mu;
    pic_xy = c1*f0[1]+c4*(f1[1]+f2[1]+f3[1])+c5*f4[1]-c1*phi*(1.0-v0-v1-v2+3.0*v0v1);
    pic_xz = c1*f0[1]+c4*(f1[1]+f2[1]+f3[1])+c5*f4[1]-c1*phi*(1.0-v0-v1-v2+3.0*v0v2);
    pic_yz = c1*f0[1]+c4*(f1[1]+f2[1]+f3[1])+c5*f4[1]-c1*phi*(1.0-v0-v1-v2+3.0*v1v2);

    f0[1] =mu*lbwpt[0] +phi*         (1.0-                   0.5*lbwi[0]*modv)-c1*(pic_xx+   pic_yy+   pic_zz);
    f1[1] =mu*lbwpt[1] +phi*lbwi[1] *(-v0      +1.5*v0v0            -0.5*modv)+c1* pic_xx-c2*pic_yy-c2*pic_zz;
    f2[1] =mu*lbwpt[2] +phi*lbwi[2] *(-v1      +1.5*v1v1            -0.5*modv)-c2* pic_xx+c1*pic_yy-c2*pic_zz;
    f3[1] =mu*lbwpt[3] +phi*lbwi[3] *(-v2      +1.5*v2v2            -0.5*modv)-c2* pic_xx-c2*pic_yy+c1*pic_zz;
    f4[1] =mu*lbwpt[4] +phi*lbwi[4] *(-v0-v1-v2+3.0*(v0v1+v0v2+v1v2)    +modv)+c3*(pic_xx+   pic_yy+   pic_zz)+0.125*(pic_xy+pic_xz+pic_yz);
    f5[1] =mu*lbwpt[5] +phi*lbwi[5] *(-v0-v1+v2+3.0*(v0v1-v0v2-v1v2)    +modv)+c3*(pic_xx+   pic_yy+   pic_zz)+0.125*(pic_xy-pic_xz-pic_yz);
    f6[1] =mu*lbwpt[6] +phi*lbwi[6] *(-v0+v1-v2-3.0*(v0v1-v0v2+v1v2)    +modv)+c3*(pic_xx+   pic_yy+   pic_zz)-0.125*(pic_xy-pic_xz+pic_yz);
    f7[1] =mu*lbwpt[7] +phi*lbwi[7] *(-v0+v1+v2-3.0*(v0v1+v0v2-v1v2)    +modv)+c3*(pic_xx+   pic_yy+   pic_zz)-0.125*(pic_xy+pic_xz-pic_yz);
    f8[1] =mu*lbwpt[8] +phi*lbwi[8] *( v0      +1.5*v0v0            -0.5*modv)+c1* pic_xx-c2*pic_yy-c2*pic_zz;
    f9[1] =mu*lbwpt[9] +phi*lbwi[9] *( v1      +1.5*v1v1            -0.5*modv)-c2* pic_xx+c1*pic_yy-c2*pic_zz;
    f10[1]=mu*lbwpt[10]+phi*lbwi[10]*( v2      +1.5*v2v2            -0.5*modv)-c2* pic_xx-c2*pic_yy+c1*pic_zz;
    f11[1]=mu*lbwpt[11]+phi*lbwi[11]*( v0+v1+v2+3.0*(v0v1+v0v2+v1v2)    +modv)+c3*(pic_xx+   pic_yy+   pic_zz)+0.125*(pic_xy+pic_xz+pic_yz);
    f12[1]=mu*lbwpt[12]+phi*lbwi[12]*( v0+v1-v2+3.0*(v0v1-v0v2-v1v2)    +modv)+c3*(pic_xx+   pic_yy+   pic_zz)+0.125*(pic_xy-pic_xz-pic_yz);
    f13[1]=mu*lbwpt[13]+phi*lbwi[13]*( v0-v1+v2-3.0*(v0v1-v0v2+v1v2)    +modv)+c3*(pic_xx+   pic_yy+   pic_zz)-0.125*(pic_xy-pic_xz+pic_yz);
    f14[1]=mu*lbwpt[14]+phi*lbwi[14]*( v0-v1-v2-3.0*(v0v1+v0v2-v1v2)    +modv)+c3*(pic_xx+   pic_yy+   pic_zz)-0.125*(pic_xy+pic_xz-pic_yz);
  }
  else {
    phi = 0.0;
    omegat = omega[0];
    d2rdx2 = drdx*drdx;
    d2rdy2 = drdy*drdy;
    d2rdz2 = drdz*drdz;
    d2rdxdy = drdx*drdy;
    d2rdxdz = drdx*drdz;
    d2rdydz = drdy*drdz;
    nabrp = rho*nabr;
  }
  pb = fGetBulkPressureSwift(rho, phi, T);
  lambda = fGetLambdaSwift(rho, omegat, T);
  udr = drdx*v0 + drdy*v1 + drdz*v2;

  pi_xx = -f0[0]-2.0*(f2[0]+f3[0])+rho*(1.0-c4*(v1+v2)-v0v0)+v0*force[0]-pb+lbkappa*nabrp+lbkappa*(d2rdy2+d2rdz2)-lambda*(3.0*v0*drdx+v1*drdy+v2*drdz);
  pi_yy = -f0[0]-2.0*(f1[0]+f3[0])+rho*(1.0-c4*(v0+v2)-v1v1)+v1*force[1]-pb+lbkappa*nabrp+lbkappa*(d2rdx2+d2rdz2)-lambda*(v0*drdx+3.0*v1*drdy+v2*drdz);
  pi_zz = -f0[0]-2.0*(f1[0]+f2[0])+rho*(1.0-c4*(v0+v1)-v2v2)+v2*force[2]-pb+lbkappa*nabrp+lbkappa*(d2rdx2+d2rdy2)-lambda*(v0*drdx+v1*drdy+3.0*v2*drdz);
  pi_xy = c1*f0[0]+c4*(f1[0]+f2[0]+f3[0])+c5*f4[0]-c1*rho*(1.0-v0-v1-v2+3.0*v0v1)+0.5*(v1*force[0]+v0*force[1])-lbkappa*d2rdxdy-lambda*(v1*drdx+v0*drdy);
  pi_xz = c1*f0[0]+c4*(f1[0]+f2[0]+f3[0])+c5*f4[0]-c1*rho*(1.0-v0-v1-v2+3.0*v0v2)+0.5*(v2*force[0]+v0*force[2])-lbkappa*d2rdxdz-lambda*(v2*drdx+v0*drdz);
  pi_yz = c1*f0[0]+c4*(f1[0]+f2[0]+f3[0])+c5*f4[0]-c1*rho*(1.0-v0-v1-v2+3.0*v1v2)+0.5*(v2*force[1]+v1*force[2])-lbkappa*d2rdydz-lambda*(v2*drdy+v1*drdz);
    
  f0[0] =rho*(lbw0[0]-0.5*lbwi[0]*modv)+lambda*lbwi[0]*lbwdel[0]*udr
        +lbwpt[0] *(pb-lbkappa*nabrp)+lbkappa*(lbwxx[0] *d2rdx2+lbwyy[0] *d2rdy2+lbwzz[0] *d2rdz2)
        -c1*(pi_xx+   pi_yy+   pi_zz);
  f1[0] =lbwi [1] *(rho*(-v0      +1.5* v0v0       -0.5*modv)+lambda*(udr+3.0*drdx*v0))
        +lbwpt[1] *(pb-lbkappa*nabrp)+lbkappa*(lbwxx[1] *d2rdx2+lbwyy[1] *d2rdy2+lbwzz[1] *d2rdz2)
        +c1* pi_xx-c2*pi_yy-c2*pi_zz;
  f2[0] =lbwi [2] *(rho*(-v1      +1.5* v1v1       -0.5*modv)+lambda*(udr+3.0*drdy*v1))
        +lbwpt[2] *(pb-lbkappa*nabrp)+lbkappa*(lbwxx[2] *d2rdx2+lbwyy[2] *d2rdy2+lbwzz[2] *d2rdz2)
        -c2* pi_xx+c1*pi_yy-c2*pi_zz;
  f3[0] =lbwi [3] *(rho*(-v2      +1.5* v2v2       -0.5*modv)+lambda*(udr+3.0*drdz*v2))
        +lbwpt[3] *(pb-lbkappa*nabrp)+lbkappa*(lbwxx[3] *d2rdx2+lbwyy[3] *d2rdy2+lbwzz[3] *d2rdz2)
        -c2* pi_xx-c2*pi_yy+c1*pi_zz;
  f4[0] =lbwi [4] *(rho*(-v0-v1-v2+3.0*(v0v1+v0v2+v1v2)+modv)+lambda*(udr+3.0*(drdx*( v1+v2)+drdy*(v0+v2)+drdz*(v0+v1))))
        +lbwpt[4] *(pb-lbkappa*nabrp)+lbkappa*(lbwxx[4] *d2rdx2+lbwyy[4] *d2rdy2+lbwzz[4] *d2rdz2+lbwxy[4] *d2rdxdy+lbwxz[4] *d2rdxdz+lbwyz[4] *d2rdydz)
        +c3*(pi_xx+   pi_yy+   pi_zz)+0.125*(pi_xy+pi_xz+pi_yz);
  f5[0] =lbwi [5] *(rho*(-v0-v1+v2+3.0*(v0v1-v0v2-v1v2)+modv)+lambda*(udr+3.0*(drdx*( v1-v2)+drdy*(v0-v2)-drdz*(v0+v1))))
        +lbwpt[5] *(pb-lbkappa*nabrp)+lbkappa*(lbwxx[5] *d2rdx2+lbwyy[5] *d2rdy2+lbwzz[5] *d2rdz2+lbwxy[5] *d2rdxdy+lbwxz[5] *d2rdxdz+lbwyz[5] *d2rdydz)
        +c3*(pi_xx+   pi_yy+   pi_zz)+0.125*(pi_xy-pi_xz-pi_yz);
  f6[0] =lbwi [6] *(rho*(-v0+v1-v2-3.0*(v0v1-v0v2+v1v2)+modv)+lambda*(udr+3.0*(drdx*(-v1+v2)-drdy*(v0+v2)+drdz*(v0-v1))))
        +lbwpt[6] *(pb-lbkappa*nabrp)+lbkappa*(lbwxx[6] *d2rdx2+lbwyy[6] *d2rdy2+lbwzz[6] *d2rdz2+lbwxy[6] *d2rdxdy+lbwxz[6] *d2rdxdz+lbwyz[6] *d2rdydz)
        +c3*(pi_xx+   pi_yy+   pi_zz)-0.125*(pi_xy-pi_xz+pi_yz);
  f7[0] =lbwi [7] *(rho*(-v0+v1+v2+3.0*(v0v1+v0v2-v1v2)+modv)+lambda*(udr+3.0*(drdx*(-v1-v2)-drdy*(v0-v2)-drdz*(v0-v1))))
        +lbwpt[7] *(pb-lbkappa*nabrp)+lbkappa*(lbwxx[7] *d2rdx2+lbwyy[7] *d2rdy2+lbwzz[7] *d2rdz2+lbwxy[7] *d2rdxdy+lbwxz[7] *d2rdxdz+lbwyz[7] *d2rdydz)
        +c3*(pi_xx+   pi_yy+   pi_zz)-0.125*(pi_xy+pi_xz-pi_yz);
  f8[0] =lbwi [8] *(rho*( v0      +1.5*v0v0        -0.5*modv)+lambda*(udr+3.0*drdx*v0))
        +lbwpt[8] *(pb-lbkappa*nabrp)+lbkappa*(lbwxx[8] *d2rdx2+lbwyy[8] *d2rdy2+lbwzz[8] *d2rdz2)
        +c1* pi_xx-c2*pi_yy-c2*pi_zz;
  f9[0] =lbwi [9] *(rho*( v1      +1.5*v1v1        -0.5*modv)+lambda*(udr+3.0*drdy*v1))
        +lbwpt[9] *(pb-lbkappa*nabrp)+lbkappa*(lbwxx[9] *d2rdx2+lbwyy[9] *d2rdy2+lbwzz[9] *d2rdz2)
        -c2* pi_xx+c1*pi_yy-c2*pi_zz;
  f10[0]=lbwi [10]*(rho*( v2      +1.5*v2v2        -0.5*modv)+lambda*(udr+3.0*drdz*v2))
        +lbwpt[10]*(pb-lbkappa*nabrp)+lbkappa*(lbwxx[10]*d2rdx2+lbwyy[10]*d2rdy2+lbwzz[10]*d2rdz2)
        -c2* pi_xx-c2*pi_yy+c1*pi_zz;
  f11[0]=lbwi [11]*(rho*( v0+v1+v2+3.0*(v0v1+v0v2+v1v2)+modv)+lambda*(udr+3.0*(drdx*( v1+v2)+drdy*(v0+v2)+drdz*(v0+v1))))
        +lbwpt[11]*(pb-lbkappa*nabrp)+lbkappa*(lbwxx[11]*d2rdx2+lbwyy[11]*d2rdy2+lbwzz[11]*d2rdz2+lbwxy[11]*d2rdxdy+lbwxz[11]*d2rdxdz+lbwyz[11]*d2rdydz)
        +c3*(pi_xx+   pi_yy+   pi_zz)+0.125*(pi_xy+pi_xz+pi_yz);
  f12[0]=lbwi [12]*(rho*( v0+v1-v2+3.0*(v0v1-v0v2-v1v2)+modv)+lambda*(udr+3.0*(drdx*( v1-v2)+drdy*(v0-v2)-drdz*(v0+v1))))
        +lbwpt[12]*(pb-lbkappa*nabrp)+lbkappa*(lbwxx[12]*d2rdx2+lbwyy[12]*d2rdy2+lbwzz[12]*d2rdz2+lbwxy[12]*d2rdxdy+lbwxz[12]*d2rdxdz+lbwyz[12]*d2rdydz)
        +c3*(pi_xx+   pi_yy+   pi_zz)+0.125*(pi_xy-pi_xz-pi_yz);
  f13[0]=lbwi [13]*(rho*( v0-v1+v2-3.0*(v0v1-v0v2+v1v2)+modv)+lambda*(udr+3.0*(drdx*(-v1+v2)-drdy*(v0+v2)+drdz*(v0-v1))))
        +lbwpt[13]*(pb-lbkappa*nabrp)+lbkappa*(lbwxx[13]*d2rdx2+lbwyy[13]*d2rdy2+lbwzz[13]*d2rdz2+lbwxy[13]*d2rdxdy+lbwxz[13]*d2rdxdz+lbwyz[13]*d2rdydz)
        +c3*(pi_xx+   pi_yy+   pi_zz)-0.125*(pi_xy-pi_xz+pi_yz);
  f14[0]=lbwi [14]*(rho*( v0-v1-v2+3.0*(v0v1+v0v2-v1v2)+modv)+lambda*(udr+3.0*(drdx*(-v1-v2)-drdy*(v0-v2)-drdz*(v0-v1))))
        +lbwpt[14]*(pb-lbkappa*nabrp)+lbkappa*(lbwxx[14]*d2rdx2+lbwyy[14]*d2rdy2+lbwzz[14]*d2rdz2+lbwxy[14]*d2rdxdy+lbwxz[14]*d2rdxdz+lbwyz[14]*d2rdydz)
        +c3*(pi_xx+   pi_yy+   pi_zz)-0.125*(pi_xy+pi_xz-pi_yz);
  return 0;
}

int fD3Q15VFRegular(long tpos, long rpos, int prop, double *uwall, double dx, double dy, double dz, double T)
{
  long spos=tpos * lbsitelength;
  int qdim = lbsy.nf+lbsy.nc+lbsy.nt;
  double drdx, drdy, drdz, dpdx, dpdy, dpdz, nabr, nabp;
  double force[3*lbsy.nf], rho[lbsy.nf];

  fD3Q15BoundaryForceVelocity(force, tpos, rpos, dx, dy, dz, uwall, prop);
    
  if(interact==20) {
    drdx = lbft[4*lbsy.nf*rpos  ];
    drdy = lbft[4*lbsy.nf*rpos+1];
    drdz = lbft[4*lbsy.nf*rpos+2];
    nabr = lbft[4*lbsy.nf*tpos+3];
    dpdx = (lbsy.nf>1)?lbft[4*lbsy.nf*rpos+4]:0.0;
    dpdy = (lbsy.nf>1)?lbft[4*lbsy.nf*rpos+5]:0.0;
    dpdz = (lbsy.nf>1)?lbft[4*lbsy.nf*rpos+6]:0.0;
    nabp = (lbsy.nf>1)?lbft[4*lbsy.nf*tpos+7]:0.0;
  }
  else {
    drdx = 0.0;
    drdy = 0.0;
    drdz = 0.0;
    nabr = 0.0;
    dpdx = 0.0;
    dpdy = 0.0;
    dpdz = 0.0;
    nabp = 0.0;
  }
    
  if(prop>26) {
    fGetAllMassSite(rho, &lbf[rpos*lbsitelength]);
    if(interact==20) {
      rho[0] += (dx*drdx+dy*drdy+dz*drdz);
      if(lbsy.nf>1)
        rho[1] += (dx*dpdx+dy*dpdy+dz*dpdz);
    }
  }
    
  if(interact==20) {
    switch (prop) {
      case PST:
        fD3Q15VPSSwiftRegular(uwall[0], uwall[1], uwall[2], &force[0], &lbf[spos], &lbf[spos+1*qdim],
                              &lbf[spos+2*qdim], &lbf[spos+3*qdim], &lbf[spos+4*qdim], &lbf[spos+5*qdim],
                              &lbf[spos+6*qdim], &lbf[spos+7*qdim], &lbf[spos+8*qdim], &lbf[spos+9*qdim],
                              &lbf[spos+10*qdim], &lbf[spos+11*qdim], &lbf[spos+12*qdim], &lbf[spos+13*qdim],
                              &lbf[spos+14*qdim], drdx, drdy, drdz, dpdx, dpdy, dpdz, nabr, nabp,
                              &lbomega[lbsy.nf*tpos], T);
        break;
      case PSD:
        fD3Q15VPSSwiftRegular(-uwall[0], -uwall[1], -uwall[2], &force[0], &lbf[spos], &lbf[spos+8*qdim],
                              &lbf[spos+9*qdim], &lbf[spos+10*qdim], &lbf[spos+11*qdim], &lbf[spos+12*qdim],
                              &lbf[spos+13*qdim], &lbf[spos+14*qdim], &lbf[spos+1*qdim], &lbf[spos+2*qdim],
                              &lbf[spos+3*qdim], &lbf[spos+4*qdim], &lbf[spos+5*qdim], &lbf[spos+6*qdim],
                              &lbf[spos+7*qdim], -drdx, -drdy, -drdz, -dpdx, -dpdy, -dpdz, nabr, nabp,
                              &lbomega[lbsy.nf*tpos], T);
        break;
      case PSL:
        fD3Q15VPSSwiftRegular(-uwall[2], -uwall[0], -uwall[1], &force[0], &lbf[spos], &lbf[spos+10*qdim],
                              &lbf[spos+8*qdim], &lbf[spos+9*qdim], &lbf[spos+11*qdim], &lbf[spos+13*qdim],
                              &lbf[spos+7*qdim], &lbf[spos+5*qdim], &lbf[spos+3*qdim], &lbf[spos+1*qdim],
                              &lbf[spos+2*qdim], &lbf[spos+4*qdim], &lbf[spos+6*qdim], &lbf[spos+14*qdim],
                              &lbf[spos+12*qdim], -drdz, -drdx, -drdy, -dpdz, -dpdx, -dpdy, nabr, nabp,
                              &lbomega[lbsy.nf*tpos], T);
        break;
      case PSR:
        fD3Q15VPSSwiftRegular(uwall[2], uwall[0], uwall[1], &force[0], &lbf[spos], &lbf[spos+3*qdim],
                              &lbf[spos+1*qdim], &lbf[spos+2*qdim], &lbf[spos+4*qdim], &lbf[spos+6*qdim],
                              &lbf[spos+14*qdim], &lbf[spos+12*qdim], &lbf[spos+10*qdim], &lbf[spos+8*qdim],
                              &lbf[spos+9*qdim], &lbf[spos+11*qdim], &lbf[spos+13*qdim], &lbf[spos+7*qdim],
                              &lbf[spos+5*qdim], drdz, drdx, drdy, dpdz, dpdx, dpdy, nabr, nabp,
                              &lbomega[lbsy.nf*tpos], T);
        break;
      case PSF:
        fD3Q15VPSSwiftRegular(-uwall[1], -uwall[2], -uwall[0], &force[0], &lbf[spos], &lbf[spos+9*qdim],
                              &lbf[spos+10*qdim], &lbf[spos+8*qdim], &lbf[spos+11*qdim], &lbf[spos+7*qdim],
                              &lbf[spos+12*qdim], &lbf[spos+6*qdim], &lbf[spos+2*qdim], &lbf[spos+3*qdim],
                              &lbf[spos+1*qdim], &lbf[spos+4*qdim], &lbf[spos+14*qdim], &lbf[spos+5*qdim],
                              &lbf[spos+13*qdim], -drdy, -drdz, -drdx, -dpdy, -dpdz, -dpdx, nabr, nabp,
                              &lbomega[lbsy.nf*tpos], T);
        break;
      case PSB:
        fD3Q15VPSSwiftRegular(uwall[1], uwall[2], uwall[0], &force[0], &lbf[spos], &lbf[spos+2*qdim],
                              &lbf[spos+3*qdim], &lbf[spos+1*qdim], &lbf[spos+4*qdim], &lbf[spos+14*qdim],
                              &lbf[spos+5*qdim], &lbf[spos+13*qdim], &lbf[spos+9*qdim], &lbf[spos+10*qdim],
                              &lbf[spos+8*qdim], &lbf[spos+11*qdim], &lbf[spos+7*qdim], &lbf[spos+12*qdim],
                              &lbf[spos+6*qdim], drdy, drdz, drdx, dpdy, dpdz, dpdx, nabr, nabp,
                              &lbomega[lbsy.nf*tpos], T);
        break;
      case CCTRB:
        fD3Q15VCCSwiftRegular(rho, uwall[0], uwall[1], -uwall[2], &force[0], &lbf[spos], &lbf[spos+1*qdim],
                              &lbf[spos+2*qdim], &lbf[spos+10*qdim], &lbf[spos+5*qdim], &lbf[spos+4*qdim],
                              &lbf[spos+7*qdim], &lbf[spos+6*qdim], &lbf[spos+8*qdim], &lbf[spos+9*qdim],
                              &lbf[spos+3*qdim], &lbf[spos+12*qdim], &lbf[spos+11*qdim], &lbf[spos+14*qdim],
                              &lbf[spos+13*qdim], drdx, drdy, -drdz, dpdx, dpdy, -dpdz, nabr, nabp,
                              &lbomega[lbsy.nf*tpos], T);
        break;
      case CCTLB:
        fD3Q15VCCSwiftRegular(rho, -uwall[0], uwall[1], -uwall[2], &force[0], &lbf[spos], &lbf[spos+8*qdim],
                              &lbf[spos+2*qdim], &lbf[spos+10*qdim], &lbf[spos+13*qdim], &lbf[spos+14*qdim],
                              &lbf[spos+11*qdim], &lbf[spos+12*qdim], &lbf[spos+1*qdim], &lbf[spos+9*qdim],
                              &lbf[spos+3*qdim], &lbf[spos+6*qdim], &lbf[spos+7*qdim], &lbf[spos+4*qdim],
                              &lbf[spos+5*qdim], -drdx, drdy, -drdz, -dpdx, dpdy, -dpdz, nabr, nabp,
                              &lbomega[lbsy.nf*tpos], T);
        break;
      case CCDLB:
        fD3Q15VCCSwiftRegular(rho, -uwall[0], -uwall[1], -uwall[2], &force[0], &lbf[spos], &lbf[spos+8*qdim],
                              &lbf[spos+9*qdim], &lbf[spos+10*qdim], &lbf[spos+11*qdim], &lbf[spos+12*qdim],
                              &lbf[spos+13*qdim], &lbf[spos+14*qdim], &lbf[spos+1*qdim], &lbf[spos+2*qdim],
                              &lbf[spos+3*qdim], &lbf[spos+4*qdim], &lbf[spos+5*qdim], &lbf[spos+6*qdim],
                              &lbf[spos+7*qdim], -drdx, -drdy, -drdz, -dpdx, -dpdy, -dpdz, nabr, nabp,
                              &lbomega[lbsy.nf*tpos], T);
        break;
      case CCDRB:
        fD3Q15VCCSwiftRegular(rho, uwall[0], -uwall[1], -uwall[2], &force[0], &lbf[spos], &lbf[spos+1*qdim],
                              &lbf[spos+9*qdim], &lbf[spos+10*qdim], &lbf[spos+7*qdim], &lbf[spos+6*qdim],
                              &lbf[spos+5*qdim], &lbf[spos+4*qdim], &lbf[spos+8*qdim], &lbf[spos+2*qdim],
                              &lbf[spos+3*qdim], &lbf[spos+14*qdim], &lbf[spos+13*qdim], &lbf[spos+12*qdim],
                              &lbf[spos+11*qdim], drdx, -drdy, -drdz, dpdx, -dpdy, -dpdz, nabr, nabp,
                              &lbomega[lbsy.nf*tpos], T);
        break;
      case CCTRF:
        fD3Q15VCCSwiftRegular(rho, uwall[0], uwall[1], uwall[2], &force[0], &lbf[spos], &lbf[spos+1*qdim],
                              &lbf[spos+2*qdim], &lbf[spos+3*qdim], &lbf[spos+4*qdim], &lbf[spos+5*qdim],
                              &lbf[spos+6*qdim], &lbf[spos+7*qdim], &lbf[spos+8*qdim], &lbf[spos+9*qdim],
                              &lbf[spos+10*qdim], &lbf[spos+11*qdim], &lbf[spos+12*qdim], &lbf[spos+13*qdim],
                              &lbf[spos+14*qdim], drdx, drdy, drdz, dpdx, dpdy, dpdz, nabr, nabp,
                              &lbomega[lbsy.nf*tpos], T);
        break;
      case CCTLF:
        fD3Q15VCCSwiftRegular(rho, -uwall[0], uwall[1], uwall[2], &force[0], &lbf[spos], &lbf[spos+8*qdim],
                              &lbf[spos+2*qdim], &lbf[spos+3*qdim], &lbf[spos+14*qdim], &lbf[spos+13*qdim],
                              &lbf[spos+12*qdim], &lbf[spos+11*qdim], &lbf[spos+1*qdim], &lbf[spos+9*qdim],
                              &lbf[spos+10*qdim], &lbf[spos+7*qdim], &lbf[spos+6*qdim], &lbf[spos+5*qdim],
                              &lbf[spos+4*qdim], -drdx, drdy, drdz, -dpdx, dpdy, dpdz, nabr, nabp,
                              &lbomega[lbsy.nf*tpos], T);
        break;
      case CCDLF:
        fD3Q15VCCSwiftRegular(rho, -uwall[0], -uwall[1], uwall[2], &force[0], &lbf[spos], &lbf[spos+8*qdim],
                              &lbf[spos+9*qdim], &lbf[spos+3*qdim], &lbf[spos+12*qdim], &lbf[spos+11*qdim],
                              &lbf[spos+14*qdim], &lbf[spos+13*qdim], &lbf[spos+1*qdim], &lbf[spos+2*qdim],
                              &lbf[spos+10*qdim], &lbf[spos+5*qdim], &lbf[spos+4*qdim], &lbf[spos+7*qdim],
                              &lbf[spos+6*qdim], -drdx, -drdy, drdz, -dpdx, -dpdy, dpdz, nabr, nabp,
                              &lbomega[lbsy.nf*tpos], T);
        break;
      case CCDRF:
        fD3Q15VCCSwiftRegular(rho, uwall[0], -uwall[1], uwall[2], &force[0], &lbf[spos], &lbf[spos+1*qdim],
                              &lbf[spos+9*qdim], &lbf[spos+3*qdim], &lbf[spos+6*qdim], &lbf[spos+7*qdim],
                              &lbf[spos+4*qdim], &lbf[spos+5*qdim], &lbf[spos+8*qdim], &lbf[spos+2*qdim],
                              &lbf[spos+10*qdim], &lbf[spos+13*qdim], &lbf[spos+14*qdim], &lbf[spos+11*qdim],
                              &lbf[spos+12*qdim], drdx, -drdy, drdz, dpdx, -dpdy, dpdz, nabr, nabp,
                              &lbomega[lbsy.nf*tpos], T);
        break;
      case CETR:
        fD3Q15VCESwiftRegular(rho, uwall[0], uwall[1], uwall[2], &force[0], &lbf[spos], &lbf[spos+1*qdim],
                              &lbf[spos+2*qdim], &lbf[spos+3*qdim], &lbf[spos+4*qdim], &lbf[spos+5*qdim],
                              &lbf[spos+6*qdim], &lbf[spos+7*qdim], &lbf[spos+8*qdim], &lbf[spos+9*qdim],
                              &lbf[spos+10*qdim], &lbf[spos+11*qdim], &lbf[spos+12*qdim], &lbf[spos+13*qdim],
                              &lbf[spos+14*qdim], drdx, drdy, drdz, dpdx, dpdy, dpdz, nabr, nabp,
                              &lbomega[lbsy.nf*tpos], T);
        break;
      case CETL:
        fD3Q15VCESwiftRegular(rho, uwall[1], -uwall[0], uwall[2], &force[0], &lbf[spos], &lbf[spos+2*qdim],
                              &lbf[spos+8*qdim], &lbf[spos+3*qdim], &lbf[spos+14*qdim], &lbf[spos+13*qdim],
                              &lbf[spos+4*qdim], &lbf[spos+5*qdim], &lbf[spos+9*qdim], &lbf[spos+1*qdim],
                              &lbf[spos+10*qdim], &lbf[spos+7*qdim], &lbf[spos+6*qdim], &lbf[spos+11*qdim],
                              &lbf[spos+12*qdim], drdy, -drdx, drdz, dpdy, -dpdx, dpdz, nabr, nabp,
                              &lbomega[lbsy.nf*tpos], T);
        break;
      case CEDL:
        fD3Q15VCESwiftRegular(rho, -uwall[0], -uwall[1], uwall[2], &force[0], &lbf[spos], &lbf[spos+8*qdim],
                              &lbf[spos+9*qdim], &lbf[spos+3*qdim], &lbf[spos+12*qdim], &lbf[spos+11*qdim],
                              &lbf[spos+14*qdim], &lbf[spos+13*qdim], &lbf[spos+1*qdim], &lbf[spos+2*qdim],
                              &lbf[spos+10*qdim], &lbf[spos+5*qdim], &lbf[spos+4*qdim], &lbf[spos+7*qdim],
                              &lbf[spos+6*qdim], -drdx, -drdy, drdz, -dpdx, -dpdy, dpdz, nabr, nabp,
                              &lbomega[lbsy.nf*tpos], T);
        break;
      case CEDR:
        fD3Q15VCESwiftRegular(rho, -uwall[1], uwall[0], uwall[2], &force[0], &lbf[spos], &lbf[spos+9*qdim],
                              &lbf[spos+1*qdim], &lbf[spos+3*qdim], &lbf[spos+6*qdim], &lbf[spos+7*qdim],
                              &lbf[spos+12*qdim], &lbf[spos+11*qdim], &lbf[spos+2*qdim], &lbf[spos+8*qdim],
                              &lbf[spos+10*qdim], &lbf[spos+13*qdim], &lbf[spos+14*qdim], &lbf[spos+5*qdim],
                              &lbf[spos+4*qdim], -drdy, drdx, drdz, -dpdy, dpdx, dpdz, nabr, nabp,
                              &lbomega[lbsy.nf*tpos], T);
        break;
      case CETF:
        fD3Q15VCESwiftRegular(rho, uwall[1], uwall[2], uwall[0], &force[0], &lbf[spos], &lbf[spos+2*qdim],
                              &lbf[spos+3*qdim], &lbf[spos+1*qdim], &lbf[spos+4*qdim], &lbf[spos+14*qdim],
                              &lbf[spos+5*qdim], &lbf[spos+13*qdim], &lbf[spos+9*qdim], &lbf[spos+10*qdim],
                              &lbf[spos+8*qdim], &lbf[spos+11*qdim], &lbf[spos+7*qdim], &lbf[spos+12*qdim],
                              &lbf[spos+6*qdim], drdy, drdz, drdx, dpdy, dpdz, dpdx, nabr, nabp,
                              &lbomega[lbsy.nf*tpos], T);
        break;
      case CELF:
        fD3Q15VCESwiftRegular(rho, -uwall[0], uwall[2], uwall[1], &force[0], &lbf[spos], &lbf[spos+8*qdim],
                              &lbf[spos+3*qdim], &lbf[spos+2*qdim], &lbf[spos+14*qdim], &lbf[spos+12*qdim],
                              &lbf[spos+13*qdim], &lbf[spos+11*qdim], &lbf[spos+1*qdim], &lbf[spos+10*qdim],
                              &lbf[spos+9*qdim], &lbf[spos+7*qdim], &lbf[spos+5*qdim], &lbf[spos+6*qdim],
                              &lbf[spos+4*qdim], -drdx, drdz, drdy, -dpdx, dpdz, dpdy, nabr, nabp,
                              &lbomega[lbsy.nf*tpos], T);
        break;
      case CEDF:
        fD3Q15VCESwiftRegular(rho, -uwall[1], uwall[2], uwall[0], &force[0], &lbf[spos], &lbf[spos+9*qdim],
                              &lbf[spos+3*qdim], &lbf[spos+1*qdim], &lbf[spos+6*qdim], &lbf[spos+12*qdim],
                              &lbf[spos+7*qdim], &lbf[spos+11*qdim], &lbf[spos+2*qdim], &lbf[spos+10*qdim],
                              &lbf[spos+8*qdim], &lbf[spos+13*qdim], &lbf[spos+5*qdim], &lbf[spos+14*qdim],
                              &lbf[spos+4*qdim], -drdy, drdz, drdx, -dpdy, dpdz, dpdx, nabr, nabp,
                              &lbomega[lbsy.nf*tpos], T);
        break;
      case CERF:
        fD3Q15VCESwiftRegular(rho, uwall[0], uwall[2], uwall[1], &force[0], &lbf[spos], &lbf[spos+1*qdim],
                              &lbf[spos+3*qdim], &lbf[spos+2*qdim], &lbf[spos+4*qdim], &lbf[spos+6*qdim],
                              &lbf[spos+5*qdim], &lbf[spos+7*qdim], &lbf[spos+8*qdim], &lbf[spos+10*qdim],
                              &lbf[spos+9*qdim], &lbf[spos+11*qdim], &lbf[spos+13*qdim], &lbf[spos+12*qdim],
                              &lbf[spos+14*qdim], drdx, drdz, drdy, dpdx, dpdz, dpdy, nabr, nabp,
                              &lbomega[lbsy.nf*tpos], T);
        break;
      case CETB:
        fD3Q15VCESwiftRegular(rho, uwall[1], -uwall[2], uwall[0], &force[0], &lbf[spos], &lbf[spos+2*qdim],
                              &lbf[spos+10*qdim], &lbf[spos+1*qdim], &lbf[spos+5*qdim], &lbf[spos+13*qdim],
                              &lbf[spos+4*qdim], &lbf[spos+14*qdim], &lbf[spos+9*qdim], &lbf[spos+3*qdim],
                              &lbf[spos+8*qdim], &lbf[spos+12*qdim], &lbf[spos+6*qdim], &lbf[spos+11*qdim],
                              &lbf[spos+7*qdim], drdy, -drdz, drdx, dpdy, -dpdz, dpdx, nabr, nabp,
                              &lbomega[lbsy.nf*tpos], T);
        break;
      case CELB:
        fD3Q15VCESwiftRegular(rho, -uwall[0], -uwall[2], uwall[1], &force[0], &lbf[spos], &lbf[spos+8*qdim],
                              &lbf[spos+10*qdim], &lbf[spos+2*qdim], &lbf[spos+13*qdim], &lbf[spos+11*qdim],
                              &lbf[spos+14*qdim], &lbf[spos+12*qdim], &lbf[spos+1*qdim], &lbf[spos+3*qdim],
                              &lbf[spos+9*qdim], &lbf[spos+6*qdim], &lbf[spos+4*qdim], &lbf[spos+7*qdim],
                              &lbf[spos+5*qdim], -drdx, -drdz, drdy, -dpdx, -dpdz, dpdy, nabr, nabp,
                              &lbomega[lbsy.nf*tpos], T);
        break;
      case CEDB:
        fD3Q15VCESwiftRegular(rho, -uwall[1], -uwall[2], uwall[0], &force[0], &lbf[spos], &lbf[spos+9*qdim],
                              &lbf[spos+10*qdim], &lbf[spos+1*qdim], &lbf[spos+7*qdim], &lbf[spos+11*qdim],
                              &lbf[spos+6*qdim], &lbf[spos+12*qdim], &lbf[spos+2*qdim], &lbf[spos+3*qdim],
                              &lbf[spos+8*qdim], &lbf[spos+14*qdim], &lbf[spos+4*qdim], &lbf[spos+13*qdim],
                              &lbf[spos+5*qdim], -drdy, -drdz, drdx, -dpdy, -dpdz, dpdx, nabr, nabp,
                              &lbomega[lbsy.nf*tpos], T);
        break;
      case CERB:
        fD3Q15VCESwiftRegular(rho, uwall[0], -uwall[2], uwall[1], &force[0], &lbf[spos], &lbf[spos+1*qdim],
                              &lbf[spos+10*qdim], &lbf[spos+2*qdim], &lbf[spos+5*qdim], &lbf[spos+7*qdim],
                              &lbf[spos+4*qdim], &lbf[spos+6*qdim], &lbf[spos+8*qdim], &lbf[spos+3*qdim],
                              &lbf[spos+9*qdim], &lbf[spos+12*qdim], &lbf[spos+14*qdim], &lbf[spos+11*qdim],
                              &lbf[spos+13*qdim], drdx, -drdz, drdy, dpdx, -dpdz, dpdy, nabr, nabp,
                              &lbomega[lbsy.nf*tpos], T);
        break;
    }
  }
  else {
    switch (prop) {
      case PST:
        fD3Q15VPSRegular(uwall[0], uwall[1], uwall[2], &force[0], &lbf[spos], &lbf[spos+1*qdim],
                         &lbf[spos+2*qdim], &lbf[spos+3*qdim], &lbf[spos+4*qdim], &lbf[spos+5*qdim],
                         &lbf[spos+6*qdim], &lbf[spos+7*qdim], &lbf[spos+8*qdim], &lbf[spos+9*qdim],
                         &lbf[spos+10*qdim], &lbf[spos+11*qdim], &lbf[spos+12*qdim], &lbf[spos+13*qdim],
                         &lbf[spos+14*qdim]);
        break;
      case PSD:
        fD3Q15VPSRegular(-uwall[0], -uwall[1], -uwall[2], &force[0], &lbf[spos], &lbf[spos+8*qdim],
                         &lbf[spos+9*qdim], &lbf[spos+10*qdim], &lbf[spos+11*qdim], &lbf[spos+12*qdim],
                         &lbf[spos+13*qdim], &lbf[spos+14*qdim], &lbf[spos+1*qdim], &lbf[spos+2*qdim],
                         &lbf[spos+3*qdim], &lbf[spos+4*qdim], &lbf[spos+5*qdim], &lbf[spos+6*qdim],
                         &lbf[spos+7*qdim]);
        break;
      case PSL:
        fD3Q15VPSRegular(-uwall[2], -uwall[0], -uwall[1], &force[0], &lbf[spos], &lbf[spos+10*qdim],
                         &lbf[spos+8*qdim], &lbf[spos+9*qdim], &lbf[spos+11*qdim], &lbf[spos+13*qdim],
                         &lbf[spos+7*qdim], &lbf[spos+5*qdim], &lbf[spos+3*qdim], &lbf[spos+1*qdim],
                         &lbf[spos+2*qdim], &lbf[spos+4*qdim], &lbf[spos+6*qdim], &lbf[spos+14*qdim],
                         &lbf[spos+12*qdim]);
        break;
      case PSR:
        fD3Q15VPSRegular(uwall[2], uwall[0], uwall[1], &force[0], &lbf[spos], &lbf[spos+3*qdim],
                         &lbf[spos+1*qdim], &lbf[spos+2*qdim], &lbf[spos+4*qdim], &lbf[spos+6*qdim],
                         &lbf[spos+14*qdim], &lbf[spos+12*qdim], &lbf[spos+10*qdim], &lbf[spos+8*qdim],
                         &lbf[spos+9*qdim], &lbf[spos+11*qdim], &lbf[spos+13*qdim], &lbf[spos+7*qdim],
                         &lbf[spos+5*qdim]);
        break;
      case PSF:
        fD3Q15VPSRegular(-uwall[1], -uwall[2], -uwall[0], &force[0], &lbf[spos], &lbf[spos+9*qdim],
                         &lbf[spos+10*qdim], &lbf[spos+8*qdim], &lbf[spos+11*qdim], &lbf[spos+7*qdim],
                         &lbf[spos+12*qdim], &lbf[spos+6*qdim], &lbf[spos+2*qdim], &lbf[spos+3*qdim],
                         &lbf[spos+1*qdim], &lbf[spos+4*qdim], &lbf[spos+14*qdim], &lbf[spos+5*qdim],
                         &lbf[spos+13*qdim]);
        break;
      case PSB:
        fD3Q15VPSRegular(uwall[1], uwall[2], uwall[0], &force[0], &lbf[spos], &lbf[spos+2*qdim],
                         &lbf[spos+3*qdim], &lbf[spos+1*qdim], &lbf[spos+4*qdim], &lbf[spos+14*qdim],
                         &lbf[spos+5*qdim], &lbf[spos+13*qdim], &lbf[spos+9*qdim], &lbf[spos+10*qdim],
                         &lbf[spos+8*qdim], &lbf[spos+11*qdim], &lbf[spos+7*qdim], &lbf[spos+12*qdim],
                         &lbf[spos+6*qdim]);
        break;
      case CCTRB:
        fD3Q15VCCRegular(rho, uwall[0], uwall[1], -uwall[2], &force[0], &lbf[spos], &lbf[spos+1*qdim],
                         &lbf[spos+2*qdim], &lbf[spos+10*qdim], &lbf[spos+5*qdim], &lbf[spos+4*qdim],
                         &lbf[spos+7*qdim], &lbf[spos+6*qdim], &lbf[spos+8*qdim], &lbf[spos+9*qdim],
                         &lbf[spos+3*qdim], &lbf[spos+12*qdim], &lbf[spos+11*qdim], &lbf[spos+14*qdim],
                         &lbf[spos+13*qdim]);
        break;
      case CCTLB:
        fD3Q15VCCRegular(rho, -uwall[0], uwall[1], -uwall[2], &force[0], &lbf[spos], &lbf[spos+8*qdim],
                         &lbf[spos+2*qdim], &lbf[spos+10*qdim], &lbf[spos+13*qdim], &lbf[spos+14*qdim],
                         &lbf[spos+11*qdim], &lbf[spos+12*qdim], &lbf[spos+1*qdim], &lbf[spos+9*qdim],
                         &lbf[spos+3*qdim], &lbf[spos+6*qdim], &lbf[spos+7*qdim], &lbf[spos+4*qdim],
                         &lbf[spos+5*qdim]);
        break;
      case CCDLB:
        fD3Q15VCCRegular(rho, -uwall[0], -uwall[1], -uwall[2], &force[0], &lbf[spos], &lbf[spos+8*qdim],
                         &lbf[spos+9*qdim], &lbf[spos+10*qdim], &lbf[spos+11*qdim], &lbf[spos+12*qdim],
                         &lbf[spos+13*qdim], &lbf[spos+14*qdim], &lbf[spos+1*qdim], &lbf[spos+2*qdim],
                         &lbf[spos+3*qdim], &lbf[spos+4*qdim], &lbf[spos+5*qdim], &lbf[spos+6*qdim],
                         &lbf[spos+7*qdim]);
        break;
      case CCDRB:
        fD3Q15VCCRegular(rho, uwall[0], -uwall[1], -uwall[2], &force[0], &lbf[spos], &lbf[spos+1*qdim],
                         &lbf[spos+9*qdim], &lbf[spos+10*qdim], &lbf[spos+7*qdim], &lbf[spos+6*qdim],
                         &lbf[spos+5*qdim], &lbf[spos+4*qdim], &lbf[spos+8*qdim], &lbf[spos+2*qdim],
                         &lbf[spos+3*qdim], &lbf[spos+14*qdim], &lbf[spos+13*qdim], &lbf[spos+12*qdim],
                         &lbf[spos+11*qdim]);
        break;
      case CCTRF:
        fD3Q15VCCRegular(rho, uwall[0], uwall[1], uwall[2], &force[0], &lbf[spos], &lbf[spos+1*qdim],
                         &lbf[spos+2*qdim], &lbf[spos+3*qdim], &lbf[spos+4*qdim], &lbf[spos+5*qdim],
                         &lbf[spos+6*qdim], &lbf[spos+7*qdim], &lbf[spos+8*qdim], &lbf[spos+9*qdim],
                         &lbf[spos+10*qdim], &lbf[spos+11*qdim], &lbf[spos+12*qdim], &lbf[spos+13*qdim],
                         &lbf[spos+14*qdim]);
        break;
      case CCTLF:
        fD3Q15VCCRegular(rho, -uwall[0], uwall[1], uwall[2], &force[0], &lbf[spos], &lbf[spos+8*qdim],
                         &lbf[spos+2*qdim], &lbf[spos+3*qdim], &lbf[spos+14*qdim], &lbf[spos+13*qdim],
                         &lbf[spos+12*qdim], &lbf[spos+11*qdim], &lbf[spos+1*qdim], &lbf[spos+9*qdim],
                         &lbf[spos+10*qdim], &lbf[spos+7*qdim], &lbf[spos+6*qdim], &lbf[spos+5*qdim],
                         &lbf[spos+4*qdim]);
        break;
      case CCDLF:
        fD3Q15VCCRegular(rho, -uwall[0], -uwall[1], uwall[2], &force[0], &lbf[spos], &lbf[spos+8*qdim],
                         &lbf[spos+9*qdim], &lbf[spos+3*qdim], &lbf[spos+12*qdim], &lbf[spos+11*qdim],
                         &lbf[spos+14*qdim], &lbf[spos+13*qdim], &lbf[spos+1*qdim], &lbf[spos+2*qdim],
                         &lbf[spos+10*qdim], &lbf[spos+5*qdim], &lbf[spos+4*qdim], &lbf[spos+7*qdim],
                         &lbf[spos+6*qdim]);
        break;
      case CCDRF:
        fD3Q15VCCRegular(rho, uwall[0], -uwall[1], uwall[2], &force[0], &lbf[spos], &lbf[spos+1*qdim],
                         &lbf[spos+9*qdim], &lbf[spos+3*qdim], &lbf[spos+6*qdim], &lbf[spos+7*qdim],
                         &lbf[spos+4*qdim], &lbf[spos+5*qdim], &lbf[spos+8*qdim], &lbf[spos+2*qdim],
                         &lbf[spos+10*qdim], &lbf[spos+13*qdim], &lbf[spos+14*qdim], &lbf[spos+11*qdim],
                         &lbf[spos+12*qdim]);
        break;
      case CETR:
        fD3Q15VCERegular(rho, uwall[0], uwall[1], uwall[2], &force[0], &lbf[spos], &lbf[spos+1*qdim],
                         &lbf[spos+2*qdim], &lbf[spos+3*qdim], &lbf[spos+4*qdim], &lbf[spos+5*qdim],
                         &lbf[spos+6*qdim], &lbf[spos+7*qdim], &lbf[spos+8*qdim], &lbf[spos+9*qdim],
                         &lbf[spos+10*qdim], &lbf[spos+11*qdim], &lbf[spos+12*qdim], &lbf[spos+13*qdim],
                         &lbf[spos+14*qdim]);
        break;
      case CETL:
        fD3Q15VCERegular(rho, uwall[1], -uwall[0], uwall[2], &force[0], &lbf[spos], &lbf[spos+2*qdim],
                         &lbf[spos+8*qdim], &lbf[spos+3*qdim], &lbf[spos+14*qdim], &lbf[spos+13*qdim],
                         &lbf[spos+4*qdim], &lbf[spos+5*qdim], &lbf[spos+9*qdim], &lbf[spos+1*qdim],
                         &lbf[spos+10*qdim], &lbf[spos+7*qdim], &lbf[spos+6*qdim], &lbf[spos+11*qdim],
                         &lbf[spos+12*qdim]);
        break;
      case CEDL:
        fD3Q15VCERegular(rho, -uwall[0], -uwall[1], uwall[2], &force[0], &lbf[spos], &lbf[spos+8*qdim],
                         &lbf[spos+9*qdim], &lbf[spos+3*qdim], &lbf[spos+12*qdim], &lbf[spos+11*qdim],
                         &lbf[spos+14*qdim], &lbf[spos+13*qdim], &lbf[spos+1*qdim], &lbf[spos+2*qdim],
                         &lbf[spos+10*qdim], &lbf[spos+5*qdim], &lbf[spos+4*qdim], &lbf[spos+7*qdim],
                         &lbf[spos+6*qdim]);
        break;
      case CEDR:
        fD3Q15VCERegular(rho, -uwall[1], uwall[0], uwall[2], &force[0], &lbf[spos], &lbf[spos+9*qdim],
                         &lbf[spos+1*qdim], &lbf[spos+3*qdim], &lbf[spos+6*qdim], &lbf[spos+7*qdim],
                         &lbf[spos+12*qdim], &lbf[spos+11*qdim], &lbf[spos+2*qdim], &lbf[spos+8*qdim],
                         &lbf[spos+10*qdim], &lbf[spos+13*qdim], &lbf[spos+14*qdim], &lbf[spos+5*qdim],
                         &lbf[spos+4*qdim]);
        break;
      case CETF:
        fD3Q15VCERegular(rho, uwall[1], uwall[2], uwall[0], &force[0], &lbf[spos], &lbf[spos+2*qdim],
                         &lbf[spos+3*qdim], &lbf[spos+1*qdim], &lbf[spos+4*qdim], &lbf[spos+14*qdim],
                         &lbf[spos+5*qdim], &lbf[spos+13*qdim], &lbf[spos+9*qdim], &lbf[spos+10*qdim],
                         &lbf[spos+8*qdim], &lbf[spos+11*qdim], &lbf[spos+7*qdim], &lbf[spos+12*qdim],
                         &lbf[spos+6*qdim]);
        break;
      case CELF:
        fD3Q15VCERegular(rho, -uwall[0], uwall[2], uwall[1], &force[0], &lbf[spos], &lbf[spos+8*qdim],
                         &lbf[spos+3*qdim], &lbf[spos+2*qdim], &lbf[spos+14*qdim], &lbf[spos+12*qdim],
                         &lbf[spos+13*qdim], &lbf[spos+11*qdim], &lbf[spos+1*qdim], &lbf[spos+10*qdim],
                         &lbf[spos+9*qdim], &lbf[spos+7*qdim], &lbf[spos+5*qdim], &lbf[spos+6*qdim],
                         &lbf[spos+4*qdim]);
        break;
      case CEDF:
        fD3Q15VCERegular(rho, -uwall[1], uwall[2], uwall[0], &force[0], &lbf[spos], &lbf[spos+9*qdim],
                         &lbf[spos+3*qdim], &lbf[spos+1*qdim], &lbf[spos+6*qdim], &lbf[spos+12*qdim],
                         &lbf[spos+7*qdim], &lbf[spos+11*qdim], &lbf[spos+2*qdim], &lbf[spos+10*qdim],
                         &lbf[spos+8*qdim], &lbf[spos+13*qdim], &lbf[spos+5*qdim], &lbf[spos+14*qdim],
                         &lbf[spos+4*qdim]);
        break;
      case CERF:
        fD3Q15VCERegular(rho, uwall[0], uwall[2], uwall[1], &force[0], &lbf[spos], &lbf[spos+1*qdim],
                         &lbf[spos+3*qdim], &lbf[spos+2*qdim], &lbf[spos+4*qdim], &lbf[spos+6*qdim],
                         &lbf[spos+5*qdim], &lbf[spos+7*qdim], &lbf[spos+8*qdim], &lbf[spos+10*qdim],
                         &lbf[spos+9*qdim], &lbf[spos+11*qdim], &lbf[spos+13*qdim], &lbf[spos+12*qdim],
                         &lbf[spos+14*qdim]);
        break;
      case CETB:
        fD3Q15VCERegular(rho, uwall[1], -uwall[2], uwall[0], &force[0], &lbf[spos], &lbf[spos+2*qdim],
                         &lbf[spos+10*qdim], &lbf[spos+1*qdim], &lbf[spos+5*qdim], &lbf[spos+13*qdim],
                         &lbf[spos+4*qdim], &lbf[spos+14*qdim], &lbf[spos+9*qdim], &lbf[spos+3*qdim],
                         &lbf[spos+8*qdim], &lbf[spos+12*qdim], &lbf[spos+6*qdim], &lbf[spos+11*qdim],
                         &lbf[spos+7*qdim]);
        break;
      case CELB:
        fD3Q15VCERegular(rho, -uwall[0], -uwall[2], uwall[1], &force[0], &lbf[spos], &lbf[spos+8*qdim],
                         &lbf[spos+10*qdim], &lbf[spos+2*qdim], &lbf[spos+13*qdim], &lbf[spos+11*qdim],
                         &lbf[spos+14*qdim], &lbf[spos+12*qdim], &lbf[spos+1*qdim], &lbf[spos+3*qdim],
                         &lbf[spos+9*qdim], &lbf[spos+6*qdim], &lbf[spos+4*qdim], &lbf[spos+7*qdim],
                         &lbf[spos+5*qdim]);
        break;
      case CEDB:
        fD3Q15VCERegular(rho, -uwall[1], -uwall[2], uwall[0], &force[0], &lbf[spos], &lbf[spos+9*qdim],
                         &lbf[spos+10*qdim], &lbf[spos+1*qdim], &lbf[spos+7*qdim], &lbf[spos+11*qdim],
                         &lbf[spos+6*qdim], &lbf[spos+12*qdim], &lbf[spos+2*qdim], &lbf[spos+3*qdim],
                         &lbf[spos+8*qdim], &lbf[spos+14*qdim], &lbf[spos+4*qdim], &lbf[spos+13*qdim],
                         &lbf[spos+5*qdim]);
        break;
      case CERB:
        fD3Q15VCERegular(rho, uwall[0], -uwall[2], uwall[1], &force[0], &lbf[spos], &lbf[spos+1*qdim],
                         &lbf[spos+10*qdim], &lbf[spos+2*qdim], &lbf[spos+5*qdim], &lbf[spos+7*qdim],
                         &lbf[spos+4*qdim], &lbf[spos+6*qdim], &lbf[spos+8*qdim], &lbf[spos+3*qdim],
                         &lbf[spos+9*qdim], &lbf[spos+12*qdim], &lbf[spos+14*qdim], &lbf[spos+11*qdim],
                         &lbf[spos+13*qdim]);
        break;
    }
  }
  return 0;
  
}

int fD3Q15PPSRegular(double *p, double *force, double *f0, double *f1,
	                 double *f2, double *f3, double *f4, double *f5,
	                 double *f6, double *f7, double *f8, double *f9,
	                 double *f10, double *f11, double *f12, double *f13,
	                 double *f14, double &vel)
{

  // produce fixed pressure/density at planar surface: expressed for bottom wall

  double rho, rho0, pi_xx, pi_yy, pi_zz, pi_xy, pi_xz, pi_yz, v, v1, v1v1, mass=0.0;
  double c1=1.0/3.0,c2=1.0/6.0,c3=1.0/24.0;
  vel = 0.0;

  if(!incompress) {
    for(int i=0; i<lbsy.nf; i++) {
      v = p[i]-(f0[i]+f1[i]+f3[i]+f8[i]+f10[i]+2*(f2[i]+f4[i]+f5[i]+f13[i]+f14[i]))+0.5*force[3*i+1];
      vel += v;
      mass += p[i];
    }
    vel *= fReciprocal(mass);
    v1 = vel;
    v1v1 = v1*v1;
    for(int i=0; i<lbsy.nf; i++) {
      rho = p[i];
      pi_xx = f1[i]+f8[i]+2.0*(f4[i]+f5[i]+f13[i]+f14[i])+rho*c1*(v1-1.0);
      pi_yy = 2.0*(f2[i]+f4[i]+f5[i]+f13[i]+f14[i])+rho*(v1-v1v1-c1)+v1*force[3*i+1];
      pi_zz = f3[i]+f10[i]+2.0*(f4[i]+f5[i]+f13[i]+f14[i])+rho*c1*(v1-1.0);
      pi_xy = 2.0*(f4[i]+f5[i]-f13[i]-f14[i])+0.5*v1*force[3*i  ];
      pi_xz = 2.0*(f4[i]-f5[i]+f13[i]-f14[i]);
      pi_yz = 2.0*(f4[i]-f5[i]-f13[i]+f14[i])+0.5*v1*force[3*i+2];
      f0[i] =rho*lbw[0] *(1.0       -1.5*v1v1)-c1*(pi_xx+   pi_yy+   pi_zz);
      f1[i] =rho*lbw[1] *(1.0       -1.5*v1v1)+c1* pi_xx-c2*pi_yy-c2*pi_zz;
      f2[i] =rho*lbw[2] *(1.0-3.0*v1+3.0*v1v1)-c2* pi_xx+c1*pi_yy-c2*pi_zz;
      f3[i] =rho*lbw[3] *(1.0       -1.5*v1v1)-c2* pi_xx-c2*pi_yy+c1*pi_zz;
      f4[i] =rho*lbw[4] *(1.0-3.0*v1+3.0*v1v1)+c3*(pi_xx+   pi_yy+   pi_zz)+0.125*(pi_xy+pi_xz+pi_yz);
      f5[i] =rho*lbw[5] *(1.0-3.0*v1+3.0*v1v1)+c3*(pi_xx+   pi_yy+   pi_zz)+0.125*(pi_xy-pi_xz-pi_yz);
      f6[i] =rho*lbw[6] *(1.0+3.0*v1+3.0*v1v1)+c3*(pi_xx+   pi_yy+   pi_zz)-0.125*(pi_xy-pi_xz+pi_yz);
      f7[i] =rho*lbw[7] *(1.0+3.0*v1+3.0*v1v1)+c3*(pi_xx+   pi_yy+   pi_zz)-0.125*(pi_xy+pi_xz-pi_yz);
      f8[i] =rho*lbw[8] *(1.0       -1.5*v1v1)+c1* pi_xx-c2*pi_yy-c2*pi_zz;
      f9[i] =rho*lbw[9] *(1.0+3.0*v1+3.0*v1v1)-c2* pi_xx+c1*pi_yy-c2*pi_zz;
      f10[i]=rho*lbw[10]*(1.0       -1.5*v1v1)-c2* pi_xx-c2*pi_yy+c1*pi_zz;
      f11[i]=rho*lbw[11]*(1.0+3.0*v1+3.0*v1v1)+c3*(pi_xx+   pi_yy+   pi_zz)+0.125*(pi_xy+pi_xz+pi_yz);
      f12[i]=rho*lbw[12]*(1.0+3.0*v1+3.0*v1v1)+c3*(pi_xx+   pi_yy+   pi_zz)+0.125*(pi_xy-pi_xz-pi_yz);
      f13[i]=rho*lbw[13]*(1.0-3.0*v1+3.0*v1v1)+c3*(pi_xx+   pi_yy+   pi_zz)-0.125*(pi_xy-pi_xz+pi_yz);
      f14[i]=rho*lbw[14]*(1.0-3.0*v1+3.0*v1v1)+c3*(pi_xx+   pi_yy+   pi_zz)-0.125*(pi_xy+pi_xz-pi_yz);
    }
  }
  else {
    for(int i=0; i<lbsy.nf; i++) {
      v = p[i]-(f0[i]+f1[i]+f3[i]+f8[i]+f10[i]+2*(f2[i]+f4[i]+f5[i]+f13[i]+f14[i]))+0.5*force[3*i+1];
      vel += v;
      mass += lbincp[i];
    }
    vel *= fReciprocal(mass);
    v1 = vel;
    v1v1 = v1*v1;
    for(int i=0; i<lbsy.nf; i++) {
      rho0 = lbincp[i];
      rho = f0[i]+f1[i]+f3[i]+f8[i]+f10[i]+2*(f2[i]+f4[i]+f5[i]+f13[i]+f14[i])+rho0*v1-0.5*force[3*i+1];
      pi_xx = f1[i]+f8[i]+2.0*(f4[i]+f5[i]+f13[i]+f14[i])+c1*(rho0*v1-rho);
      pi_yy = 2.0*(f2[i]+f4[i]+f5[i]+f13[i]+f14[i])+rho0*(v1-v1v1)-c1*rho+v1*force[3*i+1];
      pi_zz = f3[i]+f10[i]+2.0*(f4[i]+f5[i]+f13[i]+f14[i])+c1*(rho0*v1-rho);
      pi_xy = 2.0*(f4[i]+f5[i]-f13[i]-f14[i])+0.5*v1*force[3*i  ];
      pi_xz = 2.0*(f4[i]-f5[i]+f13[i]-f14[i]);
      pi_yz = 2.0*(f4[i]-f5[i]-f13[i]+f14[i])+0.5*v1*force[3*i+2];
      f0[i] =lbw[0] *(rho+rho0*(       -1.5*v1v1))-c1*(pi_xx+   pi_yy+   pi_zz);
      f1[i] =lbw[1] *(rho+rho0*(       -1.5*v1v1))+c1* pi_xx-c2*pi_yy-c2*pi_zz;
      f2[i] =lbw[2] *(rho+rho0*(-3.0*v1+3.0*v1v1))-c2* pi_xx+c1*pi_yy-c2*pi_zz;
      f3[i] =lbw[3] *(rho+rho0*(       -1.5*v1v1))-c2* pi_xx-c2*pi_yy+c1*pi_zz;
      f4[i] =lbw[4] *(rho+rho0*(-3.0*v1+3.0*v1v1))+c3*(pi_xx+   pi_yy+   pi_zz)+0.125*(pi_xy+pi_xz+pi_yz);
      f5[i] =lbw[5] *(rho+rho0*(-3.0*v1+3.0*v1v1))+c3*(pi_xx+   pi_yy+   pi_zz)+0.125*(pi_xy-pi_xz-pi_yz);
      f6[i] =lbw[6] *(rho+rho0*( 3.0*v1+3.0*v1v1))+c3*(pi_xx+   pi_yy+   pi_zz)-0.125*(pi_xy-pi_xz+pi_yz);
      f7[i] =lbw[7] *(rho+rho0*( 3.0*v1+3.0*v1v1))+c3*(pi_xx+   pi_yy+   pi_zz)-0.125*(pi_xy+pi_xz-pi_yz);
      f8[i] =lbw[8] *(rho+rho0*(       -1.5*v1v1))+c1* pi_xx-c2*pi_yy-c2*pi_zz;
      f9[i] =lbw[9] *(rho+rho0*(       +3.0*v1v1))-c2* pi_xx+c1*pi_yy-c2*pi_zz;
      f10[i]=lbw[10]*(rho+rho0*(       -1.5*v1v1))-c2* pi_xx-c2*pi_yy+c1*pi_zz;
      f11[i]=lbw[11]*(rho+rho0*( 3.0*v1+3.0*v1v1))+c3*(pi_xx+   pi_yy+   pi_zz)+0.125*(pi_xy+pi_xz+pi_yz);
      f12[i]=lbw[12]*(rho+rho0*( 3.0*v1+3.0*v1v1))+c3*(pi_xx+   pi_yy+   pi_zz)+0.125*(pi_xy-pi_xz-pi_yz);
      f13[i]=lbw[13]*(rho+rho0*(-3.0*v1+3.0*v1v1))+c3*(pi_xx+   pi_yy+   pi_zz)-0.125*(pi_xy-pi_xz+pi_yz);
      f14[i]=lbw[14]*(rho+rho0*(-3.0*v1+3.0*v1v1))+c3*(pi_xx+   pi_yy+   pi_zz)-0.125*(pi_xy+pi_xz-pi_yz);
    }
  }
  return 0;
}

int fD3Q15PPSSwiftRegular(double *p, double *force, double *f0, double *f1,
	                      double *f2, double *f3, double *f4, double *f5,
	                      double *f6, double *f7, double *f8, double *f9,
	                      double *f10, double *f11, double *f12, double *f13,
	                      double *f14, double drdx, double drdy, double drdz,
                          double dpdx, double dpdy, double dpdz, double nabr,
                          double nabp, double *omega, double T, double &vel)
{

  double rho, phi, omegat, pb, mu, lambda, d2rdx2, d2rdy2, d2rdz2, d2rdxdy, d2rdxdz, d2rdydz, nabrp;
  double v, v1, v1v1;
  double pi_xx, pi_yy, pi_zz, pi_xy, pi_xz, pi_yz, pic_xx, pic_yy, pic_zz, pic_xy, pic_xz, pic_yz;
  double c1=1.0/3.0,c2=1.0/6.0,c3=1.0/24.0;

  rho = p[0];
  v = p[0]-(f0[0]+f1[0]+f3[0]+f8[0]+f10[0]+2*(f2[0]+f4[0]+f5[0]+f13[0]+f14[0]))+0.5*force[1];
  vel = v*fReciprocal(rho);
  v1 = vel;
  v1v1 = v1*v1;
  if(lbsy.nf>1) {
    phi = p[1];
    omegat = 0.5*(1.0+phi)*omega[0]+0.5*(1.0-phi)*omega[1];
    mu = lbfemob*fGetPotentialSwift(phi, nabp);
    d2rdx2 = (lbfeeos>0)?(drdx*drdx):0.0 + dpdx*dpdx;
    d2rdy2 = (lbfeeos>0)?(drdy*drdy):0.0 + dpdy*dpdy;
    d2rdz2 = (lbfeeos>0)?(drdz*drdz):0.0 + dpdz*dpdz;
    d2rdxdy = (lbfeeos>0)?(drdx*drdy):0.0 + dpdx*dpdy;
    d2rdxdz = (lbfeeos>0)?(drdx*drdz):0.0 + dpdx*dpdz;
    d2rdydz = (lbfeeos>0)?(drdy*drdz):0.0 + dpdy*dpdz;
    nabrp = (lbfeeos>0)?(rho*nabr):0.0 + phi*nabp;

    pic_xx = f1[1]+f8[1]+2.0*(f4[1]+f5[1]+f13[1]+f14[1])+phi*c1*v1-mu;
    pic_yy = 2.0*(f2[1]+f4[1]+f5[1]+f13[1]+f14[1])+phi*(v1-v1v1)-mu;
    pic_zz = f3[1]+f10[1]+2.0*(f4[1]+f5[1]+f13[1]+f14[1])+phi*c1*v1-mu;
    pic_xy = 2.0*(f4[1]+f5[1]-f13[1]-f14[1]);
    pic_xz = 2.0*(f4[1]-f5[1]+f13[1]-f14[1]);
    pic_yz = 2.0*(f4[1]-f5[1]-f13[1]+f14[1]);
      
    f0[1] =mu*lbwpt[0] +phi*         (1.0-0.5*lbwi[0]*v1v1)-c1*(pic_xx+   pic_yy+   pic_zz);
    f1[1] =mu*lbwpt[1] +phi*lbwi[1] *(           -0.5*v1v1)+c1* pic_xx-c2*pic_yy-c2*pic_zz;
    f2[1] =mu*lbwpt[2] +phi*lbwi[2] *(-v1            +v1v1)-c2* pic_xx+c1*pic_yy-c2*pic_zz;
    f3[1] =mu*lbwpt[3] +phi*lbwi[3] *(           -0.5*v1v1)-c2* pic_xx-c2*pic_yy+c1*pic_zz;
    f4[1] =mu*lbwpt[4] +phi*lbwi[4] *(-v1            +v1v1)+c3*(pic_xx+   pic_yy+   pic_zz)+0.125*(pic_xy+pic_xz+pic_yz);
    f5[1] =mu*lbwpt[5] +phi*lbwi[5] *(-v1            +v1v1)+c3*(pic_xx+   pic_yy+   pic_zz)+0.125*(pic_xy-pic_xz-pic_yz);
    f6[1] =mu*lbwpt[6] +phi*lbwi[6] *( v1            +v1v1)+c3*(pic_xx+   pic_yy+   pic_zz)-0.125*(pic_xy-pic_xz+pic_yz);
    f7[1] =mu*lbwpt[7] +phi*lbwi[7] *( v1            +v1v1)+c3*(pic_xx+   pic_yy+   pic_zz)-0.125*(pic_xy+pic_xz-pic_yz);
    f8[1] =mu*lbwpt[8] +phi*lbwi[8] *(           -0.5*v1v1)+c1* pic_xx-c2*pic_yy-c2*pic_zz;
    f9[1] =mu*lbwpt[9] +phi*lbwi[9] *( v1            +v1v1)-c2* pic_xx+c1*pic_yy-c2*pic_zz;
    f10[1]=mu*lbwpt[10]+phi*lbwi[10]*(           -0.5*v1v1)-c2* pic_xx-c2*pic_yy+c1*pic_zz;
    f11[1]=mu*lbwpt[11]+phi*lbwi[11]*( v1            +v1v1)+c3*(pic_xx+   pic_yy+   pic_zz)+0.125*(pic_xy+pic_xz+pic_yz);
    f12[1]=mu*lbwpt[12]+phi*lbwi[12]*( v1            +v1v1)+c3*(pic_xx+   pic_yy+   pic_zz)+0.125*(pic_xy-pic_xz-pic_yz);
    f13[1]=mu*lbwpt[13]+phi*lbwi[13]*(-v1            +v1v1)+c3*(pic_xx+   pic_yy+   pic_zz)-0.125*(pic_xy-pic_xz+pic_yz);
    f14[1]=mu*lbwpt[14]+phi*lbwi[14]*(-v1            +v1v1)+c3*(pic_xx+   pic_yy+   pic_zz)-0.125*(pic_xy+pic_xz-pic_yz);
  }
  else {
    phi = 0.0;
    omegat = omega[0];
    d2rdx2 = drdx*drdx;
    d2rdy2 = drdy*drdy;
    d2rdz2 = drdz*drdz;
    d2rdxdy = drdx*drdy;
    d2rdxdz = drdx*drdz;
    d2rdydz = drdy*drdz;
    nabrp = rho*nabr;
  }
  pb = fGetBulkPressureSwift(rho, phi, T);
  lambda = fGetLambdaSwift(rho, omegat, T);
  pi_xx = f1[0]+f8[0]+2.0*(f4[0]+f5[0]+f13[0]+f14[0])+rho*c1*v1-pb+lbkappa*nabrp+lbkappa*(d2rdy2+d2rdz2)-lambda*v1*drdy;
  pi_yy = 2.0*(f2[0]+f4[0]+f5[0]+f13[0]+f14[0])+rho*(v1-v1v1)+v1*force[1]-pb+lbkappa*nabrp+lbkappa*(d2rdx2+d2rdz2)-1.5*lambda*v1*drdy;
  pi_zz = f3[0]+f10[0]+2.0*(f4[0]+f5[0]+f13[0]+f14[0])+rho*c1*v1-pb+lbkappa*nabrp+lbkappa*(d2rdx2+d2rdy2)-lambda*v1*drdy;
  pi_xy = 2.0*(f4[0]+f5[0]-f13[0]-f14[0])+0.5*v1*force[0]-lbkappa*d2rdxdy-lambda*v1*drdx;
  pi_xz = 2.0*(f4[0]-f5[0]+f13[0]-f14[0])-lbkappa*d2rdxdz;
  pi_yz = 2.0*(f4[0]-f5[0]-f13[0]+f14[0])+0.5*v1*force[2]-lbkappa*d2rdydz-lambda*v1*drdz;
    
  f0[0] =rho*(lbw0[0]-0.5*lbwi[0]*v1v1)+ drdy*lbwi[0]*lbwdel[0]*lambda*v1
        +lbwpt[0] *(pb-lbkappa*nabrp)+lbkappa*(lbwxx[0] *d2rdx2+lbwyy[0] *d2rdy2+lbwzz[0] *d2rdz2)
        -c1*(pi_xx+   pi_yy+   pi_zz);
  f1[0] =lbwi [1] *(rho*(    -0.5*v1v1)+ drdy*                  lambda*v1)
        +lbwpt[1] *(pb-lbkappa*nabrp)+lbkappa*(lbwxx[1] *d2rdx2+lbwyy[1] *d2rdy2+lbwzz[1] *d2rdz2)
        +c1* pi_xx-c2*pi_yy-c2*pi_zz;
  f2[0] =lbwi [2] *(rho*(-v1     +v1v1)+ 4.0*drdy*              lambda*v1)
        +lbwpt[2] *(pb-lbkappa*nabrp)+lbkappa*(lbwxx[2] *d2rdx2+lbwyy[2] *d2rdy2+lbwzz[2] *d2rdz2)
        -c2* pi_xx+c1*pi_yy-c2*pi_zz;
  f3[0] =lbwi [3] *(rho*(    -0.5*v1v1)+ drdy*                  lambda*v1)
        +lbwpt[3] *(pb-lbkappa*nabrp)+lbkappa*(lbwxx[3] *d2rdx2+lbwyy[3] *d2rdy2+lbwzz[3] *d2rdz2)
        -c2* pi_xx-c2*pi_yy+c1*pi_zz;
  f4[0] =lbwi [4] *(rho*(-v1     +v1v1)+(drdy+3.0*(drdx+drdz))* lambda*v1)
        +lbwpt[4] *(pb-lbkappa*nabrp)+lbkappa*(lbwxx[4] *d2rdx2+lbwyy[4] *d2rdy2+lbwzz[4] *d2rdz2+lbwxy[4] *d2rdxdy+lbwxz[4] *d2rdxdz+lbwyz[4] *d2rdydz)
        +c3*(pi_xx+   pi_yy+   pi_zz)+0.125*(pi_xy+pi_xz+pi_yz);
  f5[0] =lbwi [5] *(rho*(-v1     +v1v1)+(drdy+3.0*(drdx-drdz))* lambda*v1)
        +lbwpt[5] *(pb-lbkappa*nabrp)+lbkappa*(lbwxx[5] *d2rdx2+lbwyy[5] *d2rdy2+lbwzz[5] *d2rdz2+lbwxy[5] *d2rdxdy+lbwxz[5] *d2rdxdz+lbwyz[5] *d2rdydz)
        +c3*(pi_xx+   pi_yy+   pi_zz)+0.125*(pi_xy-pi_xz-pi_yz);
  f6[0] =lbwi [6] *(rho*( v1     +v1v1)+(drdy-3.0*(drdx+drdz))* lambda*v1)
        +lbwpt[6] *(pb-lbkappa*nabrp)+lbkappa*(lbwxx[6] *d2rdx2+lbwyy[6] *d2rdy2+lbwzz[6] *d2rdz2+lbwxy[6] *d2rdxdy+lbwxz[6] *d2rdxdz+lbwyz[6] *d2rdydz)
        +c3*(pi_xx+   pi_yy+   pi_zz)-0.125*(pi_xy-pi_xz+pi_yz);
  f7[0] =lbwi [7] *(rho*( v1     +v1v1)+(drdy-3.0*(drdx-drdz))* lambda*v1)
        +lbwpt[7] *(pb-lbkappa*nabrp)+lbkappa*(lbwxx[7] *d2rdx2+lbwyy[7] *d2rdy2+lbwzz[7] *d2rdz2+lbwxy[7] *d2rdxdy+lbwxz[7] *d2rdxdz+lbwyz[7] *d2rdydz)
        +c3*(pi_xx+   pi_yy+   pi_zz)-0.125*(pi_xy+pi_xz-pi_yz);
  f8[0] =lbwi [8] *(rho*(    -0.5*v1v1)+ drdy*                  lambda*v1)
        +lbwpt[8] *(pb-lbkappa*nabrp)+lbkappa*(lbwxx[8] *d2rdx2+lbwyy[8] *d2rdy2+lbwzz[8] *d2rdz2)
        +c1* pi_xx-c2*pi_yy-c2*pi_zz;
  f9[0] =lbwi [9] *(rho*( v1     +v1v1)+ 4.0*drdy*              lambda*v1)
        +lbwpt[9] *(pb-lbkappa*nabrp)+lbkappa*(lbwxx[9] *d2rdx2+lbwyy[9] *d2rdy2+lbwzz[9] *d2rdz2)
        -c2* pi_xx+c1*pi_yy-c2*pi_zz;
  f10[0]=lbwi [10]*(rho*(    -0.5*v1v1)+ drdy*                  lambda*v1)
        +lbwpt[10]*(pb-lbkappa*nabrp)+lbkappa*(lbwxx[10]*d2rdx2+lbwyy[10]*d2rdy2+lbwzz[10]*d2rdz2)
        -c2* pi_xx-c2*pi_yy+c1*pi_zz;
  f11[0]=lbwi [11]*(rho*( v1     +v1v1)+(drdy+3.0*(drdx+drdz))* lambda*v1)
        +lbwpt[11]*(pb-lbkappa*nabrp)+lbkappa*(lbwxx[11]*d2rdx2+lbwyy[11]*d2rdy2+lbwzz[11]*d2rdz2+lbwxy[11]*d2rdxdy+lbwxz[11]*d2rdxdz+lbwyz[11]*d2rdydz)
        +c3*(pi_xx+   pi_yy+   pi_zz)+0.125*(pi_xy+pi_xz+pi_yz);
  f12[0]=lbwi [12]*(rho*( v1     +v1v1)+(drdy+3.0*(drdx-drdz))* lambda*v1)
        +lbwpt[12]*(pb-lbkappa*nabrp)+lbkappa*(lbwxx[12]*d2rdx2+lbwyy[12]*d2rdy2+lbwzz[12]*d2rdz2+lbwxy[12]*d2rdxdy+lbwxz[12]*d2rdxdz+lbwyz[12]*d2rdydz)
        +c3*(pi_xx+   pi_yy+   pi_zz)+0.125*(pi_xy-pi_xz-pi_yz);
  f13[0]=lbwi [13]*(rho*(-v1     +v1v1)+(drdy-3.0*(drdx+drdz))* lambda*v1)
        +lbwpt[13]*(pb-lbkappa*nabrp)+lbkappa*(lbwxx[13]*d2rdx2+lbwyy[13]*d2rdy2+lbwzz[13]*d2rdz2+lbwxy[13]*d2rdxdy+lbwxz[13]*d2rdxdz+lbwyz[13]*d2rdydz)
        +c3*(pi_xx+   pi_yy+   pi_zz)-0.125*(pi_xy-pi_xz+pi_yz);
  f14[0]=lbwi [14]*(rho*(-v1     +v1v1)+(drdy-3.0*(drdx-drdz))* lambda*v1)
        +lbwpt[14]*(pb-lbkappa*nabrp)+lbkappa*(lbwxx[14]*d2rdx2+lbwyy[14]*d2rdy2+lbwzz[14]*d2rdz2+lbwxy[14]*d2rdxdy+lbwxz[14]*d2rdxdz+lbwyz[14]*d2rdydz)
        +c3*(pi_xx+   pi_yy+   pi_zz)-0.125*(pi_xy+pi_xz-pi_yz);
  return 0;
}


int fD3Q15PFRegular(long tpos, int prop, double *p0, double *uwall, double T)
{
  double moment;
  double drdx, drdy, drdz, dpdx, dpdy, dpdz, nabr, nabp;
  long spos=tpos * lbsitelength;
  int qdim = lbsy.nf+lbsy.nc+lbsy.nt;
  double force[3*lbsy.nf];
    
  fD3Q15BoundaryForceDensity(force, tpos, p0, prop);
    
  if(interact==20) {
    drdx = lbft[4*lbsy.nf*tpos  ];
    drdy = lbft[4*lbsy.nf*tpos+1];
    drdz = lbft[4*lbsy.nf*tpos+2];
    nabr = lbft[4*lbsy.nf*tpos+3];
    dpdx = (lbsy.nf>1)?lbft[4*lbsy.nf*tpos+4]:0.0;
    dpdy = (lbsy.nf>1)?lbft[4*lbsy.nf*tpos+5]:0.0;
    dpdz = (lbsy.nf>1)?lbft[4*lbsy.nf*tpos+6]:0.0;
    nabp = (lbsy.nf>1)?lbft[4*lbsy.nf*tpos+7]:0.0;
    switch (prop) {
      case PST:
        fD3Q15PPSSwiftRegular(p0, &force[0], &lbf[spos], &lbf[spos+1*qdim],
                              &lbf[spos+2*qdim], &lbf[spos+3*qdim], &lbf[spos+4*qdim], &lbf[spos+5*qdim],
                              &lbf[spos+6*qdim], &lbf[spos+7*qdim], &lbf[spos+8*qdim], &lbf[spos+9*qdim],
                              &lbf[spos+10*qdim], &lbf[spos+11*qdim], &lbf[spos+12*qdim], &lbf[spos+13*qdim],
                              &lbf[spos+14*qdim], drdx, drdy, drdz, dpdx, dpdy, dpdz, nabr, nabp,
                              &lbomega[lbsy.nf*tpos], T, moment);
        uwall[1] += moment;
        break;
      case PSD:
        fD3Q15PPSSwiftRegular(p0, &force[0], &lbf[spos], &lbf[spos+8*qdim],
                              &lbf[spos+9*qdim], &lbf[spos+10*qdim], &lbf[spos+11*qdim], &lbf[spos+12*qdim],
                              &lbf[spos+13*qdim], &lbf[spos+14*qdim], &lbf[spos+1*qdim], &lbf[spos+2*qdim],
                              &lbf[spos+3*qdim], &lbf[spos+4*qdim], &lbf[spos+5*qdim], &lbf[spos+6*qdim],
                              &lbf[spos+7*qdim], -drdx, -drdy, -drdz, -dpdx, -dpdy, -dpdz, nabr, nabp,
                              &lbomega[lbsy.nf*tpos], T, moment);
        uwall[1] -= moment;
        break;
      case PSL:
        fD3Q15PPSSwiftRegular(p0, &force[0], &lbf[spos], &lbf[spos+10*qdim],
                              &lbf[spos+8*qdim], &lbf[spos+9*qdim], &lbf[spos+11*qdim], &lbf[spos+13*qdim],
                              &lbf[spos+7*qdim], &lbf[spos+5*qdim], &lbf[spos+3*qdim], &lbf[spos+1*qdim],
                              &lbf[spos+2*qdim], &lbf[spos+4*qdim], &lbf[spos+6*qdim], &lbf[spos+14*qdim],
                              &lbf[spos+12*qdim], -drdz, -drdx, -drdy, -dpdz, -dpdx, -dpdy, nabr, nabp,
                              &lbomega[lbsy.nf*tpos], T, moment);
        uwall[0] -= moment;
        break;
      case PSR:
        fD3Q15PPSSwiftRegular(p0, &force[0], &lbf[spos], &lbf[spos+3*qdim],
                              &lbf[spos+1*qdim], &lbf[spos+2*qdim], &lbf[spos+4*qdim], &lbf[spos+6*qdim],
                              &lbf[spos+14*qdim], &lbf[spos+12*qdim], &lbf[spos+10*qdim], &lbf[spos+8*qdim],
                              &lbf[spos+9*qdim], &lbf[spos+11*qdim], &lbf[spos+13*qdim], &lbf[spos+7*qdim],
                              &lbf[spos+5*qdim], drdz, drdx, drdy, dpdz, dpdx, dpdy, nabr, nabp,
                              &lbomega[lbsy.nf*tpos], T, moment);
        uwall[1] += moment;
        break;
      case PSF:
        fD3Q15PPSSwiftRegular(p0, &force[0], &lbf[spos], &lbf[spos+9*qdim],
                              &lbf[spos+10*qdim], &lbf[spos+8*qdim], &lbf[spos+11*qdim], &lbf[spos+7*qdim],
                              &lbf[spos+12*qdim], &lbf[spos+6*qdim], &lbf[spos+2*qdim], &lbf[spos+3*qdim],
                              &lbf[spos+1*qdim], &lbf[spos+4*qdim], &lbf[spos+14*qdim], &lbf[spos+5*qdim],
                              &lbf[spos+13*qdim], -drdy, -drdz, -drdx, -dpdy, -dpdz, -dpdx, nabr, nabp,
                              &lbomega[lbsy.nf*tpos], T, moment);
        uwall[2] -= moment;
        break;
      case PSB:
        fD3Q15PPSSwiftRegular(p0, &force[0], &lbf[spos], &lbf[spos+2*qdim],
                              &lbf[spos+3*qdim], &lbf[spos+1*qdim], &lbf[spos+4*qdim], &lbf[spos+14*qdim],
                              &lbf[spos+5*qdim], &lbf[spos+13*qdim], &lbf[spos+9*qdim], &lbf[spos+10*qdim],
                              &lbf[spos+8*qdim], &lbf[spos+11*qdim], &lbf[spos+7*qdim], &lbf[spos+12*qdim],
                              &lbf[spos+6*qdim], drdy, drdz, drdx, dpdy, dpdz, dpdx, nabr, nabp,
                              &lbomega[lbsy.nf*tpos], T, moment);
        uwall[2] += moment;
        break;
      case CCTRB:
        fD3Q15VCCSwiftRegular(p0, uwall[0], uwall[1], -uwall[2], &force[0], &lbf[spos], &lbf[spos+1*qdim],
                              &lbf[spos+2*qdim], &lbf[spos+10*qdim], &lbf[spos+5*qdim], &lbf[spos+4*qdim],
                              &lbf[spos+7*qdim], &lbf[spos+6*qdim], &lbf[spos+8*qdim], &lbf[spos+9*qdim],
                              &lbf[spos+3*qdim], &lbf[spos+12*qdim], &lbf[spos+11*qdim], &lbf[spos+14*qdim],
                              &lbf[spos+13*qdim], drdx, drdy, -drdz, dpdx, dpdy, -dpdz, nabr, nabp,
                              &lbomega[lbsy.nf*tpos], T);
        break;
      case CCTLB:
        fD3Q15VCCSwiftRegular(p0, -uwall[0], uwall[1], -uwall[2], &force[0], &lbf[spos], &lbf[spos+8*qdim],
                              &lbf[spos+2*qdim], &lbf[spos+10*qdim], &lbf[spos+13*qdim], &lbf[spos+14*qdim],
                              &lbf[spos+11*qdim], &lbf[spos+12*qdim], &lbf[spos+1*qdim], &lbf[spos+9*qdim],
                              &lbf[spos+3*qdim], &lbf[spos+6*qdim], &lbf[spos+7*qdim], &lbf[spos+4*qdim],
                              &lbf[spos+5*qdim], -drdx, drdy, -drdz, -dpdx, dpdy, -dpdz, nabr, nabp,
                              &lbomega[lbsy.nf*tpos], T);
        break;
      case CCDLB:
        fD3Q15VCCSwiftRegular(p0, -uwall[0], -uwall[1], -uwall[2], &force[0], &lbf[spos], &lbf[spos+8*qdim],
                              &lbf[spos+9*qdim], &lbf[spos+10*qdim], &lbf[spos+11*qdim], &lbf[spos+12*qdim],
                              &lbf[spos+13*qdim], &lbf[spos+14*qdim], &lbf[spos+1*qdim], &lbf[spos+2*qdim],
                              &lbf[spos+3*qdim], &lbf[spos+4*qdim], &lbf[spos+5*qdim], &lbf[spos+6*qdim],
                              &lbf[spos+7*qdim], -drdx, -drdy, -drdz, -dpdx, -dpdy, -dpdz, nabr, nabp,
                              &lbomega[lbsy.nf*tpos], T);
        break;
      case CCDRB:
        fD3Q15VCCSwiftRegular(p0, uwall[0], -uwall[1], -uwall[2], &force[0], &lbf[spos], &lbf[spos+1*qdim],
                              &lbf[spos+9*qdim], &lbf[spos+10*qdim], &lbf[spos+7*qdim], &lbf[spos+6*qdim],
                              &lbf[spos+5*qdim], &lbf[spos+4*qdim], &lbf[spos+8*qdim], &lbf[spos+2*qdim],
                              &lbf[spos+3*qdim], &lbf[spos+14*qdim], &lbf[spos+13*qdim], &lbf[spos+12*qdim],
                              &lbf[spos+11*qdim], drdx, -drdy, -drdz, dpdx, -dpdy, -dpdz, nabr, nabp,
                              &lbomega[lbsy.nf*tpos], T);
        break;
      case CCTRF:
        fD3Q15VCCSwiftRegular(p0, uwall[0], uwall[1], uwall[2], &force[0], &lbf[spos], &lbf[spos+1*qdim],
                              &lbf[spos+2*qdim], &lbf[spos+3*qdim], &lbf[spos+4*qdim], &lbf[spos+5*qdim],
                              &lbf[spos+6*qdim], &lbf[spos+7*qdim], &lbf[spos+8*qdim], &lbf[spos+9*qdim],
                              &lbf[spos+10*qdim], &lbf[spos+11*qdim], &lbf[spos+12*qdim], &lbf[spos+13*qdim],
                              &lbf[spos+14*qdim], drdx, drdy, drdz, dpdx, dpdy, dpdz, nabr, nabp,
                              &lbomega[lbsy.nf*tpos], T);
        break;
      case CCTLF:
        fD3Q15VCCSwiftRegular(p0, -uwall[0], uwall[1], uwall[2], &force[0], &lbf[spos], &lbf[spos+8*qdim],
                              &lbf[spos+2*qdim], &lbf[spos+3*qdim], &lbf[spos+14*qdim], &lbf[spos+13*qdim],
                              &lbf[spos+12*qdim], &lbf[spos+11*qdim], &lbf[spos+1*qdim], &lbf[spos+9*qdim],
                              &lbf[spos+10*qdim], &lbf[spos+7*qdim], &lbf[spos+6*qdim], &lbf[spos+5*qdim],
                              &lbf[spos+4*qdim], -drdx, drdy, drdz, -dpdx, dpdy, dpdz, nabr, nabp,
                              &lbomega[lbsy.nf*tpos], T);
        break;
      case CCDLF:
        fD3Q15VCCSwiftRegular(p0, -uwall[0], -uwall[1], uwall[2], &force[0], &lbf[spos], &lbf[spos+8*qdim],
                              &lbf[spos+9*qdim], &lbf[spos+3*qdim], &lbf[spos+12*qdim], &lbf[spos+11*qdim],
                              &lbf[spos+14*qdim], &lbf[spos+13*qdim], &lbf[spos+1*qdim], &lbf[spos+2*qdim],
                              &lbf[spos+10*qdim], &lbf[spos+5*qdim], &lbf[spos+4*qdim], &lbf[spos+7*qdim],
                              &lbf[spos+6*qdim], -drdx, -drdy, drdz, -dpdx, -dpdy, dpdz, nabr, nabp,
                              &lbomega[lbsy.nf*tpos], T);
        break;
      case CCDRF:
        fD3Q15VCCSwiftRegular(p0, uwall[0], -uwall[1], uwall[2], &force[0], &lbf[spos], &lbf[spos+1*qdim],
                              &lbf[spos+9*qdim], &lbf[spos+3*qdim], &lbf[spos+6*qdim], &lbf[spos+7*qdim],
                              &lbf[spos+4*qdim], &lbf[spos+5*qdim], &lbf[spos+8*qdim], &lbf[spos+2*qdim],
                              &lbf[spos+10*qdim], &lbf[spos+13*qdim], &lbf[spos+14*qdim], &lbf[spos+11*qdim],
                              &lbf[spos+12*qdim], drdx, -drdy, drdz, dpdx, -dpdy, dpdz, nabr, nabp,
                              &lbomega[lbsy.nf*tpos], T);
        break;
      case CETR:
        fD3Q15VCESwiftRegular(p0, uwall[0], uwall[1], uwall[2], &force[0], &lbf[spos], &lbf[spos+1*qdim],
                              &lbf[spos+2*qdim], &lbf[spos+3*qdim], &lbf[spos+4*qdim], &lbf[spos+5*qdim],
                              &lbf[spos+6*qdim], &lbf[spos+7*qdim], &lbf[spos+8*qdim], &lbf[spos+9*qdim],
                              &lbf[spos+10*qdim], &lbf[spos+11*qdim], &lbf[spos+12*qdim], &lbf[spos+13*qdim],
                              &lbf[spos+14*qdim], drdx, drdy, drdz, dpdx, dpdy, dpdz, nabr, nabp,
                              &lbomega[lbsy.nf*tpos], T);
        break;
      case CETL:
        fD3Q15VCESwiftRegular(p0, uwall[1], -uwall[0], uwall[2], &force[0], &lbf[spos], &lbf[spos+2*qdim],
                              &lbf[spos+8*qdim], &lbf[spos+3*qdim], &lbf[spos+14*qdim], &lbf[spos+13*qdim],
                              &lbf[spos+4*qdim], &lbf[spos+5*qdim], &lbf[spos+9*qdim], &lbf[spos+1*qdim],
                              &lbf[spos+10*qdim], &lbf[spos+7*qdim], &lbf[spos+6*qdim], &lbf[spos+11*qdim],
                              &lbf[spos+12*qdim], drdy, -drdx, drdz, dpdy, -dpdx, dpdz, nabr, nabp,
                              &lbomega[lbsy.nf*tpos], T);
        break;
      case CEDL:
        fD3Q15VCESwiftRegular(p0, -uwall[0], -uwall[1], uwall[2], &force[0], &lbf[spos], &lbf[spos+8*qdim],
                              &lbf[spos+9*qdim], &lbf[spos+3*qdim], &lbf[spos+12*qdim], &lbf[spos+11*qdim],
                              &lbf[spos+14*qdim], &lbf[spos+13*qdim], &lbf[spos+1*qdim], &lbf[spos+2*qdim],
                              &lbf[spos+10*qdim], &lbf[spos+5*qdim], &lbf[spos+4*qdim], &lbf[spos+7*qdim],
                              &lbf[spos+6*qdim], -drdx, -drdy, drdz, -dpdx, -dpdy, dpdz, nabr, nabp,
                              &lbomega[lbsy.nf*tpos], T);
        break;
      case CEDR:
        fD3Q15VCESwiftRegular(p0, -uwall[1], uwall[0], uwall[2], &force[0], &lbf[spos], &lbf[spos+9*qdim],
                              &lbf[spos+1*qdim], &lbf[spos+3*qdim], &lbf[spos+6*qdim], &lbf[spos+7*qdim],
                              &lbf[spos+12*qdim], &lbf[spos+11*qdim], &lbf[spos+2*qdim], &lbf[spos+8*qdim],
                              &lbf[spos+10*qdim], &lbf[spos+13*qdim], &lbf[spos+14*qdim], &lbf[spos+5*qdim],
                              &lbf[spos+4*qdim], -drdy, drdx, drdz, -dpdy, dpdx, dpdz, nabr, nabp,
                              &lbomega[lbsy.nf*tpos], T);
        break;
      case CETF:
        fD3Q15VCESwiftRegular(p0, uwall[1], uwall[2], uwall[0], &force[0], &lbf[spos], &lbf[spos+2*qdim],
                              &lbf[spos+3*qdim], &lbf[spos+1*qdim], &lbf[spos+4*qdim], &lbf[spos+14*qdim],
                              &lbf[spos+5*qdim], &lbf[spos+13*qdim], &lbf[spos+9*qdim], &lbf[spos+10*qdim],
                              &lbf[spos+8*qdim], &lbf[spos+11*qdim], &lbf[spos+7*qdim], &lbf[spos+12*qdim],
                              &lbf[spos+6*qdim], drdy, drdz, drdx, dpdy, dpdz, dpdx, nabr, nabp,
                              &lbomega[lbsy.nf*tpos], T);
        break;
      case CELF:
        fD3Q15VCESwiftRegular(p0, -uwall[0], uwall[2], uwall[1], &force[0], &lbf[spos], &lbf[spos+8*qdim],
                              &lbf[spos+3*qdim], &lbf[spos+2*qdim], &lbf[spos+14*qdim], &lbf[spos+12*qdim],
                              &lbf[spos+13*qdim], &lbf[spos+11*qdim], &lbf[spos+1*qdim], &lbf[spos+10*qdim],
                              &lbf[spos+9*qdim], &lbf[spos+7*qdim], &lbf[spos+5*qdim], &lbf[spos+6*qdim],
                              &lbf[spos+4*qdim], -drdx, drdz, drdy, -dpdx, dpdz, dpdy, nabr, nabp,
                              &lbomega[lbsy.nf*tpos], T);
        break;
      case CEDF:
        fD3Q15VCESwiftRegular(p0, -uwall[1], uwall[2], uwall[0], &force[0], &lbf[spos], &lbf[spos+9*qdim],
                              &lbf[spos+3*qdim], &lbf[spos+1*qdim], &lbf[spos+6*qdim], &lbf[spos+12*qdim],
                              &lbf[spos+7*qdim], &lbf[spos+11*qdim], &lbf[spos+2*qdim], &lbf[spos+10*qdim],
                              &lbf[spos+8*qdim], &lbf[spos+13*qdim], &lbf[spos+5*qdim], &lbf[spos+14*qdim],
                              &lbf[spos+4*qdim], -drdy, drdz, drdx, -dpdy, dpdz, dpdx, nabr, nabp,
                              &lbomega[lbsy.nf*tpos], T);
        break;
      case CERF:
        fD3Q15VCESwiftRegular(p0, uwall[0], uwall[2], uwall[1], &force[0], &lbf[spos], &lbf[spos+1*qdim],
                              &lbf[spos+3*qdim], &lbf[spos+2*qdim], &lbf[spos+4*qdim], &lbf[spos+6*qdim],
                              &lbf[spos+5*qdim], &lbf[spos+7*qdim], &lbf[spos+8*qdim], &lbf[spos+10*qdim],
                              &lbf[spos+9*qdim], &lbf[spos+11*qdim], &lbf[spos+13*qdim], &lbf[spos+12*qdim],
                              &lbf[spos+14*qdim], drdx, drdz, drdy, dpdx, dpdz, dpdy, nabr, nabp,
                              &lbomega[lbsy.nf*tpos], T);
        break;
      case CETB:
        fD3Q15VCESwiftRegular(p0, uwall[1], -uwall[2], uwall[0], &force[0], &lbf[spos], &lbf[spos+2*qdim],
                              &lbf[spos+10*qdim], &lbf[spos+1*qdim], &lbf[spos+5*qdim], &lbf[spos+13*qdim],
                              &lbf[spos+4*qdim], &lbf[spos+14*qdim], &lbf[spos+9*qdim], &lbf[spos+3*qdim],
                              &lbf[spos+8*qdim], &lbf[spos+12*qdim], &lbf[spos+6*qdim], &lbf[spos+11*qdim],
                              &lbf[spos+7*qdim], drdy, -drdz, drdx, dpdy, -dpdz, dpdx, nabr, nabp,
                              &lbomega[lbsy.nf*tpos], T);
        break;
      case CELB:
        fD3Q15VCESwiftRegular(p0, -uwall[0], -uwall[2], uwall[1], &force[0], &lbf[spos], &lbf[spos+8*qdim],
                              &lbf[spos+10*qdim], &lbf[spos+2*qdim], &lbf[spos+13*qdim], &lbf[spos+11*qdim],
                              &lbf[spos+14*qdim], &lbf[spos+12*qdim], &lbf[spos+1*qdim], &lbf[spos+3*qdim],
                              &lbf[spos+9*qdim], &lbf[spos+6*qdim], &lbf[spos+4*qdim], &lbf[spos+7*qdim],
                              &lbf[spos+5*qdim], -drdx, -drdz, drdy, -dpdx, -dpdz, dpdy, nabr, nabp,
                              &lbomega[lbsy.nf*tpos], T);
        break;
      case CEDB:
        fD3Q15VCESwiftRegular(p0, -uwall[1], -uwall[2], uwall[0], &force[0], &lbf[spos], &lbf[spos+9*qdim],
                              &lbf[spos+10*qdim], &lbf[spos+1*qdim], &lbf[spos+7*qdim], &lbf[spos+11*qdim],
                              &lbf[spos+6*qdim], &lbf[spos+12*qdim], &lbf[spos+2*qdim], &lbf[spos+3*qdim],
                              &lbf[spos+8*qdim], &lbf[spos+14*qdim], &lbf[spos+4*qdim], &lbf[spos+13*qdim],
                              &lbf[spos+5*qdim], -drdy, -drdz, drdx, -dpdy, -dpdz, dpdx, nabr, nabp,
                              &lbomega[lbsy.nf*tpos], T);
        break;
      case CERB:
        fD3Q15VCESwiftRegular(p0, uwall[0], -uwall[2], uwall[1], &force[0], &lbf[spos], &lbf[spos+1*qdim],
                              &lbf[spos+10*qdim], &lbf[spos+2*qdim], &lbf[spos+5*qdim], &lbf[spos+7*qdim],
                              &lbf[spos+4*qdim], &lbf[spos+6*qdim], &lbf[spos+8*qdim], &lbf[spos+3*qdim],
                              &lbf[spos+9*qdim], &lbf[spos+12*qdim], &lbf[spos+14*qdim], &lbf[spos+11*qdim],
                              &lbf[spos+13*qdim], drdx, -drdz, drdy, dpdx, -dpdz, dpdy, nabr, nabp,
                              &lbomega[lbsy.nf*tpos], T);
        break;
    }
  }
  else {
    switch (prop) {
      case PST:
        fD3Q15PPSRegular(p0, &force[0], &lbf[spos], &lbf[spos+1*qdim],
                         &lbf[spos+2*qdim], &lbf[spos+3*qdim], &lbf[spos+4*qdim], &lbf[spos+5*qdim],
                         &lbf[spos+6*qdim], &lbf[spos+7*qdim], &lbf[spos+8*qdim], &lbf[spos+9*qdim],
                         &lbf[spos+10*qdim], &lbf[spos+11*qdim], &lbf[spos+12*qdim], &lbf[spos+13*qdim],
                         &lbf[spos+14*qdim], moment);
        uwall[1] += moment;
        break;
      case PSD:
        fD3Q15PPSRegular(p0, &force[0], &lbf[spos], &lbf[spos+8*qdim],
                         &lbf[spos+9*qdim], &lbf[spos+10*qdim], &lbf[spos+11*qdim], &lbf[spos+12*qdim],
                         &lbf[spos+13*qdim], &lbf[spos+14*qdim], &lbf[spos+1*qdim], &lbf[spos+2*qdim],
                         &lbf[spos+3*qdim], &lbf[spos+4*qdim], &lbf[spos+5*qdim], &lbf[spos+6*qdim],
                         &lbf[spos+7*qdim], moment);
        uwall[1] -= moment;
        break;
      case PSL:
        fD3Q15PPSRegular(p0, &force[0], &lbf[spos], &lbf[spos+10*qdim],
                         &lbf[spos+8*qdim], &lbf[spos+9*qdim], &lbf[spos+11*qdim], &lbf[spos+13*qdim],
                         &lbf[spos+7*qdim], &lbf[spos+5*qdim], &lbf[spos+3*qdim], &lbf[spos+1*qdim],
                         &lbf[spos+2*qdim], &lbf[spos+4*qdim], &lbf[spos+6*qdim], &lbf[spos+14*qdim],
                         &lbf[spos+12*qdim], moment);
        uwall[0] -= moment;
        break;
      case PSR:
        fD3Q15PPSRegular(p0, &force[0], &lbf[spos], &lbf[spos+3*qdim],
                         &lbf[spos+1*qdim], &lbf[spos+2*qdim], &lbf[spos+4*qdim], &lbf[spos+6*qdim],
                         &lbf[spos+14*qdim], &lbf[spos+12*qdim], &lbf[spos+10*qdim], &lbf[spos+8*qdim],
                         &lbf[spos+9*qdim], &lbf[spos+11*qdim], &lbf[spos+13*qdim], &lbf[spos+7*qdim],
                         &lbf[spos+5*qdim], moment);
        uwall[1] += moment;
        break;
      case PSF:
        fD3Q15PPSRegular(p0, &force[0], &lbf[spos], &lbf[spos+9*qdim],
                         &lbf[spos+10*qdim], &lbf[spos+8*qdim], &lbf[spos+11*qdim], &lbf[spos+7*qdim],
                         &lbf[spos+12*qdim], &lbf[spos+6*qdim], &lbf[spos+2*qdim], &lbf[spos+3*qdim],
                         &lbf[spos+1*qdim], &lbf[spos+4*qdim], &lbf[spos+14*qdim], &lbf[spos+5*qdim],
                         &lbf[spos+13*qdim], moment);
        uwall[2] -= moment;
        break;
      case PSB:
        fD3Q15PPSRegular(p0, &force[0], &lbf[spos], &lbf[spos+2*qdim],
                         &lbf[spos+3*qdim], &lbf[spos+1*qdim], &lbf[spos+4*qdim], &lbf[spos+14*qdim],
                         &lbf[spos+5*qdim], &lbf[spos+13*qdim], &lbf[spos+9*qdim], &lbf[spos+10*qdim],
                         &lbf[spos+8*qdim], &lbf[spos+11*qdim], &lbf[spos+7*qdim], &lbf[spos+12*qdim],
                         &lbf[spos+6*qdim], moment);
        uwall[2] += moment;
        break;
      case CCTRB:
        fD3Q15VCCRegular(p0, uwall[0], uwall[1], -uwall[2], &force[0], &lbf[spos], &lbf[spos+1*qdim],
                         &lbf[spos+2*qdim], &lbf[spos+10*qdim], &lbf[spos+5*qdim], &lbf[spos+4*qdim],
                         &lbf[spos+7*qdim], &lbf[spos+6*qdim], &lbf[spos+8*qdim], &lbf[spos+9*qdim],
                         &lbf[spos+3*qdim], &lbf[spos+12*qdim], &lbf[spos+11*qdim], &lbf[spos+14*qdim],
                         &lbf[spos+13*qdim]);
        break;
      case CCTLB:
        fD3Q15VCCRegular(p0, -uwall[0], uwall[1], -uwall[2], &force[0], &lbf[spos], &lbf[spos+8*qdim],
                         &lbf[spos+2*qdim], &lbf[spos+10*qdim], &lbf[spos+13*qdim], &lbf[spos+14*qdim],
                         &lbf[spos+11*qdim], &lbf[spos+12*qdim], &lbf[spos+1*qdim], &lbf[spos+9*qdim],
                         &lbf[spos+3*qdim], &lbf[spos+6*qdim], &lbf[spos+7*qdim], &lbf[spos+4*qdim],
                         &lbf[spos+5*qdim]);
        break;
      case CCDLB:
        fD3Q15VCCRegular(p0, -uwall[0], -uwall[1], -uwall[2], &force[0], &lbf[spos], &lbf[spos+8*qdim],
                         &lbf[spos+9*qdim], &lbf[spos+10*qdim], &lbf[spos+11*qdim], &lbf[spos+12*qdim],
                         &lbf[spos+13*qdim], &lbf[spos+14*qdim], &lbf[spos+1*qdim], &lbf[spos+2*qdim],
                         &lbf[spos+3*qdim], &lbf[spos+4*qdim], &lbf[spos+5*qdim], &lbf[spos+6*qdim],
                         &lbf[spos+7*qdim]);
        break;
      case CCDRB:
        fD3Q15VCCRegular(p0, uwall[0], -uwall[1], -uwall[2], &force[0], &lbf[spos], &lbf[spos+1*qdim],
                         &lbf[spos+9*qdim], &lbf[spos+10*qdim], &lbf[spos+7*qdim], &lbf[spos+6*qdim],
                         &lbf[spos+5*qdim], &lbf[spos+4*qdim], &lbf[spos+8*qdim], &lbf[spos+2*qdim],
                         &lbf[spos+3*qdim], &lbf[spos+14*qdim], &lbf[spos+13*qdim], &lbf[spos+12*qdim],
                         &lbf[spos+11*qdim]);
        break;
      case CCTRF:
        fD3Q15VCCRegular(p0, uwall[0], uwall[1], uwall[2], &force[0], &lbf[spos], &lbf[spos+1*qdim],
                         &lbf[spos+2*qdim], &lbf[spos+3*qdim], &lbf[spos+4*qdim], &lbf[spos+5*qdim],
                         &lbf[spos+6*qdim], &lbf[spos+7*qdim], &lbf[spos+8*qdim], &lbf[spos+9*qdim],
                         &lbf[spos+10*qdim], &lbf[spos+11*qdim], &lbf[spos+12*qdim], &lbf[spos+13*qdim],
                         &lbf[spos+14*qdim]);
        break;
      case CCTLF:
        fD3Q15VCCRegular(p0, -uwall[0], uwall[1], uwall[2], &force[0], &lbf[spos], &lbf[spos+8*qdim],
                         &lbf[spos+2*qdim], &lbf[spos+3*qdim], &lbf[spos+14*qdim], &lbf[spos+13*qdim],
                         &lbf[spos+12*qdim], &lbf[spos+11*qdim], &lbf[spos+1*qdim], &lbf[spos+9*qdim],
                         &lbf[spos+10*qdim], &lbf[spos+7*qdim], &lbf[spos+6*qdim], &lbf[spos+5*qdim],
                         &lbf[spos+4*qdim]);
        break;
      case CCDLF:
        fD3Q15VCCRegular(p0, -uwall[0], -uwall[1], uwall[2], &force[0], &lbf[spos], &lbf[spos+8*qdim],
                         &lbf[spos+9*qdim], &lbf[spos+3*qdim], &lbf[spos+12*qdim], &lbf[spos+11*qdim],
                         &lbf[spos+14*qdim], &lbf[spos+13*qdim], &lbf[spos+1*qdim], &lbf[spos+2*qdim],
                         &lbf[spos+10*qdim], &lbf[spos+5*qdim], &lbf[spos+4*qdim], &lbf[spos+7*qdim],
                         &lbf[spos+6*qdim]);
        break;
      case CCDRF:
        fD3Q15VCCRegular(p0, uwall[0], -uwall[1], uwall[2], &force[0], &lbf[spos], &lbf[spos+1*qdim],
                         &lbf[spos+9*qdim], &lbf[spos+3*qdim], &lbf[spos+6*qdim], &lbf[spos+7*qdim],
                         &lbf[spos+4*qdim], &lbf[spos+5*qdim], &lbf[spos+8*qdim], &lbf[spos+2*qdim],
                         &lbf[spos+10*qdim], &lbf[spos+13*qdim], &lbf[spos+14*qdim], &lbf[spos+11*qdim],
                         &lbf[spos+12*qdim]);
        break;
      case CETR:
        fD3Q15VCERegular(p0, uwall[0], uwall[1], uwall[2], &force[0], &lbf[spos], &lbf[spos+1*qdim],
                         &lbf[spos+2*qdim], &lbf[spos+3*qdim], &lbf[spos+4*qdim], &lbf[spos+5*qdim],
                         &lbf[spos+6*qdim], &lbf[spos+7*qdim], &lbf[spos+8*qdim], &lbf[spos+9*qdim],
                         &lbf[spos+10*qdim], &lbf[spos+11*qdim], &lbf[spos+12*qdim], &lbf[spos+13*qdim],
                         &lbf[spos+14*qdim]);
        break;
      case CETL:
        fD3Q15VCERegular(p0, uwall[1], -uwall[0], uwall[2], &force[0], &lbf[spos], &lbf[spos+2*qdim],
                         &lbf[spos+8*qdim], &lbf[spos+3*qdim], &lbf[spos+14*qdim], &lbf[spos+13*qdim],
                         &lbf[spos+4*qdim], &lbf[spos+5*qdim], &lbf[spos+9*qdim], &lbf[spos+1*qdim],
                         &lbf[spos+10*qdim], &lbf[spos+7*qdim], &lbf[spos+6*qdim], &lbf[spos+11*qdim],
                         &lbf[spos+12*qdim]);
        break;
      case CEDL:
        fD3Q15VCERegular(p0, -uwall[0], -uwall[1], uwall[2], &force[0], &lbf[spos], &lbf[spos+8*qdim],
                         &lbf[spos+9*qdim], &lbf[spos+3*qdim], &lbf[spos+12*qdim], &lbf[spos+11*qdim],
                         &lbf[spos+14*qdim], &lbf[spos+13*qdim], &lbf[spos+1*qdim], &lbf[spos+2*qdim],
                         &lbf[spos+10*qdim], &lbf[spos+5*qdim], &lbf[spos+4*qdim], &lbf[spos+7*qdim],
                         &lbf[spos+6*qdim]);
        break;
      case CEDR:
        fD3Q15VCERegular(p0, -uwall[1], uwall[0], uwall[2], &force[0], &lbf[spos], &lbf[spos+9*qdim],
                         &lbf[spos+1*qdim], &lbf[spos+3*qdim], &lbf[spos+6*qdim], &lbf[spos+7*qdim],
                         &lbf[spos+12*qdim], &lbf[spos+11*qdim], &lbf[spos+2*qdim], &lbf[spos+8*qdim],
                         &lbf[spos+10*qdim], &lbf[spos+13*qdim], &lbf[spos+14*qdim], &lbf[spos+5*qdim],
                         &lbf[spos+4*qdim]);
        break;
      case CETF:
        fD3Q15VCERegular(p0, uwall[1], uwall[2], uwall[0], &force[0], &lbf[spos], &lbf[spos+2*qdim],
                         &lbf[spos+3*qdim], &lbf[spos+1*qdim], &lbf[spos+4*qdim], &lbf[spos+14*qdim],
                         &lbf[spos+5*qdim], &lbf[spos+13*qdim], &lbf[spos+9*qdim], &lbf[spos+10*qdim],
                         &lbf[spos+8*qdim], &lbf[spos+11*qdim], &lbf[spos+7*qdim], &lbf[spos+12*qdim],
                         &lbf[spos+6*qdim]);
        break;
      case CELF:
        fD3Q15VCERegular(p0, -uwall[0], uwall[2], uwall[1], &force[0], &lbf[spos], &lbf[spos+8*qdim],
                         &lbf[spos+3*qdim], &lbf[spos+2*qdim], &lbf[spos+14*qdim], &lbf[spos+12*qdim],
                         &lbf[spos+13*qdim], &lbf[spos+11*qdim], &lbf[spos+1*qdim], &lbf[spos+10*qdim],
                         &lbf[spos+9*qdim], &lbf[spos+7*qdim], &lbf[spos+5*qdim], &lbf[spos+6*qdim],
                         &lbf[spos+4*qdim]);
        break;
      case CEDF:
        fD3Q15VCERegular(p0, -uwall[1], uwall[2], uwall[0], &force[0], &lbf[spos], &lbf[spos+9*qdim],
                         &lbf[spos+3*qdim], &lbf[spos+1*qdim], &lbf[spos+6*qdim], &lbf[spos+12*qdim],
                         &lbf[spos+7*qdim], &lbf[spos+11*qdim], &lbf[spos+2*qdim], &lbf[spos+10*qdim],
                         &lbf[spos+8*qdim], &lbf[spos+13*qdim], &lbf[spos+5*qdim], &lbf[spos+14*qdim],
                         &lbf[spos+4*qdim]);
        break;
      case CERF:
        fD3Q15VCERegular(p0, uwall[0], uwall[2], uwall[1], &force[0], &lbf[spos], &lbf[spos+1*qdim],
                         &lbf[spos+3*qdim], &lbf[spos+2*qdim], &lbf[spos+4*qdim], &lbf[spos+6*qdim],
                         &lbf[spos+5*qdim], &lbf[spos+7*qdim], &lbf[spos+8*qdim], &lbf[spos+10*qdim],
                         &lbf[spos+9*qdim], &lbf[spos+11*qdim], &lbf[spos+13*qdim], &lbf[spos+12*qdim],
                         &lbf[spos+14*qdim]);
        break;
      case CETB:
        fD3Q15VCERegular(p0, uwall[1], -uwall[2], uwall[0], &force[0], &lbf[spos], &lbf[spos+2*qdim],
                         &lbf[spos+10*qdim], &lbf[spos+1*qdim], &lbf[spos+5*qdim], &lbf[spos+13*qdim],
                         &lbf[spos+4*qdim], &lbf[spos+14*qdim], &lbf[spos+9*qdim], &lbf[spos+3*qdim],
                         &lbf[spos+8*qdim], &lbf[spos+12*qdim], &lbf[spos+6*qdim], &lbf[spos+11*qdim],
                         &lbf[spos+7*qdim]);
        break;
      case CELB:
        fD3Q15VCERegular(p0, -uwall[0], -uwall[2], uwall[1], &force[0], &lbf[spos], &lbf[spos+8*qdim],
                         &lbf[spos+10*qdim], &lbf[spos+2*qdim], &lbf[spos+13*qdim], &lbf[spos+11*qdim],
                         &lbf[spos+14*qdim], &lbf[spos+12*qdim], &lbf[spos+1*qdim], &lbf[spos+3*qdim],
                         &lbf[spos+9*qdim], &lbf[spos+6*qdim], &lbf[spos+4*qdim], &lbf[spos+7*qdim],
                         &lbf[spos+5*qdim]);
        break;
      case CEDB:
        fD3Q15VCERegular(p0, -uwall[1], -uwall[2], uwall[0], &force[0], &lbf[spos], &lbf[spos+9*qdim],
                         &lbf[spos+10*qdim], &lbf[spos+1*qdim], &lbf[spos+7*qdim], &lbf[spos+11*qdim],
                         &lbf[spos+6*qdim], &lbf[spos+12*qdim], &lbf[spos+2*qdim], &lbf[spos+3*qdim],
                         &lbf[spos+8*qdim], &lbf[spos+14*qdim], &lbf[spos+4*qdim], &lbf[spos+13*qdim],
                         &lbf[spos+5*qdim]);
        break;
      case CERB:
        fD3Q15VCERegular(p0, uwall[0], -uwall[2], uwall[1], &force[0], &lbf[spos], &lbf[spos+1*qdim],
                         &lbf[spos+10*qdim], &lbf[spos+2*qdim], &lbf[spos+5*qdim], &lbf[spos+7*qdim],
                         &lbf[spos+4*qdim], &lbf[spos+6*qdim], &lbf[spos+8*qdim], &lbf[spos+3*qdim],
                         &lbf[spos+9*qdim], &lbf[spos+12*qdim], &lbf[spos+14*qdim], &lbf[spos+11*qdim],
                         &lbf[spos+13*qdim]);
        break;
    }
  }
  return 0;
}


// D3Q19

int fD3Q19VPSRegular(double v0, double v1, double v2, double *force,
                     double *f0, double *f1, double *f2, double *f3, double *f4,
                     double *f5, double *f6, double *f7, double *f8, double *f9,
                     double *f10, double *f11, double *f12, double *f13, double *f14,
                     double *f15, double *f16, double *f17, double *f18)
{

  // produce fixed velocity for compressible/incompressible fluids at planar surface boundary:
  // expressed for bottom wall (VPST)
  double rho, rho0, modv, pi_xx, pi_yy, pi_zz, pi_xy, pi_xz, pi_yz, v0v0, v0v1, v0v2, v1v1, v1v2, v2v2;
  double c1=1.0/3.0,c2=1.0/6.0,c3=1.0/12.0,c4=1.0/24.0;

  v0v0 = v0*v0;
  v0v1 = v0*v1;
  v0v2 = v0*v2;
  v1v1 = v1*v1;
  v1v2 = v1*v2;
  v2v2 = v2*v2;
  modv = v0v0+v1v1+v2v2;
    
  if(!incompress) {
    for(int i=0; i<lbsy.nf; i++) {
      rho = (f0[i]+f1[i]+f3[i]+f6[i]+f7[i]+f10[i]+f12[i]+f15[i]+f16[i]+2.0*(f2[i]+f4[i]+f8[i]+f9[i]+f14[i])-0.5*force[3*i+1])/(1.0-v1);
      pi_xx = f1[i]+f6[i]+f7[i]+f10[i]+f15[i]+f16[i]+2.0*(f4[i]+f14[i])+rho*(c1*(v1-1.0)-v0v0)+v0*force[3*i  ];
      pi_yy = 2.0*(f2[i]+f4[i]+f8[i]+f9[i]+f14[i])+rho*(v1-v1v1-c1)+v1*force[3*i+1];
      pi_zz = f3[i]+f6[i]+f7[i]+f12[i]+f15[i]+f16[i]+2.0*(f8[i]+f9[i])+rho*(c1*(v1-1.0)-v2v2)+v2*force[3*i+2];
      pi_xy = 2.0*(f4[i]-f14[i])+rho*(c1*v0-v0v1)+0.5*(v1*force[3*i  ]+v0*force[3*i+1]);
      pi_xz = f6[i]-f7[i]+f15[i]-f16[i]-rho*v0v2+0.5*(v2*force[3*i  ]+v0*force[3*i+2]);
      pi_yz = 2.0*(f8[i]-f9[i])+rho*(c1*v2-v1v2)+0.5*(v2*force[3*i+1]+v1*force[3*i+2]);
      f0[i] =rho*lbw[0] *(1.0                              -1.5*modv)-0.5*(pi_xx+   pi_yy+   pi_zz);
      f1[i] =rho*lbw[1] *(1.0-3.0*v0              +4.5*v0v0-1.5*modv)+ c2* pi_xx-c3*pi_yy-c3*pi_zz;
      f2[i] =rho*lbw[2] *(1.0-3.0*v1              +4.5*v1v1-1.5*modv)- c3* pi_xx+c2*pi_yy-c3*pi_zz;
      f3[i] =rho*lbw[3] *(1.0-3.0*v2              +4.5*v2v2-1.5*modv)- c3* pi_xx-c3*pi_yy+c2*pi_zz;
      f4[i] =rho*lbw[4] *(1.0-3.0*(v0+v1)+9.0*v0v1-4.5*v2v2+3.0*modv)+ c3* pi_xx+c3*pi_yy-c4*pi_zz+0.25*pi_xy;
      f5[i] =rho*lbw[5] *(1.0-3.0*(v0-v1)-9.0*v0v1-4.5*v2v2+3.0*modv)+ c3* pi_xx+c3*pi_yy-c4*pi_zz-0.25*pi_xy;
      f6[i] =rho*lbw[6] *(1.0-3.0*(v0+v2)+9.0*v0v2-4.5*v1v1+3.0*modv)+ c3* pi_xx-c4*pi_yy+c3*pi_zz+0.25*pi_xz;
      f7[i] =rho*lbw[7] *(1.0-3.0*(v0-v2)-9.0*v0v2-4.5*v1v1+3.0*modv)+ c3* pi_xx-c4*pi_yy+c3*pi_zz-0.25*pi_xz;
      f8[i] =rho*lbw[8] *(1.0-3.0*(v1+v2)+9.0*v1v2-4.5*v0v0+3.0*modv)- c4* pi_xx+c3*pi_yy+c3*pi_zz+0.25*pi_yz;
      f9[i] =rho*lbw[9] *(1.0-3.0*(v1-v2)-9.0*v1v2-4.5*v0v0+3.0*modv)- c4* pi_xx+c3*pi_yy+c3*pi_zz-0.25*pi_yz;
      f10[i]=rho*lbw[10]*(1.0+3.0*v0              +4.5*v0v0-1.5*modv)+ c2* pi_xx-c3*pi_yy-c3*pi_zz;
      f11[i]=rho*lbw[11]*(1.0+3.0*v1              +4.5*v1v1-1.5*modv)- c3* pi_xx+c2*pi_yy-c3*pi_zz;
      f12[i]=rho*lbw[12]*(1.0+3.0*v2              +4.5*v2v2-1.5*modv)- c3* pi_xx-c3*pi_yy+c2*pi_zz;
      f13[i]=rho*lbw[13]*(1.0+3.0*(v0+v1)+9.0*v0v1-4.5*v2v2+3.0*modv)+ c3* pi_xx+c3*pi_yy-c4*pi_zz+0.25*pi_xy;
      f14[i]=rho*lbw[14]*(1.0+3.0*(v0-v1)-9.0*v0v1-4.5*v2v2+3.0*modv)+ c3* pi_xx+c3*pi_yy-c4*pi_zz-0.25*pi_xy;
      f15[i]=rho*lbw[15]*(1.0+3.0*(v0+v2)+9.0*v0v2-4.5*v1v1+3.0*modv)+ c3* pi_xx-c4*pi_yy+c3*pi_zz+0.25*pi_xz;
      f16[i]=rho*lbw[16]*(1.0+3.0*(v0-v2)-9.0*v0v2-4.5*v1v1+3.0*modv)+ c3* pi_xx-c4*pi_yy+c3*pi_zz-0.25*pi_xz;
      f17[i]=rho*lbw[17]*(1.0+3.0*(v1+v2)+9.0*v1v2-4.5*v0v0+3.0*modv)- c4* pi_xx+c3*pi_yy+c3*pi_zz+0.25*pi_yz;
      f18[i]=rho*lbw[18]*(1.0+3.0*(v1-v2)-9.0*v1v2-4.5*v0v0+3.0*modv)- c4* pi_xx+c3*pi_yy+c3*pi_zz-0.25*pi_yz;
    }
  }
  else {
    for(int i=0; i<lbsy.nf; i++) {
      rho0 = lbincp[i];
      rho = f0[i]+f1[i]+f3[i]+f6[i]+f7[i]+f10[i]+f12[i]+f15[i]+f16[i]+2.0*(f2[i]+f4[i]+f8[i]+f9[i]+f14[i])+rho0*v1-0.5*force[3*i+1];
      pi_xx = f1[i]+f6[i]+f7[i]+f10[i]+f15[i]+f16[i]+2.0*(f4[i]+f14[i])+rho0*(c1*v1-v0v0)-c1*rho+v0*force[3*i  ];
      pi_yy = 2.0*(f2[i]+f4[i]+f8[i]+f9[i]+f14[i])+rho0*(v1-v1v1)-c1*rho+v1*force[3*i+1];
      pi_zz = f3[i]+f6[i]+f7[i]+f12[i]+f15[i]+f16[i]+2.0*(f8[i]+f9[i])+rho0*(c1*v1-v2v2)-c1*rho+v2*force[3*i+2];
      pi_xy = 2.0*(f4[i]-f14[i])+rho0*(c1*v0-v0v1)+0.5*(v1*force[3*i  ]+v0*force[3*i+1]);
      pi_xz = f6[i]-f7[i]+f15[i]-f16[i]-rho0*v0v2+0.5*(v2*force[3*i  ]+v0*force[3*i+2]);
      pi_yz = 2.0*(f8[i]-f9[i])+rho0*(c1*v2-v1v2)+0.5*(v2*force[3*i+1]+v1*force[3*i+2]);
      f0[i] =lbw[0] *(rho+rho0*(                              -1.5*modv))-0.5*(pi_xx+   pi_yy+   pi_zz);
      f1[i] =lbw[1] *(rho+rho0*(-3.0*v0              +4.5*v0v0-1.5*modv))+ c2* pi_xx-c3*pi_yy-c3*pi_zz;
      f2[i] =lbw[2] *(rho+rho0*(-3.0*v1              +4.5*v1v1-1.5*modv))- c3* pi_xx+c2*pi_yy-c3*pi_zz;
      f3[i] =lbw[3] *(rho+rho0*(-3.0*v2              +4.5*v2v2-1.5*modv))- c3* pi_xx-c3*pi_yy+c2*pi_zz;
      f4[i] =lbw[4] *(rho+rho0*(-3.0*(v0+v1)+9.0*v0v1-4.5*v2v2+3.0*modv))+ c3* pi_xx+c3*pi_yy-c4*pi_zz+0.25*pi_xy;
      f5[i] =lbw[5] *(rho+rho0*(-3.0*(v0-v1)-9.0*v0v1-4.5*v2v2+3.0*modv))+ c3* pi_xx+c3*pi_yy-c4*pi_zz-0.25*pi_xy;
      f6[i] =lbw[6] *(rho+rho0*(-3.0*(v0+v2)+9.0*v0v2-4.5*v1v1+3.0*modv))+ c3* pi_xx-c4*pi_yy+c3*pi_zz+0.25*pi_xz;
      f7[i] =lbw[7] *(rho+rho0*(-3.0*(v0-v2)-9.0*v0v2-4.5*v1v1+3.0*modv))+ c3* pi_xx-c4*pi_yy+c3*pi_zz-0.25*pi_xz;
      f8[i] =lbw[8] *(rho+rho0*(-3.0*(v1+v2)+9.0*v1v2-4.5*v0v0+3.0*modv))- c4* pi_xx+c3*pi_yy+c3*pi_zz+0.25*pi_yz;
      f9[i] =lbw[9] *(rho+rho0*(-3.0*(v1-v2)-9.0*v1v2-4.5*v0v0+3.0*modv))- c4* pi_xx+c3*pi_yy+c3*pi_zz-0.25*pi_yz;
      f10[i]=lbw[10]*(rho+rho0*( 3.0*v0              +4.5*v0v0-1.5*modv))+ c2* pi_xx-c3*pi_yy-c3*pi_zz;
      f11[i]=lbw[11]*(rho+rho0*( 3.0*v1              +4.5*v1v1-1.5*modv))- c3* pi_xx+c2*pi_yy-c3*pi_zz;
      f12[i]=lbw[12]*(rho+rho0*( 3.0*v2              +4.5*v2v2-1.5*modv))- c3* pi_xx-c3*pi_yy+c2*pi_zz;
      f13[i]=lbw[13]*(rho+rho0*( 3.0*(v0+v1)+9.0*v0v1-4.5*v2v2+3.0*modv))+ c3* pi_xx+c3*pi_yy-c4*pi_zz+0.25*pi_xy;
      f14[i]=lbw[14]*(rho+rho0*( 3.0*(v0-v1)-9.0*v0v1-4.5*v2v2+3.0*modv))+ c3* pi_xx+c3*pi_yy-c4*pi_zz-0.25*pi_xy;
      f15[i]=lbw[15]*(rho+rho0*( 3.0*(v0+v2)+9.0*v0v2-4.5*v1v1+3.0*modv))+ c3* pi_xx-c4*pi_yy+c3*pi_zz+0.25*pi_xz;
      f16[i]=lbw[16]*(rho+rho0*( 3.0*(v0-v2)-9.0*v0v2-4.5*v1v1+3.0*modv))+ c3* pi_xx-c4*pi_yy+c3*pi_zz-0.25*pi_xz;
      f17[i]=lbw[17]*(rho+rho0*( 3.0*(v1+v2)+9.0*v1v2-4.5*v0v0+3.0*modv))- c4* pi_xx+c3*pi_yy+c3*pi_zz+0.25*pi_yz;
      f18[i]=lbw[18]*(rho+rho0*( 3.0*(v1-v2)-9.0*v1v2-4.5*v0v0+3.0*modv))- c4* pi_xx+c3*pi_yy+c3*pi_zz-0.25*pi_yz;
    }
  }
  return 0;
}

int fD3Q19VCERegular(double *p, double v0, double v1, double v2, double *force,
                     double *f0, double *f1, double *f2, double *f3, double *f4,
                     double *f5, double *f6, double *f7, double *f8, double *f9,
                     double *f10, double *f11, double *f12, double *f13, double *f14,
                     double *f15, double *f16, double *f17, double *f18)
{

  // produce fixed velocity for compressible/incompressible fluids at concave edge boundary:
  // expressed for bottom left edge (VCETR)
  double rho0, modv, pi_xx, pi_yy, pi_zz, pi_xy, pi_xz, pi_yz, v0v0, v0v1, v0v2, v1v1, v1v2, v2v2;
  double c1=1.0/3.0,c2=1.0/6.0,c3=1.0/12.0,c4=1.0/24.0,c5=2.0/3.0;

  v0v0 = v0*v0;
  v0v1 = v0*v1;
  v0v2 = v0*v2;
  v1v1 = v1*v1;
  v1v2 = v1*v2;
  v2v2 = v2*v2;
  modv = v0v0+v1v1+v2v2;
    
  if(!incompress) {
    for(int i=0; i<lbsy.nf; i++) {
      pi_xx = -f0[i]-f3[i]-f12[i]-2.0*(f2[i]+f8[i]+f9[i])+p[i]*(c5+c1*v0-c5*v1-v0v0)+v0*force[3*i  ];
      pi_yy = -f0[i]-f3[i]-f12[i]-2.0*(f1[i]+f6[i]+f7[i])+p[i]*(c5-c5*v0+c1*v1-v1v1)+v1*force[3*i+1];
      pi_zz = f3[i]+f12[i]+2.0*(f6[i]+f7[i]+f8[i]+f9[i])+p[i]*(c1*(v0+v1)-c1-v2v2)+v2*force[3*i+2];
      pi_xy = f0[i]+f3[i]+f12[i]+2.0*(f1[i]+f2[i]+f6[i]+f7[i]+f8[i]+f9[i])+4.0*f4[i]-p[i]*(1.0-v0)*(1.0-v1)+0.5*(v1*force[3*i  ]+v0*force[3*i+1]);
      pi_xz = 2.0*(f6[i]-f7[i])+p[i]*v2*(c1-v0)+0.5*(v2*force[3*i  ]+v0*force[3*i+2]);
      pi_yz = 2.0*(f8[i]-f9[i])+p[i]*v2*(c1-v1)+0.5*(v2*force[3*i+1]+v1*force[3*i+2]);
      f0[i] =p[i]*lbw[0] *(1.0                              -1.5*modv)-0.5*(pi_xx+   pi_yy+   pi_zz);
      f1[i] =p[i]*lbw[1] *(1.0-3.0*v0              +4.5*v0v0-1.5*modv)+ c2* pi_xx-c3*pi_yy-c3*pi_zz;
      f2[i] =p[i]*lbw[2] *(1.0-3.0*v1              +4.5*v1v1-1.5*modv)- c3* pi_xx+c2*pi_yy-c3*pi_zz;
      f3[i] =p[i]*lbw[3] *(1.0-3.0*v2              +4.5*v2v2-1.5*modv)- c3* pi_xx-c3*pi_yy+c2*pi_zz;
      f4[i] =p[i]*lbw[4] *(1.0-3.0*(v0+v1)+9.0*v0v1-4.5*v2v2+3.0*modv)+ c3* pi_xx+c3*pi_yy-c4*pi_zz+0.25*pi_xy;
      f5[i] =p[i]*lbw[5] *(1.0-3.0*(v0-v1)-9.0*v0v1-4.5*v2v2+3.0*modv)+ c3* pi_xx+c3*pi_yy-c4*pi_zz-0.25*pi_xy;
      f6[i] =p[i]*lbw[6] *(1.0-3.0*(v0+v2)+9.0*v0v2-4.5*v1v1+3.0*modv)+ c3* pi_xx-c4*pi_yy+c3*pi_zz+0.25*pi_xz;
      f7[i] =p[i]*lbw[7] *(1.0-3.0*(v0-v2)-9.0*v0v2-4.5*v1v1+3.0*modv)+ c3* pi_xx-c4*pi_yy+c3*pi_zz-0.25*pi_xz;
      f8[i] =p[i]*lbw[8] *(1.0-3.0*(v1+v2)+9.0*v1v2-4.5*v0v0+3.0*modv)- c4* pi_xx+c3*pi_yy+c3*pi_zz+0.25*pi_yz;
      f9[i] =p[i]*lbw[9] *(1.0-3.0*(v1-v2)-9.0*v1v2-4.5*v0v0+3.0*modv)- c4* pi_xx+c3*pi_yy+c3*pi_zz-0.25*pi_yz;
      f10[i]=p[i]*lbw[10]*(1.0+3.0*v0              +4.5*v0v0-1.5*modv)+ c2* pi_xx-c3*pi_yy-c3*pi_zz;
      f11[i]=p[i]*lbw[11]*(1.0+3.0*v1              +4.5*v1v1-1.5*modv)- c3* pi_xx+c2*pi_yy-c3*pi_zz;
      f12[i]=p[i]*lbw[12]*(1.0+3.0*v2              +4.5*v2v2-1.5*modv)- c3* pi_xx-c3*pi_yy+c2*pi_zz;
      f13[i]=p[i]*lbw[13]*(1.0+3.0*(v0+v1)+9.0*v0v1-4.5*v2v2+3.0*modv)+ c3* pi_xx+c3*pi_yy-c4*pi_zz+0.25*pi_xy;
      f14[i]=p[i]*lbw[14]*(1.0+3.0*(v0-v1)-9.0*v0v1-4.5*v2v2+3.0*modv)+ c3* pi_xx+c3*pi_yy-c4*pi_zz-0.25*pi_xy;
      f15[i]=p[i]*lbw[15]*(1.0+3.0*(v0+v2)+9.0*v0v2-4.5*v1v1+3.0*modv)+ c3* pi_xx-c4*pi_yy+c3*pi_zz+0.25*pi_xz;
      f16[i]=p[i]*lbw[16]*(1.0+3.0*(v0-v2)-9.0*v0v2-4.5*v1v1+3.0*modv)+ c3* pi_xx-c4*pi_yy+c3*pi_zz-0.25*pi_xz;
      f17[i]=p[i]*lbw[17]*(1.0+3.0*(v1+v2)+9.0*v1v2-4.5*v0v0+3.0*modv)- c4* pi_xx+c3*pi_yy+c3*pi_zz+0.25*pi_yz;
      f18[i]=p[i]*lbw[18]*(1.0+3.0*(v1-v2)-9.0*v1v2-4.5*v0v0+3.0*modv)- c4* pi_xx+c3*pi_yy+c3*pi_zz-0.25*pi_yz;
    }
  }
  else {
    for(int i=0; i<lbsy.nf; i++) {
      rho0 = lbincp[i];
      pi_xx = -f0[i]-f3[i]-f12[i]-2.0*(f2[i]+f8[i]+f9[i])+c5*p[i]+rho0*(c1*v0-c5*v1-v0v0)+v0*force[3*i  ];
      pi_yy = -f0[i]-f3[i]-f12[i]-2.0*(f1[i]+f6[i]+f7[i])+c5*p[i]-rho0*(c5*v0-c1*v1+v1v1)+v1*force[3*i+1];
      pi_zz = f3[i]+f12[i]+2.0*(f6[i]+f7[i]+f8[i]+f9[i])-c1*p[i]+rho0*(c1*(v0+v1)-v2v2)+v2*force[3*i+2];
      pi_xy = f0[i]+f3[i]+f12[i]+2.0*(f1[i]+f2[i]+f6[i]+f7[i]+f8[i]+f9[i])+4.0*f4[i]-p[i]+rho0*(v0+v1-v0v1)+0.5*(v1*force[3*i  ]+v0*force[3*i+1]);
      pi_xz = 2.0*(f6[i]-f7[i])+rho0*v2*(c1-v0)+0.5*(v2*force[3*i  ]+v0*force[3*i+2]);
      pi_yz = 2.0*(f8[i]-f9[i])+rho0*v2*(c1-v1)+0.5*(v2*force[3*i+1]+v1*force[3*i+2]);
      f0[i] =lbw[0] *(p[i]+rho0*(                              -1.5*modv))-0.5*(pi_xx+   pi_yy+   pi_zz);
      f1[i] =lbw[1] *(p[i]+rho0*(-3.0*v0              +4.5*v0v0-1.5*modv))+ c2* pi_xx-c3*pi_yy-c3*pi_zz;
      f2[i] =lbw[2] *(p[i]+rho0*(-3.0*v1              +4.5*v1v1-1.5*modv))- c3* pi_xx+c2*pi_yy-c3*pi_zz;
      f3[i] =lbw[3] *(p[i]+rho0*(-3.0*v2              +4.5*v2v2-1.5*modv))- c3* pi_xx-c3*pi_yy+c2*pi_zz;
      f4[i] =lbw[4] *(p[i]+rho0*(-3.0*(v0+v1)+9.0*v0v1-4.5*v2v2+3.0*modv))+ c3* pi_xx+c3*pi_yy-c4*pi_zz+0.25*pi_xy;
      f5[i] =lbw[5] *(p[i]+rho0*(-3.0*(v0-v1)-9.0*v0v1-4.5*v2v2+3.0*modv))+ c3* pi_xx+c3*pi_yy-c4*pi_zz-0.25*pi_xy;
      f6[i] =lbw[6] *(p[i]+rho0*(-3.0*(v0+v2)+9.0*v0v2-4.5*v1v1+3.0*modv))+ c3* pi_xx-c4*pi_yy+c3*pi_zz+0.25*pi_xz;
      f7[i] =lbw[7] *(p[i]+rho0*(-3.0*(v0-v2)-9.0*v0v2-4.5*v1v1+3.0*modv))+ c3* pi_xx-c4*pi_yy+c3*pi_zz-0.25*pi_xz;
      f8[i] =lbw[8] *(p[i]+rho0*(-3.0*(v1+v2)+9.0*v1v2-4.5*v0v0+3.0*modv))- c4* pi_xx+c3*pi_yy+c3*pi_zz+0.25*pi_yz;
      f9[i] =lbw[9] *(p[i]+rho0*(-3.0*(v1-v2)-9.0*v1v2-4.5*v0v0+3.0*modv))- c4* pi_xx+c3*pi_yy+c3*pi_zz-0.25*pi_yz;
      f10[i]=lbw[10]*(p[i]+rho0*( 3.0*v0              +4.5*v0v0-1.5*modv))+ c2* pi_xx-c3*pi_yy-c3*pi_zz;
      f11[i]=lbw[11]*(p[i]+rho0*( 3.0*v1              +4.5*v1v1-1.5*modv))- c3* pi_xx+c2*pi_yy-c3*pi_zz;
      f12[i]=lbw[12]*(p[i]+rho0*( 3.0*v2              +4.5*v2v2-1.5*modv))- c3* pi_xx-c3*pi_yy+c2*pi_zz;
      f13[i]=lbw[13]*(p[i]+rho0*( 3.0*(v0+v1)+9.0*v0v1-4.5*v2v2+3.0*modv))+ c3* pi_xx+c3*pi_yy-c4*pi_zz+0.25*pi_xy;
      f14[i]=lbw[14]*(p[i]+rho0*( 3.0*(v0-v1)-9.0*v0v1-4.5*v2v2+3.0*modv))+ c3* pi_xx+c3*pi_yy-c4*pi_zz-0.25*pi_xy;
      f15[i]=lbw[15]*(p[i]+rho0*( 3.0*(v0+v2)+9.0*v0v2-4.5*v1v1+3.0*modv))+ c3* pi_xx-c4*pi_yy+c3*pi_zz+0.25*pi_xz;
      f16[i]=lbw[16]*(p[i]+rho0*( 3.0*(v0-v2)-9.0*v0v2-4.5*v1v1+3.0*modv))+ c3* pi_xx-c4*pi_yy+c3*pi_zz-0.25*pi_xz;
      f17[i]=lbw[17]*(p[i]+rho0*( 3.0*(v1+v2)+9.0*v1v2-4.5*v0v0+3.0*modv))- c4* pi_xx+c3*pi_yy+c3*pi_zz+0.25*pi_yz;
      f18[i]=lbw[18]*(p[i]+rho0*( 3.0*(v1-v2)-9.0*v1v2-4.5*v0v0+3.0*modv))- c4* pi_xx+c3*pi_yy+c3*pi_zz-0.25*pi_yz;
    }
  }
  return 0;
}

int fD3Q19VCCRegular(double *p, double v0, double v1, double v2, double *force,
                     double *f0, double *f1, double *f2, double *f3, double *f4,
                     double *f5, double *f6, double *f7, double *f8, double *f9,
                     double *f10, double *f11, double *f12, double *f13, double *f14,
                     double *f15, double *f16, double *f17, double *f18)
{

  // produce fixed velocity for compressible/incompressible fluids at concave corner boundary:
  // expressed for bottom left back corner (VCCTRF)
  double rho0, modv, pi_xx, pi_yy, pi_zz, pi_xy, pi_xz, pi_yz, v0v0, v0v1, v0v2, v1v1, v1v2, v2v2;
  double c1=1.0/3.0,c2=1.0/6.0,c3=1.0/12.0,c4=1.0/24.0,c5=2.0/3.0,c6=4.0/3.0,c7=2.0/9.0,c8=5.0/18.0,c9=7.0/18.0,c10=8.0/3.0;

  v0v0 = v0*v0;
  v0v1 = v0*v1;
  v0v2 = v0*v2;
  v1v1 = v1*v1;
  v1v2 = v1*v2;
  v2v2 = v2*v2;
  modv = v0v0+v1v1+v2v2;
    
  if(!incompress) {
    for(int i=0; i<lbsy.nf; i++) {
      pi_xx = c5*(f1[i]+f4[i]+f6[i]-f0[i])-c6*(f2[i]+f3[i]+f8[i])+p[i]*(c1+c7*v0-c8*(v1+v2)-v0v0)+v0*force[3*i  ];
      pi_yy = c5*(f2[i]+f4[i]+f8[i]-f0[i])-c6*(f1[i]+f3[i]+f6[i])+p[i]*(c1+c7*v1-c8*(v0+v2)-v1v1)+v1*force[3*i+1];
      pi_zz = c5*(f3[i]+f6[i]+f8[i]-f0[i])-c6*(f1[i]+f2[i]+f4[i])+p[i]*(c1+c7*v2-c8*(v0+v1)-v2v2)+v2*force[3*i+2];
      pi_xy = c1*f0[i]+c5*(f1[i]+f2[i]+f3[i]+f6[i]+f8[i])+c10*f4[i]-p[i]*(c1-c9*(v0+v1)-c7*v2+v0v1)+0.5*(v1*force[3*i  ]+v0*force[3*i+1]);
      pi_xz = c1*f0[i]+c5*(f1[i]+f2[i]+f3[i]+f4[i]+f8[i])+c10*f6[i]-p[i]*(c1-c9*(v0+v2)-c7*v1+v0v2)+0.5*(v2*force[3*i  ]+v0*force[3*i+2]);
      pi_yz = c1*f0[i]+c5*(f1[i]+f2[i]+f3[i]+f4[i]+f6[i])+c10*f8[i]-p[i]*(c1-c9*(v1+v2)-c7*v0+v1v2)+0.5*(v2*force[3*i+1]+v1*force[3*i+2]);
      f0[i] =p[i]*lbw[0] *(1.0                              -1.5*modv)-0.5*(pi_xx+   pi_yy+   pi_zz);
      f1[i] =p[i]*lbw[1] *(1.0-3.0*v0              +4.5*v0v0-1.5*modv)+ c2* pi_xx-c3*pi_yy-c3*pi_zz;
      f2[i] =p[i]*lbw[2] *(1.0-3.0*v1              +4.5*v1v1-1.5*modv)- c3* pi_xx+c2*pi_yy-c3*pi_zz;
      f3[i] =p[i]*lbw[3] *(1.0-3.0*v2              +4.5*v2v2-1.5*modv)- c3* pi_xx-c3*pi_yy+c2*pi_zz;
      f4[i] =p[i]*lbw[4] *(1.0-3.0*(v0+v1)+9.0*v0v1-4.5*v2v2+3.0*modv)+ c3* pi_xx+c3*pi_yy-c4*pi_zz+0.25*pi_xy;
      f5[i] =p[i]*lbw[5] *(1.0-3.0*(v0-v1)-9.0*v0v1-4.5*v2v2+3.0*modv)+ c3* pi_xx+c3*pi_yy-c4*pi_zz-0.25*pi_xy;
      f6[i] =p[i]*lbw[6] *(1.0-3.0*(v0+v2)+9.0*v0v2-4.5*v1v1+3.0*modv)+ c3* pi_xx-c4*pi_yy+c3*pi_zz+0.25*pi_xz;
      f7[i] =p[i]*lbw[7] *(1.0-3.0*(v0-v2)-9.0*v0v2-4.5*v1v1+3.0*modv)+ c3* pi_xx-c4*pi_yy+c3*pi_zz-0.25*pi_xz;
      f8[i] =p[i]*lbw[8] *(1.0-3.0*(v1+v2)+9.0*v1v2-4.5*v0v0+3.0*modv)- c4* pi_xx+c3*pi_yy+c3*pi_zz+0.25*pi_yz;
      f9[i] =p[i]*lbw[9] *(1.0-3.0*(v1-v2)-9.0*v1v2-4.5*v0v0+3.0*modv)- c4* pi_xx+c3*pi_yy+c3*pi_zz-0.25*pi_yz;
      f10[i]=p[i]*lbw[10]*(1.0+3.0*v0              +4.5*v0v0-1.5*modv)+ c2* pi_xx-c3*pi_yy-c3*pi_zz;
      f11[i]=p[i]*lbw[11]*(1.0+3.0*v1              +4.5*v1v1-1.5*modv)- c3* pi_xx+c2*pi_yy-c3*pi_zz;
      f12[i]=p[i]*lbw[12]*(1.0+3.0*v2              +4.5*v2v2-1.5*modv)- c3* pi_xx-c3*pi_yy+c2*pi_zz;
      f13[i]=p[i]*lbw[13]*(1.0+3.0*(v0+v1)+9.0*v0v1-4.5*v2v2+3.0*modv)+ c3* pi_xx+c3*pi_yy-c4*pi_zz+0.25*pi_xy;
      f14[i]=p[i]*lbw[14]*(1.0+3.0*(v0-v1)-9.0*v0v1-4.5*v2v2+3.0*modv)+ c3* pi_xx+c3*pi_yy-c4*pi_zz-0.25*pi_xy;
      f15[i]=p[i]*lbw[15]*(1.0+3.0*(v0+v2)+9.0*v0v2-4.5*v1v1+3.0*modv)+ c3* pi_xx-c4*pi_yy+c3*pi_zz+0.25*pi_xz;
      f16[i]=p[i]*lbw[16]*(1.0+3.0*(v0-v2)-9.0*v0v2-4.5*v1v1+3.0*modv)+ c3* pi_xx-c4*pi_yy+c3*pi_zz-0.25*pi_xz;
      f17[i]=p[i]*lbw[17]*(1.0+3.0*(v1+v2)+9.0*v1v2-4.5*v0v0+3.0*modv)- c4* pi_xx+c3*pi_yy+c3*pi_zz+0.25*pi_yz;
      f18[i]=p[i]*lbw[18]*(1.0+3.0*(v1-v2)-9.0*v1v2-4.5*v0v0+3.0*modv)- c4* pi_xx+c3*pi_yy+c3*pi_zz-0.25*pi_yz;
    }
  }
  else {
    for(int i=0; i<lbsy.nf; i++) {
      rho0 = lbincp[i];
      pi_xx = c5*(f1[i]+f4[i]+f6[i]-f0[i])-c6*(f2[i]+f3[i]+f8[i])+c1*p[i]+rho0*(c7*v0-c8*(v1+v2)-v0v0)+v0*force[3*i  ];
      pi_yy = c5*(f2[i]+f4[i]+f8[i]-f0[i])-c6*(f1[i]+f3[i]+f6[i])+c1*p[i]+rho0*(c7*v1-c8*(v0+v2)-v1v1)+v1*force[3*i+1];
      pi_zz = c5*(f3[i]+f6[i]+f8[i]-f0[i])-c6*(f1[i]+f2[i]+f4[i])+c1*p[i]+rho0*(c7*v2-c8*(v0+v1)-v2v2)+v2*force[3*i+2];
      pi_xy = c1*f0[i]+c5*(f1[i]+f2[i]+f3[i]+f6[i]+f8[i])+c10*f4[i]-c1*p[i]+rho0*(c9*(v0+v1)+c7*v2-v0v1)+0.5*(v1*force[3*i  ]+v0*force[3*i+1]);
      pi_xz = c1*f0[i]+c5*(f1[i]+f2[i]+f3[i]+f4[i]+f8[i])+c10*f6[i]-c1*p[i]+rho0*(c9*(v0+v2)+c7*v1-v0v2)+0.5*(v2*force[3*i  ]+v0*force[3*i+2]);
      pi_yz = c1*f0[i]+c5*(f1[i]+f2[i]+f3[i]+f4[i]+f6[i])+c10*f8[i]-c1*p[i]+rho0*(c9*(v1+v2)+c7*v0-v1v2)+0.5*(v2*force[3*i+1]+v1*force[3*i+2]);
      f0[i] =lbw[0] *(p[i]+rho0*(                              -1.5*modv))-0.5*(pi_xx+   pi_yy+   pi_zz);
      f1[i] =lbw[1] *(p[i]+rho0*(-3.0*v0              +4.5*v0v0-1.5*modv))+ c2* pi_xx-c3*pi_yy-c3*pi_zz;
      f2[i] =lbw[2] *(p[i]+rho0*(-3.0*v1              +4.5*v1v1-1.5*modv))- c3* pi_xx+c2*pi_yy-c3*pi_zz;
      f3[i] =lbw[3] *(p[i]+rho0*(-3.0*v2              +4.5*v2v2-1.5*modv))- c3* pi_xx-c3*pi_yy+c2*pi_zz;
      f4[i] =lbw[4] *(p[i]+rho0*(-3.0*(v0+v1)+9.0*v0v1-4.5*v2v2+3.0*modv))+ c3* pi_xx+c3*pi_yy-c4*pi_zz+0.25*pi_xy;
      f5[i] =lbw[5] *(p[i]+rho0*(-3.0*(v0-v1)-9.0*v0v1-4.5*v2v2+3.0*modv))+ c3* pi_xx+c3*pi_yy-c4*pi_zz-0.25*pi_xy;
      f6[i] =lbw[6] *(p[i]+rho0*(-3.0*(v0+v2)+9.0*v0v2-4.5*v1v1+3.0*modv))+ c3* pi_xx-c4*pi_yy+c3*pi_zz+0.25*pi_xz;
      f7[i] =lbw[7] *(p[i]+rho0*(-3.0*(v0-v2)-9.0*v0v2-4.5*v1v1+3.0*modv))+ c3* pi_xx-c4*pi_yy+c3*pi_zz-0.25*pi_xz;
      f8[i] =lbw[8] *(p[i]+rho0*(-3.0*(v1+v2)+9.0*v1v2-4.5*v0v0+3.0*modv))- c4* pi_xx+c3*pi_yy+c3*pi_zz+0.25*pi_yz;
      f9[i] =lbw[9] *(p[i]+rho0*(-3.0*(v1-v2)-9.0*v1v2-4.5*v0v0+3.0*modv))- c4* pi_xx+c3*pi_yy+c3*pi_zz-0.25*pi_yz;
      f10[i]=lbw[10]*(p[i]+rho0*( 3.0*v0              +4.5*v0v0-1.5*modv))+ c2* pi_xx-c3*pi_yy-c3*pi_zz;
      f11[i]=lbw[11]*(p[i]+rho0*( 3.0*v1              +4.5*v1v1-1.5*modv))- c3* pi_xx+c2*pi_yy-c3*pi_zz;
      f12[i]=lbw[12]*(p[i]+rho0*( 3.0*v2              +4.5*v2v2-1.5*modv))- c3* pi_xx-c3*pi_yy+c2*pi_zz;
      f13[i]=lbw[13]*(p[i]+rho0*( 3.0*(v0+v1)+9.0*v0v1-4.5*v2v2+3.0*modv))+ c3* pi_xx+c3*pi_yy-c4*pi_zz+0.25*pi_xy;
      f14[i]=lbw[14]*(p[i]+rho0*( 3.0*(v0-v1)-9.0*v0v1-4.5*v2v2+3.0*modv))+ c3* pi_xx+c3*pi_yy-c4*pi_zz-0.25*pi_xy;
      f15[i]=lbw[15]*(p[i]+rho0*( 3.0*(v0+v2)+9.0*v0v2-4.5*v1v1+3.0*modv))+ c3* pi_xx-c4*pi_yy+c3*pi_zz+0.25*pi_xz;
      f16[i]=lbw[16]*(p[i]+rho0*( 3.0*(v0-v2)-9.0*v0v2-4.5*v1v1+3.0*modv))+ c3* pi_xx-c4*pi_yy+c3*pi_zz-0.25*pi_xz;
      f17[i]=lbw[17]*(p[i]+rho0*( 3.0*(v1+v2)+9.0*v1v2-4.5*v0v0+3.0*modv))- c4* pi_xx+c3*pi_yy+c3*pi_zz+0.25*pi_yz;
      f18[i]=lbw[18]*(p[i]+rho0*( 3.0*(v1-v2)-9.0*v1v2-4.5*v0v0+3.0*modv))- c4* pi_xx+c3*pi_yy+c3*pi_zz-0.25*pi_yz;
    }
  }
  return 0;
}

int fD3Q19VPSCLBERegular(double v0, double v1, double v2, double *force,
                         double *f0, double *f1, double *f2, double *f3, double *f4,
                         double *f5, double *f6, double *f7, double *f8, double *f9,
                         double *f10, double *f11, double *f12, double *f13, double *f14,
                         double *f15, double *f16, double *f17, double *f18)
{

  // produce fixed velocity for compressible fluids at planar surface boundary:
  // expressed for bottom wall (VPST) with higher-order local equilibrium distribution functions for CLBE collisions
  double rho, pi_xx, pi_yy, pi_zz, pi_xy, pi_xz, pi_yz, v0v0, v0v1, v0v2, v1v1, v1v2, v2v2;
  double c1=1.0/3.0,c2=1.0/6.0,c3=1.0/12.0,c4=1.0/24.0;

  v0v0 = v0*v0;
  v0v1 = v0*v1;
  v0v2 = v0*v2;
  v1v1 = v1*v1;
  v1v2 = v1*v2;
  v2v2 = v2*v2;
    
  for(int i=0; i<lbsy.nf; i++) {
    rho = (f0[i]+f1[i]+f3[i]+f6[i]+f7[i]+f10[i]+f12[i]+f15[i]+f16[i]+2.0*(f2[i]+f4[i]+f8[i]+f9[i]+f14[i])-0.5*force[3*i+1])/(1.0-v1);
    pi_xx = f1[i]+f6[i]+f7[i]+f10[i]+f15[i]+f16[i]+2.0*(f4[i]+f14[i])+rho*(c1+v0v0)*(v1-1.0);
    pi_yy = 2.0*(f2[i]+f4[i]+f8[i]+f9[i]+f14[i])+rho*(v1-v1v1-c1);
    pi_zz = f3[i]+f6[i]+f7[i]+f12[i]+f15[i]+f16[i]+2.0*(f8[i]+f9[i])+rho*(c1+v2v2)*(v1-1.0);
    pi_xy = 2.0*(f4[i]-f14[i])+rho*(c1*v0+v0v1*(v1-1.0))+0.5*(v1*force[3*i  ]+v0*force[3*i+1]);
    pi_xz = f6[i]-f7[i]+f15[i]-f16[i]-rho*v0v2+0.5*(v2*force[3*i  ]+v0*force[3*i+2]);
    pi_yz = 2.0*(f8[i]-f9[i])+rho*(c1*v2+v1v2*(v1-1.0))+0.5*(v2*force[3*i+1]+v1*force[3*i+2]);
    f0[i] =rho*lbw[0] *(1.0                 -v0v0-v1v1-v2v2 +3.0*(v0v1*v0v1+v0v2*v0v2+v1v2*v1v2))-0.5*(pi_xx+   pi_yy+   pi_zz);
    f1[i] =rho*lbw[1] *(1.0-3.0*v0     +3.0*(v0v0-v1v1-v2v2)+9.0*(v1v1+v2v2)*(v0-v0v0)          )+ c2* pi_xx-c3*pi_yy-c3*pi_zz;
    f2[i] =rho*lbw[2] *(1.0-3.0*v1     -3.0*(v0v0-v1v1+v2v2)+9.0*(v0v0+v2v2)*(v1-v1v1)          )- c3* pi_xx+c2*pi_yy-c3*pi_zz;
    f3[i] =rho*lbw[3] *(1.0-3.0*v2     -3.0*(v0v0+v1v1-v2v2)+9.0*(v0v0+v1v1)*(v2-v2v2)          )- c3* pi_xx-c3*pi_yy+c2*pi_zz;
    f4[i] =rho*lbw[4] *(1.0-3.0*(v0+v1)+3.0*(v0v0+v1v1     )+9.0* v0v1      *(1.0-v0)*(1.0-v1)  )+ c3* pi_xx+c3*pi_yy-c4*pi_zz+0.25*pi_xy;
    f5[i] =rho*lbw[5] *(1.0-3.0*(v0-v1)+3.0*(v0v0+v1v1     )-9.0* v0v1      *(1.0-v0)*(1.0+v1)  )+ c3* pi_xx+c3*pi_yy-c4*pi_zz-0.25*pi_xy;
    f6[i] =rho*lbw[6] *(1.0-3.0*(v0+v2)+3.0*(v0v0+v2v2     )+9.0* v0v2      *(1.0-v0)*(1.0-v2)  )+ c3* pi_xx-c4*pi_yy+c3*pi_zz+0.25*pi_xz;
    f7[i] =rho*lbw[7] *(1.0-3.0*(v0-v2)+3.0*(v0v0+v2v2     )-9.0* v0v2      *(1.0-v0)*(1.0+v2)  )+ c3* pi_xx-c4*pi_yy+c3*pi_zz-0.25*pi_xz;
    f8[i] =rho*lbw[8] *(1.0-3.0*(v1+v2)+3.0*(v1v1+v2v2     )+9.0* v1v2      *(1.0-v1)*(1.0-v2)  )- c4* pi_xx+c3*pi_yy+c3*pi_zz+0.25*pi_yz;
    f9[i] =rho*lbw[9] *(1.0-3.0*(v1-v2)+3.0*(v1v1+v2v2     )-9.0* v1v2      *(1.0-v1)*(1.0+v2)  )- c4* pi_xx+c3*pi_yy+c3*pi_zz-0.25*pi_yz;
    f10[i]=rho*lbw[10]*(1.0+3.0*v0     +3.0*(v0v0-v1v1-v2v2)-9.0*(v1v1+v2v2)*(v0+v0v0)          )+ c2* pi_xx-c3*pi_yy-c3*pi_zz;
    f11[i]=rho*lbw[11]*(1.0+3.0*v1     -3.0*(v0v0-v1v1+v2v2)-9.0*(v0v0+v2v2)*(v1+v1v1)          )- c3* pi_xx+c2*pi_yy-c3*pi_zz;
    f12[i]=rho*lbw[12]*(1.0+3.0*v2     -3.0*(v0v0+v1v1-v2v2)-9.0*(v0v0+v1v1)*(v2+v2v2)          )- c3* pi_xx-c3*pi_yy+c2*pi_zz;
    f13[i]=rho*lbw[13]*(1.0+3.0*(v0+v1)+3.0*(v0v0+v1v1     )+9.0* v0v1      *(1.0+v0)*(1.0+v1)  )+ c3* pi_xx+c3*pi_yy-c4*pi_zz+0.25*pi_xy;
    f14[i]=rho*lbw[14]*(1.0+3.0*(v0-v1)+3.0*(v0v0+v1v1     )-9.0* v0v1      *(1.0+v0)*(1.0-v1)  )+ c3* pi_xx+c3*pi_yy-c4*pi_zz-0.25*pi_xy;
    f15[i]=rho*lbw[15]*(1.0+3.0*(v0+v2)+3.0*(v0v0+v2v2     )+9.0* v0v2      *(1.0+v0)*(1.0+v2)  )+ c3* pi_xx-c4*pi_yy+c3*pi_zz+0.25*pi_xz;
    f16[i]=rho*lbw[16]*(1.0+3.0*(v0-v2)+3.0*(v0v0+v2v2     )-9.0* v0v2      *(1.0+v0)*(1.0-v2)  )+ c3* pi_xx-c4*pi_yy+c3*pi_zz-0.25*pi_xz;
    f17[i]=rho*lbw[17]*(1.0+3.0*(v1+v2)+3.0*(v1v1+v2v2     )+9.0* v1v2      *(1.0+v1)*(1.0+v2)  )- c4* pi_xx+c3*pi_yy+c3*pi_zz+0.25*pi_yz;
    f18[i]=rho*lbw[18]*(1.0+3.0*(v1-v2)+3.0*(v1v1+v2v2     )-9.0* v1v2      *(1.0+v1)*(1.0-v2)  )- c4* pi_xx+c3*pi_yy+c3*pi_zz-0.25*pi_yz;
  }
  return 0;
}

int fD3Q19VCECLBERegular(double *p, double v0, double v1, double v2, double *force,
                         double *f0, double *f1, double *f2, double *f3, double *f4,
                         double *f5, double *f6, double *f7, double *f8, double *f9,
                         double *f10, double *f11, double *f12, double *f13, double *f14,
                         double *f15, double *f16, double *f17, double *f18)
{

  // produce fixed velocity for compressible fluids at concave edge boundary:
  // expressed for bottom left edge (VCETR) with higher-order local equilibrium distribution functions for CLBE collisions
  double pi_xx, pi_yy, pi_zz, pi_xy, pi_xz, pi_yz, v0v0, v0v1, v0v2, v1v1, v1v2, v2v2;
  double c1=1.0/3.0,c2=1.0/6.0,c3=1.0/12.0,c4=1.0/24.0,c5=2.0/3.0;

  v0v0 = v0*v0;
  v0v1 = v0*v1;
  v0v2 = v0*v2;
  v1v1 = v1*v1;
  v1v2 = v1*v2;
  v2v2 = v2*v2;

  for(int i=0; i<lbsy.nf; i++) {
    pi_xx = -f0[i]-f3[i]-f12[i]-2.0*(f2[i]+f8[i]+f9[i])+p[i]*(c5+c1*v0-c5*v1+0.5*(v0v0*v1-v0*v1v1)-v0v0)+v0*force[3*i  ];
    pi_yy = -f0[i]-f3[i]-f12[i]-2.0*(f1[i]+f6[i]+f7[i])+p[i]*(c5-c5*v0+c1*v1+0.5*(v0*v1v1-v0v0*v1)-v1v1)+v1*force[3*i+1];
    pi_zz = f3[i]+f12[i]+2.0*(f6[i]+f7[i]+f8[i]+f9[i])+p[i]*((v0+v1)*(c1+v2v2)-c1-v2v2)+v2*force[3*i+2];
    pi_xy = f0[i]+f3[i]+f12[i]+2.0*(f1[i]+f2[i]+f6[i]+f7[i]+f8[i]+f9[i])+4.0*f4[i]-p[i]*(1.0-v0)*(1.0-v1)+0.5*p[i]*(v0v0*v1+v0*v1v1)+0.5*(v1*force[3*i  ]+v0*force[3*i+1]);
    pi_xz = 2.0*(f6[i]-f7[i])+p[i]*v2*(c1-v0+v0v0)+0.5*(v2*force[3*i  ]+v0*force[3*i+2]);
    pi_yz = 2.0*(f8[i]-f9[i])+p[i]*v2*(c1-v1+v1v1)+0.5*(v2*force[3*i+1]+v1*force[3*i+2]);
    f0[i] =p[i]*lbw[0] *(1.0                 -v0v0-v1v1-v2v2 +3.0*(v0v1*v0v1+v0v2*v0v2+v1v2*v1v2))-0.5*(pi_xx+   pi_yy+   pi_zz);
    f1[i] =p[i]*lbw[1] *(1.0-3.0*v0     +3.0*(v0v0-v1v1-v2v2)+9.0*(v1v1+v2v2)*(v0-v0v0)          )+ c2* pi_xx-c3*pi_yy-c3*pi_zz;
    f2[i] =p[i]*lbw[2] *(1.0-3.0*v1     -3.0*(v0v0-v1v1+v2v2)+9.0*(v0v0+v2v2)*(v1-v1v1)          )- c3* pi_xx+c2*pi_yy-c3*pi_zz;
    f3[i] =p[i]*lbw[3] *(1.0-3.0*v2     -3.0*(v0v0+v1v1-v2v2)+9.0*(v0v0+v1v1)*(v2-v2v2)          )- c3* pi_xx-c3*pi_yy+c2*pi_zz;
    f4[i] =p[i]*lbw[4] *(1.0-3.0*(v0+v1)+3.0*(v0v0+v1v1     )+9.0* v0v1      *(1.0-v0)*(1.0-v1)  )+ c3* pi_xx+c3*pi_yy-c4*pi_zz+0.25*pi_xy;
    f5[i] =p[i]*lbw[5] *(1.0-3.0*(v0-v1)+3.0*(v0v0+v1v1     )-9.0* v0v1      *(1.0-v0)*(1.0+v1)  )+ c3* pi_xx+c3*pi_yy-c4*pi_zz-0.25*pi_xy;
    f6[i] =p[i]*lbw[6] *(1.0-3.0*(v0+v2)+3.0*(v0v0+v2v2     )+9.0* v0v2      *(1.0-v0)*(1.0-v2)  )+ c3* pi_xx-c4*pi_yy+c3*pi_zz+0.25*pi_xz;
    f7[i] =p[i]*lbw[7] *(1.0-3.0*(v0-v2)+3.0*(v0v0+v2v2     )-9.0* v0v2      *(1.0-v0)*(1.0+v2)  )+ c3* pi_xx-c4*pi_yy+c3*pi_zz-0.25*pi_xz;
    f8[i] =p[i]*lbw[8] *(1.0-3.0*(v1+v2)+3.0*(v1v1+v2v2     )+9.0* v1v2      *(1.0-v1)*(1.0-v2)  )- c4* pi_xx+c3*pi_yy+c3*pi_zz+0.25*pi_yz;
    f9[i] =p[i]*lbw[9] *(1.0-3.0*(v1-v2)+3.0*(v1v1+v2v2     )-9.0* v1v2      *(1.0-v1)*(1.0+v2)  )- c4* pi_xx+c3*pi_yy+c3*pi_zz-0.25*pi_yz;
    f10[i]=p[i]*lbw[10]*(1.0+3.0*v0     +3.0*(v0v0-v1v1-v2v2)-9.0*(v1v1+v2v2)*(v0+v0v0)          )+ c2* pi_xx-c3*pi_yy-c3*pi_zz;
    f11[i]=p[i]*lbw[11]*(1.0+3.0*v1     -3.0*(v0v0-v1v1+v2v2)-9.0*(v0v0+v2v2)*(v1+v1v1)          )- c3* pi_xx+c2*pi_yy-c3*pi_zz;
    f12[i]=p[i]*lbw[12]*(1.0+3.0*v2     -3.0*(v0v0+v1v1-v2v2)-9.0*(v0v0+v1v1)*(v2+v2v2)          )- c3* pi_xx-c3*pi_yy+c2*pi_zz;
    f13[i]=p[i]*lbw[13]*(1.0+3.0*(v0+v1)+3.0*(v0v0+v1v1     )+9.0* v0v1      *(1.0+v0)*(1.0+v1)  )+ c3* pi_xx+c3*pi_yy-c4*pi_zz+0.25*pi_xy;
    f14[i]=p[i]*lbw[14]*(1.0+3.0*(v0-v1)+3.0*(v0v0+v1v1     )-9.0* v0v1      *(1.0+v0)*(1.0-v1)  )+ c3* pi_xx+c3*pi_yy-c4*pi_zz-0.25*pi_xy;
    f15[i]=p[i]*lbw[15]*(1.0+3.0*(v0+v2)+3.0*(v0v0+v2v2     )+9.0* v0v2      *(1.0+v0)*(1.0+v2)  )+ c3* pi_xx-c4*pi_yy+c3*pi_zz+0.25*pi_xz;
    f16[i]=p[i]*lbw[16]*(1.0+3.0*(v0-v2)+3.0*(v0v0+v2v2     )-9.0* v0v2      *(1.0+v0)*(1.0-v2)  )+ c3* pi_xx-c4*pi_yy+c3*pi_zz-0.25*pi_xz;
    f17[i]=p[i]*lbw[17]*(1.0+3.0*(v1+v2)+3.0*(v1v1+v2v2     )+9.0* v1v2      *(1.0+v1)*(1.0+v2)  )- c4* pi_xx+c3*pi_yy+c3*pi_zz+0.25*pi_yz;
    f18[i]=p[i]*lbw[18]*(1.0+3.0*(v1-v2)+3.0*(v1v1+v2v2     )-9.0* v1v2      *(1.0+v1)*(1.0-v2)  )- c4* pi_xx+c3*pi_yy+c3*pi_zz-0.25*pi_yz;
  }
  return 0;
}

int fD3Q19VCCCLBERegular(double *p, double v0, double v1, double v2, double *force,
                         double *f0, double *f1, double *f2, double *f3, double *f4,
                         double *f5, double *f6, double *f7, double *f8, double *f9,
                         double *f10, double *f11, double *f12, double *f13, double *f14,
                         double *f15, double *f16, double *f17, double *f18)
{

  // produce fixed velocity for compressible fluids at concave corner boundary:
  // expressed for bottom left back corner (VCCTRF) with higher-order local equilibrium distribution functions for CLBE collisions
  double pi_xx, pi_yy, pi_zz, pi_xy, pi_xz, pi_yz, v0v0, v0v1, v0v2, v1v1, v1v2, v2v2;
  double c1=1.0/3.0,c2=1.0/6.0,c3=1.0/12.0,c4=1.0/24.0,c5=2.0/3.0,c6=4.0/3.0,c7=2.0/9.0,c8=5.0/18.0,c9=7.0/18.0,c10=8.0/3.0,c11=5.0/6.0;

  v0v0 = v0*v0;
  v0v1 = v0*v1;
  v0v2 = v0*v2;
  v1v1 = v1*v1;
  v1v2 = v1*v2;
  v2v2 = v2*v2;

  for(int i=0; i<lbsy.nf; i++) {
    pi_xx = c5*(f1[i]+f4[i]+f6[i]-f0[i])-c6*(f2[i]+f3[i]+f8[i])+p[i]*(c1+v0*(c7-c2  *(v1v1+v2v2))-v1*(c8-c11*v0v0-c1*v2v2)-v2*(c8-c11*v0v0-c1*v1v1)-v0v0)+v0*force[3*i  ];
    pi_yy = c5*(f2[i]+f4[i]+f8[i]-f0[i])-c6*(f1[i]+f3[i]+f6[i])+p[i]*(c1-v0*(c8-c11*v1v1-c1*v2v2)+v1*(c7-c2*  (v0v0+v2v2))-v2*(c8-c1*v0v0-c11*v1v1)-v0v0)+v1*force[3*i+1];
    pi_zz = c5*(f3[i]+f6[i]+f8[i]-f0[i])-c6*(f1[i]+f2[i]+f4[i])+p[i]*(c1-v0*(c8-c1*v1v1-c11*v2v2)+v1*(c8-c1*v0v0-c11*v2v2)-v2*(c7-c2*  (v0v0+v1v1))-v0v0)+v2*force[3*i+2];
    pi_xy = c1*f0[i]+c5*(f1[i]+f2[i]+f3[i]+f6[i]+f8[i])+c10*f4[i]-p[i]*(c1-v0*(c9+c1*v1v1-c2*v2v2)-v1*(c9+c1*v0v0-c2*v2v2)-v2*(c7-c2* (v0v0+v1v1))+v0v1)+0.5*(v1*force[3*i  ]+v0*force[3*i+1]);
    pi_xz = c1*f0[i]+c5*(f1[i]+f2[i]+f3[i]+f4[i]+f8[i])+c10*f6[i]-p[i]*(c1-v0*(c9-c2*v1v1+c1*v2v2)-v1*(c7-c2* (v0v0+v2v2))-v2*(c9+c1*v0v0-c2*v1v1)+v0v2)+0.5*(v2*force[3*i  ]+v0*force[3*i+2]);
    pi_yz = c1*f0[i]+c5*(f1[i]+f2[i]+f3[i]+f4[i]+f8[i])+c10*f6[i]-p[i]*(c1-v0*(c7-c2 *(v1v1+v2v2))-v1*(c9-c2*v0v0+c1*v2v2)-v2*(c9-c2*v0v0+c1*v1v1)+v1v2)+0.5*(v2*force[3*i+1]+v1*force[3*i+2]);
      
    f0[i] =p[i]*lbw[0] *(1.0                 -v0v0-v1v1-v2v2 +3.0*(v0v1*v0v1+v0v2*v0v2+v1v2*v1v2))-0.5*(pi_xx+   pi_yy+   pi_zz);
    f1[i] =p[i]*lbw[1] *(1.0-3.0*v0     +3.0*(v0v0-v1v1-v2v2)+9.0*(v1v1+v2v2)*(v0-v0v0)          )+ c2* pi_xx-c3*pi_yy-c3*pi_zz;
    f2[i] =p[i]*lbw[2] *(1.0-3.0*v1     -3.0*(v0v0-v1v1+v2v2)+9.0*(v0v0+v2v2)*(v1-v1v1)          )- c3* pi_xx+c2*pi_yy-c3*pi_zz;
    f3[i] =p[i]*lbw[3] *(1.0-3.0*v2     -3.0*(v0v0+v1v1-v2v2)+9.0*(v0v0+v1v1)*(v2-v2v2)          )- c3* pi_xx-c3*pi_yy+c2*pi_zz;
    f4[i] =p[i]*lbw[4] *(1.0-3.0*(v0+v1)+3.0*(v0v0+v1v1     )+9.0* v0v1      *(1.0-v0)*(1.0-v1)  )+ c3* pi_xx+c3*pi_yy-c4*pi_zz+0.25*pi_xy;
    f5[i] =p[i]*lbw[5] *(1.0-3.0*(v0-v1)+3.0*(v0v0+v1v1     )-9.0* v0v1      *(1.0-v0)*(1.0+v1)  )+ c3* pi_xx+c3*pi_yy-c4*pi_zz-0.25*pi_xy;
    f6[i] =p[i]*lbw[6] *(1.0-3.0*(v0+v2)+3.0*(v0v0+v2v2     )+9.0* v0v2      *(1.0-v0)*(1.0-v2)  )+ c3* pi_xx-c4*pi_yy+c3*pi_zz+0.25*pi_xz;
    f7[i] =p[i]*lbw[7] *(1.0-3.0*(v0-v2)+3.0*(v0v0+v2v2     )-9.0* v0v2      *(1.0-v0)*(1.0+v2)  )+ c3* pi_xx-c4*pi_yy+c3*pi_zz-0.25*pi_xz;
    f8[i] =p[i]*lbw[8] *(1.0-3.0*(v1+v2)+3.0*(v1v1+v2v2     )+9.0* v1v2      *(1.0-v1)*(1.0-v2)  )- c4* pi_xx+c3*pi_yy+c3*pi_zz+0.25*pi_yz;
    f9[i] =p[i]*lbw[9] *(1.0-3.0*(v1-v2)+3.0*(v1v1+v2v2     )-9.0* v1v2      *(1.0-v1)*(1.0+v2)  )- c4* pi_xx+c3*pi_yy+c3*pi_zz-0.25*pi_yz;
    f10[i]=p[i]*lbw[10]*(1.0+3.0*v0     +3.0*(v0v0-v1v1-v2v2)-9.0*(v1v1+v2v2)*(v0+v0v0)          )+ c2* pi_xx-c3*pi_yy-c3*pi_zz;
    f11[i]=p[i]*lbw[11]*(1.0+3.0*v1     -3.0*(v0v0-v1v1+v2v2)-9.0*(v0v0+v2v2)*(v1+v1v1)          )- c3* pi_xx+c2*pi_yy-c3*pi_zz;
    f12[i]=p[i]*lbw[12]*(1.0+3.0*v2     -3.0*(v0v0+v1v1-v2v2)-9.0*(v0v0+v1v1)*(v2+v2v2)          )- c3* pi_xx-c3*pi_yy+c2*pi_zz;
    f13[i]=p[i]*lbw[13]*(1.0+3.0*(v0+v1)+3.0*(v0v0+v1v1     )+9.0* v0v1      *(1.0+v0)*(1.0+v1)  )+ c3* pi_xx+c3*pi_yy-c4*pi_zz+0.25*pi_xy;
    f14[i]=p[i]*lbw[14]*(1.0+3.0*(v0-v1)+3.0*(v0v0+v1v1     )-9.0* v0v1      *(1.0+v0)*(1.0-v1)  )+ c3* pi_xx+c3*pi_yy-c4*pi_zz-0.25*pi_xy;
    f15[i]=p[i]*lbw[15]*(1.0+3.0*(v0+v2)+3.0*(v0v0+v2v2     )+9.0* v0v2      *(1.0+v0)*(1.0+v2)  )+ c3* pi_xx-c4*pi_yy+c3*pi_zz+0.25*pi_xz;
    f16[i]=p[i]*lbw[16]*(1.0+3.0*(v0-v2)+3.0*(v0v0+v2v2     )-9.0* v0v2      *(1.0+v0)*(1.0-v2)  )+ c3* pi_xx-c4*pi_yy+c3*pi_zz-0.25*pi_xz;
    f17[i]=p[i]*lbw[17]*(1.0+3.0*(v1+v2)+3.0*(v1v1+v2v2     )+9.0* v1v2      *(1.0+v1)*(1.0+v2)  )- c4* pi_xx+c3*pi_yy+c3*pi_zz+0.25*pi_yz;
    f18[i]=p[i]*lbw[18]*(1.0+3.0*(v1-v2)+3.0*(v1v1+v2v2     )-9.0* v1v2      *(1.0+v1)*(1.0-v2)  )- c4* pi_xx+c3*pi_yy+c3*pi_zz-0.25*pi_yz;
  }
  return 0;
}

int fD3Q19VPSSwiftRegular(double v0, double v1, double v2, double *force,
                          double *f0, double *f1, double *f2, double *f3, double *f4,
                          double *f5, double *f6, double *f7, double *f8, double *f9,
                          double *f10, double *f11, double *f12, double *f13, double *f14,
                          double *f15, double *f16, double *f17, double *f18,
                          double drdx, double drdy, double drdz, double dpdx, double dpdy, double dpdz,
                          double nabr, double nabp, double *omega, double T)
{

  // produce fixed velocity for compressible/incompressible fluids at planar surface boundary:
  // expressed for bottom wall (VPST)

  double rho, phi, omegat, pb, mu, lambda, d2rdx2, d2rdy2, d2rdz2, d2rdxdy, d2rdxdz, d2rdydz, nabrp, modv;
  double v0v0, v0v1, v0v2, v1v1, v1v2, v2v2, udr;
  double pi_xx, pi_yy, pi_zz, pi_xy, pi_xz, pi_yz, pic_xx, pic_yy, pic_zz, pic_xy, pic_xz, pic_yz;
  double c1=1.0/3.0,c2=1.0/6.0,c3=1.0/12.0,c4=1.0/24.0;

  v0v0 = v0*v0;
  v0v1 = v0*v1;
  v0v2 = v0*v2;
  v1v1 = v1*v1;
  v1v2 = v1*v2;
  v2v2 = v2*v2;
  modv = v0v0 + v1v1 + v2v2;
  rho = (f0[0]+f1[0]+f3[0]+f6[0]+f7[0]+f10[0]+f12[0]+f15[0]+f16[0]+2.0*(f2[0]+f4[0]+f8[0]+f9[0]+f14[0])-0.5*force[1])/(1.0-v1);
  if(lbsy.nf>1) {
    phi = (f0[1]+f1[1]+f3[1]+f6[1]+f7[1]+f10[1]+f12[1]+f15[1]+f16[1]+2.0*(f2[1]+f4[1]+f8[1]+f9[1]+f14[1]))/(1.0-v1);
    omegat = 0.5*(1.0+phi)*omega[0]+0.5*(1.0-phi)*omega[1];
    mu = lbfemob*fGetPotentialSwift(phi, nabp);
    d2rdx2 = (lbfeeos>0)?(drdx*drdx):0.0 + dpdx*dpdx;
    d2rdy2 = (lbfeeos>0)?(drdy*drdy):0.0 + dpdy*dpdy;
    d2rdz2 = (lbfeeos>0)?(drdz*drdz):0.0 + dpdz*dpdz;
    d2rdxdy = (lbfeeos>0)?(drdx*drdy):0.0 + dpdx*dpdy;
    d2rdxdz = (lbfeeos>0)?(drdx*drdz):0.0 + dpdx*dpdz;
    d2rdydz = (lbfeeos>0)?(drdy*drdz):0.0 + dpdy*dpdz;
    nabrp = (lbfeeos>0)?(rho*nabr):0.0 + phi*nabp;

    pic_xx = f1[1]+f6[1]+f7[1]+f10[1]+f15[1]+f16[1]+2.0*(f4[1]+f14[1])+phi*(c1*v1-v0v0)-mu;
    pic_yy = 2.0*(f2[1]+f4[1]+f8[1]+f9[1]+f14[1])+phi*(v1-v1v1)-mu;
    pic_zz = f3[1]+f6[1]+f7[1]+f12[1]+f15[1]+f16[1]+2.0*(f8[1]+f9[1])+phi*(c1*v1-v2v2)-mu;
    pic_xy = 2.0*(f4[1]-f14[1])+phi*(c1*v0-v0v1);
    pic_xz = 2.0*(f6[1]-f7[1]+f15[1]-f16[1])-phi*v0v2;
    pic_yz = 2.0*(f8[1]-f9[1])+phi*(c1*v2-v1v2);

    f0[1] =mu*lbwpt[0] +phi*         (1.0-             0.5*lbwi[0]*modv)-0.5*(pic_xx+   pic_yy+   pic_zz);
    f1[1] =mu*lbwpt[1] +phi*lbwi[1] *(-v0            +1.5*v0v0-0.5*modv)+ c2* pic_xx-c3*pic_yy-c3*pic_zz;
    f2[1] =mu*lbwpt[2] +phi*lbwi[2] *(-v1            +1.5*v1v1-0.5*modv)- c3* pic_xx+c2*pic_yy-c3*pic_zz;
    f3[1] =mu*lbwpt[3] +phi*lbwi[3] *(-v2            +1.5*v2v2-0.5*modv)- c3* pic_xx-c3*pic_yy+c2*pic_zz;
    f4[1] =mu*lbwpt[4] +phi*lbwi[4] *(-v0-v1+3.0+v0v1-1.5*v2v2    +modv)+ c3* pic_xx+c3*pic_yy-c4*pic_zz+0.25*pic_xy;
    f5[1] =mu*lbwpt[5] +phi*lbwi[5] *(-v0+v1-3.0+v0v1-1.5*v2v2    +modv)+ c3* pic_xx+c3*pic_yy-c4*pic_zz-0.25*pic_xy;
    f6[1] =mu*lbwpt[6] +phi*lbwi[6] *(-v0-v2+3.0+v0v2-1.5*v1v1    +modv)+ c3* pic_xx-c4*pic_yy+c3*pic_zz+0.25*pic_xz;
    f7[1] =mu*lbwpt[7] +phi*lbwi[7] *(-v0+v2-3.0+v0v2-1.5*v1v1    +modv)+ c3* pic_xx-c4*pic_yy+c3*pic_zz-0.25*pic_xz;
    f8[1] =mu*lbwpt[8] +phi*lbwi[8] *(-v1-v2+3.0+v1v2-1.5*v0v0    +modv)- c4* pic_xx+c3*pic_yy+c3*pic_zz+0.25*pic_yz;
    f9[1] =mu*lbwpt[9] +phi*lbwi[9] *(-v1+v2-3.0+v1v2-1.5*v0v0    +modv)- c4* pic_xx+c3*pic_yy+c3*pic_zz-0.25*pic_yz;
    f10[1]=mu*lbwpt[10]+phi*lbwi[10]*( v0            +1.5*v0v0-0.5*modv)+ c2* pic_xx-c3*pic_yy-c3*pic_zz;
    f11[1]=mu*lbwpt[11]+phi*lbwi[11]*( v1            +1.5*v1v1-0.5*modv)- c3* pic_xx+c2*pic_yy-c3*pic_zz;
    f12[1]=mu*lbwpt[12]+phi*lbwi[12]*( v2            +1.5*v2v2-0.5*modv)- c3* pic_xx-c3*pic_yy+c2*pic_zz;
    f13[1]=mu*lbwpt[13]+phi*lbwi[13]*( v0+v1+3.0+v0v1-1.5*v2v2    +modv)+ c3* pic_xx+c3*pic_yy-c4*pic_zz+0.25*pic_xy;
    f14[1]=mu*lbwpt[14]+phi*lbwi[14]*( v0-v1-3.0+v0v1-1.5*v2v2    +modv)+ c3* pic_xx+c3*pic_yy-c4*pic_zz-0.25*pic_xy;
    f15[1]=mu*lbwpt[15]+phi*lbwi[15]*( v0+v2+3.0+v0v2-1.5*v1v1    +modv)+ c3* pic_xx-c4*pic_yy+c3*pic_zz+0.25*pic_xz;
    f16[1]=mu*lbwpt[16]+phi*lbwi[16]*( v0-v2-3.0+v0v2-1.5*v1v1    +modv)+ c3* pic_xx-c4*pic_yy+c3*pic_zz-0.25*pic_xz;
    f17[1]=mu*lbwpt[17]+phi*lbwi[17]*( v1+v2+3.0+v1v2-1.5*v0v0    +modv)- c4* pic_xx+c3*pic_yy+c3*pic_zz+0.25*pic_yz;
    f18[1]=mu*lbwpt[18]+phi*lbwi[18]*( v1-v2-3.0+v1v2-1.5*v0v0    +modv)- c4* pic_xx+c3*pic_yy+c3*pic_zz-0.25*pic_yz;
  }
  else {
    phi = 0.0;
    omegat = omega[0];
    d2rdx2 = drdx*drdx;
    d2rdy2 = drdy*drdy;
    d2rdz2 = drdz*drdz;
    d2rdxdy = drdx*drdy;
    d2rdxdz = drdx*drdz;
    d2rdydz = drdy*drdz;
    nabrp = rho*nabr;
  }
  pb = fGetBulkPressureSwift(rho, phi, T);
  lambda = fGetLambdaSwift(rho, omegat, T);
  udr = drdx*v0 + drdy*v1 + drdz*v2;
  pi_xx = f1[0]+f6[0]+f7[0]+f10[0]+f15[0]+f16[0]+2.0*(f4[0]+f14[0])+rho*(c1*v1-v0v0)+v0*force[0]-pb+lbkappa*nabrp-0.5*lbkappa*(d2rdx2-d2rdy2-d2rdz2)-2.0*lambda*(2.0*v0*drdx+v1*drdy+v2*drdz);
  pi_yy = 2.0*(f2[0]+f4[0]+f8[0]+f9[0]+f14[0])+rho*(v1-v1v1)+v1*force[1]-pb+lbkappa*nabrp-0.5*lbkappa*(d2rdx2-d2rdy2+d2rdz2)-2.0*lambda*(v0*drdx+2.0*v1*drdy+v2*drdz);
  pi_zz = f3[0]+f6[0]+f7[0]+f12[0]+f15[0]+f16[0]+2.0*(f8[0]+f9[0])+rho*(c1*v1-v2v2)+v2*force[2]-pb+lbkappa*nabrp+0.5*lbkappa*(d2rdx2+d2rdy2-d2rdz2)-2.0*lambda*(v0*drdx+v1*drdy+2.0*v2*drdz);
  pi_xy = 2.0*(f4[0]-f14[0])+rho*(c1*v0-v0v1)+0.5*(v1*force[0]+v0*force[1])-lbkappa*d2rdxdy-lambda*(v1*drdx+v0*drdy);
  pi_xz = f6[0]-f7[0]+f15[0]-f16[0]-rho*v0v2+0.5*(v2*force[0]+v0*force[2])-lbkappa*d2rdxdz-lambda*(v2*drdx+v0*drdz);
  pi_yz = 2.0*(f8[0]-f9[0])+rho*(c1*v2-v1v2)+0.5*(v2*force[1]+v1*force[2])-lbkappa*d2rdydz-lambda*(v2*drdy+v1*drdz);
    
  f0[0] =rho*(lbw0[0]-                    0.5*lbwi[0]*modv)+lambda*lbwdel[0]*udr
        +lbwpt[0] *(pb-lbkappa*nabrp)+lbkappa*(lbwxx[0]*d2rdx2 +lbwyy[0] *d2rdy2+lbwzz[0] *d2rdz2)
        -0.5*(pi_xx+   pi_yy+   pi_zz);
  f1[0] =lbwi [1] *(rho*(-v0            +1.5*v0v0-0.5*modv)+lambda*(3.0*drdx*v0))
        +lbwpt[1] *(pb-lbkappa*nabrp)+lbkappa*(lbwxx[1] *d2rdx2+lbwyy[1] *d2rdy2+lbwzz[1] *d2rdz2)
        + c2* pi_xx-c3*pi_yy-c3*pi_zz;
  f2[0] =lbwi [2] *(rho*(-v1            +1.5*v1v1-0.5*modv)+lambda*(3.0*drdy*v1))
        +lbwpt[2] *(pb-lbkappa*nabrp)+lbkappa*(lbwxx[2] *d2rdx2+lbwyy[2] *d2rdy2+lbwzz[2] *d2rdz2)
        - c3* pi_xx+c2*pi_yy-c3*pi_zz;
  f3[0] =lbwi [3] *(rho*(-v2            +1.5*v2v2-0.5*modv)+lambda*(3.0*drdz*v2))
        +lbwpt[3] *(pb-lbkappa*nabrp)+lbkappa*(lbwxx[3] *d2rdx2+lbwyy[3] *d2rdy2+lbwzz[3] *d2rdz2)
        - c3* pi_xx-c3*pi_yy+c2*pi_zz;
  f4[0] =lbwi [4] *(rho*(-v0-v1+3.0*v0v1-1.5*v2v2    +modv)+lambda*(1.5*udr+3.0*((v0+v1)*drdx+(v0+v1)*drdy)))
        +lbwpt[4] *(pb-lbkappa*nabrp)+lbkappa*(lbwxx[4] *d2rdx2+lbwyy[4] *d2rdy2+lbwzz[4] *d2rdz2+lbwxy[4] *d2rdxdy+lbwxz[4] *d2rdxdz+lbwyz[4] *d2rdydz)
        + c3* pi_xx+c3*pi_yy-c4*pi_zz+0.25*pi_xy;
  f5[0] =lbwi [5] *(rho*(-v0+v1-3.0*v0v1-1.5*v2v2    +modv)+lambda*(1.5*udr+3.0*((v0-v1)*drdx-(v0-v1)*drdy)))
        +lbwpt[5] *(pb-lbkappa*nabrp)+lbkappa*(lbwxx[5] *d2rdx2+lbwyy[5] *d2rdy2+lbwzz[5] *d2rdz2+lbwxy[5] *d2rdxdy+lbwxz[5] *d2rdxdz+lbwyz[5] *d2rdydz)
        + c3* pi_xx+c3*pi_yy-c4*pi_zz-0.25*pi_xy;
  f6[0] =lbwi [6] *(rho*(-v0-v2+3.0*v0v2-1.5*v1v1    +modv)+lambda*(1.5*udr+3.0*((v0+v2)*drdx+(v0+v2)*drdz)))
        +lbwpt[6] *(pb-lbkappa*nabrp)+lbkappa*(lbwxx[6] *d2rdx2+lbwyy[6] *d2rdy2+lbwzz[6] *d2rdz2+lbwxy[6] *d2rdxdy+lbwxz[6] *d2rdxdz+lbwyz[6] *d2rdydz)
        + c3* pi_xx-c4*pi_yy+c3*pi_zz+0.25*pi_xz;
  f7[0] =lbwi [7] *(rho*(-v0+v2-3.0*v0v2-1.5*v1v1    +modv)+lambda*(1.5*udr+3.0*((v0-v2)*drdx-(v0-v2)*drdz)))
        +lbwpt[7] *(pb-lbkappa*nabrp)+lbkappa*(lbwxx[7] *d2rdx2+lbwyy[7] *d2rdy2+lbwzz[7] *d2rdz2+lbwxy[7] *d2rdxdy+lbwxz[7] *d2rdxdz+lbwyz[7] *d2rdydz)
        + c3* pi_xx-c4*pi_yy+c3*pi_zz-0.25*pi_xz;
  f8[0] =lbwi [8] *(rho*(-v1-v2+3.0*v1v2-1.5*v0v0    +modv)+lambda*(1.5*udr+3.0*((v1+v2)*drdy+(v1+v2)*drdz)))
        +lbwpt[8] *(pb-lbkappa*nabrp)+lbkappa*(lbwxx[8] *d2rdx2+lbwyy[8] *d2rdy2+lbwzz[8] *d2rdz2+lbwxy[8] *d2rdxdy+lbwxz[8] *d2rdxdz+lbwyz[8] *d2rdydz)
        - c4* pi_xx+c3*pi_yy+c3*pi_zz+0.25*pi_yz;
  f9[0] =lbwi [9] *(rho*(-v1+v2-3.0*v1v2-1.5*v0v0    +modv)+lambda*(1.5*udr+3.0*((v1-v2)*drdy-(v1-v2)*drdz)))
        +lbwpt[9] *(pb-lbkappa*nabrp)+lbkappa*(lbwxx[9] *d2rdx2+lbwyy[9] *d2rdy2+lbwzz[9] *d2rdz2+lbwxy[9] *d2rdxdy+lbwxz[9] *d2rdxdz+lbwyz[9] *d2rdydz)
        - c4* pi_xx+c3*pi_yy+c3*pi_zz-0.25*pi_yz;
  f10[0]=lbwi [10]*(rho*( v0            +1.5*v0v0-0.5*modv)+lambda*(3.0*drdx*v0))
        +lbwpt[10]*(pb-lbkappa*nabrp)+lbkappa*(lbwxx[10]*d2rdx2+lbwyy[10]*d2rdy2+lbwzz[10]*d2rdz2)
        + c2* pi_xx-c3*pi_yy-c3*pi_zz;
  f11[0]=lbwi [11]*(rho*( v1            +1.5*v1v1-0.5*modv)+lambda*(3.0*drdy*v1))
        +lbwpt[11]*(pb-lbkappa*nabrp)+lbkappa*(lbwxx[11]*d2rdx2+lbwyy[11]*d2rdy2+lbwzz[11]*d2rdz2)
        - c3* pi_xx+c2*pi_yy-c3*pi_zz;
  f12[0]=lbwi [12]*(rho*( v2            +1.5*v2v2-0.5*modv)+lambda*(3.0*drdz*v2))
        +lbwpt[12]*(pb-lbkappa*nabrp)+lbkappa*(lbwxx[12]*d2rdx2+lbwyy[12]*d2rdy2+lbwzz[12]*d2rdz2)
        - c3* pi_xx-c3*pi_yy+c2*pi_zz;
  f13[0]=lbwi [13]*(rho*( v0+v1+3.0*v0v1-1.5*v2v2    +modv)+lambda*(1.5*udr+3.0*((v0+v1)*drdx+(v0+v1)*drdy)))
        +lbwpt[13]*(pb-lbkappa*nabrp)+lbkappa*(lbwxx[13]*d2rdx2+lbwyy[13]*d2rdy2+lbwzz[13]*d2rdz2+lbwxy[13]*d2rdxdy+lbwxz[13]*d2rdxdz+lbwyz[13]*d2rdydz)
        + c3* pi_xx+c3*pi_yy-c4*pi_zz+0.25*pi_xy;
  f14[0]=lbwi [14]*(rho*( v0-v1-3.0*v0v1-1.5*v2v2    +modv)+lambda*(1.5*udr+3.0*((v0-v1)*drdx-(v0-v1)*drdy)))
        +lbwpt[14]*(pb-lbkappa*nabrp)+lbkappa*(lbwxx[14]*d2rdx2+lbwyy[14]*d2rdy2+lbwzz[14]*d2rdz2+lbwxy[14]*d2rdxdy+lbwxz[14]*d2rdxdz+lbwyz[14]*d2rdydz)
        + c3* pi_xx+c3*pi_yy-c4*pi_zz-0.25*pi_xy;
  f15[0]=lbwi [15]*(rho*( v0+v2+3.0*v0v2-1.5*v1v1    +modv)+lambda*(1.5*udr+3.0*((v0+v2)*drdx+(v0+v2)*drdz)))
        +lbwpt[15]*(pb-lbkappa*nabrp)+lbkappa*(lbwxx[15]*d2rdx2+lbwyy[15]*d2rdy2+lbwzz[15]*d2rdz2+lbwxy[15]*d2rdxdy+lbwxz[15]*d2rdxdz+lbwyz[15]*d2rdydz)
        + c3* pi_xx-c4*pi_yy+c3*pi_zz+0.25*pi_xz;
  f16[0]=lbwi [16]*(rho*( v0-v2-3.0*v0v2-1.5*v1v1    +modv)+lambda*(1.5*udr+3.0*((v0-v2)*drdx-(v0-v2)*drdz)))
        +lbwpt[16]*(pb-lbkappa*nabrp)+lbkappa*(lbwxx[16]*d2rdx2+lbwyy[16]*d2rdy2+lbwzz[16]*d2rdz2+lbwxy[16]*d2rdxdy+lbwxz[16]*d2rdxdz+lbwyz[16]*d2rdydz)
        + c3* pi_xx-c4*pi_yy+c3*pi_zz-0.25*pi_xz;
  f17[0]=lbwi [17]*(rho*( v1+v2+3.0*v1v2-1.5*v0v0    +modv)+lambda*(1.5*udr+3.0*((v1+v2)*drdy+(v1+v2)*drdz)))
        +lbwpt[17]*(pb-lbkappa*nabrp)+lbkappa*(lbwxx[17]*d2rdx2+lbwyy[17]*d2rdy2+lbwzz[17]*d2rdz2+lbwxy[17]*d2rdxdy+lbwxz[17]*d2rdxdz+lbwyz[17]*d2rdydz)
        - c4* pi_xx+c3*pi_yy+c3*pi_zz+0.25*pi_yz;
  f18[0]=lbwi [18]*(rho*( v1-v2-3.0*v1v2-1.5*v0v0    +modv)+lambda*(1.5*udr+3.0*((v1-v2)*drdy-(v1-v2)*drdz)))
        +lbwpt[18]*(pb-lbkappa*nabrp)+lbkappa*(lbwxx[18]*d2rdx2+lbwyy[18]*d2rdy2+lbwzz[18]*d2rdz2+lbwxy[18]*d2rdxdy+lbwxz[18]*d2rdxdz+lbwyz[18]*d2rdydz)
        - c4* pi_xx+c3*pi_yy+c3*pi_zz-0.25*pi_yz;
  return 0;
}

int fD3Q19VCESwiftRegular(double *p, double v0, double v1, double v2, double *force,
                          double *f0, double *f1, double *f2, double *f3, double *f4,
                          double *f5, double *f6, double *f7, double *f8, double *f9,
                          double *f10, double *f11, double *f12, double *f13, double *f14,
                          double *f15, double *f16, double *f17, double *f18,
                          double drdx, double drdy, double drdz, double dpdx, double dpdy, double dpdz,
                          double nabr, double nabp, double *omega, double T)
{

  // produce fixed velocity for compressible/incompressible fluids at concave edge boundary:
  // expressed for bottom left edge (VCETR)

  double rho, phi, omegat, pb, mu, lambda, d2rdx2, d2rdy2, d2rdz2, d2rdxdy, d2rdxdz, d2rdydz, nabrp, modv;
  double v0v0, v0v1, v0v2, v1v1, v1v2, v2v2, udr;
  double pi_xx, pi_yy, pi_zz, pi_xy, pi_xz, pi_yz, pic_xx, pic_yy, pic_zz, pic_xy, pic_xz, pic_yz;
  double c1=1.0/3.0,c2=1.0/6.0,c3=1.0/12.0,c4=1.0/24.0,c5=2.0/3.0;

  v0v0 = v0*v0;
  v0v1 = v0*v1;
  v0v2 = v0*v2;
  v1v1 = v1*v1;
  v1v2 = v1*v2;
  v2v2 = v2*v2;
  modv = v0v0 + v1v1 + v2v2;
  rho = p[0];
  if(lbsy.nf>1) {
    phi = p[1];
    omegat = 0.5*(1.0+phi)*omega[0]+0.5*(1.0-phi)*omega[1];
    mu = lbfemob*fGetPotentialSwift(phi, nabp);
    d2rdx2 = (lbfeeos>0)?(drdx*drdx):0.0 + dpdx*dpdx;
    d2rdy2 = (lbfeeos>0)?(drdy*drdy):0.0 + dpdy*dpdy;
    d2rdz2 = (lbfeeos>0)?(drdz*drdz):0.0 + dpdz*dpdz;
    d2rdxdy = (lbfeeos>0)?(drdx*drdy):0.0 + dpdx*dpdy;
    d2rdxdz = (lbfeeos>0)?(drdx*drdz):0.0 + dpdx*dpdz;
    d2rdydz = (lbfeeos>0)?(drdy*drdz):0.0 + dpdy*dpdz;
    nabrp = (lbfeeos>0)?(rho*nabr):0.0 + phi*nabp;

    pic_xx = -f0[1]-f3[1]-f12[1]-2.0*(f2[1]+f8[1]+f9[1])+phi*(1.0+c1*v0-c5*v1-v0v0)-mu;
    pic_yy = -f0[1]-f3[1]-f12[1]-2.0*(f1[1]+f6[1]+f7[1])+phi*(1.0-c5*v0+c1*v1-v1v1)-mu;
    pic_zz = f3[1]+f12[1]+2.0*(f6[1]+f7[1]+f8[1]+f9[1])+phi*(c1*(v0+v1)-v2v2)-mu;
    pic_xy = f0[1]+f3[1]+f12[1]+2.0*(f1[1]+f2[1]+f6[1]+f7[1]+f8[1]+f9[1])+4.0*f4[1]-phi*(1.0-v0)*(1.0-v1);
    pic_xz = 2.0*(f6[1]-f7[1])+phi*v2*(c1-v0);
    pic_yz = 2.0*(f8[1]-f9[1])+phi*v2*(c1-v1);

    f0[1] =mu*lbwpt[0] +phi*         (1.0-             0.5*lbwi[0]*modv)-0.5*(pic_xx+   pic_yy+   pic_zz);
    f1[1] =mu*lbwpt[1] +phi*lbwi[1] *(-v0            +1.5*v0v0-0.5*modv)+ c2* pic_xx-c3*pic_yy-c3*pic_zz;
    f2[1] =mu*lbwpt[2] +phi*lbwi[2] *(-v1            +1.5*v1v1-0.5*modv)- c3* pic_xx+c2*pic_yy-c3*pic_zz;
    f3[1] =mu*lbwpt[3] +phi*lbwi[3] *(-v2            +1.5*v2v2-0.5*modv)- c3* pic_xx-c3*pic_yy+c2*pic_zz;
    f4[1] =mu*lbwpt[4] +phi*lbwi[4] *(-v0-v1+3.0+v0v1-1.5*v2v2    +modv)+ c3* pic_xx+c3*pic_yy-c4*pic_zz+0.25*pic_xy;
    f5[1] =mu*lbwpt[5] +phi*lbwi[5] *(-v0+v1-3.0+v0v1-1.5*v2v2    +modv)+ c3* pic_xx+c3*pic_yy-c4*pic_zz-0.25*pic_xy;
    f6[1] =mu*lbwpt[6] +phi*lbwi[6] *(-v0-v2+3.0+v0v2-1.5*v1v1    +modv)+ c3* pic_xx-c4*pic_yy+c3*pic_zz+0.25*pic_xz;
    f7[1] =mu*lbwpt[7] +phi*lbwi[7] *(-v0+v2-3.0+v0v2-1.5*v1v1    +modv)+ c3* pic_xx-c4*pic_yy+c3*pic_zz-0.25*pic_xz;
    f8[1] =mu*lbwpt[8] +phi*lbwi[8] *(-v1-v2+3.0+v1v2-1.5*v0v0    +modv)- c4* pic_xx+c3*pic_yy+c3*pic_zz+0.25*pic_yz;
    f9[1] =mu*lbwpt[9] +phi*lbwi[9] *(-v1+v2-3.0+v1v2-1.5*v0v0    +modv)- c4* pic_xx+c3*pic_yy+c3*pic_zz-0.25*pic_yz;
    f10[1]=mu*lbwpt[10]+phi*lbwi[10]*( v0            +1.5*v0v0-0.5*modv)+ c2* pic_xx-c3*pic_yy-c3*pic_zz;
    f11[1]=mu*lbwpt[11]+phi*lbwi[11]*( v1            +1.5*v1v1-0.5*modv)- c3* pic_xx+c2*pic_yy-c3*pic_zz;
    f12[1]=mu*lbwpt[12]+phi*lbwi[12]*( v2            +1.5*v2v2-0.5*modv)- c3* pic_xx-c3*pic_yy+c2*pic_zz;
    f13[1]=mu*lbwpt[13]+phi*lbwi[13]*( v0+v1+3.0+v0v1-1.5*v2v2    +modv)+ c3* pic_xx+c3*pic_yy-c4*pic_zz+0.25*pic_xy;
    f14[1]=mu*lbwpt[14]+phi*lbwi[14]*( v0-v1-3.0+v0v1-1.5*v2v2    +modv)+ c3* pic_xx+c3*pic_yy-c4*pic_zz-0.25*pic_xy;
    f15[1]=mu*lbwpt[15]+phi*lbwi[15]*( v0+v2+3.0+v0v2-1.5*v1v1    +modv)+ c3* pic_xx-c4*pic_yy+c3*pic_zz+0.25*pic_xz;
    f16[1]=mu*lbwpt[16]+phi*lbwi[16]*( v0-v2-3.0+v0v2-1.5*v1v1    +modv)+ c3* pic_xx-c4*pic_yy+c3*pic_zz-0.25*pic_xz;
    f17[1]=mu*lbwpt[17]+phi*lbwi[17]*( v1+v2+3.0+v1v2-1.5*v0v0    +modv)- c4* pic_xx+c3*pic_yy+c3*pic_zz+0.25*pic_yz;
    f18[1]=mu*lbwpt[18]+phi*lbwi[18]*( v1-v2-3.0+v1v2-1.5*v0v0    +modv)- c4* pic_xx+c3*pic_yy+c3*pic_zz-0.25*pic_yz;
  }
  else {
    phi = 0.0;
    omegat = omega[0];
    d2rdx2 = drdx*drdx;
    d2rdy2 = drdy*drdy;
    d2rdz2 = drdz*drdz;
    d2rdxdy = drdx*drdy;
    d2rdxdz = drdx*drdz;
    d2rdydz = drdy*drdz;
    nabrp = rho*nabr;
  }
  pb = fGetBulkPressureSwift(rho, phi, T);
  lambda = fGetLambdaSwift(rho, omegat, T);
  udr = drdx*v0 + drdy*v1 + drdz*v2;
    
  pi_xx = -f0[0]-f3[0]-f12[0]-2.0*(f2[0]+f8[0]+f9[0])+rho*(1.0+c1*v0-c5*v1-v0v0)+v0*force[0]-pb+lbkappa*nabrp-0.5*lbkappa*(d2rdx2-d2rdy2-d2rdz2)-2.0*lambda*(2.0*v0*drdx+v1*drdy+v2*drdz);
  pi_yy = -f0[0]-f3[0]-f12[0]-2.0*(f1[0]+f6[0]+f7[0])+rho*(1.0-c5*v0+c1*v1-v1v1)+v1*force[1]-pb+lbkappa*nabrp-0.5*lbkappa*(d2rdx2-d2rdy2+d2rdz2)-2.0*lambda*(v0*drdx+2.0*v1*drdy+v2*drdz);
  pi_zz = f3[0]+f12[0]+2.0*(f6[0]+f7[0]+f8[0]+f9[0])+rho*(c1*(v0+v1)-v2v2)+v2*force[2]-pb+lbkappa*nabrp+0.5*lbkappa*(d2rdx2+d2rdy2-d2rdz2)-2.0*lambda*(v0*drdx+v1*drdy+2.0*v2*drdz);
  pi_xy = f0[0]+f3[0]+f12[0]+2.0*(f1[0]+f2[0]+f6[0]+f7[0]+f8[0]+f9[0])+4.0*f4[0]-rho*(1.0-v0)*(1.0-v1)+0.5*(v1*force[0]+v0*force[1])-lbkappa*d2rdxdy-lambda*(v1*drdx+v0*drdy);
  pi_xz = 2.0*(f6[0]-f7[0])+rho*v2*(c1-v0)+0.5*(v2*force[0]+v0*force[2])-lbkappa*d2rdxdz-lambda*(v2*drdx+v0*drdz);
  pi_yz = 2.0*(f8[0]-f9[0])+rho*v2*(c1-v1)+0.5*(v2*force[1]+v1*force[2])-lbkappa*d2rdydz-lambda*(v2*drdy+v1*drdz);
    
  f0[0] =rho*(lbw0[0]-                    0.5*lbwi[0]*modv)+lambda*lbwdel[0]*udr
        +lbwpt[0] *(pb-lbkappa*nabrp)+lbkappa*(lbwxx[0]*d2rdx2 +lbwyy[0] *d2rdy2+lbwzz[0] *d2rdz2)
        -0.5*(pi_xx+   pi_yy+   pi_zz);
  f1[0] =lbwi [1] *(rho*(-v0            +1.5*v0v0-0.5*modv)+lambda*(3.0*drdx*v0))
        +lbwpt[1] *(pb-lbkappa*nabrp)+lbkappa*(lbwxx[1] *d2rdx2+lbwyy[1] *d2rdy2+lbwzz[1] *d2rdz2)
        + c2* pi_xx-c3*pi_yy-c3*pi_zz;
  f2[0] =lbwi [2] *(rho*(-v1            +1.5*v1v1-0.5*modv)+lambda*(3.0*drdy*v1))
        +lbwpt[2] *(pb-lbkappa*nabrp)+lbkappa*(lbwxx[2] *d2rdx2+lbwyy[2] *d2rdy2+lbwzz[2] *d2rdz2)
        - c3* pi_xx+c2*pi_yy-c3*pi_zz;
  f3[0] =lbwi [3] *(rho*(-v2            +1.5*v2v2-0.5*modv)+lambda*(3.0*drdz*v2))
        +lbwpt[3] *(pb-lbkappa*nabrp)+lbkappa*(lbwxx[3] *d2rdx2+lbwyy[3] *d2rdy2+lbwzz[3] *d2rdz2)
        - c3* pi_xx-c3*pi_yy+c2*pi_zz;
  f4[0] =lbwi [4] *(rho*(-v0-v1+3.0*v0v1-1.5*v2v2    +modv)+lambda*(1.5*udr+3.0*((v0+v1)*drdx+(v0+v1)*drdy)))
        +lbwpt[4] *(pb-lbkappa*nabrp)+lbkappa*(lbwxx[4] *d2rdx2+lbwyy[4] *d2rdy2+lbwzz[4] *d2rdz2+lbwxy[4] *d2rdxdy+lbwxz[4] *d2rdxdz+lbwyz[4] *d2rdydz)
        + c3* pi_xx+c3*pi_yy-c4*pi_zz+0.25*pi_xy;
  f5[0] =lbwi [5] *(rho*(-v0+v1-3.0*v0v1-1.5*v2v2    +modv)+lambda*(1.5*udr+3.0*((v0-v1)*drdx-(v0-v1)*drdy)))
        +lbwpt[5] *(pb-lbkappa*nabrp)+lbkappa*(lbwxx[5] *d2rdx2+lbwyy[5] *d2rdy2+lbwzz[5] *d2rdz2+lbwxy[5] *d2rdxdy+lbwxz[5] *d2rdxdz+lbwyz[5] *d2rdydz)
        + c3* pi_xx+c3*pi_yy-c4*pi_zz-0.25*pi_xy;
  f6[0] =lbwi [6] *(rho*(-v0-v2+3.0*v0v2-1.5*v1v1    +modv)+lambda*(1.5*udr+3.0*((v0+v2)*drdx+(v0+v2)*drdz)))
        +lbwpt[6] *(pb-lbkappa*nabrp)+lbkappa*(lbwxx[6] *d2rdx2+lbwyy[6] *d2rdy2+lbwzz[6] *d2rdz2+lbwxy[6] *d2rdxdy+lbwxz[6] *d2rdxdz+lbwyz[6] *d2rdydz)
        + c3* pi_xx-c4*pi_yy+c3*pi_zz+0.25*pi_xz;
  f7[0] =lbwi [7] *(rho*(-v0+v2-3.0*v0v2-1.5*v1v1    +modv)+lambda*(1.5*udr+3.0*((v0-v2)*drdx-(v0-v2)*drdz)))
        +lbwpt[7] *(pb-lbkappa*nabrp)+lbkappa*(lbwxx[7] *d2rdx2+lbwyy[7] *d2rdy2+lbwzz[7] *d2rdz2+lbwxy[7] *d2rdxdy+lbwxz[7] *d2rdxdz+lbwyz[7] *d2rdydz)
        + c3* pi_xx-c4*pi_yy+c3*pi_zz-0.25*pi_xz;
  f8[0] =lbwi [8] *(rho*(-v1-v2+3.0*v1v2-1.5*v0v0    +modv)+lambda*(1.5*udr+3.0*((v1+v2)*drdy+(v1+v2)*drdz)))
        +lbwpt[8] *(pb-lbkappa*nabrp)+lbkappa*(lbwxx[8] *d2rdx2+lbwyy[8] *d2rdy2+lbwzz[8] *d2rdz2+lbwxy[8] *d2rdxdy+lbwxz[8] *d2rdxdz+lbwyz[8] *d2rdydz)
        - c4* pi_xx+c3*pi_yy+c3*pi_zz+0.25*pi_yz;
  f9[0] =lbwi [9] *(rho*(-v1+v2-3.0*v1v2-1.5*v0v0    +modv)+lambda*(1.5*udr+3.0*((v1-v2)*drdy-(v1-v2)*drdz)))
        +lbwpt[9] *(pb-lbkappa*nabrp)+lbkappa*(lbwxx[9] *d2rdx2+lbwyy[9] *d2rdy2+lbwzz[9] *d2rdz2+lbwxy[9] *d2rdxdy+lbwxz[9] *d2rdxdz+lbwyz[9] *d2rdydz)
        - c4* pi_xx+c3*pi_yy+c3*pi_zz-0.25*pi_yz;
  f10[0]=lbwi [10]*(rho*( v0            +1.5*v0v0-0.5*modv)+lambda*(3.0*drdx*v0))
        +lbwpt[10]*(pb-lbkappa*nabrp)+lbkappa*(lbwxx[10]*d2rdx2+lbwyy[10]*d2rdy2+lbwzz[10]*d2rdz2)
        + c2* pi_xx-c3*pi_yy-c3*pi_zz;
  f11[0]=lbwi [11]*(rho*( v1            +1.5*v1v1-0.5*modv)+lambda*(3.0*drdy*v1))
        +lbwpt[11]*(pb-lbkappa*nabrp)+lbkappa*(lbwxx[11]*d2rdx2+lbwyy[11]*d2rdy2+lbwzz[11]*d2rdz2)
        - c3* pi_xx+c2*pi_yy-c3*pi_zz;
  f12[0]=lbwi [12]*(rho*( v2            +1.5*v2v2-0.5*modv)+lambda*(3.0*drdz*v2))
        +lbwpt[12]*(pb-lbkappa*nabrp)+lbkappa*(lbwxx[12]*d2rdx2+lbwyy[12]*d2rdy2+lbwzz[12]*d2rdz2)
        - c3* pi_xx-c3*pi_yy+c2*pi_zz;
  f13[0]=lbwi [13]*(rho*( v0+v1+3.0*v0v1-1.5*v2v2    +modv)+lambda*(1.5*udr+3.0*((v0+v1)*drdx+(v0+v1)*drdy)))
        +lbwpt[13]*(pb-lbkappa*nabrp)+lbkappa*(lbwxx[13]*d2rdx2+lbwyy[13]*d2rdy2+lbwzz[13]*d2rdz2+lbwxy[13]*d2rdxdy+lbwxz[13]*d2rdxdz+lbwyz[13]*d2rdydz)
        + c3* pi_xx+c3*pi_yy-c4*pi_zz+0.25*pi_xy;
  f14[0]=lbwi [14]*(rho*( v0-v1-3.0*v0v1-1.5*v2v2    +modv)+lambda*(1.5*udr+3.0*((v0-v1)*drdx-(v0-v1)*drdy)))
        +lbwpt[14]*(pb-lbkappa*nabrp)+lbkappa*(lbwxx[14]*d2rdx2+lbwyy[14]*d2rdy2+lbwzz[14]*d2rdz2+lbwxy[14]*d2rdxdy+lbwxz[14]*d2rdxdz+lbwyz[14]*d2rdydz)
        + c3* pi_xx+c3*pi_yy-c4*pi_zz-0.25*pi_xy;
  f15[0]=lbwi [15]*(rho*( v0+v2+3.0*v0v2-1.5*v1v1    +modv)+lambda*(1.5*udr+3.0*((v0+v2)*drdx+(v0+v2)*drdz)))
        +lbwpt[15]*(pb-lbkappa*nabrp)+lbkappa*(lbwxx[15]*d2rdx2+lbwyy[15]*d2rdy2+lbwzz[15]*d2rdz2+lbwxy[15]*d2rdxdy+lbwxz[15]*d2rdxdz+lbwyz[15]*d2rdydz)
        + c3* pi_xx-c4*pi_yy+c3*pi_zz+0.25*pi_xz;
  f16[0]=lbwi [16]*(rho*( v0-v2-3.0*v0v2-1.5*v1v1    +modv)+lambda*(1.5*udr+3.0*((v0-v2)*drdx-(v0-v2)*drdz)))
        +lbwpt[16]*(pb-lbkappa*nabrp)+lbkappa*(lbwxx[16]*d2rdx2+lbwyy[16]*d2rdy2+lbwzz[16]*d2rdz2+lbwxy[16]*d2rdxdy+lbwxz[16]*d2rdxdz+lbwyz[16]*d2rdydz)
        + c3* pi_xx-c4*pi_yy+c3*pi_zz-0.25*pi_xz;
  f17[0]=lbwi [17]*(rho*( v1+v2+3.0*v1v2-1.5*v0v0    +modv)+lambda*(1.5*udr+3.0*((v1+v2)*drdy+(v1+v2)*drdz)))
        +lbwpt[17]*(pb-lbkappa*nabrp)+lbkappa*(lbwxx[17]*d2rdx2+lbwyy[17]*d2rdy2+lbwzz[17]*d2rdz2+lbwxy[17]*d2rdxdy+lbwxz[17]*d2rdxdz+lbwyz[17]*d2rdydz)
        - c4* pi_xx+c3*pi_yy+c3*pi_zz+0.25*pi_yz;
  f18[0]=lbwi [18]*(rho*( v1-v2-3.0*v1v2-1.5*v0v0    +modv)+lambda*(1.5*udr+3.0*((v1-v2)*drdy-(v1-v2)*drdz)))
        +lbwpt[18]*(pb-lbkappa*nabrp)+lbkappa*(lbwxx[18]*d2rdx2+lbwyy[18]*d2rdy2+lbwzz[18]*d2rdz2+lbwxy[18]*d2rdxdy+lbwxz[18]*d2rdxdz+lbwyz[18]*d2rdydz)
        - c4* pi_xx+c3*pi_yy+c3*pi_zz-0.25*pi_yz;
  return 0;
}

int fD3Q19VCCSwiftRegular(double *p, double v0, double v1, double v2, double *force,
                          double *f0, double *f1, double *f2, double *f3, double *f4,
                          double *f5, double *f6, double *f7, double *f8, double *f9,
                          double *f10, double *f11, double *f12, double *f13, double *f14,
                          double *f15, double *f16, double *f17, double *f18,
                          double drdx, double drdy, double drdz, double dpdx, double dpdy, double dpdz,
                          double nabr, double nabp, double *omega, double T)
{

  // produce fixed velocity for compressible/incompressible fluids at concave corner boundary:
  // expressed for bottom left back corner (VCCTRF)

  double rho, phi, omegat, pb, mu, lambda, d2rdx2, d2rdy2, d2rdz2, d2rdxdy, d2rdxdz, d2rdydz, nabrp, modv;
  double v0v0, v0v1, v0v2, v1v1, v1v2, v2v2, udr;
  double pi_xx, pi_yy, pi_zz, pi_xy, pi_xz, pi_yz, pic_xx, pic_yy, pic_zz, pic_xy, pic_xz, pic_yz;
  double c1=1.0/3.0,c2=1.0/6.0,c3=1.0/12.0,c4=1.0/24.0,c5=2.0/3.0,c6=4.0/3.0,c7=2.0/9.0,c8=5.0/18.0,c9=7.0/18.0,c10=8.0/3.0;

  v0v0 = v0*v0;
  v0v1 = v0*v1;
  v0v2 = v0*v2;
  v1v1 = v1*v1;
  v1v2 = v1*v2;
  v2v2 = v2*v2;
  modv = v0v0 + v1v1 + v2v2;
  rho = p[0];
  if(lbsy.nf>1) {
    phi = p[1];
    omegat = 0.5*(1.0+phi)*omega[0]+0.5*(1.0-phi)*omega[1];
    mu = lbfemob*fGetPotentialSwift(phi, nabp);
    d2rdx2 = (lbfeeos>0)?(drdx*drdx):0.0 + dpdx*dpdx;
    d2rdy2 = (lbfeeos>0)?(drdy*drdy):0.0 + dpdy*dpdy;
    d2rdz2 = (lbfeeos>0)?(drdz*drdz):0.0 + dpdz*dpdz;
    d2rdxdy = (lbfeeos>0)?(drdx*drdy):0.0 + dpdx*dpdy;
    d2rdxdz = (lbfeeos>0)?(drdx*drdz):0.0 + dpdx*dpdz;
    d2rdydz = (lbfeeos>0)?(drdy*drdz):0.0 + dpdy*dpdz;
    nabrp = (lbfeeos>0)?(rho*nabr):0.0 + phi*nabp;

    pic_xx = c5*(f1[1]+f4[1]+f6[1]-f0[1])-c6*(f2[1]+f3[1]+f8[1])+phi*(c5+c7*v0-c8*(v1+v2)-v0v0)-mu;
    pic_yy = c5*(f2[1]+f4[1]+f8[1]-f0[1])-c6*(f1[1]+f3[1]+f6[1])+phi*(c5+c7*v1-c8*(v0+v2)-v1v1)-mu;
    pic_zz = c5*(f3[1]+f6[1]+f8[1]-f0[1])-c6*(f1[1]+f2[1]+f4[1])+phi*(c5+c7*v2-c8*(v0+v1)-v2v2)-mu;
    pic_xy = c1*f0[1]+c5*(f1[1]+f2[1]+f3[1]+f6[1]+f8[1])+c10*f4[1]-phi*(c1-c9*(v0+v1)-c7*v2+v0v1);
    pic_xz = c1*f0[1]+c5*(f1[1]+f2[1]+f3[1]+f4[1]+f8[1])+c10*f6[1]-phi*(c1-c9*(v0+v2)-c7*v1+v0v2);
    pic_yz = c1*f0[1]+c5*(f1[1]+f2[1]+f3[1]+f4[1]+f6[1])+c10*f8[1]-phi*(c1-c9*(v1+v2)-c7*v0+v1v2);

    f0[1] =mu*lbwpt[0] +phi*         (1.0-             0.5*lbwi[0]*modv)-0.5*(pic_xx+   pic_yy+   pic_zz);
    f1[1] =mu*lbwpt[1] +phi*lbwi[1] *(-v0            +1.5*v0v0-0.5*modv)+ c2* pic_xx-c3*pic_yy-c3*pic_zz;
    f2[1] =mu*lbwpt[2] +phi*lbwi[2] *(-v1            +1.5*v1v1-0.5*modv)- c3* pic_xx+c2*pic_yy-c3*pic_zz;
    f3[1] =mu*lbwpt[3] +phi*lbwi[3] *(-v2            +1.5*v2v2-0.5*modv)- c3* pic_xx-c3*pic_yy+c2*pic_zz;
    f4[1] =mu*lbwpt[4] +phi*lbwi[4] *(-v0-v1+3.0+v0v1-1.5*v2v2    +modv)+ c3* pic_xx+c3*pic_yy-c4*pic_zz+0.25*pic_xy;
    f5[1] =mu*lbwpt[5] +phi*lbwi[5] *(-v0+v1-3.0+v0v1-1.5*v2v2    +modv)+ c3* pic_xx+c3*pic_yy-c4*pic_zz-0.25*pic_xy;
    f6[1] =mu*lbwpt[6] +phi*lbwi[6] *(-v0-v2+3.0+v0v2-1.5*v1v1    +modv)+ c3* pic_xx-c4*pic_yy+c3*pic_zz+0.25*pic_xz;
    f7[1] =mu*lbwpt[7] +phi*lbwi[7] *(-v0+v2-3.0+v0v2-1.5*v1v1    +modv)+ c3* pic_xx-c4*pic_yy+c3*pic_zz-0.25*pic_xz;
    f8[1] =mu*lbwpt[8] +phi*lbwi[8] *(-v1-v2+3.0+v1v2-1.5*v0v0    +modv)- c4* pic_xx+c3*pic_yy+c3*pic_zz+0.25*pic_yz;
    f9[1] =mu*lbwpt[9] +phi*lbwi[9] *(-v1+v2-3.0+v1v2-1.5*v0v0    +modv)- c4* pic_xx+c3*pic_yy+c3*pic_zz-0.25*pic_yz;
    f10[1]=mu*lbwpt[10]+phi*lbwi[10]*( v0            +1.5*v0v0-0.5*modv)+ c2* pic_xx-c3*pic_yy-c3*pic_zz;
    f11[1]=mu*lbwpt[11]+phi*lbwi[11]*( v1            +1.5*v1v1-0.5*modv)- c3* pic_xx+c2*pic_yy-c3*pic_zz;
    f12[1]=mu*lbwpt[12]+phi*lbwi[12]*( v2            +1.5*v2v2-0.5*modv)- c3* pic_xx-c3*pic_yy+c2*pic_zz;
    f13[1]=mu*lbwpt[13]+phi*lbwi[13]*( v0+v1+3.0+v0v1-1.5*v2v2    +modv)+ c3* pic_xx+c3*pic_yy-c4*pic_zz+0.25*pic_xy;
    f14[1]=mu*lbwpt[14]+phi*lbwi[14]*( v0-v1-3.0+v0v1-1.5*v2v2    +modv)+ c3* pic_xx+c3*pic_yy-c4*pic_zz-0.25*pic_xy;
    f15[1]=mu*lbwpt[15]+phi*lbwi[15]*( v0+v2+3.0+v0v2-1.5*v1v1    +modv)+ c3* pic_xx-c4*pic_yy+c3*pic_zz+0.25*pic_xz;
    f16[1]=mu*lbwpt[16]+phi*lbwi[16]*( v0-v2-3.0+v0v2-1.5*v1v1    +modv)+ c3* pic_xx-c4*pic_yy+c3*pic_zz-0.25*pic_xz;
    f17[1]=mu*lbwpt[17]+phi*lbwi[17]*( v1+v2+3.0+v1v2-1.5*v0v0    +modv)- c4* pic_xx+c3*pic_yy+c3*pic_zz+0.25*pic_yz;
    f18[1]=mu*lbwpt[18]+phi*lbwi[18]*( v1-v2-3.0+v1v2-1.5*v0v0    +modv)- c4* pic_xx+c3*pic_yy+c3*pic_zz-0.25*pic_yz;
  }
  else {
    phi = 0.0;
    omegat = omega[0];
    d2rdx2 = drdx*drdx;
    d2rdy2 = drdy*drdy;
    d2rdz2 = drdz*drdz;
    d2rdxdy = drdx*drdy;
    d2rdxdz = drdx*drdz;
    d2rdydz = drdy*drdz;
    nabrp = rho*nabr;
  }
  pb = fGetBulkPressureSwift(rho, phi, T);
  lambda = fGetLambdaSwift(rho, omegat, T);
  udr = drdx*v0 + drdy*v1 + drdz*v2;

  pi_xx = c5*(f1[0]+f4[0]+f6[0]-f0[0])-c6*(f2[0]+f3[0]+f8[0])+rho*(c5+c7*v0-c8*(v1+v2)-v0v0)+v0*force[0]-pb+lbkappa*nabrp-0.5*lbkappa*(d2rdx2-d2rdy2-d2rdz2)-2.0*lambda*(2.0*v0*drdx+v1*drdy+v2*drdz);
  pi_yy = c5*(f2[0]+f4[0]+f8[0]-f0[0])-c6*(f1[0]+f3[0]+f6[0])+rho*(c5+c7*v1-c8*(v0+v2)-v1v1)+v1*force[1]-pb+lbkappa*nabrp-0.5*lbkappa*(d2rdx2-d2rdy2+d2rdz2)-2.0*lambda*(v0*drdx+2.0*v1*drdy+v2*drdz);
  pi_zz = c5*(f3[0]+f6[0]+f8[0]-f0[0])-c6*(f1[0]+f2[0]+f4[0])+rho*(c5+c7*v2-c8*(v0+v1)-v2v2)+v2*force[2]-pb+lbkappa*nabrp+0.5*lbkappa*(d2rdx2+d2rdy2-d2rdz2)-2.0*lambda*(v0*drdx+v1*drdy+2.0*v2*drdz);
  pi_xy = c1*f0[0]+c5*(f1[0]+f2[0]+f3[0]+f6[0]+f8[0])+c10*f4[0]-rho*(c1-c9*(v0+v1)-c7*v2+v0v1)+0.5*(v1*force[0]+v0*force[1])-lbkappa*d2rdxdy-lambda*(v1*drdx+v0*drdy);
  pi_xz = c1*f0[0]+c5*(f1[0]+f2[0]+f3[0]+f4[0]+f8[0])+c10*f6[0]-rho*(c1-c9*(v0+v2)-c7*v1+v0v2)+0.5*(v2*force[0]+v0*force[2])-lbkappa*d2rdxdz-lambda*(v2*drdx+v0*drdz);
  pi_yz = c1*f0[0]+c5*(f1[0]+f2[0]+f3[0]+f4[0]+f6[0])+c10*f8[0]-rho*(c1-c9*(v1+v2)-c7*v0+v1v2)+0.5*(v2*force[1]+v1*force[2])-lbkappa*d2rdydz-lambda*(v2*drdy+v1*drdz);

  f0[0] =rho*(lbw0[0]-                    0.5*lbwi[0]*modv)+lambda*lbwdel[0]*udr
        +lbwpt[0] *(pb-lbkappa*nabrp)+lbkappa*(lbwxx[0]*d2rdx2 +lbwyy[0] *d2rdy2+lbwzz[0] *d2rdz2)
        -0.5*(pi_xx+   pi_yy+   pi_zz);
  f1[0] =lbwi [1] *(rho*(-v0            +1.5*v0v0-0.5*modv)+lambda*(3.0*drdx*v0))
        +lbwpt[1] *(pb-lbkappa*nabrp)+lbkappa*(lbwxx[1] *d2rdx2+lbwyy[1] *d2rdy2+lbwzz[1] *d2rdz2)
        + c2* pi_xx-c3*pi_yy-c3*pi_zz;
  f2[0] =lbwi [2] *(rho*(-v1            +1.5*v1v1-0.5*modv)+lambda*(3.0*drdy*v1))
        +lbwpt[2] *(pb-lbkappa*nabrp)+lbkappa*(lbwxx[2] *d2rdx2+lbwyy[2] *d2rdy2+lbwzz[2] *d2rdz2)
        - c3* pi_xx+c2*pi_yy-c3*pi_zz;
  f3[0] =lbwi [3] *(rho*(-v2            +1.5*v2v2-0.5*modv)+lambda*(3.0*drdz*v2))
        +lbwpt[3] *(pb-lbkappa*nabrp)+lbkappa*(lbwxx[3] *d2rdx2+lbwyy[3] *d2rdy2+lbwzz[3] *d2rdz2)
        - c3* pi_xx-c3*pi_yy+c2*pi_zz;
  f4[0] =lbwi [4] *(rho*(-v0-v1+3.0*v0v1-1.5*v2v2    +modv)+lambda*(1.5*udr+3.0*((v0+v1)*drdx+(v0+v1)*drdy)))
        +lbwpt[4] *(pb-lbkappa*nabrp)+lbkappa*(lbwxx[4] *d2rdx2+lbwyy[4] *d2rdy2+lbwzz[4] *d2rdz2+lbwxy[4] *d2rdxdy+lbwxz[4] *d2rdxdz+lbwyz[4] *d2rdydz)
        + c3* pi_xx+c3*pi_yy-c4*pi_zz+0.25*pi_xy;
  f5[0] =lbwi [5] *(rho*(-v0+v1-3.0*v0v1-1.5*v2v2    +modv)+lambda*(1.5*udr+3.0*((v0-v1)*drdx-(v0-v1)*drdy)))
        +lbwpt[5] *(pb-lbkappa*nabrp)+lbkappa*(lbwxx[5] *d2rdx2+lbwyy[5] *d2rdy2+lbwzz[5] *d2rdz2+lbwxy[5] *d2rdxdy+lbwxz[5] *d2rdxdz+lbwyz[5] *d2rdydz)
        + c3* pi_xx+c3*pi_yy-c4*pi_zz-0.25*pi_xy;
  f6[0] =lbwi [6] *(rho*(-v0-v2+3.0*v0v2-1.5*v1v1    +modv)+lambda*(1.5*udr+3.0*((v0+v2)*drdx+(v0+v2)*drdz)))
        +lbwpt[6] *(pb-lbkappa*nabrp)+lbkappa*(lbwxx[6] *d2rdx2+lbwyy[6] *d2rdy2+lbwzz[6] *d2rdz2+lbwxy[6] *d2rdxdy+lbwxz[6] *d2rdxdz+lbwyz[6] *d2rdydz)
        + c3* pi_xx-c4*pi_yy+c3*pi_zz+0.25*pi_xz;
  f7[0] =lbwi [7] *(rho*(-v0+v2-3.0*v0v2-1.5*v1v1    +modv)+lambda*(1.5*udr+3.0*((v0-v2)*drdx-(v0-v2)*drdz)))
        +lbwpt[7] *(pb-lbkappa*nabrp)+lbkappa*(lbwxx[7] *d2rdx2+lbwyy[7] *d2rdy2+lbwzz[7] *d2rdz2+lbwxy[7] *d2rdxdy+lbwxz[7] *d2rdxdz+lbwyz[7] *d2rdydz)
        + c3* pi_xx-c4*pi_yy+c3*pi_zz-0.25*pi_xz;
  f8[0] =lbwi [8] *(rho*(-v1-v2+3.0*v1v2-1.5*v0v0    +modv)+lambda*(1.5*udr+3.0*((v1+v2)*drdy+(v1+v2)*drdz)))
        +lbwpt[8] *(pb-lbkappa*nabrp)+lbkappa*(lbwxx[8] *d2rdx2+lbwyy[8] *d2rdy2+lbwzz[8] *d2rdz2+lbwxy[8] *d2rdxdy+lbwxz[8] *d2rdxdz+lbwyz[8] *d2rdydz)
        - c4* pi_xx+c3*pi_yy+c3*pi_zz+0.25*pi_yz;
  f9[0] =lbwi [9] *(rho*(-v1+v2-3.0*v1v2-1.5*v0v0    +modv)+lambda*(1.5*udr+3.0*((v1-v2)*drdy-(v1-v2)*drdz)))
        +lbwpt[9] *(pb-lbkappa*nabrp)+lbkappa*(lbwxx[9] *d2rdx2+lbwyy[9] *d2rdy2+lbwzz[9] *d2rdz2+lbwxy[9] *d2rdxdy+lbwxz[9] *d2rdxdz+lbwyz[9] *d2rdydz)
        - c4* pi_xx+c3*pi_yy+c3*pi_zz-0.25*pi_yz;
  f10[0]=lbwi [10]*(rho*( v0            +1.5*v0v0-0.5*modv)+lambda*(3.0*drdx*v0))
        +lbwpt[10]*(pb-lbkappa*nabrp)+lbkappa*(lbwxx[10]*d2rdx2+lbwyy[10]*d2rdy2+lbwzz[10]*d2rdz2)
        + c2* pi_xx-c3*pi_yy-c3*pi_zz;
  f11[0]=lbwi [11]*(rho*( v1            +1.5*v1v1-0.5*modv)+lambda*(3.0*drdy*v1))
        +lbwpt[11]*(pb-lbkappa*nabrp)+lbkappa*(lbwxx[11]*d2rdx2+lbwyy[11]*d2rdy2+lbwzz[11]*d2rdz2)
        - c3* pi_xx+c2*pi_yy-c3*pi_zz;
  f12[0]=lbwi [12]*(rho*( v2            +1.5*v2v2-0.5*modv)+lambda*(3.0*drdz*v2))
        +lbwpt[12]*(pb-lbkappa*nabrp)+lbkappa*(lbwxx[12]*d2rdx2+lbwyy[12]*d2rdy2+lbwzz[12]*d2rdz2)
        - c3* pi_xx-c3*pi_yy+c2*pi_zz;
  f13[0]=lbwi [13]*(rho*( v0+v1+3.0*v0v1-1.5*v2v2    +modv)+lambda*(1.5*udr+3.0*((v0+v1)*drdx+(v0+v1)*drdy)))
        +lbwpt[13]*(pb-lbkappa*nabrp)+lbkappa*(lbwxx[13]*d2rdx2+lbwyy[13]*d2rdy2+lbwzz[13]*d2rdz2+lbwxy[13]*d2rdxdy+lbwxz[13]*d2rdxdz+lbwyz[13]*d2rdydz)
        + c3* pi_xx+c3*pi_yy-c4*pi_zz+0.25*pi_xy;
  f14[0]=lbwi [14]*(rho*( v0-v1-3.0*v0v1-1.5*v2v2    +modv)+lambda*(1.5*udr+3.0*((v0-v1)*drdx-(v0-v1)*drdy)))
        +lbwpt[14]*(pb-lbkappa*nabrp)+lbkappa*(lbwxx[14]*d2rdx2+lbwyy[14]*d2rdy2+lbwzz[14]*d2rdz2+lbwxy[14]*d2rdxdy+lbwxz[14]*d2rdxdz+lbwyz[14]*d2rdydz)
        + c3* pi_xx+c3*pi_yy-c4*pi_zz-0.25*pi_xy;
  f15[0]=lbwi [15]*(rho*( v0+v2+3.0*v0v2-1.5*v1v1    +modv)+lambda*(1.5*udr+3.0*((v0+v2)*drdx+(v0+v2)*drdz)))
        +lbwpt[15]*(pb-lbkappa*nabrp)+lbkappa*(lbwxx[15]*d2rdx2+lbwyy[15]*d2rdy2+lbwzz[15]*d2rdz2+lbwxy[15]*d2rdxdy+lbwxz[15]*d2rdxdz+lbwyz[15]*d2rdydz)
        + c3* pi_xx-c4*pi_yy+c3*pi_zz+0.25*pi_xz;
  f16[0]=lbwi [16]*(rho*( v0-v2-3.0*v0v2-1.5*v1v1    +modv)+lambda*(1.5*udr+3.0*((v0-v2)*drdx-(v0-v2)*drdz)))
        +lbwpt[16]*(pb-lbkappa*nabrp)+lbkappa*(lbwxx[16]*d2rdx2+lbwyy[16]*d2rdy2+lbwzz[16]*d2rdz2+lbwxy[16]*d2rdxdy+lbwxz[16]*d2rdxdz+lbwyz[16]*d2rdydz)
        + c3* pi_xx-c4*pi_yy+c3*pi_zz-0.25*pi_xz;
  f17[0]=lbwi [17]*(rho*( v1+v2+3.0*v1v2-1.5*v0v0    +modv)+lambda*(1.5*udr+3.0*((v1+v2)*drdy+(v1+v2)*drdz)))
        +lbwpt[17]*(pb-lbkappa*nabrp)+lbkappa*(lbwxx[17]*d2rdx2+lbwyy[17]*d2rdy2+lbwzz[17]*d2rdz2+lbwxy[17]*d2rdxdy+lbwxz[17]*d2rdxdz+lbwyz[17]*d2rdydz)
        - c4* pi_xx+c3*pi_yy+c3*pi_zz+0.25*pi_yz;
  f18[0]=lbwi [18]*(rho*( v1-v2-3.0*v1v2-1.5*v0v0    +modv)+lambda*(1.5*udr+3.0*((v1-v2)*drdy-(v1-v2)*drdz)))
        +lbwpt[18]*(pb-lbkappa*nabrp)+lbkappa*(lbwxx[18]*d2rdx2+lbwyy[18]*d2rdy2+lbwzz[18]*d2rdz2+lbwxy[18]*d2rdxdy+lbwxz[18]*d2rdxdz+lbwyz[18]*d2rdydz)
        - c4* pi_xx+c3*pi_yy+c3*pi_zz-0.25*pi_yz;
  return 0;
}

int fD3Q19VFRegular(long tpos, long rpos, int prop, double *uwall, double dx, double dy, double dz, double T)
{
  long spos=tpos * lbsitelength;
  int qdim=lbsy.nf+lbsy.nc+lbsy.nt;
  double drdx, drdy, drdz, dpdx, dpdy, dpdz, nabr, nabp;
  double force[3*lbsy.nf], rho[lbsy.nf];
    
  fD3Q19BoundaryForceVelocity(force, tpos, rpos, dx, dy, dz, uwall, prop);

  if(interact==20) {
    drdx = lbft[4*lbsy.nf*rpos  ];
    drdy = lbft[4*lbsy.nf*rpos+1];
    drdz = lbft[4*lbsy.nf*rpos+2];
    nabr = lbft[4*lbsy.nf*tpos+3];
    dpdx = (lbsy.nf>1)?lbft[4*lbsy.nf*rpos+4]:0.0;
    dpdy = (lbsy.nf>1)?lbft[4*lbsy.nf*rpos+5]:0.0;
    dpdz = (lbsy.nf>1)?lbft[4*lbsy.nf*rpos+6]:0.0;
    nabp = (lbsy.nf>1)?lbft[4*lbsy.nf*tpos+7]:0.0;
  }
  else {
    drdx = 0.0;
    drdy = 0.0;
    drdz = 0.0;
    nabr = 0.0;
    dpdx = 0.0;
    dpdy = 0.0;
    dpdz = 0.0;
    nabp = 0.0;
  }
    
  if(prop>26) {
    fGetAllMassSite(rho, &lbf[rpos*lbsitelength]);
    if(interact==20) {
      rho[0] += (dx*drdx+dy*drdy+dz*drdz);
      if(lbsy.nf>1)
        rho[1] += (dx*dpdx+dy*dpdy+dz*dpdz);
    }
  }

  if(interact==20) {
    switch (prop) {
      case PST:
        fD3Q19VPSSwiftRegular(uwall[0], uwall[1], uwall[2], &force[0], &lbf[spos], &lbf[spos+1*qdim],
                              &lbf[spos+2*qdim], &lbf[spos+3*qdim], &lbf[spos+4*qdim], &lbf[spos+5*qdim],
                              &lbf[spos+6*qdim], &lbf[spos+7*qdim], &lbf[spos+8*qdim], &lbf[spos+9*qdim],
                              &lbf[spos+10*qdim], &lbf[spos+11*qdim], &lbf[spos+12*qdim], &lbf[spos+13*qdim],
                              &lbf[spos+14*qdim], &lbf[spos+15*qdim], &lbf[spos+16*qdim], &lbf[spos+17*qdim],
                              &lbf[spos+18*qdim], drdx, drdy, drdz, dpdx, dpdy, dpdz, nabr, nabp,
                              &lbomega[lbsy.nf*tpos], T);
        break;
      case PSD:
        fD3Q19VPSSwiftRegular(-uwall[0], -uwall[1], -uwall[2], &force[0], &lbf[spos], &lbf[spos+10*qdim],
                              &lbf[spos+11*qdim], &lbf[spos+12*qdim], &lbf[spos+13*qdim], &lbf[spos+14*qdim],
                              &lbf[spos+15*qdim], &lbf[spos+16*qdim], &lbf[spos+17*qdim], &lbf[spos+18*qdim],
                              &lbf[spos+1*qdim], &lbf[spos+2*qdim], &lbf[spos+3*qdim], &lbf[spos+4*qdim],
                              &lbf[spos+5*qdim], &lbf[spos+6*qdim], &lbf[spos+7*qdim], &lbf[spos+8*qdim],
                              &lbf[spos+9*qdim], -drdx, -drdy, -drdz, -dpdx, -dpdy, -dpdz, nabr, nabp,
                              &lbomega[lbsy.nf*tpos], T);
        break;
      case PSL:
        fD3Q19VPSSwiftRegular(-uwall[2], -uwall[0], -uwall[1], &force[0], &lbf[spos], &lbf[spos+12*qdim],
                              &lbf[spos+10*qdim], &lbf[spos+11*qdim], &lbf[spos+15*qdim], &lbf[spos+7*qdim],
                              &lbf[spos+17*qdim], &lbf[spos+9*qdim], &lbf[spos+13*qdim], &lbf[spos+14*qdim],
                              &lbf[spos+3*qdim], &lbf[spos+1*qdim], &lbf[spos+2*qdim], &lbf[spos+6*qdim],
                              &lbf[spos+16*qdim], &lbf[spos+8*qdim], &lbf[spos+18*qdim], &lbf[spos+4*qdim],
                              &lbf[spos+5*qdim], -drdz, -drdx, -drdy, -dpdz, -dpdx, -dpdy, nabr, nabp,
                              &lbomega[lbsy.nf*tpos], T);
        break;
      case PSR:
        fD3Q19VPSSwiftRegular(uwall[2], uwall[0], uwall[1], &force[0], &lbf[spos], &lbf[spos+3*qdim],
                              &lbf[spos+1*qdim], &lbf[spos+2*qdim], &lbf[spos+6*qdim], &lbf[spos+16*qdim],
                              &lbf[spos+8*qdim], &lbf[spos+18*qdim], &lbf[spos+4*qdim], &lbf[spos+5*qdim],
                              &lbf[spos+12*qdim], &lbf[spos+10*qdim], &lbf[spos+11*qdim], &lbf[spos+15*qdim],
                              &lbf[spos+7*qdim], &lbf[spos+17*qdim], &lbf[spos+9*qdim], &lbf[spos+13*qdim],
                              &lbf[spos+14*qdim], drdz, drdx, drdy, dpdz, dpdx, dpdy, nabr, nabp,
                              &lbomega[lbsy.nf*tpos], T);
        break;
      case PSF:
        fD3Q19VPSSwiftRegular(-uwall[1], -uwall[2], -uwall[0], &force[0], &lbf[spos], &lbf[spos+11*qdim],
                              &lbf[spos+12*qdim], &lbf[spos+10*qdim], &lbf[spos+17*qdim], &lbf[spos+18*qdim],
                              &lbf[spos+13*qdim], &lbf[spos+5*qdim], &lbf[spos+15*qdim], &lbf[spos+7*qdim],
                              &lbf[spos+2*qdim], &lbf[spos+3*qdim], &lbf[spos+1*qdim], &lbf[spos+8*qdim],
                              &lbf[spos+9*qdim], &lbf[spos+4*qdim], &lbf[spos+14*qdim], &lbf[spos+6*qdim],
                              &lbf[spos+16*qdim], -drdy, -drdz, -drdx, -dpdy, -dpdz, -dpdx, nabr, nabp,
                              &lbomega[lbsy.nf*tpos], T);
        break;
      case PSB:
        fD3Q19VPSSwiftRegular(uwall[1], uwall[2], uwall[0], &force[0], &lbf[spos], &lbf[spos+2*qdim],
                              &lbf[spos+3*qdim], &lbf[spos+1*qdim], &lbf[spos+8*qdim], &lbf[spos+9*qdim],
                              &lbf[spos+4*qdim], &lbf[spos+14*qdim], &lbf[spos+6*qdim], &lbf[spos+16*qdim],
                              &lbf[spos+11*qdim], &lbf[spos+12*qdim], &lbf[spos+10*qdim], &lbf[spos+17*qdim],
                              &lbf[spos+18*qdim], &lbf[spos+13*qdim], &lbf[spos+5*qdim], &lbf[spos+15*qdim],
                              &lbf[spos+7*qdim], drdy, drdz, drdx, dpdy, dpdz, dpdx, nabr, nabp,
                              &lbomega[lbsy.nf*tpos], T);
        break;
      case CCTRB:
        fD3Q19VCCSwiftRegular(rho, uwall[0], uwall[1], -uwall[2], &force[0], &lbf[spos], &lbf[spos+1*qdim],
                              &lbf[spos+2*qdim], &lbf[spos+12*qdim], &lbf[spos+4*qdim], &lbf[spos+5*qdim],
                              &lbf[spos+7*qdim], &lbf[spos+6*qdim], &lbf[spos+9*qdim], &lbf[spos+8*qdim],
                              &lbf[spos+10*qdim], &lbf[spos+11*qdim], &lbf[spos+3*qdim], &lbf[spos+13*qdim],
                              &lbf[spos+14*qdim], &lbf[spos+16*qdim], &lbf[spos+15*qdim], &lbf[spos+18*qdim],
                              &lbf[spos+17*qdim], drdx, drdy, -drdz, dpdx, dpdy, -dpdz, nabr, nabp,
                              &lbomega[lbsy.nf*tpos], T);
        break;
      case CCTLB:
        fD3Q19VCCSwiftRegular(rho, -uwall[0], uwall[1], -uwall[2], &force[0], &lbf[spos], &lbf[spos+10*qdim],
                              &lbf[spos+2*qdim], &lbf[spos+12*qdim], &lbf[spos+14*qdim], &lbf[spos+13*qdim],
                              &lbf[spos+15*qdim], &lbf[spos+16*qdim], &lbf[spos+9*qdim], &lbf[spos+8*qdim],
                              &lbf[spos+1*qdim], &lbf[spos+11*qdim], &lbf[spos+3*qdim], &lbf[spos+5*qdim],
                              &lbf[spos+4*qdim], &lbf[spos+6*qdim], &lbf[spos+7*qdim], &lbf[spos+18*qdim],
                              &lbf[spos+17*qdim], -drdx, drdy, -drdz, -dpdx, dpdy, -dpdz, nabr, nabp,
                              &lbomega[lbsy.nf*tpos], T);
        break;
      case CCDLB:
        fD3Q19VCCSwiftRegular(rho, -uwall[0], -uwall[1], -uwall[2], &force[0], &lbf[spos], &lbf[spos+10*qdim],
                              &lbf[spos+11*qdim], &lbf[spos+12*qdim], &lbf[spos+13*qdim], &lbf[spos+14*qdim],
                              &lbf[spos+15*qdim], &lbf[spos+16*qdim], &lbf[spos+17*qdim], &lbf[spos+18*qdim],
                              &lbf[spos+1*qdim], &lbf[spos+2*qdim], &lbf[spos+3*qdim], &lbf[spos+4*qdim],
                              &lbf[spos+5*qdim], &lbf[spos+6*qdim], &lbf[spos+7*qdim], &lbf[spos+8*qdim],
                              &lbf[spos+9*qdim], -drdx, -drdy, -drdz, -dpdx, -dpdy, -dpdz, nabr, nabp,
                              &lbomega[lbsy.nf*tpos], T);
        break;
      case CCDRB:
        fD3Q19VCCSwiftRegular(rho, uwall[0], -uwall[1], -uwall[2], &force[0], &lbf[spos], &lbf[spos+1*qdim],
                              &lbf[spos+11*qdim], &lbf[spos+12*qdim], &lbf[spos+5*qdim], &lbf[spos+4*qdim],
                              &lbf[spos+7*qdim], &lbf[spos+6*qdim], &lbf[spos+17*qdim], &lbf[spos+18*qdim],
                              &lbf[spos+10*qdim], &lbf[spos+2*qdim], &lbf[spos+3*qdim], &lbf[spos+14*qdim],
                              &lbf[spos+13*qdim], &lbf[spos+16*qdim], &lbf[spos+15*qdim], &lbf[spos+8*qdim],
                              &lbf[spos+9*qdim], drdx, -drdy, -drdz, dpdx, -dpdy, -dpdz, nabr, nabp,
                              &lbomega[lbsy.nf*tpos], T);
        break;
      case CCTRF:
        fD3Q19VCCSwiftRegular(rho, uwall[0], uwall[1], uwall[2], &force[0], &lbf[spos], &lbf[spos+1*qdim],
                              &lbf[spos+2*qdim], &lbf[spos+3*qdim], &lbf[spos+4*qdim], &lbf[spos+5*qdim],
                              &lbf[spos+6*qdim], &lbf[spos+7*qdim], &lbf[spos+8*qdim], &lbf[spos+9*qdim],
                              &lbf[spos+10*qdim], &lbf[spos+11*qdim], &lbf[spos+12*qdim], &lbf[spos+13*qdim],
                              &lbf[spos+14*qdim], &lbf[spos+15*qdim], &lbf[spos+16*qdim], &lbf[spos+17*qdim],
                              &lbf[spos+18*qdim], drdx, drdy, drdz, dpdx, dpdy, dpdz, nabr, nabp,
                              &lbomega[lbsy.nf*tpos], T);
        break;
      case CCTLF:
        fD3Q19VCCSwiftRegular(rho, -uwall[0], uwall[1], uwall[2], &force[0], &lbf[spos], &lbf[spos+10*qdim],
                              &lbf[spos+2*qdim], &lbf[spos+3*qdim], &lbf[spos+14*qdim], &lbf[spos+13*qdim],
                              &lbf[spos+16*qdim], &lbf[spos+15*qdim], &lbf[spos+8*qdim], &lbf[spos+9*qdim],
                              &lbf[spos+1*qdim], &lbf[spos+11*qdim], &lbf[spos+12*qdim], &lbf[spos+5*qdim],
                              &lbf[spos+4*qdim], &lbf[spos+7*qdim], &lbf[spos+6*qdim], &lbf[spos+17*qdim],
                              &lbf[spos+18*qdim], -drdx, drdy, drdz, -dpdx, dpdy, dpdz, nabr, nabp,
                              &lbomega[lbsy.nf*tpos], T);
        break;
      case CCDLF:
        fD3Q19VCCSwiftRegular(rho, -uwall[0], -uwall[1], uwall[2], &force[0], &lbf[spos], &lbf[spos+10*qdim],
                              &lbf[spos+11*qdim], &lbf[spos+3*qdim], &lbf[spos+13*qdim], &lbf[spos+14*qdim],
                              &lbf[spos+16*qdim], &lbf[spos+15*qdim], &lbf[spos+18*qdim], &lbf[spos+17*qdim],
                              &lbf[spos+1*qdim], &lbf[spos+2*qdim], &lbf[spos+12*qdim], &lbf[spos+4*qdim],
                              &lbf[spos+5*qdim], &lbf[spos+7*qdim], &lbf[spos+6*qdim], &lbf[spos+9*qdim],
                              &lbf[spos+8*qdim], -drdx, -drdy, drdz, -dpdx, -dpdy, dpdz, nabr, nabp,
                              &lbomega[lbsy.nf*tpos], T);
        break;
      case CCDRF:
        fD3Q19VCCSwiftRegular(rho, uwall[0], -uwall[1], uwall[2], &force[0], &lbf[spos], &lbf[spos+1*qdim],
                              &lbf[spos+11*qdim], &lbf[spos+3*qdim], &lbf[spos+5*qdim], &lbf[spos+4*qdim],
                              &lbf[spos+6*qdim], &lbf[spos+7*qdim], &lbf[spos+18*qdim], &lbf[spos+17*qdim],
                              &lbf[spos+10*qdim], &lbf[spos+2*qdim], &lbf[spos+12*qdim], &lbf[spos+14*qdim],
                              &lbf[spos+13*qdim], &lbf[spos+15*qdim], &lbf[spos+16*qdim], &lbf[spos+9*qdim],
                              &lbf[spos+8*qdim], drdx, -drdy, drdz, dpdx, -dpdy, dpdz, nabr, nabp,
                              &lbomega[lbsy.nf*tpos], T);
        break;
      case CETR:
        fD3Q19VCESwiftRegular(rho, uwall[0], uwall[1], uwall[2], &force[0], &lbf[spos], &lbf[spos+1*qdim],
                              &lbf[spos+2*qdim], &lbf[spos+3*qdim], &lbf[spos+4*qdim], &lbf[spos+5*qdim],
                              &lbf[spos+6*qdim], &lbf[spos+7*qdim], &lbf[spos+8*qdim], &lbf[spos+9*qdim],
                              &lbf[spos+10*qdim], &lbf[spos+11*qdim], &lbf[spos+12*qdim], &lbf[spos+13*qdim],
                              &lbf[spos+14*qdim], &lbf[spos+15*qdim], &lbf[spos+16*qdim], &lbf[spos+17*qdim],
                              &lbf[spos+18*qdim], drdx, drdy, drdz, dpdx, dpdy, dpdz, nabr, nabp,
                              &lbomega[lbsy.nf*tpos], T);
        break;
      case CETL:
        fD3Q19VCESwiftRegular(rho, uwall[1], -uwall[0], uwall[2], &force[0], &lbf[spos], &lbf[spos+2*qdim],
                              &lbf[spos+10*qdim], &lbf[spos+3*qdim], &lbf[spos+14*qdim], &lbf[spos+4*qdim],
                              &lbf[spos+8*qdim], &lbf[spos+9*qdim], &lbf[spos+16*qdim], &lbf[spos+15*qdim],
                              &lbf[spos+11*qdim], &lbf[spos+1*qdim], &lbf[spos+12*qdim], &lbf[spos+5*qdim],
                              &lbf[spos+13*qdim], &lbf[spos+17*qdim], &lbf[spos+18*qdim], &lbf[spos+7*qdim],
                              &lbf[spos+6*qdim], drdy, -drdx, drdz, dpdy, -dpdx, dpdz, nabr, nabp,
                              &lbomega[lbsy.nf*tpos], T);
        break;
      case CEDL:
        fD3Q19VCESwiftRegular(rho, -uwall[0], -uwall[1], uwall[2], &force[0], &lbf[spos], &lbf[spos+10*qdim],
                              &lbf[spos+11*qdim], &lbf[spos+3*qdim], &lbf[spos+13*qdim], &lbf[spos+14*qdim],
                              &lbf[spos+16*qdim], &lbf[spos+15*qdim], &lbf[spos+18*qdim], &lbf[spos+17*qdim],
                              &lbf[spos+1*qdim], &lbf[spos+2*qdim], &lbf[spos+12*qdim], &lbf[spos+4*qdim],
                              &lbf[spos+5*qdim], &lbf[spos+7*qdim], &lbf[spos+6*qdim], &lbf[spos+9*qdim],
                              &lbf[spos+8*qdim], -drdx, -drdy, drdz, -dpdx, -dpdy, dpdz, nabr, nabp,
                              &lbomega[lbsy.nf*tpos], T);
        break;
      case CEDR:
        fD3Q19VCESwiftRegular(rho, -uwall[1], uwall[0], uwall[2], &force[0], &lbf[spos], &lbf[spos+11*qdim],
                              &lbf[spos+1*qdim], &lbf[spos+3*qdim], &lbf[spos+5*qdim], &lbf[spos+13*qdim],
                              &lbf[spos+18*qdim], &lbf[spos+17*qdim], &lbf[spos+6*qdim], &lbf[spos+7*qdim],
                              &lbf[spos+2*qdim], &lbf[spos+10*qdim], &lbf[spos+12*qdim], &lbf[spos+14*qdim],
                              &lbf[spos+4*qdim], &lbf[spos+9*qdim], &lbf[spos+8*qdim], &lbf[spos+15*qdim],
                              &lbf[spos+16*qdim], -drdy, drdx, drdz, -dpdy, dpdx, dpdz, nabr, nabp,
                              &lbomega[lbsy.nf*tpos], T);
        break;
      case CETF:
        fD3Q19VCESwiftRegular(rho, uwall[1], uwall[2], uwall[0], &force[0], &lbf[spos], &lbf[spos+2*qdim],
                              &lbf[spos+3*qdim], &lbf[spos+1*qdim], &lbf[spos+8*qdim], &lbf[spos+9*qdim],
                              &lbf[spos+4*qdim], &lbf[spos+14*qdim], &lbf[spos+6*qdim], &lbf[spos+16*qdim],
                              &lbf[spos+11*qdim], &lbf[spos+12*qdim], &lbf[spos+10*qdim], &lbf[spos+17*qdim],
                              &lbf[spos+18*qdim], &lbf[spos+13*qdim], &lbf[spos+5*qdim], &lbf[spos+15*qdim],
                              &lbf[spos+7*qdim], drdy, drdz, drdx, dpdy, dpdz, dpdx, nabr, nabp,
                              &lbomega[lbsy.nf*tpos], T);
        break;
      case CELF:
        fD3Q19VCESwiftRegular(rho, -uwall[0], uwall[2], uwall[1], &force[0], &lbf[spos], &lbf[spos+10*qdim],
                              &lbf[spos+3*qdim], &lbf[spos+2*qdim], &lbf[spos+16*qdim], &lbf[spos+15*qdim],
                              &lbf[spos+14*qdim], &lbf[spos+13*qdim], &lbf[spos+8*qdim], &lbf[spos+18*qdim],
                              &lbf[spos+1*qdim], &lbf[spos+12*qdim], &lbf[spos+11*qdim], &lbf[spos+7*qdim],
                              &lbf[spos+6*qdim], &lbf[spos+5*qdim], &lbf[spos+4*qdim], &lbf[spos+17*qdim],
                              &lbf[spos+9*qdim], -drdx, drdz, drdy, -dpdx, dpdz, dpdy, nabr, nabp,
                              &lbomega[lbsy.nf*tpos], T);
        break;
      case CEDF:
        fD3Q19VCESwiftRegular(rho, -uwall[1], uwall[2], uwall[0], &force[0], &lbf[spos], &lbf[spos+11*qdim],
                              &lbf[spos+3*qdim], &lbf[spos+1*qdim], &lbf[spos+18*qdim], &lbf[spos+17*qdim],
                              &lbf[spos+5*qdim], &lbf[spos+13*qdim], &lbf[spos+6*qdim], &lbf[spos+16*qdim],
                              &lbf[spos+2*qdim], &lbf[spos+12*qdim], &lbf[spos+10*qdim], &lbf[spos+9*qdim],
                              &lbf[spos+8*qdim], &lbf[spos+14*qdim], &lbf[spos+4*qdim], &lbf[spos+15*qdim],
                              &lbf[spos+7*qdim], -drdy, drdz, drdx, -dpdy, dpdz, dpdx, nabr, nabp,
                              &lbomega[lbsy.nf*tpos], T);
        break;
      case CERF:
        fD3Q19VCESwiftRegular(rho, uwall[0], uwall[2], uwall[1], &force[0], &lbf[spos], &lbf[spos+1*qdim],
                              &lbf[spos+3*qdim], &lbf[spos+2*qdim], &lbf[spos+6*qdim], &lbf[spos+7*qdim],
                              &lbf[spos+4*qdim], &lbf[spos+5*qdim], &lbf[spos+8*qdim], &lbf[spos+18*qdim],
                              &lbf[spos+10*qdim], &lbf[spos+12*qdim], &lbf[spos+11*qdim], &lbf[spos+15*qdim],
                              &lbf[spos+16*qdim], &lbf[spos+13*qdim], &lbf[spos+14*qdim], &lbf[spos+17*qdim],
                              &lbf[spos+9*qdim], drdx, drdz, drdy, dpdx, dpdz, dpdy, nabr, nabp,
                              &lbomega[lbsy.nf*tpos], T);
        break;
      case CETB:
        fD3Q19VCESwiftRegular(rho, uwall[1], -uwall[2], uwall[0], &force[0], &lbf[spos], &lbf[spos+2*qdim],
                              &lbf[spos+12*qdim], &lbf[spos+1*qdim], &lbf[spos+9*qdim], &lbf[spos+8*qdim],
                              &lbf[spos+4*qdim], &lbf[spos+14*qdim], &lbf[spos+7*qdim], &lbf[spos+15*qdim],
                              &lbf[spos+11*qdim], &lbf[spos+3*qdim], &lbf[spos+10*qdim], &lbf[spos+18*qdim],
                              &lbf[spos+17*qdim], &lbf[spos+13*qdim], &lbf[spos+5*qdim], &lbf[spos+16*qdim],
                              &lbf[spos+6*qdim], drdy, -drdz, drdx, dpdy, -dpdz, dpdx, nabr, nabp,
                              &lbomega[lbsy.nf*tpos], T);
        break;
      case CELB:
        fD3Q19VCESwiftRegular(rho, -uwall[0], -uwall[2], uwall[1], &force[0], &lbf[spos], &lbf[spos+10*qdim],
                              &lbf[spos+12*qdim], &lbf[spos+2*qdim], &lbf[spos+15*qdim], &lbf[spos+16*qdim],
                              &lbf[spos+14*qdim], &lbf[spos+13*qdim], &lbf[spos+9*qdim], &lbf[spos+17*qdim],
                              &lbf[spos+1*qdim], &lbf[spos+3*qdim], &lbf[spos+11*qdim], &lbf[spos+6*qdim],
                              &lbf[spos+7*qdim], &lbf[spos+5*qdim], &lbf[spos+4*qdim], &lbf[spos+18*qdim],
                              &lbf[spos+8*qdim], -drdx, -drdz, drdy, -dpdx, -dpdz, dpdy, nabr, nabp,
                              &lbomega[lbsy.nf*tpos], T);
        break;
      case CEDB:
        fD3Q19VCESwiftRegular(rho, -uwall[1], -uwall[2], uwall[0], &force[0], &lbf[spos], &lbf[spos+11*qdim],
                              &lbf[spos+12*qdim], &lbf[spos+1*qdim], &lbf[spos+17*qdim], &lbf[spos+18*qdim],
                              &lbf[spos+5*qdim], &lbf[spos+13*qdim], &lbf[spos+7*qdim], &lbf[spos+15*qdim],
                              &lbf[spos+2*qdim], &lbf[spos+3*qdim], &lbf[spos+10*qdim], &lbf[spos+8*qdim],
                              &lbf[spos+9*qdim], &lbf[spos+14*qdim], &lbf[spos+4*qdim], &lbf[spos+16*qdim],
                              &lbf[spos+6*qdim], -drdy, -drdz, drdx, -dpdy, -dpdz, dpdx, nabr, nabp,
                              &lbomega[lbsy.nf*tpos], T);
        break;
      case CERB:
        fD3Q19VCESwiftRegular(rho, uwall[0], -uwall[2], uwall[1], &force[0], &lbf[spos], &lbf[spos+1*qdim],
                              &lbf[spos+12*qdim], &lbf[spos+2*qdim], &lbf[spos+7*qdim], &lbf[spos+6*qdim],
                              &lbf[spos+4*qdim], &lbf[spos+5*qdim], &lbf[spos+9*qdim], &lbf[spos+17*qdim],
                              &lbf[spos+10*qdim], &lbf[spos+3*qdim], &lbf[spos+11*qdim], &lbf[spos+16*qdim],
                              &lbf[spos+15*qdim], &lbf[spos+13*qdim], &lbf[spos+14*qdim], &lbf[spos+18*qdim],
                              &lbf[spos+8*qdim], drdx, -drdz, drdy, dpdx, -dpdz, dpdy, nabr, nabp,
                              &lbomega[lbsy.nf*tpos], T);
        break;
    }
  }
  else if(collide>11) {
    switch (prop) {
      case PST:
        fD3Q19VPSCLBERegular(uwall[0], uwall[1], uwall[2], &force[0], &lbf[spos], &lbf[spos+1*qdim],
                             &lbf[spos+2*qdim], &lbf[spos+3*qdim], &lbf[spos+4*qdim], &lbf[spos+5*qdim],
                             &lbf[spos+6*qdim], &lbf[spos+7*qdim], &lbf[spos+8*qdim], &lbf[spos+9*qdim],
                             &lbf[spos+10*qdim], &lbf[spos+11*qdim], &lbf[spos+12*qdim], &lbf[spos+13*qdim],
                             &lbf[spos+14*qdim], &lbf[spos+15*qdim], &lbf[spos+16*qdim], &lbf[spos+17*qdim],
                             &lbf[spos+18*qdim]);
        break;
      case PSD:
        fD3Q19VPSCLBERegular(-uwall[0], -uwall[1], -uwall[2], &force[0], &lbf[spos], &lbf[spos+10*qdim],
                             &lbf[spos+11*qdim], &lbf[spos+12*qdim], &lbf[spos+13*qdim], &lbf[spos+14*qdim],
                             &lbf[spos+15*qdim], &lbf[spos+16*qdim], &lbf[spos+17*qdim], &lbf[spos+18*qdim],
                             &lbf[spos+1*qdim], &lbf[spos+2*qdim], &lbf[spos+3*qdim], &lbf[spos+4*qdim],
                             &lbf[spos+5*qdim], &lbf[spos+6*qdim], &lbf[spos+7*qdim], &lbf[spos+8*qdim],
                             &lbf[spos+9*qdim]);
        break;
      case PSL:
        fD3Q19VPSCLBERegular(-uwall[2], -uwall[0], -uwall[1], &force[0], &lbf[spos], &lbf[spos+12*qdim],
                             &lbf[spos+10*qdim], &lbf[spos+11*qdim], &lbf[spos+15*qdim], &lbf[spos+7*qdim],
                             &lbf[spos+17*qdim], &lbf[spos+9*qdim], &lbf[spos+13*qdim], &lbf[spos+14*qdim],
                             &lbf[spos+3*qdim], &lbf[spos+1*qdim], &lbf[spos+2*qdim], &lbf[spos+6*qdim],
                             &lbf[spos+16*qdim], &lbf[spos+8*qdim], &lbf[spos+18*qdim], &lbf[spos+4*qdim],
                             &lbf[spos+5*qdim]);
        break;
      case PSR:
        fD3Q19VPSCLBERegular(uwall[2], uwall[0], uwall[1], &force[0], &lbf[spos], &lbf[spos+3*qdim],
                             &lbf[spos+1*qdim], &lbf[spos+2*qdim], &lbf[spos+6*qdim], &lbf[spos+16*qdim],
                             &lbf[spos+8*qdim], &lbf[spos+18*qdim], &lbf[spos+4*qdim], &lbf[spos+5*qdim],
                             &lbf[spos+12*qdim], &lbf[spos+10*qdim], &lbf[spos+11*qdim], &lbf[spos+15*qdim],
                             &lbf[spos+7*qdim], &lbf[spos+17*qdim], &lbf[spos+9*qdim], &lbf[spos+13*qdim],
                             &lbf[spos+14*qdim]);
        break;
      case PSF:
        fD3Q19VPSCLBERegular(-uwall[1], -uwall[2], -uwall[0], &force[0], &lbf[spos], &lbf[spos+11*qdim],
                             &lbf[spos+12*qdim], &lbf[spos+10*qdim], &lbf[spos+17*qdim], &lbf[spos+18*qdim],
                             &lbf[spos+13*qdim], &lbf[spos+5*qdim], &lbf[spos+15*qdim], &lbf[spos+7*qdim],
                             &lbf[spos+2*qdim], &lbf[spos+3*qdim], &lbf[spos+1*qdim], &lbf[spos+8*qdim],
                             &lbf[spos+9*qdim], &lbf[spos+4*qdim], &lbf[spos+14*qdim], &lbf[spos+6*qdim],
                             &lbf[spos+16*qdim]);
        break;
      case PSB:
        fD3Q19VPSCLBERegular(uwall[1], uwall[2], uwall[0], &force[0], &lbf[spos], &lbf[spos+2*qdim],
                             &lbf[spos+3*qdim], &lbf[spos+1*qdim], &lbf[spos+8*qdim], &lbf[spos+9*qdim],
                             &lbf[spos+4*qdim], &lbf[spos+14*qdim], &lbf[spos+6*qdim], &lbf[spos+16*qdim],
                             &lbf[spos+11*qdim], &lbf[spos+12*qdim], &lbf[spos+10*qdim], &lbf[spos+17*qdim],
                             &lbf[spos+18*qdim], &lbf[spos+13*qdim], &lbf[spos+5*qdim], &lbf[spos+15*qdim],
                             &lbf[spos+7*qdim]);
        break;
      case CCTRB:
        fD3Q19VCCCLBERegular(rho, uwall[0], uwall[1], -uwall[2], &force[0], &lbf[spos], &lbf[spos+1*qdim],
                             &lbf[spos+2*qdim], &lbf[spos+12*qdim], &lbf[spos+4*qdim], &lbf[spos+5*qdim],
                             &lbf[spos+7*qdim], &lbf[spos+6*qdim], &lbf[spos+9*qdim], &lbf[spos+8*qdim],
                             &lbf[spos+10*qdim], &lbf[spos+11*qdim], &lbf[spos+3*qdim], &lbf[spos+13*qdim],
                             &lbf[spos+14*qdim], &lbf[spos+16*qdim], &lbf[spos+15*qdim], &lbf[spos+18*qdim],
                             &lbf[spos+17*qdim]);
        break;
      case CCTLB:
        fD3Q19VCCCLBERegular(rho, -uwall[0], uwall[1], -uwall[2], &force[0], &lbf[spos], &lbf[spos+10*qdim],
                             &lbf[spos+2*qdim], &lbf[spos+12*qdim], &lbf[spos+14*qdim], &lbf[spos+13*qdim],
                             &lbf[spos+15*qdim], &lbf[spos+16*qdim], &lbf[spos+9*qdim], &lbf[spos+8*qdim],
                             &lbf[spos+1*qdim], &lbf[spos+11*qdim], &lbf[spos+3*qdim], &lbf[spos+5*qdim],
                             &lbf[spos+4*qdim], &lbf[spos+6*qdim], &lbf[spos+7*qdim], &lbf[spos+18*qdim],
                             &lbf[spos+17*qdim]);
        break;
      case CCDLB:
        fD3Q19VCCCLBERegular(rho, -uwall[0], -uwall[1], -uwall[2], &force[0], &lbf[spos], &lbf[spos+10*qdim],
                             &lbf[spos+11*qdim], &lbf[spos+12*qdim], &lbf[spos+13*qdim], &lbf[spos+14*qdim],
                             &lbf[spos+15*qdim], &lbf[spos+16*qdim], &lbf[spos+17*qdim], &lbf[spos+18*qdim],
                             &lbf[spos+1*qdim], &lbf[spos+2*qdim], &lbf[spos+3*qdim], &lbf[spos+4*qdim],
                             &lbf[spos+5*qdim], &lbf[spos+6*qdim], &lbf[spos+7*qdim], &lbf[spos+8*qdim],
                             &lbf[spos+9*qdim]);
        break;
      case CCDRB:
        fD3Q19VCCCLBERegular(rho, uwall[0], -uwall[1], -uwall[2], &force[0], &lbf[spos], &lbf[spos+1*qdim],
                             &lbf[spos+11*qdim], &lbf[spos+12*qdim], &lbf[spos+5*qdim], &lbf[spos+4*qdim],
                             &lbf[spos+7*qdim], &lbf[spos+6*qdim], &lbf[spos+17*qdim], &lbf[spos+18*qdim],
                             &lbf[spos+10*qdim], &lbf[spos+2*qdim], &lbf[spos+3*qdim], &lbf[spos+14*qdim],
                             &lbf[spos+13*qdim], &lbf[spos+16*qdim], &lbf[spos+15*qdim], &lbf[spos+8*qdim],
                             &lbf[spos+9*qdim]);
        break;
      case CCTRF:
        fD3Q19VCCCLBERegular(rho, uwall[0], uwall[1], uwall[2], &force[0], &lbf[spos], &lbf[spos+1*qdim],
                             &lbf[spos+2*qdim], &lbf[spos+3*qdim], &lbf[spos+4*qdim], &lbf[spos+5*qdim],
                             &lbf[spos+6*qdim], &lbf[spos+7*qdim], &lbf[spos+8*qdim], &lbf[spos+9*qdim],
                             &lbf[spos+10*qdim], &lbf[spos+11*qdim], &lbf[spos+12*qdim], &lbf[spos+13*qdim],
                             &lbf[spos+14*qdim], &lbf[spos+15*qdim], &lbf[spos+16*qdim], &lbf[spos+17*qdim],
                             &lbf[spos+18*qdim]);
        break;
      case CCTLF:
        fD3Q19VCCCLBERegular(rho, -uwall[0], uwall[1], uwall[2], &force[0], &lbf[spos], &lbf[spos+10*qdim],
                             &lbf[spos+2*qdim], &lbf[spos+3*qdim], &lbf[spos+14*qdim], &lbf[spos+13*qdim],
                             &lbf[spos+16*qdim], &lbf[spos+15*qdim], &lbf[spos+8*qdim], &lbf[spos+9*qdim],
                             &lbf[spos+1*qdim], &lbf[spos+11*qdim], &lbf[spos+12*qdim], &lbf[spos+5*qdim],
                             &lbf[spos+4*qdim], &lbf[spos+7*qdim], &lbf[spos+6*qdim], &lbf[spos+17*qdim],
                             &lbf[spos+18*qdim]);
        break;
      case CCDLF:
        fD3Q19VCCCLBERegular(rho, -uwall[0], -uwall[1], uwall[2], &force[0], &lbf[spos], &lbf[spos+10*qdim],
                             &lbf[spos+11*qdim], &lbf[spos+3*qdim], &lbf[spos+13*qdim], &lbf[spos+14*qdim],
                             &lbf[spos+16*qdim], &lbf[spos+15*qdim], &lbf[spos+18*qdim], &lbf[spos+17*qdim],
                             &lbf[spos+1*qdim], &lbf[spos+2*qdim], &lbf[spos+12*qdim], &lbf[spos+4*qdim],
                             &lbf[spos+5*qdim], &lbf[spos+7*qdim], &lbf[spos+6*qdim], &lbf[spos+9*qdim],
                             &lbf[spos+8*qdim]);
        break;
      case CCDRF:
        fD3Q19VCCCLBERegular(rho, uwall[0], -uwall[1], uwall[2], &force[0], &lbf[spos], &lbf[spos+1*qdim],
                             &lbf[spos+11*qdim], &lbf[spos+3*qdim], &lbf[spos+5*qdim], &lbf[spos+4*qdim],
                             &lbf[spos+6*qdim], &lbf[spos+7*qdim], &lbf[spos+18*qdim], &lbf[spos+17*qdim],
                             &lbf[spos+10*qdim], &lbf[spos+2*qdim], &lbf[spos+12*qdim], &lbf[spos+14*qdim],
                             &lbf[spos+13*qdim], &lbf[spos+15*qdim], &lbf[spos+16*qdim], &lbf[spos+9*qdim],
                             &lbf[spos+8*qdim]);
        break;
      case CETR:
        fD3Q19VCECLBERegular(rho, uwall[0], uwall[1], uwall[2], &force[0], &lbf[spos], &lbf[spos+1*qdim],
                             &lbf[spos+2*qdim], &lbf[spos+3*qdim], &lbf[spos+4*qdim], &lbf[spos+5*qdim],
                             &lbf[spos+6*qdim], &lbf[spos+7*qdim], &lbf[spos+8*qdim], &lbf[spos+9*qdim],
                             &lbf[spos+10*qdim], &lbf[spos+11*qdim], &lbf[spos+12*qdim], &lbf[spos+13*qdim],
                             &lbf[spos+14*qdim], &lbf[spos+15*qdim], &lbf[spos+16*qdim], &lbf[spos+17*qdim],
                             &lbf[spos+18*qdim]);
        break;
      case CETL:
        fD3Q19VCECLBERegular(rho, uwall[1], -uwall[0], uwall[2], &force[0], &lbf[spos], &lbf[spos+2*qdim],
                             &lbf[spos+10*qdim], &lbf[spos+3*qdim], &lbf[spos+14*qdim], &lbf[spos+4*qdim],
                             &lbf[spos+8*qdim], &lbf[spos+9*qdim], &lbf[spos+16*qdim], &lbf[spos+15*qdim],
                             &lbf[spos+11*qdim], &lbf[spos+1*qdim], &lbf[spos+12*qdim], &lbf[spos+5*qdim],
                             &lbf[spos+13*qdim], &lbf[spos+17*qdim], &lbf[spos+18*qdim], &lbf[spos+7*qdim],
                             &lbf[spos+6*qdim]);
        break;
      case CEDL:
        fD3Q19VCECLBERegular(rho, -uwall[0], -uwall[1], uwall[2], &force[0], &lbf[spos], &lbf[spos+10*qdim],
                             &lbf[spos+11*qdim], &lbf[spos+3*qdim], &lbf[spos+13*qdim], &lbf[spos+14*qdim],
                             &lbf[spos+16*qdim], &lbf[spos+15*qdim], &lbf[spos+18*qdim], &lbf[spos+17*qdim],
                             &lbf[spos+1*qdim], &lbf[spos+2*qdim], &lbf[spos+12*qdim], &lbf[spos+4*qdim],
                             &lbf[spos+5*qdim], &lbf[spos+7*qdim], &lbf[spos+6*qdim], &lbf[spos+9*qdim],
                             &lbf[spos+8*qdim]);
        break;
      case CEDR:
        fD3Q19VCECLBERegular(rho, -uwall[1], uwall[0], uwall[2], &force[0], &lbf[spos], &lbf[spos+11*qdim],
                             &lbf[spos+1*qdim], &lbf[spos+3*qdim], &lbf[spos+5*qdim], &lbf[spos+13*qdim],
                             &lbf[spos+18*qdim], &lbf[spos+17*qdim], &lbf[spos+6*qdim], &lbf[spos+7*qdim],
                             &lbf[spos+2*qdim], &lbf[spos+10*qdim], &lbf[spos+12*qdim], &lbf[spos+14*qdim],
                             &lbf[spos+4*qdim], &lbf[spos+9*qdim], &lbf[spos+8*qdim], &lbf[spos+15*qdim],
                             &lbf[spos+16*qdim]);
        break;
      case CETF:
        fD3Q19VCECLBERegular(rho, uwall[1], uwall[2], uwall[0], &force[0], &lbf[spos], &lbf[spos+2*qdim],
                             &lbf[spos+3*qdim], &lbf[spos+1*qdim], &lbf[spos+8*qdim], &lbf[spos+9*qdim],
                             &lbf[spos+4*qdim], &lbf[spos+14*qdim], &lbf[spos+6*qdim], &lbf[spos+16*qdim],
                             &lbf[spos+11*qdim], &lbf[spos+12*qdim], &lbf[spos+10*qdim], &lbf[spos+17*qdim],
                             &lbf[spos+18*qdim], &lbf[spos+13*qdim], &lbf[spos+5*qdim], &lbf[spos+15*qdim],
                             &lbf[spos+7*qdim]);
        break;
      case CELF:
        fD3Q19VCECLBERegular(rho, -uwall[0], uwall[2], uwall[1], &force[0], &lbf[spos], &lbf[spos+10*qdim],
                             &lbf[spos+3*qdim], &lbf[spos+2*qdim], &lbf[spos+16*qdim], &lbf[spos+15*qdim],
                             &lbf[spos+14*qdim], &lbf[spos+13*qdim], &lbf[spos+8*qdim], &lbf[spos+18*qdim],
                             &lbf[spos+1*qdim], &lbf[spos+12*qdim], &lbf[spos+11*qdim], &lbf[spos+7*qdim],
                             &lbf[spos+6*qdim], &lbf[spos+5*qdim], &lbf[spos+4*qdim], &lbf[spos+17*qdim],
                             &lbf[spos+9*qdim]);
        break;
      case CEDF:
        fD3Q19VCECLBERegular(rho, -uwall[1], uwall[2], uwall[0], &force[0], &lbf[spos], &lbf[spos+11*qdim],
                             &lbf[spos+3*qdim], &lbf[spos+1*qdim], &lbf[spos+18*qdim], &lbf[spos+17*qdim],
                             &lbf[spos+5*qdim], &lbf[spos+13*qdim], &lbf[spos+6*qdim], &lbf[spos+16*qdim],
                             &lbf[spos+2*qdim], &lbf[spos+12*qdim], &lbf[spos+10*qdim], &lbf[spos+9*qdim],
                             &lbf[spos+8*qdim], &lbf[spos+14*qdim], &lbf[spos+4*qdim], &lbf[spos+15*qdim],
                             &lbf[spos+7*qdim]);
        break;
      case CERF:
        fD3Q19VCECLBERegular(rho, uwall[0], uwall[2], uwall[1], &force[0], &lbf[spos], &lbf[spos+1*qdim],
                             &lbf[spos+3*qdim], &lbf[spos+2*qdim], &lbf[spos+6*qdim], &lbf[spos+7*qdim],
                             &lbf[spos+4*qdim], &lbf[spos+5*qdim], &lbf[spos+8*qdim], &lbf[spos+18*qdim],
                             &lbf[spos+10*qdim], &lbf[spos+12*qdim], &lbf[spos+11*qdim], &lbf[spos+15*qdim],
                             &lbf[spos+16*qdim], &lbf[spos+13*qdim], &lbf[spos+14*qdim], &lbf[spos+17*qdim],
                             &lbf[spos+9*qdim]);
        break;
      case CETB:
        fD3Q19VCECLBERegular(rho, uwall[1], -uwall[2], uwall[0], &force[0], &lbf[spos], &lbf[spos+2*qdim],
                             &lbf[spos+12*qdim], &lbf[spos+1*qdim], &lbf[spos+9*qdim], &lbf[spos+8*qdim],
                             &lbf[spos+4*qdim], &lbf[spos+14*qdim], &lbf[spos+7*qdim], &lbf[spos+15*qdim],
                             &lbf[spos+11*qdim], &lbf[spos+3*qdim], &lbf[spos+10*qdim], &lbf[spos+18*qdim],
                             &lbf[spos+17*qdim], &lbf[spos+13*qdim], &lbf[spos+5*qdim], &lbf[spos+16*qdim],
                             &lbf[spos+6*qdim]);
        break;
      case CELB:
        fD3Q19VCECLBERegular(rho, -uwall[0], -uwall[2], uwall[1], &force[0], &lbf[spos], &lbf[spos+10*qdim],
                             &lbf[spos+12*qdim], &lbf[spos+2*qdim], &lbf[spos+15*qdim], &lbf[spos+16*qdim],
                             &lbf[spos+14*qdim], &lbf[spos+13*qdim], &lbf[spos+9*qdim], &lbf[spos+17*qdim],
                             &lbf[spos+1*qdim], &lbf[spos+3*qdim], &lbf[spos+11*qdim], &lbf[spos+6*qdim],
                             &lbf[spos+7*qdim], &lbf[spos+5*qdim], &lbf[spos+4*qdim], &lbf[spos+18*qdim],
                             &lbf[spos+8*qdim]);
        break;
      case CEDB:
        fD3Q19VCECLBERegular(rho, -uwall[1], -uwall[2], uwall[0], &force[0], &lbf[spos], &lbf[spos+11*qdim],
                             &lbf[spos+12*qdim], &lbf[spos+1*qdim], &lbf[spos+17*qdim], &lbf[spos+18*qdim],
                             &lbf[spos+5*qdim], &lbf[spos+13*qdim], &lbf[spos+7*qdim], &lbf[spos+15*qdim],
                             &lbf[spos+2*qdim], &lbf[spos+3*qdim], &lbf[spos+10*qdim], &lbf[spos+8*qdim],
                             &lbf[spos+9*qdim], &lbf[spos+14*qdim], &lbf[spos+4*qdim], &lbf[spos+16*qdim],
                             &lbf[spos+6*qdim]);
        break;
      case CERB:
        fD3Q19VCECLBERegular(rho, uwall[0], -uwall[2], uwall[1], &force[0], &lbf[spos], &lbf[spos+1*qdim],
                             &lbf[spos+12*qdim], &lbf[spos+2*qdim], &lbf[spos+7*qdim], &lbf[spos+6*qdim],
                             &lbf[spos+4*qdim], &lbf[spos+5*qdim], &lbf[spos+9*qdim], &lbf[spos+17*qdim],
                             &lbf[spos+10*qdim], &lbf[spos+3*qdim], &lbf[spos+11*qdim], &lbf[spos+16*qdim],
                             &lbf[spos+15*qdim], &lbf[spos+13*qdim], &lbf[spos+14*qdim], &lbf[spos+18*qdim],
                             &lbf[spos+8*qdim]);
        break;
    }
  }
  else {
    switch (prop) {
      case PST:
        fD3Q19VPSRegular(uwall[0], uwall[1], uwall[2], &force[0], &lbf[spos], &lbf[spos+1*qdim],
                         &lbf[spos+2*qdim], &lbf[spos+3*qdim], &lbf[spos+4*qdim], &lbf[spos+5*qdim],
                         &lbf[spos+6*qdim], &lbf[spos+7*qdim], &lbf[spos+8*qdim], &lbf[spos+9*qdim],
                         &lbf[spos+10*qdim], &lbf[spos+11*qdim], &lbf[spos+12*qdim], &lbf[spos+13*qdim],
                         &lbf[spos+14*qdim], &lbf[spos+15*qdim], &lbf[spos+16*qdim], &lbf[spos+17*qdim],
                         &lbf[spos+18*qdim]);
        break;
      case PSD:
        fD3Q19VPSRegular(-uwall[0], -uwall[1], -uwall[2], &force[0], &lbf[spos], &lbf[spos+10*qdim],
                         &lbf[spos+11*qdim], &lbf[spos+12*qdim], &lbf[spos+13*qdim], &lbf[spos+14*qdim],
                         &lbf[spos+15*qdim], &lbf[spos+16*qdim], &lbf[spos+17*qdim], &lbf[spos+18*qdim],
                         &lbf[spos+1*qdim], &lbf[spos+2*qdim], &lbf[spos+3*qdim], &lbf[spos+4*qdim],
                         &lbf[spos+5*qdim], &lbf[spos+6*qdim], &lbf[spos+7*qdim], &lbf[spos+8*qdim],
                         &lbf[spos+9*qdim]);
        break;
      case PSL:
        fD3Q19VPSRegular(-uwall[2], -uwall[0], -uwall[1], &force[0], &lbf[spos], &lbf[spos+12*qdim],
                         &lbf[spos+10*qdim], &lbf[spos+11*qdim], &lbf[spos+15*qdim], &lbf[spos+7*qdim],
                         &lbf[spos+17*qdim], &lbf[spos+9*qdim], &lbf[spos+13*qdim], &lbf[spos+14*qdim],
                         &lbf[spos+3*qdim], &lbf[spos+1*qdim], &lbf[spos+2*qdim], &lbf[spos+6*qdim],
                         &lbf[spos+16*qdim], &lbf[spos+8*qdim], &lbf[spos+18*qdim], &lbf[spos+4*qdim],
                         &lbf[spos+5*qdim]);
        break;
      case PSR:
        fD3Q19VPSRegular(uwall[2], uwall[0], uwall[1], &force[0], &lbf[spos], &lbf[spos+3*qdim],
                         &lbf[spos+1*qdim], &lbf[spos+2*qdim], &lbf[spos+6*qdim], &lbf[spos+16*qdim],
                         &lbf[spos+8*qdim], &lbf[spos+18*qdim], &lbf[spos+4*qdim], &lbf[spos+5*qdim],
                         &lbf[spos+12*qdim], &lbf[spos+10*qdim], &lbf[spos+11*qdim], &lbf[spos+15*qdim],
                         &lbf[spos+7*qdim], &lbf[spos+17*qdim], &lbf[spos+9*qdim], &lbf[spos+13*qdim],
                         &lbf[spos+14*qdim]);
        break;
      case PSF:
        fD3Q19VPSRegular(-uwall[1], -uwall[2], -uwall[0], &force[0], &lbf[spos], &lbf[spos+11*qdim],
                         &lbf[spos+12*qdim], &lbf[spos+10*qdim], &lbf[spos+17*qdim], &lbf[spos+18*qdim],
                         &lbf[spos+13*qdim], &lbf[spos+5*qdim], &lbf[spos+15*qdim], &lbf[spos+7*qdim],
                         &lbf[spos+2*qdim], &lbf[spos+3*qdim], &lbf[spos+1*qdim], &lbf[spos+8*qdim],
                         &lbf[spos+9*qdim], &lbf[spos+4*qdim], &lbf[spos+14*qdim], &lbf[spos+6*qdim],
                         &lbf[spos+16*qdim]);
        break;
      case PSB:
        fD3Q19VPSRegular(uwall[1], uwall[2], uwall[0], &force[0], &lbf[spos], &lbf[spos+2*qdim],
                         &lbf[spos+3*qdim], &lbf[spos+1*qdim], &lbf[spos+8*qdim], &lbf[spos+9*qdim],
                         &lbf[spos+4*qdim], &lbf[spos+14*qdim], &lbf[spos+6*qdim], &lbf[spos+16*qdim],
                         &lbf[spos+11*qdim], &lbf[spos+12*qdim], &lbf[spos+10*qdim], &lbf[spos+17*qdim],
                         &lbf[spos+18*qdim], &lbf[spos+13*qdim], &lbf[spos+5*qdim], &lbf[spos+15*qdim],
                         &lbf[spos+7*qdim]);
        break;
      case CCTRB:
        fD3Q19VCCRegular(rho, uwall[0], uwall[1], -uwall[2], &force[0], &lbf[spos], &lbf[spos+1*qdim],
                         &lbf[spos+2*qdim], &lbf[spos+12*qdim], &lbf[spos+4*qdim], &lbf[spos+5*qdim],
                         &lbf[spos+7*qdim], &lbf[spos+6*qdim], &lbf[spos+9*qdim], &lbf[spos+8*qdim],
                         &lbf[spos+10*qdim], &lbf[spos+11*qdim], &lbf[spos+3*qdim], &lbf[spos+13*qdim],
                         &lbf[spos+14*qdim], &lbf[spos+16*qdim], &lbf[spos+15*qdim], &lbf[spos+18*qdim],
                         &lbf[spos+17*qdim]);
        break;
      case CCTLB:
        fD3Q19VCCRegular(rho, -uwall[0], uwall[1], -uwall[2], &force[0], &lbf[spos], &lbf[spos+10*qdim],
                         &lbf[spos+2*qdim], &lbf[spos+12*qdim], &lbf[spos+14*qdim], &lbf[spos+13*qdim],
                         &lbf[spos+15*qdim], &lbf[spos+16*qdim], &lbf[spos+9*qdim], &lbf[spos+8*qdim],
                         &lbf[spos+1*qdim], &lbf[spos+11*qdim], &lbf[spos+3*qdim], &lbf[spos+5*qdim],
                         &lbf[spos+4*qdim], &lbf[spos+6*qdim], &lbf[spos+7*qdim], &lbf[spos+18*qdim],
                         &lbf[spos+17*qdim]);
        break;
      case CCDLB:
        fD3Q19VCCRegular(rho, -uwall[0], -uwall[1], -uwall[2], &force[0], &lbf[spos], &lbf[spos+10*qdim],
                         &lbf[spos+11*qdim], &lbf[spos+12*qdim], &lbf[spos+13*qdim], &lbf[spos+14*qdim],
                         &lbf[spos+15*qdim], &lbf[spos+16*qdim], &lbf[spos+17*qdim], &lbf[spos+18*qdim],
                         &lbf[spos+1*qdim], &lbf[spos+2*qdim], &lbf[spos+3*qdim], &lbf[spos+4*qdim],
                         &lbf[spos+5*qdim], &lbf[spos+6*qdim], &lbf[spos+7*qdim], &lbf[spos+8*qdim],
                         &lbf[spos+9*qdim]);
        break;
      case CCDRB:
        fD3Q19VCCRegular(rho, uwall[0], -uwall[1], -uwall[2], &force[0], &lbf[spos], &lbf[spos+1*qdim],
                         &lbf[spos+11*qdim], &lbf[spos+12*qdim], &lbf[spos+5*qdim], &lbf[spos+4*qdim],
                         &lbf[spos+7*qdim], &lbf[spos+6*qdim], &lbf[spos+17*qdim], &lbf[spos+18*qdim],
                         &lbf[spos+10*qdim], &lbf[spos+2*qdim], &lbf[spos+3*qdim], &lbf[spos+14*qdim],
                         &lbf[spos+13*qdim], &lbf[spos+16*qdim], &lbf[spos+15*qdim], &lbf[spos+8*qdim],
                         &lbf[spos+9*qdim]);
        break;
      case CCTRF:
        fD3Q19VCCRegular(rho, uwall[0], uwall[1], uwall[2], &force[0], &lbf[spos], &lbf[spos+1*qdim],
                         &lbf[spos+2*qdim], &lbf[spos+3*qdim], &lbf[spos+4*qdim], &lbf[spos+5*qdim],
                         &lbf[spos+6*qdim], &lbf[spos+7*qdim], &lbf[spos+8*qdim], &lbf[spos+9*qdim],
                         &lbf[spos+10*qdim], &lbf[spos+11*qdim], &lbf[spos+12*qdim], &lbf[spos+13*qdim],
                         &lbf[spos+14*qdim], &lbf[spos+15*qdim], &lbf[spos+16*qdim], &lbf[spos+17*qdim],
                         &lbf[spos+18*qdim]);
        break;
      case CCTLF:
        fD3Q19VCCRegular(rho, -uwall[0], uwall[1], uwall[2], &force[0], &lbf[spos], &lbf[spos+10*qdim],
                         &lbf[spos+2*qdim], &lbf[spos+3*qdim], &lbf[spos+14*qdim], &lbf[spos+13*qdim],
                         &lbf[spos+16*qdim], &lbf[spos+15*qdim], &lbf[spos+8*qdim], &lbf[spos+9*qdim],
                         &lbf[spos+1*qdim], &lbf[spos+11*qdim], &lbf[spos+12*qdim], &lbf[spos+5*qdim],
                         &lbf[spos+4*qdim], &lbf[spos+7*qdim], &lbf[spos+6*qdim], &lbf[spos+17*qdim],
                         &lbf[spos+18*qdim]);
        break;
      case CCDLF:
        fD3Q19VCCRegular(rho, -uwall[0], -uwall[1], uwall[2], &force[0], &lbf[spos], &lbf[spos+10*qdim],
                         &lbf[spos+11*qdim], &lbf[spos+3*qdim], &lbf[spos+13*qdim], &lbf[spos+14*qdim],
                         &lbf[spos+16*qdim], &lbf[spos+15*qdim], &lbf[spos+18*qdim], &lbf[spos+17*qdim],
                         &lbf[spos+1*qdim], &lbf[spos+2*qdim], &lbf[spos+12*qdim], &lbf[spos+4*qdim],
                         &lbf[spos+5*qdim], &lbf[spos+7*qdim], &lbf[spos+6*qdim], &lbf[spos+9*qdim],
                         &lbf[spos+8*qdim]);
        break;
      case CCDRF:
        fD3Q19VCCRegular(rho, uwall[0], -uwall[1], uwall[2], &force[0], &lbf[spos], &lbf[spos+1*qdim],
                         &lbf[spos+11*qdim], &lbf[spos+3*qdim], &lbf[spos+5*qdim], &lbf[spos+4*qdim],
                         &lbf[spos+6*qdim], &lbf[spos+7*qdim], &lbf[spos+18*qdim], &lbf[spos+17*qdim],
                         &lbf[spos+10*qdim], &lbf[spos+2*qdim], &lbf[spos+12*qdim], &lbf[spos+14*qdim],
                         &lbf[spos+13*qdim], &lbf[spos+15*qdim], &lbf[spos+16*qdim], &lbf[spos+9*qdim],
                         &lbf[spos+8*qdim]);
        break;
      case CETR:
        fD3Q19VCERegular(rho, uwall[0], uwall[1], uwall[2], &force[0], &lbf[spos], &lbf[spos+1*qdim],
                         &lbf[spos+2*qdim], &lbf[spos+3*qdim], &lbf[spos+4*qdim], &lbf[spos+5*qdim],
                         &lbf[spos+6*qdim], &lbf[spos+7*qdim], &lbf[spos+8*qdim], &lbf[spos+9*qdim],
                         &lbf[spos+10*qdim], &lbf[spos+11*qdim], &lbf[spos+12*qdim], &lbf[spos+13*qdim],
                         &lbf[spos+14*qdim], &lbf[spos+15*qdim], &lbf[spos+16*qdim], &lbf[spos+17*qdim],
                         &lbf[spos+18*qdim]);
        break;
      case CETL:
        fD3Q19VCERegular(rho, uwall[1], -uwall[0], uwall[2], &force[0], &lbf[spos], &lbf[spos+2*qdim],
                         &lbf[spos+10*qdim], &lbf[spos+3*qdim], &lbf[spos+14*qdim], &lbf[spos+4*qdim],
                         &lbf[spos+8*qdim], &lbf[spos+9*qdim], &lbf[spos+16*qdim], &lbf[spos+15*qdim],
                         &lbf[spos+11*qdim], &lbf[spos+1*qdim], &lbf[spos+12*qdim], &lbf[spos+5*qdim],
                         &lbf[spos+13*qdim], &lbf[spos+17*qdim], &lbf[spos+18*qdim], &lbf[spos+7*qdim],
                         &lbf[spos+6*qdim]);
        break;
      case CEDL:
        fD3Q19VCERegular(rho, -uwall[0], -uwall[1], uwall[2], &force[0], &lbf[spos], &lbf[spos+10*qdim],
                         &lbf[spos+11*qdim], &lbf[spos+3*qdim], &lbf[spos+13*qdim], &lbf[spos+14*qdim],
                         &lbf[spos+16*qdim], &lbf[spos+15*qdim], &lbf[spos+18*qdim], &lbf[spos+17*qdim],
                         &lbf[spos+1*qdim], &lbf[spos+2*qdim], &lbf[spos+12*qdim], &lbf[spos+4*qdim],
                         &lbf[spos+5*qdim], &lbf[spos+7*qdim], &lbf[spos+6*qdim], &lbf[spos+9*qdim],
                         &lbf[spos+8*qdim]);
        break;
      case CEDR:
        fD3Q19VCERegular(rho, -uwall[1], uwall[0], uwall[2], &force[0], &lbf[spos], &lbf[spos+11*qdim],
                         &lbf[spos+1*qdim], &lbf[spos+3*qdim], &lbf[spos+5*qdim], &lbf[spos+13*qdim],
                         &lbf[spos+18*qdim], &lbf[spos+17*qdim], &lbf[spos+6*qdim], &lbf[spos+7*qdim],
                         &lbf[spos+2*qdim], &lbf[spos+10*qdim], &lbf[spos+12*qdim], &lbf[spos+14*qdim],
                         &lbf[spos+4*qdim], &lbf[spos+9*qdim], &lbf[spos+8*qdim], &lbf[spos+15*qdim],
                         &lbf[spos+16*qdim]);
        break;
      case CETF:
        fD3Q19VCERegular(rho, uwall[1], uwall[2], uwall[0], &force[0], &lbf[spos], &lbf[spos+2*qdim],
                         &lbf[spos+3*qdim], &lbf[spos+1*qdim], &lbf[spos+8*qdim], &lbf[spos+9*qdim],
                         &lbf[spos+4*qdim], &lbf[spos+14*qdim], &lbf[spos+6*qdim], &lbf[spos+16*qdim],
                         &lbf[spos+11*qdim], &lbf[spos+12*qdim], &lbf[spos+10*qdim], &lbf[spos+17*qdim],
                         &lbf[spos+18*qdim], &lbf[spos+13*qdim], &lbf[spos+5*qdim], &lbf[spos+15*qdim],
                         &lbf[spos+7*qdim]);
        break;
      case CELF:
        fD3Q19VCERegular(rho, -uwall[0], uwall[2], uwall[1], &force[0], &lbf[spos], &lbf[spos+10*qdim],
                         &lbf[spos+3*qdim], &lbf[spos+2*qdim], &lbf[spos+16*qdim], &lbf[spos+15*qdim],
                         &lbf[spos+14*qdim], &lbf[spos+13*qdim], &lbf[spos+8*qdim], &lbf[spos+18*qdim],
                         &lbf[spos+1*qdim], &lbf[spos+12*qdim], &lbf[spos+11*qdim], &lbf[spos+7*qdim],
                         &lbf[spos+6*qdim], &lbf[spos+5*qdim], &lbf[spos+4*qdim], &lbf[spos+17*qdim],
                         &lbf[spos+9*qdim]);
        break;
      case CEDF:
        fD3Q19VCERegular(rho, -uwall[1], uwall[2], uwall[0], &force[0], &lbf[spos], &lbf[spos+11*qdim],
                         &lbf[spos+3*qdim], &lbf[spos+1*qdim], &lbf[spos+18*qdim], &lbf[spos+17*qdim],
                         &lbf[spos+5*qdim], &lbf[spos+13*qdim], &lbf[spos+6*qdim], &lbf[spos+16*qdim],
                         &lbf[spos+2*qdim], &lbf[spos+12*qdim], &lbf[spos+10*qdim], &lbf[spos+9*qdim],
                         &lbf[spos+8*qdim], &lbf[spos+14*qdim], &lbf[spos+4*qdim], &lbf[spos+15*qdim],
                         &lbf[spos+7*qdim]);
        break;
      case CERF:
        fD3Q19VCERegular(rho, uwall[0], uwall[2], uwall[1], &force[0], &lbf[spos], &lbf[spos+1*qdim],
                         &lbf[spos+3*qdim], &lbf[spos+2*qdim], &lbf[spos+6*qdim], &lbf[spos+7*qdim],
                         &lbf[spos+4*qdim], &lbf[spos+5*qdim], &lbf[spos+8*qdim], &lbf[spos+18*qdim],
                         &lbf[spos+10*qdim], &lbf[spos+12*qdim], &lbf[spos+11*qdim], &lbf[spos+15*qdim],
                         &lbf[spos+16*qdim], &lbf[spos+13*qdim], &lbf[spos+14*qdim], &lbf[spos+17*qdim],
                         &lbf[spos+9*qdim]);
        break;
      case CETB:
        fD3Q19VCERegular(rho, uwall[1], -uwall[2], uwall[0], &force[0], &lbf[spos], &lbf[spos+2*qdim],
                         &lbf[spos+12*qdim], &lbf[spos+1*qdim], &lbf[spos+9*qdim], &lbf[spos+8*qdim],
                         &lbf[spos+4*qdim], &lbf[spos+14*qdim], &lbf[spos+7*qdim], &lbf[spos+15*qdim],
                         &lbf[spos+11*qdim], &lbf[spos+3*qdim], &lbf[spos+10*qdim], &lbf[spos+18*qdim],
                         &lbf[spos+17*qdim], &lbf[spos+13*qdim], &lbf[spos+5*qdim], &lbf[spos+16*qdim],
                         &lbf[spos+6*qdim]);
        break;
      case CELB:
        fD3Q19VCERegular(rho, -uwall[0], -uwall[2], uwall[1], &force[0], &lbf[spos], &lbf[spos+10*qdim],
                         &lbf[spos+12*qdim], &lbf[spos+2*qdim], &lbf[spos+15*qdim], &lbf[spos+16*qdim],
                         &lbf[spos+14*qdim], &lbf[spos+13*qdim], &lbf[spos+9*qdim], &lbf[spos+17*qdim],
                         &lbf[spos+1*qdim], &lbf[spos+3*qdim], &lbf[spos+11*qdim], &lbf[spos+6*qdim],
                         &lbf[spos+7*qdim], &lbf[spos+5*qdim], &lbf[spos+4*qdim], &lbf[spos+18*qdim],
                         &lbf[spos+8*qdim]);
        break;
      case CEDB:
        fD3Q19VCERegular(rho, -uwall[1], -uwall[2], uwall[0], &force[0], &lbf[spos], &lbf[spos+11*qdim],
                         &lbf[spos+12*qdim], &lbf[spos+1*qdim], &lbf[spos+17*qdim], &lbf[spos+18*qdim],
                         &lbf[spos+5*qdim], &lbf[spos+13*qdim], &lbf[spos+7*qdim], &lbf[spos+15*qdim],
                         &lbf[spos+2*qdim], &lbf[spos+3*qdim], &lbf[spos+10*qdim], &lbf[spos+8*qdim],
                         &lbf[spos+9*qdim], &lbf[spos+14*qdim], &lbf[spos+4*qdim], &lbf[spos+16*qdim],
                         &lbf[spos+6*qdim]);
        break;
      case CERB:
        fD3Q19VCERegular(rho, uwall[0], -uwall[2], uwall[1], &force[0], &lbf[spos], &lbf[spos+1*qdim],
                         &lbf[spos+12*qdim], &lbf[spos+2*qdim], &lbf[spos+7*qdim], &lbf[spos+6*qdim],
                         &lbf[spos+4*qdim], &lbf[spos+5*qdim], &lbf[spos+9*qdim], &lbf[spos+17*qdim],
                         &lbf[spos+10*qdim], &lbf[spos+3*qdim], &lbf[spos+11*qdim], &lbf[spos+16*qdim],
                         &lbf[spos+15*qdim], &lbf[spos+13*qdim], &lbf[spos+14*qdim], &lbf[spos+18*qdim],
                         &lbf[spos+8*qdim]);
        break;
    }
  }
  
  return 0;
  
}


int fD3Q19PPSRegular(double *p, double *force, double *f0, double *f1,
	                 double *f2, double *f3, double *f4, double *f5,
	                 double *f6, double *f7, double *f8, double *f9,
	                 double *f10, double *f11, double *f12, double *f13,
	                 double *f14, double *f15, double *f16, double *f17,
	                 double *f18, double &vel)
{

  // produce fixed pressure/density at planar surface: expressed for bottom wall

  double rho, rho0, pi_xx, pi_yy, pi_zz, pi_xy, pi_xz, pi_yz, v, v1, v1v1, mass=0.0;
  double c1=1.0/3.0,c2=1.0/6.0,c3=1.0/12.0,c4=1.0/24.0;
  vel = 0.0;

  if(!incompress) {
    for(int i=0; i<lbsy.nf; i++) {
      v = p[i]-(f0[i]+f1[i]+f3[i]+f6[i]+f7[i]+f10[i]+f12[i]+f15[i]+f16[i]+2.0*(f2[i]+f4[i]+f8[i]+f9[i]+f14[i]))+0.5*force[3*i+1];
      vel += v;
      mass += p[i];
    }
    vel *= fReciprocal(mass);
    v1 = vel;
    v1v1 = v1*v1;
    for(int i=0; i<lbsy.nf; i++) {
      rho = p[i];
      pi_xx = f1[i]+f6[i]+f7[i]+f10[i]+f15[i]+f16[i]+2.0*(f4[i]+f14[i])+rho*c1*(v1-1.0);
      pi_yy = 2.0*(f2[i]+f4[i]+f8[i]+f9[i]+f14[i])+rho*(v1-v1v1-c1)+v1*force[3*i+1];
      pi_zz = f3[i]+f6[i]+f7[i]+f12[i]+f15[i]+f16[i]+2.0*(f8[i]+f9[i])+rho*c1*(v1-1.0);
      pi_xy = 2.0*(f4[i]-f14[i])+0.5*v1*force[3*i  ];
      pi_xz = f6[i]-f7[i]+f15[i]-f16[i];
      pi_yz = 2.0*(f8[i]-f9[i])+0.5*v1*force[3*i+2];
      f0[i] =rho*lbw[0] *(1.0       -1.5*v1v1)-0.5*(pi_xx+   pi_yy+   pi_zz);
      f1[i] =rho*lbw[1] *(1.0       -1.5*v1v1)+ c2* pi_xx-c3*pi_yy-c3*pi_zz;
      f2[i] =rho*lbw[2] *(1.0-3.0*v1+3.0*v1v1)- c3* pi_xx+c2*pi_yy-c3*pi_zz;
      f3[i] =rho*lbw[3] *(1.0       -1.5*v1v1)- c3* pi_xx-c3*pi_yy+c2*pi_zz;
      f4[i] =rho*lbw[4] *(1.0-3.0*v1+3.0*v1v1)+ c3* pi_xx+c3*pi_yy-c4*pi_zz+0.25*pi_xy;
      f5[i] =rho*lbw[5] *(1.0+3.0*v1+3.0*v1v1)+ c3* pi_xx+c3*pi_yy-c4*pi_zz-0.25*pi_xy;
      f6[i] =rho*lbw[6] *(1.0       -1.5*v1v1)+ c3* pi_xx-c4*pi_yy+c3*pi_zz+0.25*pi_xz;
      f7[i] =rho*lbw[7] *(1.0       -1.5*v1v1)+ c3* pi_xx-c4*pi_yy+c3*pi_zz-0.25*pi_xz;
      f8[i] =rho*lbw[8] *(1.0-3.0*v1+3.0*v1v1)- c4* pi_xx+c3*pi_yy+c3*pi_zz+0.25*pi_yz;
      f9[i] =rho*lbw[9] *(1.0-3.0*v1+3.0*v1v1)- c4* pi_xx+c3*pi_yy+c3*pi_zz-0.25*pi_yz;
      f10[i]=rho*lbw[10]*(1.0       -1.5*v1v1)+ c2* pi_xx-c3*pi_yy-c3*pi_zz;
      f11[i]=rho*lbw[11]*(1.0+3.0*v1+3.0*v1v1)- c3* pi_xx+c2*pi_yy-c3*pi_zz;
      f12[i]=rho*lbw[12]*(1.0       -1.5*v1v1)- c3* pi_xx-c3*pi_yy+c2*pi_zz;
      f13[i]=rho*lbw[13]*(1.0+3.0*v1+3.0*v1v1)+ c3* pi_xx+c3*pi_yy-c4*pi_zz+0.25*pi_xy;
      f14[i]=rho*lbw[14]*(1.0-3.0*v1+3.0*v1v1)+ c3* pi_xx+c3*pi_yy-c4*pi_zz-0.25*pi_xy;
      f15[i]=rho*lbw[15]*(1.0       -1.5*v1v1)+ c3* pi_xx-c4*pi_yy+c3*pi_zz+0.25*pi_xz;
      f16[i]=rho*lbw[16]*(1.0       -1.5*v1v1)+ c3* pi_xx-c4*pi_yy+c3*pi_zz-0.25*pi_xz;
      f17[i]=rho*lbw[17]*(1.0+3.0*v1+3.0*v1v1)- c4* pi_xx+c3*pi_yy+c3*pi_zz+0.25*pi_yz;
      f18[i]=rho*lbw[18]*(1.0+3.0*v1+3.0*v1v1)- c4* pi_xx+c3*pi_yy+c3*pi_zz-0.25*pi_yz;
    }
  }
  else {
    for(int i=0; i<lbsy.nf; i++) {
      v = p[i]-(f0[i]+f1[i]+f3[i]+f6[i]+f7[i]+f10[i]+f12[i]+f15[i]+f16[i]+2.0*(f2[i]+f4[i]+f8[i]+f9[i]+f14[i]))+0.5*force[3*i+1];
      vel += v;
      mass += lbincp[i];
    }
    vel *= fReciprocal(mass);
    v1 = vel;
    v1v1 = v1*v1;
    for(int i=0; i<lbsy.nf; i++) {
      rho0 = lbincp[i];
      rho = p[i];
      pi_xx = f1[i]+f6[i]+f7[i]+f10[i]+f15[i]+f16[i]+2.0*(f4[i]+f14[i])+c1*(rho0*v1-rho);
      pi_yy = 2.0*(f2[i]+f4[i]+f8[i]+f9[i]+f14[i])+rho0*(v1-v1v1)-c1*rho+v1*force[3*i+1];
      pi_zz = f3[i]+f6[i]+f7[i]+f12[i]+f15[i]+f16[i]+2.0*(f8[i]+f9[i])+c1*(rho0*v1-rho);
      pi_xy = 2.0*(f4[i]-f14[i])+0.5*v1*force[3*i  ];
      pi_xz = 2.0*(f6[i]-f7[i]+f15[i]-f16[i]);
      pi_yz = 2.0*(f8[i]-f9[i])+0.5*v1*force[3*i+2];
      f0[i] =lbw[0] *(rho+rho0*(       -1.5*v1v1))-0.5*(pi_xx+   pi_yy+   pi_zz);
      f1[i] =lbw[1] *(rho+rho0*(       -1.5*v1v1))+ c2* pi_xx-c3*pi_yy-c3*pi_zz;
      f2[i] =lbw[2] *(rho+rho0*(-3.0*v1+3.0*v1v1))- c3* pi_xx+c2*pi_yy-c3*pi_zz;
      f3[i] =lbw[3] *(rho+rho0*(       -1.5*v1v1))- c3* pi_xx-c3*pi_yy+c2*pi_zz;
      f4[i] =lbw[4] *(rho+rho0*(-3.0*v1+3.0*v1v1))+ c3* pi_xx+c3*pi_yy-c4*pi_zz+0.25*pi_xy;
      f5[i] =lbw[5] *(rho+rho0*( 3.0*v1+3.0*v1v1))+ c3* pi_xx+c3*pi_yy-c4*pi_zz-0.25*pi_xy;
      f6[i] =lbw[6] *(rho+rho0*(       -1.5*v1v1))+ c3* pi_xx-c4*pi_yy+c3*pi_zz+0.25*pi_xz;
      f7[i] =lbw[7] *(rho+rho0*(       -1.5*v1v1))+ c3* pi_xx-c4*pi_yy+c3*pi_zz-0.25*pi_xz;
      f8[i] =lbw[8] *(rho+rho0*(-3.0*v1+3.0*v1v1))- c4* pi_xx+c3*pi_yy+c3*pi_zz+0.25*pi_yz;
      f9[i] =lbw[9] *(rho+rho0*(-3.0*v1+3.0*v1v1))- c4* pi_xx+c3*pi_yy+c3*pi_zz-0.25*pi_yz;
      f10[i]=lbw[10]*(rho+rho0*(       -1.5*v1v1))+ c2* pi_xx-c3*pi_yy-c3*pi_zz;
      f11[i]=lbw[11]*(rho+rho0*( 3.0*v1+3.0*v1v1))- c3* pi_xx+c2*pi_yy-c3*pi_zz;
      f12[i]=lbw[12]*(rho+rho0*(       -1.5*v1v1))- c3* pi_xx-c3*pi_yy+c2*pi_zz;
      f13[i]=lbw[13]*(rho+rho0*( 3.0*v1+3.0*v1v1))+ c3* pi_xx+c3*pi_yy-c4*pi_zz+0.25*pi_xy;
      f14[i]=lbw[14]*(rho+rho0*(-3.0*v1+3.0*v1v1))+ c3* pi_xx+c3*pi_yy-c4*pi_zz-0.25*pi_xy;
      f15[i]=lbw[15]*(rho+rho0*(       -1.5*v1v1))+ c3* pi_xx-c4*pi_yy+c3*pi_zz+0.25*pi_xz;
      f16[i]=lbw[16]*(rho+rho0*(       -1.5*v1v1))+ c3* pi_xx-c4*pi_yy+c3*pi_zz-0.25*pi_xz;
      f17[i]=lbw[17]*(rho+rho0*( 3.0*v1+3.0*v1v1))- c4* pi_xx+c3*pi_yy+c3*pi_zz+0.25*pi_yz;
      f18[i]=lbw[18]*(rho+rho0*( 3.0*v1+3.0*v1v1))- c4* pi_xx+c3*pi_yy+c3*pi_zz-0.25*pi_yz;
    }
  }
  return 0;
}


int fD3Q19PPSSwiftRegular(double *p, double *force, double *f0, double *f1,
	                      double *f2, double *f3, double *f4, double *f5,
	                      double *f6, double *f7, double *f8, double *f9,
	                      double *f10, double *f11, double *f12, double *f13,
	                      double *f14, double *f15, double *f16, double *f17,
	                      double *f18, double drdx, double drdy, double drdz,
                          double dpdx, double dpdy, double dpdz, double nabr,
                          double nabp, double *omega, double T, double &vel)
{

  // produce fixed pressure/density at planar surface: expressed for bottom wall
  // with Swift free-energy interactions

  double rho, phi, omegat, pb, mu, lambda, d2rdx2, d2rdy2, d2rdz2, d2rdxdy, d2rdxdz, d2rdydz, nabrp;
  double v, v1, v1v1;
  double pi_xx, pi_yy, pi_zz, pi_xy, pi_xz, pi_yz, pic_xx, pic_yy, pic_zz, pic_xy, pic_xz, pic_yz;
  double c1=1.0/3.0,c2=1.0/6.0,c3=1.0/12.0,c4=1.0/24.0;

  rho = p[0];
  v = p[0]-(f0[0]+f1[0]+f3[0]+f6[0]+f7[0]+f10[0]+f12[0]+f15[0]+f16[0]+2.0*(f2[0]+f4[0]+f8[0]+f9[0]+f14[0]))+0.5*force[1];
  vel = v*fReciprocal(rho);
  v1 = vel;
  v1v1 = v1*v1;
  if(lbsy.nf>1) {
    phi = p[1];
    omegat = 0.5*(1.0+phi)*omega[0]+0.5*(1.0-phi)*omega[1];
    mu = lbfemob*fGetPotentialSwift(phi, nabp);
    d2rdx2 = (lbfeeos>0)?(drdx*drdx):0.0 + dpdx*dpdx;
    d2rdy2 = (lbfeeos>0)?(drdy*drdy):0.0 + dpdy*dpdy;
    d2rdz2 = (lbfeeos>0)?(drdz*drdz):0.0 + dpdz*dpdz;
    d2rdxdy = (lbfeeos>0)?(drdx*drdy):0.0 + dpdx*dpdy;
    d2rdxdz = (lbfeeos>0)?(drdx*drdz):0.0 + dpdx*dpdz;
    d2rdydz = (lbfeeos>0)?(drdy*drdz):0.0 + dpdy*dpdz;
    nabrp = (lbfeeos>0)?(rho*nabr):0.0 + phi*nabp;

    pic_xx = f1[1]+f6[1]+f7[1]+f10[1]+f15[1]+f16[1]+2.0*(f4[1]+f14[1])+phi*c1*v1-mu;
    pic_yy = 2.0*(f2[1]+f4[1]+f8[1]+f9[1]+f14[1])+phi*(v1-v1v1)-mu;
    pic_zz = f3[1]+f6[1]+f7[1]+f12[1]+f15[1]+f16[1]+2.0*(f8[1]+f9[1])+phi*c1*v1-mu;
    pic_xy = 2.0*(f4[1]-f14[1]);
    pic_xz = 2.0*(f6[1]-f7[1]+f15[1]-f16[1]);
    pic_yz = 2.0*(f8[1]-f9[1]);

    f0[1] =mu*lbwpt[0] +phi*         (1.0-0.5*lbwi[0]*v1v1)-0.5*(pic_xx+   pic_yy+   pic_zz);
    f1[1] =mu*lbwpt[1] +phi*lbwi[1] *(           -0.5*v1v1)+ c2* pic_xx-c3*pic_yy-c3*pic_zz;
    f2[1] =mu*lbwpt[2] +phi*lbwi[2] *(-v1            +v1v1)- c3* pic_xx+c2*pic_yy-c3*pic_zz;
    f3[1] =mu*lbwpt[3] +phi*lbwi[3] *(           -0.5*v1v1)- c3* pic_xx-c3*pic_yy+c2*pic_zz;
    f4[1] =mu*lbwpt[4] +phi*lbwi[4] *(-v1            +v1v1)+ c3* pic_xx+c3*pic_yy-c4*pic_zz+0.25*pic_xy;
    f5[1] =mu*lbwpt[5] +phi*lbwi[5] *( v1            +v1v1)+ c3* pic_xx+c3*pic_yy-c4*pic_zz-0.25*pic_xy;
    f6[1] =mu*lbwpt[6] +phi*lbwi[6] *(           -0.5*v1v1)+ c3* pic_xx-c4*pic_yy+c3*pic_zz+0.25*pic_xz;
    f7[1] =mu*lbwpt[7] +phi*lbwi[7] *(           -0.5*v1v1)+ c3* pic_xx-c4*pic_yy+c3*pic_zz-0.25*pic_xz;
    f8[1] =mu*lbwpt[8] +phi*lbwi[8] *(-v1            +v1v1)- c4* pic_xx+c3*pic_yy+c3*pic_zz+0.25*pic_yz;
    f9[1] =mu*lbwpt[9] +phi*lbwi[9] *(-v1            +v1v1)- c4* pic_xx+c3*pic_yy+c3*pic_zz-0.25*pic_yz;
    f10[1]=mu*lbwpt[10]+phi*lbwi[10]*(           -0.5*v1v1)+ c2* pic_xx-c3*pic_yy-c3*pic_zz;
    f11[1]=mu*lbwpt[11]+phi*lbwi[11]*( v1            +v1v1)- c3* pic_xx+c2*pic_yy-c3*pic_zz;
    f12[1]=mu*lbwpt[12]+phi*lbwi[12]*(           -0.5*v1v1)- c3* pic_xx-c3*pic_yy+c2*pic_zz;
    f13[1]=mu*lbwpt[13]+phi*lbwi[13]*( v1            +v1v1)+ c3* pic_xx+c3*pic_yy-c4*pic_zz+0.25*pic_xy;
    f14[1]=mu*lbwpt[14]+phi*lbwi[14]*(-v1            +v1v1)+ c3* pic_xx+c3*pic_yy-c4*pic_zz-0.25*pic_xy;
    f15[1]=mu*lbwpt[15]+phi*lbwi[15]*(           -0.5*v1v1)+ c3* pic_xx-c4*pic_yy+c3*pic_zz+0.25*pic_xz;
    f16[1]=mu*lbwpt[16]+phi*lbwi[16]*(           -0.5*v1v1)+ c3* pic_xx-c4*pic_yy+c3*pic_zz-0.25*pic_xz;
    f17[1]=mu*lbwpt[17]+phi*lbwi[17]*( v1            +v1v1)- c4* pic_xx+c3*pic_yy+c3*pic_zz+0.25*pic_yz;
    f18[1]=mu*lbwpt[18]+phi*lbwi[18]*( v1            +v1v1)- c4* pic_xx+c3*pic_yy+c3*pic_zz-0.25*pic_yz;
  }
  else {
    phi = 0.0;
    omegat = omega[0];
    d2rdx2 = drdx*drdx;
    d2rdy2 = drdy*drdy;
    d2rdz2 = drdz*drdz;
    d2rdxdy = drdx*drdy;
    d2rdxdz = drdx*drdz;
    d2rdydz = drdy*drdz;
    nabrp = rho*nabr;
  }
  pb = fGetBulkPressureSwift(rho, phi, T);
  lambda = fGetLambdaSwift(rho, omegat, T);
  pi_xx = f1[0]+f6[0]+f7[0]+f10[0]+f15[0]+f16[0]+2.0*(f4[0]+f14[0])+rho*c1*v1-pb+lbkappa*nabrp-0.5*lbkappa*(d2rdx2-d2rdy2-d2rdz2)-2.0*lambda*v1*drdy;
  pi_yy = 2.0*(f2[0]+f4[0]+f8[0]+f9[0]+f14[0])+rho*(v1-v1v1)+v1*force[1]-pb+lbkappa*nabrp-0.5*lbkappa*(d2rdx2-d2rdy2+d2rdz2)-4.0*lambda*v1*drdy;
  pi_zz = f3[0]+f6[0]+f7[0]+f12[0]+f15[0]+f16[0]+2.0*(f8[0]+f9[0])+rho*c1*v1-pb+lbkappa*nabrp+0.5*lbkappa*(d2rdx2+d2rdy2-d2rdz2)-2.0*lambda*v1*drdy;
  pi_xy = 2.0*(f4[0]-f14[0])+0.5*v1*force[0]-lbkappa*d2rdxdy-lambda*v1*drdx;
  pi_xz = f6[0]-f7[0]+f15[0]-f16[0]-lbkappa*d2rdxdz;
  pi_yz = 2.0*(f8[0]-f9[0])+0.5*v1*force[2]-lbkappa*d2rdydz-lambda*v1*drdz;
    
  f0[0] =rho*(lbw0[0]-0.5*lbwi[0]*v1v1)+lambda*lbwi[0]*lbwdel[0]*v1*drdy
        +lbwpt[0] *(pb-lbkappa*nabrp)+lbkappa*(lbwxx[0]*d2rdx2 +lbwyy[0] *d2rdy2+lbwzz[0] *d2rdz2)
        -0.5*(pi_xx+   pi_yy+   pi_zz);
  f1[0] =lbwi [1] *(rho*(    -0.5*v1v1))
        +lbwpt[1] *(pb-lbkappa*nabrp)+lbkappa*(lbwxx[1] *d2rdx2+lbwyy[1] *d2rdy2+lbwzz[1] *d2rdz2)
        + c2* pi_xx-c3*pi_yy-c3*pi_zz;
  f2[0] =lbwi [2] *(rho*(-v1     +v1v1)+3.0*lambda*drdy*v1)
        +lbwpt[2] *(pb-lbkappa*nabrp)+lbkappa*(lbwxx[2] *d2rdx2+lbwyy[2] *d2rdy2+lbwzz[2] *d2rdz2)
        - c3* pi_xx+c2*pi_yy-c3*pi_zz;
  f3[0] =lbwi [3] *(rho*(    -0.5*v1v1))
        +lbwpt[3] *(pb-lbkappa*nabrp)+lbkappa*(lbwxx[3] *d2rdx2+lbwyy[3] *d2rdy2+lbwzz[3] *d2rdz2)
        - c3* pi_xx-c3*pi_yy+c2*pi_zz;
  f4[0] =lbwi [4] *(rho*(-v1     +v1v1)+1.5*lambda*v1*(drdy+2.0*(drdx+drdy)))
        +lbwpt[4] *(pb-lbkappa*nabrp)+lbkappa*(lbwxx[4] *d2rdx2+lbwyy[4] *d2rdy2+lbwzz[4] *d2rdz2+lbwxy[4] *d2rdxdy+lbwxz[4] *d2rdxdz+lbwyz[4] *d2rdydz)
        + c3* pi_xx+c3*pi_yy-c4*pi_zz+0.25*pi_xy;
  f5[0] =lbwi [5] *(rho*( v1     +v1v1)+1.5*lambda*v1*(drdy-2.0*(drdx-drdy)))
        +lbwpt[5] *(pb-lbkappa*nabrp)+lbkappa*(lbwxx[5] *d2rdx2+lbwyy[5] *d2rdy2+lbwzz[5] *d2rdz2+lbwxy[5] *d2rdxdy+lbwxz[5] *d2rdxdz+lbwyz[5] *d2rdydz)
        + c3* pi_xx+c3*pi_yy-c4*pi_zz-0.25*pi_xy;
  f6[0] =lbwi [6] *(rho*(    -0.5*v1v1)+1.5*lambda*v1*drdy)
        +lbwpt[6] *(pb-lbkappa*nabrp)+lbkappa*(lbwxx[6] *d2rdx2+lbwyy[6] *d2rdy2+lbwzz[6] *d2rdz2+lbwxy[6] *d2rdxdy+lbwxz[6] *d2rdxdz+lbwyz[6] *d2rdydz)
        + c3* pi_xx-c4*pi_yy+c3*pi_zz+0.25*pi_xz;
  f7[0] =lbwi [7] *(rho*(    -0.5*v1v1)+1.5*lambda*v1*drdy)
        +lbwpt[7] *(pb-lbkappa*nabrp)+lbkappa*(lbwxx[7] *d2rdx2+lbwyy[7] *d2rdy2+lbwzz[7] *d2rdz2+lbwxy[7] *d2rdxdy+lbwxz[7] *d2rdxdz+lbwyz[7] *d2rdydz)
        + c3* pi_xx-c4*pi_yy+c3*pi_zz-0.25*pi_xz;
  f8[0] =lbwi [8] *(rho*(-v1     +v1v1)+1.5*lambda*v1*(drdy+2.0*(drdy+drdz)))
        +lbwpt[8] *(pb-lbkappa*nabrp)+lbkappa*(lbwxx[8] *d2rdx2+lbwyy[8] *d2rdy2+lbwzz[8] *d2rdz2+lbwxy[8] *d2rdxdy+lbwxz[8] *d2rdxdz+lbwyz[8] *d2rdydz)
        - c4* pi_xx+c3*pi_yy+c3*pi_zz+0.25*pi_yz;
  f9[0] =lbwi [9] *(rho*(-v1     +v1v1)+1.5*lambda*v1*(drdy+2.0*(drdy-drdz)))
        +lbwpt[9] *(pb-lbkappa*nabrp)+lbkappa*(lbwxx[9] *d2rdx2+lbwyy[9] *d2rdy2+lbwzz[9] *d2rdz2+lbwxy[9] *d2rdxdy+lbwxz[9] *d2rdxdz+lbwyz[9] *d2rdydz)
        - c4* pi_xx+c3*pi_yy+c3*pi_zz-0.25*pi_yz;
  f10[0]=lbwi [10]*(rho*(    -0.5*v1v1))
        +lbwpt[10]*(pb-lbkappa*nabrp)+lbkappa*(lbwxx[10]*d2rdx2+lbwyy[10]*d2rdy2+lbwzz[10]*d2rdz2)
        + c2* pi_xx-c3*pi_yy-c3*pi_zz;
  f11[0]=lbwi [11]*(rho*( v1     +v1v1)+3.0*lambda*drdy*v1)
        +lbwpt[11]*(pb-lbkappa*nabrp)+lbkappa*(lbwxx[11]*d2rdx2+lbwyy[11]*d2rdy2+lbwzz[11]*d2rdz2)
        - c3* pi_xx+c2*pi_yy-c3*pi_zz;
  f12[0]=lbwi [12]*(rho*(    -0.5*v1v1))
        +lbwpt[12]*(pb-lbkappa*nabrp)+lbkappa*(lbwxx[12]*d2rdx2+lbwyy[12]*d2rdy2+lbwzz[12]*d2rdz2)
        - c3* pi_xx-c3*pi_yy+c2*pi_zz;
  f13[0]=lbwi [13]*(rho*( v1     +v1v1)+1.5*lambda*v1*(drdy+2.0*(drdx+drdy)))
        +lbwpt[13]*(pb-lbkappa*nabrp)+lbkappa*(lbwxx[13]*d2rdx2+lbwyy[13]*d2rdy2+lbwzz[13]*d2rdz2+lbwxy[13]*d2rdxdy+lbwxz[13]*d2rdxdz+lbwyz[13]*d2rdydz)
        + c3* pi_xx+c3*pi_yy-c4*pi_zz+0.25*pi_xy;
  f14[0]=lbwi [14]*(rho*(-v1     +v1v1)+1.5*lambda*v1*(drdy-2.0*(drdx-drdy)))
        +lbwpt[14]*(pb-lbkappa*nabrp)+lbkappa*(lbwxx[14]*d2rdx2+lbwyy[14]*d2rdy2+lbwzz[14]*d2rdz2+lbwxy[14]*d2rdxdy+lbwxz[14]*d2rdxdz+lbwyz[14]*d2rdydz)
        + c3* pi_xx+c3*pi_yy-c4*pi_zz-0.25*pi_xy;
  f15[0]=lbwi [15]*(rho*(    -0.5*v1v1)+1.5*lambda*v1*drdy)
        +lbwpt[15]*(pb-lbkappa*nabrp)+lbkappa*(lbwxx[15]*d2rdx2+lbwyy[15]*d2rdy2+lbwzz[15]*d2rdz2+lbwxy[15]*d2rdxdy+lbwxz[15]*d2rdxdz+lbwyz[15]*d2rdydz)
        + c3* pi_xx-c4*pi_yy+c3*pi_zz+0.25*pi_xz;
  f16[0]=lbwi [16]*(rho*(    -0.5*v1v1)+1.5*lambda*v1*drdy)
        +lbwpt[16]*(pb-lbkappa*nabrp)+lbkappa*(lbwxx[16]*d2rdx2+lbwyy[16]*d2rdy2+lbwzz[16]*d2rdz2+lbwxy[16]*d2rdxdy+lbwxz[16]*d2rdxdz+lbwyz[16]*d2rdydz)
        + c3* pi_xx-c4*pi_yy+c3*pi_zz-0.25*pi_xz;
  f17[0]=lbwi [17]*(rho*( v1     +v1v1)+1.5*lambda*v1*(drdy+2.0*(drdy+drdz)))
        +lbwpt[17]*(pb-lbkappa*nabrp)+lbkappa*(lbwxx[17]*d2rdx2+lbwyy[17]*d2rdy2+lbwzz[17]*d2rdz2+lbwxy[17]*d2rdxdy+lbwxz[17]*d2rdxdz+lbwyz[17]*d2rdydz)
        - c4* pi_xx+c3*pi_yy+c3*pi_zz+0.25*pi_yz;
  f18[0]=lbwi [18]*(rho*( v1     +v1v1)+1.5*lambda*v1*(drdy+2.0*(drdy-drdz)))
        +lbwpt[18]*(pb-lbkappa*nabrp)+lbkappa*(lbwxx[18]*d2rdx2+lbwyy[18]*d2rdy2+lbwzz[18]*d2rdz2+lbwxy[18]*d2rdxdy+lbwxz[18]*d2rdxdz+lbwyz[18]*d2rdydz)
        - c4* pi_xx+c3*pi_yy+c3*pi_zz-0.25*pi_yz;
  return 0;
}


int fD3Q19PFRegular(long tpos, int prop, double *p0, double *uwall, double T)
{
  double moment, drdx, drdy, drdz, dpdx, dpdy, dpdz, nabr, nabp;
  long spos=tpos * lbsitelength;
  int qdim = lbsy.nf+lbsy.nc+lbsy.nt;
  double force[3*lbsy.nf];
    
  fD3Q19BoundaryForceDensity(force, tpos, p0, prop);

  if(interact==20) {
    drdx = lbft[4*lbsy.nf*tpos  ];
    drdy = lbft[4*lbsy.nf*tpos+1];
    drdz = lbft[4*lbsy.nf*tpos+2];
    nabr = lbft[4*lbsy.nf*tpos+3];
    dpdx = (lbsy.nf>1)?lbft[4*lbsy.nf*tpos+4]:0.0;
    dpdy = (lbsy.nf>1)?lbft[4*lbsy.nf*tpos+5]:0.0;
    dpdz = (lbsy.nf>1)?lbft[4*lbsy.nf*tpos+6]:0.0;
    nabp = (lbsy.nf>1)?lbft[4*lbsy.nf*tpos+7]:0.0;
    switch (prop) {
      case PST:
        fD3Q19PPSSwiftRegular(p0, &force[0], &lbf[spos], &lbf[spos+1*qdim],
                              &lbf[spos+2*qdim], &lbf[spos+3*qdim], &lbf[spos+4*qdim], &lbf[spos+5*qdim],
                              &lbf[spos+6*qdim], &lbf[spos+7*qdim], &lbf[spos+8*qdim], &lbf[spos+9*qdim],
                              &lbf[spos+10*qdim], &lbf[spos+11*qdim], &lbf[spos+12*qdim], &lbf[spos+13*qdim],
                              &lbf[spos+14*qdim], &lbf[spos+15*qdim], &lbf[spos+16*qdim], &lbf[spos+17*qdim],
                              &lbf[spos+18*qdim], drdx, drdy, drdz, dpdx, dpdy, dpdz, nabr, nabp,
                              &lbomega[lbsy.nf*tpos], T, moment);
        uwall[1] += moment;
        break;
      case PSD:
        fD3Q19PPSSwiftRegular(p0, &force[0], &lbf[spos], &lbf[spos+10*qdim],
                              &lbf[spos+11*qdim], &lbf[spos+12*qdim], &lbf[spos+13*qdim], &lbf[spos+14*qdim],
                              &lbf[spos+15*qdim], &lbf[spos+16*qdim], &lbf[spos+17*qdim], &lbf[spos+18*qdim],
                              &lbf[spos+1*qdim], &lbf[spos+2*qdim], &lbf[spos+3*qdim], &lbf[spos+4*qdim],
                              &lbf[spos+5*qdim], &lbf[spos+6*qdim], &lbf[spos+7*qdim], &lbf[spos+8*qdim],
                              &lbf[spos+9*qdim], -drdx, -drdy, -drdz, -dpdx, -dpdy, -dpdz, nabr, nabp,
                              &lbomega[lbsy.nf*tpos], T, moment);
        uwall[1] -= moment;
        break;
      case PSL:
        fD3Q19PPSSwiftRegular(p0, &force[0], &lbf[spos], &lbf[spos+12*qdim],
                            &lbf[spos+10*qdim], &lbf[spos+11*qdim], &lbf[spos+15*qdim], &lbf[spos+7*qdim],
                            &lbf[spos+17*qdim], &lbf[spos+9*qdim], &lbf[spos+13*qdim], &lbf[spos+14*qdim],
                            &lbf[spos+3*qdim], &lbf[spos+1*qdim], &lbf[spos+2*qdim], &lbf[spos+6*qdim],
                            &lbf[spos+16*qdim], &lbf[spos+8*qdim], &lbf[spos+18*qdim], &lbf[spos+4*qdim],
                            &lbf[spos+5*qdim], -drdz, -drdx, -drdy, -dpdz, -dpdx, -dpdy, nabr, nabp,
                              &lbomega[lbsy.nf*tpos], T, moment);
        uwall[0] -= moment;
        break;
      case PSR:
        fD3Q19PPSSwiftRegular(p0, &force[0], &lbf[spos], &lbf[spos+3*qdim],
                              &lbf[spos+1*qdim], &lbf[spos+2*qdim], &lbf[spos+6*qdim], &lbf[spos+16*qdim],
                              &lbf[spos+8*qdim], &lbf[spos+18*qdim], &lbf[spos+4*qdim], &lbf[spos+5*qdim],
                              &lbf[spos+12*qdim], &lbf[spos+10*qdim], &lbf[spos+11*qdim], &lbf[spos+15*qdim],
                              &lbf[spos+7*qdim], &lbf[spos+17*qdim], &lbf[spos+9*qdim], &lbf[spos+13*qdim],
                              &lbf[spos+14*qdim], drdz, drdx, drdy, dpdz, dpdx, dpdy, nabr, nabp,
                              &lbomega[lbsy.nf*tpos], T, moment);
        uwall[0] += moment;
        break;
      case PSF:
        fD3Q19PPSSwiftRegular(p0, &force[0], &lbf[spos], &lbf[spos+11*qdim],
                              &lbf[spos+12*qdim], &lbf[spos+10*qdim], &lbf[spos+17*qdim], &lbf[spos+18*qdim],
                              &lbf[spos+13*qdim], &lbf[spos+5*qdim], &lbf[spos+15*qdim], &lbf[spos+7*qdim],
                              &lbf[spos+2*qdim], &lbf[spos+3*qdim], &lbf[spos+1*qdim], &lbf[spos+8*qdim],
                              &lbf[spos+9*qdim], &lbf[spos+4*qdim], &lbf[spos+14*qdim], &lbf[spos+6*qdim],
                              &lbf[spos+16*qdim], -drdy, -drdz, -drdx, -dpdy, -dpdz, -dpdx, nabr, nabp,
                              &lbomega[lbsy.nf*tpos], T, moment);
        uwall[2] -= moment;
        break;
      case PSB:
        fD3Q19PPSSwiftRegular(p0, &force[0], &lbf[spos], &lbf[spos+2*qdim],
                              &lbf[spos+3*qdim], &lbf[spos+1*qdim], &lbf[spos+8*qdim], &lbf[spos+9*qdim],
                              &lbf[spos+4*qdim], &lbf[spos+14*qdim], &lbf[spos+6*qdim], &lbf[spos+16*qdim],
                              &lbf[spos+11*qdim], &lbf[spos+12*qdim], &lbf[spos+10*qdim], &lbf[spos+17*qdim],
                              &lbf[spos+18*qdim], &lbf[spos+13*qdim], &lbf[spos+5*qdim], &lbf[spos+15*qdim],
                              &lbf[spos+7*qdim], drdy, drdz, drdx, dpdy, dpdz, dpdx, nabr, nabp,
                              &lbomega[lbsy.nf*tpos], T, moment);
        uwall[2] += moment;
        break;
      case CCTRB:
        fD3Q19VCCSwiftRegular(p0, uwall[0], uwall[1], -uwall[2], &force[0], &lbf[spos], &lbf[spos+1*qdim],
                              &lbf[spos+2*qdim], &lbf[spos+12*qdim], &lbf[spos+4*qdim], &lbf[spos+5*qdim],
                              &lbf[spos+7*qdim], &lbf[spos+6*qdim], &lbf[spos+9*qdim], &lbf[spos+8*qdim],
                              &lbf[spos+10*qdim], &lbf[spos+11*qdim], &lbf[spos+3*qdim], &lbf[spos+13*qdim],
                              &lbf[spos+14*qdim], &lbf[spos+16*qdim], &lbf[spos+15*qdim], &lbf[spos+18*qdim],
                              &lbf[spos+17*qdim], drdx, drdy, -drdz, dpdx, dpdy, -dpdz, nabr, nabp,
                              &lbomega[lbsy.nf*tpos], T);
        break;
      case CCTLB:
        fD3Q19VCCSwiftRegular(p0, -uwall[0], uwall[1], -uwall[2], &force[0], &lbf[spos], &lbf[spos+10*qdim],
                              &lbf[spos+2*qdim], &lbf[spos+12*qdim], &lbf[spos+14*qdim], &lbf[spos+13*qdim],
                              &lbf[spos+15*qdim], &lbf[spos+16*qdim], &lbf[spos+9*qdim], &lbf[spos+8*qdim],
                              &lbf[spos+1*qdim], &lbf[spos+11*qdim], &lbf[spos+3*qdim], &lbf[spos+5*qdim],
                              &lbf[spos+4*qdim], &lbf[spos+6*qdim], &lbf[spos+7*qdim], &lbf[spos+18*qdim],
                              &lbf[spos+17*qdim], -drdx, drdy, -drdz, -dpdx, dpdy, -dpdz, nabr, nabp,
                              &lbomega[lbsy.nf*tpos], T);
        break;
      case CCDLB:
        fD3Q19VCCSwiftRegular(p0, -uwall[0], -uwall[1], -uwall[2], &force[0], &lbf[spos], &lbf[spos+10*qdim],
                              &lbf[spos+11*qdim], &lbf[spos+12*qdim], &lbf[spos+13*qdim], &lbf[spos+14*qdim],
                              &lbf[spos+15*qdim], &lbf[spos+16*qdim], &lbf[spos+17*qdim], &lbf[spos+18*qdim],
                              &lbf[spos+1*qdim], &lbf[spos+2*qdim], &lbf[spos+3*qdim], &lbf[spos+4*qdim],
                              &lbf[spos+5*qdim], &lbf[spos+6*qdim], &lbf[spos+7*qdim], &lbf[spos+8*qdim],
                              &lbf[spos+9*qdim], -drdx, -drdy, -drdz, -dpdx, -dpdy, -dpdz, nabr, nabp,
                              &lbomega[lbsy.nf*tpos], T);
        break;
      case CCDRB:
        fD3Q19VCCSwiftRegular(p0, uwall[0], -uwall[1], -uwall[2], &force[0], &lbf[spos], &lbf[spos+1*qdim],
                              &lbf[spos+11*qdim], &lbf[spos+12*qdim], &lbf[spos+5*qdim], &lbf[spos+4*qdim],
                              &lbf[spos+7*qdim], &lbf[spos+6*qdim], &lbf[spos+17*qdim], &lbf[spos+18*qdim],
                              &lbf[spos+10*qdim], &lbf[spos+2*qdim], &lbf[spos+3*qdim], &lbf[spos+14*qdim],
                              &lbf[spos+13*qdim], &lbf[spos+16*qdim], &lbf[spos+15*qdim], &lbf[spos+8*qdim],
                              &lbf[spos+9*qdim], drdx, -drdy, -drdz, dpdx, -dpdy, -dpdz, nabr, nabp,
                              &lbomega[lbsy.nf*tpos], T);
        break;
      case CCTRF:
        fD3Q19VCCSwiftRegular(p0, uwall[0], uwall[1], uwall[2], &force[0], &lbf[spos], &lbf[spos+1*qdim],
                              &lbf[spos+2*qdim], &lbf[spos+3*qdim], &lbf[spos+4*qdim], &lbf[spos+5*qdim],
                              &lbf[spos+6*qdim], &lbf[spos+7*qdim], &lbf[spos+8*qdim], &lbf[spos+9*qdim],
                              &lbf[spos+10*qdim], &lbf[spos+11*qdim], &lbf[spos+12*qdim], &lbf[spos+13*qdim],
                              &lbf[spos+14*qdim], &lbf[spos+15*qdim], &lbf[spos+16*qdim], &lbf[spos+17*qdim],
                              &lbf[spos+18*qdim], drdx, drdy, drdz, dpdx, dpdy, dpdz, nabr, nabp,
                              &lbomega[lbsy.nf*tpos], T);
        break;
      case CCTLF:
        fD3Q19VCCSwiftRegular(p0, -uwall[0], uwall[1], uwall[2], &force[0], &lbf[spos], &lbf[spos+10*qdim],
                              &lbf[spos+2*qdim], &lbf[spos+3*qdim], &lbf[spos+14*qdim], &lbf[spos+13*qdim],
                              &lbf[spos+16*qdim], &lbf[spos+15*qdim], &lbf[spos+8*qdim], &lbf[spos+9*qdim],
                              &lbf[spos+1*qdim], &lbf[spos+11*qdim], &lbf[spos+12*qdim], &lbf[spos+5*qdim],
                              &lbf[spos+4*qdim], &lbf[spos+7*qdim], &lbf[spos+6*qdim], &lbf[spos+17*qdim],
                              &lbf[spos+18*qdim], -drdx, drdy, drdz, -dpdx, dpdy, dpdz, nabr, nabp,
                              &lbomega[lbsy.nf*tpos], T);
        break;
      case CCDLF:
        fD3Q19VCCSwiftRegular(p0, -uwall[0], -uwall[1], uwall[2], &force[0], &lbf[spos], &lbf[spos+10*qdim],
                              &lbf[spos+11*qdim], &lbf[spos+3*qdim], &lbf[spos+13*qdim], &lbf[spos+14*qdim],
                              &lbf[spos+16*qdim], &lbf[spos+15*qdim], &lbf[spos+18*qdim], &lbf[spos+17*qdim],
                              &lbf[spos+1*qdim], &lbf[spos+2*qdim], &lbf[spos+12*qdim], &lbf[spos+4*qdim],
                              &lbf[spos+5*qdim], &lbf[spos+7*qdim], &lbf[spos+6*qdim], &lbf[spos+9*qdim],
                              &lbf[spos+8*qdim], -drdx, -drdy, drdz, -dpdx, -dpdy, dpdz, nabr, nabp,
                              &lbomega[lbsy.nf*tpos], T);
        break;
      case CCDRF:
        fD3Q19VCCSwiftRegular(p0, uwall[0], -uwall[1], uwall[2], &force[0], &lbf[spos], &lbf[spos+1*qdim],
                              &lbf[spos+11*qdim], &lbf[spos+3*qdim], &lbf[spos+5*qdim], &lbf[spos+4*qdim],
                              &lbf[spos+6*qdim], &lbf[spos+7*qdim], &lbf[spos+18*qdim], &lbf[spos+17*qdim],
                              &lbf[spos+10*qdim], &lbf[spos+2*qdim], &lbf[spos+12*qdim], &lbf[spos+14*qdim],
                              &lbf[spos+13*qdim], &lbf[spos+15*qdim], &lbf[spos+16*qdim], &lbf[spos+9*qdim],
                              &lbf[spos+8*qdim], drdx, -drdy, drdz, dpdx, -dpdy, dpdz, nabr, nabp,
                              &lbomega[lbsy.nf*tpos], T);
        break;
      case CETR:
        fD3Q19VCESwiftRegular(p0, uwall[0], uwall[1], uwall[2], &force[0], &lbf[spos], &lbf[spos+1*qdim],
                              &lbf[spos+2*qdim], &lbf[spos+3*qdim], &lbf[spos+4*qdim], &lbf[spos+5*qdim],
                              &lbf[spos+6*qdim], &lbf[spos+7*qdim], &lbf[spos+8*qdim], &lbf[spos+9*qdim],
                              &lbf[spos+10*qdim], &lbf[spos+11*qdim], &lbf[spos+12*qdim], &lbf[spos+13*qdim],
                              &lbf[spos+14*qdim], &lbf[spos+15*qdim], &lbf[spos+16*qdim], &lbf[spos+17*qdim],
                              &lbf[spos+18*qdim], drdx, drdy, drdz, dpdx, dpdy, dpdz, nabr, nabp,
                              &lbomega[lbsy.nf*tpos], T);
        break;
      case CETL:
        fD3Q19VCESwiftRegular(p0, uwall[1], -uwall[0], uwall[2], &force[0], &lbf[spos], &lbf[spos+2*qdim],
                              &lbf[spos+10*qdim], &lbf[spos+3*qdim], &lbf[spos+14*qdim], &lbf[spos+4*qdim],
                              &lbf[spos+8*qdim], &lbf[spos+9*qdim], &lbf[spos+16*qdim], &lbf[spos+15*qdim],
                              &lbf[spos+11*qdim], &lbf[spos+1*qdim], &lbf[spos+12*qdim], &lbf[spos+5*qdim],
                              &lbf[spos+13*qdim], &lbf[spos+17*qdim], &lbf[spos+18*qdim], &lbf[spos+7*qdim],
                              &lbf[spos+6*qdim], drdy, -drdx, drdz, dpdy, -dpdx, dpdz, nabr, nabp,
                              &lbomega[lbsy.nf*tpos], T);
        break;
      case CEDL:
        fD3Q19VCESwiftRegular(p0, -uwall[0], -uwall[1], uwall[2], &force[0], &lbf[spos], &lbf[spos+10*qdim],
                              &lbf[spos+11*qdim], &lbf[spos+3*qdim], &lbf[spos+13*qdim], &lbf[spos+14*qdim],
                              &lbf[spos+16*qdim], &lbf[spos+15*qdim], &lbf[spos+18*qdim], &lbf[spos+17*qdim],
                              &lbf[spos+1*qdim], &lbf[spos+2*qdim], &lbf[spos+12*qdim], &lbf[spos+4*qdim],
                              &lbf[spos+5*qdim], &lbf[spos+7*qdim], &lbf[spos+6*qdim], &lbf[spos+9*qdim],
                              &lbf[spos+8*qdim], -drdx, -drdy, drdz, -dpdx, -dpdy, dpdz, nabr, nabp,
                              &lbomega[lbsy.nf*tpos], T);
        break;
      case CEDR:
        fD3Q19VCESwiftRegular(p0, -uwall[1], uwall[0], uwall[2], &force[0], &lbf[spos], &lbf[spos+11*qdim],
                              &lbf[spos+1*qdim], &lbf[spos+3*qdim], &lbf[spos+5*qdim], &lbf[spos+13*qdim],
                              &lbf[spos+18*qdim], &lbf[spos+17*qdim], &lbf[spos+6*qdim], &lbf[spos+7*qdim],
                              &lbf[spos+2*qdim], &lbf[spos+10*qdim], &lbf[spos+12*qdim], &lbf[spos+14*qdim],
                              &lbf[spos+4*qdim], &lbf[spos+9*qdim], &lbf[spos+8*qdim], &lbf[spos+15*qdim],
                              &lbf[spos+16*qdim], -drdy, drdx, drdz, -dpdy, dpdx, dpdz, nabr, nabp,
                              &lbomega[lbsy.nf*tpos], T);
        break;
      case CETF:
        fD3Q19VCESwiftRegular(p0, uwall[1], uwall[2], uwall[0], &force[0], &lbf[spos], &lbf[spos+2*qdim],
                              &lbf[spos+3*qdim], &lbf[spos+1*qdim], &lbf[spos+8*qdim], &lbf[spos+9*qdim],
                              &lbf[spos+4*qdim], &lbf[spos+14*qdim], &lbf[spos+6*qdim], &lbf[spos+16*qdim],
                              &lbf[spos+11*qdim], &lbf[spos+12*qdim], &lbf[spos+10*qdim], &lbf[spos+17*qdim],
                              &lbf[spos+18*qdim], &lbf[spos+13*qdim], &lbf[spos+5*qdim], &lbf[spos+15*qdim],
                              &lbf[spos+7*qdim], drdy, drdz, drdx, dpdy, dpdz, dpdx, nabr, nabp,
                              &lbomega[lbsy.nf*tpos], T);
        break;
      case CELF:
        fD3Q19VCESwiftRegular(p0, -uwall[0], uwall[2], uwall[1], &force[0], &lbf[spos], &lbf[spos+10*qdim],
                              &lbf[spos+3*qdim], &lbf[spos+2*qdim], &lbf[spos+16*qdim], &lbf[spos+15*qdim],
                              &lbf[spos+14*qdim], &lbf[spos+13*qdim], &lbf[spos+8*qdim], &lbf[spos+18*qdim],
                              &lbf[spos+1*qdim], &lbf[spos+12*qdim], &lbf[spos+11*qdim], &lbf[spos+7*qdim],
                              &lbf[spos+6*qdim], &lbf[spos+5*qdim], &lbf[spos+4*qdim], &lbf[spos+17*qdim],
                              &lbf[spos+9*qdim], -drdx, drdz, drdy, -dpdx, dpdz, dpdy, nabr, nabp,
                              &lbomega[lbsy.nf*tpos], T);
        break;
      case CEDF:
        fD3Q19VCESwiftRegular(p0, -uwall[1], uwall[2], uwall[0], &force[0], &lbf[spos], &lbf[spos+11*qdim],
                              &lbf[spos+3*qdim], &lbf[spos+1*qdim], &lbf[spos+18*qdim], &lbf[spos+17*qdim],
                              &lbf[spos+5*qdim], &lbf[spos+13*qdim], &lbf[spos+6*qdim], &lbf[spos+16*qdim],
                              &lbf[spos+2*qdim], &lbf[spos+12*qdim], &lbf[spos+10*qdim], &lbf[spos+9*qdim],
                              &lbf[spos+8*qdim], &lbf[spos+14*qdim], &lbf[spos+4*qdim], &lbf[spos+15*qdim],
                              &lbf[spos+7*qdim], -drdy, drdz, drdx, -dpdy, dpdz, dpdx, nabr, nabp,
                              &lbomega[lbsy.nf*tpos], T);
        break;
      case CERF:
        fD3Q19VCESwiftRegular(p0, uwall[0], uwall[2], uwall[1], &force[0], &lbf[spos], &lbf[spos+1*qdim],
                              &lbf[spos+3*qdim], &lbf[spos+2*qdim], &lbf[spos+6*qdim], &lbf[spos+7*qdim],
                              &lbf[spos+4*qdim], &lbf[spos+5*qdim], &lbf[spos+8*qdim], &lbf[spos+18*qdim],
                              &lbf[spos+10*qdim], &lbf[spos+12*qdim], &lbf[spos+11*qdim], &lbf[spos+15*qdim],
                              &lbf[spos+16*qdim], &lbf[spos+13*qdim], &lbf[spos+14*qdim], &lbf[spos+17*qdim],
                              &lbf[spos+9*qdim], drdx, drdz, drdy, dpdx, dpdz, dpdy, nabr, nabp,
                              &lbomega[lbsy.nf*tpos], T);
        break;
      case CETB:
        fD3Q19VCESwiftRegular(p0, uwall[1], -uwall[2], uwall[0], &force[0], &lbf[spos], &lbf[spos+2*qdim],
                              &lbf[spos+12*qdim], &lbf[spos+1*qdim], &lbf[spos+9*qdim], &lbf[spos+8*qdim],
                              &lbf[spos+4*qdim], &lbf[spos+14*qdim], &lbf[spos+7*qdim], &lbf[spos+15*qdim],
                              &lbf[spos+11*qdim], &lbf[spos+3*qdim], &lbf[spos+10*qdim], &lbf[spos+18*qdim],
                              &lbf[spos+17*qdim], &lbf[spos+13*qdim], &lbf[spos+5*qdim], &lbf[spos+16*qdim],
                              &lbf[spos+6*qdim], drdy, -drdz, drdx, dpdy, -dpdz, dpdx, nabr, nabp,
                              &lbomega[lbsy.nf*tpos], T);
        break;
      case CELB:
        fD3Q19VCESwiftRegular(p0, -uwall[0], -uwall[2], uwall[1], &force[0], &lbf[spos], &lbf[spos+10*qdim],
                              &lbf[spos+12*qdim], &lbf[spos+2*qdim], &lbf[spos+15*qdim], &lbf[spos+16*qdim],
                              &lbf[spos+14*qdim], &lbf[spos+13*qdim], &lbf[spos+9*qdim], &lbf[spos+17*qdim],
                              &lbf[spos+1*qdim], &lbf[spos+3*qdim], &lbf[spos+11*qdim], &lbf[spos+6*qdim],
                              &lbf[spos+7*qdim], &lbf[spos+5*qdim], &lbf[spos+4*qdim], &lbf[spos+18*qdim],
                              &lbf[spos+8*qdim], -drdx, -drdz, drdy, -dpdx, -dpdz, dpdy, nabr, nabp,
                              &lbomega[lbsy.nf*tpos], T);
        break;
      case CEDB:
        fD3Q19VCESwiftRegular(p0, -uwall[1], -uwall[2], uwall[0], &force[0], &lbf[spos], &lbf[spos+11*qdim],
                              &lbf[spos+12*qdim], &lbf[spos+1*qdim], &lbf[spos+17*qdim], &lbf[spos+18*qdim],
                              &lbf[spos+5*qdim], &lbf[spos+13*qdim], &lbf[spos+7*qdim], &lbf[spos+15*qdim],
                              &lbf[spos+2*qdim], &lbf[spos+3*qdim], &lbf[spos+10*qdim], &lbf[spos+8*qdim],
                              &lbf[spos+9*qdim], &lbf[spos+14*qdim], &lbf[spos+4*qdim], &lbf[spos+16*qdim],
                              &lbf[spos+6*qdim], -drdy, -drdz, drdx, -dpdy, -dpdz, dpdx, nabr, nabp,
                              &lbomega[lbsy.nf*tpos], T);
        break;
      case CERB:
        fD3Q19VCESwiftRegular(p0, uwall[0], -uwall[2], uwall[1], &force[0], &lbf[spos], &lbf[spos+1*qdim],
                              &lbf[spos+12*qdim], &lbf[spos+2*qdim], &lbf[spos+7*qdim], &lbf[spos+6*qdim],
                              &lbf[spos+4*qdim], &lbf[spos+5*qdim], &lbf[spos+9*qdim], &lbf[spos+17*qdim],
                              &lbf[spos+10*qdim], &lbf[spos+3*qdim], &lbf[spos+11*qdim], &lbf[spos+16*qdim],
                              &lbf[spos+15*qdim], &lbf[spos+13*qdim], &lbf[spos+14*qdim], &lbf[spos+18*qdim],
                              &lbf[spos+8*qdim], drdx, -drdz, drdy, dpdx, -dpdz, dpdy, nabr, nabp,
                              &lbomega[lbsy.nf*tpos], T);
        break;
    }
  }
  else if(collide>11) {
    switch (prop) {
      case PST:
        fD3Q19PPSRegular(p0, &force[0], &lbf[spos], &lbf[spos+1*qdim],
                         &lbf[spos+2*qdim], &lbf[spos+3*qdim], &lbf[spos+4*qdim], &lbf[spos+5*qdim],
                         &lbf[spos+6*qdim], &lbf[spos+7*qdim], &lbf[spos+8*qdim], &lbf[spos+9*qdim],
                         &lbf[spos+10*qdim], &lbf[spos+11*qdim], &lbf[spos+12*qdim], &lbf[spos+13*qdim],
                         &lbf[spos+14*qdim], &lbf[spos+15*qdim], &lbf[spos+16*qdim], &lbf[spos+17*qdim],
                         &lbf[spos+18*qdim], moment);
        uwall[1] += moment;
        break;
      case PSD:
        fD3Q19PPSRegular(p0, &force[0], &lbf[spos], &lbf[spos+10*qdim],
                         &lbf[spos+11*qdim], &lbf[spos+12*qdim], &lbf[spos+13*qdim], &lbf[spos+14*qdim],
                         &lbf[spos+15*qdim], &lbf[spos+16*qdim], &lbf[spos+17*qdim], &lbf[spos+18*qdim],
                         &lbf[spos+1*qdim], &lbf[spos+2*qdim], &lbf[spos+3*qdim], &lbf[spos+4*qdim],
                         &lbf[spos+5*qdim], &lbf[spos+6*qdim], &lbf[spos+7*qdim], &lbf[spos+8*qdim],
                         &lbf[spos+9*qdim], moment);
        uwall[1] -= moment;
        break;
      case PSL:
        fD3Q19PPSRegular(p0, &force[0], &lbf[spos], &lbf[spos+12*qdim],
                         &lbf[spos+10*qdim], &lbf[spos+11*qdim], &lbf[spos+15*qdim], &lbf[spos+7*qdim],
                         &lbf[spos+17*qdim], &lbf[spos+9*qdim], &lbf[spos+13*qdim], &lbf[spos+14*qdim],
                         &lbf[spos+3*qdim], &lbf[spos+1*qdim], &lbf[spos+2*qdim], &lbf[spos+6*qdim],
                         &lbf[spos+16*qdim], &lbf[spos+8*qdim], &lbf[spos+18*qdim], &lbf[spos+4*qdim],
                         &lbf[spos+5*qdim], moment);
        uwall[0] -= moment;
        break;
      case PSR:
        fD3Q19PPSRegular(p0, &force[0], &lbf[spos], &lbf[spos+3*qdim],
                         &lbf[spos+1*qdim], &lbf[spos+2*qdim], &lbf[spos+6*qdim], &lbf[spos+16*qdim],
                         &lbf[spos+8*qdim], &lbf[spos+18*qdim], &lbf[spos+4*qdim], &lbf[spos+5*qdim],
                         &lbf[spos+12*qdim], &lbf[spos+10*qdim], &lbf[spos+11*qdim], &lbf[spos+15*qdim],
                         &lbf[spos+7*qdim], &lbf[spos+17*qdim], &lbf[spos+9*qdim], &lbf[spos+13*qdim],
                         &lbf[spos+14*qdim], moment);
        uwall[0] += moment;
        break;
      case PSF:
        fD3Q19PPSRegular(p0, &force[0], &lbf[spos], &lbf[spos+11*qdim],
                         &lbf[spos+12*qdim], &lbf[spos+10*qdim], &lbf[spos+17*qdim], &lbf[spos+18*qdim],
                         &lbf[spos+13*qdim], &lbf[spos+5*qdim], &lbf[spos+15*qdim], &lbf[spos+7*qdim],
                         &lbf[spos+2*qdim], &lbf[spos+3*qdim], &lbf[spos+1*qdim], &lbf[spos+8*qdim],
                         &lbf[spos+9*qdim], &lbf[spos+4*qdim], &lbf[spos+14*qdim], &lbf[spos+6*qdim],
                         &lbf[spos+16*qdim], moment);
        uwall[2] -= moment;
        break;
      case PSB:
        fD3Q19PPSRegular(p0, &force[0], &lbf[spos], &lbf[spos+2*qdim],
                         &lbf[spos+3*qdim], &lbf[spos+1*qdim], &lbf[spos+8*qdim], &lbf[spos+9*qdim],
                         &lbf[spos+4*qdim], &lbf[spos+14*qdim], &lbf[spos+6*qdim], &lbf[spos+16*qdim],
                         &lbf[spos+11*qdim], &lbf[spos+12*qdim], &lbf[spos+10*qdim], &lbf[spos+17*qdim],
                         &lbf[spos+18*qdim], &lbf[spos+13*qdim], &lbf[spos+5*qdim], &lbf[spos+15*qdim],
                         &lbf[spos+7*qdim], moment);
        uwall[2] += moment;
        break;
      case CCTRB:
        fD3Q19VCCCLBERegular(p0, uwall[0], uwall[1], -uwall[2], &force[0], &lbf[spos], &lbf[spos+1*qdim],
                             &lbf[spos+2*qdim], &lbf[spos+12*qdim], &lbf[spos+4*qdim], &lbf[spos+5*qdim],
                             &lbf[spos+7*qdim], &lbf[spos+6*qdim], &lbf[spos+9*qdim], &lbf[spos+8*qdim],
                             &lbf[spos+10*qdim], &lbf[spos+11*qdim], &lbf[spos+3*qdim], &lbf[spos+13*qdim],
                             &lbf[spos+14*qdim], &lbf[spos+16*qdim], &lbf[spos+15*qdim], &lbf[spos+18*qdim],
                             &lbf[spos+17*qdim]);
        break;
      case CCTLB:
        fD3Q19VCCCLBERegular(p0, -uwall[0], uwall[1], -uwall[2], &force[0], &lbf[spos], &lbf[spos+10*qdim],
                             &lbf[spos+2*qdim], &lbf[spos+12*qdim], &lbf[spos+14*qdim], &lbf[spos+13*qdim],
                             &lbf[spos+15*qdim], &lbf[spos+16*qdim], &lbf[spos+9*qdim], &lbf[spos+8*qdim],
                             &lbf[spos+1*qdim], &lbf[spos+11*qdim], &lbf[spos+3*qdim], &lbf[spos+5*qdim],
                             &lbf[spos+4*qdim], &lbf[spos+6*qdim], &lbf[spos+7*qdim], &lbf[spos+18*qdim],
                             &lbf[spos+17*qdim]);
        break;
      case CCDLB:
        fD3Q19VCCCLBERegular(p0, -uwall[0], -uwall[1], -uwall[2], &force[0], &lbf[spos], &lbf[spos+10*qdim],
                             &lbf[spos+11*qdim], &lbf[spos+12*qdim], &lbf[spos+13*qdim], &lbf[spos+14*qdim],
                             &lbf[spos+15*qdim], &lbf[spos+16*qdim], &lbf[spos+17*qdim], &lbf[spos+18*qdim],
                             &lbf[spos+1*qdim], &lbf[spos+2*qdim], &lbf[spos+3*qdim], &lbf[spos+4*qdim],
                             &lbf[spos+5*qdim], &lbf[spos+6*qdim], &lbf[spos+7*qdim], &lbf[spos+8*qdim],
                             &lbf[spos+9*qdim]);
        break;
      case CCDRB:
        fD3Q19VCCCLBERegular(p0, uwall[0], -uwall[1], -uwall[2], &force[0], &lbf[spos], &lbf[spos+1*qdim],
                             &lbf[spos+11*qdim], &lbf[spos+12*qdim], &lbf[spos+5*qdim], &lbf[spos+4*qdim],
                             &lbf[spos+7*qdim], &lbf[spos+6*qdim], &lbf[spos+17*qdim], &lbf[spos+18*qdim],
                             &lbf[spos+10*qdim], &lbf[spos+2*qdim], &lbf[spos+3*qdim], &lbf[spos+14*qdim],
                             &lbf[spos+13*qdim], &lbf[spos+16*qdim], &lbf[spos+15*qdim], &lbf[spos+8*qdim],
                             &lbf[spos+9*qdim]);
        break;
      case CCTRF:
        fD3Q19VCCCLBERegular(p0, uwall[0], uwall[1], uwall[2], &force[0], &lbf[spos], &lbf[spos+1*qdim],
                             &lbf[spos+2*qdim], &lbf[spos+3*qdim], &lbf[spos+4*qdim], &lbf[spos+5*qdim],
                             &lbf[spos+6*qdim], &lbf[spos+7*qdim], &lbf[spos+8*qdim], &lbf[spos+9*qdim],
                             &lbf[spos+10*qdim], &lbf[spos+11*qdim], &lbf[spos+12*qdim], &lbf[spos+13*qdim],
                             &lbf[spos+14*qdim], &lbf[spos+15*qdim], &lbf[spos+16*qdim], &lbf[spos+17*qdim],
                             &lbf[spos+18*qdim]);
        break;
      case CCTLF:
        fD3Q19VCCCLBERegular(p0, -uwall[0], uwall[1], uwall[2], &force[0], &lbf[spos], &lbf[spos+10*qdim],
                             &lbf[spos+2*qdim], &lbf[spos+3*qdim], &lbf[spos+14*qdim], &lbf[spos+13*qdim],
                             &lbf[spos+16*qdim], &lbf[spos+15*qdim], &lbf[spos+8*qdim], &lbf[spos+9*qdim],
                             &lbf[spos+1*qdim], &lbf[spos+11*qdim], &lbf[spos+12*qdim], &lbf[spos+5*qdim],
                             &lbf[spos+4*qdim], &lbf[spos+7*qdim], &lbf[spos+6*qdim], &lbf[spos+17*qdim],
                             &lbf[spos+18*qdim]);
        break;
      case CCDLF:
        fD3Q19VCCCLBERegular(p0, -uwall[0], -uwall[1], uwall[2], &force[0], &lbf[spos], &lbf[spos+10*qdim],
                             &lbf[spos+11*qdim], &lbf[spos+3*qdim], &lbf[spos+13*qdim], &lbf[spos+14*qdim],
                             &lbf[spos+16*qdim], &lbf[spos+15*qdim], &lbf[spos+18*qdim], &lbf[spos+17*qdim],
                             &lbf[spos+1*qdim], &lbf[spos+2*qdim], &lbf[spos+12*qdim], &lbf[spos+4*qdim],
                             &lbf[spos+5*qdim], &lbf[spos+7*qdim], &lbf[spos+6*qdim], &lbf[spos+9*qdim],
                             &lbf[spos+8*qdim]);
        break;
      case CCDRF:
        fD3Q19VCCCLBERegular(p0, uwall[0], -uwall[1], uwall[2], &force[0], &lbf[spos], &lbf[spos+1*qdim],
                             &lbf[spos+11*qdim], &lbf[spos+3*qdim], &lbf[spos+5*qdim], &lbf[spos+4*qdim],
                             &lbf[spos+6*qdim], &lbf[spos+7*qdim], &lbf[spos+18*qdim], &lbf[spos+17*qdim],
                             &lbf[spos+10*qdim], &lbf[spos+2*qdim], &lbf[spos+12*qdim], &lbf[spos+14*qdim],
                             &lbf[spos+13*qdim], &lbf[spos+15*qdim], &lbf[spos+16*qdim], &lbf[spos+9*qdim],
                             &lbf[spos+8*qdim]);
        break;
      case CETR:
        fD3Q19VCECLBERegular(p0, uwall[0], uwall[1], uwall[2], &force[0], &lbf[spos], &lbf[spos+1*qdim],
                             &lbf[spos+2*qdim], &lbf[spos+3*qdim], &lbf[spos+4*qdim], &lbf[spos+5*qdim],
                             &lbf[spos+6*qdim], &lbf[spos+7*qdim], &lbf[spos+8*qdim], &lbf[spos+9*qdim],
                             &lbf[spos+10*qdim], &lbf[spos+11*qdim], &lbf[spos+12*qdim], &lbf[spos+13*qdim],
                             &lbf[spos+14*qdim], &lbf[spos+15*qdim], &lbf[spos+16*qdim], &lbf[spos+17*qdim],
                             &lbf[spos+18*qdim]);
        break;
      case CETL:
        fD3Q19VCECLBERegular(p0, uwall[1], -uwall[0], uwall[2], &force[0], &lbf[spos], &lbf[spos+2*qdim],
                             &lbf[spos+10*qdim], &lbf[spos+3*qdim], &lbf[spos+14*qdim], &lbf[spos+4*qdim],
                             &lbf[spos+8*qdim], &lbf[spos+9*qdim], &lbf[spos+16*qdim], &lbf[spos+15*qdim],
                             &lbf[spos+11*qdim], &lbf[spos+1*qdim], &lbf[spos+12*qdim], &lbf[spos+5*qdim],
                             &lbf[spos+13*qdim], &lbf[spos+17*qdim], &lbf[spos+18*qdim], &lbf[spos+7*qdim],
                             &lbf[spos+6*qdim]);
        break;
      case CEDL:
        fD3Q19VCECLBERegular(p0, -uwall[0], -uwall[1], uwall[2], &force[0], &lbf[spos], &lbf[spos+10*qdim],
                             &lbf[spos+11*qdim], &lbf[spos+3*qdim], &lbf[spos+13*qdim], &lbf[spos+14*qdim],
                             &lbf[spos+16*qdim], &lbf[spos+15*qdim], &lbf[spos+18*qdim], &lbf[spos+17*qdim],
                             &lbf[spos+1*qdim], &lbf[spos+2*qdim], &lbf[spos+12*qdim], &lbf[spos+4*qdim],
                             &lbf[spos+5*qdim], &lbf[spos+7*qdim], &lbf[spos+6*qdim], &lbf[spos+9*qdim],
                             &lbf[spos+8*qdim]);
        break;
      case CEDR:
        fD3Q19VCECLBERegular(p0, -uwall[1], uwall[0], uwall[2], &force[0], &lbf[spos], &lbf[spos+11*qdim],
                             &lbf[spos+1*qdim], &lbf[spos+3*qdim], &lbf[spos+5*qdim], &lbf[spos+13*qdim],
                             &lbf[spos+18*qdim], &lbf[spos+17*qdim], &lbf[spos+6*qdim], &lbf[spos+7*qdim],
                             &lbf[spos+2*qdim], &lbf[spos+10*qdim], &lbf[spos+12*qdim], &lbf[spos+14*qdim],
                             &lbf[spos+4*qdim], &lbf[spos+9*qdim], &lbf[spos+8*qdim], &lbf[spos+15*qdim],
                             &lbf[spos+16*qdim]);
        break;
      case CETF:
        fD3Q19VCECLBERegular(p0, uwall[1], uwall[2], uwall[0], &force[0], &lbf[spos], &lbf[spos+2*qdim],
                             &lbf[spos+3*qdim], &lbf[spos+1*qdim], &lbf[spos+8*qdim], &lbf[spos+9*qdim],
                             &lbf[spos+4*qdim], &lbf[spos+14*qdim], &lbf[spos+6*qdim], &lbf[spos+16*qdim],
                             &lbf[spos+11*qdim], &lbf[spos+12*qdim], &lbf[spos+10*qdim], &lbf[spos+17*qdim],
                             &lbf[spos+18*qdim], &lbf[spos+13*qdim], &lbf[spos+5*qdim], &lbf[spos+15*qdim],
                             &lbf[spos+7*qdim]);
        break;
      case CELF:
        fD3Q19VCECLBERegular(p0, -uwall[0], uwall[2], uwall[1], &force[0], &lbf[spos], &lbf[spos+10*qdim],
                             &lbf[spos+3*qdim], &lbf[spos+2*qdim], &lbf[spos+16*qdim], &lbf[spos+15*qdim],
                             &lbf[spos+14*qdim], &lbf[spos+13*qdim], &lbf[spos+8*qdim], &lbf[spos+18*qdim],
                             &lbf[spos+1*qdim], &lbf[spos+12*qdim], &lbf[spos+11*qdim], &lbf[spos+7*qdim],
                             &lbf[spos+6*qdim], &lbf[spos+5*qdim], &lbf[spos+4*qdim], &lbf[spos+17*qdim],
                             &lbf[spos+9*qdim]);
        break;
      case CEDF:
        fD3Q19VCECLBERegular(p0, -uwall[1], uwall[2], uwall[0], &force[0], &lbf[spos], &lbf[spos+11*qdim],
                             &lbf[spos+3*qdim], &lbf[spos+1*qdim], &lbf[spos+18*qdim], &lbf[spos+17*qdim],
                             &lbf[spos+5*qdim], &lbf[spos+13*qdim], &lbf[spos+6*qdim], &lbf[spos+16*qdim],
                             &lbf[spos+2*qdim], &lbf[spos+12*qdim], &lbf[spos+10*qdim], &lbf[spos+9*qdim],
                             &lbf[spos+8*qdim], &lbf[spos+14*qdim], &lbf[spos+4*qdim], &lbf[spos+15*qdim],
                             &lbf[spos+7*qdim]);
        break;
      case CERF:
        fD3Q19VCECLBERegular(p0, uwall[0], uwall[2], uwall[1], &force[0], &lbf[spos], &lbf[spos+1*qdim],
                             &lbf[spos+3*qdim], &lbf[spos+2*qdim], &lbf[spos+6*qdim], &lbf[spos+7*qdim],
                             &lbf[spos+4*qdim], &lbf[spos+5*qdim], &lbf[spos+8*qdim], &lbf[spos+18*qdim],
                             &lbf[spos+10*qdim], &lbf[spos+12*qdim], &lbf[spos+11*qdim], &lbf[spos+15*qdim],
                             &lbf[spos+16*qdim], &lbf[spos+13*qdim], &lbf[spos+14*qdim], &lbf[spos+17*qdim],
                             &lbf[spos+9*qdim]);
        break;
      case CETB:
        fD3Q19VCECLBERegular(p0, uwall[1], -uwall[2], uwall[0], &force[0], &lbf[spos], &lbf[spos+2*qdim],
                             &lbf[spos+12*qdim], &lbf[spos+1*qdim], &lbf[spos+9*qdim], &lbf[spos+8*qdim],
                             &lbf[spos+4*qdim], &lbf[spos+14*qdim], &lbf[spos+7*qdim], &lbf[spos+15*qdim],
                             &lbf[spos+11*qdim], &lbf[spos+3*qdim], &lbf[spos+10*qdim], &lbf[spos+18*qdim],
                             &lbf[spos+17*qdim], &lbf[spos+13*qdim], &lbf[spos+5*qdim], &lbf[spos+16*qdim],
                             &lbf[spos+6*qdim]);
        break;
      case CELB:
        fD3Q19VCECLBERegular(p0, -uwall[0], -uwall[2], uwall[1], &force[0], &lbf[spos], &lbf[spos+10*qdim],
                             &lbf[spos+12*qdim], &lbf[spos+2*qdim], &lbf[spos+15*qdim], &lbf[spos+16*qdim],
                             &lbf[spos+14*qdim], &lbf[spos+13*qdim], &lbf[spos+9*qdim], &lbf[spos+17*qdim],
                             &lbf[spos+1*qdim], &lbf[spos+3*qdim], &lbf[spos+11*qdim], &lbf[spos+6*qdim],
                             &lbf[spos+7*qdim], &lbf[spos+5*qdim], &lbf[spos+4*qdim], &lbf[spos+18*qdim],
                             &lbf[spos+8*qdim]);
        break;
      case CEDB:
        fD3Q19VCECLBERegular(p0, -uwall[1], -uwall[2], uwall[0], &force[0], &lbf[spos], &lbf[spos+11*qdim],
                             &lbf[spos+12*qdim], &lbf[spos+1*qdim], &lbf[spos+17*qdim], &lbf[spos+18*qdim],
                             &lbf[spos+5*qdim], &lbf[spos+13*qdim], &lbf[spos+7*qdim], &lbf[spos+15*qdim],
                             &lbf[spos+2*qdim], &lbf[spos+3*qdim], &lbf[spos+10*qdim], &lbf[spos+8*qdim],
                             &lbf[spos+9*qdim], &lbf[spos+14*qdim], &lbf[spos+4*qdim], &lbf[spos+16*qdim],
                             &lbf[spos+6*qdim]);
        break;
      case CERB:
        fD3Q19VCECLBERegular(p0, uwall[0], -uwall[2], uwall[1], &force[0], &lbf[spos], &lbf[spos+1*qdim],
                             &lbf[spos+12*qdim], &lbf[spos+2*qdim], &lbf[spos+7*qdim], &lbf[spos+6*qdim],
                             &lbf[spos+4*qdim], &lbf[spos+5*qdim], &lbf[spos+9*qdim], &lbf[spos+17*qdim],
                             &lbf[spos+10*qdim], &lbf[spos+3*qdim], &lbf[spos+11*qdim], &lbf[spos+16*qdim],
                             &lbf[spos+15*qdim], &lbf[spos+13*qdim], &lbf[spos+14*qdim], &lbf[spos+18*qdim],
                             &lbf[spos+8*qdim]);
        break;
    }
  }
  else {
    switch (prop) {
      case PST:
        fD3Q19PPSRegular(p0, &force[0], &lbf[spos], &lbf[spos+1*qdim],
                         &lbf[spos+2*qdim], &lbf[spos+3*qdim], &lbf[spos+4*qdim], &lbf[spos+5*qdim],
                         &lbf[spos+6*qdim], &lbf[spos+7*qdim], &lbf[spos+8*qdim], &lbf[spos+9*qdim],
                         &lbf[spos+10*qdim], &lbf[spos+11*qdim], &lbf[spos+12*qdim], &lbf[spos+13*qdim],
                         &lbf[spos+14*qdim], &lbf[spos+15*qdim], &lbf[spos+16*qdim], &lbf[spos+17*qdim],
                         &lbf[spos+18*qdim], moment);
        uwall[1] += moment;
        break;
      case PSD:
        fD3Q19PPSRegular(p0, &force[0], &lbf[spos], &lbf[spos+10*qdim],
                         &lbf[spos+11*qdim], &lbf[spos+12*qdim], &lbf[spos+13*qdim], &lbf[spos+14*qdim],
                         &lbf[spos+15*qdim], &lbf[spos+16*qdim], &lbf[spos+17*qdim], &lbf[spos+18*qdim],
                         &lbf[spos+1*qdim], &lbf[spos+2*qdim], &lbf[spos+3*qdim], &lbf[spos+4*qdim],
                         &lbf[spos+5*qdim], &lbf[spos+6*qdim], &lbf[spos+7*qdim], &lbf[spos+8*qdim],
                         &lbf[spos+9*qdim], moment);
        uwall[1] -= moment;
        break;
      case PSL:
        fD3Q19PPSRegular(p0, &force[0], &lbf[spos], &lbf[spos+12*qdim],
                         &lbf[spos+10*qdim], &lbf[spos+11*qdim], &lbf[spos+15*qdim], &lbf[spos+7*qdim],
                         &lbf[spos+17*qdim], &lbf[spos+9*qdim], &lbf[spos+13*qdim], &lbf[spos+14*qdim],
                         &lbf[spos+3*qdim], &lbf[spos+1*qdim], &lbf[spos+2*qdim], &lbf[spos+6*qdim],
                         &lbf[spos+16*qdim], &lbf[spos+8*qdim], &lbf[spos+18*qdim], &lbf[spos+4*qdim],
                         &lbf[spos+5*qdim], moment);
        uwall[0] -= moment;
        break;
      case PSR:
        fD3Q19PPSRegular(p0, &force[0], &lbf[spos], &lbf[spos+3*qdim],
                         &lbf[spos+1*qdim], &lbf[spos+2*qdim], &lbf[spos+6*qdim], &lbf[spos+16*qdim],
                         &lbf[spos+8*qdim], &lbf[spos+18*qdim], &lbf[spos+4*qdim], &lbf[spos+5*qdim],
                         &lbf[spos+12*qdim], &lbf[spos+10*qdim], &lbf[spos+11*qdim], &lbf[spos+15*qdim],
                         &lbf[spos+7*qdim], &lbf[spos+17*qdim], &lbf[spos+9*qdim], &lbf[spos+13*qdim],
                         &lbf[spos+14*qdim], moment);
        uwall[0] += moment;
        break;
      case PSF:
        fD3Q19PPSRegular(p0, &force[0], &lbf[spos], &lbf[spos+11*qdim],
                         &lbf[spos+12*qdim], &lbf[spos+10*qdim], &lbf[spos+17*qdim], &lbf[spos+18*qdim],
                         &lbf[spos+13*qdim], &lbf[spos+5*qdim], &lbf[spos+15*qdim], &lbf[spos+7*qdim],
                         &lbf[spos+2*qdim], &lbf[spos+3*qdim], &lbf[spos+1*qdim], &lbf[spos+8*qdim],
                         &lbf[spos+9*qdim], &lbf[spos+4*qdim], &lbf[spos+14*qdim], &lbf[spos+6*qdim],
                         &lbf[spos+16*qdim], moment);
        uwall[2] -= moment;
        break;
      case PSB:
        fD3Q19PPSRegular(p0, &force[0], &lbf[spos], &lbf[spos+2*qdim],
                         &lbf[spos+3*qdim], &lbf[spos+1*qdim], &lbf[spos+8*qdim], &lbf[spos+9*qdim],
                         &lbf[spos+4*qdim], &lbf[spos+14*qdim], &lbf[spos+6*qdim], &lbf[spos+16*qdim],
                         &lbf[spos+11*qdim], &lbf[spos+12*qdim], &lbf[spos+10*qdim], &lbf[spos+17*qdim],
                         &lbf[spos+18*qdim], &lbf[spos+13*qdim], &lbf[spos+5*qdim], &lbf[spos+15*qdim],
                         &lbf[spos+7*qdim], moment);
        uwall[2] += moment;
        break;
      case CCTRB:
        fD3Q19VCCRegular(p0, uwall[0], uwall[1], -uwall[2], &force[0], &lbf[spos], &lbf[spos+1*qdim],
                         &lbf[spos+2*qdim], &lbf[spos+12*qdim], &lbf[spos+4*qdim], &lbf[spos+5*qdim],
                         &lbf[spos+7*qdim], &lbf[spos+6*qdim], &lbf[spos+9*qdim], &lbf[spos+8*qdim],
                         &lbf[spos+10*qdim], &lbf[spos+11*qdim], &lbf[spos+3*qdim], &lbf[spos+13*qdim],
                         &lbf[spos+14*qdim], &lbf[spos+16*qdim], &lbf[spos+15*qdim], &lbf[spos+18*qdim],
                         &lbf[spos+17*qdim]);
        break;
      case CCTLB:
        fD3Q19VCCRegular(p0, -uwall[0], uwall[1], -uwall[2], &force[0], &lbf[spos], &lbf[spos+10*qdim],
                         &lbf[spos+2*qdim], &lbf[spos+12*qdim], &lbf[spos+14*qdim], &lbf[spos+13*qdim],
                         &lbf[spos+15*qdim], &lbf[spos+16*qdim], &lbf[spos+9*qdim], &lbf[spos+8*qdim],
                         &lbf[spos+1*qdim], &lbf[spos+11*qdim], &lbf[spos+3*qdim], &lbf[spos+5*qdim],
                         &lbf[spos+4*qdim], &lbf[spos+6*qdim], &lbf[spos+7*qdim], &lbf[spos+18*qdim],
                         &lbf[spos+17*qdim]);
        break;
      case CCDLB:
        fD3Q19VCCRegular(p0, -uwall[0], -uwall[1], -uwall[2], &force[0], &lbf[spos], &lbf[spos+10*qdim],
                         &lbf[spos+11*qdim], &lbf[spos+12*qdim], &lbf[spos+13*qdim], &lbf[spos+14*qdim],
                         &lbf[spos+15*qdim], &lbf[spos+16*qdim], &lbf[spos+17*qdim], &lbf[spos+18*qdim],
                         &lbf[spos+1*qdim], &lbf[spos+2*qdim], &lbf[spos+3*qdim], &lbf[spos+4*qdim],
                         &lbf[spos+5*qdim], &lbf[spos+6*qdim], &lbf[spos+7*qdim], &lbf[spos+8*qdim],
                         &lbf[spos+9*qdim]);
        break;
      case CCDRB:
        fD3Q19VCCRegular(p0, uwall[0], -uwall[1], -uwall[2], &force[0], &lbf[spos], &lbf[spos+1*qdim],
                         &lbf[spos+11*qdim], &lbf[spos+12*qdim], &lbf[spos+5*qdim], &lbf[spos+4*qdim],
                         &lbf[spos+7*qdim], &lbf[spos+6*qdim], &lbf[spos+17*qdim], &lbf[spos+18*qdim],
                         &lbf[spos+10*qdim], &lbf[spos+2*qdim], &lbf[spos+3*qdim], &lbf[spos+14*qdim],
                         &lbf[spos+13*qdim], &lbf[spos+16*qdim], &lbf[spos+15*qdim], &lbf[spos+8*qdim],
                         &lbf[spos+9*qdim]);
        break;
      case CCTRF:
        fD3Q19VCCRegular(p0, uwall[0], uwall[1], uwall[2], &force[0], &lbf[spos], &lbf[spos+1*qdim],
                         &lbf[spos+2*qdim], &lbf[spos+3*qdim], &lbf[spos+4*qdim], &lbf[spos+5*qdim],
                         &lbf[spos+6*qdim], &lbf[spos+7*qdim], &lbf[spos+8*qdim], &lbf[spos+9*qdim],
                         &lbf[spos+10*qdim], &lbf[spos+11*qdim], &lbf[spos+12*qdim], &lbf[spos+13*qdim],
                         &lbf[spos+14*qdim], &lbf[spos+15*qdim], &lbf[spos+16*qdim], &lbf[spos+17*qdim],
                         &lbf[spos+18*qdim]);
        break;
      case CCTLF:
        fD3Q19VCCRegular(p0, -uwall[0], uwall[1], uwall[2], &force[0], &lbf[spos], &lbf[spos+10*qdim],
                         &lbf[spos+2*qdim], &lbf[spos+3*qdim], &lbf[spos+14*qdim], &lbf[spos+13*qdim],
                         &lbf[spos+16*qdim], &lbf[spos+15*qdim], &lbf[spos+8*qdim], &lbf[spos+9*qdim],
                         &lbf[spos+1*qdim], &lbf[spos+11*qdim], &lbf[spos+12*qdim], &lbf[spos+5*qdim],
                         &lbf[spos+4*qdim], &lbf[spos+7*qdim], &lbf[spos+6*qdim], &lbf[spos+17*qdim],
                         &lbf[spos+18*qdim]);
        break;
      case CCDLF:
        fD3Q19VCCRegular(p0, -uwall[0], -uwall[1], uwall[2], &force[0], &lbf[spos], &lbf[spos+10*qdim],
                         &lbf[spos+11*qdim], &lbf[spos+3*qdim], &lbf[spos+13*qdim], &lbf[spos+14*qdim],
                         &lbf[spos+16*qdim], &lbf[spos+15*qdim], &lbf[spos+18*qdim], &lbf[spos+17*qdim],
                         &lbf[spos+1*qdim], &lbf[spos+2*qdim], &lbf[spos+12*qdim], &lbf[spos+4*qdim],
                         &lbf[spos+5*qdim], &lbf[spos+7*qdim], &lbf[spos+6*qdim], &lbf[spos+9*qdim],
                         &lbf[spos+8*qdim]);
        break;
      case CCDRF:
        fD3Q19VCCRegular(p0, uwall[0], -uwall[1], uwall[2], &force[0], &lbf[spos], &lbf[spos+1*qdim],
                         &lbf[spos+11*qdim], &lbf[spos+3*qdim], &lbf[spos+5*qdim], &lbf[spos+4*qdim],
                         &lbf[spos+6*qdim], &lbf[spos+7*qdim], &lbf[spos+18*qdim], &lbf[spos+17*qdim],
                         &lbf[spos+10*qdim], &lbf[spos+2*qdim], &lbf[spos+12*qdim], &lbf[spos+14*qdim],
                         &lbf[spos+13*qdim], &lbf[spos+15*qdim], &lbf[spos+16*qdim], &lbf[spos+9*qdim],
                         &lbf[spos+8*qdim]);
        break;
      case CETR:
        fD3Q19VCERegular(p0, uwall[0], uwall[1], uwall[2], &force[0], &lbf[spos], &lbf[spos+1*qdim],
                         &lbf[spos+2*qdim], &lbf[spos+3*qdim], &lbf[spos+4*qdim], &lbf[spos+5*qdim],
                         &lbf[spos+6*qdim], &lbf[spos+7*qdim], &lbf[spos+8*qdim], &lbf[spos+9*qdim],
                         &lbf[spos+10*qdim], &lbf[spos+11*qdim], &lbf[spos+12*qdim], &lbf[spos+13*qdim],
                         &lbf[spos+14*qdim], &lbf[spos+15*qdim], &lbf[spos+16*qdim], &lbf[spos+17*qdim],
                         &lbf[spos+18*qdim]);
        break;
      case CETL:
        fD3Q19VCERegular(p0, uwall[1], -uwall[0], uwall[2], &force[0], &lbf[spos], &lbf[spos+2*qdim],
                         &lbf[spos+10*qdim], &lbf[spos+3*qdim], &lbf[spos+14*qdim], &lbf[spos+4*qdim],
                         &lbf[spos+8*qdim], &lbf[spos+9*qdim], &lbf[spos+16*qdim], &lbf[spos+15*qdim],
                         &lbf[spos+11*qdim], &lbf[spos+1*qdim], &lbf[spos+12*qdim], &lbf[spos+5*qdim],
                         &lbf[spos+13*qdim], &lbf[spos+17*qdim], &lbf[spos+18*qdim], &lbf[spos+7*qdim],
                         &lbf[spos+6*qdim]);
        break;
      case CEDL:
        fD3Q19VCERegular(p0, -uwall[0], -uwall[1], uwall[2], &force[0], &lbf[spos], &lbf[spos+10*qdim],
                         &lbf[spos+11*qdim], &lbf[spos+3*qdim], &lbf[spos+13*qdim], &lbf[spos+14*qdim],
                         &lbf[spos+16*qdim], &lbf[spos+15*qdim], &lbf[spos+18*qdim], &lbf[spos+17*qdim],
                         &lbf[spos+1*qdim], &lbf[spos+2*qdim], &lbf[spos+12*qdim], &lbf[spos+4*qdim],
                         &lbf[spos+5*qdim], &lbf[spos+7*qdim], &lbf[spos+6*qdim], &lbf[spos+9*qdim],
                         &lbf[spos+8*qdim]);
        break;
      case CEDR:
        fD3Q19VCERegular(p0, -uwall[1], uwall[0], uwall[2], &force[0], &lbf[spos], &lbf[spos+11*qdim],
                         &lbf[spos+1*qdim], &lbf[spos+3*qdim], &lbf[spos+5*qdim], &lbf[spos+13*qdim],
                         &lbf[spos+18*qdim], &lbf[spos+17*qdim], &lbf[spos+6*qdim], &lbf[spos+7*qdim],
                         &lbf[spos+2*qdim], &lbf[spos+10*qdim], &lbf[spos+12*qdim], &lbf[spos+14*qdim],
                         &lbf[spos+4*qdim], &lbf[spos+9*qdim], &lbf[spos+8*qdim], &lbf[spos+15*qdim],
                         &lbf[spos+16*qdim]);
        break;
      case CETF:
        fD3Q19VCERegular(p0, uwall[1], uwall[2], uwall[0], &force[0], &lbf[spos], &lbf[spos+2*qdim],
                         &lbf[spos+3*qdim], &lbf[spos+1*qdim], &lbf[spos+8*qdim], &lbf[spos+9*qdim],
                         &lbf[spos+4*qdim], &lbf[spos+14*qdim], &lbf[spos+6*qdim], &lbf[spos+16*qdim],
                         &lbf[spos+11*qdim], &lbf[spos+12*qdim], &lbf[spos+10*qdim], &lbf[spos+17*qdim],
                         &lbf[spos+18*qdim], &lbf[spos+13*qdim], &lbf[spos+5*qdim], &lbf[spos+15*qdim],
                         &lbf[spos+7*qdim]);
        break;
      case CELF:
        fD3Q19VCERegular(p0, -uwall[0], uwall[2], uwall[1], &force[0], &lbf[spos], &lbf[spos+10*qdim],
                         &lbf[spos+3*qdim], &lbf[spos+2*qdim], &lbf[spos+16*qdim], &lbf[spos+15*qdim],
                         &lbf[spos+14*qdim], &lbf[spos+13*qdim], &lbf[spos+8*qdim], &lbf[spos+18*qdim],
                         &lbf[spos+1*qdim], &lbf[spos+12*qdim], &lbf[spos+11*qdim], &lbf[spos+7*qdim],
                         &lbf[spos+6*qdim], &lbf[spos+5*qdim], &lbf[spos+4*qdim], &lbf[spos+17*qdim],
                         &lbf[spos+9*qdim]);
        break;
      case CEDF:
        fD3Q19VCERegular(p0, -uwall[1], uwall[2], uwall[0], &force[0], &lbf[spos], &lbf[spos+11*qdim],
                         &lbf[spos+3*qdim], &lbf[spos+1*qdim], &lbf[spos+18*qdim], &lbf[spos+17*qdim],
                         &lbf[spos+5*qdim], &lbf[spos+13*qdim], &lbf[spos+6*qdim], &lbf[spos+16*qdim],
                         &lbf[spos+2*qdim], &lbf[spos+12*qdim], &lbf[spos+10*qdim], &lbf[spos+9*qdim],
                         &lbf[spos+8*qdim], &lbf[spos+14*qdim], &lbf[spos+4*qdim], &lbf[spos+15*qdim],
                         &lbf[spos+7*qdim]);
        break;
      case CERF:
        fD3Q19VCERegular(p0, uwall[0], uwall[2], uwall[1], &force[0], &lbf[spos], &lbf[spos+1*qdim],
                         &lbf[spos+3*qdim], &lbf[spos+2*qdim], &lbf[spos+6*qdim], &lbf[spos+7*qdim],
                         &lbf[spos+4*qdim], &lbf[spos+5*qdim], &lbf[spos+8*qdim], &lbf[spos+18*qdim],
                         &lbf[spos+10*qdim], &lbf[spos+12*qdim], &lbf[spos+11*qdim], &lbf[spos+15*qdim],
                         &lbf[spos+16*qdim], &lbf[spos+13*qdim], &lbf[spos+14*qdim], &lbf[spos+17*qdim],
                         &lbf[spos+9*qdim]);
        break;
      case CETB:
        fD3Q19VCERegular(p0, uwall[1], -uwall[2], uwall[0], &force[0], &lbf[spos], &lbf[spos+2*qdim],
                         &lbf[spos+12*qdim], &lbf[spos+1*qdim], &lbf[spos+9*qdim], &lbf[spos+8*qdim],
                         &lbf[spos+4*qdim], &lbf[spos+14*qdim], &lbf[spos+7*qdim], &lbf[spos+15*qdim],
                         &lbf[spos+11*qdim], &lbf[spos+3*qdim], &lbf[spos+10*qdim], &lbf[spos+18*qdim],
                         &lbf[spos+17*qdim], &lbf[spos+13*qdim], &lbf[spos+5*qdim], &lbf[spos+16*qdim],
                         &lbf[spos+6*qdim]);
        break;
      case CELB:
        fD3Q19VCERegular(p0, -uwall[0], -uwall[2], uwall[1], &force[0], &lbf[spos], &lbf[spos+10*qdim],
                         &lbf[spos+12*qdim], &lbf[spos+2*qdim], &lbf[spos+15*qdim], &lbf[spos+16*qdim],
                         &lbf[spos+14*qdim], &lbf[spos+13*qdim], &lbf[spos+9*qdim], &lbf[spos+17*qdim],
                         &lbf[spos+1*qdim], &lbf[spos+3*qdim], &lbf[spos+11*qdim], &lbf[spos+6*qdim],
                         &lbf[spos+7*qdim], &lbf[spos+5*qdim], &lbf[spos+4*qdim], &lbf[spos+18*qdim],
                         &lbf[spos+8*qdim]);
        break;
      case CEDB:
        fD3Q19VCERegular(p0, -uwall[1], -uwall[2], uwall[0], &force[0], &lbf[spos], &lbf[spos+11*qdim],
                         &lbf[spos+12*qdim], &lbf[spos+1*qdim], &lbf[spos+17*qdim], &lbf[spos+18*qdim],
                         &lbf[spos+5*qdim], &lbf[spos+13*qdim], &lbf[spos+7*qdim], &lbf[spos+15*qdim],
                         &lbf[spos+2*qdim], &lbf[spos+3*qdim], &lbf[spos+10*qdim], &lbf[spos+8*qdim],
                         &lbf[spos+9*qdim], &lbf[spos+14*qdim], &lbf[spos+4*qdim], &lbf[spos+16*qdim],
                         &lbf[spos+6*qdim]);
        break;
      case CERB:
        fD3Q19VCERegular(p0, uwall[0], -uwall[2], uwall[1], &force[0], &lbf[spos], &lbf[spos+1*qdim],
                         &lbf[spos+12*qdim], &lbf[spos+2*qdim], &lbf[spos+7*qdim], &lbf[spos+6*qdim],
                         &lbf[spos+4*qdim], &lbf[spos+5*qdim], &lbf[spos+9*qdim], &lbf[spos+17*qdim],
                         &lbf[spos+10*qdim], &lbf[spos+3*qdim], &lbf[spos+11*qdim], &lbf[spos+16*qdim],
                         &lbf[spos+15*qdim], &lbf[spos+13*qdim], &lbf[spos+14*qdim], &lbf[spos+18*qdim],
                         &lbf[spos+8*qdim]);
        break;
    }
  }
  return 0;
}


// D3Q27

int fD3Q27VPSRegular(double v0, double v1, double v2, double *force,
                     double *f0, double *f1, double *f2, double *f3, double *f4,
                     double *f5, double *f6, double *f7, double *f8, double *f9,
                     double *f10, double *f11, double *f12, double *f13, double *f14,
                     double *f15, double *f16, double *f17, double *f18, double *f19,
                     double *f20, double *f21, double *f22, double *f23, double *f24,
                     double *f25, double *f26)
{

  // produce fixed velocity for compressible/incompressible fluids at planar surface boundary:
  // expressed for bottom wall (VPST)
  
  double rho, rho0, modv, pi_xx, pi_yy, pi_zz, pi_xy, pi_xz, pi_yz, v0v0, v0v1, v0v2, v1v1, v1v2, v2v2;
  double c1=1.0/3.0,c2=4.0/9.0,c3=2.0/9.0,c4=1.0/9.0,c5=1.0/6.0,c6=1.0/18.0,c7=1.0/24.0,c8=1.0/36.0,c9=1.0/72.0;

  v0v0 = v0*v0;
  v0v1 = v0*v1;
  v0v2 = v0*v2;
  v1v1 = v1*v1;
  v1v2 = v1*v2;
  v2v2 = v2*v2;
  modv = v0v0+v1v1+v2v2;

  if(!incompress) {
    for(int i=0; i<lbsy.nf; i++) {
      rho=(f0[i]+f1[i]+f3[i]+f6[i]+f7[i]+f14[i]+f16[i]+f19[i]+f20[i]+2.0*(f2[i]+f4[i]+f8[i]+f9[i]+f10[i]+f11[i]+f18[i]+f25[i]+f26[i])-0.5*force[3*i+1])/(1.0-v1);
      pi_xx = f1[i]+f6[i]+f7[i]+f14[i]+f19[i]+f20[i]+2.0*(f4[i]+f10[i]+f11[i]+f18[i]+f25[i]+f26[i])+rho*(c1*(v1-1.0)-v0v0)+v0*force[3*i  ];
      pi_yy = 2.0*(f2[i]+f4[i]+f8[i]+f9[i]+f10[i]+f11[i]+f18[i]+f25[i]+f26[i])+rho*(v1-v1v1-c1)+v1*force[3*i+1];
      pi_zz = f3[i]+f6[i]+f7[i]+f16[i]+f19[i]+f20[i]+2.0*(f8[i]+f9[i]+f10[i]+f11[i]+f25[i]+f26[i])+rho*(c1*(v1-1.0)-v2v2)+v2*force[3*i+2];
      pi_xy = 2.0*(f4[i]+f10[i]+f11[i]-f18[i]-f25[i]-f26[i])+rho*(c1*v0-v0v1)+0.5*(v1*force[3*i  ]+v0*force[3*i+1]);
      pi_xz = f6[i]-f7[i]+f19[i]-f20[i]+2.0*(f10[i]-f11[i]+f25[i]-f26[i])-rho*v0v2+0.5*(v2*force[3*i  ]+v0*force[3*i+2]);
      pi_yz = 2.0*(f8[i]-f9[i]+f10[i]-f11[i]-f25[i]+f26[i])+rho*(c1*v2-v1v2)+0.5*(v2*force[3*i+1]+v1*force[3*i+2]);
      f0[i] =rho*lbw[0] *(1.0                                    -1.5*modv)-c2*(pi_xx+   pi_yy+   pi_zz);
      f1[i] =rho*lbw[1] *(1.0-3.0*v0                   +4.5*v0v0 -1.5*modv)+c3* pi_xx-c4*pi_yy-c4*pi_zz;
      f2[i] =rho*lbw[2] *(1.0-3.0*v1                   +4.5*v1v1 -1.5*modv)-c4* pi_xx+c3*pi_yy-c4*pi_zz;
      f3[i] =rho*lbw[3] *(1.0-3.0*v2                   +4.5*v2v2 -1.5*modv)-c4* pi_xx-c4*pi_yy+c3*pi_zz;
      f4[i] =rho*lbw[4] *(1.0-3.0*(v0+v1)   +9.0* v0v1 -4.5*v2v2 +3.0*modv)+c6* pi_xx+c6*pi_yy-c8*pi_zz +c5* pi_xy;
      f5[i] =rho*lbw[5] *(1.0-3.0*(v0-v1)   -9.0* v0v1 -4.5*v2v2 +3.0*modv)+c6* pi_xx+c6*pi_yy-c8*pi_zz -c5* pi_xy;
      f6[i] =rho*lbw[6] *(1.0-3.0*(v0+v2)   +9.0* v0v2 -4.5*v1v1 +3.0*modv)+c6* pi_xx-c8*pi_yy+c6*pi_zz +c5* pi_xz;
      f7[i] =rho*lbw[7] *(1.0-3.0*(v0-v2)   -9.0* v0v2 -4.5*v1v1 +3.0*modv)+c6* pi_xx-c8*pi_yy+c6*pi_zz -c5* pi_xz;
      f8[i] =rho*lbw[8] *(1.0-3.0*(v1+v2)   +9.0* v1v2 -4.5*v0v0 +3.0*modv)-c8* pi_xx+c6*pi_yy+c6*pi_zz +c5* pi_yz;
      f9[i] =rho*lbw[9] *(1.0-3.0*(v1-v2)   -9.0* v1v2 -4.5*v0v0 +3.0*modv)-c8* pi_xx+c6*pi_yy+c6*pi_zz -c5* pi_yz;
      f10[i]=rho*lbw[10]*(1.0-3.0*(v0+v1+v2)+9.0*(v0v1+v0v2+v1v2)+3.0*modv)+c9*(pi_xx+   pi_yy+   pi_zz)+c7*(pi_xy+pi_xz+pi_yz);
      f11[i]=rho*lbw[11]*(1.0-3.0*(v0+v1-v2)+9.0*(v0v1-v0v2-v1v2)+3.0*modv)+c9*(pi_xx+   pi_yy+   pi_zz)+c7*(pi_xy-pi_xz-pi_yz);
      f12[i]=rho*lbw[12]*(1.0-3.0*(v0-v1+v2)-9.0*(v0v1-v0v2+v1v2)+3.0*modv)+c9*(pi_xx+   pi_yy+   pi_zz)-c7*(pi_xy-pi_xz+pi_yz);
      f13[i]=rho*lbw[13]*(1.0-3.0*(v0-v1-v2)-9.0*(v0v1+v0v2-v1v2)+3.0*modv)+c9*(pi_xx+   pi_yy+   pi_zz)-c7*(pi_xy+pi_xz-pi_yz);
      f14[i]=rho*lbw[14]*(1.0+3.0*v0                   +4.5*v0v0 -1.5*modv)+c3* pi_xx-c4*pi_yy-c4*pi_zz;
      f15[i]=rho*lbw[15]*(1.0+3.0*v1                   +4.5*v1v1 -1.5*modv)-c4* pi_xx+c3*pi_yy-c4*pi_zz;
      f16[i]=rho*lbw[16]*(1.0+3.0*v2                   +4.5*v2v2 -1.5*modv)-c4* pi_xx-c4*pi_yy+c3*pi_zz;
      f17[i]=rho*lbw[17]*(1.0+3.0*(v0+v1)   +9.0* v0v1 -4.5*v2v2 +3.0*modv)+c6* pi_xx+c6*pi_yy-c8*pi_zz +c5* pi_xy;
      f18[i]=rho*lbw[18]*(1.0+3.0*(v0-v1)   -9.0* v0v1 -4.5*v2v2 +3.0*modv)+c6* pi_xx+c6*pi_yy-c8*pi_zz -c5* pi_xy;
      f19[i]=rho*lbw[19]*(1.0+3.0*(v0+v2)   +9.0* v0v2 -4.5*v1v1 +3.0*modv)+c6* pi_xx-c8*pi_yy+c6*pi_zz +c5* pi_xz;
      f20[i]=rho*lbw[20]*(1.0+3.0*(v0-v2)   -9.0* v0v2 -4.5*v1v1 +3.0*modv)+c6* pi_xx-c8*pi_yy+c6*pi_zz -c5* pi_xz;
      f21[i]=rho*lbw[21]*(1.0+3.0*(v1+v2)   +9.0* v1v2 -4.5*v0v0 +3.0*modv)-c8* pi_xx+c6*pi_yy+c6*pi_zz +c5* pi_yz;
      f22[i]=rho*lbw[22]*(1.0+3.0*(v1-v2)   -9.0* v1v2 -4.5*v0v0 +3.0*modv)-c8* pi_xx+c6*pi_yy+c6*pi_zz -c5* pi_yz;
      f23[i]=rho*lbw[23]*(1.0+3.0*(v0+v1+v2)+9.0*(v0v1+v0v2+v1v2)+3.0*modv)+c9*(pi_xx+   pi_yy+   pi_zz)+c7*(pi_xy+pi_xz+pi_yz);
      f24[i]=rho*lbw[24]*(1.0+3.0*(v0+v1-v2)+9.0*(v0v1-v0v2-v1v2)+3.0*modv)+c9*(pi_xx+   pi_yy+   pi_zz)+c7*(pi_xy-pi_xz-pi_yz);
      f25[i]=rho*lbw[25]*(1.0+3.0*(v0-v1+v2)-9.0*(v0v1-v0v2+v1v2)+3.0*modv)+c9*(pi_xx+   pi_yy+   pi_zz)-c7*(pi_xy-pi_xz+pi_yz);
      f26[i]=rho*lbw[26]*(1.0+3.0*(v0-v1-v2)-9.0*(v0v1+v0v2-v1v2)+3.0*modv)+c9*(pi_xx+   pi_yy+   pi_zz)-c7*(pi_xy+pi_xz-pi_yz);
    }
  }
  else {
    for(int i=0; i<lbsy.nf; i++) {
      rho0 = lbincp[i];
      rho = f0[i]+f1[i]+f3[i]+f6[i]+f7[i]+f14[i]+f16[i]+f19[i]+f20[i]+2.0*(f2[i]+f4[i]+f8[i]+f9[i]+f10[i]+f11[i]+f18[i]+f25[i]+f26[i])+rho0*v1-0.5*force[3*i+1];
      pi_xx = f1[i]+f6[i]+f7[i]+f14[i]+f19[i]+f20[i]+2.0*(f4[i]+f10[i]+f11[i]+f18[i]+f25[i]+f26[i])+rho0*(c1*v1-v0v0)-c1*rho+v0*force[3*i  ];
      pi_yy = 2.0*(f2[i]+f4[i]+f8[i]+f9[i]+f10[i]+f11[i]+f18[i]+f25[i]+f26[i])+rho0*(v1-v1v1)-c1*rho+v1*force[3*i+1];
      pi_zz = f3[i]+f6[i]+f7[i]+f16[i]+f19[i]+f20[i]+2.0*(f8[i]+f9[i]+f10[i]+f11[i]+f25[i]+f26[i])+rho0*(c1*v1-v2v2)-c1*rho+v2*force[3*i+2];
      pi_xy = 2.0*(f4[i]+f10[i]+f11[i]-f18[i]-f25[i]-f26[i])+rho0*(c1*v0-v0v1)+0.5*(v1*force[3*i  ]+v0*force[3*i+1]);
      pi_xz = f6[i]-f7[i]+f19[i]-f20[i]+2.0*(f10[i]-f11[i]+f25[i]-f26[i])-rho0*v0v2+0.5*(v2*force[3*i  ]+v0*force[3*i+2]);
      pi_yz = 2.0*(f8[i]-f9[i]+f10[i]-f11[i]-f25[i]+f26[i])+rho0*(c1*v2-v1v2)+0.5*(v2*force[3*i+1]+v1*force[3*i+2]);
      f0[i] =lbw[0] *(rho+rho0*(                                    -1.5*modv))-c2*(pi_xx+   pi_yy+   pi_zz);
      f1[i] =lbw[1] *(rho+rho0*(-3.0*v0                   +4.5*v0v0 -1.5*modv))+c3* pi_xx-c4*pi_yy-c4*pi_zz;
      f2[i] =lbw[2] *(rho+rho0*(-3.0*v1                   +4.5*v1v1 -1.5*modv))-c4* pi_xx+c3*pi_yy-c4*pi_zz;
      f3[i] =lbw[3] *(rho+rho0*(-3.0*v2                   +4.5*v2v2 -1.5*modv))-c4* pi_xx-c4*pi_yy+c3*pi_zz;
      f4[i] =lbw[4] *(rho+rho0*(-3.0*(v0+v1)   +9.0* v0v1 -4.5*v2v2 +3.0*modv))+c6* pi_xx+c6*pi_yy-c8*pi_zz +c5* pi_xy;
      f5[i] =lbw[5] *(rho+rho0*(-3.0*(v0-v1)   -9.0* v0v1 -4.5*v2v2 +3.0*modv))+c6* pi_xx+c6*pi_yy-c8*pi_zz -c5* pi_xy;
      f6[i] =lbw[6] *(rho+rho0*(-3.0*(v0+v2)   +9.0* v0v2 -4.5*v1v1 +3.0*modv))+c6* pi_xx-c8*pi_yy+c6*pi_zz +c5* pi_xz;
      f7[i] =lbw[7] *(rho+rho0*(-3.0*(v0-v2)   -9.0* v0v2 -4.5*v1v1 +3.0*modv))+c6* pi_xx-c8*pi_yy+c6*pi_zz -c5* pi_xz;
      f8[i] =lbw[8] *(rho+rho0*(-3.0*(v1+v2)   +9.0* v1v2 -4.5*v0v0 +3.0*modv))-c8* pi_xx+c6*pi_yy+c6*pi_zz +c5* pi_yz;
      f9[i] =lbw[9] *(rho+rho0*(-3.0*(v1-v2)   -9.0* v1v2 -4.5*v0v0 +3.0*modv))-c8* pi_xx+c6*pi_yy+c6*pi_zz -c5* pi_yz;
      f10[i]=lbw[10]*(rho+rho0*(-3.0*(v0+v1+v2)+9.0*(v0v1+v0v2+v1v2)+3.0*modv))+c9*(pi_xx+   pi_yy+   pi_zz)+c7*(pi_xy+pi_xz+pi_yz);
      f11[i]=lbw[11]*(rho+rho0*(-3.0*(v0+v1-v2)+9.0*(v0v1-v0v2-v1v2)+3.0*modv))+c9*(pi_xx+   pi_yy+   pi_zz)+c7*(pi_xy-pi_xz-pi_yz);
      f12[i]=lbw[12]*(rho+rho0*(-3.0*(v0-v1+v2)-9.0*(v0v1-v0v2+v1v2)+3.0*modv))+c9*(pi_xx+   pi_yy+   pi_zz)-c7*(pi_xy-pi_xz+pi_yz);
      f13[i]=lbw[13]*(rho+rho0*(-3.0*(v0-v1-v2)-9.0*(v0v1+v0v2-v1v2)+3.0*modv))+c9*(pi_xx+   pi_yy+   pi_zz)-c7*(pi_xy+pi_xz-pi_yz);
      f14[i]=lbw[14]*(rho+rho0*( 3.0*v0                   +4.5*v0v0 -1.5*modv))+c3* pi_xx-c4*pi_yy-c4*pi_zz;
      f15[i]=lbw[15]*(rho+rho0*( 3.0*v1                   +4.5*v1v1 -1.5*modv))-c4* pi_xx+c3*pi_yy-c4*pi_zz;
      f16[i]=lbw[16]*(rho+rho0*( 3.0*v2                   +4.5*v2v2 -1.5*modv))-c4* pi_xx-c4*pi_yy+c3*pi_zz;
      f17[i]=lbw[17]*(rho+rho0*( 3.0*(v0+v1)   +9.0* v0v1 -4.5*v2v2 +3.0*modv))+c6* pi_xx+c6*pi_yy-c8*pi_zz +c5* pi_xy;
      f18[i]=lbw[18]*(rho+rho0*( 3.0*(v0-v1)   -9.0* v0v1 -4.5*v2v2 +3.0*modv))+c6* pi_xx+c6*pi_yy-c8*pi_zz -c5* pi_xy;
      f19[i]=lbw[19]*(rho+rho0*( 3.0*(v0+v2)   +9.0* v0v2 -4.5*v1v1 +3.0*modv))+c6* pi_xx-c8*pi_yy+c6*pi_zz +c5* pi_xz;
      f20[i]=lbw[20]*(rho+rho0*( 3.0*(v0-v2)   -9.0* v0v2 -4.5*v1v1 +3.0*modv))+c6* pi_xx-c8*pi_yy+c6*pi_zz -c5* pi_xz;
      f21[i]=lbw[21]*(rho+rho0*( 3.0*(v1+v2)   +9.0* v1v2 -4.5*v0v0 +3.0*modv))-c8* pi_xx+c6*pi_yy+c6*pi_zz +c5* pi_yz;
      f22[i]=lbw[22]*(rho+rho0*( 3.0*(v1-v2)   -9.0* v1v2 -4.5*v0v0 +3.0*modv))-c8* pi_xx+c6*pi_yy+c6*pi_zz -c5* pi_yz;
      f23[i]=lbw[23]*(rho+rho0*( 3.0*(v0+v1+v2)+9.0*(v0v1+v0v2+v1v2)+3.0*modv))+c9*(pi_xx+   pi_yy+   pi_zz)+c7*(pi_xy+pi_xz+pi_yz);
      f24[i]=lbw[24]*(rho+rho0*( 3.0*(v0+v1-v2)+9.0*(v0v1-v0v2-v1v2)+3.0*modv))+c9*(pi_xx+   pi_yy+   pi_zz)+c7*(pi_xy-pi_xz-pi_yz);
      f25[i]=lbw[25]*(rho+rho0*( 3.0*(v0-v1+v2)-9.0*(v0v1-v0v2+v1v2)+3.0*modv))+c9*(pi_xx+   pi_yy+   pi_zz)-c7*(pi_xy-pi_xz+pi_yz);
      f26[i]=lbw[26]*(rho+rho0*( 3.0*(v0-v1-v2)-9.0*(v0v1+v0v2-v1v2)+3.0*modv))+c9*(pi_xx+   pi_yy+   pi_zz)-c7*(pi_xy+pi_xz-pi_yz);
    }
  }
  return 0;
}

int fD3Q27VCERegular(double *p, double v0, double v1, double v2, double *force,
                     double *f0, double *f1, double *f2, double *f3, double *f4,
                     double *f5, double *f6, double *f7, double *f8, double *f9,
                     double *f10, double *f11, double *f12, double *f13, double *f14,
                     double *f15, double *f16, double *f17, double *f18, double *f19,
                     double *f20, double *f21, double *f22, double *f23, double *f24,
                     double *f25, double *f26)
{

  // produce fixed velocity for compressible/incompressible fluids at concave edge boundary:
  // expressed for bottom left edge (VCETR)
  
  double rho0, modv, pi_xx, pi_yy, pi_zz, pi_xy, pi_xz, pi_yz, v0v0, v0v1, v0v2, v1v1, v1v2, v2v2;
  double c1=1.0/3.0,c2=4.0/9.0,c3=2.0/9.0,c4=1.0/9.0,c5=1.0/6.0,c6=1.0/18.0,c7=1.0/24.0,c8=1.0/36.0,c9=1.0/72.0,c10=2.0/3.0,c11=4.0/3.0,c12=5.0/18.0;

  v0v0 = v0*v0;
  v0v1 = v0*v1;
  v0v2 = v0*v2;
  v1v1 = v1*v1;
  v1v2 = v1*v2;
  v2v2 = v2*v2;
  modv = v0v0+v1v1+v2v2;

  if(!incompress) {
    for(int i=0; i<lbsy.nf; i++) {
      pi_xx = -f0[i]-f3[i]-f16[i]-2.0*(f2[i]+f8[i]+f9[i])+p[i]*(c10-c10*v1-v0v0)+v0*force[3*i  ];
      pi_yy = -f0[i]-f3[i]-f16[i]-2.0*(f1[i]+f6[i]+f7[i])+p[i]*(c10-c10*v0-v1v1)+v1*force[3*i+1];
      pi_zz = -c1*f0[i]+c10*(f3[i]+f16[i]-f1[i]-f2[i]-f4[i])+c11*(f6[i]+f7[i]+f8[i]+f9[i]+f10[i]+f11[i])-p[i]*v2v2+v2*force[3*i+2];
      pi_xy = f0[i]+f3[i]+f16[i]+2.0*(f1[i]+f2[i]+f6[i]+f7[i]+f8[i]+f9[i])+4.0*(f4[i]+f10[i]+f11[i])-p[i]*(1.0-v0)*(1.0-v1)+0.5*(v1*force[3*i  ]+v0*force[3*i+1]);
      pi_xz = 2.0*(f6[i]-f7[i]+f10[i]-f11[i])+p[i]*v2*(c12-v0)+0.5*(v2*force[3*i  ]+v0*force[3*i+2]);
      pi_yz = 2.0*(f8[i]-f9[i]+f10[i]-f11[i])+p[i]*v2*(c12-v1)+0.5*(v2*force[3*i+1]+v1*force[3*i+2]);
      f0[i] =p[i]*lbw[0] *(1.0                                    -1.5*modv)-c2*(pi_xx+   pi_yy+   pi_zz);
      f1[i] =p[i]*lbw[1] *(1.0-3.0*v0                   +4.5*v0v0 -1.5*modv)+c3* pi_xx-c4*pi_yy-c4*pi_zz;
      f2[i] =p[i]*lbw[2] *(1.0-3.0*v1                   +4.5*v1v1 -1.5*modv)-c4* pi_xx+c3*pi_yy-c4*pi_zz;
      f3[i] =p[i]*lbw[3] *(1.0-3.0*v2                   +4.5*v2v2 -1.5*modv)-c4* pi_xx-c4*pi_yy+c3*pi_zz;
      f4[i] =p[i]*lbw[4] *(1.0-3.0*(v0+v1)   +9.0* v0v1 -4.5*v2v2 +3.0*modv)+c6* pi_xx+c6*pi_yy-c8*pi_zz +c5* pi_xy;
      f5[i] =p[i]*lbw[5] *(1.0-3.0*(v0-v1)   -9.0* v0v1 -4.5*v2v2 +3.0*modv)+c6* pi_xx+c6*pi_yy-c8*pi_zz -c5* pi_xy;
      f6[i] =p[i]*lbw[6] *(1.0-3.0*(v0+v2)   +9.0* v0v2 -4.5*v1v1 +3.0*modv)+c6* pi_xx-c8*pi_yy+c6*pi_zz +c5* pi_xz;
      f7[i] =p[i]*lbw[7] *(1.0-3.0*(v0-v2)   -9.0* v0v2 -4.5*v1v1 +3.0*modv)+c6* pi_xx-c8*pi_yy+c6*pi_zz -c5* pi_xz;
      f8[i] =p[i]*lbw[8] *(1.0-3.0*(v1+v2)   +9.0* v1v2 -4.5*v0v0 +3.0*modv)-c8* pi_xx+c6*pi_yy+c6*pi_zz +c5* pi_yz;
      f9[i] =p[i]*lbw[9] *(1.0-3.0*(v1-v2)   -9.0* v1v2 -4.5*v0v0 +3.0*modv)-c8* pi_xx+c6*pi_yy+c6*pi_zz -c5* pi_yz;
      f10[i]=p[i]*lbw[10]*(1.0-3.0*(v0+v1+v2)+9.0*(v0v1+v0v2+v1v2)+3.0*modv)+c9*(pi_xx+   pi_yy+   pi_zz)+c7*(pi_xy+pi_xz+pi_yz);
      f11[i]=p[i]*lbw[11]*(1.0-3.0*(v0+v1-v2)+9.0*(v0v1-v0v2-v1v2)+3.0*modv)+c9*(pi_xx+   pi_yy+   pi_zz)+c7*(pi_xy-pi_xz-pi_yz);
      f12[i]=p[i]*lbw[12]*(1.0-3.0*(v0-v1+v2)-9.0*(v0v1-v0v2+v1v2)+3.0*modv)+c9*(pi_xx+   pi_yy+   pi_zz)-c7*(pi_xy-pi_xz+pi_yz);
      f13[i]=p[i]*lbw[13]*(1.0-3.0*(v0-v1-v2)-9.0*(v0v1+v0v2-v1v2)+3.0*modv)+c9*(pi_xx+   pi_yy+   pi_zz)-c7*(pi_xy+pi_xz-pi_yz);
      f14[i]=p[i]*lbw[14]*(1.0+3.0*v0                   +4.5*v0v0 -1.5*modv)+c3* pi_xx-c4*pi_yy-c4*pi_zz;
      f15[i]=p[i]*lbw[15]*(1.0+3.0*v1                   +4.5*v1v1 -1.5*modv)-c4* pi_xx+c3*pi_yy-c4*pi_zz;
      f16[i]=p[i]*lbw[16]*(1.0+3.0*v2                   +4.5*v2v2 -1.5*modv)-c4* pi_xx-c4*pi_yy+c3*pi_zz;
      f17[i]=p[i]*lbw[17]*(1.0+3.0*(v0+v1)   +9.0* v0v1 -4.5*v2v2 +3.0*modv)+c6* pi_xx+c6*pi_yy-c8*pi_zz +c5* pi_xy;
      f18[i]=p[i]*lbw[18]*(1.0+3.0*(v0-v1)   -9.0* v0v1 -4.5*v2v2 +3.0*modv)+c6* pi_xx+c6*pi_yy-c8*pi_zz -c5* pi_xy;
      f19[i]=p[i]*lbw[19]*(1.0+3.0*(v0+v2)   +9.0* v0v2 -4.5*v1v1 +3.0*modv)+c6* pi_xx-c8*pi_yy+c6*pi_zz +c5* pi_xz;
      f20[i]=p[i]*lbw[20]*(1.0+3.0*(v0-v2)   -9.0* v0v2 -4.5*v1v1 +3.0*modv)+c6* pi_xx-c8*pi_yy+c6*pi_zz -c5* pi_xz;
      f21[i]=p[i]*lbw[21]*(1.0+3.0*(v1+v2)   +9.0* v1v2 -4.5*v0v0 +3.0*modv)-c8* pi_xx+c6*pi_yy+c6*pi_zz +c5* pi_yz;
      f22[i]=p[i]*lbw[22]*(1.0+3.0*(v1-v2)   -9.0* v1v2 -4.5*v0v0 +3.0*modv)-c8* pi_xx+c6*pi_yy+c6*pi_zz -c5* pi_yz;
      f23[i]=p[i]*lbw[23]*(1.0+3.0*(v0+v1+v2)+9.0*(v0v1+v0v2+v1v2)+3.0*modv)+c9*(pi_xx+   pi_yy+   pi_zz)+c7*(pi_xy+pi_xz+pi_yz);
      f24[i]=p[i]*lbw[24]*(1.0+3.0*(v0+v1-v2)+9.0*(v0v1-v0v2-v1v2)+3.0*modv)+c9*(pi_xx+   pi_yy+   pi_zz)+c7*(pi_xy-pi_xz-pi_yz);
      f25[i]=p[i]*lbw[25]*(1.0+3.0*(v0-v1+v2)-9.0*(v0v1-v0v2+v1v2)+3.0*modv)+c9*(pi_xx+   pi_yy+   pi_zz)-c7*(pi_xy-pi_xz+pi_yz);
      f26[i]=p[i]*lbw[26]*(1.0+3.0*(v0-v1-v2)-9.0*(v0v1+v0v2-v1v2)+3.0*modv)+c9*(pi_xx+   pi_yy+   pi_zz)-c7*(pi_xy+pi_xz-pi_yz);
    }
  }
  else {
    for(int i=0; i<lbsy.nf; i++) {
      rho0 = lbincp[i];
      pi_xx = -f0[i]-f3[i]-f16[i]-2.0*(f2[i]+f8[i]+f9[i])+c10*p[i]-rho0*(c10*v1+v0v0)+v0*force[3*i  ];
      pi_yy = -f0[i]-f3[i]-f16[i]-2.0*(f1[i]+f6[i]+f7[i])+c10*p[i]-rho0*(c10*v0+v1v1)+v1*force[3*i+1];
      pi_zz = -c1*f0[i]+c10*(f3[i]+f16[i]-f1[i]-f2[i]-f4[i])+c11*(f6[i]+f7[i]+f8[i]+f9[i]+f10[i]+f11[i])-rho0*v2v2+v2*force[3*i+2];
      pi_xy = f0[i]+f3[i]+f16[i]+2.0*(f1[i]+f2[i]+f6[i]+f7[i]+f8[i]+f9[i])+4.0*(f4[i]+f10[i]+f11[i])-p[i]+rho0*(v0+v1-v0v1)+0.5*(v1*force[3*i  ]+v0*force[3*i+1]);
      pi_xz = 2.0*(f6[i]-f7[i]+f10[i]-f11[i])+rho0*v2*(c12-v0)+0.5*(v2*force[3*i  ]+v0*force[3*i+2]);
      pi_yz = 2.0*(f8[i]-f9[i]+f10[i]-f11[i])+rho0*v2*(c12-v1)+0.5*(v2*force[3*i+1]+v1*force[3*i+2]);
      f0[i] =lbw[0] *(p[i]+rho0*(                                    -1.5*modv))-c2*(pi_xx+   pi_yy+   pi_zz);
      f1[i] =lbw[1] *(p[i]+rho0*(-3.0*v0                   +4.5*v0v0 -1.5*modv))+c3* pi_xx-c4*pi_yy-c4*pi_zz;
      f2[i] =lbw[2] *(p[i]+rho0*(-3.0*v1                   +4.5*v1v1 -1.5*modv))-c4* pi_xx+c3*pi_yy-c4*pi_zz;
      f3[i] =lbw[3] *(p[i]+rho0*(-3.0*v2                   +4.5*v2v2 -1.5*modv))-c4* pi_xx-c4*pi_yy+c3*pi_zz;
      f4[i] =lbw[4] *(p[i]+rho0*(-3.0*(v0+v1)   +9.0* v0v1 -4.5*v2v2 +3.0*modv))+c6* pi_xx+c6*pi_yy-c8*pi_zz +c5* pi_xy;
      f5[i] =lbw[5] *(p[i]+rho0*(-3.0*(v0-v1)   -9.0* v0v1 -4.5*v2v2 +3.0*modv))+c6* pi_xx+c6*pi_yy-c8*pi_zz -c5* pi_xy;
      f6[i] =lbw[6] *(p[i]+rho0*(-3.0*(v0+v2)   +9.0* v0v2 -4.5*v1v1 +3.0*modv))+c6* pi_xx-c8*pi_yy+c6*pi_zz +c5* pi_xz;
      f7[i] =lbw[7] *(p[i]+rho0*(-3.0*(v0-v2)   -9.0* v0v2 -4.5*v1v1 +3.0*modv))+c6* pi_xx-c8*pi_yy+c6*pi_zz -c5* pi_xz;
      f8[i] =lbw[8] *(p[i]+rho0*(-3.0*(v1+v2)   +9.0* v1v2 -4.5*v0v0 +3.0*modv))-c8* pi_xx+c6*pi_yy+c6*pi_zz +c5* pi_yz;
      f9[i] =lbw[9] *(p[i]+rho0*(-3.0*(v1-v2)   -9.0* v1v2 -4.5*v0v0 +3.0*modv))-c8* pi_xx+c6*pi_yy+c6*pi_zz -c5* pi_yz;
      f10[i]=lbw[10]*(p[i]+rho0*(-3.0*(v0+v1+v2)+9.0*(v0v1+v0v2+v1v2)+3.0*modv))+c9*(pi_xx+   pi_yy+   pi_zz)+c7*(pi_xy+pi_xz+pi_yz);
      f11[i]=lbw[11]*(p[i]+rho0*(-3.0*(v0+v1-v2)+9.0*(v0v1-v0v2-v1v2)+3.0*modv))+c9*(pi_xx+   pi_yy+   pi_zz)+c7*(pi_xy-pi_xz-pi_yz);
      f12[i]=lbw[12]*(p[i]+rho0*(-3.0*(v0-v1+v2)-9.0*(v0v1-v0v2+v1v2)+3.0*modv))+c9*(pi_xx+   pi_yy+   pi_zz)-c7*(pi_xy-pi_xz+pi_yz);
      f13[i]=lbw[13]*(p[i]+rho0*(-3.0*(v0-v1-v2)-9.0*(v0v1+v0v2-v1v2)+3.0*modv))+c9*(pi_xx+   pi_yy+   pi_zz)-c7*(pi_xy+pi_xz-pi_yz);
      f14[i]=lbw[14]*(p[i]+rho0*( 3.0*v0                   +4.5*v0v0 -1.5*modv))+c3* pi_xx-c4*pi_yy-c4*pi_zz;
      f15[i]=lbw[15]*(p[i]+rho0*( 3.0*v1                   +4.5*v1v1 -1.5*modv))-c4* pi_xx+c3*pi_yy-c4*pi_zz;
      f16[i]=lbw[16]*(p[i]+rho0*( 3.0*v2                   +4.5*v2v2 -1.5*modv))-c4* pi_xx-c4*pi_yy+c3*pi_zz;
      f17[i]=lbw[17]*(p[i]+rho0*( 3.0*(v0+v1)   +9.0* v0v1 -4.5*v2v2 +3.0*modv))+c6* pi_xx+c6*pi_yy-c8*pi_zz +c5* pi_xy;
      f18[i]=lbw[18]*(p[i]+rho0*( 3.0*(v0-v1)   -9.0* v0v1 -4.5*v2v2 +3.0*modv))+c6* pi_xx+c6*pi_yy-c8*pi_zz -c5* pi_xy;
      f19[i]=lbw[19]*(p[i]+rho0*( 3.0*(v0+v2)   +9.0* v0v2 -4.5*v1v1 +3.0*modv))+c6* pi_xx-c8*pi_yy+c6*pi_zz +c5* pi_xz;
      f20[i]=lbw[20]*(p[i]+rho0*( 3.0*(v0-v2)   -9.0* v0v2 -4.5*v1v1 +3.0*modv))+c6* pi_xx-c8*pi_yy+c6*pi_zz -c5* pi_xz;
      f21[i]=lbw[21]*(p[i]+rho0*( 3.0*(v1+v2)   +9.0* v1v2 -4.5*v0v0 +3.0*modv))-c8* pi_xx+c6*pi_yy+c6*pi_zz +c5* pi_yz;
      f22[i]=lbw[22]*(p[i]+rho0*( 3.0*(v1-v2)   -9.0* v1v2 -4.5*v0v0 +3.0*modv))-c8* pi_xx+c6*pi_yy+c6*pi_zz -c5* pi_yz;
      f23[i]=lbw[23]*(p[i]+rho0*( 3.0*(v0+v1+v2)+9.0*(v0v1+v0v2+v1v2)+3.0*modv))+c9*(pi_xx+   pi_yy+   pi_zz)+c7*(pi_xy+pi_xz+pi_yz);
      f24[i]=lbw[24]*(p[i]+rho0*( 3.0*(v0+v1-v2)+9.0*(v0v1-v0v2-v1v2)+3.0*modv))+c9*(pi_xx+   pi_yy+   pi_zz)+c7*(pi_xy-pi_xz-pi_yz);
      f25[i]=lbw[25]*(p[i]+rho0*( 3.0*(v0-v1+v2)-9.0*(v0v1-v0v2+v1v2)+3.0*modv))+c9*(pi_xx+   pi_yy+   pi_zz)-c7*(pi_xy-pi_xz+pi_yz);
      f26[i]=lbw[26]*(p[i]+rho0*( 3.0*(v0-v1-v2)-9.0*(v0v1+v0v2-v1v2)+3.0*modv))+c9*(pi_xx+   pi_yy+   pi_zz)-c7*(pi_xy+pi_xz-pi_yz);
    }
  }
  return 0;
}

int fD3Q27VCCRegular(double *p, double v0, double v1, double v2, double *force,
                     double *f0, double *f1, double *f2, double *f3, double *f4,
                     double *f5, double *f6, double *f7, double *f8, double *f9,
                     double *f10, double *f11, double *f12, double *f13, double *f14,
                     double *f15, double *f16, double *f17, double *f18, double *f19,
                     double *f20, double *f21, double *f22, double *f23, double *f24,
                     double *f25, double *f26)
{

  // produce fixed velocity for compressible/incompressible fluids at concave corner boundary:
  // expressed for bottom left back corner (VCCTRF)
  
  double rho0, modv, pi_xx, pi_yy, pi_zz, pi_xy, pi_xz, pi_yz, v0v0, v0v1, v0v2, v1v1, v1v2, v2v2;
  double c1=1.0/3.0,c2=4.0/9.0,c3=2.0/9.0,c4=1.0/9.0,c5=1.0/6.0,c6=1.0/18.0,c7=1.0/24.0,c8=1.0/36.0,c9=1.0/72.0,c10=11.0/15.0;
  double c11=8.0/15.0,c12=22.0/15.0,c13=5.0/27.0,c14=10.0/27.0,c15=2.0/3.0,c16=8.0/3.0,c17=7.0/27.0;

  v0v0 = v0*v0;
  v0v1 = v0*v1;
  v0v2 = v0*v2;
  v1v1 = v1*v1;
  v1v2 = v1*v2;
  v2v2 = v2*v2;
  modv = v0v0+v1v1+v2v2;

  if(!incompress) {
    for(int i=0; i<lbsy.nf; i++) {
      pi_xx = -c10*f0[i]+c11*(f1[i]+f4[i]+f6[i]+f10[i])-c12*(f2[i]+f3[i]+f8[i])+p[i]*(0.4+c13*v0-c14*(v1+v2)-v0v0)+v0*force[3*i  ];
      pi_yy = -c10*f0[i]+c11*(f2[i]+f4[i]+f8[i]+f10[i])-c12*(f1[i]+f3[i]+f6[i])+p[i]*(0.4+c13*v1-c14*(v0+v2)-v1v1)+v1*force[3*i+1];
      pi_zz = -c10*f0[i]+c11*(f3[i]+f6[i]+f8[i]+f10[i])-c12*(f1[i]+f2[i]+f4[i])+p[i]*(0.4+c13*v2-c14*(v0+v1)-v2v2)+v2*force[3*i+2];
      pi_xy = c1*f0[i]+c15*(f1[i]+f2[i]+f3[i]+f6[i]+f8[i])+c16*(f4[i]+f10[i])-p[i]*(c1-c14*(v0+v1)-c17*v2+v0v1)+0.5*(v1*force[3*i  ]+v0*force[3*i+1]);
      pi_xz = c1*f0[i]+c15*(f1[i]+f2[i]+f3[i]+f4[i]+f8[i])+c16*(f6[i]+f10[i])-p[i]*(c1-c14*(v0+v2)-c17*v1+v0v2)+0.5*(v2*force[3*i  ]+v0*force[3*i+2]);
      pi_yz = c1*f0[i]+c15*(f1[i]+f2[i]+f3[i]+f4[i]+f6[i])+c16*(f8[i]+f10[i])-p[i]*(c1-c14*(v1+v2)-c17*v0+v1v2)+0.5*(v2*force[3*i+1]+v1*force[3*i+2]);
      f0[i] =p[i]*lbw[0] *(1.0                                    -1.5*modv)-c2*(pi_xx+   pi_yy+   pi_zz);
      f1[i] =p[i]*lbw[1] *(1.0-3.0*v0                   +4.5*v0v0 -1.5*modv)+c3* pi_xx-c4*pi_yy-c4*pi_zz;
      f2[i] =p[i]*lbw[2] *(1.0-3.0*v1                   +4.5*v1v1 -1.5*modv)-c4* pi_xx+c3*pi_yy-c4*pi_zz;
      f3[i] =p[i]*lbw[3] *(1.0-3.0*v2                   +4.5*v2v2 -1.5*modv)-c4* pi_xx-c4*pi_yy+c3*pi_zz;
      f4[i] =p[i]*lbw[4] *(1.0-3.0*(v0+v1)   +9.0* v0v1 -4.5*v2v2 +3.0*modv)+c6* pi_xx+c6*pi_yy-c8*pi_zz +c5* pi_xy;
      f5[i] =p[i]*lbw[5] *(1.0-3.0*(v0-v1)   -9.0* v0v1 -4.5*v2v2 +3.0*modv)+c6* pi_xx+c6*pi_yy-c8*pi_zz -c5* pi_xy;
      f6[i] =p[i]*lbw[6] *(1.0-3.0*(v0+v2)   +9.0* v0v2 -4.5*v1v1 +3.0*modv)+c6* pi_xx-c8*pi_yy+c6*pi_zz +c5* pi_xz;
      f7[i] =p[i]*lbw[7] *(1.0-3.0*(v0-v2)   -9.0* v0v2 -4.5*v1v1 +3.0*modv)+c6* pi_xx-c8*pi_yy+c6*pi_zz -c5* pi_xz;
      f8[i] =p[i]*lbw[8] *(1.0-3.0*(v1+v2)   +9.0* v1v2 -4.5*v0v0 +3.0*modv)-c8* pi_xx+c6*pi_yy+c6*pi_zz +c5* pi_yz;
      f9[i] =p[i]*lbw[9] *(1.0-3.0*(v1-v2)   -9.0* v1v2 -4.5*v0v0 +3.0*modv)-c8* pi_xx+c6*pi_yy+c6*pi_zz -c5* pi_yz;
      f10[i]=p[i]*lbw[10]*(1.0-3.0*(v0+v1+v2)+9.0*(v0v1+v0v2+v1v2)+3.0*modv)+c9*(pi_xx+   pi_yy+   pi_zz)+c7*(pi_xy+pi_xz+pi_yz);
      f11[i]=p[i]*lbw[11]*(1.0-3.0*(v0+v1-v2)+9.0*(v0v1-v0v2-v1v2)+3.0*modv)+c9*(pi_xx+   pi_yy+   pi_zz)+c7*(pi_xy-pi_xz-pi_yz);
      f12[i]=p[i]*lbw[12]*(1.0-3.0*(v0-v1+v2)-9.0*(v0v1-v0v2+v1v2)+3.0*modv)+c9*(pi_xx+   pi_yy+   pi_zz)-c7*(pi_xy-pi_xz+pi_yz);
      f13[i]=p[i]*lbw[13]*(1.0-3.0*(v0-v1-v2)-9.0*(v0v1+v0v2-v1v2)+3.0*modv)+c9*(pi_xx+   pi_yy+   pi_zz)-c7*(pi_xy+pi_xz-pi_yz);
      f14[i]=p[i]*lbw[14]*(1.0+3.0*v0                   +4.5*v0v0 -1.5*modv)+c3* pi_xx-c4*pi_yy-c4*pi_zz;
      f15[i]=p[i]*lbw[15]*(1.0+3.0*v1                   +4.5*v1v1 -1.5*modv)-c4* pi_xx+c3*pi_yy-c4*pi_zz;
      f16[i]=p[i]*lbw[16]*(1.0+3.0*v2                   +4.5*v2v2 -1.5*modv)-c4* pi_xx-c4*pi_yy+c3*pi_zz;
      f17[i]=p[i]*lbw[17]*(1.0+3.0*(v0+v1)   +9.0* v0v1 -4.5*v2v2 +3.0*modv)+c6* pi_xx+c6*pi_yy-c8*pi_zz +c5* pi_xy;
      f18[i]=p[i]*lbw[18]*(1.0+3.0*(v0-v1)   -9.0* v0v1 -4.5*v2v2 +3.0*modv)+c6* pi_xx+c6*pi_yy-c8*pi_zz -c5* pi_xy;
      f19[i]=p[i]*lbw[19]*(1.0+3.0*(v0+v2)   +9.0* v0v2 -4.5*v1v1 +3.0*modv)+c6* pi_xx-c8*pi_yy+c6*pi_zz +c5* pi_xz;
      f20[i]=p[i]*lbw[20]*(1.0+3.0*(v0-v2)   -9.0* v0v2 -4.5*v1v1 +3.0*modv)+c6* pi_xx-c8*pi_yy+c6*pi_zz -c5* pi_xz;
      f21[i]=p[i]*lbw[21]*(1.0+3.0*(v1+v2)   +9.0* v1v2 -4.5*v0v0 +3.0*modv)-c8* pi_xx+c6*pi_yy+c6*pi_zz +c5* pi_yz;
      f22[i]=p[i]*lbw[22]*(1.0+3.0*(v1-v2)   -9.0* v1v2 -4.5*v0v0 +3.0*modv)-c8* pi_xx+c6*pi_yy+c6*pi_zz -c5* pi_yz;
      f23[i]=p[i]*lbw[23]*(1.0+3.0*(v0+v1+v2)+9.0*(v0v1+v0v2+v1v2)+3.0*modv)+c9*(pi_xx+   pi_yy+   pi_zz)+c7*(pi_xy+pi_xz+pi_yz);
      f24[i]=p[i]*lbw[24]*(1.0+3.0*(v0+v1-v2)+9.0*(v0v1-v0v2-v1v2)+3.0*modv)+c9*(pi_xx+   pi_yy+   pi_zz)+c7*(pi_xy-pi_xz-pi_yz);
      f25[i]=p[i]*lbw[25]*(1.0+3.0*(v0-v1+v2)-9.0*(v0v1-v0v2+v1v2)+3.0*modv)+c9*(pi_xx+   pi_yy+   pi_zz)-c7*(pi_xy-pi_xz+pi_yz);
      f26[i]=p[i]*lbw[26]*(1.0+3.0*(v0-v1-v2)-9.0*(v0v1+v0v2-v1v2)+3.0*modv)+c9*(pi_xx+   pi_yy+   pi_zz)-c7*(pi_xy+pi_xz-pi_yz);
    }
  }
  else {
    for(int i=0; i<lbsy.nf; i++) {
      rho0 = lbincp[i];
      pi_xx = -c10*f0[i]+c11*(f1[i]+f4[i]+f6[i]+f10[i])-c12*(f2[i]+f3[i]+f8[i])+0.4*p[i]+rho0*(c13*v0-c14*(v1+v2)-v0v0)+v0*force[3*i  ];
      pi_yy = -c10*f0[i]+c11*(f2[i]+f4[i]+f8[i]+f10[i])-c12*(f1[i]+f3[i]+f6[i])+0.4*p[i]+rho0*(c13*v1-c14*(v0+v2)-v1v1)+v1*force[3*i+1];
      pi_zz = -c10*f0[i]+c11*(f3[i]+f6[i]+f8[i]+f10[i])-c12*(f1[i]+f2[i]+f4[i])+0.4*p[i]+rho0*(c13*v2-c14*(v0+v1)-v2v2)+v2*force[3*i+2];
      pi_xy = c1*f0[i]+c15*(f1[i]+f2[i]+f3[i]+f6[i]+f8[i])+c16*(f4[i]+f10[i])-c1*p[i]+rho0*(c14*(v0+v1)+c17*v2-v0v1)+0.5*(v1*force[3*i  ]+v0*force[3*i+1]);
      pi_xz = c1*f0[i]+c15*(f1[i]+f2[i]+f3[i]+f4[i]+f8[i])+c16*(f6[i]+f10[i])-c1*p[i]+rho0*(c14*(v0+v2)+c17*v1-v0v2)+0.5*(v2*force[3*i  ]+v0*force[3*i+2]);
      pi_yz = c1*f0[i]+c15*(f1[i]+f2[i]+f3[i]+f4[i]+f6[i])+c16*(f8[i]+f10[i])-c1*p[i]+rho0*(c14*(v1+v2)+c17*v0-v1v2)+0.5*(v2*force[3*i+1]+v1*force[3*i+2]);
      f0[i] =lbw[0] *(p[i]+rho0*(                                    -1.5*modv))-c2*(pi_xx+   pi_yy+   pi_zz);
      f1[i] =lbw[1] *(p[i]+rho0*(-3.0*v0                   +4.5*v0v0 -1.5*modv))+c3* pi_xx-c4*pi_yy-c4*pi_zz;
      f2[i] =lbw[2] *(p[i]+rho0*(-3.0*v1                   +4.5*v1v1 -1.5*modv))-c4* pi_xx+c3*pi_yy-c4*pi_zz;
      f3[i] =lbw[3] *(p[i]+rho0*(-3.0*v2                   +4.5*v2v2 -1.5*modv))-c4* pi_xx-c4*pi_yy+c3*pi_zz;
      f4[i] =lbw[4] *(p[i]+rho0*(-3.0*(v0+v1)   +9.0* v0v1 -4.5*v2v2 +3.0*modv))+c6* pi_xx+c6*pi_yy-c8*pi_zz +c5* pi_xy;
      f5[i] =lbw[5] *(p[i]+rho0*(-3.0*(v0-v1)   -9.0* v0v1 -4.5*v2v2 +3.0*modv))+c6* pi_xx+c6*pi_yy-c8*pi_zz -c5* pi_xy;
      f6[i] =lbw[6] *(p[i]+rho0*(-3.0*(v0+v2)   +9.0* v0v2 -4.5*v1v1 +3.0*modv))+c6* pi_xx-c8*pi_yy+c6*pi_zz +c5* pi_xz;
      f7[i] =lbw[7] *(p[i]+rho0*(-3.0*(v0-v2)   -9.0* v0v2 -4.5*v1v1 +3.0*modv))+c6* pi_xx-c8*pi_yy+c6*pi_zz -c5* pi_xz;
      f8[i] =lbw[8] *(p[i]+rho0*(-3.0*(v1+v2)   +9.0* v1v2 -4.5*v0v0 +3.0*modv))-c8* pi_xx+c6*pi_yy+c6*pi_zz +c5* pi_yz;
      f9[i] =lbw[9] *(p[i]+rho0*(-3.0*(v1-v2)   -9.0* v1v2 -4.5*v0v0 +3.0*modv))-c8* pi_xx+c6*pi_yy+c6*pi_zz -c5* pi_yz;
      f10[i]=lbw[10]*(p[i]+rho0*(-3.0*(v0+v1+v2)+9.0*(v0v1+v0v2+v1v2)+3.0*modv))+c9*(pi_xx+   pi_yy+   pi_zz)+c7*(pi_xy+pi_xz+pi_yz);
      f11[i]=lbw[11]*(p[i]+rho0*(-3.0*(v0+v1-v2)+9.0*(v0v1-v0v2-v1v2)+3.0*modv))+c9*(pi_xx+   pi_yy+   pi_zz)+c7*(pi_xy-pi_xz-pi_yz);
      f12[i]=lbw[12]*(p[i]+rho0*(-3.0*(v0-v1+v2)-9.0*(v0v1-v0v2+v1v2)+3.0*modv))+c9*(pi_xx+   pi_yy+   pi_zz)-c7*(pi_xy-pi_xz+pi_yz);
      f13[i]=lbw[13]*(p[i]+rho0*(-3.0*(v0-v1-v2)-9.0*(v0v1+v0v2-v1v2)+3.0*modv))+c9*(pi_xx+   pi_yy+   pi_zz)-c7*(pi_xy+pi_xz-pi_yz);
      f14[i]=lbw[14]*(p[i]+rho0*( 3.0*v0                   +4.5*v0v0 -1.5*modv))+c3* pi_xx-c4*pi_yy-c4*pi_zz;
      f15[i]=lbw[15]*(p[i]+rho0*( 3.0*v1                   +4.5*v1v1 -1.5*modv))-c4* pi_xx+c3*pi_yy-c4*pi_zz;
      f16[i]=lbw[16]*(p[i]+rho0*( 3.0*v2                   +4.5*v2v2 -1.5*modv))-c4* pi_xx-c4*pi_yy+c3*pi_zz;
      f17[i]=lbw[17]*(p[i]+rho0*( 3.0*(v0+v1)   +9.0* v0v1 -4.5*v2v2 +3.0*modv))+c6* pi_xx+c6*pi_yy-c8*pi_zz +c5* pi_xy;
      f18[i]=lbw[18]*(p[i]+rho0*( 3.0*(v0-v1)   -9.0* v0v1 -4.5*v2v2 +3.0*modv))+c6* pi_xx+c6*pi_yy-c8*pi_zz -c5* pi_xy;
      f19[i]=lbw[19]*(p[i]+rho0*( 3.0*(v0+v2)   +9.0* v0v2 -4.5*v1v1 +3.0*modv))+c6* pi_xx-c8*pi_yy+c6*pi_zz +c5* pi_xz;
      f20[i]=lbw[20]*(p[i]+rho0*( 3.0*(v0-v2)   -9.0* v0v2 -4.5*v1v1 +3.0*modv))+c6* pi_xx-c8*pi_yy+c6*pi_zz -c5* pi_xz;
      f21[i]=lbw[21]*(p[i]+rho0*( 3.0*(v1+v2)   +9.0* v1v2 -4.5*v0v0 +3.0*modv))-c8* pi_xx+c6*pi_yy+c6*pi_zz +c5* pi_yz;
      f22[i]=lbw[22]*(p[i]+rho0*( 3.0*(v1-v2)   -9.0* v1v2 -4.5*v0v0 +3.0*modv))-c8* pi_xx+c6*pi_yy+c6*pi_zz -c5* pi_yz;
      f23[i]=lbw[23]*(p[i]+rho0*( 3.0*(v0+v1+v2)+9.0*(v0v1+v0v2+v1v2)+3.0*modv))+c9*(pi_xx+   pi_yy+   pi_zz)+c7*(pi_xy+pi_xz+pi_yz);
      f24[i]=lbw[24]*(p[i]+rho0*( 3.0*(v0+v1-v2)+9.0*(v0v1-v0v2-v1v2)+3.0*modv))+c9*(pi_xx+   pi_yy+   pi_zz)+c7*(pi_xy-pi_xz-pi_yz);
      f25[i]=lbw[25]*(p[i]+rho0*( 3.0*(v0-v1+v2)-9.0*(v0v1-v0v2+v1v2)+3.0*modv))+c9*(pi_xx+   pi_yy+   pi_zz)-c7*(pi_xy-pi_xz+pi_yz);
      f26[i]=lbw[26]*(p[i]+rho0*( 3.0*(v0-v1-v2)-9.0*(v0v1+v0v2-v1v2)+3.0*modv))+c9*(pi_xx+   pi_yy+   pi_zz)-c7*(pi_xy+pi_xz-pi_yz);
    }
  }
  return 0;
}

int fD3Q27VPSCLBERegular(double v0, double v1, double v2, double *force,
                         double *f0, double *f1, double *f2, double *f3, double *f4,
                         double *f5, double *f6, double *f7, double *f8, double *f9,
                         double *f10, double *f11, double *f12, double *f13, double *f14,
                         double *f15, double *f16, double *f17, double *f18, double *f19,
                         double *f20, double *f21, double *f22, double *f23, double *f24,
                         double *f25, double *f26)
{

  // produce fixed velocity for compressible fluids at planar surface boundary:
  // expressed for bottom wall (VPST) using higher-order equilibrium distribution functions for CLBE collisions
  
  double rho, pi_xx, pi_yy, pi_zz, pi_xy, pi_xz, pi_yz, v0v0, v0v1, v0v2, v1v1, v1v2, v2v2, v0v1v2;
  double c1=1.0/3.0,c2=4.0/9.0,c3=2.0/9.0,c4=1.0/9.0,c5=1.0/6.0,c6=1.0/18.0,c7=1.0/24.0,c8=1.0/36.0,c9=1.0/72.0;

  v0v0 = v0*v0;
  v0v1 = v0*v1;
  v0v2 = v0*v2;
  v1v1 = v1*v1;
  v1v2 = v1*v2;
  v2v2 = v2*v2;
  v0v1v2 = v0*v1*v2;

  for(int i=0; i<lbsy.nf; i++) {
    rho=(f0[i]+f1[i]+f3[i]+f6[i]+f7[i]+f14[i]+f16[i]+f19[i]+f20[i]+2.0*(f2[i]+f4[i]+f8[i]+f9[i]+f10[i]+f11[i]+f18[i]+f25[i]+f26[i])-0.5*force[3*i+1])/(1.0-v1);
    pi_xx = f1[i]+f6[i]+f7[i]+f14[i]+f19[i]+f20[i]+2.0*(f4[i]+f10[i]+f11[i]+f18[i]+f25[i]+f26[i])+rho*(v1-1.0)*(c1+v0v0)+v0*force[3*i  ];
    pi_yy = 2.0*(f2[i]+f4[i]+f8[i]+f9[i]+f10[i]+f11[i]+f18[i]+f25[i]+f26[i])+rho*(v1-v1v1-c1)+v1*force[3*i+1];
    pi_zz = f3[i]+f6[i]+f7[i]+f16[i]+f19[i]+f20[i]+2.0*(f8[i]+f9[i]+f10[i]+f11[i]+f25[i]+f26[i])+rho*(v1-1.0)*(c1+v2v2)+v2*force[3*i+2];
    pi_xy = 2.0*(f4[i]+f10[i]+f11[i]-f18[i]-f25[i]-f26[i])+rho*v0*(c1-v1+v1v1)+0.5*(v1*force[3*i  ]+v0*force[3*i+1]);
    pi_xz = f6[i]-f7[i]+f19[i]-f20[i]+2.0*(f10[i]-f11[i]+f25[i]-f26[i])+rho*v0v2*(v1-1.0)+0.5*(v2*force[3*i  ]+v0*force[3*i+2]);
    pi_yz = 2.0*(f8[i]-f9[i]+f10[i]-f11[i]-f25[i]+f26[i])+rho*v2*(c1-v1+v1v1)+0.5*(v2*force[3*i+1]+v1*force[3*i+2]);
    f0[i] =rho*lbw[0] *(1.0               -1.5*(v0v0+v1v1+v2v2      )+2.25*(     v0v1 *v0v1     +v0v2 *v0v2     +v1v2 *v1v2)                                                                         -3.375*v0v1v2*v0v1v2 )-c2*(pi_xx+   pi_yy+   pi_zz);
    f1[i] =rho*lbw[1] *(1.0-3.0*v0        +3.0*(v0v0-0.5*(v1v1+v2v2)) -4.5*(     v0v1 *v0v1     +v0v2 *v0v2 -0.5*v1v2 *v1v2)+4.5*(             v1v1 *v0    +v2v2* v0    )+6.75*v0v1v2*(                      -v1v2+v0v1v2))+c3* pi_xx-c4*pi_yy-c4*pi_zz;
    f2[i] =rho*lbw[2] *(1.0-3.0*v1        +3.0*(v1v1-0.5*(v0v0+v2v2)) -4.5*(     v0v1 *v0v1 -0.5*v0v2 *v0v2     +v1v2 *v1v2)+4.5*(v0v0 *v1                 +v2v2* v1    )+6.75*v0v1v2*(                 -v0v2     +v0v1v2))-c4* pi_xx+c3*pi_yy-c4*pi_zz;
    f3[i] =rho*lbw[3] *(1.0-3.0*v2        +3.0*(v2v2-0.5*(v0v0+v1v1)) -4.5*(-0.5*v0v1 *v0v1     +v0v2 *v0v2     +v1v2 *v1v2)+4.5*(v0v0 *v2    +v1v1 *v2                 )+6.75*v0v1v2*(            -v0v1          +v0v1v2))-c4* pi_xx-c4*pi_yy+c3*pi_zz;
    f4[i] =rho*lbw[4] *(1.0-3.0*(v0+v1)   +3.0*(v0v0+v1v1-0.5*v2v2  ) +9.0*((1.0+v0v1)*v0v1 -0.5*v0v2 *v0v2 -0.5*v1v2 *v1v2)-9.0*(v0v0 *v1    +v1v1 *v0-0.5*v2v2*(v0+v1))-13.5*v0v1v2*(          v2     -v0v2-v1v2+v0v1v2))+c6* pi_xx+c6*pi_yy-c8*pi_zz +c5* pi_xy;
    f5[i] =rho*lbw[5] *(1.0-3.0*(v0-v1)   +3.0*(v0v0+v1v1-0.5*v2v2  ) -9.0*((1.0-v0v1)*v0v1 +0.5*v0v2 *v0v2 +0.5*v1v2 *v1v2)+9.0*(v0v0 *v1    -v1v1 *v0+0.5*v2v2*(v0-v1))+13.5*v0v1v2*(          v2     -v0v2+v1v2-v0v1v2))+c6* pi_xx+c6*pi_yy-c8*pi_zz -c5* pi_xy;
    f6[i] =rho*lbw[6] *(1.0-3.0*(v0+v2)   +3.0*(v0v0+v2v2-0.5*v1v1  ) +9.0*(-0.5*v0v1 *v0v1+(1.0+v0v2)*v0v2  -0.5*v1v2*v1v2)-9.0*(v0v0 *v2    +v2v2 *v0-0.5*v1v1*(v0+v2))-13.5*v0v1v2*(       v1   -v0v1     -v1v2+v0v1v2))+c6* pi_xx-c8*pi_yy+c6*pi_zz +c5* pi_xz;
    f7[i] =rho*lbw[7] *(1.0-3.0*(v0-v2)   +3.0*(v0v0+v2v2-0.5*v1v1  ) -9.0*( 0.5*v0v1 *v0v1+(1.0-v0v2)*v0v2  +0.5*v1v2*v1v2)+9.0*(v0v0 *v2    -v2v2 *v0+0.5*v1v1*(v0-v2))+13.5*v0v1v2*(       v1   -v0v1     +v1v2-v0v1v2))+c6* pi_xx-c8*pi_yy+c6*pi_zz -c5* pi_xz;
    f8[i] =rho*lbw[8] *(1.0-3.0*(v1+v2)   +3.0*(v1v1+v2v2-0.5*v0v0  ) +9.0*(-0.5*v0v1 *v0v1 -0.5*v0v2 *v0v2+(1.0+v1v2)*v1v2)-9.0*(v1v1 *v2    +v2v2 *v1-0.5*v0v0*(v1+v2))-13.5*v0v1v2*(    v0      -v0v1-v0v2     +v0v1v2))-c8* pi_xx+c6*pi_yy+c6*pi_zz +c5* pi_yz;
    f9[i] =rho*lbw[9] *(1.0-3.0*(v1-v2)   +3.0*(v1v1+v2v2-0.5*v0v0  ) -9.0*( 0.5*v0v1 *v0v1 +0.5*v0v2 *v0v2+(1.0-v1v2)*v1v2)+9.0*(v1v1 *v2    -v2v2 *v1+0.5*v0v0*(v1-v2))+13.5*v0v1v2*(    v0      -v0v1+v0v2     -v0v1v2))-c8* pi_xx+c6*pi_yy+c6*pi_zz -c5* pi_yz;
    f10[i]=rho*lbw[10]*(1.0-3.0*(v0+v1+v2)+3.0*(v0v0+v1v1+v2v2      ) +9.0*((1.0+v0v1)*v0v1+(1.0+v0v2)*v0v2+(1.0+v1v2)*v1v2)-9.0*(v0v0*(v1+v2)+v1v1*(v0+v2)+v2v2*(v0+v1))-27.0*v0v1v2*(1.0-v0-v1-v2+v0v1+v0v2+v1v2-v0v1v2))+c9*(pi_xx+   pi_yy+   pi_zz)+c7*(pi_xy+pi_xz+pi_yz);
    f11[i]=rho*lbw[11]*(1.0-3.0*(v0+v1-v2)+3.0*(v0v0+v1v1+v2v2      ) +9.0*((1.0+v0v1)*v0v1-(1.0-v0v2)*v0v2-(1.0-v1v2)*v1v2)-9.0*(v0v0*(v1-v2)-v1v1*(v0+v2)+v2v2*(v0+v1))+27.0*v0v1v2*(1.0-v0-v1+v2+v0v1-v0v2-v1v2+v0v1v2))+c9*(pi_xx+   pi_yy+   pi_zz)+c7*(pi_xy-pi_xz-pi_yz);
    f12[i]=rho*lbw[12]*(1.0-3.0*(v0-v1+v2)+3.0*(v0v0+v1v1+v2v2      ) -9.0*((1.0-v0v1)*v0v1-(1.0+v0v2)*v0v2+(1.0-v1v2)*v1v2)+9.0*(v0v0*(v1-v2)-v1v1*(v0+v2)-v2v2*(v0-v1))+27.0*v0v1v2*(1.0-v0+v1-v2-v0v1+v0v2-v1v2+v0v1v2))+c9*(pi_xx+   pi_yy+   pi_zz)-c7*(pi_xy-pi_xz+pi_yz);
    f13[i]=rho*lbw[13]*(1.0-3.0*(v0-v1-v2)+3.0*(v0v0+v1v1+v2v2      ) -9.0*((1.0-v0v1)*v0v1+(1.0-v0v2)*v0v2-(1.0+v1v2)*v1v2)+9.0*(v0v0*(v1+v2)-v1v1*(v0-v2)-v2v2*(v0-v1))-27.0*v0v1v2*(1.0-v0+v1+v2-v0v1-v0v2+v1v2-v0v1v2))+c9*(pi_xx+   pi_yy+   pi_zz)-c7*(pi_xy+pi_xz-pi_yz);
    f14[i]=rho*lbw[14]*(1.0+3.0*v0        +3.0*(v0v0-0.5*(v1v1+v2v2)) -4.5*(     v0v1 *v0v1     +v0v2 *v0v2 -0.5*v1v2 *v1v2)-4.5*(             v1v1 *v0    +v2v2* v0    )+6.75*v0v1v2*(                       v1v2+v0v1v2))+c3* pi_xx-c4*pi_yy-c4*pi_zz;
    f15[i]=rho*lbw[15]*(1.0+3.0*v1        +3.0*(v1v1-0.5*(v0v0+v2v2)) -4.5*(     v0v1 *v0v1 -0.5*v0v2 *v0v2     +v1v2 *v1v2)-4.5*(v0v0 *v1                 +v2v2* v1    )+6.75*v0v1v2*(                  v0v2     +v0v1v2))-c4* pi_xx+c3*pi_yy-c4*pi_zz;
    f16[i]=rho*lbw[16]*(1.0+3.0*v2        +3.0*(v2v2-0.5*(v0v0+v1v1)) -4.5*(-0.5*v0v1 *v0v1     +v0v2 *v0v2     +v1v2 *v1v2)-4.5*(v0v0 *v2    +v1v1 *v2                 )+6.75*v0v1v2*(             v0v1          +v0v1v2))-c4* pi_xx-c4*pi_yy+c3*pi_zz;
    f17[i]=rho*lbw[17]*(1.0+3.0*(v0+v1)   +3.0*(v0v0+v1v1-0.5*v2v2  ) +9.0*((1.0+v0v1)*v0v1 -0.5*v0v2 *v0v2 -0.5*v1v2 *v1v2)+9.0*(v0v0 *v1    +v1v1 *v0-0.5*v2v2*(v0+v1))-13.5*v0v1v2*(          v2     +v0v2+v1v2+v0v1v2))+c6* pi_xx+c6*pi_yy-c8*pi_zz +c5* pi_xy;
    f18[i]=rho*lbw[18]*(1.0+3.0*(v0-v1)   +3.0*(v0v0+v1v1-0.5*v2v2  ) -9.0*((1.0-v0v1)*v0v1 +0.5*v0v2 *v0v2 +0.5*v1v2 *v1v2)-9.0*(v0v0 *v1    -v1v1 *v0+0.5*v2v2*(v0-v1))+13.5*v0v1v2*(          v2     +v0v2-v1v2-v0v1v2))+c6* pi_xx+c6*pi_yy-c8*pi_zz -c5* pi_xy;
    f19[i]=rho*lbw[19]*(1.0+3.0*(v0+v2)   +3.0*(v0v0+v2v2-0.5*v1v1  ) +9.0*(-0.5*v0v1 *v0v1+(1.0+v0v2)*v0v2  -0.5*v1v2*v1v2)+9.0*(v0v0 *v2    +v2v2 *v0-0.5*v1v1*(v0+v2))-13.5*v0v1v2*(       v1   +v0v1     +v1v2+v0v1v2))+c6* pi_xx-c8*pi_yy+c6*pi_zz +c5* pi_xz;
    f20[i]=rho*lbw[20]*(1.0+3.0*(v0-v2)   +3.0*(v0v0+v2v2-0.5*v1v1  ) -9.0*( 0.5*v0v1 *v0v1+(1.0-v0v2)*v0v2  +0.5*v1v2*v1v2)-9.0*(v0v0 *v2    -v2v2 *v0+0.5*v1v1*(v0-v2))+13.5*v0v1v2*(       v1   +v0v1     -v1v2-v0v1v2))+c6* pi_xx-c8*pi_yy+c6*pi_zz -c5* pi_xz;
    f21[i]=rho*lbw[21]*(1.0+3.0*(v1+v2)   +3.0*(v1v1+v2v2-0.5*v0v0  ) +9.0*(-0.5*v0v1 *v0v1 -0.5*v0v2 *v0v2+(1.0+v1v2)*v1v2)+9.0*(v1v1 *v2    +v2v2 *v1-0.5*v0v0*(v1+v2))-13.5*v0v1v2*(    v0      +v0v1+v0v2     +v0v1v2))-c8* pi_xx+c6*pi_yy+c6*pi_zz +c5* pi_yz;
    f22[i]=rho*lbw[22]*(1.0+3.0*(v1-v2)   +3.0*(v1v1+v2v2-0.5*v0v0  ) -9.0*( 0.5*v0v1 *v0v1 +0.5*v0v2 *v0v2+(1.0-v1v2)*v1v2)-9.0*(v1v1 *v2    -v2v2 *v1+0.5*v0v0*(v1-v2))+13.5*v0v1v2*(    v0      +v0v1-v0v2     -v0v1v2))-c8* pi_xx+c6*pi_yy+c6*pi_zz -c5* pi_yz;
    f23[i]=rho*lbw[23]*(1.0+3.0*(v0+v1+v2)+3.0*(v0v0+v1v1+v2v2      ) +9.0*(v0v1*(1.0+v0v1)+v0v2*(1.0+v0v2)+v1v2*(1.0+v1v2))+9.0*(v0v0*(v1+v2)+v1v1*(v0+v2)+v2v2*(v0+v1))+27.0*v0v1v2*(1.0+v0+v1+v2+v0v1+v0v2+v1v2+v0v1v2))+c9*(pi_xx+   pi_yy+   pi_zz)+c7*(pi_xy+pi_xz+pi_yz);
    f24[i]=rho*lbw[24]*(1.0+3.0*(v0+v1-v2)+3.0*(v0v0+v1v1+v2v2      ) +9.0*(v0v1*(1.0+v0v1)-v0v2*(1.0-v0v2)-v1v2*(1.0-v1v2))+9.0*(v0v0*(v1-v2)+v1v1*(v0-v2)+v2v2*(v0+v1))-27.0*v0v1v2*(1.0+v0+v1-v2+v0v1-v0v2-v1v2-v0v1v2))+c9*(pi_xx+   pi_yy+   pi_zz)+c7*(pi_xy-pi_xz-pi_yz);
    f25[i]=rho*lbw[25]*(1.0+3.0*(v0-v1+v2)+3.0*(v0v0+v1v1+v2v2      ) -9.0*(v0v1*(1.0-v0v1)-v0v2*(1.0+v0v2)+v1v2*(1.0-v1v2))-9.0*(v0v0*(v1-v2)-v1v1*(v0+v2)-v2v2*(v0-v1))-27.0*v0v1v2*(1.0+v0-v1+v2-v0v1+v0v2-v1v2-v0v1v2))+c9*(pi_xx+   pi_yy+   pi_zz)-c7*(pi_xy-pi_xz+pi_yz);
    f26[i]=rho*lbw[26]*(1.0+3.0*(v0-v1-v2)+3.0*(v0v0+v1v1+v2v2      ) -9.0*(v0v1*(1.0-v0v1)+v0v2*(1.0-v0v2)-v1v2*(1.0+v1v2))-9.0*(v0v0*(v1+v2)-v1v1*(v0-v2)-v2v2*(v0-v1))+27.0*v0v1v2*(1.0+v0-v1-v2-v0v1-v0v2+v1v2+v0v1v2))+c9*(pi_xx+   pi_yy+   pi_zz)-c7*(pi_xy+pi_xz-pi_yz);
  }
  return 0;
}

int fD3Q27VCECLBERegular(double *p, double v0, double v1, double v2, double *force,
                         double *f0, double *f1, double *f2, double *f3, double *f4,
                         double *f5, double *f6, double *f7, double *f8, double *f9,
                         double *f10, double *f11, double *f12, double *f13, double *f14,
                         double *f15, double *f16, double *f17, double *f18, double *f19,
                         double *f20, double *f21, double *f22, double *f23, double *f24,
                         double *f25, double *f26)
{

  // produce fixed velocity for compressible fluids at concave edge boundary:
  // expressed for bottom left edge (VCETR) using higher-order equilibrium distribution functions for CLBE collisions
  
  double pi_xx, pi_yy, pi_zz, pi_xy, pi_xz, pi_yz, v0v0, v0v1, v0v2, v1v1, v1v2, v2v2, v0v1v2;
  double c1=1.0/3.0,c2=4.0/9.0,c3=2.0/9.0,c4=1.0/9.0,c5=1.0/6.0,c6=1.0/18.0,c7=1.0/24.0,c8=1.0/36.0,c9=1.0/72.0,c10=2.0/3.0,c11=4.0/3.0,c12=5.0/18.0,c13=5.0/6.0;

  v0v0 = v0*v0;
  v0v1 = v0*v1;
  v0v2 = v0*v2;
  v1v1 = v1*v1;
  v1v2 = v1*v2;
  v2v2 = v2*v2;
  v0v1v2 = v0*v1*v2;

  for(int i=0; i<lbsy.nf; i++) {
    pi_xx = -f0[i]-f3[i]-f16[i]-2.0*(f2[i]+f8[i]+f9[i])+p[i]*(c10-v1*(c10-v0v0)-v0v0)+v0*force[3*i  ];
    pi_yy = -f0[i]-f3[i]-f16[i]-2.0*(f1[i]+f6[i]+f7[i])+p[i]*(c10-v0*(c10-v1v1)-v1v1)+v1*force[3*i+1];
    pi_zz = -c1*f0[i]+c10*(f3[i]+f16[i]-f1[i]-f2[i]-f4[i])+c11*(f6[i]+f7[i]+f8[i]+f9[i]+f10[i]+f11[i])+p[i]*v2v2*(v0+v1-0.5*(v0*v1v1+v0v0*v1)-1.0)+v2*force[3*i+2];
    pi_xy = f0[i]+f3[i]+f16[i]+2.0*(f1[i]+f2[i]+f6[i]+f7[i]+f8[i]+f9[i])+4.0*(f4[i]+f10[i]+f11[i])-p[i]*(1.0-v0)*(1.0-v1)+0.5*(v1*force[3*i  ]+v0*force[3*i+1]);
    pi_xz = 2.0*(f6[i]-f7[i]+f10[i]-f11[i])+p[i]*v2*(c12-v0+c13*v0v0-c5*v1v1+0.5*v0v1*(1.0-v0v1))+0.5*(v2*force[3*i  ]+v0*force[3*i+2]);
    pi_yz = 2.0*(f8[i]-f9[i]+f10[i]-f11[i])+p[i]*v2*(c12-v1-c5*v0v0+c11*v1v1+0.5*v0v1*(1.0-v0v1))+0.5*(v2*force[3*i+1]+v1*force[3*i+2]);
    f0[i] =p[i]*lbw[0] *(1.0               -1.5*(v0v0+v1v1+v2v2      )+2.25*(     v0v1 *v0v1     +v0v2 *v0v2     +v1v2 *v1v2)                                                                         -3.375*v0v1v2*v0v1v2 )-c2*(pi_xx+   pi_yy+   pi_zz);
    f1[i] =p[i]*lbw[1] *(1.0-3.0*v0        +3.0*(v0v0-0.5*(v1v1+v2v2)) -4.5*(     v0v1 *v0v1     +v0v2 *v0v2 -0.5*v1v2 *v1v2)+4.5*(             v1v1 *v0    +v2v2* v0    )+6.75*v0v1v2*(                      -v1v2+v0v1v2))+c3* pi_xx-c4*pi_yy-c4*pi_zz;
    f2[i] =p[i]*lbw[2] *(1.0-3.0*v1        +3.0*(v1v1-0.5*(v0v0+v2v2)) -4.5*(     v0v1 *v0v1 -0.5*v0v2 *v0v2     +v1v2 *v1v2)+4.5*(v0v0 *v1                 +v2v2* v1    )+6.75*v0v1v2*(                 -v0v2     +v0v1v2))-c4* pi_xx+c3*pi_yy-c4*pi_zz;
    f3[i] =p[i]*lbw[3] *(1.0-3.0*v2        +3.0*(v2v2-0.5*(v0v0+v1v1)) -4.5*(-0.5*v0v1 *v0v1     +v0v2 *v0v2     +v1v2 *v1v2)+4.5*(v0v0 *v2    +v1v1 *v2                 )+6.75*v0v1v2*(            -v0v1          +v0v1v2))-c4* pi_xx-c4*pi_yy+c3*pi_zz;
    f4[i] =p[i]*lbw[4] *(1.0-3.0*(v0+v1)   +3.0*(v0v0+v1v1-0.5*v2v2  ) +9.0*((1.0+v0v1)*v0v1 -0.5*v0v2 *v0v2 -0.5*v1v2 *v1v2)-9.0*(v0v0 *v1    +v1v1 *v0-0.5*v2v2*(v0+v1))-13.5*v0v1v2*(          v2     -v0v2-v1v2+v0v1v2))+c6* pi_xx+c6*pi_yy-c8*pi_zz +c5* pi_xy;
    f5[i] =p[i]*lbw[5] *(1.0-3.0*(v0-v1)   +3.0*(v0v0+v1v1-0.5*v2v2  ) -9.0*((1.0-v0v1)*v0v1 +0.5*v0v2 *v0v2 +0.5*v1v2 *v1v2)+9.0*(v0v0 *v1    -v1v1 *v0+0.5*v2v2*(v0-v1))+13.5*v0v1v2*(          v2     -v0v2+v1v2-v0v1v2))+c6* pi_xx+c6*pi_yy-c8*pi_zz -c5* pi_xy;
    f6[i] =p[i]*lbw[6] *(1.0-3.0*(v0+v2)   +3.0*(v0v0+v2v2-0.5*v1v1  ) +9.0*(-0.5*v0v1 *v0v1+(1.0+v0v2)*v0v2  -0.5*v1v2*v1v2)-9.0*(v0v0 *v2    +v2v2 *v0-0.5*v1v1*(v0+v2))-13.5*v0v1v2*(       v1   -v0v1     -v1v2+v0v1v2))+c6* pi_xx-c8*pi_yy+c6*pi_zz +c5* pi_xz;
    f7[i] =p[i]*lbw[7] *(1.0-3.0*(v0-v2)   +3.0*(v0v0+v2v2-0.5*v1v1  ) -9.0*( 0.5*v0v1 *v0v1+(1.0-v0v2)*v0v2  +0.5*v1v2*v1v2)+9.0*(v0v0 *v2    -v2v2 *v0+0.5*v1v1*(v0-v2))+13.5*v0v1v2*(       v1   -v0v1     +v1v2-v0v1v2))+c6* pi_xx-c8*pi_yy+c6*pi_zz -c5* pi_xz;
    f8[i] =p[i]*lbw[8] *(1.0-3.0*(v1+v2)   +3.0*(v1v1+v2v2-0.5*v0v0  ) +9.0*(-0.5*v0v1 *v0v1 -0.5*v0v2 *v0v2+(1.0+v1v2)*v1v2)-9.0*(v1v1 *v2    +v2v2 *v1-0.5*v0v0*(v1+v2))-13.5*v0v1v2*(    v0      -v0v1-v0v2     +v0v1v2))-c8* pi_xx+c6*pi_yy+c6*pi_zz +c5* pi_yz;
    f9[i] =p[i]*lbw[9] *(1.0-3.0*(v1-v2)   +3.0*(v1v1+v2v2-0.5*v0v0  ) -9.0*( 0.5*v0v1 *v0v1 +0.5*v0v2 *v0v2+(1.0-v1v2)*v1v2)+9.0*(v1v1 *v2    -v2v2 *v1+0.5*v0v0*(v1-v2))+13.5*v0v1v2*(    v0      -v0v1+v0v2     -v0v1v2))-c8* pi_xx+c6*pi_yy+c6*pi_zz -c5* pi_yz;
    f10[i]=p[i]*lbw[10]*(1.0-3.0*(v0+v1+v2)+3.0*(v0v0+v1v1+v2v2      ) +9.0*((1.0+v0v1)*v0v1+(1.0+v0v2)*v0v2+(1.0+v1v2)*v1v2)-9.0*(v0v0*(v1+v2)+v1v1*(v0+v2)+v2v2*(v0+v1))-27.0*v0v1v2*(1.0-v0-v1-v2+v0v1+v0v2+v1v2-v0v1v2))+c9*(pi_xx+   pi_yy+   pi_zz)+c7*(pi_xy+pi_xz+pi_yz);
    f11[i]=p[i]*lbw[11]*(1.0-3.0*(v0+v1-v2)+3.0*(v0v0+v1v1+v2v2      ) +9.0*((1.0+v0v1)*v0v1-(1.0-v0v2)*v0v2-(1.0-v1v2)*v1v2)-9.0*(v0v0*(v1-v2)-v1v1*(v0+v2)+v2v2*(v0+v1))+27.0*v0v1v2*(1.0-v0-v1+v2+v0v1-v0v2-v1v2+v0v1v2))+c9*(pi_xx+   pi_yy+   pi_zz)+c7*(pi_xy-pi_xz-pi_yz);
    f12[i]=p[i]*lbw[12]*(1.0-3.0*(v0-v1+v2)+3.0*(v0v0+v1v1+v2v2      ) -9.0*((1.0-v0v1)*v0v1-(1.0+v0v2)*v0v2+(1.0-v1v2)*v1v2)+9.0*(v0v0*(v1-v2)-v1v1*(v0+v2)-v2v2*(v0-v1))+27.0*v0v1v2*(1.0-v0+v1-v2-v0v1+v0v2-v1v2+v0v1v2))+c9*(pi_xx+   pi_yy+   pi_zz)-c7*(pi_xy-pi_xz+pi_yz);
    f13[i]=p[i]*lbw[13]*(1.0-3.0*(v0-v1-v2)+3.0*(v0v0+v1v1+v2v2      ) -9.0*((1.0-v0v1)*v0v1+(1.0-v0v2)*v0v2-(1.0+v1v2)*v1v2)+9.0*(v0v0*(v1+v2)-v1v1*(v0-v2)-v2v2*(v0-v1))-27.0*v0v1v2*(1.0-v0+v1+v2-v0v1-v0v2+v1v2-v0v1v2))+c9*(pi_xx+   pi_yy+   pi_zz)-c7*(pi_xy+pi_xz-pi_yz);
    f14[i]=p[i]*lbw[14]*(1.0+3.0*v0        +3.0*(v0v0-0.5*(v1v1+v2v2)) -4.5*(     v0v1 *v0v1     +v0v2 *v0v2 -0.5*v1v2 *v1v2)-4.5*(             v1v1 *v0    +v2v2* v0    )+6.75*v0v1v2*(                       v1v2+v0v1v2))+c3* pi_xx-c4*pi_yy-c4*pi_zz;
    f15[i]=p[i]*lbw[15]*(1.0+3.0*v1        +3.0*(v1v1-0.5*(v0v0+v2v2)) -4.5*(     v0v1 *v0v1 -0.5*v0v2 *v0v2     +v1v2 *v1v2)-4.5*(v0v0 *v1                 +v2v2* v1    )+6.75*v0v1v2*(                  v0v2     +v0v1v2))-c4* pi_xx+c3*pi_yy-c4*pi_zz;
    f16[i]=p[i]*lbw[16]*(1.0+3.0*v2        +3.0*(v2v2-0.5*(v0v0+v1v1)) -4.5*(-0.5*v0v1 *v0v1     +v0v2 *v0v2     +v1v2 *v1v2)-4.5*(v0v0 *v2    +v1v1 *v2                 )+6.75*v0v1v2*(             v0v1          +v0v1v2))-c4* pi_xx-c4*pi_yy+c3*pi_zz;
    f17[i]=p[i]*lbw[17]*(1.0+3.0*(v0+v1)   +3.0*(v0v0+v1v1-0.5*v2v2  ) +9.0*((1.0+v0v1)*v0v1 -0.5*v0v2 *v0v2 -0.5*v1v2 *v1v2)+9.0*(v0v0 *v1    +v1v1 *v0-0.5*v2v2*(v0+v1))-13.5*v0v1v2*(          v2     +v0v2+v1v2+v0v1v2))+c6* pi_xx+c6*pi_yy-c8*pi_zz +c5* pi_xy;
    f18[i]=p[i]*lbw[18]*(1.0+3.0*(v0-v1)   +3.0*(v0v0+v1v1-0.5*v2v2  ) -9.0*((1.0-v0v1)*v0v1 +0.5*v0v2 *v0v2 +0.5*v1v2 *v1v2)-9.0*(v0v0 *v1    -v1v1 *v0+0.5*v2v2*(v0-v1))+13.5*v0v1v2*(          v2     +v0v2-v1v2-v0v1v2))+c6* pi_xx+c6*pi_yy-c8*pi_zz -c5* pi_xy;
    f19[i]=p[i]*lbw[19]*(1.0+3.0*(v0+v2)   +3.0*(v0v0+v2v2-0.5*v1v1  ) +9.0*(-0.5*v0v1 *v0v1+(1.0+v0v2)*v0v2  -0.5*v1v2*v1v2)+9.0*(v0v0 *v2    +v2v2 *v0-0.5*v1v1*(v0+v2))-13.5*v0v1v2*(       v1   +v0v1     +v1v2+v0v1v2))+c6* pi_xx-c8*pi_yy+c6*pi_zz +c5* pi_xz;
    f20[i]=p[i]*lbw[20]*(1.0+3.0*(v0-v2)   +3.0*(v0v0+v2v2-0.5*v1v1  ) -9.0*( 0.5*v0v1 *v0v1+(1.0-v0v2)*v0v2  +0.5*v1v2*v1v2)-9.0*(v0v0 *v2    -v2v2 *v0+0.5*v1v1*(v0-v2))+13.5*v0v1v2*(       v1   +v0v1     -v1v2-v0v1v2))+c6* pi_xx-c8*pi_yy+c6*pi_zz -c5* pi_xz;
    f21[i]=p[i]*lbw[21]*(1.0+3.0*(v1+v2)   +3.0*(v1v1+v2v2-0.5*v0v0  ) +9.0*(-0.5*v0v1 *v0v1 -0.5*v0v2 *v0v2+(1.0+v1v2)*v1v2)+9.0*(v1v1 *v2    +v2v2 *v1-0.5*v0v0*(v1+v2))-13.5*v0v1v2*(    v0      +v0v1+v0v2     +v0v1v2))-c8* pi_xx+c6*pi_yy+c6*pi_zz +c5* pi_yz;
    f22[i]=p[i]*lbw[22]*(1.0+3.0*(v1-v2)   +3.0*(v1v1+v2v2-0.5*v0v0  ) -9.0*( 0.5*v0v1 *v0v1 +0.5*v0v2 *v0v2+(1.0-v1v2)*v1v2)-9.0*(v1v1 *v2    -v2v2 *v1+0.5*v0v0*(v1-v2))+13.5*v0v1v2*(    v0      +v0v1-v0v2     -v0v1v2))-c8* pi_xx+c6*pi_yy+c6*pi_zz -c5* pi_yz;
    f23[i]=p[i]*lbw[23]*(1.0+3.0*(v0+v1+v2)+3.0*(v0v0+v1v1+v2v2      ) +9.0*(v0v1*(1.0+v0v1)+v0v2*(1.0+v0v2)+v1v2*(1.0+v1v2))+9.0*(v0v0*(v1+v2)+v1v1*(v0+v2)+v2v2*(v0+v1))+27.0*v0v1v2*(1.0+v0+v1+v2+v0v1+v0v2+v1v2+v0v1v2))+c9*(pi_xx+   pi_yy+   pi_zz)+c7*(pi_xy+pi_xz+pi_yz);
    f24[i]=p[i]*lbw[24]*(1.0+3.0*(v0+v1-v2)+3.0*(v0v0+v1v1+v2v2      ) +9.0*(v0v1*(1.0+v0v1)-v0v2*(1.0-v0v2)-v1v2*(1.0-v1v2))+9.0*(v0v0*(v1-v2)+v1v1*(v0-v2)+v2v2*(v0+v1))-27.0*v0v1v2*(1.0+v0+v1-v2+v0v1-v0v2-v1v2-v0v1v2))+c9*(pi_xx+   pi_yy+   pi_zz)+c7*(pi_xy-pi_xz-pi_yz);
    f25[i]=p[i]*lbw[25]*(1.0+3.0*(v0-v1+v2)+3.0*(v0v0+v1v1+v2v2      ) -9.0*(v0v1*(1.0-v0v1)-v0v2*(1.0+v0v2)+v1v2*(1.0-v1v2))-9.0*(v0v0*(v1-v2)-v1v1*(v0+v2)-v2v2*(v0-v1))-27.0*v0v1v2*(1.0+v0-v1+v2-v0v1+v0v2-v1v2-v0v1v2))+c9*(pi_xx+   pi_yy+   pi_zz)-c7*(pi_xy-pi_xz+pi_yz);
    f26[i]=p[i]*lbw[26]*(1.0+3.0*(v0-v1-v2)+3.0*(v0v0+v1v1+v2v2      ) -9.0*(v0v1*(1.0-v0v1)+v0v2*(1.0-v0v2)-v1v2*(1.0+v1v2))-9.0*(v0v0*(v1+v2)-v1v1*(v0-v2)-v2v2*(v0-v1))+27.0*v0v1v2*(1.0+v0-v1-v2-v0v1-v0v2+v1v2+v0v1v2))+c9*(pi_xx+   pi_yy+   pi_zz)-c7*(pi_xy+pi_xz-pi_yz);
  }
  return 0;
}

int fD3Q27VCCCLBERegular(double *p, double v0, double v1, double v2, double *force,
                         double *f0, double *f1, double *f2, double *f3, double *f4,
                         double *f5, double *f6, double *f7, double *f8, double *f9,
                         double *f10, double *f11, double *f12, double *f13, double *f14,
                         double *f15, double *f16, double *f17, double *f18, double *f19,
                         double *f20, double *f21, double *f22, double *f23, double *f24,
                         double *f25, double *f26)
{

  // produce fixed velocity for compressible fluids at concave corner boundary:
  // expressed for bottom left back corner (VCCTRF) using higher-order equilibrium distribution functions for CLBE collisions
  
  double pi_xx, pi_yy, pi_zz, pi_xy, pi_xz, pi_yz, v0v0, v0v1, v0v2, v1v1, v1v2, v2v2, v0v1v2;
  double c1=1.0/3.0,c2=4.0/9.0,c3=2.0/9.0,c4=1.0/9.0,c5=1.0/6.0,c6=1.0/18.0,c7=1.0/24.0,c8=1.0/36.0,c9=1.0/72.0,c10=11.0/15.0;
  double c11=8.0/15.0,c12=22.0/15.0,c13=5.0/27.0,c14=10.0/27.0,c15=2.0/3.0,c16=8.0/3.0,c17=7.0/27.0,c18=13.0/18.0,c19=1.0/15.0,c20=13.0/30.0;
  double c21=5.0/18.0,c22=1.0/12.0,c23=5.0/12.0;

  v0v0 = v0*v0;
  v0v1 = v0*v1;
  v0v2 = v0*v2;
  v1v1 = v1*v1;
  v1v2 = v1*v2;
  v2v2 = v2*v2;
  v0v1v2 = v0*v1*v2;

  for(int i=0; i<lbsy.nf; i++) {
    pi_xx = -c10*f0[i]+c11*(f1[i]+f4[i]+f6[i]+f10[i])-c12*(f2[i]+f3[i]+f8[i])+p[i]*(0.4+v0*(c13-c4*(v1v1+v2v2))-v1*(c14-c18*v0v0-c3*v2v2)-v2*(c14-c18*v0v0-c3*v1v1)+v0v1v2*(c19*(1.0+v1v2)-c20*(v0v1+v0v2))-v0v0)+v0*force[3*i  ];
    pi_yy = -c10*f0[i]+c11*(f2[i]+f4[i]+f8[i]+f10[i])-c12*(f1[i]+f3[i]+f6[i])+p[i]*(0.4+v1*(c13-c4*(v0v0+v2v2))-v0*(c14-c18*v1v1-c3*v2v2)-v2*(c14-c3*v0v0-c18*v1v1)+v0v1v2*(c19*(1.0+v0v2)-c20*(v0v1+v1v2))-v1v1)+v1*force[3*i+1];
    pi_zz = -c10*f0[i]+c11*(f3[i]+f6[i]+f8[i]+f10[i])-c12*(f1[i]+f2[i]+f4[i])+p[i]*(0.4+v2*(c13-c4*(v0v0+v1v1))-v0*(c14-c3*v1v1-c18*v2v2)-v1*(c14-c3*v0v0-c18*v1v1)+v0v1v2*(c19*(1.0+v0v1)-c20*(v0v2+v1v2))-v2v2)+v2*force[3*i+2];
    pi_xy = c1*f0[i]+c15*(f1[i]+f2[i]+f3[i]+f6[i]+f8[i])+c16*(f4[i]+f10[i])-p[i]*(c1-v0*(c14+c21*v1v1-c3*v2v2)-v1*(c14+c21*v0v0-c3*v2v2)-v2*(c17-c6*(v0v0+v1v1))-v0v1v2*(c23*(1.0+v0v1)-c22*(v0v2+v1v2))+v0v1)+0.5*(v1*force[3*i  ]+v0*force[3*i+1]);
    pi_xz = c1*f0[i]+c15*(f1[i]+f2[i]+f3[i]+f4[i]+f8[i])+c16*(f6[i]+f10[i])-p[i]*(c1-v0*(c14-c3*v1v1+c21*v2v2)-v2*(c14+c21*v0v0-c3*v1v1)-v1*(c17-c6*(v0v0+v2v2))-v0v1v2*(c23*(1.0+v0v2)-c22*(v0v1+v1v2))+v0v2)+0.5*(v2*force[3*i  ]+v0*force[3*i+2]);
    pi_yz = c1*f0[i]+c15*(f1[i]+f2[i]+f3[i]+f4[i]+f6[i])+c16*(f8[i]+f10[i])-p[i]*(c1-v1*(c14-c3*v0v0+c21*v2v2)-v2*(c14-c3*v0v0+c21*v1v1)-v0*(c17-c6*(v1v1+v2v2))-v0v1v2*(c23*(1.0+v1v2)-c22*(v0v1+v0v2))+v1v2)+0.5*(v2*force[3*i+1]+v1*force[3*i+2]);
    f0[i] =p[i]*lbw[0] *(1.0               -1.5*(v0v0+v1v1+v2v2      )+2.25*(     v0v1 *v0v1     +v0v2 *v0v2     +v1v2 *v1v2)                                                                         -3.375*v0v1v2*v0v1v2 )-c2*(pi_xx+   pi_yy+   pi_zz);
    f1[i] =p[i]*lbw[1] *(1.0-3.0*v0        +3.0*(v0v0-0.5*(v1v1+v2v2)) -4.5*(     v0v1 *v0v1     +v0v2 *v0v2 -0.5*v1v2 *v1v2)+4.5*(             v1v1 *v0    +v2v2* v0    )+6.75*v0v1v2*(                      -v1v2+v0v1v2))+c3* pi_xx-c4*pi_yy-c4*pi_zz;
    f2[i] =p[i]*lbw[2] *(1.0-3.0*v1        +3.0*(v1v1-0.5*(v0v0+v2v2)) -4.5*(     v0v1 *v0v1 -0.5*v0v2 *v0v2     +v1v2 *v1v2)+4.5*(v0v0 *v1                 +v2v2* v1    )+6.75*v0v1v2*(                 -v0v2     +v0v1v2))-c4* pi_xx+c3*pi_yy-c4*pi_zz;
    f3[i] =p[i]*lbw[3] *(1.0-3.0*v2        +3.0*(v2v2-0.5*(v0v0+v1v1)) -4.5*(-0.5*v0v1 *v0v1     +v0v2 *v0v2     +v1v2 *v1v2)+4.5*(v0v0 *v2    +v1v1 *v2                 )+6.75*v0v1v2*(            -v0v1          +v0v1v2))-c4* pi_xx-c4*pi_yy+c3*pi_zz;
    f4[i] =p[i]*lbw[4] *(1.0-3.0*(v0+v1)   +3.0*(v0v0+v1v1-0.5*v2v2  ) +9.0*((1.0+v0v1)*v0v1 -0.5*v0v2 *v0v2 -0.5*v1v2 *v1v2)-9.0*(v0v0 *v1    +v1v1 *v0-0.5*v2v2*(v0+v1))-13.5*v0v1v2*(          v2     -v0v2-v1v2+v0v1v2))+c6* pi_xx+c6*pi_yy-c8*pi_zz +c5* pi_xy;
    f5[i] =p[i]*lbw[5] *(1.0-3.0*(v0-v1)   +3.0*(v0v0+v1v1-0.5*v2v2  ) -9.0*((1.0-v0v1)*v0v1 +0.5*v0v2 *v0v2 +0.5*v1v2 *v1v2)+9.0*(v0v0 *v1    -v1v1 *v0+0.5*v2v2*(v0-v1))+13.5*v0v1v2*(          v2     -v0v2+v1v2-v0v1v2))+c6* pi_xx+c6*pi_yy-c8*pi_zz -c5* pi_xy;
    f6[i] =p[i]*lbw[6] *(1.0-3.0*(v0+v2)   +3.0*(v0v0+v2v2-0.5*v1v1  ) +9.0*(-0.5*v0v1 *v0v1+(1.0+v0v2)*v0v2  -0.5*v1v2*v1v2)-9.0*(v0v0 *v2    +v2v2 *v0-0.5*v1v1*(v0+v2))-13.5*v0v1v2*(       v1   -v0v1     -v1v2+v0v1v2))+c6* pi_xx-c8*pi_yy+c6*pi_zz +c5* pi_xz;
    f7[i] =p[i]*lbw[7] *(1.0-3.0*(v0-v2)   +3.0*(v0v0+v2v2-0.5*v1v1  ) -9.0*( 0.5*v0v1 *v0v1+(1.0-v0v2)*v0v2  +0.5*v1v2*v1v2)+9.0*(v0v0 *v2    -v2v2 *v0+0.5*v1v1*(v0-v2))+13.5*v0v1v2*(       v1   -v0v1     +v1v2-v0v1v2))+c6* pi_xx-c8*pi_yy+c6*pi_zz -c5* pi_xz;
    f8[i] =p[i]*lbw[8] *(1.0-3.0*(v1+v2)   +3.0*(v1v1+v2v2-0.5*v0v0  ) +9.0*(-0.5*v0v1 *v0v1 -0.5*v0v2 *v0v2+(1.0+v1v2)*v1v2)-9.0*(v1v1 *v2    +v2v2 *v1-0.5*v0v0*(v1+v2))-13.5*v0v1v2*(    v0      -v0v1-v0v2     +v0v1v2))-c8* pi_xx+c6*pi_yy+c6*pi_zz +c5* pi_yz;
    f9[i] =p[i]*lbw[9] *(1.0-3.0*(v1-v2)   +3.0*(v1v1+v2v2-0.5*v0v0  ) -9.0*( 0.5*v0v1 *v0v1 +0.5*v0v2 *v0v2+(1.0-v1v2)*v1v2)+9.0*(v1v1 *v2    -v2v2 *v1+0.5*v0v0*(v1-v2))+13.5*v0v1v2*(    v0      -v0v1+v0v2     -v0v1v2))-c8* pi_xx+c6*pi_yy+c6*pi_zz -c5* pi_yz;
    f10[i]=p[i]*lbw[10]*(1.0-3.0*(v0+v1+v2)+3.0*(v0v0+v1v1+v2v2      ) +9.0*((1.0+v0v1)*v0v1+(1.0+v0v2)*v0v2+(1.0+v1v2)*v1v2)-9.0*(v0v0*(v1+v2)+v1v1*(v0+v2)+v2v2*(v0+v1))-27.0*v0v1v2*(1.0-v0-v1-v2+v0v1+v0v2+v1v2-v0v1v2))+c9*(pi_xx+   pi_yy+   pi_zz)+c7*(pi_xy+pi_xz+pi_yz);
    f11[i]=p[i]*lbw[11]*(1.0-3.0*(v0+v1-v2)+3.0*(v0v0+v1v1+v2v2      ) +9.0*((1.0+v0v1)*v0v1-(1.0-v0v2)*v0v2-(1.0-v1v2)*v1v2)-9.0*(v0v0*(v1-v2)-v1v1*(v0+v2)+v2v2*(v0+v1))+27.0*v0v1v2*(1.0-v0-v1+v2+v0v1-v0v2-v1v2+v0v1v2))+c9*(pi_xx+   pi_yy+   pi_zz)+c7*(pi_xy-pi_xz-pi_yz);
    f12[i]=p[i]*lbw[12]*(1.0-3.0*(v0-v1+v2)+3.0*(v0v0+v1v1+v2v2      ) -9.0*((1.0-v0v1)*v0v1-(1.0+v0v2)*v0v2+(1.0-v1v2)*v1v2)+9.0*(v0v0*(v1-v2)-v1v1*(v0+v2)-v2v2*(v0-v1))+27.0*v0v1v2*(1.0-v0+v1-v2-v0v1+v0v2-v1v2+v0v1v2))+c9*(pi_xx+   pi_yy+   pi_zz)-c7*(pi_xy-pi_xz+pi_yz);
    f13[i]=p[i]*lbw[13]*(1.0-3.0*(v0-v1-v2)+3.0*(v0v0+v1v1+v2v2      ) -9.0*((1.0-v0v1)*v0v1+(1.0-v0v2)*v0v2-(1.0+v1v2)*v1v2)+9.0*(v0v0*(v1+v2)-v1v1*(v0-v2)-v2v2*(v0-v1))-27.0*v0v1v2*(1.0-v0+v1+v2-v0v1-v0v2+v1v2-v0v1v2))+c9*(pi_xx+   pi_yy+   pi_zz)-c7*(pi_xy+pi_xz-pi_yz);
    f14[i]=p[i]*lbw[14]*(1.0+3.0*v0        +3.0*(v0v0-0.5*(v1v1+v2v2)) -4.5*(     v0v1 *v0v1     +v0v2 *v0v2 -0.5*v1v2 *v1v2)-4.5*(             v1v1 *v0    +v2v2* v0    )+6.75*v0v1v2*(                       v1v2+v0v1v2))+c3* pi_xx-c4*pi_yy-c4*pi_zz;
    f15[i]=p[i]*lbw[15]*(1.0+3.0*v1        +3.0*(v1v1-0.5*(v0v0+v2v2)) -4.5*(     v0v1 *v0v1 -0.5*v0v2 *v0v2     +v1v2 *v1v2)-4.5*(v0v0 *v1                 +v2v2* v1    )+6.75*v0v1v2*(                  v0v2     +v0v1v2))-c4* pi_xx+c3*pi_yy-c4*pi_zz;
    f16[i]=p[i]*lbw[16]*(1.0+3.0*v2        +3.0*(v2v2-0.5*(v0v0+v1v1)) -4.5*(-0.5*v0v1 *v0v1     +v0v2 *v0v2     +v1v2 *v1v2)-4.5*(v0v0 *v2    +v1v1 *v2                 )+6.75*v0v1v2*(             v0v1          +v0v1v2))-c4* pi_xx-c4*pi_yy+c3*pi_zz;
    f17[i]=p[i]*lbw[17]*(1.0+3.0*(v0+v1)   +3.0*(v0v0+v1v1-0.5*v2v2  ) +9.0*((1.0+v0v1)*v0v1 -0.5*v0v2 *v0v2 -0.5*v1v2 *v1v2)+9.0*(v0v0 *v1    +v1v1 *v0-0.5*v2v2*(v0+v1))-13.5*v0v1v2*(          v2     +v0v2+v1v2+v0v1v2))+c6* pi_xx+c6*pi_yy-c8*pi_zz +c5* pi_xy;
    f18[i]=p[i]*lbw[18]*(1.0+3.0*(v0-v1)   +3.0*(v0v0+v1v1-0.5*v2v2  ) -9.0*((1.0-v0v1)*v0v1 +0.5*v0v2 *v0v2 +0.5*v1v2 *v1v2)-9.0*(v0v0 *v1    -v1v1 *v0+0.5*v2v2*(v0-v1))+13.5*v0v1v2*(          v2     +v0v2-v1v2-v0v1v2))+c6* pi_xx+c6*pi_yy-c8*pi_zz -c5* pi_xy;
    f19[i]=p[i]*lbw[19]*(1.0+3.0*(v0+v2)   +3.0*(v0v0+v2v2-0.5*v1v1  ) +9.0*(-0.5*v0v1 *v0v1+(1.0+v0v2)*v0v2  -0.5*v1v2*v1v2)+9.0*(v0v0 *v2    +v2v2 *v0-0.5*v1v1*(v0+v2))-13.5*v0v1v2*(       v1   +v0v1     +v1v2+v0v1v2))+c6* pi_xx-c8*pi_yy+c6*pi_zz +c5* pi_xz;
    f20[i]=p[i]*lbw[20]*(1.0+3.0*(v0-v2)   +3.0*(v0v0+v2v2-0.5*v1v1  ) -9.0*( 0.5*v0v1 *v0v1+(1.0-v0v2)*v0v2  +0.5*v1v2*v1v2)-9.0*(v0v0 *v2    -v2v2 *v0+0.5*v1v1*(v0-v2))+13.5*v0v1v2*(       v1   +v0v1     -v1v2-v0v1v2))+c6* pi_xx-c8*pi_yy+c6*pi_zz -c5* pi_xz;
    f21[i]=p[i]*lbw[21]*(1.0+3.0*(v1+v2)   +3.0*(v1v1+v2v2-0.5*v0v0  ) +9.0*(-0.5*v0v1 *v0v1 -0.5*v0v2 *v0v2+(1.0+v1v2)*v1v2)+9.0*(v1v1 *v2    +v2v2 *v1-0.5*v0v0*(v1+v2))-13.5*v0v1v2*(    v0      +v0v1+v0v2     +v0v1v2))-c8* pi_xx+c6*pi_yy+c6*pi_zz +c5* pi_yz;
    f22[i]=p[i]*lbw[22]*(1.0+3.0*(v1-v2)   +3.0*(v1v1+v2v2-0.5*v0v0  ) -9.0*( 0.5*v0v1 *v0v1 +0.5*v0v2 *v0v2+(1.0-v1v2)*v1v2)-9.0*(v1v1 *v2    -v2v2 *v1+0.5*v0v0*(v1-v2))+13.5*v0v1v2*(    v0      +v0v1-v0v2     -v0v1v2))-c8* pi_xx+c6*pi_yy+c6*pi_zz -c5* pi_yz;
    f23[i]=p[i]*lbw[23]*(1.0+3.0*(v0+v1+v2)+3.0*(v0v0+v1v1+v2v2      ) +9.0*(v0v1*(1.0+v0v1)+v0v2*(1.0+v0v2)+v1v2*(1.0+v1v2))+9.0*(v0v0*(v1+v2)+v1v1*(v0+v2)+v2v2*(v0+v1))+27.0*v0v1v2*(1.0+v0+v1+v2+v0v1+v0v2+v1v2+v0v1v2))+c9*(pi_xx+   pi_yy+   pi_zz)+c7*(pi_xy+pi_xz+pi_yz);
    f24[i]=p[i]*lbw[24]*(1.0+3.0*(v0+v1-v2)+3.0*(v0v0+v1v1+v2v2      ) +9.0*(v0v1*(1.0+v0v1)-v0v2*(1.0-v0v2)-v1v2*(1.0-v1v2))+9.0*(v0v0*(v1-v2)+v1v1*(v0-v2)+v2v2*(v0+v1))-27.0*v0v1v2*(1.0+v0+v1-v2+v0v1-v0v2-v1v2-v0v1v2))+c9*(pi_xx+   pi_yy+   pi_zz)+c7*(pi_xy-pi_xz-pi_yz);
    f25[i]=p[i]*lbw[25]*(1.0+3.0*(v0-v1+v2)+3.0*(v0v0+v1v1+v2v2      ) -9.0*(v0v1*(1.0-v0v1)-v0v2*(1.0+v0v2)+v1v2*(1.0-v1v2))-9.0*(v0v0*(v1-v2)-v1v1*(v0+v2)-v2v2*(v0-v1))-27.0*v0v1v2*(1.0+v0-v1+v2-v0v1+v0v2-v1v2-v0v1v2))+c9*(pi_xx+   pi_yy+   pi_zz)-c7*(pi_xy-pi_xz+pi_yz);
    f26[i]=p[i]*lbw[26]*(1.0+3.0*(v0-v1-v2)+3.0*(v0v0+v1v1+v2v2      ) -9.0*(v0v1*(1.0-v0v1)+v0v2*(1.0-v0v2)-v1v2*(1.0+v1v2))-9.0*(v0v0*(v1+v2)-v1v1*(v0-v2)-v2v2*(v0-v1))+27.0*v0v1v2*(1.0+v0-v1-v2-v0v1-v0v2+v1v2+v0v1v2))+c9*(pi_xx+   pi_yy+   pi_zz)-c7*(pi_xy+pi_xz-pi_yz);
  }
  return 0;
}

int fD3Q27VFRegular(long tpos, long rpos, int prop, double *uwall)
{
  long spos=tpos * lbsitelength;
  int qdim=lbsy.nf+lbsy.nc+lbsy.nt;
  double force[3*lbsy.nf], rho[lbsy.nf];

  fD3Q27BoundaryForceVelocity(force, tpos, rpos, uwall, prop);

  if(prop>26)
    fGetAllMassSite(rho, &lbf[rpos*lbsitelength]);

  if(collide>11) {
    switch (prop) {
      case PST:
        fD3Q27VPSCLBERegular(uwall[0], uwall[1], uwall[2], &force[0], &lbf[spos], &lbf[spos+1*qdim],
                             &lbf[spos+2*qdim], &lbf[spos+3*qdim], &lbf[spos+4*qdim], &lbf[spos+5*qdim],
                             &lbf[spos+6*qdim], &lbf[spos+7*qdim], &lbf[spos+8*qdim], &lbf[spos+9*qdim],
                             &lbf[spos+10*qdim], &lbf[spos+11*qdim], &lbf[spos+12*qdim], &lbf[spos+13*qdim],
                             &lbf[spos+14*qdim], &lbf[spos+15*qdim], &lbf[spos+16*qdim], &lbf[spos+17*qdim],
                             &lbf[spos+18*qdim], &lbf[spos+19*qdim], &lbf[spos+20*qdim], &lbf[spos+21*qdim],
                             &lbf[spos+22*qdim], &lbf[spos+23*qdim], &lbf[spos+24*qdim], &lbf[spos+25*qdim],
                             &lbf[spos+26*qdim]);
        break;
      case PSD:
        fD3Q27VPSCLBERegular(-uwall[0], -uwall[1], -uwall[2], &force[0], &lbf[spos], &lbf[spos+14*qdim],
                             &lbf[spos+15*qdim], &lbf[spos+16*qdim], &lbf[spos+17*qdim], &lbf[spos+18*qdim],
                             &lbf[spos+19*qdim], &lbf[spos+20*qdim], &lbf[spos+21*qdim], &lbf[spos+22*qdim],
                             &lbf[spos+23*qdim], &lbf[spos+24*qdim], &lbf[spos+25*qdim], &lbf[spos+26*qdim],
                             &lbf[spos+1*qdim], &lbf[spos+2*qdim], &lbf[spos+3*qdim], &lbf[spos+4*qdim],
                             &lbf[spos+5*qdim], &lbf[spos+6*qdim], &lbf[spos+7*qdim], &lbf[spos+8*qdim],
                             &lbf[spos+9*qdim], &lbf[spos+10*qdim], &lbf[spos+11*qdim], &lbf[spos+12*qdim],
                             &lbf[spos+13*qdim]);
        break;
      case PSL:
        fD3Q27VPSCLBERegular(-uwall[2], -uwall[0], -uwall[1], &force[0], &lbf[spos], &lbf[spos+16*qdim],
                             &lbf[spos+14*qdim], &lbf[spos+15*qdim], &lbf[spos+19*qdim], &lbf[spos+7*qdim],
                             &lbf[spos+21*qdim], &lbf[spos+9*qdim], &lbf[spos+17*qdim], &lbf[spos+18*qdim],
                             &lbf[spos+23*qdim], &lbf[spos+25*qdim], &lbf[spos+13*qdim], &lbf[spos+11*qdim],
                             &lbf[spos+3*qdim], &lbf[spos+1*qdim], &lbf[spos+2*qdim], &lbf[spos+6*qdim],
                             &lbf[spos+20*qdim], &lbf[spos+8*qdim], &lbf[spos+22*qdim], &lbf[spos+4*qdim],
                             &lbf[spos+5*qdim], &lbf[spos+10*qdim], &lbf[spos+12*qdim], &lbf[spos+26*qdim],
                             &lbf[spos+24*qdim]);
        break;
      case PSR:
        fD3Q27VPSCLBERegular(uwall[2], uwall[0], uwall[1], &force[0], &lbf[spos], &lbf[spos+3*qdim],
                             &lbf[spos+1*qdim], &lbf[spos+2*qdim], &lbf[spos+6*qdim], &lbf[spos+20*qdim],
                             &lbf[spos+8*qdim], &lbf[spos+22*qdim], &lbf[spos+4*qdim], &lbf[spos+5*qdim],
                             &lbf[spos+10*qdim], &lbf[spos+12*qdim], &lbf[spos+26*qdim], &lbf[spos+24*qdim],
                             &lbf[spos+16*qdim], &lbf[spos+14*qdim], &lbf[spos+15*qdim], &lbf[spos+19*qdim],
                             &lbf[spos+7*qdim], &lbf[spos+21*qdim], &lbf[spos+9*qdim], &lbf[spos+17*qdim],
                             &lbf[spos+18*qdim], &lbf[spos+23*qdim], &lbf[spos+25*qdim], &lbf[spos+13*qdim],
                             &lbf[spos+11*qdim]);
        break;
      case PSF:
        fD3Q27VPSCLBERegular(-uwall[1], -uwall[2], -uwall[0], &force[0], &lbf[spos], &lbf[spos+15*qdim],
                             &lbf[spos+16*qdim], &lbf[spos+14*qdim], &lbf[spos+21*qdim], &lbf[spos+22*qdim],
                             &lbf[spos+17*qdim], &lbf[spos+5*qdim], &lbf[spos+19*qdim], &lbf[spos+7*qdim],
                             &lbf[spos+23*qdim], &lbf[spos+13*qdim], &lbf[spos+24*qdim], &lbf[spos+12*qdim],
                             &lbf[spos+2*qdim], &lbf[spos+3*qdim], &lbf[spos+1*qdim], &lbf[spos+8*qdim],
                             &lbf[spos+9*qdim], &lbf[spos+4*qdim], &lbf[spos+18*qdim], &lbf[spos+6*qdim],
                             &lbf[spos+20*qdim], &lbf[spos+10*qdim], &lbf[spos+26*qdim], &lbf[spos+11*qdim],
                             &lbf[spos+25*qdim]);
        break;
      case PSB:
        fD3Q27VPSCLBERegular(uwall[1], uwall[2], uwall[0], &force[0], &lbf[spos], &lbf[spos+2*qdim],
                             &lbf[spos+3*qdim], &lbf[spos+1*qdim], &lbf[spos+8*qdim], &lbf[spos+9*qdim],
                             &lbf[spos+4*qdim], &lbf[spos+18*qdim], &lbf[spos+6*qdim], &lbf[spos+20*qdim],
                             &lbf[spos+10*qdim], &lbf[spos+26*qdim], &lbf[spos+11*qdim], &lbf[spos+25*qdim],
                             &lbf[spos+15*qdim], &lbf[spos+16*qdim], &lbf[spos+14*qdim], &lbf[spos+21*qdim],
                             &lbf[spos+22*qdim], &lbf[spos+17*qdim], &lbf[spos+5*qdim], &lbf[spos+19*qdim],
                             &lbf[spos+7*qdim], &lbf[spos+23*qdim], &lbf[spos+13*qdim], &lbf[spos+24*qdim],
                             &lbf[spos+12*qdim]);
        break;
      case CCTRB:
        fD3Q27VCCCLBERegular(rho, uwall[0], uwall[1], -uwall[2], &force[0], &lbf[spos], &lbf[spos+1*qdim],
                             &lbf[spos+2*qdim], &lbf[spos+16*qdim], &lbf[spos+4*qdim], &lbf[spos+5*qdim],
                             &lbf[spos+7*qdim], &lbf[spos+6*qdim], &lbf[spos+9*qdim], &lbf[spos+8*qdim],
                             &lbf[spos+11*qdim], &lbf[spos+10*qdim], &lbf[spos+13*qdim], &lbf[spos+12*qdim],
                             &lbf[spos+14*qdim], &lbf[spos+15*qdim], &lbf[spos+3*qdim], &lbf[spos+17*qdim],
                             &lbf[spos+18*qdim], &lbf[spos+20*qdim], &lbf[spos+19*qdim], &lbf[spos+22*qdim],
                             &lbf[spos+21*qdim], &lbf[spos+24*qdim], &lbf[spos+23*qdim], &lbf[spos+26*qdim],
                             &lbf[spos+25*qdim]);
        break;
      case CCTLB:
        fD3Q27VCCCLBERegular(rho, -uwall[0], uwall[1], -uwall[2], &force[0], &lbf[spos], &lbf[spos+14*qdim],
                             &lbf[spos+2*qdim], &lbf[spos+16*qdim], &lbf[spos+18*qdim], &lbf[spos+17*qdim],
                             &lbf[spos+19*qdim], &lbf[spos+20*qdim], &lbf[spos+9*qdim], &lbf[spos+8*qdim],
                             &lbf[spos+25*qdim], &lbf[spos+26*qdim], &lbf[spos+23*qdim], &lbf[spos+24*qdim],
                             &lbf[spos+1*qdim], &lbf[spos+15*qdim], &lbf[spos+3*qdim], &lbf[spos+5*qdim],
                             &lbf[spos+4*qdim], &lbf[spos+6*qdim], &lbf[spos+7*qdim], &lbf[spos+22*qdim],
                             &lbf[spos+21*qdim], &lbf[spos+12*qdim], &lbf[spos+13*qdim], &lbf[spos+10*qdim],
                             &lbf[spos+11*qdim]);
        break;
      case CCDLB:
        fD3Q27VCCCLBERegular(rho, -uwall[0], -uwall[1], -uwall[2], &force[0], &lbf[spos], &lbf[spos+14*qdim],
                             &lbf[spos+15*qdim], &lbf[spos+16*qdim], &lbf[spos+17*qdim], &lbf[spos+18*qdim],
                             &lbf[spos+19*qdim], &lbf[spos+20*qdim], &lbf[spos+21*qdim], &lbf[spos+22*qdim],
                             &lbf[spos+23*qdim], &lbf[spos+24*qdim], &lbf[spos+25*qdim], &lbf[spos+26*qdim],
                             &lbf[spos+1*qdim], &lbf[spos+2*qdim], &lbf[spos+3*qdim], &lbf[spos+4*qdim],
                             &lbf[spos+5*qdim], &lbf[spos+6*qdim], &lbf[spos+7*qdim], &lbf[spos+8*qdim],
                             &lbf[spos+9*qdim], &lbf[spos+10*qdim], &lbf[spos+11*qdim], &lbf[spos+12*qdim],
                             &lbf[spos+13*qdim]);
        break;
      case CCDRB:
        fD3Q27VCCCLBERegular(rho, uwall[0], -uwall[1], -uwall[2], &force[0], &lbf[spos], &lbf[spos+1*qdim],
                             &lbf[spos+15*qdim], &lbf[spos+16*qdim], &lbf[spos+5*qdim], &lbf[spos+4*qdim],
                             &lbf[spos+7*qdim], &lbf[spos+6*qdim], &lbf[spos+21*qdim], &lbf[spos+22*qdim],
                             &lbf[spos+13*qdim], &lbf[spos+12*qdim], &lbf[spos+11*qdim], &lbf[spos+10*qdim],
                             &lbf[spos+14*qdim], &lbf[spos+2*qdim], &lbf[spos+3*qdim], &lbf[spos+18*qdim],
                             &lbf[spos+17*qdim], &lbf[spos+20*qdim], &lbf[spos+19*qdim], &lbf[spos+8*qdim],
                             &lbf[spos+9*qdim], &lbf[spos+26*qdim], &lbf[spos+25*qdim], &lbf[spos+24*qdim],
                             &lbf[spos+23*qdim]);
        break;
      case CCTRF:
        fD3Q27VCCCLBERegular(rho, uwall[0], uwall[1], uwall[2], &force[0], &lbf[spos], &lbf[spos+1*qdim],
                             &lbf[spos+2*qdim], &lbf[spos+3*qdim], &lbf[spos+4*qdim], &lbf[spos+5*qdim],
                             &lbf[spos+6*qdim], &lbf[spos+7*qdim], &lbf[spos+8*qdim], &lbf[spos+9*qdim],
                             &lbf[spos+10*qdim], &lbf[spos+11*qdim], &lbf[spos+12*qdim], &lbf[spos+13*qdim],
                             &lbf[spos+14*qdim], &lbf[spos+15*qdim], &lbf[spos+16*qdim], &lbf[spos+17*qdim],
                             &lbf[spos+18*qdim], &lbf[spos+19*qdim], &lbf[spos+20*qdim], &lbf[spos+21*qdim],
                             &lbf[spos+22*qdim], &lbf[spos+23*qdim], &lbf[spos+24*qdim], &lbf[spos+25*qdim],
                             &lbf[spos+26*qdim]);
        break;
      case CCTLF:
        fD3Q27VCCCLBERegular(rho, -uwall[0], uwall[1], uwall[2], &force[0], &lbf[spos], &lbf[spos+14*qdim],
                             &lbf[spos+2*qdim], &lbf[spos+3*qdim], &lbf[spos+18*qdim], &lbf[spos+17*qdim],
                             &lbf[spos+20*qdim], &lbf[spos+19*qdim], &lbf[spos+8*qdim], &lbf[spos+9*qdim],
                             &lbf[spos+26*qdim], &lbf[spos+25*qdim], &lbf[spos+24*qdim], &lbf[spos+23*qdim],
                             &lbf[spos+1*qdim], &lbf[spos+15*qdim], &lbf[spos+16*qdim], &lbf[spos+5*qdim],
                             &lbf[spos+4*qdim], &lbf[spos+7*qdim], &lbf[spos+6*qdim], &lbf[spos+21*qdim],
                             &lbf[spos+22*qdim], &lbf[spos+13*qdim], &lbf[spos+12*qdim], &lbf[spos+11*qdim],
                             &lbf[spos+10*qdim]);
        break;
      case CCDLF:
        fD3Q27VCCCLBERegular(rho, -uwall[0], -uwall[1], uwall[2], &force[0], &lbf[spos], &lbf[spos+14*qdim],
                             &lbf[spos+15*qdim], &lbf[spos+3*qdim], &lbf[spos+17*qdim], &lbf[spos+18*qdim],
                             &lbf[spos+20*qdim], &lbf[spos+19*qdim], &lbf[spos+22*qdim], &lbf[spos+21*qdim],
                             &lbf[spos+24*qdim], &lbf[spos+23*qdim], &lbf[spos+26*qdim], &lbf[spos+25*qdim],
                             &lbf[spos+1*qdim], &lbf[spos+2*qdim], &lbf[spos+16*qdim], &lbf[spos+4*qdim],
                             &lbf[spos+5*qdim], &lbf[spos+7*qdim], &lbf[spos+6*qdim], &lbf[spos+9*qdim],
                             &lbf[spos+8*qdim], &lbf[spos+11*qdim], &lbf[spos+10*qdim], &lbf[spos+13*qdim],
                             &lbf[spos+12*qdim]);
        break;
      case CCDRF:
        fD3Q27VCCCLBERegular(rho, uwall[0], -uwall[1], uwall[2], &force[0], &lbf[spos], &lbf[spos+1*qdim],
                             &lbf[spos+15*qdim], &lbf[spos+3*qdim], &lbf[spos+5*qdim], &lbf[spos+4*qdim],
                             &lbf[spos+6*qdim], &lbf[spos+7*qdim], &lbf[spos+22*qdim], &lbf[spos+21*qdim],
                             &lbf[spos+12*qdim], &lbf[spos+13*qdim], &lbf[spos+10*qdim], &lbf[spos+11*qdim],
                             &lbf[spos+14*qdim], &lbf[spos+2*qdim], &lbf[spos+16*qdim], &lbf[spos+18*qdim],
                             &lbf[spos+17*qdim], &lbf[spos+19*qdim], &lbf[spos+20*qdim], &lbf[spos+9*qdim],
                             &lbf[spos+8*qdim], &lbf[spos+25*qdim], &lbf[spos+26*qdim], &lbf[spos+23*qdim],
                             &lbf[spos+24*qdim]);
        break;
      case CETR:
        fD3Q27VCECLBERegular(rho, uwall[0], uwall[1], uwall[2], &force[0], &lbf[spos], &lbf[spos+1*qdim],
                             &lbf[spos+2*qdim], &lbf[spos+3*qdim], &lbf[spos+4*qdim], &lbf[spos+5*qdim],
                             &lbf[spos+6*qdim], &lbf[spos+7*qdim], &lbf[spos+8*qdim], &lbf[spos+9*qdim],
                             &lbf[spos+10*qdim], &lbf[spos+11*qdim], &lbf[spos+12*qdim], &lbf[spos+13*qdim],
                             &lbf[spos+14*qdim], &lbf[spos+15*qdim], &lbf[spos+16*qdim], &lbf[spos+17*qdim],
                             &lbf[spos+18*qdim], &lbf[spos+19*qdim], &lbf[spos+20*qdim], &lbf[spos+21*qdim],
                             &lbf[spos+22*qdim], &lbf[spos+23*qdim], &lbf[spos+24*qdim], &lbf[spos+25*qdim],
                             &lbf[spos+26*qdim]);
        break;
      case CETL:
        fD3Q27VCECLBERegular(rho, uwall[1], -uwall[0], uwall[2], &force[0], &lbf[spos], &lbf[spos+2*qdim],
                             &lbf[spos+14*qdim], &lbf[spos+3*qdim], &lbf[spos+18*qdim], &lbf[spos+4*qdim],
                             &lbf[spos+8*qdim], &lbf[spos+9*qdim], &lbf[spos+20*qdim], &lbf[spos+19*qdim],
                             &lbf[spos+26*qdim], &lbf[spos+25*qdim], &lbf[spos+10*qdim], &lbf[spos+11*qdim],
                             &lbf[spos+15*qdim], &lbf[spos+1*qdim], &lbf[spos+16*qdim], &lbf[spos+5*qdim],
                             &lbf[spos+17*qdim], &lbf[spos+21*qdim], &lbf[spos+22*qdim], &lbf[spos+7*qdim],
                             &lbf[spos+6*qdim], &lbf[spos+13*qdim], &lbf[spos+12*qdim], &lbf[spos+23*qdim],
                             &lbf[spos+24*qdim]);
        break;
      case CEDL:
        fD3Q27VCECLBERegular(rho, -uwall[0], -uwall[1], uwall[2], &force[0], &lbf[spos], &lbf[spos+14*qdim],
                             &lbf[spos+15*qdim], &lbf[spos+3*qdim], &lbf[spos+17*qdim], &lbf[spos+18*qdim],
                             &lbf[spos+20*qdim], &lbf[spos+19*qdim], &lbf[spos+22*qdim], &lbf[spos+21*qdim],
                             &lbf[spos+24*qdim], &lbf[spos+23*qdim], &lbf[spos+26*qdim], &lbf[spos+25*qdim],
                             &lbf[spos+1*qdim], &lbf[spos+2*qdim], &lbf[spos+16*qdim], &lbf[spos+4*qdim],
                             &lbf[spos+5*qdim], &lbf[spos+7*qdim], &lbf[spos+6*qdim], &lbf[spos+9*qdim],
                             &lbf[spos+8*qdim], &lbf[spos+11*qdim], &lbf[spos+10*qdim], &lbf[spos+13*qdim],
                             &lbf[spos+12*qdim]);
        break;
      case CEDR:
        fD3Q27VCECLBERegular(rho, -uwall[1], uwall[0], uwall[2], &force[0], &lbf[spos], &lbf[spos+15*qdim],
                             &lbf[spos+1*qdim], &lbf[spos+3*qdim], &lbf[spos+5*qdim], &lbf[spos+17*qdim],
                             &lbf[spos+22*qdim], &lbf[spos+21*qdim], &lbf[spos+6*qdim], &lbf[spos+7*qdim],
                             &lbf[spos+12*qdim], &lbf[spos+13*qdim], &lbf[spos+24*qdim], &lbf[spos+23*qdim],
                             &lbf[spos+2*qdim], &lbf[spos+14*qdim], &lbf[spos+16*qdim], &lbf[spos+18*qdim],
                             &lbf[spos+4*qdim], &lbf[spos+9*qdim], &lbf[spos+8*qdim], &lbf[spos+19*qdim],
                             &lbf[spos+20*qdim], &lbf[spos+25*qdim], &lbf[spos+26*qdim], &lbf[spos+11*qdim],
                             &lbf[spos+10*qdim]);
        break;
      case CETF:
        fD3Q27VCECLBERegular(rho, uwall[1], uwall[2], uwall[0], &force[0], &lbf[spos], &lbf[spos+2*qdim],
                             &lbf[spos+3*qdim], &lbf[spos+1*qdim], &lbf[spos+8*qdim], &lbf[spos+9*qdim],
                             &lbf[spos+4*qdim], &lbf[spos+18*qdim], &lbf[spos+6*qdim], &lbf[spos+20*qdim],
                             &lbf[spos+10*qdim], &lbf[spos+26*qdim], &lbf[spos+11*qdim], &lbf[spos+25*qdim],
                             &lbf[spos+15*qdim], &lbf[spos+16*qdim], &lbf[spos+14*qdim], &lbf[spos+21*qdim],
                             &lbf[spos+22*qdim], &lbf[spos+17*qdim], &lbf[spos+5*qdim], &lbf[spos+19*qdim],
                             &lbf[spos+7*qdim], &lbf[spos+23*qdim], &lbf[spos+13*qdim], &lbf[spos+24*qdim],
                             &lbf[spos+12*qdim]);
        break;
      case CELF:
        fD3Q27VCECLBERegular(rho, -uwall[0], uwall[1], uwall[2], &force[0], &lbf[spos], &lbf[spos+14*qdim],
                             &lbf[spos+3*qdim], &lbf[spos+2*qdim], &lbf[spos+20*qdim], &lbf[spos+19*qdim],
                             &lbf[spos+18*qdim], &lbf[spos+17*qdim], &lbf[spos+8*qdim], &lbf[spos+22*qdim],
                             &lbf[spos+26*qdim], &lbf[spos+24*qdim], &lbf[spos+25*qdim], &lbf[spos+23*qdim],
                             &lbf[spos+1*qdim], &lbf[spos+16*qdim], &lbf[spos+15*qdim], &lbf[spos+7*qdim],
                             &lbf[spos+6*qdim], &lbf[spos+5*qdim], &lbf[spos+4*qdim], &lbf[spos+21*qdim],
                             &lbf[spos+9*qdim], &lbf[spos+13*qdim], &lbf[spos+11*qdim], &lbf[spos+12*qdim],
                             &lbf[spos+10*qdim]);
        break;
      case CEDF:
        fD3Q27VCECLBERegular(rho, -uwall[1], uwall[2], uwall[0], &force[0], &lbf[spos], &lbf[spos+15*qdim],
                             &lbf[spos+3*qdim], &lbf[spos+1*qdim], &lbf[spos+22*qdim], &lbf[spos+21*qdim],
                             &lbf[spos+5*qdim], &lbf[spos+17*qdim], &lbf[spos+6*qdim], &lbf[spos+20*qdim],
                             &lbf[spos+12*qdim], &lbf[spos+24*qdim], &lbf[spos+13*qdim], &lbf[spos+23*qdim],
                             &lbf[spos+2*qdim], &lbf[spos+16*qdim], &lbf[spos+14*qdim], &lbf[spos+9*qdim],
                             &lbf[spos+8*qdim], &lbf[spos+18*qdim], &lbf[spos+4*qdim], &lbf[spos+19*qdim],
                             &lbf[spos+7*qdim], &lbf[spos+25*qdim], &lbf[spos+11*qdim], &lbf[spos+26*qdim],
                             &lbf[spos+10*qdim]);
        break;
      case CERF:
        fD3Q27VCECLBERegular(rho, uwall[0], uwall[2], uwall[2], &force[0], &lbf[spos], &lbf[spos+1*qdim],
                             &lbf[spos+3*qdim], &lbf[spos+2*qdim], &lbf[spos+6*qdim], &lbf[spos+7*qdim],
                             &lbf[spos+4*qdim], &lbf[spos+5*qdim], &lbf[spos+8*qdim], &lbf[spos+22*qdim],
                             &lbf[spos+10*qdim], &lbf[spos+12*qdim], &lbf[spos+11*qdim], &lbf[spos+13*qdim],
                             &lbf[spos+14*qdim], &lbf[spos+16*qdim], &lbf[spos+15*qdim], &lbf[spos+19*qdim],
                             &lbf[spos+20*qdim], &lbf[spos+17*qdim], &lbf[spos+18*qdim], &lbf[spos+21*qdim],
                             &lbf[spos+9*qdim], &lbf[spos+23*qdim], &lbf[spos+25*qdim], &lbf[spos+24*qdim],
                             &lbf[spos+26*qdim]);
        break;
      case CETB:
        fD3Q27VCECLBERegular(rho, uwall[1], -uwall[2], uwall[0], &force[0], &lbf[spos], &lbf[spos+2*qdim],
                             &lbf[spos+16*qdim], &lbf[spos+1*qdim], &lbf[spos+9*qdim], &lbf[spos+8*qdim],
                             &lbf[spos+4*qdim], &lbf[spos+18*qdim], &lbf[spos+7*qdim], &lbf[spos+19*qdim],
                             &lbf[spos+11*qdim], &lbf[spos+25*qdim], &lbf[spos+10*qdim], &lbf[spos+26*qdim],
                             &lbf[spos+15*qdim], &lbf[spos+3*qdim], &lbf[spos+14*qdim], &lbf[spos+22*qdim],
                             &lbf[spos+21*qdim], &lbf[spos+17*qdim], &lbf[spos+5*qdim], &lbf[spos+20*qdim],
                             &lbf[spos+6*qdim], &lbf[spos+24*qdim], &lbf[spos+12*qdim], &lbf[spos+23*qdim],
                             &lbf[spos+13*qdim]);
        break;
      case CELB:
        fD3Q27VCECLBERegular(rho, -uwall[0], -uwall[2], uwall[1], &force[0], &lbf[spos], &lbf[spos+14*qdim],
                             &lbf[spos+16*qdim], &lbf[spos+2*qdim], &lbf[spos+19*qdim], &lbf[spos+20*qdim],
                             &lbf[spos+18*qdim], &lbf[spos+17*qdim], &lbf[spos+9*qdim], &lbf[spos+21*qdim],
                             &lbf[spos+25*qdim], &lbf[spos+23*qdim], &lbf[spos+26*qdim], &lbf[spos+24*qdim],
                             &lbf[spos+1*qdim], &lbf[spos+3*qdim], &lbf[spos+15*qdim], &lbf[spos+6*qdim],
                             &lbf[spos+7*qdim], &lbf[spos+5*qdim], &lbf[spos+4*qdim], &lbf[spos+22*qdim],
                             &lbf[spos+8*qdim], &lbf[spos+12*qdim], &lbf[spos+10*qdim], &lbf[spos+13*qdim],
                             &lbf[spos+11*qdim]);
        break;
      case CEDB:
        fD3Q27VCECLBERegular(rho, -uwall[1], -uwall[2], uwall[0], &force[0], &lbf[spos], &lbf[spos+15*qdim],
                             &lbf[spos+16*qdim], &lbf[spos+1*qdim], &lbf[spos+21*qdim], &lbf[spos+22*qdim],
                             &lbf[spos+5*qdim], &lbf[spos+17*qdim], &lbf[spos+7*qdim], &lbf[spos+19*qdim],
                             &lbf[spos+13*qdim], &lbf[spos+23*qdim], &lbf[spos+12*qdim], &lbf[spos+24*qdim],
                             &lbf[spos+2*qdim], &lbf[spos+3*qdim], &lbf[spos+14*qdim], &lbf[spos+8*qdim],
                             &lbf[spos+9*qdim], &lbf[spos+18*qdim], &lbf[spos+4*qdim], &lbf[spos+20*qdim],
                             &lbf[spos+6*qdim], &lbf[spos+26*qdim], &lbf[spos+10*qdim], &lbf[spos+25*qdim],
                             &lbf[spos+11*qdim]);
        break;
      case CERB:
        fD3Q27VCECLBERegular(rho, uwall[0], -uwall[2], uwall[1], &force[0], &lbf[spos], &lbf[spos+1*qdim],
                             &lbf[spos+16*qdim], &lbf[spos+2*qdim], &lbf[spos+7*qdim], &lbf[spos+6*qdim],
                             &lbf[spos+4*qdim], &lbf[spos+5*qdim], &lbf[spos+9*qdim], &lbf[spos+21*qdim],
                             &lbf[spos+11*qdim], &lbf[spos+13*qdim], &lbf[spos+10*qdim], &lbf[spos+12*qdim],
                             &lbf[spos+14*qdim], &lbf[spos+3*qdim], &lbf[spos+15*qdim], &lbf[spos+20*qdim],
                             &lbf[spos+19*qdim], &lbf[spos+17*qdim], &lbf[spos+18*qdim], &lbf[spos+22*qdim],
                             &lbf[spos+8*qdim], &lbf[spos+24*qdim], &lbf[spos+26*qdim], &lbf[spos+23*qdim],
                             &lbf[spos+25*qdim]);
        break;
    }
  }
  else {
    switch (prop) {
      case PST:
        fD3Q27VPSRegular(uwall[0], uwall[1], uwall[2], &force[0], &lbf[spos], &lbf[spos+1*qdim],
                         &lbf[spos+2*qdim], &lbf[spos+3*qdim], &lbf[spos+4*qdim], &lbf[spos+5*qdim],
                         &lbf[spos+6*qdim], &lbf[spos+7*qdim], &lbf[spos+8*qdim], &lbf[spos+9*qdim],
                         &lbf[spos+10*qdim], &lbf[spos+11*qdim], &lbf[spos+12*qdim], &lbf[spos+13*qdim],
                         &lbf[spos+14*qdim], &lbf[spos+15*qdim], &lbf[spos+16*qdim], &lbf[spos+17*qdim],
                         &lbf[spos+18*qdim], &lbf[spos+19*qdim], &lbf[spos+20*qdim], &lbf[spos+21*qdim],
                         &lbf[spos+22*qdim], &lbf[spos+23*qdim], &lbf[spos+24*qdim], &lbf[spos+25*qdim],
                         &lbf[spos+26*qdim]);
        break;
      case PSD:
        fD3Q27VPSRegular(-uwall[0], -uwall[1], -uwall[2], &force[0], &lbf[spos], &lbf[spos+14*qdim],
                         &lbf[spos+15*qdim], &lbf[spos+16*qdim], &lbf[spos+17*qdim], &lbf[spos+18*qdim],
                         &lbf[spos+19*qdim], &lbf[spos+20*qdim], &lbf[spos+21*qdim], &lbf[spos+22*qdim],
                         &lbf[spos+23*qdim], &lbf[spos+24*qdim], &lbf[spos+25*qdim], &lbf[spos+26*qdim],
                         &lbf[spos+1*qdim], &lbf[spos+2*qdim], &lbf[spos+3*qdim], &lbf[spos+4*qdim],
                         &lbf[spos+5*qdim], &lbf[spos+6*qdim], &lbf[spos+7*qdim], &lbf[spos+8*qdim],
                         &lbf[spos+9*qdim], &lbf[spos+10*qdim], &lbf[spos+11*qdim], &lbf[spos+12*qdim],
                         &lbf[spos+13*qdim]);
        break;
      case PSL:
        fD3Q27VPSRegular(-uwall[2], -uwall[0], -uwall[1], &force[0], &lbf[spos], &lbf[spos+16*qdim],
                         &lbf[spos+14*qdim], &lbf[spos+15*qdim], &lbf[spos+19*qdim], &lbf[spos+7*qdim],
                         &lbf[spos+21*qdim], &lbf[spos+9*qdim], &lbf[spos+17*qdim], &lbf[spos+18*qdim],
                         &lbf[spos+23*qdim], &lbf[spos+25*qdim], &lbf[spos+13*qdim], &lbf[spos+11*qdim],
                         &lbf[spos+3*qdim], &lbf[spos+1*qdim], &lbf[spos+2*qdim], &lbf[spos+6*qdim],
                         &lbf[spos+20*qdim], &lbf[spos+8*qdim], &lbf[spos+22*qdim], &lbf[spos+4*qdim],
                         &lbf[spos+5*qdim], &lbf[spos+10*qdim], &lbf[spos+12*qdim], &lbf[spos+26*qdim],
                         &lbf[spos+24*qdim]);
        break;
      case PSR:
        fD3Q27VPSRegular(uwall[2], uwall[0], uwall[1], &force[0], &lbf[spos], &lbf[spos+3*qdim],
                         &lbf[spos+1*qdim], &lbf[spos+2*qdim], &lbf[spos+6*qdim], &lbf[spos+20*qdim],
                         &lbf[spos+8*qdim], &lbf[spos+22*qdim], &lbf[spos+4*qdim], &lbf[spos+5*qdim],
                         &lbf[spos+10*qdim], &lbf[spos+12*qdim], &lbf[spos+26*qdim], &lbf[spos+24*qdim],
                         &lbf[spos+16*qdim], &lbf[spos+14*qdim], &lbf[spos+15*qdim], &lbf[spos+19*qdim],
                         &lbf[spos+7*qdim], &lbf[spos+21*qdim], &lbf[spos+9*qdim], &lbf[spos+17*qdim],
                         &lbf[spos+18*qdim], &lbf[spos+23*qdim], &lbf[spos+25*qdim], &lbf[spos+13*qdim],
                         &lbf[spos+11*qdim]);
        break;
      case PSF:
        fD3Q27VPSRegular(-uwall[1], -uwall[2], -uwall[0], &force[0], &lbf[spos], &lbf[spos+15*qdim],
                         &lbf[spos+16*qdim], &lbf[spos+14*qdim], &lbf[spos+21*qdim], &lbf[spos+22*qdim],
                         &lbf[spos+17*qdim], &lbf[spos+5*qdim], &lbf[spos+19*qdim], &lbf[spos+7*qdim],
                         &lbf[spos+23*qdim], &lbf[spos+13*qdim], &lbf[spos+24*qdim], &lbf[spos+12*qdim],
                         &lbf[spos+2*qdim], &lbf[spos+3*qdim], &lbf[spos+1*qdim], &lbf[spos+8*qdim],
                         &lbf[spos+9*qdim], &lbf[spos+4*qdim], &lbf[spos+18*qdim], &lbf[spos+6*qdim],
                         &lbf[spos+20*qdim], &lbf[spos+10*qdim], &lbf[spos+26*qdim], &lbf[spos+11*qdim],
                         &lbf[spos+25*qdim]);
        break;
      case PSB:
        fD3Q27VPSRegular(uwall[1], uwall[2], uwall[0], &force[0], &lbf[spos], &lbf[spos+2*qdim],
                         &lbf[spos+3*qdim], &lbf[spos+1*qdim], &lbf[spos+8*qdim], &lbf[spos+9*qdim],
                         &lbf[spos+4*qdim], &lbf[spos+18*qdim], &lbf[spos+6*qdim], &lbf[spos+20*qdim],
                         &lbf[spos+10*qdim], &lbf[spos+26*qdim], &lbf[spos+11*qdim], &lbf[spos+25*qdim],
                         &lbf[spos+15*qdim], &lbf[spos+16*qdim], &lbf[spos+14*qdim], &lbf[spos+21*qdim],
                         &lbf[spos+22*qdim], &lbf[spos+17*qdim], &lbf[spos+5*qdim], &lbf[spos+19*qdim],
                         &lbf[spos+7*qdim], &lbf[spos+23*qdim], &lbf[spos+13*qdim], &lbf[spos+24*qdim],
                         &lbf[spos+12*qdim]);
        break;
      case CCTRB:
        fD3Q27VCCRegular(rho, uwall[0], uwall[1], -uwall[2], &force[0], &lbf[spos], &lbf[spos+1*qdim],
                         &lbf[spos+2*qdim], &lbf[spos+16*qdim], &lbf[spos+4*qdim], &lbf[spos+5*qdim],
                         &lbf[spos+7*qdim], &lbf[spos+6*qdim], &lbf[spos+9*qdim], &lbf[spos+8*qdim],
                         &lbf[spos+11*qdim], &lbf[spos+10*qdim], &lbf[spos+13*qdim], &lbf[spos+12*qdim],
                         &lbf[spos+14*qdim], &lbf[spos+15*qdim], &lbf[spos+3*qdim], &lbf[spos+17*qdim],
                         &lbf[spos+18*qdim], &lbf[spos+20*qdim], &lbf[spos+19*qdim], &lbf[spos+22*qdim],
                         &lbf[spos+21*qdim], &lbf[spos+24*qdim], &lbf[spos+23*qdim], &lbf[spos+26*qdim],
                         &lbf[spos+25*qdim]);
        break;
      case CCTLB:
        fD3Q27VCCRegular(rho, -uwall[0], uwall[1], -uwall[2], &force[0], &lbf[spos], &lbf[spos+14*qdim],
                         &lbf[spos+2*qdim], &lbf[spos+16*qdim], &lbf[spos+18*qdim], &lbf[spos+17*qdim],
                         &lbf[spos+19*qdim], &lbf[spos+20*qdim], &lbf[spos+9*qdim], &lbf[spos+8*qdim],
                         &lbf[spos+25*qdim], &lbf[spos+26*qdim], &lbf[spos+23*qdim], &lbf[spos+24*qdim],
                         &lbf[spos+1*qdim], &lbf[spos+15*qdim], &lbf[spos+3*qdim], &lbf[spos+5*qdim],
                         &lbf[spos+4*qdim], &lbf[spos+6*qdim], &lbf[spos+7*qdim], &lbf[spos+22*qdim],
                         &lbf[spos+21*qdim], &lbf[spos+12*qdim], &lbf[spos+13*qdim], &lbf[spos+10*qdim],
                         &lbf[spos+11*qdim]);
        break;
      case CCDLB:
        fD3Q27VCCRegular(rho, -uwall[0], -uwall[1], -uwall[2], &force[0], &lbf[spos], &lbf[spos+14*qdim],
                         &lbf[spos+15*qdim], &lbf[spos+16*qdim], &lbf[spos+17*qdim], &lbf[spos+18*qdim],
                         &lbf[spos+19*qdim], &lbf[spos+20*qdim], &lbf[spos+21*qdim], &lbf[spos+22*qdim],
                         &lbf[spos+23*qdim], &lbf[spos+24*qdim], &lbf[spos+25*qdim], &lbf[spos+26*qdim],
                         &lbf[spos+1*qdim], &lbf[spos+2*qdim], &lbf[spos+3*qdim], &lbf[spos+4*qdim],
                         &lbf[spos+5*qdim], &lbf[spos+6*qdim], &lbf[spos+7*qdim], &lbf[spos+8*qdim],
                         &lbf[spos+9*qdim], &lbf[spos+10*qdim], &lbf[spos+11*qdim], &lbf[spos+12*qdim],
                         &lbf[spos+13*qdim]);
        break;
      case CCDRB:
        fD3Q27VCCRegular(rho, uwall[0], -uwall[1], -uwall[2], &force[0], &lbf[spos], &lbf[spos+1*qdim],
                         &lbf[spos+15*qdim], &lbf[spos+16*qdim], &lbf[spos+5*qdim], &lbf[spos+4*qdim],
                         &lbf[spos+7*qdim], &lbf[spos+6*qdim], &lbf[spos+21*qdim], &lbf[spos+22*qdim],
                         &lbf[spos+13*qdim], &lbf[spos+12*qdim], &lbf[spos+11*qdim], &lbf[spos+10*qdim],
                         &lbf[spos+14*qdim], &lbf[spos+2*qdim], &lbf[spos+3*qdim], &lbf[spos+18*qdim],
                         &lbf[spos+17*qdim], &lbf[spos+20*qdim], &lbf[spos+19*qdim], &lbf[spos+8*qdim],
                         &lbf[spos+9*qdim], &lbf[spos+26*qdim], &lbf[spos+25*qdim], &lbf[spos+24*qdim],
                         &lbf[spos+23*qdim]);
        break;
      case CCTRF:
        fD3Q27VCCRegular(rho, uwall[0], uwall[1], uwall[2], &force[0], &lbf[spos], &lbf[spos+1*qdim],
                         &lbf[spos+2*qdim], &lbf[spos+3*qdim], &lbf[spos+4*qdim], &lbf[spos+5*qdim],
                         &lbf[spos+6*qdim], &lbf[spos+7*qdim], &lbf[spos+8*qdim], &lbf[spos+9*qdim],
                         &lbf[spos+10*qdim], &lbf[spos+11*qdim], &lbf[spos+12*qdim], &lbf[spos+13*qdim],
                         &lbf[spos+14*qdim], &lbf[spos+15*qdim], &lbf[spos+16*qdim], &lbf[spos+17*qdim],
                         &lbf[spos+18*qdim], &lbf[spos+19*qdim], &lbf[spos+20*qdim], &lbf[spos+21*qdim],
                         &lbf[spos+22*qdim], &lbf[spos+23*qdim], &lbf[spos+24*qdim], &lbf[spos+25*qdim],
                         &lbf[spos+26*qdim]);
        break;
      case CCTLF:
        fD3Q27VCCRegular(rho, -uwall[0], uwall[1], uwall[2], &force[0], &lbf[spos], &lbf[spos+14*qdim],
                         &lbf[spos+2*qdim], &lbf[spos+3*qdim], &lbf[spos+18*qdim], &lbf[spos+17*qdim],
                         &lbf[spos+20*qdim], &lbf[spos+19*qdim], &lbf[spos+8*qdim], &lbf[spos+9*qdim],
                         &lbf[spos+26*qdim], &lbf[spos+25*qdim], &lbf[spos+24*qdim], &lbf[spos+23*qdim],
                         &lbf[spos+1*qdim], &lbf[spos+15*qdim], &lbf[spos+16*qdim], &lbf[spos+5*qdim],
                         &lbf[spos+4*qdim], &lbf[spos+7*qdim], &lbf[spos+6*qdim], &lbf[spos+21*qdim],
                         &lbf[spos+22*qdim], &lbf[spos+13*qdim], &lbf[spos+12*qdim], &lbf[spos+11*qdim],
                         &lbf[spos+10*qdim]);
        break;
      case CCDLF:
        fD3Q27VCCRegular(rho, -uwall[0], -uwall[1], uwall[2], &force[0], &lbf[spos], &lbf[spos+14*qdim],
                         &lbf[spos+15*qdim], &lbf[spos+3*qdim], &lbf[spos+17*qdim], &lbf[spos+18*qdim],
                         &lbf[spos+20*qdim], &lbf[spos+19*qdim], &lbf[spos+22*qdim], &lbf[spos+21*qdim],
                         &lbf[spos+24*qdim], &lbf[spos+23*qdim], &lbf[spos+26*qdim], &lbf[spos+25*qdim],
                         &lbf[spos+1*qdim], &lbf[spos+2*qdim], &lbf[spos+16*qdim], &lbf[spos+4*qdim],
                         &lbf[spos+5*qdim], &lbf[spos+7*qdim], &lbf[spos+6*qdim], &lbf[spos+9*qdim],
                         &lbf[spos+8*qdim], &lbf[spos+11*qdim], &lbf[spos+10*qdim], &lbf[spos+13*qdim],
                         &lbf[spos+12*qdim]);
        break;
      case CCDRF:
        fD3Q27VCCRegular(rho, uwall[0], -uwall[1], uwall[2], &force[0], &lbf[spos], &lbf[spos+1*qdim],
                         &lbf[spos+15*qdim], &lbf[spos+3*qdim], &lbf[spos+5*qdim], &lbf[spos+4*qdim],
                         &lbf[spos+6*qdim], &lbf[spos+7*qdim], &lbf[spos+22*qdim], &lbf[spos+21*qdim],
                         &lbf[spos+12*qdim], &lbf[spos+13*qdim], &lbf[spos+10*qdim], &lbf[spos+11*qdim],
                         &lbf[spos+14*qdim], &lbf[spos+2*qdim], &lbf[spos+16*qdim], &lbf[spos+18*qdim],
                         &lbf[spos+17*qdim], &lbf[spos+19*qdim], &lbf[spos+20*qdim], &lbf[spos+9*qdim],
                         &lbf[spos+8*qdim], &lbf[spos+25*qdim], &lbf[spos+26*qdim], &lbf[spos+23*qdim],
                         &lbf[spos+24*qdim]);
        break;
      case CETR:
        fD3Q27VCERegular(rho, uwall[0], uwall[1], uwall[2], &force[0], &lbf[spos], &lbf[spos+1*qdim],
                         &lbf[spos+2*qdim], &lbf[spos+3*qdim], &lbf[spos+4*qdim], &lbf[spos+5*qdim],
                         &lbf[spos+6*qdim], &lbf[spos+7*qdim], &lbf[spos+8*qdim], &lbf[spos+9*qdim],
                         &lbf[spos+10*qdim], &lbf[spos+11*qdim], &lbf[spos+12*qdim], &lbf[spos+13*qdim],
                         &lbf[spos+14*qdim], &lbf[spos+15*qdim], &lbf[spos+16*qdim], &lbf[spos+17*qdim],
                         &lbf[spos+18*qdim], &lbf[spos+19*qdim], &lbf[spos+20*qdim], &lbf[spos+21*qdim],
                         &lbf[spos+22*qdim], &lbf[spos+23*qdim], &lbf[spos+24*qdim], &lbf[spos+25*qdim],
                         &lbf[spos+26*qdim]);
        break;
      case CETL:
        fD3Q27VCERegular(rho, uwall[1], -uwall[0], uwall[2], &force[0], &lbf[spos], &lbf[spos+2*qdim],
                         &lbf[spos+14*qdim], &lbf[spos+3*qdim], &lbf[spos+18*qdim], &lbf[spos+4*qdim],
                         &lbf[spos+8*qdim], &lbf[spos+9*qdim], &lbf[spos+20*qdim], &lbf[spos+19*qdim],
                         &lbf[spos+26*qdim], &lbf[spos+25*qdim], &lbf[spos+10*qdim], &lbf[spos+11*qdim],
                         &lbf[spos+15*qdim], &lbf[spos+1*qdim], &lbf[spos+16*qdim], &lbf[spos+5*qdim],
                         &lbf[spos+17*qdim], &lbf[spos+21*qdim], &lbf[spos+22*qdim], &lbf[spos+7*qdim],
                         &lbf[spos+6*qdim], &lbf[spos+13*qdim], &lbf[spos+12*qdim], &lbf[spos+23*qdim],
                         &lbf[spos+24*qdim]);
        break;
      case CEDL:
        fD3Q27VCERegular(rho, -uwall[0], -uwall[1], uwall[2], &force[0], &lbf[spos], &lbf[spos+14*qdim],
                         &lbf[spos+15*qdim], &lbf[spos+3*qdim], &lbf[spos+17*qdim], &lbf[spos+18*qdim],
                         &lbf[spos+20*qdim], &lbf[spos+19*qdim], &lbf[spos+22*qdim], &lbf[spos+21*qdim],
                         &lbf[spos+24*qdim], &lbf[spos+23*qdim], &lbf[spos+26*qdim], &lbf[spos+25*qdim],
                         &lbf[spos+1*qdim], &lbf[spos+2*qdim], &lbf[spos+16*qdim], &lbf[spos+4*qdim],
                         &lbf[spos+5*qdim], &lbf[spos+7*qdim], &lbf[spos+6*qdim], &lbf[spos+9*qdim],
                         &lbf[spos+8*qdim], &lbf[spos+11*qdim], &lbf[spos+10*qdim], &lbf[spos+13*qdim],
                         &lbf[spos+12*qdim]);
        break;
      case CEDR:
        fD3Q27VCERegular(rho, -uwall[1], uwall[0], uwall[2], &force[0], &lbf[spos], &lbf[spos+15*qdim],
                         &lbf[spos+1*qdim], &lbf[spos+3*qdim], &lbf[spos+5*qdim], &lbf[spos+17*qdim],
                         &lbf[spos+22*qdim], &lbf[spos+21*qdim], &lbf[spos+6*qdim], &lbf[spos+7*qdim],
                         &lbf[spos+12*qdim], &lbf[spos+13*qdim], &lbf[spos+24*qdim], &lbf[spos+23*qdim],
                         &lbf[spos+2*qdim], &lbf[spos+14*qdim], &lbf[spos+16*qdim], &lbf[spos+18*qdim],
                         &lbf[spos+4*qdim], &lbf[spos+9*qdim], &lbf[spos+8*qdim], &lbf[spos+19*qdim],
                         &lbf[spos+20*qdim], &lbf[spos+25*qdim], &lbf[spos+26*qdim], &lbf[spos+11*qdim],
                         &lbf[spos+10*qdim]);
        break;
      case CETF:
        fD3Q27VCERegular(rho, uwall[1], uwall[2], uwall[0], &force[0], &lbf[spos], &lbf[spos+2*qdim],
                         &lbf[spos+3*qdim], &lbf[spos+1*qdim], &lbf[spos+8*qdim], &lbf[spos+9*qdim],
                         &lbf[spos+4*qdim], &lbf[spos+18*qdim], &lbf[spos+6*qdim], &lbf[spos+20*qdim],
                         &lbf[spos+10*qdim], &lbf[spos+26*qdim], &lbf[spos+11*qdim], &lbf[spos+25*qdim],
                         &lbf[spos+15*qdim], &lbf[spos+16*qdim], &lbf[spos+14*qdim], &lbf[spos+21*qdim],
                         &lbf[spos+22*qdim], &lbf[spos+17*qdim], &lbf[spos+5*qdim], &lbf[spos+19*qdim],
                         &lbf[spos+7*qdim], &lbf[spos+23*qdim], &lbf[spos+13*qdim], &lbf[spos+24*qdim],
                         &lbf[spos+12*qdim]);
        break;
      case CELF:
        fD3Q27VCERegular(rho, -uwall[0], uwall[1], uwall[2], &force[0], &lbf[spos], &lbf[spos+14*qdim],
                         &lbf[spos+3*qdim], &lbf[spos+2*qdim], &lbf[spos+20*qdim], &lbf[spos+19*qdim],
                         &lbf[spos+18*qdim], &lbf[spos+17*qdim], &lbf[spos+8*qdim], &lbf[spos+22*qdim],
                         &lbf[spos+26*qdim], &lbf[spos+24*qdim], &lbf[spos+25*qdim], &lbf[spos+23*qdim],
                         &lbf[spos+1*qdim], &lbf[spos+16*qdim], &lbf[spos+15*qdim], &lbf[spos+7*qdim],
                         &lbf[spos+6*qdim], &lbf[spos+5*qdim], &lbf[spos+4*qdim], &lbf[spos+21*qdim],
                         &lbf[spos+9*qdim], &lbf[spos+13*qdim], &lbf[spos+11*qdim], &lbf[spos+12*qdim],
                         &lbf[spos+10*qdim]);
        break;
      case CEDF:
        fD3Q27VCERegular(rho, -uwall[1], uwall[2], uwall[0], &force[0], &lbf[spos], &lbf[spos+15*qdim],
                         &lbf[spos+3*qdim], &lbf[spos+1*qdim], &lbf[spos+22*qdim], &lbf[spos+21*qdim],
                         &lbf[spos+5*qdim], &lbf[spos+17*qdim], &lbf[spos+6*qdim], &lbf[spos+20*qdim],
                         &lbf[spos+12*qdim], &lbf[spos+24*qdim], &lbf[spos+13*qdim], &lbf[spos+23*qdim],
                         &lbf[spos+2*qdim], &lbf[spos+16*qdim], &lbf[spos+14*qdim], &lbf[spos+9*qdim],
                         &lbf[spos+8*qdim], &lbf[spos+18*qdim], &lbf[spos+4*qdim], &lbf[spos+19*qdim],
                         &lbf[spos+7*qdim], &lbf[spos+25*qdim], &lbf[spos+11*qdim], &lbf[spos+26*qdim],
                         &lbf[spos+10*qdim]);
        break;
      case CERF:
        fD3Q27VCERegular(rho, uwall[0], uwall[2], uwall[2], &force[0], &lbf[spos], &lbf[spos+1*qdim],
                         &lbf[spos+3*qdim], &lbf[spos+2*qdim], &lbf[spos+6*qdim], &lbf[spos+7*qdim],
                         &lbf[spos+4*qdim], &lbf[spos+5*qdim], &lbf[spos+8*qdim], &lbf[spos+22*qdim],
                         &lbf[spos+10*qdim], &lbf[spos+12*qdim], &lbf[spos+11*qdim], &lbf[spos+13*qdim],
                         &lbf[spos+14*qdim], &lbf[spos+16*qdim], &lbf[spos+15*qdim], &lbf[spos+19*qdim],
                         &lbf[spos+20*qdim], &lbf[spos+17*qdim], &lbf[spos+18*qdim], &lbf[spos+21*qdim],
                         &lbf[spos+9*qdim], &lbf[spos+23*qdim], &lbf[spos+25*qdim], &lbf[spos+24*qdim],
                         &lbf[spos+26*qdim]);
        break;
      case CETB:
        fD3Q27VCERegular(rho, uwall[1], -uwall[2], uwall[0], &force[0], &lbf[spos], &lbf[spos+2*qdim],
                         &lbf[spos+16*qdim], &lbf[spos+1*qdim], &lbf[spos+9*qdim], &lbf[spos+8*qdim],
                         &lbf[spos+4*qdim], &lbf[spos+18*qdim], &lbf[spos+7*qdim], &lbf[spos+19*qdim],
                         &lbf[spos+11*qdim], &lbf[spos+25*qdim], &lbf[spos+10*qdim], &lbf[spos+26*qdim],
                         &lbf[spos+15*qdim], &lbf[spos+3*qdim], &lbf[spos+14*qdim], &lbf[spos+22*qdim],
                         &lbf[spos+21*qdim], &lbf[spos+17*qdim], &lbf[spos+5*qdim], &lbf[spos+20*qdim],
                         &lbf[spos+6*qdim], &lbf[spos+24*qdim], &lbf[spos+12*qdim], &lbf[spos+23*qdim],
                         &lbf[spos+13*qdim]);
        break;
      case CELB:
        fD3Q27VCERegular(rho, -uwall[0], -uwall[2], uwall[1], &force[0], &lbf[spos], &lbf[spos+14*qdim],
                         &lbf[spos+16*qdim], &lbf[spos+2*qdim], &lbf[spos+19*qdim], &lbf[spos+20*qdim],
                         &lbf[spos+18*qdim], &lbf[spos+17*qdim], &lbf[spos+9*qdim], &lbf[spos+21*qdim],
                         &lbf[spos+25*qdim], &lbf[spos+23*qdim], &lbf[spos+26*qdim], &lbf[spos+24*qdim],
                         &lbf[spos+1*qdim], &lbf[spos+3*qdim], &lbf[spos+15*qdim], &lbf[spos+6*qdim],
                         &lbf[spos+7*qdim], &lbf[spos+5*qdim], &lbf[spos+4*qdim], &lbf[spos+22*qdim],
                         &lbf[spos+8*qdim], &lbf[spos+12*qdim], &lbf[spos+10*qdim], &lbf[spos+13*qdim],
                         &lbf[spos+11*qdim]);
        break;
      case CEDB:
        fD3Q27VCERegular(rho, -uwall[1], -uwall[2], uwall[0], &force[0], &lbf[spos], &lbf[spos+15*qdim],
                         &lbf[spos+16*qdim], &lbf[spos+1*qdim], &lbf[spos+21*qdim], &lbf[spos+22*qdim],
                         &lbf[spos+5*qdim], &lbf[spos+17*qdim], &lbf[spos+7*qdim], &lbf[spos+19*qdim],
                         &lbf[spos+13*qdim], &lbf[spos+23*qdim], &lbf[spos+12*qdim], &lbf[spos+24*qdim],
                         &lbf[spos+2*qdim], &lbf[spos+3*qdim], &lbf[spos+14*qdim], &lbf[spos+8*qdim],
                         &lbf[spos+9*qdim], &lbf[spos+18*qdim], &lbf[spos+4*qdim], &lbf[spos+20*qdim],
                         &lbf[spos+6*qdim], &lbf[spos+26*qdim], &lbf[spos+10*qdim], &lbf[spos+25*qdim],
                         &lbf[spos+11*qdim]);
        break;
      case CERB:
        fD3Q27VCERegular(rho, uwall[0], -uwall[2], uwall[1], &force[0], &lbf[spos], &lbf[spos+1*qdim],
                         &lbf[spos+16*qdim], &lbf[spos+2*qdim], &lbf[spos+7*qdim], &lbf[spos+6*qdim],
                         &lbf[spos+4*qdim], &lbf[spos+5*qdim], &lbf[spos+9*qdim], &lbf[spos+21*qdim],
                         &lbf[spos+11*qdim], &lbf[spos+13*qdim], &lbf[spos+10*qdim], &lbf[spos+12*qdim],
                         &lbf[spos+14*qdim], &lbf[spos+3*qdim], &lbf[spos+15*qdim], &lbf[spos+20*qdim],
                         &lbf[spos+19*qdim], &lbf[spos+17*qdim], &lbf[spos+18*qdim], &lbf[spos+22*qdim],
                         &lbf[spos+8*qdim], &lbf[spos+24*qdim], &lbf[spos+26*qdim], &lbf[spos+23*qdim],
                         &lbf[spos+25*qdim]);
        break;
    }
  }
  return 0;
  
}

int fD3Q27PPSRegular(double *p, double *force, double *f0, double *f1,
                     double *f2, double *f3, double *f4, double *f5,
                     double *f6, double *f7, double *f8, double *f9,
                     double *f10, double *f11, double *f12, double *f13,
                     double *f14, double *f15, double *f16, double *f17,
                     double *f18, double *f19, double *f20, double *f21,
                     double *f22, double *f23, double *f24, double *f25,
                     double *f26, double &vel)
{

  // produce fixed pressure/density at planar surface: expressed for bottom wall

  double rho, rho0, pi_xx, pi_yy, pi_zz, pi_xy, pi_xz, pi_yz, v, v1, v1v1, mass=0.0;
  double c1=1.0/3.0,c2=4.0/9.0,c3=2.0/9.0,c4=1.0/9.0,c5=1.0/6.0,c6=1.0/18.0,c7=1.0/24.0,c8=1.0/36.0,c9=1.0/72.0;
  vel = 0.0;

  if(!incompress) {
    for(int i=0; i<lbsy.nf; i++) {
      v = p[i]-(f0[i]+f1[i]+f3[i]+f6[i]+f7[i]+f14[i]+f16[i]+f19[i]+f20[i]+2.0*(f2[i]+f4[i]+f8[i]+f9[i]+f10[i]+f11[i]+f18[i]+f25[i]+f26[i]))+0.5*force[3*i+1];
      vel += v;
      mass += p[i];
    }
    vel *= fReciprocal(mass);
    v1 = vel;
    v1v1 = v1*v1;
    for(int i=0; i<lbsy.nf; i++) {
      rho=p[i];
      pi_xx = f1[i]+f6[i]+f7[i]+f14[i]+f19[i]+f20[i]+2.0*(f4[i]+f10[i]+f11[i]+f18[i]+f25[i]+f26[i])+rho*c1*(v1-1.0);
      pi_yy = 2.0*(f2[i]+f4[i]+f8[i]+f9[i]+f10[i]+f11[i]+f18[i]+f25[i]+f26[i])+rho*(v1-v1v1-c1)+v1*force[3*i+1];
      pi_zz = f3[i]+f6[i]+f7[i]+f16[i]+f19[i]+f20[i]+2.0*(f8[i]+f9[i]+f10[i]+f11[i]+f25[i]+f26[i])+rho*c1*(v1-1.0);
      pi_xy = 2.0*(f4[i]+f10[i]+f11[i]-f18[i]-f25[i]-f26[i])+0.5*v1*force[3*i  ];
      pi_xz = f6[i]-f7[i]+f19[i]-f20[i]+2.0*(f10[i]-f11[i]+f25[i]-f26[i]);
      pi_yz = 2.0*(f8[i]-f9[i]+f10[i]-f11[i]-f25[i]+f26[i])+0.5*v1*force[3*i+2];
      f0[i] =rho*lbw[0] *(1.0       -1.5*v1v1)-c2*(pi_xx+   pi_yy+   pi_zz);
      f1[i] =rho*lbw[1] *(1.0       -1.5*v1v1)+c3* pi_xx-c4*pi_yy-c4*pi_zz;
      f2[i] =rho*lbw[2] *(1.0-3.0*v1+3.0*v1v1)-c4* pi_xx+c3*pi_yy-c4*pi_zz;
      f3[i] =rho*lbw[3] *(1.0       -1.5*v1v1)-c4* pi_xx-c4*pi_yy+c3*pi_zz;
      f4[i] =rho*lbw[4] *(1.0-3.0*v1+3.0*v1v1)+c6* pi_xx+c6*pi_yy-c8*pi_zz +c5* pi_xy;
      f5[i] =rho*lbw[5] *(1.0+3.0*v1+3.0*v1v1)+c6* pi_xx+c6*pi_yy-c8*pi_zz -c5* pi_xy;
      f6[i] =rho*lbw[6] *(1.0       -1.5*v1v1)+c6* pi_xx-c8*pi_yy+c6*pi_zz +c5* pi_xz;
      f7[i] =rho*lbw[7] *(1.0       -1.5*v1v1)+c6* pi_xx-c8*pi_yy+c6*pi_zz -c5* pi_xz;
      f8[i] =rho*lbw[8] *(1.0-3.0*v1+3.0*v1v1)-c8* pi_xx+c6*pi_yy+c6*pi_zz +c5* pi_yz;
      f9[i] =rho*lbw[9] *(1.0-3.0*v1+3.0*v1v1)-c8* pi_xx+c6*pi_yy+c6*pi_zz -c5* pi_yz;
      f10[i]=rho*lbw[10]*(1.0-3.0*v1+3.0*v1v1)+c9*(pi_xx+   pi_yy+   pi_zz)+c7*(pi_xy+pi_xz+pi_yz);
      f11[i]=rho*lbw[11]*(1.0-3.0*v1+3.0*v1v1)+c9*(pi_xx+   pi_yy+   pi_zz)+c7*(pi_xy-pi_xz-pi_yz);
      f12[i]=rho*lbw[12]*(1.0+3.0*v1+3.0*v1v1)+c9*(pi_xx+   pi_yy+   pi_zz)-c7*(pi_xy-pi_xz+pi_yz);
      f13[i]=rho*lbw[13]*(1.0+3.0*v1+3.0*v1v1)+c9*(pi_xx+   pi_yy+   pi_zz)-c7*(pi_xy+pi_xz-pi_yz);
      f14[i]=rho*lbw[14]*(1.0       -1.5*v1v1)+c3* pi_xx-c4*pi_yy-c4*pi_zz;
      f15[i]=rho*lbw[15]*(1.0+3.0*v1+3.0*v1v1)-c4* pi_xx+c3*pi_yy-c4*pi_zz;
      f16[i]=rho*lbw[16]*(1.0       -1.5*v1v1)-c4* pi_xx-c4*pi_yy+c3*pi_zz;
      f17[i]=rho*lbw[17]*(1.0+3.0*v1+3.0*v1v1)+c6* pi_xx+c6*pi_yy-c8*pi_zz +c5* pi_xy;
      f18[i]=rho*lbw[18]*(1.0-3.0*v1+3.0*v1v1)+c6* pi_xx+c6*pi_yy-c8*pi_zz -c5* pi_xy;
      f19[i]=rho*lbw[19]*(1.0       -1.5*v1v1)+c6* pi_xx-c8*pi_yy+c6*pi_zz +c5* pi_xz;
      f20[i]=rho*lbw[20]*(1.0       -1.5*v1v1)+c6* pi_xx-c8*pi_yy+c6*pi_zz -c5* pi_xz;
      f21[i]=rho*lbw[21]*(1.0+3.0*v1+3.0*v1v1)-c8* pi_xx+c6*pi_yy+c6*pi_zz +c5* pi_yz;
      f22[i]=rho*lbw[22]*(1.0+3.0*v1+3.0*v1v1)-c8* pi_xx+c6*pi_yy+c6*pi_zz -c5* pi_yz;
      f23[i]=rho*lbw[23]*(1.0+3.0*v1+3.0*v1v1)+c9*(pi_xx+   pi_yy+   pi_zz)+c7*(pi_xy+pi_xz+pi_yz);
      f24[i]=rho*lbw[24]*(1.0+3.0*v1+3.0*v1v1)+c9*(pi_xx+   pi_yy+   pi_zz)+c7*(pi_xy-pi_xz-pi_yz);
      f25[i]=rho*lbw[25]*(1.0-3.0*v1+3.0*v1v1)+c9*(pi_xx+   pi_yy+   pi_zz)-c7*(pi_xy-pi_xz+pi_yz);
      f26[i]=rho*lbw[26]*(1.0-3.0*v1+3.0*v1v1)+c9*(pi_xx+   pi_yy+   pi_zz)-c7*(pi_xy+pi_xz-pi_yz);
    }
  }
  else {
    for(int i=0; i<lbsy.nf; i++) {
      v = p[i]-(f0[i]+f1[i]+f3[i]+f6[i]+f7[i]+f14[i]+f16[i]+f19[i]+f20[i]+2.0*(f2[i]+f4[i]+f8[i]+f9[i]+f10[i]+f11[i]+f18[i]+f25[i]+f26[i]))+0.5*force[3*i+1];
      vel += v;
      mass += lbincp[i];
    }
    vel *= fReciprocal(mass);
    v1 = vel;
    v1v1 = v1*v1;
    for(int i=0; i<lbsy.nf; i++) {
      rho0 = lbincp[i];
      rho = p[i];
      pi_xx = f1[i]+f6[i]+f7[i]+f14[i]+f19[i]+f20[i]+2.0*(f4[i]+f10[i]+f11[i]+f18[i]+f25[i]+f26[i])+c1*(rho0*v1-rho);
      pi_yy = 2.0*(f2[i]+f4[i]+f8[i]+f9[i]+f10[i]+f11[i]+f18[i]+f25[i]+f26[i])+rho0*(v1-v1v1)-c1*rho+v1*force[3*i+1];
      pi_zz = f3[i]+f6[i]+f7[i]+f16[i]+f19[i]+f20[i]+2.0*(f8[i]+f9[i]+f10[i]+f11[i]+f25[i]+f26[i])+c1*(rho0*v1-rho);
      pi_xy = 2.0*(f4[i]+f10[i]+f11[i]-f18[i]-f25[i]-f26[i])+0.5*v1*force[3*i  ];
      pi_xz = f6[i]-f7[i]+f19[i]-f20[i]+2.0*(f10[i]-f11[i]+f25[i]-f26[i]);
      pi_yz = 2.0*(f8[i]-f9[i]+f10[i]-f11[i]-f25[i]+f26[i])+0.5*v1*force[3*i+2];
      f0[i] =lbw[0] *(rho+rho0*(       -1.5*v1v1))-c2*(pi_xx+   pi_yy+   pi_zz);
      f1[i] =lbw[1] *(rho+rho0*(       -1.5*v1v1))+c3* pi_xx-c4*pi_yy-c4*pi_zz;
      f2[i] =lbw[2] *(rho+rho0*(-3.0*v1+3.0*v1v1))-c4* pi_xx+c3*pi_yy-c4*pi_zz;
      f3[i] =lbw[3] *(rho+rho0*(       -1.5*v1v1))-c4* pi_xx-c4*pi_yy+c3*pi_zz;
      f4[i] =lbw[4] *(rho+rho0*(-3.0*v1+3.0*v1v1))+c6* pi_xx+c6*pi_yy-c8*pi_zz +c5* pi_xy;
      f5[i] =lbw[5] *(rho+rho0*( 3.0*v1+3.0*v1v1))+c6* pi_xx+c6*pi_yy-c8*pi_zz -c5* pi_xy;
      f6[i] =lbw[6] *(rho+rho0*(       -1.5*v1v1))+c6* pi_xx-c8*pi_yy+c6*pi_zz +c5* pi_xz;
      f7[i] =lbw[7] *(rho+rho0*(       -1.5*v1v1))+c6* pi_xx-c8*pi_yy+c6*pi_zz -c5* pi_xz;
      f8[i] =lbw[8] *(rho+rho0*(-3.0*v1+3.0*v1v1))-c8* pi_xx+c6*pi_yy+c6*pi_zz +c5* pi_yz;
      f9[i] =lbw[9] *(rho+rho0*(-3.0*v1+3.0*v1v1))-c8* pi_xx+c6*pi_yy+c6*pi_zz -c5* pi_yz;
      f10[i]=lbw[10]*(rho+rho0*(-3.0*v1+3.0*v1v1))+c9*(pi_xx+   pi_yy+   pi_zz)+c7*(pi_xy+pi_xz+pi_yz);
      f11[i]=lbw[11]*(rho+rho0*(-3.0*v1+3.0*v1v1))+c9*(pi_xx+   pi_yy+   pi_zz)+c7*(pi_xy-pi_xz-pi_yz);
      f12[i]=lbw[12]*(rho+rho0*( 3.0*v1+3.0*v1v1))+c9*(pi_xx+   pi_yy+   pi_zz)-c7*(pi_xy-pi_xz+pi_yz);
      f13[i]=lbw[13]*(rho+rho0*( 3.0*v1+3.0*v1v1))+c9*(pi_xx+   pi_yy+   pi_zz)-c7*(pi_xy+pi_xz-pi_yz);
      f14[i]=lbw[14]*(rho+rho0*(       -1.5*v1v1))+c3* pi_xx-c4*pi_yy-c4*pi_zz;
      f15[i]=lbw[15]*(rho+rho0*( 3.0*v1+3.0*v1v1))-c4* pi_xx+c3*pi_yy-c4*pi_zz;
      f16[i]=lbw[16]*(rho+rho0*(       -1.5*v1v1))-c4* pi_xx-c4*pi_yy+c3*pi_zz;
      f17[i]=lbw[17]*(rho+rho0*( 3.0*v1+3.0*v1v1))+c6* pi_xx+c6*pi_yy-c8*pi_zz +c5* pi_xy;
      f18[i]=lbw[18]*(rho+rho0*(-3.0*v1+3.0*v1v1))+c6* pi_xx+c6*pi_yy-c8*pi_zz -c5* pi_xy;
      f19[i]=lbw[19]*(rho+rho0*(       -1.5*v1v1))+c6* pi_xx-c8*pi_yy+c6*pi_zz +c5* pi_xz;
      f20[i]=lbw[20]*(rho+rho0*(       -1.5*v1v1))+c6* pi_xx-c8*pi_yy+c6*pi_zz -c5* pi_xz;
      f21[i]=lbw[21]*(rho+rho0*( 3.0*v1+3.0*v1v1))-c8* pi_xx+c6*pi_yy+c6*pi_zz +c5* pi_yz;
      f22[i]=lbw[22]*(rho+rho0*( 3.0*v1+3.0*v1v1))-c8* pi_xx+c6*pi_yy+c6*pi_zz -c5* pi_yz;
      f23[i]=lbw[23]*(rho+rho0*( 3.0*v1+3.0*v1v1))+c9*(pi_xx+   pi_yy+   pi_zz)+c7*(pi_xy+pi_xz+pi_yz);
      f24[i]=lbw[24]*(rho+rho0*( 3.0*v1+3.0*v1v1))+c9*(pi_xx+   pi_yy+   pi_zz)+c7*(pi_xy-pi_xz-pi_yz);
      f25[i]=lbw[25]*(rho+rho0*(-3.0*v1+3.0*v1v1))+c9*(pi_xx+   pi_yy+   pi_zz)-c7*(pi_xy-pi_xz+pi_yz);
      f26[i]=lbw[26]*(rho+rho0*(-3.0*v1+3.0*v1v1))+c9*(pi_xx+   pi_yy+   pi_zz)-c7*(pi_xy+pi_xz-pi_yz);
    }
  }
  return 0;
}


int fD3Q27PFRegular(long tpos, int prop, double *p0, double *uwall)
{
  double moment;
  long spos=tpos * lbsitelength;
  int qdim=lbsy.nf+lbsy.nc+lbsy.nt;
  double force[3*lbsy.nf];
  
  fD3Q27BoundaryForceDensity(force, tpos, p0, prop);

  if(collide>11) {
    switch (prop) {
      case PST:
        fD3Q27PPSRegular(p0, &force[0], &lbf[spos], &lbf[spos+1*qdim],
                         &lbf[spos+2*qdim], &lbf[spos+3*qdim], &lbf[spos+4*qdim], &lbf[spos+5*qdim],
                         &lbf[spos+6*qdim], &lbf[spos+7*qdim], &lbf[spos+8*qdim], &lbf[spos+9*qdim],
                         &lbf[spos+10*qdim], &lbf[spos+11*qdim], &lbf[spos+12*qdim], &lbf[spos+13*qdim],
                         &lbf[spos+14*qdim], &lbf[spos+15*qdim], &lbf[spos+16*qdim], &lbf[spos+17*qdim],
                         &lbf[spos+18*qdim], &lbf[spos+19*qdim], &lbf[spos+20*qdim], &lbf[spos+21*qdim],
                         &lbf[spos+22*qdim], &lbf[spos+23*qdim], &lbf[spos+24*qdim], &lbf[spos+25*qdim],
                         &lbf[spos+26*qdim], moment);
        uwall[1] += moment;
        break;
      case PSD:
        fD3Q27PPSRegular(p0, &force[0], &lbf[spos], &lbf[spos+14*qdim],
                         &lbf[spos+15*qdim], &lbf[spos+16*qdim], &lbf[spos+17*qdim], &lbf[spos+18*qdim],
                         &lbf[spos+19*qdim], &lbf[spos+20*qdim], &lbf[spos+21*qdim], &lbf[spos+22*qdim],
                         &lbf[spos+23*qdim], &lbf[spos+24*qdim], &lbf[spos+25*qdim], &lbf[spos+26*qdim],
                         &lbf[spos+1*qdim], &lbf[spos+2*qdim], &lbf[spos+3*qdim], &lbf[spos+4*qdim],
                         &lbf[spos+5*qdim], &lbf[spos+6*qdim], &lbf[spos+7*qdim], &lbf[spos+8*qdim],
                         &lbf[spos+9*qdim], &lbf[spos+10*qdim], &lbf[spos+11*qdim], &lbf[spos+12*qdim],
                         &lbf[spos+13*qdim], moment);
        uwall[1] -= moment;
        break;
      case PSL:
        fD3Q27PPSRegular(p0, &force[0], &lbf[spos], &lbf[spos+16*qdim],
                         &lbf[spos+14*qdim], &lbf[spos+15*qdim], &lbf[spos+19*qdim], &lbf[spos+7*qdim],
                         &lbf[spos+21*qdim], &lbf[spos+9*qdim], &lbf[spos+17*qdim], &lbf[spos+18*qdim],
                         &lbf[spos+23*qdim], &lbf[spos+25*qdim], &lbf[spos+13*qdim], &lbf[spos+11*qdim],
                         &lbf[spos+3*qdim], &lbf[spos+1*qdim], &lbf[spos+2*qdim], &lbf[spos+6*qdim],
                         &lbf[spos+20*qdim], &lbf[spos+8*qdim], &lbf[spos+22*qdim], &lbf[spos+4*qdim],
                         &lbf[spos+5*qdim], &lbf[spos+10*qdim], &lbf[spos+12*qdim], &lbf[spos+26*qdim],
                         &lbf[spos+24*qdim], moment);
        uwall[0] -= moment;
        break;
      case PSR:
        fD3Q27PPSRegular(p0, &force[0], &lbf[spos], &lbf[spos+3*qdim],
                         &lbf[spos+1*qdim], &lbf[spos+2*qdim], &lbf[spos+6*qdim], &lbf[spos+20*qdim],
                         &lbf[spos+8*qdim], &lbf[spos+22*qdim], &lbf[spos+4*qdim], &lbf[spos+5*qdim],
                         &lbf[spos+10*qdim], &lbf[spos+12*qdim], &lbf[spos+26*qdim], &lbf[spos+24*qdim],
                         &lbf[spos+16*qdim], &lbf[spos+14*qdim], &lbf[spos+15*qdim], &lbf[spos+19*qdim],
                         &lbf[spos+7*qdim], &lbf[spos+21*qdim], &lbf[spos+9*qdim], &lbf[spos+17*qdim],
                         &lbf[spos+18*qdim], &lbf[spos+23*qdim], &lbf[spos+25*qdim], &lbf[spos+13*qdim],
                         &lbf[spos+11*qdim], moment);
        uwall[0] += moment;
        break;
      case PSF:
        fD3Q27PPSRegular(p0, &force[0], &lbf[spos], &lbf[spos+15*qdim],
                         &lbf[spos+16*qdim], &lbf[spos+14*qdim], &lbf[spos+21*qdim], &lbf[spos+22*qdim],
                         &lbf[spos+17*qdim], &lbf[spos+5*qdim], &lbf[spos+19*qdim], &lbf[spos+7*qdim],
                         &lbf[spos+23*qdim], &lbf[spos+13*qdim], &lbf[spos+24*qdim], &lbf[spos+12*qdim],
                         &lbf[spos+2*qdim], &lbf[spos+3*qdim], &lbf[spos+1*qdim], &lbf[spos+8*qdim],
                         &lbf[spos+9*qdim], &lbf[spos+4*qdim], &lbf[spos+18*qdim], &lbf[spos+6*qdim],
                         &lbf[spos+20*qdim], &lbf[spos+10*qdim], &lbf[spos+26*qdim], &lbf[spos+11*qdim],
                         &lbf[spos+25*qdim], moment);
        uwall[2] -= moment;
        break;
      case PSB:
        fD3Q27PPSRegular(p0, &force[0], &lbf[spos], &lbf[spos+2*qdim],
                         &lbf[spos+3*qdim], &lbf[spos+1*qdim], &lbf[spos+8*qdim], &lbf[spos+9*qdim],
                         &lbf[spos+4*qdim], &lbf[spos+18*qdim], &lbf[spos+6*qdim], &lbf[spos+20*qdim],
                         &lbf[spos+10*qdim], &lbf[spos+26*qdim], &lbf[spos+11*qdim], &lbf[spos+25*qdim],
                         &lbf[spos+15*qdim], &lbf[spos+16*qdim], &lbf[spos+14*qdim], &lbf[spos+21*qdim],
                         &lbf[spos+22*qdim], &lbf[spos+17*qdim], &lbf[spos+5*qdim], &lbf[spos+19*qdim],
                         &lbf[spos+7*qdim], &lbf[spos+23*qdim], &lbf[spos+13*qdim], &lbf[spos+24*qdim],
                         &lbf[spos+12*qdim], moment);
        uwall[2] += moment;
        break;
      case CCTRB:
        fD3Q27VCCCLBERegular(p0, uwall[0], uwall[1], -uwall[2], &force[0], &lbf[spos], &lbf[spos+1*qdim],
                             &lbf[spos+2*qdim], &lbf[spos+16*qdim], &lbf[spos+4*qdim], &lbf[spos+5*qdim],
                             &lbf[spos+7*qdim], &lbf[spos+6*qdim], &lbf[spos+9*qdim], &lbf[spos+8*qdim],
                             &lbf[spos+11*qdim], &lbf[spos+10*qdim], &lbf[spos+13*qdim], &lbf[spos+12*qdim],
                             &lbf[spos+14*qdim], &lbf[spos+15*qdim], &lbf[spos+3*qdim], &lbf[spos+17*qdim],
                             &lbf[spos+18*qdim], &lbf[spos+20*qdim], &lbf[spos+19*qdim], &lbf[spos+22*qdim],
                             &lbf[spos+21*qdim], &lbf[spos+24*qdim], &lbf[spos+23*qdim], &lbf[spos+26*qdim],
                             &lbf[spos+25*qdim]);
        break;
      case CCTLB:
        fD3Q27VCCCLBERegular(p0, -uwall[0], uwall[1], -uwall[2], &force[0], &lbf[spos], &lbf[spos+14*qdim],
                             &lbf[spos+2*qdim], &lbf[spos+16*qdim], &lbf[spos+18*qdim], &lbf[spos+17*qdim],
                             &lbf[spos+19*qdim], &lbf[spos+20*qdim], &lbf[spos+9*qdim], &lbf[spos+8*qdim],
                             &lbf[spos+25*qdim], &lbf[spos+26*qdim], &lbf[spos+23*qdim], &lbf[spos+24*qdim],
                             &lbf[spos+1*qdim], &lbf[spos+15*qdim], &lbf[spos+3*qdim], &lbf[spos+5*qdim],
                             &lbf[spos+4*qdim], &lbf[spos+6*qdim], &lbf[spos+7*qdim], &lbf[spos+22*qdim],
                             &lbf[spos+21*qdim], &lbf[spos+12*qdim], &lbf[spos+13*qdim], &lbf[spos+10*qdim],
                             &lbf[spos+11*qdim]);
        break;
      case CCDLB:
        fD3Q27VCCCLBERegular(p0, -uwall[0], -uwall[1], -uwall[2], &force[0], &lbf[spos], &lbf[spos+14*qdim],
                             &lbf[spos+15*qdim], &lbf[spos+16*qdim], &lbf[spos+17*qdim], &lbf[spos+18*qdim],
                             &lbf[spos+19*qdim], &lbf[spos+20*qdim], &lbf[spos+21*qdim], &lbf[spos+22*qdim],
                             &lbf[spos+23*qdim], &lbf[spos+24*qdim], &lbf[spos+25*qdim], &lbf[spos+26*qdim],
                             &lbf[spos+1*qdim], &lbf[spos+2*qdim], &lbf[spos+3*qdim], &lbf[spos+4*qdim],
                             &lbf[spos+5*qdim], &lbf[spos+6*qdim], &lbf[spos+7*qdim], &lbf[spos+8*qdim],
                             &lbf[spos+9*qdim], &lbf[spos+10*qdim], &lbf[spos+11*qdim], &lbf[spos+12*qdim],
                             &lbf[spos+13*qdim]);
        break;
      case CCDRB:
        fD3Q27VCCCLBERegular(p0, uwall[0], -uwall[1], -uwall[2], &force[0], &lbf[spos], &lbf[spos+1*qdim],
                             &lbf[spos+15*qdim], &lbf[spos+16*qdim], &lbf[spos+5*qdim], &lbf[spos+4*qdim],
                             &lbf[spos+7*qdim], &lbf[spos+6*qdim], &lbf[spos+21*qdim], &lbf[spos+22*qdim],
                             &lbf[spos+13*qdim], &lbf[spos+12*qdim], &lbf[spos+11*qdim], &lbf[spos+10*qdim],
                             &lbf[spos+14*qdim], &lbf[spos+2*qdim], &lbf[spos+3*qdim], &lbf[spos+18*qdim],
                             &lbf[spos+17*qdim], &lbf[spos+20*qdim], &lbf[spos+19*qdim], &lbf[spos+8*qdim],
                             &lbf[spos+9*qdim], &lbf[spos+26*qdim], &lbf[spos+25*qdim], &lbf[spos+24*qdim],
                             &lbf[spos+23*qdim]);
        break;
      case CCTRF:
        fD3Q27VCCCLBERegular(p0, uwall[0], uwall[1], uwall[2], &force[0], &lbf[spos], &lbf[spos+1*qdim],
                             &lbf[spos+2*qdim], &lbf[spos+3*qdim], &lbf[spos+4*qdim], &lbf[spos+5*qdim],
                             &lbf[spos+6*qdim], &lbf[spos+7*qdim], &lbf[spos+8*qdim], &lbf[spos+9*qdim],
                             &lbf[spos+10*qdim], &lbf[spos+11*qdim], &lbf[spos+12*qdim], &lbf[spos+13*qdim],
                             &lbf[spos+14*qdim], &lbf[spos+15*qdim], &lbf[spos+16*qdim], &lbf[spos+17*qdim],
                             &lbf[spos+18*qdim], &lbf[spos+19*qdim], &lbf[spos+20*qdim], &lbf[spos+21*qdim],
                             &lbf[spos+22*qdim], &lbf[spos+23*qdim], &lbf[spos+24*qdim], &lbf[spos+25*qdim],
                             &lbf[spos+26*qdim]);
        break;
      case CCTLF:
        fD3Q27VCCCLBERegular(p0, -uwall[0], uwall[1], uwall[2], &force[0], &lbf[spos], &lbf[spos+14*qdim],
                             &lbf[spos+2*qdim], &lbf[spos+3*qdim], &lbf[spos+18*qdim], &lbf[spos+17*qdim],
                             &lbf[spos+20*qdim], &lbf[spos+19*qdim], &lbf[spos+8*qdim], &lbf[spos+9*qdim],
                             &lbf[spos+26*qdim], &lbf[spos+25*qdim], &lbf[spos+24*qdim], &lbf[spos+23*qdim],
                             &lbf[spos+1*qdim], &lbf[spos+15*qdim], &lbf[spos+16*qdim], &lbf[spos+5*qdim],
                             &lbf[spos+4*qdim], &lbf[spos+7*qdim], &lbf[spos+6*qdim], &lbf[spos+21*qdim],
                             &lbf[spos+22*qdim], &lbf[spos+13*qdim], &lbf[spos+12*qdim], &lbf[spos+11*qdim],
                             &lbf[spos+10*qdim]);
        break;
      case CCDLF:
        fD3Q27VCCCLBERegular(p0, -uwall[0], -uwall[1], uwall[2], &force[0], &lbf[spos], &lbf[spos+14*qdim],
                             &lbf[spos+15*qdim], &lbf[spos+3*qdim], &lbf[spos+17*qdim], &lbf[spos+18*qdim],
                             &lbf[spos+20*qdim], &lbf[spos+19*qdim], &lbf[spos+22*qdim], &lbf[spos+21*qdim],
                             &lbf[spos+24*qdim], &lbf[spos+23*qdim], &lbf[spos+26*qdim], &lbf[spos+25*qdim],
                             &lbf[spos+1*qdim], &lbf[spos+2*qdim], &lbf[spos+16*qdim], &lbf[spos+4*qdim],
                             &lbf[spos+5*qdim], &lbf[spos+7*qdim], &lbf[spos+6*qdim], &lbf[spos+9*qdim],
                             &lbf[spos+8*qdim], &lbf[spos+11*qdim], &lbf[spos+10*qdim], &lbf[spos+13*qdim],
                             &lbf[spos+12*qdim]);
        break;
      case CCDRF:
        fD3Q27VCCCLBERegular(p0, uwall[0], -uwall[1], uwall[2], &force[0], &lbf[spos], &lbf[spos+1*qdim],
                             &lbf[spos+15*qdim], &lbf[spos+3*qdim], &lbf[spos+5*qdim], &lbf[spos+4*qdim],
                             &lbf[spos+6*qdim], &lbf[spos+7*qdim], &lbf[spos+22*qdim], &lbf[spos+21*qdim],
                             &lbf[spos+12*qdim], &lbf[spos+13*qdim], &lbf[spos+10*qdim], &lbf[spos+11*qdim],
                             &lbf[spos+14*qdim], &lbf[spos+2*qdim], &lbf[spos+16*qdim], &lbf[spos+18*qdim],
                             &lbf[spos+17*qdim], &lbf[spos+19*qdim], &lbf[spos+20*qdim], &lbf[spos+9*qdim],
                             &lbf[spos+8*qdim], &lbf[spos+25*qdim], &lbf[spos+26*qdim], &lbf[spos+23*qdim],
                             &lbf[spos+24*qdim]);
        break;
      case CETR:
        fD3Q27VCECLBERegular(p0, uwall[0], uwall[1], uwall[2], &force[0], &lbf[spos], &lbf[spos+1*qdim],
                             &lbf[spos+2*qdim], &lbf[spos+3*qdim], &lbf[spos+4*qdim], &lbf[spos+5*qdim],
                             &lbf[spos+6*qdim], &lbf[spos+7*qdim], &lbf[spos+8*qdim], &lbf[spos+9*qdim],
                             &lbf[spos+10*qdim], &lbf[spos+11*qdim], &lbf[spos+12*qdim], &lbf[spos+13*qdim],
                             &lbf[spos+14*qdim], &lbf[spos+15*qdim], &lbf[spos+16*qdim], &lbf[spos+17*qdim],
                             &lbf[spos+18*qdim], &lbf[spos+19*qdim], &lbf[spos+20*qdim], &lbf[spos+21*qdim],
                             &lbf[spos+22*qdim], &lbf[spos+23*qdim], &lbf[spos+24*qdim], &lbf[spos+25*qdim],
                             &lbf[spos+26*qdim]);
        break;
      case CETL:
        fD3Q27VCECLBERegular(p0, uwall[1], -uwall[0], uwall[2], &force[0], &lbf[spos], &lbf[spos+2*qdim],
                             &lbf[spos+14*qdim], &lbf[spos+3*qdim], &lbf[spos+18*qdim], &lbf[spos+4*qdim],
                             &lbf[spos+8*qdim], &lbf[spos+9*qdim], &lbf[spos+20*qdim], &lbf[spos+19*qdim],
                             &lbf[spos+26*qdim], &lbf[spos+25*qdim], &lbf[spos+10*qdim], &lbf[spos+11*qdim],
                             &lbf[spos+15*qdim], &lbf[spos+1*qdim], &lbf[spos+16*qdim], &lbf[spos+5*qdim],
                             &lbf[spos+17*qdim], &lbf[spos+21*qdim], &lbf[spos+22*qdim], &lbf[spos+7*qdim],
                             &lbf[spos+6*qdim], &lbf[spos+13*qdim], &lbf[spos+12*qdim], &lbf[spos+23*qdim],
                             &lbf[spos+24*qdim]);
        break;
      case CEDL:
        fD3Q27VCECLBERegular(p0, -uwall[0], -uwall[1], uwall[2], &force[0], &lbf[spos], &lbf[spos+14*qdim],
                             &lbf[spos+15*qdim], &lbf[spos+3*qdim], &lbf[spos+17*qdim], &lbf[spos+18*qdim],
                             &lbf[spos+20*qdim], &lbf[spos+19*qdim], &lbf[spos+22*qdim], &lbf[spos+21*qdim],
                             &lbf[spos+24*qdim], &lbf[spos+23*qdim], &lbf[spos+26*qdim], &lbf[spos+25*qdim],
                             &lbf[spos+1*qdim], &lbf[spos+2*qdim], &lbf[spos+16*qdim], &lbf[spos+4*qdim],
                             &lbf[spos+5*qdim], &lbf[spos+7*qdim], &lbf[spos+6*qdim], &lbf[spos+9*qdim],
                             &lbf[spos+8*qdim], &lbf[spos+11*qdim], &lbf[spos+10*qdim], &lbf[spos+13*qdim],
                             &lbf[spos+12*qdim]);
        break;
      case CEDR:
        fD3Q27VCECLBERegular(p0, -uwall[1], uwall[0], uwall[2], &force[0], &lbf[spos], &lbf[spos+15*qdim],
                             &lbf[spos+1*qdim], &lbf[spos+3*qdim], &lbf[spos+5*qdim], &lbf[spos+17*qdim],
                             &lbf[spos+22*qdim], &lbf[spos+21*qdim], &lbf[spos+6*qdim], &lbf[spos+7*qdim],
                             &lbf[spos+12*qdim], &lbf[spos+13*qdim], &lbf[spos+24*qdim], &lbf[spos+23*qdim],
                             &lbf[spos+2*qdim], &lbf[spos+14*qdim], &lbf[spos+16*qdim], &lbf[spos+18*qdim],
                             &lbf[spos+4*qdim], &lbf[spos+9*qdim], &lbf[spos+8*qdim], &lbf[spos+19*qdim],
                             &lbf[spos+20*qdim], &lbf[spos+25*qdim], &lbf[spos+26*qdim], &lbf[spos+11*qdim],
                             &lbf[spos+10*qdim]);
        break;
      case CETF:
        fD3Q27VCECLBERegular(p0, uwall[1], uwall[2], uwall[0], &force[0], &lbf[spos], &lbf[spos+2*qdim],
                             &lbf[spos+3*qdim], &lbf[spos+1*qdim], &lbf[spos+8*qdim], &lbf[spos+9*qdim],
                             &lbf[spos+4*qdim], &lbf[spos+18*qdim], &lbf[spos+6*qdim], &lbf[spos+20*qdim],
                             &lbf[spos+10*qdim], &lbf[spos+26*qdim], &lbf[spos+11*qdim], &lbf[spos+25*qdim],
                             &lbf[spos+15*qdim], &lbf[spos+16*qdim], &lbf[spos+14*qdim], &lbf[spos+21*qdim],
                             &lbf[spos+22*qdim], &lbf[spos+17*qdim], &lbf[spos+5*qdim], &lbf[spos+19*qdim],
                             &lbf[spos+7*qdim], &lbf[spos+23*qdim], &lbf[spos+13*qdim], &lbf[spos+24*qdim],
                             &lbf[spos+12*qdim]);
        break;
      case CELF:
        fD3Q27VCECLBERegular(p0, -uwall[0], uwall[1], uwall[2], &force[0], &lbf[spos], &lbf[spos+14*qdim],
                             &lbf[spos+3*qdim], &lbf[spos+2*qdim], &lbf[spos+20*qdim], &lbf[spos+19*qdim],
                             &lbf[spos+18*qdim], &lbf[spos+17*qdim], &lbf[spos+8*qdim], &lbf[spos+22*qdim],
                             &lbf[spos+26*qdim], &lbf[spos+24*qdim], &lbf[spos+25*qdim], &lbf[spos+23*qdim],
                             &lbf[spos+1*qdim], &lbf[spos+16*qdim], &lbf[spos+15*qdim], &lbf[spos+7*qdim],
                             &lbf[spos+6*qdim], &lbf[spos+5*qdim], &lbf[spos+4*qdim], &lbf[spos+21*qdim],
                             &lbf[spos+9*qdim], &lbf[spos+13*qdim], &lbf[spos+11*qdim], &lbf[spos+12*qdim],
                             &lbf[spos+10*qdim]);
        break;
      case CEDF:
        fD3Q27VCECLBERegular(p0, -uwall[1], uwall[2], uwall[0], &force[0], &lbf[spos], &lbf[spos+15*qdim],
                             &lbf[spos+3*qdim], &lbf[spos+1*qdim], &lbf[spos+22*qdim], &lbf[spos+21*qdim],
                             &lbf[spos+5*qdim], &lbf[spos+17*qdim], &lbf[spos+6*qdim], &lbf[spos+20*qdim],
                             &lbf[spos+12*qdim], &lbf[spos+24*qdim], &lbf[spos+13*qdim], &lbf[spos+23*qdim],
                             &lbf[spos+2*qdim], &lbf[spos+16*qdim], &lbf[spos+14*qdim], &lbf[spos+9*qdim],
                             &lbf[spos+8*qdim], &lbf[spos+18*qdim], &lbf[spos+4*qdim], &lbf[spos+19*qdim],
                             &lbf[spos+7*qdim], &lbf[spos+25*qdim], &lbf[spos+11*qdim], &lbf[spos+26*qdim],
                             &lbf[spos+10*qdim]);
        break;
      case CERF:
        fD3Q27VCECLBERegular(p0, uwall[0], uwall[2], uwall[2], &force[0], &lbf[spos], &lbf[spos+1*qdim],
                             &lbf[spos+3*qdim], &lbf[spos+2*qdim], &lbf[spos+6*qdim], &lbf[spos+7*qdim],
                             &lbf[spos+4*qdim], &lbf[spos+5*qdim], &lbf[spos+8*qdim], &lbf[spos+22*qdim],
                             &lbf[spos+10*qdim], &lbf[spos+12*qdim], &lbf[spos+11*qdim], &lbf[spos+13*qdim],
                             &lbf[spos+14*qdim], &lbf[spos+16*qdim], &lbf[spos+15*qdim], &lbf[spos+19*qdim],
                             &lbf[spos+20*qdim], &lbf[spos+17*qdim], &lbf[spos+18*qdim], &lbf[spos+21*qdim],
                             &lbf[spos+9*qdim], &lbf[spos+23*qdim], &lbf[spos+25*qdim], &lbf[spos+24*qdim],
                             &lbf[spos+26*qdim]);
        break;
      case CETB:
        fD3Q27VCECLBERegular(p0, uwall[1], -uwall[2], uwall[0], &force[0], &lbf[spos], &lbf[spos+2*qdim],
                             &lbf[spos+16*qdim], &lbf[spos+1*qdim], &lbf[spos+9*qdim], &lbf[spos+8*qdim],
                             &lbf[spos+4*qdim], &lbf[spos+18*qdim], &lbf[spos+7*qdim], &lbf[spos+19*qdim],
                             &lbf[spos+11*qdim], &lbf[spos+25*qdim], &lbf[spos+10*qdim], &lbf[spos+26*qdim],
                             &lbf[spos+15*qdim], &lbf[spos+3*qdim], &lbf[spos+14*qdim], &lbf[spos+22*qdim],
                             &lbf[spos+21*qdim], &lbf[spos+17*qdim], &lbf[spos+5*qdim], &lbf[spos+20*qdim],
                             &lbf[spos+6*qdim], &lbf[spos+24*qdim], &lbf[spos+12*qdim], &lbf[spos+23*qdim],
                             &lbf[spos+13*qdim]);
        break;
      case CELB:
        fD3Q27VCECLBERegular(p0, -uwall[0], -uwall[2], uwall[1], &force[0], &lbf[spos], &lbf[spos+14*qdim],
                             &lbf[spos+16*qdim], &lbf[spos+2*qdim], &lbf[spos+19*qdim], &lbf[spos+20*qdim],
                             &lbf[spos+18*qdim], &lbf[spos+17*qdim], &lbf[spos+9*qdim], &lbf[spos+21*qdim],
                             &lbf[spos+25*qdim], &lbf[spos+23*qdim], &lbf[spos+26*qdim], &lbf[spos+24*qdim],
                             &lbf[spos+1*qdim], &lbf[spos+3*qdim], &lbf[spos+15*qdim], &lbf[spos+6*qdim],
                             &lbf[spos+7*qdim], &lbf[spos+5*qdim], &lbf[spos+4*qdim], &lbf[spos+22*qdim],
                             &lbf[spos+8*qdim], &lbf[spos+12*qdim], &lbf[spos+10*qdim], &lbf[spos+13*qdim],
                             &lbf[spos+11*qdim]);
        break;
      case CEDB:
        fD3Q27VCECLBERegular(p0, -uwall[1], -uwall[2], uwall[0], &force[0], &lbf[spos], &lbf[spos+15*qdim],
                             &lbf[spos+16*qdim], &lbf[spos+1*qdim], &lbf[spos+21*qdim], &lbf[spos+22*qdim],
                             &lbf[spos+5*qdim], &lbf[spos+17*qdim], &lbf[spos+7*qdim], &lbf[spos+19*qdim],
                             &lbf[spos+13*qdim], &lbf[spos+23*qdim], &lbf[spos+12*qdim], &lbf[spos+24*qdim],
                             &lbf[spos+2*qdim], &lbf[spos+3*qdim], &lbf[spos+14*qdim], &lbf[spos+8*qdim],
                             &lbf[spos+9*qdim], &lbf[spos+18*qdim], &lbf[spos+4*qdim], &lbf[spos+20*qdim],
                             &lbf[spos+6*qdim], &lbf[spos+26*qdim], &lbf[spos+10*qdim], &lbf[spos+25*qdim],
                             &lbf[spos+11*qdim]);
        break;
      case CERB:
        fD3Q27VCECLBERegular(p0, uwall[0], -uwall[2], uwall[1], &force[0], &lbf[spos], &lbf[spos+1*qdim],
                             &lbf[spos+16*qdim], &lbf[spos+2*qdim], &lbf[spos+7*qdim], &lbf[spos+6*qdim],
                             &lbf[spos+4*qdim], &lbf[spos+5*qdim], &lbf[spos+9*qdim], &lbf[spos+21*qdim],
                             &lbf[spos+11*qdim], &lbf[spos+13*qdim], &lbf[spos+10*qdim], &lbf[spos+12*qdim],
                             &lbf[spos+14*qdim], &lbf[spos+3*qdim], &lbf[spos+15*qdim], &lbf[spos+20*qdim],
                             &lbf[spos+19*qdim], &lbf[spos+17*qdim], &lbf[spos+18*qdim], &lbf[spos+22*qdim],
                             &lbf[spos+8*qdim], &lbf[spos+24*qdim], &lbf[spos+26*qdim], &lbf[spos+23*qdim],
                             &lbf[spos+25*qdim]);
        break;
    }
  }
  else {
    switch (prop) {
      case PST:
        fD3Q27PPSRegular(p0, &force[0], &lbf[spos], &lbf[spos+1*qdim],
                         &lbf[spos+2*qdim], &lbf[spos+3*qdim], &lbf[spos+4*qdim], &lbf[spos+5*qdim],
                         &lbf[spos+6*qdim], &lbf[spos+7*qdim], &lbf[spos+8*qdim], &lbf[spos+9*qdim],
                         &lbf[spos+10*qdim], &lbf[spos+11*qdim], &lbf[spos+12*qdim], &lbf[spos+13*qdim],
                         &lbf[spos+14*qdim], &lbf[spos+15*qdim], &lbf[spos+16*qdim], &lbf[spos+17*qdim],
                         &lbf[spos+18*qdim], &lbf[spos+19*qdim], &lbf[spos+20*qdim], &lbf[spos+21*qdim],
                         &lbf[spos+22*qdim], &lbf[spos+23*qdim], &lbf[spos+24*qdim], &lbf[spos+25*qdim],
                         &lbf[spos+26*qdim], moment);
        uwall[1] += moment;
        break;
      case PSD:
        fD3Q27PPSRegular(p0, &force[0], &lbf[spos], &lbf[spos+14*qdim],
                         &lbf[spos+15*qdim], &lbf[spos+16*qdim], &lbf[spos+17*qdim], &lbf[spos+18*qdim],
                         &lbf[spos+19*qdim], &lbf[spos+20*qdim], &lbf[spos+21*qdim], &lbf[spos+22*qdim],
                         &lbf[spos+23*qdim], &lbf[spos+24*qdim], &lbf[spos+25*qdim], &lbf[spos+26*qdim],
                         &lbf[spos+1*qdim], &lbf[spos+2*qdim], &lbf[spos+3*qdim], &lbf[spos+4*qdim],
                         &lbf[spos+5*qdim], &lbf[spos+6*qdim], &lbf[spos+7*qdim], &lbf[spos+8*qdim],
                         &lbf[spos+9*qdim], &lbf[spos+10*qdim], &lbf[spos+11*qdim], &lbf[spos+12*qdim],
                         &lbf[spos+13*qdim], moment);
        uwall[1] -= moment;
        break;
      case PSL:
        fD3Q27PPSRegular(p0, &force[0], &lbf[spos], &lbf[spos+16*qdim],
                         &lbf[spos+14*qdim], &lbf[spos+15*qdim], &lbf[spos+19*qdim], &lbf[spos+7*qdim],
                         &lbf[spos+21*qdim], &lbf[spos+9*qdim], &lbf[spos+17*qdim], &lbf[spos+18*qdim],
                         &lbf[spos+23*qdim], &lbf[spos+25*qdim], &lbf[spos+13*qdim], &lbf[spos+11*qdim],
                         &lbf[spos+3*qdim], &lbf[spos+1*qdim], &lbf[spos+2*qdim], &lbf[spos+6*qdim],
                         &lbf[spos+20*qdim], &lbf[spos+8*qdim], &lbf[spos+22*qdim], &lbf[spos+4*qdim],
                         &lbf[spos+5*qdim], &lbf[spos+10*qdim], &lbf[spos+12*qdim], &lbf[spos+26*qdim],
                         &lbf[spos+24*qdim], moment);
        uwall[0] -= moment;
        break;
      case PSR:
        fD3Q27PPSRegular(p0, &force[0], &lbf[spos], &lbf[spos+3*qdim],
                         &lbf[spos+1*qdim], &lbf[spos+2*qdim], &lbf[spos+6*qdim], &lbf[spos+20*qdim],
                         &lbf[spos+8*qdim], &lbf[spos+22*qdim], &lbf[spos+4*qdim], &lbf[spos+5*qdim],
                         &lbf[spos+10*qdim], &lbf[spos+12*qdim], &lbf[spos+26*qdim], &lbf[spos+24*qdim],
                         &lbf[spos+16*qdim], &lbf[spos+14*qdim], &lbf[spos+15*qdim], &lbf[spos+19*qdim],
                         &lbf[spos+7*qdim], &lbf[spos+21*qdim], &lbf[spos+9*qdim], &lbf[spos+17*qdim],
                         &lbf[spos+18*qdim], &lbf[spos+23*qdim], &lbf[spos+25*qdim], &lbf[spos+13*qdim],
                         &lbf[spos+11*qdim], moment);
        uwall[0] += moment;
        break;
      case PSF:
        fD3Q27PPSRegular(p0, &force[0], &lbf[spos], &lbf[spos+15*qdim],
                         &lbf[spos+16*qdim], &lbf[spos+14*qdim], &lbf[spos+21*qdim], &lbf[spos+22*qdim],
                         &lbf[spos+17*qdim], &lbf[spos+5*qdim], &lbf[spos+19*qdim], &lbf[spos+7*qdim],
                         &lbf[spos+23*qdim], &lbf[spos+13*qdim], &lbf[spos+24*qdim], &lbf[spos+12*qdim],
                         &lbf[spos+2*qdim], &lbf[spos+3*qdim], &lbf[spos+1*qdim], &lbf[spos+8*qdim],
                         &lbf[spos+9*qdim], &lbf[spos+4*qdim], &lbf[spos+18*qdim], &lbf[spos+6*qdim],
                         &lbf[spos+20*qdim], &lbf[spos+10*qdim], &lbf[spos+26*qdim], &lbf[spos+11*qdim],
                         &lbf[spos+25*qdim], moment);
        uwall[2] -= moment;
        break;
      case PSB:
        fD3Q27PPSRegular(p0, &force[0], &lbf[spos], &lbf[spos+2*qdim],
                         &lbf[spos+3*qdim], &lbf[spos+1*qdim], &lbf[spos+8*qdim], &lbf[spos+9*qdim],
                         &lbf[spos+4*qdim], &lbf[spos+18*qdim], &lbf[spos+6*qdim], &lbf[spos+20*qdim],
                         &lbf[spos+10*qdim], &lbf[spos+26*qdim], &lbf[spos+11*qdim], &lbf[spos+25*qdim],
                         &lbf[spos+15*qdim], &lbf[spos+16*qdim], &lbf[spos+14*qdim], &lbf[spos+21*qdim],
                         &lbf[spos+22*qdim], &lbf[spos+17*qdim], &lbf[spos+5*qdim], &lbf[spos+19*qdim],
                         &lbf[spos+7*qdim], &lbf[spos+23*qdim], &lbf[spos+13*qdim], &lbf[spos+24*qdim],
                         &lbf[spos+12*qdim], moment);
        uwall[2] += moment;
        break;
      case CCTRB:
        fD3Q27VCCRegular(p0, uwall[0], uwall[1], -uwall[2], &force[0], &lbf[spos], &lbf[spos+1*qdim],
                         &lbf[spos+2*qdim], &lbf[spos+16*qdim], &lbf[spos+4*qdim], &lbf[spos+5*qdim],
                         &lbf[spos+7*qdim], &lbf[spos+6*qdim], &lbf[spos+9*qdim], &lbf[spos+8*qdim],
                         &lbf[spos+11*qdim], &lbf[spos+10*qdim], &lbf[spos+13*qdim], &lbf[spos+12*qdim],
                         &lbf[spos+14*qdim], &lbf[spos+15*qdim], &lbf[spos+3*qdim], &lbf[spos+17*qdim],
                         &lbf[spos+18*qdim], &lbf[spos+20*qdim], &lbf[spos+19*qdim], &lbf[spos+22*qdim],
                         &lbf[spos+21*qdim], &lbf[spos+24*qdim], &lbf[spos+23*qdim], &lbf[spos+26*qdim],
                         &lbf[spos+25*qdim]);
        break;
      case CCTLB:
        fD3Q27VCCRegular(p0, -uwall[0], uwall[1], -uwall[2], &force[0], &lbf[spos], &lbf[spos+14*qdim],
                         &lbf[spos+2*qdim], &lbf[spos+16*qdim], &lbf[spos+18*qdim], &lbf[spos+17*qdim],
                         &lbf[spos+19*qdim], &lbf[spos+20*qdim], &lbf[spos+9*qdim], &lbf[spos+8*qdim],
                         &lbf[spos+25*qdim], &lbf[spos+26*qdim], &lbf[spos+23*qdim], &lbf[spos+24*qdim],
                         &lbf[spos+1*qdim], &lbf[spos+15*qdim], &lbf[spos+3*qdim], &lbf[spos+5*qdim],
                         &lbf[spos+4*qdim], &lbf[spos+6*qdim], &lbf[spos+7*qdim], &lbf[spos+22*qdim],
                         &lbf[spos+21*qdim], &lbf[spos+12*qdim], &lbf[spos+13*qdim], &lbf[spos+10*qdim],
                         &lbf[spos+11*qdim]);
        break;
      case CCDLB:
        fD3Q27VCCRegular(p0, -uwall[0], -uwall[1], -uwall[2], &force[0], &lbf[spos], &lbf[spos+14*qdim],
                         &lbf[spos+15*qdim], &lbf[spos+16*qdim], &lbf[spos+17*qdim], &lbf[spos+18*qdim],
                         &lbf[spos+19*qdim], &lbf[spos+20*qdim], &lbf[spos+21*qdim], &lbf[spos+22*qdim],
                         &lbf[spos+23*qdim], &lbf[spos+24*qdim], &lbf[spos+25*qdim], &lbf[spos+26*qdim],
                         &lbf[spos+1*qdim], &lbf[spos+2*qdim], &lbf[spos+3*qdim], &lbf[spos+4*qdim],
                         &lbf[spos+5*qdim], &lbf[spos+6*qdim], &lbf[spos+7*qdim], &lbf[spos+8*qdim],
                         &lbf[spos+9*qdim], &lbf[spos+10*qdim], &lbf[spos+11*qdim], &lbf[spos+12*qdim],
                         &lbf[spos+13*qdim]);
        break;
      case CCDRB:
        fD3Q27VCCRegular(p0, uwall[0], -uwall[1], -uwall[2], &force[0], &lbf[spos], &lbf[spos+1*qdim],
                         &lbf[spos+15*qdim], &lbf[spos+16*qdim], &lbf[spos+5*qdim], &lbf[spos+4*qdim],
                         &lbf[spos+7*qdim], &lbf[spos+6*qdim], &lbf[spos+21*qdim], &lbf[spos+22*qdim],
                         &lbf[spos+13*qdim], &lbf[spos+12*qdim], &lbf[spos+11*qdim], &lbf[spos+10*qdim],
                         &lbf[spos+14*qdim], &lbf[spos+2*qdim], &lbf[spos+3*qdim], &lbf[spos+18*qdim],
                         &lbf[spos+17*qdim], &lbf[spos+20*qdim], &lbf[spos+19*qdim], &lbf[spos+8*qdim],
                         &lbf[spos+9*qdim], &lbf[spos+26*qdim], &lbf[spos+25*qdim], &lbf[spos+24*qdim],
                         &lbf[spos+23*qdim]);
        break;
      case CCTRF:
        fD3Q27VCCRegular(p0, uwall[0], uwall[1], uwall[2], &force[0], &lbf[spos], &lbf[spos+1*qdim],
                         &lbf[spos+2*qdim], &lbf[spos+3*qdim], &lbf[spos+4*qdim], &lbf[spos+5*qdim],
                         &lbf[spos+6*qdim], &lbf[spos+7*qdim], &lbf[spos+8*qdim], &lbf[spos+9*qdim],
                         &lbf[spos+10*qdim], &lbf[spos+11*qdim], &lbf[spos+12*qdim], &lbf[spos+13*qdim],
                         &lbf[spos+14*qdim], &lbf[spos+15*qdim], &lbf[spos+16*qdim], &lbf[spos+17*qdim],
                         &lbf[spos+18*qdim], &lbf[spos+19*qdim], &lbf[spos+20*qdim], &lbf[spos+21*qdim],
                         &lbf[spos+22*qdim], &lbf[spos+23*qdim], &lbf[spos+24*qdim], &lbf[spos+25*qdim],
                         &lbf[spos+26*qdim]);
        break;
      case CCTLF:
        fD3Q27VCCRegular(p0, -uwall[0], uwall[1], uwall[2], &force[0], &lbf[spos], &lbf[spos+14*qdim],
                         &lbf[spos+2*qdim], &lbf[spos+3*qdim], &lbf[spos+18*qdim], &lbf[spos+17*qdim],
                         &lbf[spos+20*qdim], &lbf[spos+19*qdim], &lbf[spos+8*qdim], &lbf[spos+9*qdim],
                         &lbf[spos+26*qdim], &lbf[spos+25*qdim], &lbf[spos+24*qdim], &lbf[spos+23*qdim],
                         &lbf[spos+1*qdim], &lbf[spos+15*qdim], &lbf[spos+16*qdim], &lbf[spos+5*qdim],
                         &lbf[spos+4*qdim], &lbf[spos+7*qdim], &lbf[spos+6*qdim], &lbf[spos+21*qdim],
                         &lbf[spos+22*qdim], &lbf[spos+13*qdim], &lbf[spos+12*qdim], &lbf[spos+11*qdim],
                         &lbf[spos+10*qdim]);
        break;
      case CCDLF:
        fD3Q27VCCRegular(p0, -uwall[0], -uwall[1], uwall[2], &force[0], &lbf[spos], &lbf[spos+14*qdim],
                         &lbf[spos+15*qdim], &lbf[spos+3*qdim], &lbf[spos+17*qdim], &lbf[spos+18*qdim],
                         &lbf[spos+20*qdim], &lbf[spos+19*qdim], &lbf[spos+22*qdim], &lbf[spos+21*qdim],
                         &lbf[spos+24*qdim], &lbf[spos+23*qdim], &lbf[spos+26*qdim], &lbf[spos+25*qdim],
                         &lbf[spos+1*qdim], &lbf[spos+2*qdim], &lbf[spos+16*qdim], &lbf[spos+4*qdim],
                         &lbf[spos+5*qdim], &lbf[spos+7*qdim], &lbf[spos+6*qdim], &lbf[spos+9*qdim],
                         &lbf[spos+8*qdim], &lbf[spos+11*qdim], &lbf[spos+10*qdim], &lbf[spos+13*qdim],
                         &lbf[spos+12*qdim]);
        break;
      case CCDRF:
        fD3Q27VCCRegular(p0, uwall[0], -uwall[1], uwall[2], &force[0], &lbf[spos], &lbf[spos+1*qdim],
                         &lbf[spos+15*qdim], &lbf[spos+3*qdim], &lbf[spos+5*qdim], &lbf[spos+4*qdim],
                         &lbf[spos+6*qdim], &lbf[spos+7*qdim], &lbf[spos+22*qdim], &lbf[spos+21*qdim],
                         &lbf[spos+12*qdim], &lbf[spos+13*qdim], &lbf[spos+10*qdim], &lbf[spos+11*qdim],
                         &lbf[spos+14*qdim], &lbf[spos+2*qdim], &lbf[spos+16*qdim], &lbf[spos+18*qdim],
                         &lbf[spos+17*qdim], &lbf[spos+19*qdim], &lbf[spos+20*qdim], &lbf[spos+9*qdim],
                         &lbf[spos+8*qdim], &lbf[spos+25*qdim], &lbf[spos+26*qdim], &lbf[spos+23*qdim],
                         &lbf[spos+24*qdim]);
        break;
      case CETR:
        fD3Q27VCERegular(p0, uwall[0], uwall[1], uwall[2], &force[0], &lbf[spos], &lbf[spos+1*qdim],
                         &lbf[spos+2*qdim], &lbf[spos+3*qdim], &lbf[spos+4*qdim], &lbf[spos+5*qdim],
                         &lbf[spos+6*qdim], &lbf[spos+7*qdim], &lbf[spos+8*qdim], &lbf[spos+9*qdim],
                         &lbf[spos+10*qdim], &lbf[spos+11*qdim], &lbf[spos+12*qdim], &lbf[spos+13*qdim],
                         &lbf[spos+14*qdim], &lbf[spos+15*qdim], &lbf[spos+16*qdim], &lbf[spos+17*qdim],
                         &lbf[spos+18*qdim], &lbf[spos+19*qdim], &lbf[spos+20*qdim], &lbf[spos+21*qdim],
                         &lbf[spos+22*qdim], &lbf[spos+23*qdim], &lbf[spos+24*qdim], &lbf[spos+25*qdim],
                         &lbf[spos+26*qdim]);
        break;
      case CETL:
        fD3Q27VCERegular(p0, uwall[1], -uwall[0], uwall[2], &force[0], &lbf[spos], &lbf[spos+2*qdim],
                         &lbf[spos+14*qdim], &lbf[spos+3*qdim], &lbf[spos+18*qdim], &lbf[spos+4*qdim],
                         &lbf[spos+8*qdim], &lbf[spos+9*qdim], &lbf[spos+20*qdim], &lbf[spos+19*qdim],
                         &lbf[spos+26*qdim], &lbf[spos+25*qdim], &lbf[spos+10*qdim], &lbf[spos+11*qdim],
                         &lbf[spos+15*qdim], &lbf[spos+1*qdim], &lbf[spos+16*qdim], &lbf[spos+5*qdim],
                         &lbf[spos+17*qdim], &lbf[spos+21*qdim], &lbf[spos+22*qdim], &lbf[spos+7*qdim],
                         &lbf[spos+6*qdim], &lbf[spos+13*qdim], &lbf[spos+12*qdim], &lbf[spos+23*qdim],
                         &lbf[spos+24*qdim]);
        break;
      case CEDL:
        fD3Q27VCERegular(p0, -uwall[0], -uwall[1], uwall[2], &force[0], &lbf[spos], &lbf[spos+14*qdim],
                         &lbf[spos+15*qdim], &lbf[spos+3*qdim], &lbf[spos+17*qdim], &lbf[spos+18*qdim],
                         &lbf[spos+20*qdim], &lbf[spos+19*qdim], &lbf[spos+22*qdim], &lbf[spos+21*qdim],
                         &lbf[spos+24*qdim], &lbf[spos+23*qdim], &lbf[spos+26*qdim], &lbf[spos+25*qdim],
                         &lbf[spos+1*qdim], &lbf[spos+2*qdim], &lbf[spos+16*qdim], &lbf[spos+4*qdim],
                         &lbf[spos+5*qdim], &lbf[spos+7*qdim], &lbf[spos+6*qdim], &lbf[spos+9*qdim],
                         &lbf[spos+8*qdim], &lbf[spos+11*qdim], &lbf[spos+10*qdim], &lbf[spos+13*qdim],
                         &lbf[spos+12*qdim]);
        break;
      case CEDR:
        fD3Q27VCERegular(p0, -uwall[1], uwall[0], uwall[2], &force[0], &lbf[spos], &lbf[spos+15*qdim],
                         &lbf[spos+1*qdim], &lbf[spos+3*qdim], &lbf[spos+5*qdim], &lbf[spos+17*qdim],
                         &lbf[spos+22*qdim], &lbf[spos+21*qdim], &lbf[spos+6*qdim], &lbf[spos+7*qdim],
                         &lbf[spos+12*qdim], &lbf[spos+13*qdim], &lbf[spos+24*qdim], &lbf[spos+23*qdim],
                         &lbf[spos+2*qdim], &lbf[spos+14*qdim], &lbf[spos+16*qdim], &lbf[spos+18*qdim],
                         &lbf[spos+4*qdim], &lbf[spos+9*qdim], &lbf[spos+8*qdim], &lbf[spos+19*qdim],
                         &lbf[spos+20*qdim], &lbf[spos+25*qdim], &lbf[spos+26*qdim], &lbf[spos+11*qdim],
                         &lbf[spos+10*qdim]);
        break;
      case CETF:
        fD3Q27VCERegular(p0, uwall[1], uwall[2], uwall[0], &force[0], &lbf[spos], &lbf[spos+2*qdim],
                         &lbf[spos+3*qdim], &lbf[spos+1*qdim], &lbf[spos+8*qdim], &lbf[spos+9*qdim],
                         &lbf[spos+4*qdim], &lbf[spos+18*qdim], &lbf[spos+6*qdim], &lbf[spos+20*qdim],
                         &lbf[spos+10*qdim], &lbf[spos+26*qdim], &lbf[spos+11*qdim], &lbf[spos+25*qdim],
                         &lbf[spos+15*qdim], &lbf[spos+16*qdim], &lbf[spos+14*qdim], &lbf[spos+21*qdim],
                         &lbf[spos+22*qdim], &lbf[spos+17*qdim], &lbf[spos+5*qdim], &lbf[spos+19*qdim],
                         &lbf[spos+7*qdim], &lbf[spos+23*qdim], &lbf[spos+13*qdim], &lbf[spos+24*qdim],
                         &lbf[spos+12*qdim]);
        break;
      case CELF:
        fD3Q27VCERegular(p0, -uwall[0], uwall[1], uwall[2], &force[0], &lbf[spos], &lbf[spos+14*qdim],
                         &lbf[spos+3*qdim], &lbf[spos+2*qdim], &lbf[spos+20*qdim], &lbf[spos+19*qdim],
                         &lbf[spos+18*qdim], &lbf[spos+17*qdim], &lbf[spos+8*qdim], &lbf[spos+22*qdim],
                         &lbf[spos+26*qdim], &lbf[spos+24*qdim], &lbf[spos+25*qdim], &lbf[spos+23*qdim],
                         &lbf[spos+1*qdim], &lbf[spos+16*qdim], &lbf[spos+15*qdim], &lbf[spos+7*qdim],
                         &lbf[spos+6*qdim], &lbf[spos+5*qdim], &lbf[spos+4*qdim], &lbf[spos+21*qdim],
                         &lbf[spos+9*qdim], &lbf[spos+13*qdim], &lbf[spos+11*qdim], &lbf[spos+12*qdim],
                         &lbf[spos+10*qdim]);
        break;
      case CEDF:
        fD3Q27VCERegular(p0, -uwall[1], uwall[2], uwall[0], &force[0], &lbf[spos], &lbf[spos+15*qdim],
                         &lbf[spos+3*qdim], &lbf[spos+1*qdim], &lbf[spos+22*qdim], &lbf[spos+21*qdim],
                         &lbf[spos+5*qdim], &lbf[spos+17*qdim], &lbf[spos+6*qdim], &lbf[spos+20*qdim],
                         &lbf[spos+12*qdim], &lbf[spos+24*qdim], &lbf[spos+13*qdim], &lbf[spos+23*qdim],
                         &lbf[spos+2*qdim], &lbf[spos+16*qdim], &lbf[spos+14*qdim], &lbf[spos+9*qdim],
                         &lbf[spos+8*qdim], &lbf[spos+18*qdim], &lbf[spos+4*qdim], &lbf[spos+19*qdim],
                         &lbf[spos+7*qdim], &lbf[spos+25*qdim], &lbf[spos+11*qdim], &lbf[spos+26*qdim],
                         &lbf[spos+10*qdim]);
        break;
      case CERF:
        fD3Q27VCERegular(p0, uwall[0], uwall[2], uwall[2], &force[0], &lbf[spos], &lbf[spos+1*qdim],
                         &lbf[spos+3*qdim], &lbf[spos+2*qdim], &lbf[spos+6*qdim], &lbf[spos+7*qdim],
                         &lbf[spos+4*qdim], &lbf[spos+5*qdim], &lbf[spos+8*qdim], &lbf[spos+22*qdim],
                         &lbf[spos+10*qdim], &lbf[spos+12*qdim], &lbf[spos+11*qdim], &lbf[spos+13*qdim],
                         &lbf[spos+14*qdim], &lbf[spos+16*qdim], &lbf[spos+15*qdim], &lbf[spos+19*qdim],
                         &lbf[spos+20*qdim], &lbf[spos+17*qdim], &lbf[spos+18*qdim], &lbf[spos+21*qdim],
                         &lbf[spos+9*qdim], &lbf[spos+23*qdim], &lbf[spos+25*qdim], &lbf[spos+24*qdim],
                         &lbf[spos+26*qdim]);
        break;
      case CETB:
        fD3Q27VCERegular(p0, uwall[1], -uwall[2], uwall[0], &force[0], &lbf[spos], &lbf[spos+2*qdim],
                         &lbf[spos+16*qdim], &lbf[spos+1*qdim], &lbf[spos+9*qdim], &lbf[spos+8*qdim],
                         &lbf[spos+4*qdim], &lbf[spos+18*qdim], &lbf[spos+7*qdim], &lbf[spos+19*qdim],
                         &lbf[spos+11*qdim], &lbf[spos+25*qdim], &lbf[spos+10*qdim], &lbf[spos+26*qdim],
                         &lbf[spos+15*qdim], &lbf[spos+3*qdim], &lbf[spos+14*qdim], &lbf[spos+22*qdim],
                         &lbf[spos+21*qdim], &lbf[spos+17*qdim], &lbf[spos+5*qdim], &lbf[spos+20*qdim],
                         &lbf[spos+6*qdim], &lbf[spos+24*qdim], &lbf[spos+12*qdim], &lbf[spos+23*qdim],
                         &lbf[spos+13*qdim]);
        break;
      case CELB:
        fD3Q27VCERegular(p0, -uwall[0], -uwall[2], uwall[1], &force[0], &lbf[spos], &lbf[spos+14*qdim],
                         &lbf[spos+16*qdim], &lbf[spos+2*qdim], &lbf[spos+19*qdim], &lbf[spos+20*qdim],
                         &lbf[spos+18*qdim], &lbf[spos+17*qdim], &lbf[spos+9*qdim], &lbf[spos+21*qdim],
                         &lbf[spos+25*qdim], &lbf[spos+23*qdim], &lbf[spos+26*qdim], &lbf[spos+24*qdim],
                         &lbf[spos+1*qdim], &lbf[spos+3*qdim], &lbf[spos+15*qdim], &lbf[spos+6*qdim],
                         &lbf[spos+7*qdim], &lbf[spos+5*qdim], &lbf[spos+4*qdim], &lbf[spos+22*qdim],
                         &lbf[spos+8*qdim], &lbf[spos+12*qdim], &lbf[spos+10*qdim], &lbf[spos+13*qdim],
                         &lbf[spos+11*qdim]);
        break;
      case CEDB:
        fD3Q27VCERegular(p0, -uwall[1], -uwall[2], uwall[0], &force[0], &lbf[spos], &lbf[spos+15*qdim],
                         &lbf[spos+16*qdim], &lbf[spos+1*qdim], &lbf[spos+21*qdim], &lbf[spos+22*qdim],
                         &lbf[spos+5*qdim], &lbf[spos+17*qdim], &lbf[spos+7*qdim], &lbf[spos+19*qdim],
                         &lbf[spos+13*qdim], &lbf[spos+23*qdim], &lbf[spos+12*qdim], &lbf[spos+24*qdim],
                         &lbf[spos+2*qdim], &lbf[spos+3*qdim], &lbf[spos+14*qdim], &lbf[spos+8*qdim],
                         &lbf[spos+9*qdim], &lbf[spos+18*qdim], &lbf[spos+4*qdim], &lbf[spos+20*qdim],
                         &lbf[spos+6*qdim], &lbf[spos+26*qdim], &lbf[spos+10*qdim], &lbf[spos+25*qdim],
                         &lbf[spos+11*qdim]);
        break;
      case CERB:
        fD3Q27VCERegular(p0, uwall[0], -uwall[2], uwall[1], &force[0], &lbf[spos], &lbf[spos+1*qdim],
                         &lbf[spos+16*qdim], &lbf[spos+2*qdim], &lbf[spos+7*qdim], &lbf[spos+6*qdim],
                         &lbf[spos+4*qdim], &lbf[spos+5*qdim], &lbf[spos+9*qdim], &lbf[spos+21*qdim],
                         &lbf[spos+11*qdim], &lbf[spos+13*qdim], &lbf[spos+10*qdim], &lbf[spos+12*qdim],
                         &lbf[spos+14*qdim], &lbf[spos+3*qdim], &lbf[spos+15*qdim], &lbf[spos+20*qdim],
                         &lbf[spos+19*qdim], &lbf[spos+17*qdim], &lbf[spos+18*qdim], &lbf[spos+22*qdim],
                         &lbf[spos+8*qdim], &lbf[spos+24*qdim], &lbf[spos+26*qdim], &lbf[spos+23*qdim],
                         &lbf[spos+25*qdim]);
        break;
    }
  }
  return 0;
}


