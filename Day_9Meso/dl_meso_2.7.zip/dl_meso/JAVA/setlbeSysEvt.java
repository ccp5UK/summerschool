import javax.swing.*;
import java.util.*;
import java.lang.*;
import java.io.*;
import java.awt.*;
import java.awt.event.*;
import java.awt.geom.*;
import java.awt.image.*;
/*
 *     DL_MESO_GUI
 *     author: R. S. Qin, M. A. Seaton
 *     copyright: UKRI STFC Daresbury Laboratory and CCP5
 *     2005, 2018
 */
class setlbeSysEvt implements ItemListener, ActionListener {
    
    static setlbeSys inigui;
    setFluid fg;
    setFluidForce frg;
	setFluidInteract ig;
    setSolute sg;
    setThermal tg;
    FileWriter ot;
    Scanner in,in2;
    String filename="lbin.sys";
    int xint;
    double xdouble;
    lbesysdim dim = new lbesysdim();
    static int lbd=2, lbq=9, lbf=1, lbc=0, lbt=0, lbp=0, lbincomp=0, lbrestart=0;
    static int collide=0, interact=0, outtype=0, outansi=0, eoscrit=0, oscfps=0;
    static int cx=0, cy=0, cz=0;
    static double iniv[] = new double[3];
    static double bdf[] = new double[6*3];
    static double oscf[] = new double[6*3];
    static double bousf[] = new double[6*3];
    static double densfic[] = new double[6*2];
    static int rheomodel[] = new int[6];
    static double rheoparama[] = new double[6];
    static double rheoparamb[] = new double[6];
    static double rheoparamc[] = new double[6];
    static double rheoparamd[] = new double[6];
    static double rheopower[] = new double[6];
    static double relaxtime[] = new double[6*4];
    static double mrtrelaxfreq[] = new double[8];
    static double fluidinteract[] = new double[6*6];
    static double wallinteract[] = new double[6];
    static int eos[] = new int[6];
    static double eosa[] = new double[6];
    static double eosb[] = new double[6];
    static double acentric[] = new double[6];
    static double psi0[] = new double[6];
    static int wettyp[] = new int[6];

    static double quadw[] = new double[6];
    static double segregate;
    static double concsi[] = new double[6];
    static double solrelax[] = new double[6];
    static double heatrelax,boustemph,boustempl,tempsi,heatratei;
    static double mobrelax,mobility,fekappa;
    static double tempsys,gascon,oscfp,trtmagic;
   
    public setlbeSysEvt(setlbeSys ini) {
        java.util.Arrays.fill(bdf, 0.0);
        java.util.Arrays.fill(oscf, 0.0);
        java.util.Arrays.fill(bousf, 0.0);
        java.util.Arrays.fill(iniv, 0.0);
        for (int i=0; i<6; i++) {
          densfic[i*2] = 1.0;
          densfic[i*2+1] = 1.0;
          concsi[i] = 0.0;
        }
        tempsi = 0.0;
        heatratei = 0.0;
        java.util.Arrays.fill(relaxtime, 1.0);
        java.util.Arrays.fill(mrtrelaxfreq, 0.0);
        java.util.Arrays.fill(fluidinteract, 0.0);
        java.util.Arrays.fill(wallinteract, 0.0);
        java.util.Arrays.fill(rheomodel, 0);
        java.util.Arrays.fill(rheoparama, 1.0);
        java.util.Arrays.fill(rheoparamb, 1.0);
        java.util.Arrays.fill(rheoparamc, 1.0);
        java.util.Arrays.fill(rheoparamd, 1.0);
        java.util.Arrays.fill(rheopower, 1.0);
        java.util.Arrays.fill(eosa, 0.0);
        java.util.Arrays.fill(eosb, 0.0);
        java.util.Arrays.fill(acentric, 0.0);
        java.util.Arrays.fill(psi0, 0.0);
        segregate = 0.0;
        tempsys=1.0;
        gascon=1.0;
        mobrelax=1.0;
        mobility=1.0;
        java.util.Arrays.fill(solrelax, 1.0);
        heatrelax = 1.0;
        boustemph = 1.0;
        boustempl = 0.0;
        trtmagic = 0.375;
        oscfp = 1.0;
        for (int i=0; i<6; i++) {
            dim.densf[i*6] = 1.0;
            dim.densf[i*6+1] = 1.0;
            dim.densf[i*6+2] = 1.0;
            dim.densf[i*6+3] = 1.0;
            dim.densf[i*6+4] = 1.0;
            dim.densf[i*6+5] = 1.0;
            dim.conc[i*6] = 0.0;
            dim.conc[i*6+1] = 0.0;
            dim.conc[i*6+2] = 0.0;
            dim.conc[i*6+3] = 0.0;
            dim.conc[i*6+4] = 0.0;
            dim.conc[i*6+5] = 0.0;
            dim.temp[i] = 0.0;
            dim.tempdt[i] = 0.0;
            dim.vel[i*3] = 0.0;
            dim.vel[i*3+1] = 0.0;
            dim.vel[i*3+2] = 0.0;
            dim.velos[i*3] = 0.0;
            dim.velos[i*3+1] = 0.0;
            dim.velos[i*3+2] = 0.0;
            dim.velospf[i] = 0.0;
            dim.pf[i] = 0;
        }
	inigui=ini;	
    }

    public setlbeSysEvt(setFluid fluini) {
	fg=fluini;
    }

    public setlbeSysEvt(setFluidForce fluforini) {
	frg=fluforini;
    }

    public setlbeSysEvt(setFluidInteract fluinterini) {
	ig=fluinterini;
    }

    public setlbeSysEvt(setSolute solini) {
	sg=solini;
    }

    public setlbeSysEvt(setThermal theini) {
	tg=theini;
    }

    public void actionPerformed(ActionEvent event) {
	String cmd =event.getActionCommand();

	if (cmd == "set fluid parameters") {
	    try {
			lbf = Integer.parseInt(inigui.fluidn.getText());
			try{
				lbc = Integer.parseInt(inigui.solutn.getText());
			} catch (NumberFormatException ecc) {
				lbc = 0;
			}
			if((lbc > 0) && (lbf > 1))
				ierr(" you cannot have "+lbc+" solutes and "+lbf+" fluids ");	
  	        else if((lbf<0) || (lbf>6)) 
				ierr("  number of fluids should be between 1 to 6  ");
            else if((interact>9 && interact<20) && lbf<2)
                ierr(" at least 2 fluids needed for Lishchuk interactions ");
            else if(interact==20 && lbf>2)
                ierr(" no more than 2 fluids possible for Swift interactions ");
	        else {
				if(inigui.yesincomp.isSelected())
					lbincomp = 1;
                else
					lbincomp = 0;
				if((lbf > 1) && (lbf < 7))
					setfluitparameter(lbf,lbd,lbq,collide,interact,densfic,iniv,relaxtime,mrtrelaxfreq,trtmagic,rheomodel,rheoparama,rheoparamb,rheoparamc,rheoparamd,rheopower);
				else if(lbf == 1)
					setfluitparameter(lbf,lbd,lbq,collide,interact,densfic,iniv,relaxtime,mrtrelaxfreq,trtmagic,rheomodel,rheoparama,rheoparamb,rheoparamc,rheoparamd,rheopower);
	        }	
	    } catch (NumberFormatException e) {
			ierr(" expecting an integer number ");
	    }
	}
	
	else if (cmd == "set fluid forces") {
	    try {
			lbf = Integer.parseInt(inigui.fluidn.getText());
            if((lbf<0) || (lbf>6))
				ierr("  number of fluids should be between 1 to 6  ");
	        else {
				if((lbf > 1) && (lbf < 7))
					setfluitforceparameter(lbf,lbd,collide,bdf,oscf,bousf,oscfp,oscfps);
				else if(lbf == 1)
					setfluitforceparameter(lbf,lbd,collide,bdf,oscf,bousf,oscfp,oscfps);
	        }	
	    } catch (NumberFormatException e) {
			ierr(" expecting an integer number ");
	    }
	}
	
	else if (cmd == "set fluid interactions") {
	    try {
			lbf = Integer.parseInt(inigui.fluidn.getText());
			try{
				lbc = Integer.parseInt(inigui.solutn.getText());
			} catch (NumberFormatException ecc) {
				lbc = 0;
			}
			if((lbc > 0) && (lbf > 1))
				ierr(" you cannot have "+lbc+" solutes and "+lbf+" fluids ");	
  	        else if((lbf<0) || (lbf>6)) 
				ierr("  number of fluids should be between 1 to 6  ");
            else if((interact>9 && interact<20) && lbf<2)
                ierr(" at least 2 fluids needed for Lishchuk interactions ");
            else if(interact==20 && lbf>2)
                ierr(" no more than 2 fluids possible for Swift interactions ");
	        else {
				if(inigui.yesincomp.isSelected())
					lbincomp = 1;
                else
					lbincomp = 0;
				if((lbf > 1) && (lbf < 7))
					setfluitintparameter(lbf,interact,fluidinteract,eos,eoscrit,eosa,eosb,acentric,psi0,quadw,wettyp,wallinteract,segregate,gascon,tempsys,fekappa,mobrelax,mobility);
				else if(lbf == 1)
					setfluitintparameter(lbf,interact,fluidinteract,eos,eoscrit,eosa,eosb,acentric,psi0,quadw,wettyp,wallinteract,segregate,gascon,tempsys,fekappa,mobrelax,mobility);
			}
	    } catch (NumberFormatException e) {
			ierr(" expecting an integer number ");
	    }
	}

	else if (cmd == "set solute parameters") {
	    try {
                lbf = Integer.parseInt(inigui.fluidn.getText());
                lbc = Integer.parseInt(inigui.solutn.getText());
                if(lbf >1)
                    ierr(" error: number of fluid phases = "+lbf);
                else if((lbc<0) || (lbc>6))
                    ierr("number of solutes should be between 0 and 6");
                else if(lbc == 0)
                     ierr("no solute parameters needed");
                else{
                    setsoluteparameter(lbc,lbd,solrelax,concsi);
                }
	    } catch (NumberFormatException e) {
            ierr(" expecting an integer number ");
	    }
	}

	else if (cmd == "set thermal parameters") {
	    try {
                if (inigui.yest.isSelected())
                  lbt = 1;
                else {
                  lbt = 0;
                }
                if(lbt == 0)
                     ierr("no thermal parameters needed");
	        else{
		    setthermalparameter(lbd,heatrelax,boustemph,boustempl,tempsi,heatratei);
	        }
	    } catch (NumberFormatException e) {
		ierr(" expecting an integer number ");
	    }
	}

	else if (cmd == "OPEN") {
	    openlbe();	    
	}

	else if (cmd == "SAVE") {
	    savelbe();	    
	}

	else if (cmd == "SAVE F") {
        saveflu();
    }

	else if (cmd == "SAVE FR") {
        saveflufor();
    }

	else if (cmd == "SAVE FI") {
        savefluint();
    }

	else if (cmd == "SAVE C") {
	    savesol();
	}

	else if (cmd == "SAVE T") {
        savethe();
	}

	else if (cmd == "CANCEL F") {
	    fg.dispose();
	}

	else if (cmd == "CANCEL FR") {
	    frg.dispose();
	}

	else if (cmd == "CANCEL FI") {
	    ig.dispose();
	}

	else if (cmd == "CANCEL C") {
	    sg.dispose();
	}

	else if (cmd == "CANCEL T") {
	    tg.dispose();
	}

    }

    void  saveflu() {
        int i, j, k;
	    try {
            lbf = Integer.parseInt(inigui.fluidn.getText());
            iniv[0] = Double.parseDouble(fg.inivx.getText());
            iniv[1] = Double.parseDouble(fg.inivy.getText());
            iniv[2] = Double.parseDouble(fg.inivz.getText());
			for(i=0; i<lbf; i++) {
				densfic[2*i]=Double.parseDouble(fg.inidensity[i].getText());
                densfic[2*i+1]=Double.parseDouble(fg.cstdensity[i].getText());
			}
            for(i=0; i<lbf; i++) {
                rheomodel[i] = fg.rheo[i].getSelectedIndex();
                rheoparama[i] = Double.parseDouble(fg.rheoaparam[i].getText());
                rheoparamb[i] = Double.parseDouble(fg.rheobparam[i].getText());
                rheoparamc[i] = Double.parseDouble(fg.rheocparam[i].getText());
                rheoparamd[i] = Double.parseDouble(fg.rheodparam[i].getText());
                rheopower[i] = Double.parseDouble(fg.rheopower[i].getText());
            }
            trtmagic = Double.parseDouble(fg.trtmagic.getText());
			for(i=0; i<lbf; i++)
				relaxtime[4*i] =Double.parseDouble(fg.viscosities[i].getText());
            if(collide>7) {
              for(i=0; i<lbf; i++)
                  relaxtime[4*i+1] =Double.parseDouble(fg.bulkviscosities[i].getText());
            }
            if(collide>11) {
                for(i=0; i<lbf; i++) {
                    relaxtime[4*i+2] =Double.parseDouble(fg.relax3[i].getText());
                    relaxtime[4*i+3] =Double.parseDouble(fg.relax4[i].getText());
                }
			}
            if(collide>7 && collide<12) {
                for(i=0; i<8; i++)
                    mrtrelaxfreq[i] = Double.parseDouble(fg.mrtrelax[i].getText());
            }
			fg.dispose();
        } catch (NumberFormatException enfl) {
			ierr(" fluid parameter: format error or no value ");
	    }
    }

    void  saveflufor() {
        int i, j, k;
	    try {
            lbf = Integer.parseInt(inigui.fluidn.getText());
			for(i=0; i<lbf; i++) {
				j = i * 3;
				bdf[j]=Double.parseDouble(frg.xforce[i].getText());
				j = i * 3 + 1;
				bdf[j]=Double.parseDouble(frg.yforce[i].getText());
				j = i * 3 + 2;
				bdf[j]=Double.parseDouble(frg.zforce[i].getText());
			}
			for(i=0; i<lbf; i++) {
				j = i * 3;
				oscf[j]=Double.parseDouble(frg.oscxforce[i].getText());
				j = i * 3 + 1;
				oscf[j]=Double.parseDouble(frg.oscyforce[i].getText());
				j = i * 3 + 2;
				oscf[j]=Double.parseDouble(frg.osczforce[i].getText());
			}
            oscfp = frg.oscilfrp.getSelectedIndex();
			for(i=0; i<lbf; i++) {
				j = i * 3;
				bousf[j]=Double.parseDouble(frg.bousxforce[i].getText());
				j = i * 3 + 1;
				bousf[j]=Double.parseDouble(frg.bousyforce[i].getText());
				j = i * 3 + 2;
				bousf[j]=Double.parseDouble(frg.bouszforce[i].getText());
			}
			frg.dispose();
        } catch (NumberFormatException enfl) {
			ierr(" fluid parameter: format error or no value ");
	    }
    }

    void  savefluint() {
        int i, j, k, ii;
	    try {
            lbf = Integer.parseInt(inigui.fluidn.getText());
            if(interact==1 || interact==2) {
                for(i=0; i<lbf; i++) {
                    for(j=0; j<lbf; j++) {
                        if(j >= i) {
                            xdouble = Double.parseDouble(ig.interactions[i*lbf+j].getText());
                        }
                        else {
                            xdouble = Double.parseDouble(ig.interactions[j*lbf+i].getText());
                        }
                        k = i*lbf + j;
                        fluidinteract[k] = xdouble;
                    }
                }
            }
            else if(interact>9 && interact<20) {
                for(i=0; i<lbf; i++) {
                    for(j=0; j<lbf; j++) {
                        if(j > i) {
                            xdouble = Double.parseDouble(ig.interactions[i*lbf+j].getText());
                            k = i*lbf + j;
                            fluidinteract[k] = xdouble;
                        }
                        else if (j < i) {
                            xdouble = Double.parseDouble(ig.interactions[j*lbf+i].getText());
                            k = i*lbf + j;
                            fluidinteract[k] = xdouble;
                        }
                    }
                }
            }
			if(interact==2){
				for(i=0; i<lbf; i++) {
					quadw[i] = Double.parseDouble(ig.quadweight[i].getText());
				}
			}
			if(interact==1 || interact==2) {
				for(i=0; i<lbf; i++) {
                    eos[i] = ig.fluid[i].getSelectedIndex();
                    eosa[i] = Double.parseDouble(ig.eosabox[i].getText());
                    eosb[i] = Double.parseDouble(ig.eosbbox[i].getText());
                    acentric[i] = Double.parseDouble(ig.acentricbox[i].getText());
                    psi0[i] = Double.parseDouble(ig.psi0box[i].getText());
                    wettyp[i] = ig.wet[i].getSelectedIndex();
				}
                wallinteract[0] = Double.parseDouble(ig.wallinteractions0.getText());
                wallinteract[1] = Double.parseDouble(ig.wallinteractions1.getText());
                wallinteract[2] = Double.parseDouble(ig.wallinteractions2.getText());
                wallinteract[3] = Double.parseDouble(ig.wallinteractions3.getText());
                wallinteract[4] = Double.parseDouble(ig.wallinteractions4.getText());
                wallinteract[5] = Double.parseDouble(ig.wallinteractions5.getText());
                gascon = Double.parseDouble(ig.gasconst.getText());
                tempsys = Double.parseDouble(ig.systemp.getText());
			}
            if(interact>9 && interact<20) {
                wallinteract[1] = Double.parseDouble(ig.wallinteractions1.getText());
                wallinteract[2] = Double.parseDouble(ig.wallinteractions2.getText());
                wallinteract[3] = Double.parseDouble(ig.wallinteractions3.getText());
                wallinteract[4] = Double.parseDouble(ig.wallinteractions4.getText());
                wallinteract[5] = Double.parseDouble(ig.wallinteractions5.getText());
				segregate = Double.parseDouble(ig.segregation.getText());
            }
            if(interact==20) {
                eos[0] = ig.fluid[0].getSelectedIndex();
                eosa[0] = Double.parseDouble(ig.eosabox[0].getText());
                eosb[0] = Double.parseDouble(ig.eosbbox[0].getText());
                acentric[0] = Double.parseDouble(ig.acentricbox[0].getText());
                fekappa = Double.parseDouble(ig.eosabox[2].getText());
                wettyp[0] = ig.wet[0].getSelectedIndex();
                wallinteract[0] = Double.parseDouble(ig.wallinteractions0.getText());
                wallinteract[1] = Double.parseDouble(ig.wallinteractions1.getText());
                if(lbf>1) {
                    eos[1] = ig.fluid[1].getSelectedIndex();
                    eosa[1] = Double.parseDouble(ig.eosabox[1].getText());
                    eosb[1] = Double.parseDouble(ig.eosbbox[1].getText());
                    wallinteract[2] = Double.parseDouble(ig.wallinteractions2.getText());
                    wallinteract[3] = Double.parseDouble(ig.wallinteractions3.getText());
                    mobrelax = Double.parseDouble(ig.eosabox[4].getText());
                    mobility = Double.parseDouble(ig.eosbbox[4].getText());
                }
                gascon = Double.parseDouble(ig.gasconst.getText());
                tempsys = Double.parseDouble(ig.systemp.getText());
            }

			ig.dispose();
		} catch (NumberFormatException enfl) {
			ierr(" fluid interaction parameter: format error or no value ");
		}
	}

    void  savesol() {
        int i, j;
	    try {
            lbc = Integer.parseInt(inigui.solutn.getText());
            for(i=0; i<lbc; i++) {
                concsi[i] =Double.parseDouble(sg.iniconcen[i].getText());
                solrelax[i] =Double.parseDouble(sg.diffusivities[i].getText());
            }
            sg.dispose();
	    } catch (NumberFormatException enfc) {
            ierr(" solute parameter: format error or no value ");
	    }
    }

    void  savethe() {
        int i, j;
  	    try {
	        heatrelax = Double.parseDouble(tg.difut.getText());
            boustemph = Double.parseDouble(tg.boushigh.getText());
            boustempl = Double.parseDouble(tg.bouslow.getText());
	        tempsi = Double.parseDouble(tg.init.getText());
	        heatratei = Double.parseDouble(tg.inidt.getText());
            tg.dispose();
	    } catch (NumberFormatException enfc) {
	        ierr(" thermal parameter: format error or no value ");
	    }
    }

    void  savelbe() {
        int i, j, k;
        Boolean gs;
	    try {
            ot = new FileWriter(filename, false);
            lbf = Integer.parseInt(inigui.fluidn.getText());
           
	    } catch (IOException e) {
            ierr(" cannot create "+filename+" file ");
     	    try{
	          lbc = Integer.parseInt(inigui.solutn.getText());
	        } catch (NumberFormatException ecc) {
	          lbc = 0;
	        }
            if((lbc > 0) && (lbf > 1))
	          ierr(" you cannot have "+lbc+" solutes and "+lbf+" fluids ");
  	        else if((lbf<0) || (lbf>6))
	          ierr("  number of fluids should be between 1 to 6  ");
            else if((interact>2 && interact<6) && lbf<2)
              ierr(" ");
	        else {
              if(inigui.yesincomp.isSelected())
                lbincomp = 1;
              else
                lbincomp = 0;
              if(inigui.yesrestart.isSelected())
                lbrestart = 1;
              else
                lbrestart = 0;
	        }
        }
	    try {
            // simulation properties
            ot.write("space_dimension              "+lbd+"\n");
	        dim.lbd = lbd;
            ot.write("discrete_speed               "+lbq+"\n");
            ot.write("number_of_fluid              "+lbf+"\n");
	        dim.lbf = lbf;
            ot.write("number_of_solute             "+lbc+"\n");
	        dim.lbc = lbc;
            ot.write("temperature_scalar           "+lbt+"\n");
	        dim.lbt = lbt;
            ot.write("phase_field                  "+lbp+"\n");
            ot.write("incompressible_fluids        "+lbincomp+"\n");
            ot.write("restart_simulation           "+lbrestart+"\n");
            switch (collide)
            {
              case 0:
                ot.write("collision_type               BGK\n");
                break;
              case 1:
                ot.write("collision_type               BGKEDM\n");
                break;
              case 2:
                ot.write("collision_type               BGKGuo\n");
                break;
              case 3:
                ot.write("collision_type               BGKHe\n");
                break;
              case 4:
                ot.write("collision_type               TRT\n");
                ot.write("trt_magic_number             "+trtmagic+"\n");
                break;
              case 5:
                ot.write("collision_type               TRTEDM\n");
                ot.write("trt_magic_number             "+trtmagic+"\n");
                break;
              case 6:
                ot.write("collision_type               TRTGuo\n");
                ot.write("trt_magic_number             "+trtmagic+"\n");
                break;
              case 7:
                ot.write("collision_type               TRTHe\n");
                ot.write("trt_magic_number             "+trtmagic+"\n");
                break;
              case 8:
                ot.write("collision_type               MRT\n");
                break;
              case 9:
                ot.write("collision_type               MRTEDM\n");
                break;
              case 10:
                ot.write("collision_type               MRTGuo\n");
                break;
              case 11:
                ot.write("collision_type               MRTHe\n");
                break;
              case 12:
                ot.write("collision_type               CLBE\n");
                break;
              case 13:
                ot.write("collision_type               CLBEEDM\n");
                break;
              case 14:
                ot.write("collision_type               CLBEGuo\n");
                break;
              case 15:
                ot.write("collision_type               CLBEHe\n");
                break;
            }
            switch (interact)
            {
              case 1:
                ot.write("interaction_type             ShanChen\n");
                break;
              case 2:
                ot.write("interaction_type             ShanChenQuadratic\n");
                break;
              case 10:
                ot.write("interaction_type             Lishchuk\n");
                break;
              case 11:
                ot.write("interaction_type             LishchukSpencer\n");
                break;
              case 12:
                ot.write("interaction_type             LishchukSpencerTensor\n");
                break;
              case 13:
                ot.write("interaction_type             LishchukLocal\n");
                break;
              case 20:
                ot.write("interaction_type             Swift\n");
                break;
            }
            switch (outtype)
            {
              case 0:
                ot.write("output_format                VTK\n");
                break;
              case 1:
                ot.write("output_format                LegacyVTK\n");
                break;
              case 2:
                ot.write("output_format                Plot3D\n");
                break;
            }
            switch (outansi)
            {
              case 0:
                ot.write("output_type                  Binary\n");
                break;
              case 1:
                ot.write("output_type                  ANSI\n");
                break;
            }
            ot.write("output_combine_x             ");
            if(inigui.combinex.isSelected())
              ot.write("1\n");
            else
              ot.write("0\n");
            ot.write("output_combine_y             ");
            if(inigui.combiney.isSelected())
              ot.write("1\n");
            else
              ot.write("0\n");
            ot.write("output_combine_z             ");
            if(inigui.combinez.isSelected())
              ot.write("1\n");
            else
              ot.write("0\n");
            
            // system properties (read directly from window)
            xint = Integer.parseInt(inigui.totx.getText());
            ot.write("grid_number_x                "+xint+"\n");
	        dim.lbnx = xint;
            xint = Integer.parseInt(inigui.toty.getText());
            ot.write("grid_number_y                "+xint+"\n");
	        dim.lbny = xint;
	        xint = Integer.parseInt(inigui.totz.getText());
            ot.write("grid_number_z                "+xint+"\n");
	        dim.lbnz = xint;
            xint = Integer.parseInt(inigui.bwid.getText());
            ot.write("domain_boundary_width        "+xint+"\n");
	        xint = Integer.parseInt(inigui.tott.getText());
            ot.write("total_step                   "+xint+"\n");
	        xint = Integer.parseInt(inigui.equt.getText());
            ot.write("equilibration_step           "+xint+"\n");
	        xint = Integer.parseInt(inigui.savet.getText());
            ot.write("save_span                    "+xint+"\n");
	        xint = Integer.parseInt(inigui.dumpt.getText());
            ot.write("dump_span                    "+xint+"\n");
	        xdouble =Double.parseDouble(inigui.calctime.getText());
            ot.write("calculation_time             "+xdouble+"\n");
	        xdouble =Double.parseDouble(inigui.noiei.getText());
            ot.write("noise_intensity              "+xdouble+"\n");
	        xdouble = Double.parseDouble(inigui.soundv.getText());
            ot.write("sound_speed                  "+xdouble+"\n");
	        xdouble = Double.parseDouble(inigui.kineticv.getText());
            ot.write("kinetic_viscosity            "+xdouble+"\n");
            // fluid properties
            for(i=0; i<lbf; i++) {
              j = i * 3;
              ot.write("body_force_"+j+"                 "+bdf[j]+"\n");
              j = i * 3 + 1;
              ot.write("body_force_"+j+"                 "+bdf[j]+"\n");
              j = i * 3 + 2;
              ot.write("body_force_"+j+"                 "+bdf[j]+"\n");
            }
            for(i=0; i<lbf; i++) {
              j = i * 3;
              ot.write("oscillating_force_"+j+"          "+oscf[j]+"\n");
              j = i * 3 + 1;
              ot.write("oscillating_force_"+j+"          "+oscf[j]+"\n");
              j = i * 3 + 2;
              ot.write("oscillating_force_"+j+"          "+oscf[j]+"\n");
            }
            if(oscfps>0)
              ot.write("oscillating_period           "+oscfp+"\n");
            else
              ot.write("oscillating_freq             "+oscfp+"\n");
            for(i=0; i<lbf; i++) {
              j = i * 3;
              ot.write("boussinesq_force_"+j+"           "+bousf[j]+"\n");
              j = i * 3 + 1;
              ot.write("boussinesq_force_"+j+"           "+bousf[j]+"\n");
              j = i * 3 + 2;
              ot.write("boussinesq_force_"+j+"           "+bousf[j]+"\n");
            }
            for(i=0; i<3; i++) {
              ot.write("speed_ini_"+i+"                  "+iniv[i]+"\n");
            }
            for(i=0; i<lbf; i++) {
              ot.write("density_ini_"+i+"                "+densfic[2*i]+"\n");
            }
            if (lbincomp>0 || interact>0) {
              for(i=0; i<lbf; i++) {
                ot.write("density_inc_"+i+"                "+densfic[2*i+1]+"\n");
              }
            }
            for(i=0; i<lbf; i++) {
              switch (rheomodel[i]) {
                case 0:
                  ot.write("rheology_fluid_"+i+"             Simple\n");
                  break;
                case 1:
                  ot.write("rheology_fluid_"+i+"             Newtonian\n");
                  ot.write("rheology_parameter_a_"+i+"       "+rheoparama[i]+"\n");
                  break;
                case 2:
                  ot.write("rheology_fluid_"+i+"             PowerLaw\n");
                  ot.write("rheology_parameter_a_"+i+"       "+rheoparama[i]+"\n");
                  ot.write("rheology_power_"+i+"             "+rheopower[i]+"\n");
                  break;
                case 3:
                  ot.write("rheology_fluid_"+i+"             Bingham\n");
                  ot.write("rheology_parameter_a_"+i+"       "+rheoparama[i]+"\n");
                  ot.write("rheology_parameter_b_"+i+"       "+rheoparamb[i]+"\n");
                  ot.write("rheology_parameter_c_"+i+"       "+rheoparamc[i]+"\n");
                  break;
                case 4:
                  ot.write("rheology_fluid_"+i+"             HerschelBulkley\n");
                  ot.write("rheology_parameter_a_"+i+"       "+rheoparama[i]+"\n");
                  ot.write("rheology_parameter_b_"+i+"       "+rheoparamb[i]+"\n");
                  ot.write("rheology_parameter_c_"+i+"       "+rheoparamc[i]+"\n");
                  ot.write("rheology_power_"+i+"             "+rheopower[i]+"\n");
                  break;
                case 5:
                  ot.write("rheology_fluid_"+i+"             Casson\n");
                  ot.write("rheology_parameter_a_"+i+"       "+rheoparama[i]+"\n");
                  ot.write("rheology_parameter_b_"+i+"       "+rheoparamb[i]+"\n");
                  ot.write("rheology_parameter_c_"+i+"       "+rheoparamc[i]+"\n");
                  break;
                case 6:
                  ot.write("rheology_fluid_"+i+"             CarreauYasuda\n");
                  ot.write("rheology_parameter_a_"+i+"       "+rheoparama[i]+"\n");
                  ot.write("rheology_parameter_b_"+i+"       "+rheoparamb[i]+"\n");
                  ot.write("rheology_parameter_c_"+i+"       "+rheoparamc[i]+"\n");
                  ot.write("rheology_parameter_d_"+i+"       "+rheoparamd[i]+"\n");
                  ot.write("rheology_power_"+i+"             "+rheopower[i]+"\n");
                  break;
              }
            }
            for(i=0; i<lbf; i++) {
              ot.write("relaxation_fluid_"+i+"           "+relaxtime[4*i]+"\n");
              if(collide>7)
                  ot.write("bulk_relaxation_fluid_"+i+"      "+relaxtime[4*i+1]+"\n");
              if (collide>11) {
                  ot.write("clbe3_relaxation_fluid_"+i+"     "+relaxtime[4*i+2]+"\n");
                  ot.write("clbe4_relaxation_fluid_"+i+"     "+relaxtime[4*i+3]+"\n");
              }
	        }
            if(collide>7 && collide<12) {
                ot.write("mrt_relax_freq_0             "+mrtrelaxfreq[0]+"\n");
                ot.write("mrt_relax_freq_1             "+mrtrelaxfreq[1]+"\n");
                if(lbq>9)
                    ot.write("mrt_relax_freq_2             "+mrtrelaxfreq[2]+"\n");
                if(lbq==27) {
                    ot.write("mrt_relax_freq_3             "+mrtrelaxfreq[3]+"\n");
                    ot.write("mrt_relax_freq_4             "+mrtrelaxfreq[4]+"\n");
                    ot.write("mrt_relax_freq_5             "+mrtrelaxfreq[5]+"\n");
                    ot.write("mrt_relax_freq_6             "+mrtrelaxfreq[6]+"\n");
                    ot.write("mrt_relax_freq_7             "+mrtrelaxfreq[7]+"\n");
                }
            }
            if(interact>0 && interact<10) {
                for(i=0; i<lbf; i++) {
                    for(j=0; j<lbf; j++) {
                        k = i*lbf + j;
                        ot.write("interaction_"+k+"                "+fluidinteract[k]+"\n");
                    }
                }
            }
            else if(interact>9 && interact<20) {
                for(i=0; i<lbf; i++) {
                    for(j=0; j<lbf; j++) {
                        k = i*lbf + j;
                        if(i==j)
                          ot.write("interaction_"+k+"                0.0\n");
                        else
                          ot.write("interaction_"+k+"                "+fluidinteract[k]+"\n");
                    }
                }
            }
            if(interact==1 || interact==2) {
              gs = false;
              for(i=0; i<lbf; i++) {
                xint = eos[i];
                switch (xint) {
                    case 0:
                        ot.write("potential_type_"+i+"             IdealLattice\n");
                        break;
                    case 1:
                        ot.write("potential_type_"+i+"             ShanChen1993\n");
                        break;
                    case 2:
                        ot.write("potential_type_"+i+"             ShanChen1994\n");
                        ot.write("shanchen_psi0_"+i+"              "+psi0[i]+"\n");
                        break;
                    case 3:
                        ot.write("potential_type_"+i+"             Qian1995\n");
                        break;
                    case 4:
                        ot.write("potential_type_"+i+"             Rho\n");
                        break;
                    case 5:
                        ot.write("potential_type_"+i+"             Ideal\n");
                        gs = true;
                        break;
                    case 6:
                        ot.write("potential_type_"+i+"             vanderWaals\n");
                        if(eoscrit==0) {
                            ot.write("eos_parameter_a_"+i+"            "+eosa[i]+"\n");
                            ot.write("eos_parameter_b_"+i+"            "+eosb[i]+"\n");
                        }
                        else {
                            ot.write("critical_temperature_"+i+"       "+eosa[i]+"\n");
                            ot.write("critical_pressure_"+i+"          "+eosb[i]+"\n");
                        }
                        gs = true;
                        break;
                    case 7:
                        ot.write("potential_type_"+i+"             RedlichKwong\n");
                        if(eoscrit==0) {
                            ot.write("eos_parameter_a_"+i+"            "+eosa[i]+"\n");
                            ot.write("eos_parameter_b_"+i+"            "+eosb[i]+"\n");
                        }
                        else {
                            ot.write("critical_temperature_"+i+"       "+eosa[i]+"\n");
                            ot.write("critical_pressure_"+i+"          "+eosb[i]+"\n");
                        }
                        gs = true;
                        break;
                    case 8:
                        ot.write("potential_type_"+i+"             SoaveRedlichKwong\n");
                        if(eoscrit==0) {
                            ot.write("eos_parameter_a_"+i+"            "+eosa[i]+"\n");
                            ot.write("eos_parameter_b_"+i+"            "+eosb[i]+"\n");
                        }
                        else {
                            ot.write("critical_temperature_"+i+"       "+eosa[i]+"\n");
                            ot.write("critical_pressure_"+i+"          "+eosb[i]+"\n");
                        }
                        ot.write("acentric_factor_"+i+"            "+acentric[i]+"\n");
                        gs = true;
                        break;
                    case 9:
                        ot.write("potential_type_"+i+"             PengRobinson\n");
                        if(eoscrit==0) {
                            ot.write("eos_parameter_a_"+i+"            "+eosa[i]+"\n");
                            ot.write("eos_parameter_b_"+i+"            "+eosb[i]+"\n");
                        }
                        else {
                            ot.write("critical_temperature_"+i+"       "+eosa[i]+"\n");
                            ot.write("critical_pressure_"+i+"          "+eosb[i]+"\n");
                        }
                        ot.write("acentric_factor_"+i+"            "+acentric[i]+"\n");
                        gs = true;
                        break;
                    case 10:
                        ot.write("potential_type_"+i+"             CarnahanStarlingvanderWaals\n");
                        if(eoscrit==0) {
                            ot.write("eos_parameter_a_"+i+"            "+eosa[i]+"\n");
                            ot.write("eos_parameter_b_"+i+"            "+eosb[i]+"\n");
                        }
                        else {
                            ot.write("critical_temperature_"+i+"       "+eosa[i]+"\n");
                            ot.write("critical_pressure_"+i+"          "+eosb[i]+"\n");
                        }
                        gs = true;
                        break;
                    case 11:
                        ot.write("potential_type_"+i+"             CarnahanStarlingRedlichKwong\n");
                        if(eoscrit==0) {
                            ot.write("eos_parameter_a_"+i+"            "+eosa[i]+"\n");
                            ot.write("eos_parameter_b_"+i+"            "+eosb[i]+"\n");
                        }
                        else {
                            ot.write("critical_temperature_"+i+"       "+eosa[i]+"\n");
                            ot.write("critical_pressure_"+i+"          "+eosb[i]+"\n");
                        }
                        gs = true;
                        break;
                }
                if(interact==2) ot.write("quadratic_weight_"+(i*lbf+i)+"          "+quadw[i]+"\n");
                xint = wettyp[i];
                switch (xint) {
                    case 0:
                        ot.write("wetting_type_"+i+"               Density\n");
                        break;
                    case 1:
                        ot.write("wetting_type_"+i+"               Potential\n");
                        break;
                    case 2:
                        ot.write("wetting_type_"+i+"               ScreenedPotential\n");
                        break;
                }
                ot.write("wall_interaction_"+i+"           "+wallinteract[i]+"\n");
              }
              if(gs) ot.write("gas_constant                 "+gascon+"\n");
              if(gs && lbt==0) ot.write("temperature_system           "+tempsys+"\n");
            }
            if(interact>9 && interact<20) {
              for(i=1; i<lbf; i++)
                ot.write("wall_interaction_"+i+"           "+wallinteract[i]+"\n");
              ot.write("segregation                  "+segregate+"\n");
            }
            if(interact==20) {
                xint = eos[0];
                switch (xint) {
                    case 0:
                        ot.write("equation_of_state            IdealLattice\n");
                        break;
                    case 1:
                        ot.write("equation_of_state            ShanChen1993\n");
                        ot.write("eos_parameter_a              "+eosa[0]+"\n");
                        break;
                    case 2:
                        ot.write("equation_of_state            ShanChen1994\n");
                        ot.write("eos_parameter_a              "+eosa[0]+"\n");
                        ot.write("shanchen_psi0_0              "+eosb[0]+"\n");
                        break;
                    case 3:
                        ot.write("equation_of_state            Qian1995\n");
                        ot.write("eos_parameter_a              "+eosa[0]+"\n");
                        break;
                    case 4:
                        ot.write("equation_of_state            Rho\n");
                        ot.write("eos_parameter_a              "+eosa[0]+"\n");
                        break;
                    case 5:
                        ot.write("equation_of_state            Ideal\n");
                        break;
                    case 6:
                        ot.write("equation_of_state            vanderWaals\n");
                        if(eoscrit==0) {
                            ot.write("eos_parameter_a              "+eosa[0]+"\n");
                            ot.write("eos_parameter_b              "+eosb[0]+"\n");
                        }
                        else {
                            ot.write("critical_temperature_0       "+eosa[0]+"\n");
                            ot.write("critical_pressure_0          "+eosb[0]+"\n");
                        }
                        break;
                    case 7:
                        ot.write("equation_of_state            RedlichKwong\n");
                        if(eoscrit==0) {
                            ot.write("eos_parameter_a              "+eosa[0]+"\n");
                            ot.write("eos_parameter_b              "+eosb[0]+"\n");
                        }
                        else {
                            ot.write("critical_temperature_0       "+eosa[0]+"\n");
                            ot.write("critical_pressure_0          "+eosb[0]+"\n");
                        }
                        break;
                    case 8:
                        ot.write("equation_of_state            SoaveRedlichKwong\n");
                        if(eoscrit==0) {
                            ot.write("eos_parameter_a              "+eosa[0]+"\n");
                            ot.write("eos_parameter_b              "+eosb[0]+"\n");
                        }
                        else {
                            ot.write("critical_temperature_0       "+eosa[0]+"\n");
                            ot.write("critical_pressure_0          "+eosb[0]+"\n");
                        }
                        ot.write("acentric_factor_0            "+acentric[0]+"\n");
                        break;
                    case 9:
                        ot.write("equation_of_state            PengRobinson\n");
                        if(eoscrit==0) {
                            ot.write("eos_parameter_a              "+eosa[0]+"\n");
                            ot.write("eos_parameter_b              "+eosb[0]+"\n");
                        }
                        else {
                            ot.write("critical_temperature_0       "+eosa[0]+"\n");
                            ot.write("critical_pressure_0          "+eosb[0]+"\n");
                        }
                        ot.write("acentric_factor_0            "+acentric[0]+"\n");
                        break;
                    case 10:
                        ot.write("equation_of_state            CarnahanStarlingvanderWaals\n");
                        if(eoscrit==0) {
                            ot.write("eos_parameter_a              "+eosa[0]+"\n");
                            ot.write("eos_parameter_b              "+eosb[0]+"\n");
                        }
                        else {
                            ot.write("critical_temperature_0       "+eosa[0]+"\n");
                            ot.write("critical_pressure_0          "+eosb[0]+"\n");
                        }
                        break;
                    case 11:
                        ot.write("equation_of_state            CarnahanStarlingRedlichKwong\n");
                        if(eoscrit==0) {
                            ot.write("eos_parameter_a              "+eosa[0]+"\n");
                            ot.write("eos_parameter_b              "+eosb[0]+"\n");
                        }
                        else {
                            ot.write("critical_temperature_0       "+eosa[0]+"\n");
                            ot.write("critical_pressure_0          "+eosb[0]+"\n");
                        }
                        break;
                }
                if(xint>4) ot.write("gas_constant                 "+gascon+"\n");
                if(xint>4 && lbt==0) ot.write("temperature_system           "+tempsys+"\n");
                ot.write("surface_tension_parameter    "+fekappa+"\n");
                if(lbf>1) {
                    ot.write("relax_mobility               "+mobrelax+"\n");
                    ot.write("mobility_parameter           "+mobility+"\n");
                    xint = eos[1];
                    switch (xint) {
                        case 0:
                            ot.write("potential_type               None\n");
                            break;
                        case 1:
                            ot.write("potential_type               Quartic\n");
                            ot.write("potential_parameter_a        "+eosa[1]+"\n");
                            break;
                    }
                }
                xint = wettyp[0];
                switch (xint) {
                    case 0:
                        ot.write("wetting_type                 None\n");
                        break;
                    case 1:
                        ot.write("wetting_type                 Quadratic\n");
                        ot.write("wetting_parameter_rho_0      "+wallinteract[0]+"\n");
                        ot.write("wetting_parameter_rho_1      "+wallinteract[1]+"\n");
                        if(lbf>1) {
                            ot.write("wetting_parameter_phi_0      "+wallinteract[2]+"\n");
                            ot.write("wetting_parameter_phi_1      "+wallinteract[3]+"\n");
                        }
                        break;
                }
            }
            // solute properties
            for(i=0; i<lbc; i++) {
	          ot.write("solute_ini_"+i+"                 "+concsi[i]+"\n");
	          ot.write("relax_solute_"+i+"            "+solrelax[i]+"\n");
            }
            // thermal properties
            if(lbt>0) {
              ot.write("temperature_boussinesq_high  "+boustemph+"\n");
              ot.write("temperature_boussinesq_low   "+boustempl+"\n");
	          ot.write("temperature_ini              "+tempsi+"\n");
     	      ot.write("heating_rate_sys             "+heatratei+"\n");
  	          ot.write("relax_thermal                "+heatrelax+"\n");
            }

 	    } catch (NumberFormatException enf) {
	        ierr(" system parameter: format error or no value ");
	    } catch (IOException e) {
            ierr(" error when saving "+filename+" ");
	        System.out.println("Exception: "+e.getMessage());
	    }
	    try {
	        ot.close();
	    } catch (IOException e) {
            ierr(" error when closing "+filename+" ");
	        System.out.println("Exception: "+e.getMessage());
	    }
    }


    void  openlbe() {
        int i, j, k;
        String word, value, compare1, compare2;
        File it = new File(filename);
        if(!it.exists()) {
          ierr(" cannot find "+filename+" file ");
        }
	try {
            // set defaults
            inigui.yesincomp.setSelected(false);
            // first pass to find simulation properties
            Scanner in = new Scanner(new File(filename));
            while (in.hasNext("\\S+")) {
              word = in.next("\\S+");
              if(word.compareTo("space_dimension") == 0) {
                value = in.next("\\S+");
                lbd = Integer.parseInt(value);
              }
              else if(word.compareTo("discrete_speed") == 0) {
                value = in.next("\\S+");
                lbq = Integer.parseInt(value);
              }
              else if(word.compareTo("number_of_fluid") == 0) {
                value = in.next("\\S+");
                lbf = Integer.parseInt(value);
                if(lbf<1)
                  lbf = 1;
                else if(lbf>6)
                  lbf = 6;
                inigui.fluidn.setText(Integer.toString(lbf));
              }
              else if(word.compareTo("number_of_solute") == 0) {
                value = in.next("\\S+");
                lbc = Integer.parseInt(value);
                if(lbc<0)
                  lbc = 0;
                else if(lbc>6)
                  lbc = 6;
                inigui.solutn.setText(Integer.toString(lbc));
              }
              else if(word.compareTo("temperature_scalar") == 0) {
                value = in.next("\\S+");
                lbt = Integer.parseInt(value);
                if(lbt==0)
                  inigui.yest.setSelected(false);
                else
                  inigui.yest.setSelected(true);
              }
              else if(word.compareTo("phase_field") == 0) {
                value = in.next("\\S+");
                lbp = Integer.parseInt(value);
                if(lbp==0) {
                  inigui.phaseyes.setSelected(false);
                  inigui.phaseno.setSelected(true);
                }
                else {
                  inigui.phaseyes.setSelected(true);
                  inigui.phaseno.setSelected(false);
                }
              }
              else if(word.compareTo("grid_number_x") == 0) {
                value = in.next("\\S+");
                inigui.totx.setText(value);
              }
              else if(word.compareTo("grid_number_y") == 0) {
                value = in.next("\\S+");
                inigui.toty.setText(value);
              }
              else if(word.compareTo("grid_number_z") == 0) {
                value = in.next("\\S+");
                inigui.totz.setText(value);
              }
              else if(word.compareTo("domain_boundary_width") == 0) {
                value = in.next("\\S+");
                inigui.bwid.setText(value);
              }
              else if(word.compareTo("incompressible_fluids") == 0) {
                value = in.next("\\S+");
                lbincomp = Integer.parseInt(value);
                if(lbincomp==0)
                  inigui.yesincomp.setSelected(false);
                else
                  inigui.yesincomp.setSelected(true);
              }
              else if(word.compareTo("restart_simulation") == 0) {
                value = in.next("\\S+");
                lbrestart = Integer.parseInt(value);
                if(lbrestart==0)
                  inigui.yesrestart.setSelected(false);
                else
                  inigui.yesrestart.setSelected(true);
              }
              else if(word.compareTo("interaction_type") == 0) {
                  value = in.next("\\S+");
                  if(value.compareTo("ShanChen") == 0) {
                      inigui.interact.setSelectedItem("Shan/Chen");
                      interact = 1;
                      inigui.sete.setEnabled(true);
                  }
                  else if(value.compareTo("ShanChenQuadratic") == 0) {
                      inigui.interact.setSelectedItem("Shan/Chen Quadratic");
                      interact = 2;
                      inigui.sete.setEnabled(true);
                  }
                  else if(value.compareTo("Lishchuk") == 0) {
                      inigui.interact.setSelectedItem("Lishchuk");
                      interact = 10;
                      inigui.sete.setEnabled(true);
                  }
                  else if(value.compareTo("LishchukSpencer") == 0) {
                      inigui.interact.setSelectedItem("Lishchuk/Spencer");
                      interact = 11;
                      inigui.sete.setEnabled(true);
                  }
                  else if(value.compareTo("LishchukSpencerTensor") == 0) {
                      inigui.interact.setSelectedItem("Lishchuk/Spencer tensor");
                      interact = 12;
                      inigui.sete.setEnabled(true);
                  }
                  else if(value.compareTo("LishchukLocal") == 0) {
                      inigui.interact.setSelectedItem("Lishchuk Local");
                      interact = 13;
                      inigui.sete.setEnabled(true);
                  }
                  else if(value.compareTo("Swift") == 0) {
                      inigui.interact.setSelectedItem("Swift");
                      interact = 20;
                      inigui.sete.setEnabled(true);
                  }
                  else {
                      inigui.interact.setSelectedItem("none");
                      interact = 0;
                      inigui.sete.setEnabled(false);
                  }
              }
            }
            in.close();
            if(lbd==2 && lbq==9) {
                inigui.model.setSelectedItem("D2Q9");
                inigui.combinez.setEnabled(false);
            }
            else if(lbd==3 && lbq==15) {
                inigui.model.setSelectedItem("D3Q15");
                inigui.combinez.setEnabled(true);
            }
            else if(lbd==3 && lbq==19) {
                inigui.model.setSelectedItem("D3Q19");
                inigui.combinez.setEnabled(true);
            }
            else if(lbd==3 && lbq==27) {
                inigui.model.setSelectedItem("D3Q27");
                inigui.combinez.setEnabled(true);
            }
            dim.lbd = lbd;
            dim.lbnx = Integer.parseInt(inigui.totx.getText());
            dim.lbny = Integer.parseInt(inigui.toty.getText());
            dim.lbnz = Integer.parseInt(inigui.totz.getText());
	} catch (NumberFormatException enf) {
	    ierr(" system parameter: format error or no value ");
	} catch (IOException e) {
            ierr(" error when opening "+filename+" ");
	    System.out.println("Exception: "+e.getMessage());
	}
	try {
            // second pass to find system properties
            Scanner in2 = new Scanner(new File(filename));
            while (in2.hasNext("\\S+")) {
              word = in2.next("\\S+");
              if(word.compareTo("collision_type") == 0) {
                value = in2.next("\\S+");
                if(value.compareTo("BGKEDM") == 0) {
                  inigui.collide.setSelectedItem("BGK/EDM");
                  collide = 1;
                }
                else if(value.compareTo("BGKGuo") == 0) {
                  inigui.collide.setSelectedItem("BGK/Guo");
                  collide = 2;
                }
                else if(value.compareTo("BGKHe") == 0) {
                  inigui.collide.setSelectedItem("BGK/He");
                  collide = 2;
                }
                else if(value.compareTo("TRT") == 0) {
                  inigui.collide.setSelectedItem("TRT");
                  collide = 4;
                }
                else if(value.compareTo("TRTEDM") == 0) {
                  inigui.collide.setSelectedItem("TRT/EDM");
                  collide = 5;
                }
                else if(value.compareTo("TRTGuo") == 0) {
                  inigui.collide.setSelectedItem("TRT/Guo");
                  collide = 6;
                }
                else if(value.compareTo("TRTHe") == 0) {
                  inigui.collide.setSelectedItem("TRT/He");
                  collide = 6;
                }
                else if(value.compareTo("MRT") == 0) {
                  inigui.collide.setSelectedItem("MRT");
                  collide = 8;
                }
                else if(value.compareTo("MRTEDM") == 0) {
                  inigui.collide.setSelectedItem("MRT/EDM");
                  collide = 9;
                }
                else if(value.compareTo("MRTGuo") == 0) {
                  inigui.collide.setSelectedItem("MRT/Guo");
                  collide = 10;
                }
                else if(value.compareTo("MRTHe") == 0) {
                  inigui.collide.setSelectedItem("MRT/He");
                  collide = 11;
                }
                else if(value.compareTo("CLBE") == 0) {
                  inigui.collide.setSelectedItem("CLBE");
                  collide = 12;
                }
                else if(value.compareTo("CLBEEDM") == 0) {
                  inigui.collide.setSelectedItem("CLBE/EDM");
                  collide = 13;
                }
                else if(value.compareTo("CLBEGuo") == 0) {
                  inigui.collide.setSelectedItem("CLBE/Guo");
                  collide = 14;
                }
                else if(value.compareTo("CLBEHe") == 0) {
                  inigui.collide.setSelectedItem("CLBE/He");
                  collide = 15;
                }
                else {
                  inigui.collide.setSelectedItem("BGK");
                  collide = 0;
                }
              }
              else if(word.compareTo("trt_magic_number") == 0) {
                  value = in2.next("\\S+");
                  trtmagic = Double.parseDouble(value);
              }
              else if(word.compareTo("output_format") == 0) {
                value = in2.next("\\S+");
                if(value.compareTo("LegacyVTK") == 0) {
                  inigui.outformat.setSelectedItem("LegacyVTK");
                  outtype = 1;
                }
                else if(value.compareTo("Plot3D") == 0) {
                  inigui.outformat.setSelectedItem("Plot3D");
                  outtype = 2;
                }
                else {
                  inigui.outformat.setSelectedItem("VTK");
                  outtype = 0;
                }
              }
              else if(word.compareTo("output_type") == 0) {
                value = in2.next("\\S+");
                if(value.compareTo("Binary") == 0) {
                  inigui.outansi.setSelected(false);
                  outansi = 0;
                }
                else if(value.compareTo("Text") == 0 || value.compareTo("ANSI") == 0) {
                  inigui.outansi.setSelected(true);
                  outansi = 1;
                }
              }
              else if(word.compareTo("output_combine_x") == 0) {
                value = in2.next("\\S+");
                cx = Integer.signum(Integer.parseInt(value));
                inigui.combinex.setSelected(cx>0);
              }
              else if(word.compareTo("output_combine_y") == 0) {
                value = in2.next("\\S+");
                cy = Integer.signum(Integer.parseInt(value));
                inigui.combiney.setSelected(cy>0);
              }
              else if(word.compareTo("output_combine_z") == 0) {
                value = in2.next("\\S+");
                cz = Integer.signum(Integer.parseInt(value));
                inigui.combinez.setSelected(cz>0);
              }
              else if(word.compareTo("total_step") == 0) {
                value = in2.next("\\S+");
                inigui.tott.setText(value);
              }
              else if(word.compareTo("equilibration_step") == 0) {
                value = in2.next("\\S+");
                inigui.equt.setText(value);
              }
              else if(word.compareTo("save_span") == 0) {
                value = in2.next("\\S+");
                inigui.savet.setText(value);
              }
              else if(word.compareTo("dump_span") == 0) {
                value = in2.next("\\S+");
                inigui.dumpt.setText(value);
              }
              else if(word.compareTo("calculation_time") == 0) {
                value = in2.next("\\S+");
                inigui.calctime.setText(value);
              }
              else if(word.compareTo("noise_intensity") == 0) {
                value = in2.next("\\S+");
                inigui.noiei.setText(value);
              }
              else if(word.compareTo("sound_speed") == 0) {
                value = in2.next("\\S+");
                inigui.soundv.setText(value);
              }
              else if(word.compareTo("kinetic_viscosity") == 0) {
                value = in2.next("\\S+");
                inigui.kineticv.setText(value);
              }
              else if(word.compareTo("oscillating_freq") == 0) {
                value = in2.next("\\S+");
                oscfp = Double.parseDouble(value);
                oscfps = 0;
              }
              else if(word.compareTo("oscillating_period") == 0) {
                value = in2.next("\\S+");
                oscfp = Double.parseDouble(value);
                oscfps = 1;
              }
              else if(word.compareTo("speed_ini_0") == 0) {
                value = in2.next("\\S+");
                iniv[0] = Double.parseDouble(value);
              }
              else if(word.compareTo("speed_ini_1") == 0) {
                value = in2.next("\\S+");
                iniv[1] = Double.parseDouble(value);
              }
              else if(word.compareTo("speed_ini_2") == 0) {
                value = in2.next("\\S+");
                iniv[2] = Double.parseDouble(value);
              }
              else if(word.compareTo("speed_top_0") == 0) {
                value = in2.next("\\S+");
                dim.vel[0] = Double.parseDouble(value);
              }
              else if(word.compareTo("speed_top_1") == 0) {
                value = in2.next("\\S+");
                dim.vel[1] = Double.parseDouble(value);
              }
              else if(word.compareTo("speed_top_2") == 0) {
                value = in2.next("\\S+");
                dim.vel[2] = Double.parseDouble(value);
              }
              else if(word.compareTo("speed_bot_0") == 0) {
                value = in2.next("\\S+");
                dim.vel[3] = Double.parseDouble(value);
              }
              else if(word.compareTo("speed_bot_1") == 0) {
                value = in2.next("\\S+");
                dim.vel[4] = Double.parseDouble(value);
              }
              else if(word.compareTo("speed_bot_2") == 0) {
                value = in2.next("\\S+");
                dim.vel[5] = Double.parseDouble(value);
              }
              else if(word.compareTo("speed_lef_0") == 0) {
                value = in2.next("\\S+");
                dim.vel[6] = Double.parseDouble(value);
              }
              else if(word.compareTo("speed_lef_1") == 0) {
                value = in2.next("\\S+");
                dim.vel[7] = Double.parseDouble(value);
              }
              else if(word.compareTo("speed_lef_2") == 0) {
                value = in2.next("\\S+");
                dim.vel[8] = Double.parseDouble(value);
              }
              else if(word.compareTo("speed_rig_0") == 0) {
                value = in2.next("\\S+");
                dim.vel[9] = Double.parseDouble(value);
              }
              else if(word.compareTo("speed_rig_1") == 0) {
                value = in2.next("\\S+");
                dim.vel[10] = Double.parseDouble(value);
              }
              else if(word.compareTo("speed_rig_2") == 0) {
                value = in2.next("\\S+");
                dim.vel[11] = Double.parseDouble(value);
              }
              else if(word.compareTo("speed_fro_0") == 0) {
                value = in2.next("\\S+");
                dim.vel[12] = Double.parseDouble(value);
              }
              else if(word.compareTo("speed_fro_1") == 0) {
                value = in2.next("\\S+");
                dim.vel[13] = Double.parseDouble(value);
              }
              else if(word.compareTo("speed_fro_2") == 0) {
                value = in2.next("\\S+");
                dim.vel[14] = Double.parseDouble(value);
              }
              else if(word.compareTo("speed_bac_0") == 0) {
                value = in2.next("\\S+");
                dim.vel[15] = Double.parseDouble(value);
              }
              else if(word.compareTo("speed_bac_1") == 0) {
                value = in2.next("\\S+");
                dim.vel[16] = Double.parseDouble(value);
              }
              else if(word.compareTo("speed_bac_2") == 0) {
                value = in2.next("\\S+");
                dim.vel[17] = Double.parseDouble(value);
              }
              else if(word.compareTo("speed_oscil_top_0") == 0) {
                value = in2.next("\\S+");
                dim.velos[0] = Double.parseDouble(value);
              }
              else if(word.compareTo("speed_oscil_top_1") == 0) {
                value = in2.next("\\S+");
                dim.velos[1] = Double.parseDouble(value);
              }
              else if(word.compareTo("speed_oscil_top_2") == 0) {
                value = in2.next("\\S+");
                dim.velos[2] = Double.parseDouble(value);
              }
              else if(word.compareTo("speed_oscil_bot_0") == 0) {
                value = in2.next("\\S+");
                dim.velos[3] = Double.parseDouble(value);
              }
              else if(word.compareTo("speed_oscil_bot_1") == 0) {
                value = in2.next("\\S+");
                dim.velos[4] = Double.parseDouble(value);
              }
              else if(word.compareTo("speed_oscil_bot_2") == 0) {
                value = in2.next("\\S+");
                dim.velos[5] = Double.parseDouble(value);
              }
              else if(word.compareTo("speed_oscil_lef_0") == 0) {
                value = in2.next("\\S+");
                dim.velos[6] = Double.parseDouble(value);
              }
              else if(word.compareTo("speed_oscil_lef_1") == 0) {
                value = in2.next("\\S+");
                dim.velos[7] = Double.parseDouble(value);
              }
              else if(word.compareTo("speed_oscil_lef_2") == 0) {
                value = in2.next("\\S+");
                dim.velos[8] = Double.parseDouble(value);
              }
              else if(word.compareTo("speed_oscil_rig_0") == 0) {
                value = in2.next("\\S+");
                dim.velos[9] = Double.parseDouble(value);
              }
              else if(word.compareTo("speed_oscil_rig_1") == 0) {
                value = in2.next("\\S+");
                dim.velos[10] = Double.parseDouble(value);
              }
              else if(word.compareTo("speed_oscil_rig_2") == 0) {
                value = in2.next("\\S+");
                dim.velos[11] = Double.parseDouble(value);
              }
              else if(word.compareTo("speed_oscil_fro_0") == 0) {
                value = in2.next("\\S+");
                dim.velos[12] = Double.parseDouble(value);
              }
              else if(word.compareTo("speed_oscil_fro_1") == 0) {
                value = in2.next("\\S+");
                dim.velos[13] = Double.parseDouble(value);
              }
              else if(word.compareTo("speed_oscil_fro_2") == 0) {
                value = in2.next("\\S+");
                dim.velos[14] = Double.parseDouble(value);
              }
              else if(word.compareTo("speed_oscil_bac_0") == 0) {
                value = in2.next("\\S+");
                dim.velos[15] = Double.parseDouble(value);
              }
              else if(word.compareTo("speed_oscil_bac_1") == 0) {
                value = in2.next("\\S+");
                dim.velos[16] = Double.parseDouble(value);
              }
              else if(word.compareTo("speed_oscil_bac_2") == 0) {
                value = in2.next("\\S+");
                dim.velos[17] = Double.parseDouble(value);
              }
              else if(word.compareTo("oscillating_freq_top") == 0) {
                value = in2.next("\\S+");
                dim.velospf[0] = Double.parseDouble(value);
                dim.pf[0] = 0;
              }
              else if(word.compareTo("oscillating_period_top") == 0) {
                value = in2.next("\\S+");
                dim.velospf[0] = Double.parseDouble(value);
                dim.pf[0] = 1;
              }
              else if(word.compareTo("oscillating_freq_bot") == 0) {
                value = in2.next("\\S+");
                dim.velospf[1] = Double.parseDouble(value);
                dim.pf[1] = 0;
              }
              else if(word.compareTo("oscillating_period_bot") == 0) {
                value = in2.next("\\S+");
                dim.velospf[1] = Double.parseDouble(value);
                dim.pf[1] = 1;
              }
              else if(word.compareTo("oscillating_freq_lef") == 0) {
                value = in2.next("\\S+");
                dim.velospf[2] = Double.parseDouble(value);
                dim.pf[2] = 0;
              }
              else if(word.compareTo("oscillating_period_lef") == 0) {
                value = in2.next("\\S+");
                dim.velospf[2] = Double.parseDouble(value);
                dim.pf[2] = 1;
              }
              else if(word.compareTo("oscillating_freq_rig") == 0) {
                value = in2.next("\\S+");
                dim.velospf[3] = Double.parseDouble(value);
                dim.pf[3] = 0;
              }
              else if(word.compareTo("oscillating_period_rig") == 0) {
                value = in2.next("\\S+");
                dim.velospf[3] = Double.parseDouble(value);
                dim.pf[3] = 1;
              }
              else if(word.compareTo("oscillating_freq_fro") == 0) {
                value = in2.next("\\S+");
                dim.velospf[4] = Double.parseDouble(value);
                dim.pf[4] = 0;
              }
              else if(word.compareTo("oscillating_period_fro") == 0) {
                value = in2.next("\\S+");
                dim.velospf[4] = Double.parseDouble(value);
                dim.pf[4] = 1;
              }
              else if(word.compareTo("oscillating_freq_bac") == 0) {
                value = in2.next("\\S+");
                dim.velospf[5] = Double.parseDouble(value);
                dim.pf[5] = 0;
              }
              else if(word.compareTo("oscillating_period_bac") == 0) {
                value = in2.next("\\S+");
                dim.velospf[5] = Double.parseDouble(value);
                dim.pf[5] = 1;
              }
              else if(word.compareTo("segregation") == 0) {
                value = in2.next("\\S+");
                segregate = Double.parseDouble(value);
              }
              else if(word.compareTo("surface_tension_parameter") == 0) {
                  value = in2.next("\\S+");
                  fekappa = Double.parseDouble(value);
              }
              else if(word.compareTo("relax_mobility") == 0) {
                  value = in2.next("\\S+");
                  mobrelax = Double.parseDouble(value);
              }
              else if(word.compareTo("relax_freq_mobility") == 0) {
                  value = in2.next("\\S+");
                  mobrelax = 1.0/Double.parseDouble(value);
              }
              else if(word.compareTo("mobility_parameter") == 0) {
                  value = in2.next("\\S+");
                  mobility = Double.parseDouble(value);
              }
              else if(word.compareTo("eos_parameter_a") == 0) {
                  value = in2.next("\\S+");
                  eosa[0] = Double.parseDouble(value);
              }
              else if(word.compareTo("eos_parameter_b") == 0) {
                  value = in2.next("\\S+");
                  eosb[0] = Double.parseDouble(value);
              }
              else if(word.compareTo("potential_parameter_a") == 0) {
                  value = in2.next("\\S+");
                  eosa[1] = Double.parseDouble(value);
              }
              else if(word.compareTo("potential_parameter_b") == 0) {
                  value = in2.next("\\S+");
                  eosb[1] = Double.parseDouble(value);
              }
              else if(word.compareTo("temperature_system") == 0) {
                  value = in2.next("\\S+");
                  tempsys = Double.parseDouble(value);
              }
              else if(word.compareTo("gas_constant") == 0) {
                  value = in2.next("\\S+");
                  gascon = Double.parseDouble(value);
              }
              else if(word.compareTo("quadratic_weight") == 0) {
                  value = in2.next("\\S+");
                  for(i=0; i<lbf; i++) {
                      quadw[i] = Double.parseDouble(value);
                  }
              }
              else if(word.compareTo("gradient_order") == 0) {
                  value = in2.next("\\S+");
                  dim.gradord = Integer.parseInt(value);
                  if(dim.gradord<1)
                      dim.gradord = 1;
                  else if(dim.gradord>2)
                      dim.gradord = 2;
              }
              else if(word.compareTo("boundary_type") == 0) {
                  value = in2.next("\\S+");
                  if(value.compareTo("ZouHe") == 0) {
                      dim.bctyp = 0;
                  }
                  else if(value.compareTo("SimpleZouHe") == 0) {
                      dim.bctyp = 1;
                  }
                  else if(value.compareTo("Inamuro") == 0) {
                      dim.bctyp = 2;
                  }
                  else if(value.compareTo("Regularised") == 0 || value.compareTo("Regularized") == 0) {
                      dim.bctyp = 3;
                  }
                  else if(value.compareTo("Kinetic") == 0) {
                      dim.bctyp = 4;
                  }
              }
              else if(word.compareTo("solute_boundary_type") == 0) {
                  value = in2.next("\\S+");
                  if(value.compareTo("ZouHe") == 0) {
                      dim.sbctyp = 0;
                  }
                  else if(value.compareTo("Inamuro") == 0) {
                      dim.sbctyp = 1;
                  }
              }
              else if(word.compareTo("thermal_boundary_type") == 0) {
                  value = in2.next("\\S+");
                  if(value.compareTo("ZouHe") == 0) {
                      dim.tbctyp = 0;
                  }
                  else if(value.compareTo("Inamuro") == 0) {
                      dim.tbctyp = 1;
                  }
              }
              else if(word.compareTo("equation_of_state") == 0) {
                  value = in2.next("\\S+");
                  if(value.compareTo("IdealLattice")==0) {
                      eos[0] = 0;
                  }
                  else if(value.compareTo("ShanChen1993")==0) {
                      eos[0] = 1;
                  }
                  else if(value.compareTo("ShanChen1994")==0) {
                      eos[0] = 2;
                  }
                  else if(value.compareTo("Qian1995")==0) {
                      eos[0] = 3;
                  }
                  else if(value.compareTo("Rho")==0) {
                      eos[0] = 4;
                  }
                  else if(value.compareTo("Ideal")==0) {
                      eos[0] = 5;
                  }
                  else if(value.compareTo("vanderWaals")==0 || value.compareTo("vdW")==0) {
                      eos[0] = 6;
                  }
                  else if(value.compareTo("RedlichKwong")==0 || value.compareTo("RK")==0) {
                      eos[0] = 7;
                  }
                  else if(value.compareTo("SoaveRedlichKwong")==0 || value.compareTo("SRK")==0) {
                      eos[0] = 8;
                  }
                  else if(value.compareTo("PengRobinson")==0 || value.compareTo("PR")==0) {
                      eos[0] = 9;
                  }
                  else if(value.compareTo("CarnahanStarlingvanderWaals")==0 || value.compareTo("CSvdW")==0) {
                      eos[0] = 10;
                  }
                  else if(value.compareTo("CarnahanStarlingRedlichKwong")==0 || value.compareTo("CSRK")==0) {
                      eos[0] = 11;
                  }
              }
              else if(word.compareTo("potential_type") == 0) {
                  value = in2.next("\\S+");
                  if(value.compareTo("IdealLattice")==0) {
                      for(i=0; i<lbf; i++) {
                          eos[i] = 0;
                      }
                  }
                  else if(value.compareTo("ShanChen1993")==0) {
                      for(i=0; i<lbf; i++) {
                          eos[i] = 1;
                      }
                  }
                  else if(value.compareTo("ShanChen1994")==0) {
                      for(i=0; i<lbf; i++) {
                          eos[i] = 2;
                      }
                  }
                  else if(value.compareTo("Qian1995")==0) {
                      for(i=0; i<lbf; i++) {
                          eos[i] = 3;
                      }
                  }
                  else if(value.compareTo("Rho")==0) {
                      for(i=0; i<lbf; i++) {
                          eos[i] = 4;
                      }
                  }
                  else if(value.compareTo("Ideal")==0) {
                      for(i=0; i<lbf; i++) {
                          eos[i] = 5;
                      }
                  }
                  else if(value.compareTo("vanderWaals")==0 || value.compareTo("vdW")==0) {
                      for(i=0; i<lbf; i++) {
                          eos[i] = 6;
                      }
                  }
                  else if(value.compareTo("RedlichKwong")==0 || value.compareTo("RK")==0) {
                      for(i=0; i<lbf; i++) {
                          eos[i] = 7;
                      }
                  }
                  else if(value.compareTo("SoaveRedlichKwong")==0 || value.compareTo("SRK")==0) {
                      for(i=0; i<lbf; i++) {
                          eos[i] = 8;
                      }
                  }
                  else if(value.compareTo("PengRobinson")==0 || value.compareTo("PR")==0) {
                      for(i=0; i<lbf; i++) {
                          eos[i] = 9;
                      }
                  }
                  else if(value.compareTo("CarnahanStarlingvanderWaals")==0 || value.compareTo("CSvdW")==0) {
                      for(i=0; i<lbf; i++) {
                          eos[i] = 10;
                      }
                  }
                  else if(value.compareTo("CarnahanStarlingRedlichKwong")==0 || value.compareTo("CSRK")==0) {
                      for(i=0; i<lbf; i++) {
                          eos[i] = 11;
                      }
                  }
                  else if(value.compareTo("None")==0) {
                      eos[1] = 0;
                  }
                  else if(value.compareTo("Quartic")==0) {
                      eos[1] = 1;
                  }
              }
              else if(word.compareTo("wetting_type") == 0) {
                  value = in2.next("\\S+");
                  if(value.compareTo("Density")==0) {
                      for(i=0; i<lbf; i++) {
                          wettyp[i] = 0;
                      }
                  }
                  else if(value.compareTo("Potential")==0) {
                      for(i=0; i<lbf; i++) {
                          wettyp[i] = 1;
                      }
                  }
                  else if(value.compareTo("ScreenedPotential")==0) {
                      for(i=0; i<lbf; i++) {
                          wettyp[i] = 2;
                      }
                  }
                  else if(value.compareTo("None")==0) {
                      wettyp[0] = 0;
                  }
                  else if(value.compareTo("Quadratic")==0) {
                      wettyp[0] = 1;
                  }
              }
              else if(word.compareTo("wetting_parameter_rho_0")==0) {
                  value = in2.next("\\S+");
                  wallinteract[0] = Double.parseDouble(value);
              }
              else if(word.compareTo("wetting_parameter_rho_1")==0) {
                  value = in2.next("\\S+");
                  wallinteract[1] = Double.parseDouble(value);
              }
              else if(word.compareTo("wetting_parameter_phi_0")==0) {
                  value = in2.next("\\S+");
                  wallinteract[2] = Double.parseDouble(value);
              }
              else if(word.compareTo("wetting_parameter_phi_1")==0) {
                  value = in2.next("\\S+");
                  wallinteract[3] = Double.parseDouble(value);
              }
            
            // find mrt relaxation times/frequencies
              for(i=0; i<8; i++) {
                compare1 = "mrt_relax_"+i;
                compare2 = "mrt_relax_freq_"+i;
                if(word.compareTo(compare1) == 0) {
                  value = in2.next("\\S+");
                  mrtrelaxfreq[i] = 1.0/Double.parseDouble(value);
                }
                else if(word.compareTo(compare2)==0) {
                  value = in2.next("\\S+");
                  mrtrelaxfreq[i] = Double.parseDouble(value);
                }
              }

            // find fluid properties
              for(i=0; i<lbf; i++) {
                compare1 = "body_force_"+(3*i);
                compare2 = "body_force_x_"+i;
                if(word.compareTo(compare1) == 0 || word.compareTo(compare2) == 0) {
                  value = in2.next("\\S+");
                  bdf[3*i] = Double.parseDouble(value);
                }
                compare1 = "body_force_"+(3*i+1);
                compare2 = "body_force_y_"+i;
                if(word.compareTo(compare1) == 0 || word.compareTo(compare2) == 0) {
                  value = in2.next("\\S+");
                  bdf[3*i+1] = Double.parseDouble(value);
                }
                compare1 = "body_force_"+(3*i+2);
                compare2 = "body_force_z_"+i;
                if(word.compareTo(compare1) == 0 || word.compareTo(compare2) == 0) {
                  value = in2.next("\\S+");
                  bdf[3*i+2] = Double.parseDouble(value);
                }
                compare1 = "oscillating_force_"+(3*i);
                compare2 = "oscillating_force_x_"+i;
                if(word.compareTo(compare1) == 0 || word.compareTo(compare2) == 0) {
                  value = in2.next("\\S+");
                  oscf[3*i] = Double.parseDouble(value);
                }
                compare1 = "oscillating_force_"+(3*i+1);
                compare2 = "oscillating_force_y_"+i;
                if(word.compareTo(compare1) == 0 || word.compareTo(compare2) == 0) {
                  value = in2.next("\\S+");
                  oscf[3*i+1] = Double.parseDouble(value);
                }
                compare1 = "oscillating_force_"+(3*i+2);
                compare2 = "oscillating_force_z_"+i;
                if(word.compareTo(compare1) == 0 || word.compareTo(compare2) == 0) {
                  value = in2.next("\\S+");
                  oscf[3*i+2] = Double.parseDouble(value);
                }
                compare1 = "boussinesq_force_"+(3*i);
                compare2 = "boussinesq_force_x_"+i;
                if(word.compareTo(compare1) == 0 || word.compareTo(compare2) == 0) {
                  value = in2.next("\\S+");
                  bousf[3*i] = Double.parseDouble(value);
                }
                compare1 = "boussinesq_force_"+(3*i+1);
                compare2 = "boussinesq_force_y_"+i;
                if(word.compareTo(compare1) == 0 || word.compareTo(compare2) == 0) {
                  value = in2.next("\\S+");
                  bousf[3*i+1] = Double.parseDouble(value);
                }
                compare1 = "boussinesq_force_"+(3*i+2);
                compare2 = "boussinesq_force_z_"+i;
                if(word.compareTo(compare1) == 0 || word.compareTo(compare2) == 0) {
                  value = in2.next("\\S+");
                  bousf[3*i+2] = Double.parseDouble(value);
                }
                compare1 = "density_ini_"+i;
                if(word.compareTo(compare1) == 0) {
                  value = in2.next("\\S+");
                  densfic[2*i] = Double.parseDouble(value);
                }
                compare1 = "density_inc_"+i;
                if(word.compareTo(compare1) == 0) {
                  value = in2.next("\\S+");
                  densfic[2*i+1] = Double.parseDouble(value);
                }
                compare1 = "density_top_"+i;
                if(word.compareTo(compare1) == 0) {
                  value = in2.next("\\S+");
                  dim.densf[6*i] = Double.parseDouble(value);
                }
                compare1 = "density_bot_"+i;
                if(word.compareTo(compare1) == 0) {
                  value = in2.next("\\S+");
                  dim.densf[6*i+1] = Double.parseDouble(value);
                }
                compare1 = "density_lef_"+i;
                if(word.compareTo(compare1) == 0) {
                  value = in2.next("\\S+");
                  dim.densf[6*i+2] = Double.parseDouble(value);
                }
                compare1 = "density_rig_"+i;
                if(word.compareTo(compare1) == 0) {
                  value = in2.next("\\S+");
                  dim.densf[6*i+3] = Double.parseDouble(value);
                }
                compare1 = "density_fro_"+i;
                if(word.compareTo(compare1) == 0) {
                  value = in2.next("\\S+");
                  dim.densf[6*i+4] = Double.parseDouble(value);
                }
                compare1 = "density_bac_"+i;
                if(word.compareTo(compare1) == 0) {
                  value = in2.next("\\S+");
                  dim.densf[6*i+5] = Double.parseDouble(value);
                }
                compare1 = "relaxation_fluid_"+i;
                if(word.compareTo(compare1) == 0) {
                  value = in2.next("\\S+");
                  relaxtime[4*i] = Double.parseDouble(value);
                }
                compare1 = "relax_freq_fluid_"+i;
                if(word.compareTo(compare1) == 0) {
                  value = in2.next("\\S+");
                  relaxtime[4*i] = 1.0/Double.parseDouble(value);
                }
                compare1 = "bulk_relaxation_fluid_"+i;
                if(word.compareTo(compare1) == 0) {
                  value = in2.next("\\S+");
                  relaxtime[4*i+1] = Double.parseDouble(value);
                }
                compare1 = "bulk_relax_freq_fluid_"+i;
                if(word.compareTo(compare1) == 0) {
                  value = in2.next("\\S+");
                  relaxtime[4*i+1] = 1.0/Double.parseDouble(value);
                }
                compare1 = "clbe3_relaxation_fluid_"+i;
                if(word.compareTo(compare1) == 0) {
                  value = in2.next("\\S+");
                  relaxtime[4*i+2] = Double.parseDouble(value);
                }
                compare1 = "clbe3_relax_freq_fluid_"+i;
                if(word.compareTo(compare1) == 0) {
                  value = in2.next("\\S+");
                  relaxtime[4*i+2] = 1.0/Double.parseDouble(value);
                }
                compare1 = "clbe4_relaxation_fluid_"+i;
                if(word.compareTo(compare1) == 0) {
                  value = in2.next("\\S+");
                  relaxtime[4*i+3] = Double.parseDouble(value);
                }
                compare1 = "clbe4_relax_freq_fluid_"+i;
                if(word.compareTo(compare1) == 0) {
                  value = in2.next("\\S+");
                  relaxtime[4*i+3] = 1.0/Double.parseDouble(value);
                }
                compare1 = "wall_interaction_"+i;
                if(word.compareTo(compare1) == 0) {
                  value = in2.next("\\S+");
                  wallinteract[i] = Double.parseDouble(value);
                }
                compare1 = "shanchen_psi0_"+i;
                if(word.compareTo(compare1) == 0) {
                  value = in2.next("\\S+");
                  psi0[i] = Double.parseDouble(value);
                }
                compare1 = "critical_temperature_"+i;
                if(word.compareTo(compare1) == 0) {
                  value = in2.next("\\S+");
                  eosa[i] = Double.parseDouble(value);
                  eoscrit = 1;
                }
                compare1 = "critical_pressure_"+i;
                if(word.compareTo(compare1) == 0) {
                  value = in2.next("\\S+");
                  eosb[i] = Double.parseDouble(value);
                  eoscrit = 1;
                }
                compare1 = "eos_parameter_a_"+i;
                if(word.compareTo(compare1) == 0) {
                  value = in2.next("\\S+");
                  eosa[i] = Double.parseDouble(value);
                  eoscrit = 0;
                }
                compare1 = "eos_parameter_b_"+i;
                if(word.compareTo(compare1) == 0) {
                  value = in2.next("\\S+");
                  eosb[i] = Double.parseDouble(value);
                  eoscrit = 0;
                }
                compare1 = "acentric_factor_"+i;
                if(word.compareTo(compare1) == 0) {
                  value = in2.next("\\S+");
                  acentric[i] = Double.parseDouble(value);
                }
                compare1 = "potential_type_"+i;
                if(word.compareTo(compare1) == 0) {
                  value = in2.next("\\S+");
                    if(value.compareTo("IdealLattice")==0) {
                        eos[i] = 0;
                    }
                    else if(value.compareTo("ShanChen1993")==0) {
                        eos[i] = 1;
                    }
                    else if(value.compareTo("ShanChen1994")==0) {
                        eos[i] = 2;
                    }
                    else if(value.compareTo("Rho")==0) {
                        eos[i] = 3;
                    }
                    else if(value.compareTo("Ideal")==0) {
                        eos[i] = 4;
                    }
                    else if(value.compareTo("vanderWaals")==0 || value.compareTo("vdW")==0) {
                        eos[i] = 5;
                    }
                    else if(value.compareTo("RedlichKwong")==0 || value.compareTo("RK")==0) {
                        eos[i] = 6;
                    }
                    else if(value.compareTo("SoaveRedlichKwong")==0 || value.compareTo("SRK")==0) {
                        eos[i] = 7;
                    }
                    else if(value.compareTo("PengRobinson")==0 || value.compareTo("PR")==0) {
                        eos[i] = 8;
                    }
                    else if(value.compareTo("CarnahanStarlingvanderWaals")==0 || value.compareTo("CSvdW")==0) {
                        eos[i] = 9;
                    }
                    else if(value.compareTo("CarnahanStarlingRedlichKwong")==0 || value.compareTo("CSRK")==0) {
                        eos[i] = 10;
                    }
                }
                compare1 = "wetting_type_"+i;
                if(word.compareTo(compare1) == 0) {
                  value = in2.next("\\S+");
                    if(value.compareTo("Density")==0) {
                        wettyp[i] = 0;
                    }
                    else if(value.compareTo("Potential")==0) {
                        wettyp[i] = 1;
                    }
                    else if(value.compareTo("ScreenedPotential")==0) {
                        wettyp[i] = 2;
                    }
                }
                compare1 = "quadratic_weight_"+(i*lbf+i);
                compare2 = "quadratic_weight_"+i+"_"+i;
                if(word.compareTo(compare1)==0 || word.compareTo(compare2)==0) {
                    value = in2.next("\\S+");
                    quadw[i] = Double.parseDouble(value);
                }
                compare1 = "rheology_fluid_"+i;
                if(word.compareTo(compare1) == 0) {
                  value = in2.next("\\S+");
                    if(value.compareTo("Simple")==0) {
                        rheomodel[i] = 0;
                    }
                    else if(value.compareTo("Newtonian")==0) {
                        rheomodel[i] = 1;
                    }
                    else if(value.compareTo("PowerLaw")==0 || value.compareTo("Power")==0) {
                        rheomodel[i] = 2;
                    }
                    else if(value.compareTo("Bingham")==0) {
                        rheomodel[i] = 3;
                    }
                    else if(value.compareTo("HerschelBulkley")==0 || value.compareTo("Herschel")==0) {
                        rheomodel[i] = 4;
                    }
                    else if(value.compareTo("Casson")==0) {
                        rheomodel[i] = 5;
                    }
                    else if(value.compareTo("CarreauYasuda")==0 || value.compareTo("Carreau")==0) {
                        rheomodel[i] = 6;
                    }
                }
                compare1 = "rheology_parameter_a_"+i;
                if(word.compareTo(compare1)==0) {
                    value = in2.next("\\S+");
                    rheoparama[i] = Double.parseDouble(value);
                }
                compare1 = "rheology_parameter_b_"+i;
                if(word.compareTo(compare1)==0) {
                    value = in2.next("\\S+");
                    rheoparamb[i] = Double.parseDouble(value);
                }
                compare1 = "rheology_parameter_c_"+i;
                if(word.compareTo(compare1)==0) {
                    value = in2.next("\\S+");
                    rheoparamc[i] = Double.parseDouble(value);
                }
                compare1 = "rheology_parameter_d_"+i;
                if(word.compareTo(compare1)==0) {
                    value = in2.next("\\S+");
                    rheoparamd[i] = Double.parseDouble(value);
                }
                compare1 = "rheology_power_"+i;
                if(word.compareTo(compare1)==0) {
                    value = in2.next("\\S+");
                    rheopower[i] = Double.parseDouble(value);
                }
                  
                for (j=0; j<lbf; j++) {
                  compare1 = "interaction_"+(i*lbf+j);
                  compare2 = "interaction_"+i+"_"+j;
                  if(word.compareTo(compare1) == 0) {
                    value = in2.next("\\S+");
                    fluidinteract[i*lbf+j] = Double.parseDouble(value);                  
                  }
                  else if(word.compareTo(compare2) == 0) {
                    value = in2.next("\\S+");
                    fluidinteract[i*lbf+j] = Double.parseDouble(value);                  
                    fluidinteract[j*lbf+i] = Double.parseDouble(value);                  
                  }
                  compare1 = "segregation_"+(i*lbf+j);
                  compare2 = "segregation_"+i+"_"+j;
                  if(word.compareTo(compare1) == 0) {
                    value = in2.next("\\S+");
                    segregate = Double.parseDouble(value);                  
                  }
                  else if(word.compareTo(compare2) == 0) {
                    value = in2.next("\\S+");
                    segregate = Double.parseDouble(value);                  
                  }
                }
              }
            // find solute properties
              if(lbc>0) {
                for(i=0; i<lbc; i++) {
                  compare1 = "solute_ini_"+i;
                  if(word.compareTo(compare1) == 0) {
                    value = in2.next("\\S+");
                    concsi[i] = Double.parseDouble(value);
                  }
                  compare1 = "solute_top_"+i;
                  if(word.compareTo(compare1) == 0) {
                    value = in2.next("\\S+");
                    dim.conc[6*i] = Double.parseDouble(value);
                  }
                  compare1 = "solute_bot_"+i;
                  if(word.compareTo(compare1) == 0) {
                    value = in2.next("\\S+");
                    dim.conc[6*i+1] = Double.parseDouble(value);
                  }
                  compare1 = "solute_lef_"+i;
                  if(word.compareTo(compare1) == 0) {
                    value = in2.next("\\S+");
                    dim.conc[6*i+2] = Double.parseDouble(value);
                  }
                  compare1 = "solute_rig_"+i;
                  if(word.compareTo(compare1) == 0) {
                    value = in2.next("\\S+");
                    dim.conc[6*i+3] = Double.parseDouble(value);
                  }
                  compare1 = "solute_fro_"+i;
                  if(word.compareTo(compare1) == 0) {
                    value = in2.next("\\S+");
                    dim.conc[6*i+4] = Double.parseDouble(value);
                  }
                  compare1 = "solute_bac_"+i;
                  if(word.compareTo(compare1) == 0) {
                    value = in2.next("\\S+");
                    dim.conc[6*i+5] = Double.parseDouble(value);
                  }
                  compare1 = "relax_solute_"+i;
                  if(word.compareTo(compare1) == 0) {
                    value = in2.next("\\S+");
                    solrelax[i] = Double.parseDouble(value);
                  }
                  compare1 = "relax_freq_solute_"+i;
                  if(word.compareTo(compare1) == 0) {
                    value = in2.next("\\S+");
                    solrelax[i] = 1.0/Double.parseDouble(value);
                  }
                }
              }
            // find thermal properties
              if(lbt>0) {
                if(word.compareTo("temperature_boussinesq_high") == 0) {
                  value = in2.next("\\S+");
                  boustemph = Double.parseDouble(value);
                }
                else if(word.compareTo("temperature_boussinesq_low") == 0) {
                  value = in2.next("\\S+");
                  boustempl = Double.parseDouble(value);
                }
                else if(word.compareTo("temperature_ini") == 0) {
                  value = in2.next("\\S+");
                  tempsi = Double.parseDouble(value);
                }
                else if(word.compareTo("temperature_top") == 0) {
                  value = in2.next("\\S+");
                  dim.temp[0] = Double.parseDouble(value);
                }
                else if(word.compareTo("temperature_bottom") == 0) {
                  value = in2.next("\\S+");
                  dim.temp[1] = Double.parseDouble(value);
                }
                else if(word.compareTo("temperature_left") == 0) {
                  value = in2.next("\\S+");
                  dim.temp[2] = Double.parseDouble(value);
                }
                else if(word.compareTo("temperature_right") == 0) {
                  value = in2.next("\\S+");
                  dim.temp[3] = Double.parseDouble(value);
                }
                else if(word.compareTo("temperature_front") == 0) {
                  value = in2.next("\\S+");
                  dim.temp[4] = Double.parseDouble(value);
                }
                else if(word.compareTo("temperature_back") == 0) {
                  value = in2.next("\\S+");
                  dim.temp[5] = Double.parseDouble(value);
                }
                else if(word.compareTo("heating_rate_sys") == 0) {
                  value = in2.next("\\S+");
                  heatratei = Double.parseDouble(value);
                }
                else if(word.compareTo("heating_rate_top") == 0) {
                  value = in2.next("\\S+");
                  dim.tempdt[0] = Double.parseDouble(value);
                }
                else if(word.compareTo("heating_rate_bottom") == 0) {
                  value = in2.next("\\S+");
                  dim.tempdt[1] = Double.parseDouble(value);
                }
                else if(word.compareTo("heating_rate_left") == 0) {
                  value = in2.next("\\S+");
                  dim.tempdt[2] = Double.parseDouble(value);
                }
                else if(word.compareTo("heating_rate_right") == 0) {
                  value = in2.next("\\S+");
                  dim.tempdt[3] = Double.parseDouble(value);
                }
                else if(word.compareTo("heating_rate_front") == 0) {
                  value = in2.next("\\S+");
                  dim.tempdt[4] = Double.parseDouble(value);
                }
                else if(word.compareTo("heating_rate_back") == 0) {
                  value = in2.next("\\S+");
                  dim.tempdt[5] = Double.parseDouble(value);
                }
                else if(word.compareTo("relax_thermal") == 0) {
                  value = in2.next("\\S+");
                  heatrelax = Double.parseDouble(value);
                }
                else if(word.compareTo("relax_freq_thermal") == 0) {
                  value = in2.next("\\S+");
                  heatrelax = 1.0/Double.parseDouble(value);
                }
              } 
            } 
            in2.close();
        } catch (NumberFormatException enf) {
            ierr(" system parameter: format error or no value ");
        } catch (IOException e) {
            ierr(" error when opening "+filename+" ");
            System.out.println("Exception: "+e.getMessage());
        }
    }

    public void itemStateChanged(ItemEvent event) {
        Object item=event.getItem();
        String answer=item.toString();
        String compare;
        int i;
        Boolean j, j1, j2, j3, j4, k, ka, kb, kc, kd, kn;
        Boolean select1=inigui.yest.isSelected();
        Boolean select2=inigui.outansi.isSelected();
        
        if (select1)
           lbt = 1;
        else {
           lbt = 0;
        }
        if (select2)
            outansi = 1;
        else {
            outansi = 0;
        }

	    if(answer == "D2Q9") {
	      lbd = 2;
	      lbq = 9;
          inigui.combinez.setEnabled(false);
	    }

	    else if((answer == "D3Q15") || (answer == "D3Q19") ||(answer == "D3Q27")) {
	      lbd=3;
          inigui.combinez.setEnabled(true);
          if(answer == "D3Q15")
            lbq = 15;
          else if(answer == "D3Q19")
            lbq = 19;
          else
            lbq = 27;
        }
        else if(answer == "BGK") {
          collide=0;
        }
        else if(answer == "BGK/EDM") {
          collide=1;
        }
        else if(answer == "BGK/Guo") {
          collide=2;
        }
        else if(answer == "BGK/He") {
          collide=3;
        }
        else if(answer == "TRT") {
          collide=4;
        }
        else if(answer == "TRT/EDM") {
          collide=5;
        }
        else if(answer == "TRT/Guo") {
          collide=6;
        }
        else if(answer == "TRT/He") {
          collide=7;
        }
        else if(answer == "MRT") {
          collide=8;
        }
        else if(answer == "MRT/EDM") {
          collide=9;
        }
        else if(answer == "MRT/Guo") {
          collide=10;
        }
        else if(answer == "MRT/He") {
          collide=11;
        }
        else if(answer == "CLBE") {
          collide=12;
        }
        else if(answer == "CLBE/EDM") {
          collide=13;
        }
        else if(answer == "CLBE/Guo") {
          collide=14;
        }
        else if(answer == "CLBE/He") {
          collide=15;
        }

        else if(answer == "no interactions") {
            interact=0;
			inigui.sete.setEnabled(false);
		}
        else if(answer == "Shan/Chen") {
            interact=1;
			inigui.sete.setEnabled(true);
		}
		else if(answer == "Shan/Chen Quadratic") {
		    interact=2;
			inigui.sete.setEnabled(true);
		}
        else if(answer == "Lishchuk") {
            interact=10;
			inigui.sete.setEnabled(true);
		}
		else if(answer == "Lishchuk/Spencer") {
            interact=11;
			inigui.sete.setEnabled(true);
		}
		else if(answer == "Lishchuk/Spencer tensor") {
            interact=12;
			inigui.sete.setEnabled(true);
		}
		else if(answer == "Lishchuk Local") {
            interact=13;
			inigui.sete.setEnabled(true);
		}
        else if(answer == "Swift") {
            interact=20;
			inigui.sete.setEnabled(true);
		}

        else if(answer == "VTK")
            outtype=0;
        else if(answer == "LegacyVTK")
            outtype=1;
        else if(answer == "Plot3D")
            outtype=1;

		else if(item == inigui.phaseyes)
			lbp=1;   

		else if(item == inigui.phaseno)
			lbp=0;
        
        else if(answer == "eos parameters") {
            ig.eosalabel.setText("a:");
            ig.eosblabel.setText("b:");
            eoscrit = 0;
        }

        else if(answer == "critical properties") {
            ig.eosalabel.setText("Tc:");
            ig.eosblabel.setText("Pc:");
            eoscrit = 1;
        }

        try {
            if(event.getSource() instanceof JComboBox) {
                JComboBox combo = (JComboBox) event.getSource();
                k = false; ka = false; kb = false; kc = false; kd = false; kn = false;
                for(i=0; i<lbf; i++) {
                    compare = "rheo"+i;
                    if(compare.equals(combo.getName())) {
                        rheomodel[i] = fg.rheo[i].getSelectedIndex();
                        if(answer=="simple Newtonian") {
                            fg.rheoaparam[i].setEnabled(false);
                            fg.rheoaparam[i].setEditable(false);
                            fg.rheobparam[i].setEnabled(false);
                            fg.rheobparam[i].setEditable(false);
                            fg.rheocparam[i].setEnabled(false);
                            fg.rheocparam[i].setEditable(false);
                            fg.rheodparam[i].setEnabled(false);
                            fg.rheodparam[i].setEditable(false);
                            fg.rheopower[i].setEnabled(false);
                            fg.rheopower[i].setEditable(false);
                        }
                        else if(answer=="Newtonian") {
                            fg.rheoaparam[i].setEnabled(true);
                            fg.rheoaparam[i].setEditable(true);
                            fg.rheobparam[i].setEnabled(false);
                            fg.rheobparam[i].setEditable(false);
                            fg.rheocparam[i].setEnabled(false);
                            fg.rheocparam[i].setEditable(false);
                            fg.rheodparam[i].setEnabled(false);
                            fg.rheodparam[i].setEditable(false);
                            fg.rheopower[i].setEnabled(false);
                            fg.rheopower[i].setEditable(false);
                        }
                        else if(answer=="power law") {
                            fg.rheoaparam[i].setEnabled(true);
                            fg.rheoaparam[i].setEditable(true);
                            fg.rheobparam[i].setEnabled(false);
                            fg.rheobparam[i].setEditable(false);
                            fg.rheocparam[i].setEnabled(false);
                            fg.rheocparam[i].setEditable(false);
                            fg.rheodparam[i].setEnabled(false);
                            fg.rheodparam[i].setEditable(false);
                            fg.rheopower[i].setEnabled(true);
                            fg.rheopower[i].setEditable(true);
                        }
                        else if(answer=="Bingham") {
                            fg.rheoaparam[i].setEnabled(true);
                            fg.rheoaparam[i].setEditable(true);
                            fg.rheobparam[i].setEnabled(true);
                            fg.rheobparam[i].setEditable(true);
                            fg.rheocparam[i].setEnabled(true);
                            fg.rheocparam[i].setEditable(true);
                            fg.rheodparam[i].setEnabled(false);
                            fg.rheodparam[i].setEditable(false);
                            fg.rheopower[i].setEnabled(false);
                            fg.rheopower[i].setEditable(false);
                        }
                        else if(answer=="Herschel-Bulkley") {
                            fg.rheoaparam[i].setEnabled(true);
                            fg.rheoaparam[i].setEditable(true);
                            fg.rheobparam[i].setEnabled(true);
                            fg.rheobparam[i].setEditable(true);
                            fg.rheocparam[i].setEnabled(true);
                            fg.rheocparam[i].setEditable(true);
                            fg.rheodparam[i].setEnabled(false);
                            fg.rheodparam[i].setEditable(false);
                            fg.rheopower[i].setEnabled(true);
                            fg.rheopower[i].setEditable(true);
                        }
                        else if(answer=="Casson") {
                            fg.rheoaparam[i].setEnabled(true);
                            fg.rheoaparam[i].setEditable(true);
                            fg.rheobparam[i].setEnabled(true);
                            fg.rheobparam[i].setEditable(true);
                            fg.rheocparam[i].setEnabled(true);
                            fg.rheocparam[i].setEditable(true);
                            fg.rheodparam[i].setEnabled(false);
                            fg.rheodparam[i].setEditable(false);
                            fg.rheopower[i].setEnabled(false);
                            fg.rheopower[i].setEditable(false);
                        }
                        else if(answer=="Carreau-Yasuda") {
                            fg.rheoaparam[i].setEnabled(true);
                            fg.rheoaparam[i].setEditable(true);
                            fg.rheobparam[i].setEnabled(true);
                            fg.rheobparam[i].setEditable(true);
                            fg.rheocparam[i].setEnabled(true);
                            fg.rheocparam[i].setEditable(true);
                            fg.rheodparam[i].setEnabled(true);
                            fg.rheodparam[i].setEditable(true);
                            fg.rheopower[i].setEnabled(true);
                            fg.rheopower[i].setEditable(true);
                        }
                    }
                    ka = (ka || rheomodel[i]>0);
                    kb = (kb || rheomodel[i]>2);
                    kc = (kc || rheomodel[i]>2);
                    kd = (kd || rheomodel[i]>5);
                    kn = (kn || rheomodel[i]==2 || rheomodel[i]==4 || rheomodel[i]==6);
                    compare = "eos"+i;
                    if(compare.equals(combo.getName())) {
                        if(answer=="lattice gas" || answer=="ideal gas") {
                            ig.eosabox[i].setEnabled(false);
                            ig.eosabox[i].setEditable(false);
                            ig.eosbbox[i].setEnabled(false);
                            ig.eosbbox[i].setEditable(false);
                            ig.acentricbox[i].setEnabled(false);
                            ig.acentricbox[i].setEditable(false);
                            if(interact==1 || interact==2) {
                                ig.psi0box[i].setEnabled(false);
                                ig.psi0box[i].setEditable(false);
                            }
                            else if (interact==20) {
                                ig.eosalabel.setText("a:");
                                ig.eosblabel.setText("b:");
                                ig.eoscrit.setSelectedItem("eos parameters");
                                ig.eoscrit.setEnabled(false);
                            }
                            k = true;
                        }
                        else if(answer=="SC 1993" || answer=="Qian 1995" || answer=="density" || answer=="quadratic") {
                            ig.eosbbox[i].setEnabled(false);
                            ig.eosbbox[i].setEditable(false);
                            ig.acentricbox[i].setEnabled(false);
                            ig.acentricbox[i].setEditable(false);
                            if(interact==1 || interact==2) {
                                ig.eosabox[i].setEnabled(false);
                                ig.eosabox[i].setEditable(false);
                                ig.psi0box[i].setEnabled(false);
                                ig.psi0box[i].setEditable(false);
                            }
                            else if(interact==20) {
                                ig.eosabox[i].setEnabled(true);
                                ig.eosabox[i].setEditable(true);
                                ig.eosalabel.setText("g:");
                                ig.eosblabel.setText("");
                                ig.eoscrit.setSelectedItem("eos parameters");
                                ig.eoscrit.setEnabled(false);
                            }
                            k = true;
                        }
                        else if(answer=="SC 1994") {
                            ig.acentricbox[i].setEnabled(false);
                            ig.acentricbox[i].setEditable(false);
                            if(interact==1 || interact==2) {
                                ig.eosabox[i].setEnabled(false);
                                ig.eosabox[i].setEditable(false);
                                ig.eosbbox[i].setEnabled(false);
                                ig.eosbbox[i].setEditable(false);
                                ig.psi0box[i].setEnabled(true);
                                ig.psi0box[i].setEditable(true);
                            }
                            else if(interact==20) {
                                ig.eosabox[i].setEnabled(true);
                                ig.eosabox[i].setEditable(true);
                                ig.eosbbox[i].setEnabled(true);
                                ig.eosbbox[i].setEditable(true);
                                ig.eosalabel.setText("g:");
                                ig.eosblabel.setText("psi0:");
                                ig.eoscrit.setSelectedItem("eos parameters");
                                ig.eoscrit.setEnabled(false);
                            }
                            k = true;
                        }
                        else if(answer=="vdW" || answer=="RK" || answer=="CS-vdW" || answer=="CS-RK") {
                            ig.eosabox[i].setEnabled(true);
                            ig.eosabox[i].setEditable(true);
                            ig.eosbbox[i].setEnabled(true);
                            ig.eosbbox[i].setEditable(true);
                            ig.acentricbox[i].setEnabled(false);
                            ig.acentricbox[i].setEditable(false);
                            if(interact==1 || interact==2) {
                                ig.psi0box[i].setEnabled(false);
                                ig.psi0box[i].setEditable(false);
                            }
                            else if (interact==20) {
                                ig.eosalabel.setText("a:");
                                ig.eosblabel.setText("b:");
                                ig.eoscrit.setSelectedItem("eos parameters");
                                ig.eoscrit.setEnabled(true);
                            }
                            k = true;
                        }
                        else if(answer=="SRK" || answer=="PR") {
                            ig.eosabox[i].setEnabled(true);
                            ig.eosabox[i].setEditable(true);
                            ig.eosbbox[i].setEnabled(true);
                            ig.eosbbox[i].setEditable(true);
                            ig.acentricbox[i].setEnabled(true);
                            ig.acentricbox[i].setEditable(true);
                            if(interact==1 || interact==2) {
                                ig.psi0box[i].setEnabled(false);
                                ig.psi0box[i].setEditable(false);
                            }
                            else if (interact==20) {
                                ig.eosalabel.setText("a:");
                                ig.eosblabel.setText("b:");
                                ig.eoscrit.setSelectedItem("eos parameters");
                                ig.eoscrit.setEnabled(true);
                            }
                            k = true;
                        }
                        else if(answer=="none") {
                            ig.eosabox[i].setEnabled(false);
                            ig.eosabox[i].setEditable(false);
                            ig.eosbbox[i].setEnabled(false);
                            ig.eosbbox[i].setEditable(false);
                        }
                        else if(answer=="quartic") {
                            ig.eosabox[i].setEnabled(true);
                            ig.eosabox[i].setEditable(true);
                            ig.eosbbox[i].setEnabled(false);
                            ig.eosbbox[i].setEditable(false);
                        }
                    }
                }
                fg.rheoalabel.setEnabled(ka);
                fg.rheoblabel.setEnabled(kb);
                fg.rheoclabel.setEnabled(kc);
                fg.rheodlabel.setEnabled(kd);
                fg.rheonlabel.setEnabled(kn);
                if(k) {
                    j=false;
                    j1=false;
                    j2=false;
                    j3=false;
                    j4=false;
                    for(i=0; i<lbf; i++) {
                        j = (j || (ig.fluid[i].getSelectedIndex()>4));
                        j1 = (j1 || (ig.fluid[i].getSelectedIndex()>5));
                        j2 = (j2 || (ig.fluid[i].getSelectedIndex()>7 && ig.fluid[i].getSelectedIndex()<10));
                        j3 = (j3 || (ig.fluid[i].getSelectedIndex()==2));
                        j4 = (j4 || !(ig.fluid[i].getSelectedIndex()==0 || ig.fluid[i].getSelectedIndex()==5));
                    }
                    
                    if(j) {
                        ig.gasconstlabel.setEnabled(true);
                        ig.systemplabel.setEnabled(true);
                        ig.gasconst.setEnabled(true);
                        ig.gasconst.setEditable(true);
                        ig.systemp.setEnabled(true);
                        ig.systemp.setEditable(true);
                    }
                    else {
                        ig.gasconstlabel.setEnabled(false);
                        ig.systemplabel.setEnabled(false);
                        ig.gasconst.setEnabled(false);
                        ig.gasconst.setEditable(false);
                        ig.systemp.setEnabled(false);
                        ig.systemp.setEditable(false);
                    }
                    if(j1) {
                        ig.eoscrit.setEnabled(true);
                    }
                    else {
                        ig.eoscrit.setEnabled(false);
                    }
                    if(j2) {
                        ig.acentriclabel.setEnabled(true);
                    }
                    else {
                        ig.acentriclabel.setEnabled(false);
                    }
                    if(interact==1 || interact==2) {
                        if(j3)
                            ig.psi0label.setEnabled(true);
                        else
                            ig.psi0label.setEnabled(false);
                    }
                    if((j1 && (interact==1 || interact==2)) || (j4 && interact==20)) {
                        ig.eosalabel.setEnabled(true);
                        ig.eosblabel.setEnabled(true);
                    }
                    else {
                        ig.eosalabel.setEnabled(false);
                        ig.eosblabel.setEnabled(false);
                    }
                }
                if("wet".equals(combo.getName())) {
                    if(answer=="none") {
                        ig.wetadenslabel.setEnabled(false);
                        ig.wetbdenslabel.setEnabled(false);
                        ig.wallinteractions0.setEnabled(false);
                        ig.wallinteractions0.setEditable(false);
                        ig.wallinteractions1.setEnabled(false);
                        ig.wallinteractions1.setEditable(false);
                        ig.wetaconclabel.setEnabled(false);
                        ig.wetbconclabel.setEnabled(false);
                        ig.wallinteractions2.setEnabled(false);
                        ig.wallinteractions2.setEditable(false);
                        ig.wallinteractions3.setEnabled(false);
                        ig.wallinteractions3.setEditable(false);
                    }
                    else if(answer=="quadratic") {
                        ig.wetadenslabel.setEnabled(true);
                        ig.wetbdenslabel.setEnabled(true);
                        ig.wallinteractions0.setEnabled(true);
                        ig.wallinteractions0.setEditable(true);
                        ig.wallinteractions1.setEnabled(true);
                        ig.wallinteractions1.setEditable(true);
                        ig.wetaconclabel.setEnabled(true);
                        ig.wetbconclabel.setEnabled(true);
                        ig.wallinteractions2.setEnabled(true);
                        ig.wallinteractions2.setEditable(true);
                        ig.wallinteractions3.setEnabled(true);
                        ig.wallinteractions3.setEditable(true);
                    }
                }
                
            }            
        } catch (NullPointerException e) {
            // do nothing
        }
    }

    void setfluitparameter(int totf,int nd,int nq,int coll,int inter,double[] densfic,double[] initv,double[] relaxtime,double[] mrtrelaxtime,double trtm,int[] rheo,double[] rheoa,double[] rheob,double[] rheoc,double[] rheod,double[] rheon) {
      setFluid sf= new setFluid(totf, nd, nq, coll, inter, densfic, initv, relaxtime, mrtrelaxtime, trtm, rheo, rheoa, rheob, rheoc, rheod, rheon);
    }
    
    void setfluitforceparameter(int totf,int dim,int coll,double[] bdf,double[] oscf,double[] bousf,double ocfp,int fp) {
      setFluidForce sfr = new setFluidForce(totf, dim, coll, bdf, oscf, bousf, ocfp, fp);
    }

    void setfluitintparameter(int totf,int inter,double[] fluidinteract,int[] eos,int eoscrit, double[] eosa,double[] eosb,double[] acentric,double[] psi0,double[] quadw,int[] wettype, double[] wallinteract,double segregate,double gascon,double tempsys,double kappa,double taumob,double mobparam) {
      setFluidInteract sg= new setFluidInteract(totf, inter, fluidinteract, eos, eoscrit, eosa, eosb, acentric, psi0, quadw, wettype, wallinteract, segregate, gascon, tempsys, kappa, taumob, mobparam);
    }

    void setsoluteparameter(int totc,int dim,double[] solrelax,double[] concs) {
      setSolute ss = new setSolute(totc, dim, solrelax, concs);
    }

    void setthermalparameter(int dim,double heatrelax,double boustemph,double boustempl,double tempsi,double heatratei) {
      setThermal st = new setThermal(dim, heatrelax, boustemph, boustempl, tempsi, heatratei);
    }

    void ierr(String errinfo) {
      msgPanel fcer=new msgPanel(errinfo);	
    }

}
