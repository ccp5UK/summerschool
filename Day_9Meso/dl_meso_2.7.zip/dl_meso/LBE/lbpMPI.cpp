/***************************************************
 *   DL_MESO       Version 2.7                     *
 *   Authors   :   R. S. Qin, M. A. Seaton         *
 *   Amended   :   L. Grinberg, M. A. Johnston     *
 *   Copyright :   UKRI STFC Daresbury Laboratory  *
 *             :   09/12/2018                      *
 ***************************************************/

int fStartMPI(int argc, char* argv[])
{

  // start message passing interface (MPI)

  MPI_Init(&argc, &argv);
  return 0;
}

int fCloseMPI()
{

  // close message passing interface (MPI)

  MPI_Finalize();
  return 0;
}

int fGetRank()
{

  // find name of the processing unit

  int rank;
  MPI_Comm_rank(MPI_COMM_WORLD, &rank);
  return rank;
}

int fGetSize()
{

  // find the number of processes

  int size;
  MPI_Comm_size(MPI_COMM_WORLD, &size);
  return size;
}


int fAllReady()
{
  
  // block program until all processes are ready

  MPI_Barrier(MPI_COMM_WORLD);

  return 0;
}

int fGlobalValue(double *vqua, int nnum, double *vtot)
{  

  // sums values from all processes and distributes the sum
  
  MPI_Allreduce(vqua, vtot, nnum, MPI_DOUBLE, MPI_SUM, MPI_COMM_WORLD);

  return 0;
}  


int fGlobalValue(double *vqua, int nnum)
{  

  // sums values from all processes and distributes the sum
  
  double *vtot = new double[nnum];
  
  MPI_Allreduce(vqua, vtot, nnum, MPI_DOUBLE, MPI_SUM, MPI_COMM_WORLD);

  for(int i=0; i<nnum; i++)
    vqua[i] = vtot[i];

  delete [] vtot;

  return 0;
}  


int fGlobalValue(int *vqua, int nnum, int *vtot)
{  

  // sums values from all processes and distributes the sum
  
  MPI_Allreduce(vqua, vtot, nnum, MPI_INT, MPI_SUM, MPI_COMM_WORLD);

  return 0;
}  


int fGlobalValue(int *vqua, int nnum)
{  

  // sums values from all processes and distributes the sum
  
  int *vtot = new int[nnum];
  
  MPI_Allreduce(vqua, vtot, nnum, MPI_INT, MPI_SUM, MPI_COMM_WORLD);

  for(int i=0; i<nnum; i++)
    vqua[i] = vtot[i];

  delete [] vtot;

  return 0;

}  

int fGlobalValue(long int *vqua, int nnum)
{  

  // sums values from all processes and distributes the sum
  
  long int *vtot = new long int[nnum];
  
  MPI_Allreduce(vqua, vtot, nnum, MPI_INT, MPI_SUM, MPI_COMM_WORLD);

  for(int i=0; i<nnum; i++)
    vqua[i] = vtot[i];

  delete [] vtot;

  return 0;

}  


int fGlobalValue(long int *vqua, int nnum, long int *vtot)
{  

  // sums values from all processes and distributes the sum
  
  MPI_Allreduce(vqua, vtot, nnum, MPI_INT, MPI_SUM, MPI_COMM_WORLD);

  return 0;

}  


int fGlobalProduct(double *vqua, int nnum)
{  

  // multiplies together values from all processes and distributes the product
  
  double *vtot = new double[nnum];
  
  MPI_Allreduce(vqua, vtot, nnum, MPI_DOUBLE, MPI_PROD, MPI_COMM_WORLD);

  for(int i=0; i<nnum; i++)
    vqua[i] = vtot[i];

  delete [] vtot;

  return 0;
}  


int fGlobalProduct(int *vqua, int nnum)
{  

  // multiplies together values from all processes and distributes the product:
  // used to check logical value throughout processes
  
  int *vtot = new int[nnum];
  
  MPI_Allreduce(vqua, vtot, nnum, MPI_INT, MPI_PROD, MPI_COMM_WORLD);

  for(int i=0; i<nnum; i++)
    vqua[i] = vtot[i];

  delete [] vtot;

  return 0;
}  

double fCheckTimeMPI()
{

  // check the elapsed time (in seconds)

  static int timeini;
  static double starttime;
  double timeelapsed;
  
  if(timeini == 0)
    {  
      timeini = 1;
      starttime = MPI_Wtime();
      timeelapsed =0.0;
    }
  else
    timeelapsed = MPI_Wtime() - starttime;
  
  return timeelapsed;
}


int fArrangeProcessors()
{

  // arrange processes according to system dimensions

  int size = fGetSize();
  double smallvalue = size * 1.0;
  double currentvalue;
  const double third = 1.0/3.0;
    
  lbdm.xdim = lbdm.ydim = lbdm.zdim = 1;
  if(lbsy.nd == 3) {
    for(int i=1; i<=(size/2); i++) {
      if(!(size % i)) {
	    currentvalue = fCppAbs(pow(size*lbsy.nz*lbsy.nz/(1.0*lbsy.nx*lbsy.ny), third) - i);
  	    if(currentvalue <= smallvalue) {
	      smallvalue = currentvalue;
	      lbdm.zdim = i;
	    }
      }
    }
    if(size == 1)
      lbdm.zdim = 1;
    size /= lbdm.zdim;
    smallvalue = size * 1.0;
  }
  else
    lbdm.zdim = 1;
  
  for(int i=1; i<=(size/2+1); i++) {
    if(!(size % i)) {
      currentvalue = fCppAbs(size*lbsy.nx/(1.0*i*lbsy.ny) - i);
      if(currentvalue <= smallvalue) {
	    smallvalue = currentvalue;
	    lbdm.xdim = i;
      }
    }
  }
  if(size == 1)
    lbdm.xdim = 1;
  lbdm.ydim = size / lbdm.xdim;
  return 0;
}

int fGetProcessCoordinate()
{
  
  // find coordinate of this process
  
  if(lbsy.nd == 3){
    lbdm.xcor = lbdm.rank / (lbdm.ydim * lbdm.zdim);
    lbdm.zcor = lbdm.rank % lbdm.zdim;
    lbdm.ycor = (lbdm.rank % (lbdm.ydim * lbdm.zdim)) / lbdm.zdim;}
  else {
    lbdm.xcor = lbdm.rank / lbdm.ydim;
    lbdm.ycor = lbdm.rank % lbdm.ydim;
    lbdm.zcor = 0;
 }
 return 0;
}

int fGetDomainSize()
{
  
  // distribute grid points among all processes
  
  int xinn1, ln1, ii, jj, kk;

  // x-direction
  
  fBestGrouping(lbsy.nx, lbdm.xdim, xinn1, ln1);
  if(lbdm.xcor < ln1) {
    lbdm.xinner = xinn1;
    lbdm.xs = lbdm.xcor * xinn1;
  } 
  else {
    lbdm.xinner = xinn1 - 1;
    lbdm.xs = ln1 * xinn1 + (lbdm.xcor - ln1) * (xinn1 - 1);
  }
  lbdm.xouter = lbdm.xinner + 2 * lbdm.bwid;
  lbdm.xe = lbdm.xs + lbdm.xinner;
  lbdm.owidx = lbdm.bwid;
  if(lbdm.owidx<1)
    lbdm.owidx=1;

  // y-direction
  
  fBestGrouping(lbsy.ny, lbdm.ydim, xinn1, ln1);
  if(lbdm.ycor < ln1) {
      lbdm.yinner = xinn1;
      lbdm.ys = lbdm.ycor * xinn1;
  }
  else {
    lbdm.yinner = xinn1 - 1;
    lbdm.ys = ln1 * xinn1 + (lbdm.ycor - ln1) * (xinn1 - 1);
  }
  lbdm.youter = lbdm.yinner + 2 * lbdm.bwid;
  lbdm.ye = lbdm.ys + lbdm.yinner;
  lbdm.touter = lbdm.xouter * lbdm.youter;
  lbdm.owidy = lbdm.bwid;
  if(lbdm.owidy<1)
    lbdm.owidy=1;

  // z-direction

  if(lbsy.nd == 3) {
    fBestGrouping(lbsy.nz, lbdm.zdim, xinn1, ln1);
    if(lbdm.zcor < ln1) {
      lbdm.zinner = xinn1;
      lbdm.zs = lbdm.zcor * xinn1;
    }
    else {
      lbdm.zinner = xinn1 - 1;
      lbdm.zs = ln1 * xinn1 + (lbdm.zcor - ln1) * (xinn1 - 1);
    }
    lbdm.zouter = lbdm.zinner + 2 * lbdm.bwid;
    lbdm.ze = lbdm.zs + lbdm.zinner;
    lbdm.touter *= lbdm.zouter; 
    lbdm.owidz = lbdm.bwid;
    if(lbdm.owidz<1)
      lbdm.owidz=1;
  }
  else {
    lbdm.zs = 0;
    lbdm.ze = 1;
    lbdm.zinner = 1;
    lbdm.zouter = 1;
    lbdm.owidz = 0;
  }
  // set grid boundary regions
  lboutersize = 0;
  ii = 2*lbdm.xouter*lbdm.youter*lbdm.owidz +
       2*lbdm.xouter*(lbdm.zouter-2*lbdm.owidz)*lbdm.owidy +
       2*(lbdm.youter-2*lbdm.owidy)*(lbdm.zouter-2*lbdm.owidz)*lbdm.owidx;
  lbouter = new unsigned long[4*ii];
  for(ii=0; ii<lbdm.xouter; ii++) {
    for(jj=0; jj<lbdm.youter; jj++) {
      for(kk=0; kk<lbdm.zouter; kk++) {
        if ((ii<lbdm.owidx) || (jj<lbdm.owidy) || (kk<lbdm.owidz) || (ii>=(lbdm.xouter-lbdm.owidx)) ||
            (jj>=(lbdm.youter-lbdm.owidy)) || (kk>=(lbdm.zouter-lbdm.owidz))) {
          lbouter[4*lboutersize  ] = (unsigned long) ((ii*lbdm.youter+jj)*lbdm.zouter+kk);
          lbouter[4*lboutersize+1] = (unsigned long) ii;
          lbouter[4*lboutersize+2] = (unsigned long) jj;
          lbouter[4*lboutersize+3] = (unsigned long) kk;
          lboutersize++;
        }
      }
    }
  }
  return 0;
}

int fErrorInArray()
{
  
  // check for empty defined arrays
  
  if(lbdm.xinner < 1 || lbdm.yinner < 1) {
    cout << "error: empty array defined in " << lbdm.rank << endl;
    exit(1);
  }
  if(lbsy.nd == 3 && lbdm.zinner < 1) {
    cout << "error: empty array defined in " << lbdm.rank << endl;
    exit(1);
  }
  return 0;
}

int fDefineDomain()
{

  // determine domain parameters for calculation

  lbdm.rank=fGetRank();
  lbdm.size=fGetSize();
  fArrangeProcessors();
  fGetProcessCoordinate();
  fGetDomainSize();
  fErrorInArray();
  return 0;
}

void fGroupCartesianCommRange(int* start, int* end, sIOGroup* info)
{
  // return range of cartesian communicator grid covered by I/O group
    
  // reduce mininum for lower coordinate
  MPI_Allreduce(&lbdm.xcor,start,1,MPI_INT,MPI_MIN,info->ioCommunicator);
  MPI_Allreduce(&lbdm.ycor,start+1,1,MPI_INT,MPI_MIN,info->ioCommunicator);
  MPI_Allreduce(&lbdm.zcor,start+2,1,MPI_INT,MPI_MIN,info->ioCommunicator);

  // reduce maximum for upper coordinate
  MPI_Allreduce(&lbdm.xcor,end,1,MPI_INT,MPI_MAX,info->ioCommunicator);
  MPI_Allreduce(&lbdm.ycor,end+1,1,MPI_INT,MPI_MAX,info->ioCommunicator);
  MPI_Allreduce(&lbdm.zcor,end+2,1,MPI_INT,MPI_MAX,info->ioCommunicator);
}

int fCreateIOGroups()
{
  // create I/O group to combine output: requires values for
  // setting lbIOGroups.subdims from fInputParameters and
  // determines process's position in co-ordinate structure
  // based on world rank (fGetProcessCoordinate)

  int dims[3] = {lbdm.xdim, lbdm.ydim, lbdm.zdim}; 
  int periods[3] = {0,0,0};
  int lbCoords[3] = {lbdm.xcor, lbdm.ycor, lbdm.zcor}; 
  int i,ii,jj,kk,istart,iend,imin,jstart,jend,jmin,kstart,kend,kmin,index,ilen;
  int testDim,color,numberOfPoints,gridstart;
  int numberIOGroups, groupRank=-1;
  int *start, *end;
  int myStart[3], myEnd[3], length[3];
  bool includeInnerHalos[3];
  MPI_Group worldGroup, singleton;

  // create Cartesian communicator of correct size (general
  // three-dimensional case: 2D case handled by setting
  // z-dimension to 1)
  MPI_Cart_create(MPI_COMM_WORLD, 3, dims, periods, 0, &lbIOGroup.cartCommunicator);

  // check coordinates in communicator match actual coordinates
  MPI_Cart_coords(lbIOGroup.cartCommunicator, lbdm.rank, 3, lbIOGroup.cartCoords); 
  for(i=0;i<3;i++) {
    if(lbIOGroup.cartCoords[i] != lbCoords[i]) {
      cout << "Error: Incorrect cartesian mapping for rank" << lbdm.rank << endl;
      cout << "MPI Coords: " << lbIOGroup.cartCoords[0] << ", " << lbIOGroup.cartCoords[1] << ", " << lbIOGroup.cartCoords[2] << endl;
      cout << "LB Coords:  " << lbCoords[0] << ", " << lbCoords[1] << ", " << lbCoords[2] << endl;
      MPI_Abort(MPI_COMM_WORLD, 1);
    }
  }

  testDim = 0;
  for(i=0;i<3;i++)
    testDim = testDim || lbIOGroup.subgrid[i];	

  if(testDim == 0) {
    // if no combined dimensions specified, create an I/O group of size 1
    MPI_Comm_group(MPI_COMM_WORLD, &worldGroup);
    MPI_Group_incl(worldGroup, 1, &lbdm.rank, &singleton);
    MPI_Comm_create(MPI_COMM_WORLD, singleton, &lbIOGroup.ioCommunicator);
  }
  else {
    // subgrid initialised when reading input file
    MPI_Cart_sub(lbIOGroup.cartCommunicator, lbIOGroup.subgrid, &lbIOGroup.ioCommunicator);
  }

  MPI_Comm_size(lbIOGroup.ioCommunicator, &lbIOGroup.size);
  MPI_Comm_rank(lbIOGroup.ioCommunicator, &lbIOGroup.rank);

  if(lbIOGroup.rank == 0) lbIOGroup.rootRank = lbdm.rank;

  MPI_Bcast(&lbIOGroup.rootRank, 1, MPI_INT, 0, lbIOGroup.ioCommunicator);

  // get range of communication grid covered by I/O group
  fGroupCartesianCommRange(lbIOGroup.cartStart, lbIOGroup.cartEnd, &lbIOGroup);

  // create communicator for just I/O group root processes:
  // ioRootCommunicator will only be defined on I/O group root nodes
    
  if(testDim == 0) {
    ioRootCommunicator = MPI_COMM_WORLD;
  }
  else {
    color=MPI_UNDEFINED;
    if(lbIOGroup.rank==0)
      color = 1;

    MPI_Comm_split(MPI_COMM_WORLD, color, 0, &ioRootCommunicator);
  }
  if(lbIOGroup.rank == 0) {
    MPI_Comm_size(ioRootCommunicator, &numberIOGroups);
    MPI_Comm_rank(ioRootCommunicator, &groupRank);
    lbIOGroup.rootSize = numberIOGroups;
    lbIOGroup.groupId = groupRank;
  }

  // set groupId to be rank of group root process in ioRootCommunicator
  MPI_Bcast(&lbIOGroup.groupId, 1, MPI_INT, 0, lbIOGroup.ioCommunicator);

  // work out required order for received data: on I/O group root,
  // collect range of points for all cores and find how to reorder
  // data onto entire grid

  for(i=0; i<3;i++) includeInnerHalos[i] = !(lbmpiio || lbIOGroup.subgrid[i]);

  fPieceRangeLocal(myStart,myEnd,includeInnerHalos);
  numberOfPoints = fGroupPieceDataPoints(length);
  myStart[0] = myStart[0]+lbdm.xs-lbdm.bwid;
  myStart[1] = myStart[1]+lbdm.ys-lbdm.bwid;
  myStart[2] = myStart[2]+lbdm.zs-((lbsy.nd==3)?lbdm.bwid:0);
  myEnd[0] = myEnd[0]+lbdm.xs-lbdm.bwid;
  myEnd[1] = myEnd[1]+lbdm.ys-lbdm.bwid;
  myEnd[2] = myEnd[2]+lbdm.zs-((lbsy.nd==3)?lbdm.bwid:0);
  
  start = new int[3*lbIOGroup.size];
  end = new int[3*lbIOGroup.size];
  MPI_Gather(myStart, 3, MPI_INT, start, 3, MPI_INT, 0, lbIOGroup.ioCommunicator);
  MPI_Gather(myEnd,   3, MPI_INT, end,   3, MPI_INT, 0, lbIOGroup.ioCommunicator);

  lbIOGroup.sortpoint = new int[numberOfPoints];
  gridstart = 0;

  if(lbIOGroup.rank==0) {
    imin = lbsy.nx;
    jmin = lbsy.ny;
    kmin = lbsy.nz;
    for(i=0; i<lbIOGroup.size; i++) {
      imin = fCppMin(imin, start[3*i]);
      jmin = fCppMin(jmin, start[3*i+1]);
      kmin = fCppMin(kmin, start[3*i+2]);
    }
    for(i=0; i<lbIOGroup.size; i++) {
      istart=start[3*i];
      iend  =end  [3*i];
      jstart=start[3*i+1];
      jend  =end  [3*i+1];
      kstart=start[3*i+2];
      kend  =end  [3*i+2];
      for(index=0, kk=kstart; kk<kend; kk++) {
        for(jj=jstart; jj<jend; jj++) {
          for(ii=istart; ii<iend; ii++, index++) {
            ilen = (ii-imin) + length[0] * ((jj-jmin) + length[1] * (kk-kmin));
            lbIOGroup.sortpoint[ilen] = gridstart+index;
          }
        }
      }
      gridstart += (iend-istart)*(jend-jstart)*(kend-kstart);
    }
  }
  delete [] start;
  delete [] end;
    
  return 1;
}

int fDefineMessage()
{

  // define vector messages for system

  MPI_Datatype basicslice,  oneslicex,  oneslicey,  oneslicez;
  MPI_Datatype bbasicslice, boneslicex, boneslicey, boneslicez;
  MPI_Datatype fbasicslice, foneslicex, foneslicey, foneslicez;
  MPI_Datatype ibasicslice, ioneslicex, ioneslicey, ioneslicez;
//  MPI_Datatype kbasicslice, koneslicex, koneslicey, koneslicez;
  MPI_Datatype nbasicslice, noneslicex, noneslicey, noneslicez;
  int ulth, bulth, fulth, iulth, nulth;
//  int kulth;
  int maxbuf, pairs, pairs2;
  int mult = (interact>9 && interact<20)?1:lbsy.nf;

  MPI_Aint dbleth, inleth, lbound;
#ifdef MPIold
  MPI_Type_extent(MPI_DOUBLE, &dbleth);
  MPI_Type_extent(MPI_INT, &inleth);
#else
  MPI_Type_get_extent(MPI_DOUBLE, &lbound, &dbleth);
  MPI_Type_get_extent(MPI_INT, &lbound, &inleth);
#endif
    
  pairs = (interact==20)?(4*lbsy.nf):(3*lbsy.nf*(lbsy.nf-1)/2);
  pairs2 = lbsy.nf*(lbsy.nf-1)/2;
  ulth = lbsitelength * dbleth;
  bulth = inleth;
  fulth = 3 * mult * dbleth;
  iulth = pairs * dbleth;
//  kulth = pairs2 * dbleth;
  nulth = 3 * dbleth;
  maxbuf = 3*lbsy.nf;
  maxbuf = fCppMax(lbsitelength, maxbuf);
  if(interact>=10)
    maxbuf = fCppMax(maxbuf, pairs);
  MPI_Type_vector(lbsitelength, 1, 1, MPI_DOUBLE, &basicslice);
  MPI_Type_vector(1, 1, 1, MPI_INT, &bbasicslice);
  MPI_Type_vector(3 * mult, 1, 1, MPI_DOUBLE, &fbasicslice);
  MPI_Type_vector(pairs, 1, 1, MPI_DOUBLE, &ibasicslice);
//  MPI_Type_vector(pairs2, 1, 1, MPI_DOUBLE, &kbasicslice);
  MPI_Type_vector(3, 1, 1, MPI_DOUBLE, &nbasicslice);
  if(lbsy.nd == 2) {
#ifdef Packbuf
   sendbuf_0_x = new double[lbdm.yinner * lbdm.bwid * maxbuf];
   sendbuf_1_x = new double[lbdm.yinner * lbdm.bwid * maxbuf];
   recvbuf_0_x = new double[lbdm.yinner * lbdm.bwid * maxbuf];
   recvbuf_1_x = new double[lbdm.yinner * lbdm.bwid * maxbuf];

   sendbuf_0_y = new double[lbdm.xouter * lbdm.bwid * maxbuf];
   sendbuf_1_y = new double[lbdm.xouter * lbdm.bwid * maxbuf];
   recvbuf_0_y = new double[lbdm.xouter * lbdm.bwid * maxbuf];
   recvbuf_1_y = new double[lbdm.xouter * lbdm.bwid * maxbuf];
#endif
    int ylth = lbdm.youter * ulth;
#ifdef MPIold
    MPI_Type_hvector(lbdm.bwid, lbdm.yinner, ylth, basicslice, &lbmsg2x);
    MPI_Type_commit(&lbmsg2x);
    MPI_Type_hvector(lbdm.xouter, lbdm.bwid, ylth, basicslice, &lbmsg2y);
    MPI_Type_commit(&lbmsg2y);
#else
    MPI_Type_create_hvector(lbdm.bwid, lbdm.yinner, ylth, basicslice, &lbmsg2x);
    MPI_Type_commit(&lbmsg2x);
    MPI_Type_create_hvector(lbdm.xouter, lbdm.bwid, ylth, basicslice, &lbmsg2y);
    MPI_Type_commit(&lbmsg2y);
#endif
    int bylth = lbdm.youter * bulth;
#ifdef MPIold
    MPI_Type_hvector(lbdm.bwid, lbdm.yinner, bylth, bbasicslice, &lbbmsg2x);
    MPI_Type_commit(&lbbmsg2x);
    MPI_Type_hvector(lbdm.xouter, lbdm.bwid, bylth, bbasicslice, &lbbmsg2y);
    MPI_Type_commit(&lbbmsg2y);
#else
    MPI_Type_create_hvector(lbdm.bwid, lbdm.yinner, bylth, bbasicslice, &lbbmsg2x);
    MPI_Type_commit(&lbbmsg2x);
    MPI_Type_create_hvector(lbdm.xouter, lbdm.bwid, bylth, bbasicslice, &lbbmsg2y);
    MPI_Type_commit(&lbbmsg2y);
#endif
    int fylth = lbdm.youter * fulth;
#ifdef MPIold
    MPI_Type_hvector(lbdm.bwid, lbdm.yinner, fylth, fbasicslice, &lbfmsg2x);
    MPI_Type_commit(&lbfmsg2x);
    MPI_Type_hvector(lbdm.xouter, lbdm.bwid, fylth, fbasicslice, &lbfmsg2y);
    MPI_Type_commit(&lbfmsg2y);
#else
    MPI_Type_create_hvector(lbdm.bwid, lbdm.yinner, fylth, fbasicslice, &lbfmsg2x);
    MPI_Type_commit(&lbfmsg2x);
    MPI_Type_create_hvector(lbdm.xouter, lbdm.bwid, fylth, fbasicslice, &lbfmsg2y);
    MPI_Type_commit(&lbfmsg2y);
#endif
    int iylth = lbdm.youter * iulth;
#ifdef MPIold
    MPI_Type_hvector(lbdm.bwid, lbdm.yinner, iylth, ibasicslice, &lbimsg2x);
    MPI_Type_commit(&lbimsg2x);
    MPI_Type_hvector(lbdm.xouter, lbdm.bwid, iylth, ibasicslice, &lbimsg2y);
    MPI_Type_commit(&lbimsg2y);
#else
    MPI_Type_create_hvector(lbdm.bwid, lbdm.yinner, iylth, ibasicslice, &lbimsg2x);
    MPI_Type_commit(&lbimsg2x);
    MPI_Type_create_hvector(lbdm.xouter, lbdm.bwid, iylth, ibasicslice, &lbimsg2y);
    MPI_Type_commit(&lbimsg2y);
#endif
/*
    int kylth = lbdm.youter * kulth;
#ifdef MPIold
    MPI_Type_hvector(lbdm.bwid, lbdm.yinner, kylth, kbasicslice, &lbkmsg2x);
    MPI_Type_commit(&lbkmsg2x);
    MPI_Type_hvector(lbdm.xouter, lbdm.bwid, kylth, kbasicslice, &lbkmsg2y);
    MPI_Type_commit(&lbkmsg2y);
#else
    MPI_Type_create_hvector(lbdm.bwid, lbdm.yinner, kylth, kbasicslice, &lbkmsg2x);
    MPI_Type_commit(&lbkmsg2x);
    MPI_Type_create_hvector(lbdm.xouter, lbdm.bwid, kylth, kbasicslice, &lbkmsg2y);
    MPI_Type_commit(&lbkmsg2y);
#endif
*/
    int nylth = lbdm.youter * nulth;
#ifdef MPIold
    MPI_Type_hvector(lbdm.bwid, lbdm.yinner, nylth, nbasicslice, &lbnmsg2x);
    MPI_Type_commit(&lbnmsg2x);
    MPI_Type_hvector(lbdm.xouter, lbdm.bwid, nylth, nbasicslice, &lbnmsg2y);
    MPI_Type_commit(&lbnmsg2y);
#else
    MPI_Type_create_hvector(lbdm.bwid, lbdm.yinner, nylth, nbasicslice, &lbnmsg2x);
    MPI_Type_commit(&lbnmsg2x);
    MPI_Type_create_hvector(lbdm.xouter, lbdm.bwid, nylth, nbasicslice, &lbnmsg2y);
    MPI_Type_commit(&lbnmsg2y);
#endif
  }
  else if(lbsy.nd == 3){
#ifdef Packbuf
   sendbuf_0_x = new double[lbdm.yinner * lbdm.zinner * lbdm.bwid * maxbuf];
   sendbuf_1_x = new double[lbdm.yinner * lbdm.zinner * lbdm.bwid * maxbuf];
   recvbuf_0_x = new double[lbdm.yinner * lbdm.zinner * lbdm.bwid * maxbuf];
   recvbuf_1_x = new double[lbdm.yinner * lbdm.zinner * lbdm.bwid * maxbuf];

   sendbuf_0_y = new double[lbdm.xouter * lbdm.zinner * lbdm.bwid * maxbuf];
   sendbuf_1_y = new double[lbdm.xouter * lbdm.zinner * lbdm.bwid * maxbuf];
   recvbuf_0_y = new double[lbdm.xouter * lbdm.zinner * lbdm.bwid * maxbuf];
   recvbuf_1_y = new double[lbdm.xouter * lbdm.zinner * lbdm.bwid * maxbuf];

   sendbuf_0_z = new double[lbdm.xouter * lbdm.youter * lbdm.bwid * maxbuf];
   sendbuf_1_z = new double[lbdm.xouter * lbdm.youter * lbdm.bwid * maxbuf];
   recvbuf_0_z = new double[lbdm.xouter * lbdm.youter * lbdm.bwid * maxbuf];
   recvbuf_1_z = new double[lbdm.xouter * lbdm.youter * lbdm.bwid * maxbuf];
#endif
    int zlth = lbdm.zouter * ulth;
    int ylth = lbdm.youter * zlth;
#ifdef MPIold
    MPI_Type_hvector(lbdm.yinner, lbdm.zinner, zlth, basicslice, &oneslicex);
    MPI_Type_hvector(lbdm.bwid, 1, ylth, oneslicex, &lbmsg3x);
    MPI_Type_commit(&lbmsg3x);
    MPI_Type_hvector(lbdm.bwid, lbdm.zinner, zlth, basicslice, &oneslicey);
    MPI_Type_hvector(lbdm.xouter, 1, ylth, oneslicey, &lbmsg3y);
    MPI_Type_commit(&lbmsg3y);
    MPI_Type_hvector(lbdm.youter, lbdm.bwid, zlth, basicslice, &oneslicez);
    MPI_Type_hvector(lbdm.xouter, 1, ylth, oneslicez, &lbmsg3z);
    MPI_Type_commit(&lbmsg3z);
#else
    MPI_Type_create_hvector(lbdm.yinner, lbdm.zinner, zlth, basicslice, &oneslicex);
    MPI_Type_create_hvector(lbdm.bwid, 1, ylth, oneslicex, &lbmsg3x);
    MPI_Type_commit(&lbmsg3x);
    MPI_Type_create_hvector(lbdm.bwid, lbdm.zinner, zlth, basicslice, &oneslicey);
    MPI_Type_create_hvector(lbdm.xouter, 1, ylth, oneslicey, &lbmsg3y);
    MPI_Type_commit(&lbmsg3y);
    MPI_Type_create_hvector(lbdm.youter, lbdm.bwid, zlth, basicslice, &oneslicez);
    MPI_Type_create_hvector(lbdm.xouter, 1, ylth, oneslicez, &lbmsg3z);
    MPI_Type_commit(&lbmsg3z);
#endif
    int bzlth = lbdm.zouter * bulth;
    int bylth = lbdm.youter * bzlth;
#ifdef MPIold
    MPI_Type_hvector(lbdm.yinner, lbdm.zinner, bzlth, bbasicslice, &boneslicex);
    MPI_Type_hvector(lbdm.bwid, 1, bylth, boneslicex, &lbbmsg3x);
    MPI_Type_commit(&lbbmsg3x);
    MPI_Type_hvector(lbdm.bwid, lbdm.zinner, bzlth, bbasicslice, &boneslicey);
    MPI_Type_hvector(lbdm.xouter, 1, bylth, boneslicey, &lbbmsg3y);
    MPI_Type_commit(&lbbmsg3y);
    MPI_Type_hvector(lbdm.youter, lbdm.bwid, bzlth, bbasicslice, &boneslicez);
    MPI_Type_hvector(lbdm.xouter, 1, bylth, boneslicez, &lbbmsg3z);
    MPI_Type_commit(&lbbmsg3z);
#else
    MPI_Type_create_hvector(lbdm.yinner, lbdm.zinner, bzlth, bbasicslice, &boneslicex);
    MPI_Type_create_hvector(lbdm.bwid, 1, bylth, boneslicex, &lbbmsg3x);
    MPI_Type_commit(&lbbmsg3x);
    MPI_Type_create_hvector(lbdm.bwid, lbdm.zinner, bzlth, bbasicslice, &boneslicey);
    MPI_Type_create_hvector(lbdm.xouter, 1, bylth, boneslicey, &lbbmsg3y);
    MPI_Type_commit(&lbbmsg3y);
    MPI_Type_create_hvector(lbdm.youter, lbdm.bwid, bzlth, bbasicslice, &boneslicez);
    MPI_Type_create_hvector(lbdm.xouter, 1, bylth, boneslicez, &lbbmsg3z);
    MPI_Type_commit(&lbbmsg3z);
#endif
    int fzlth = lbdm.zouter * fulth;
    int fylth = lbdm.youter * fzlth;
#ifdef MPIold
    MPI_Type_hvector(lbdm.yinner, lbdm.zinner, fzlth, fbasicslice, &foneslicex);
    MPI_Type_hvector(lbdm.bwid, 1, fylth, foneslicex, &lbfmsg3x);
    MPI_Type_commit(&lbfmsg3x);
    MPI_Type_hvector(lbdm.bwid, lbdm.zinner, fzlth, fbasicslice, &foneslicey);
    MPI_Type_hvector(lbdm.xouter, 1, fylth, foneslicey, &lbfmsg3y);
    MPI_Type_commit(&lbfmsg3y);
    MPI_Type_hvector(lbdm.youter, lbdm.bwid, fzlth, fbasicslice, &foneslicez);
    MPI_Type_hvector(lbdm.xouter, 1, fylth, foneslicez, &lbfmsg3z);
    MPI_Type_commit(&lbfmsg3z);
#else
    MPI_Type_create_hvector(lbdm.yinner, lbdm.zinner, fzlth, fbasicslice, &foneslicex);
    MPI_Type_create_hvector(lbdm.bwid, 1, fylth, foneslicex, &lbfmsg3x);
    MPI_Type_commit(&lbfmsg3x);
    MPI_Type_create_hvector(lbdm.bwid, lbdm.zinner, fzlth, fbasicslice, &foneslicey);
    MPI_Type_create_hvector(lbdm.xouter, 1, fylth, foneslicey, &lbfmsg3y);
    MPI_Type_commit(&lbfmsg3y);
    MPI_Type_create_hvector(lbdm.youter, lbdm.bwid, fzlth, fbasicslice, &foneslicez);
    MPI_Type_create_hvector(lbdm.xouter, 1, fylth, foneslicez, &lbfmsg3z);
    MPI_Type_commit(&lbfmsg3z);
#endif
    int izlth = lbdm.zouter * iulth;
    int iylth = lbdm.youter * izlth;
#ifdef MPIold
    MPI_Type_hvector(lbdm.yinner, lbdm.zinner, izlth, ibasicslice, &ioneslicex);
    MPI_Type_hvector(lbdm.bwid, 1, iylth, ioneslicex, &lbimsg3x);
    MPI_Type_commit(&lbimsg3x);
    MPI_Type_hvector(lbdm.bwid, lbdm.zinner, izlth, ibasicslice, &ioneslicey);
    MPI_Type_hvector(lbdm.xouter, 1, iylth, ioneslicey, &lbimsg3y);
    MPI_Type_commit(&lbimsg3y);
    MPI_Type_hvector(lbdm.youter, lbdm.bwid, izlth, ibasicslice, &ioneslicez);
    MPI_Type_hvector(lbdm.xouter, 1, iylth, ioneslicez, &lbimsg3z);
    MPI_Type_commit(&lbimsg3z);
#else
    MPI_Type_create_hvector(lbdm.yinner, lbdm.zinner, izlth, ibasicslice, &ioneslicex);
    MPI_Type_create_hvector(lbdm.bwid, 1, iylth, ioneslicex, &lbimsg3x);
    MPI_Type_commit(&lbimsg3x);
    MPI_Type_create_hvector(lbdm.bwid, lbdm.zinner, izlth, ibasicslice, &ioneslicey);
    MPI_Type_create_hvector(lbdm.xouter, 1, iylth, ioneslicey, &lbimsg3y);
    MPI_Type_commit(&lbimsg3y);
    MPI_Type_create_hvector(lbdm.youter, lbdm.bwid, izlth, ibasicslice, &ioneslicez);
    MPI_Type_create_hvector(lbdm.xouter, 1, iylth, ioneslicez, &lbimsg3z);
    MPI_Type_commit(&lbimsg3z);
#endif
/*
    int kzlth = lbdm.zouter * kulth;
    int kylth = lbdm.youter * kzlth;
#ifdef MPIold
    MPI_Type_hvector(lbdm.yinner, lbdm.zinner, kzlth, kbasicslice, &koneslicex);
    MPI_Type_hvector(lbdm.bwid, 1, kylth, koneslicex, &lbkmsg3x);
    MPI_Type_commit(&lbkmsg3x);
    MPI_Type_hvector(lbdm.bwid, lbdm.zinner, kzlth, kbasicslice, &koneslicey);
    MPI_Type_hvector(lbdm.xouter, 1, kylth, koneslicey, &lbkmsg3y);
    MPI_Type_commit(&lbkmsg3y);
    MPI_Type_hvector(lbdm.youter, lbdm.bwid, kzlth, kbasicslice, &koneslicez);
    MPI_Type_hvector(lbdm.xouter, 1, kylth, koneslicez, &lbkmsg3z);
    MPI_Type_commit(&lbkmsg3z);
#else
    MPI_Type_create_hvector(lbdm.yinner, lbdm.zinner, kzlth, kbasicslice, &koneslicex);
    MPI_Type_create_hvector(lbdm.bwid, 1, kylth, koneslicex, &lbkmsg3x);
    MPI_Type_commit(&lbkmsg3x);
    MPI_Type_create_hvector(lbdm.bwid, lbdm.zinner, kzlth, kbasicslice, &koneslicey);
    MPI_Type_create_hvector(lbdm.xouter, 1, kylth, koneslicey, &lbkmsg3y);
    MPI_Type_commit(&lbkmsg3y);
    MPI_Type_create_hvector(lbdm.youter, lbdm.bwid, kzlth, kbasicslice, &koneslicez);
    MPI_Type_create_hvector(lbdm.xouter, 1, kylth, koneslicez, &lbkmsg3z);
    MPI_Type_commit(&lbkmsg3z);
#endif
*/
    int nzlth = lbdm.zouter * nulth;
    int nylth = lbdm.youter * nzlth;
#ifdef MPIold
    MPI_Type_hvector(lbdm.yinner, lbdm.zinner, nzlth, nbasicslice, &noneslicex);
    MPI_Type_hvector(lbdm.bwid, 1, nylth, noneslicex, &lbnmsg3x);
    MPI_Type_commit(&lbnmsg3x);
    MPI_Type_hvector(lbdm.bwid, lbdm.zinner, nzlth, nbasicslice, &noneslicey);
    MPI_Type_hvector(lbdm.xouter, 1, nylth, noneslicey, &lbnmsg3y);
    MPI_Type_commit(&lbnmsg3y);
    MPI_Type_hvector(lbdm.youter, lbdm.bwid, nzlth, nbasicslice, &noneslicez);
    MPI_Type_hvector(lbdm.xouter, 1, nylth, noneslicez, &lbnmsg3z);
    MPI_Type_commit(&lbnmsg3z);
#else
    MPI_Type_create_hvector(lbdm.yinner, lbdm.zinner, nzlth, nbasicslice, &noneslicex);
    MPI_Type_create_hvector(lbdm.bwid, 1, nylth, noneslicex, &lbnmsg3x);
    MPI_Type_commit(&lbnmsg3x);
    MPI_Type_create_hvector(lbdm.bwid, lbdm.zinner, nzlth, nbasicslice, &noneslicey);
    MPI_Type_create_hvector(lbdm.xouter, 1, nylth, noneslicey, &lbnmsg3y);
    MPI_Type_commit(&lbnmsg3y);
    MPI_Type_create_hvector(lbdm.youter, lbdm.bwid, nzlth, nbasicslice, &noneslicez);
    MPI_Type_create_hvector(lbdm.xouter, 1, nylth, noneslicez, &lbnmsg3z);
    MPI_Type_commit(&lbnmsg3z);
#endif
  }
  return 0;
}


int fDefineNeighbours()
{

  // calculate names of neigbouring processes and start points for sending/
  // receiving messages (parameters for lbnb[] objects)
  // 0: +x, 1: -x, 2: +y, 3: -y, 4: +z, 5: -z
    
  int pairs, pairs2;
  int mult = (interact>9 && interact<20)?1:lbsy.nf;
    
  pairs = (interact==20)?(4*lbsy.nf):(3*lbsy.nf*(lbsy.nf-1)/2);
  pairs2 = lbsy.nf*(lbsy.nf-1)/2;

  lbnb[0].rank = fCppMod(lbdm.xcor+1, lbdm.xdim) * lbdm.ydim + lbdm.ycor;
  lbnb[0].bspos = (lbdm.xouter - 2 * lbdm.bwid) * lbdm.youter + lbdm.bwid;
  lbnb[0].brpos = (lbdm.xouter - lbdm.bwid) * lbdm.youter + lbdm.bwid;
  lbnb[1].rank = fCppMod(lbdm.xcor-1, lbdm.xdim) * lbdm.ydim + lbdm.ycor;
  lbnb[1].bspos = lbdm.bwid * lbdm.youter + lbdm.bwid;
  lbnb[1].brpos = lbdm.bwid;
  lbnb[2].rank = lbdm.xcor * lbdm.ydim + fCppMod(lbdm.ycor+1, lbdm.ydim);
  lbnb[2].bspos = lbdm.youter - 2 * lbdm.bwid;
  lbnb[2].brpos = lbdm.youter - lbdm.bwid;
  lbnb[3].rank = lbdm.xcor * lbdm.ydim + fCppMod(lbdm.ycor-1, lbdm.ydim);
  lbnb[3].bspos = lbdm.bwid;
  lbnb[3].brpos = 0;
  if(lbsy.nd == 3) {
     lbnb[0].rank = lbnb[0].rank * lbdm.zdim + lbdm.zcor;
     lbnb[0].bspos = lbnb[0].bspos * lbdm.zouter + lbdm.bwid;
     lbnb[0].brpos = lbnb[0].brpos * lbdm.zouter + lbdm.bwid;
     lbnb[1].rank = lbnb[1].rank * lbdm.zdim + lbdm.zcor;
     lbnb[1].bspos = lbnb[1].bspos * lbdm.zouter + lbdm.bwid;
     lbnb[1].brpos = lbnb[1].brpos * lbdm.zouter + lbdm.bwid;
     lbnb[2].rank = lbnb[2].rank * lbdm.zdim + lbdm.zcor;
     lbnb[2].bspos = lbnb[2].bspos * lbdm.zouter + lbdm.bwid;
     lbnb[2].brpos = lbnb[2].brpos * lbdm.zouter + lbdm.bwid;
     lbnb[3].rank = lbnb[3].rank * lbdm.zdim + lbdm.zcor;
     lbnb[3].bspos = lbnb[3].bspos * lbdm.zouter + lbdm.bwid;
     lbnb[3].brpos = lbnb[3].brpos * lbdm.zouter + lbdm.bwid;
     lbnb[4].rank = (lbdm.xcor * lbdm.ydim + lbdm.ycor)* lbdm.zdim
                    + fCppMod(lbdm.zcor+1, lbdm.zdim);
     lbnb[4].bspos = lbdm.zouter - 2 * lbdm.bwid;
     lbnb[4].brpos = lbdm.zouter - lbdm.bwid;
     lbnb[5].rank = (lbdm.xcor * lbdm.ydim + lbdm.ycor)* lbdm.zdim
                    + fCppMod(lbdm.zcor-1, lbdm.zdim);
     lbnb[5].bspos = lbdm.bwid;
     lbnb[5].brpos =0;
  }
 
  for(int i=0; i<4; i++) {
    lbnb[i].rpos = lbnb[i].brpos * lbsitelength;
    lbnb[i].spos = lbnb[i].bspos * lbsitelength;
    lbnb[i].frpos = lbnb[i].brpos * 3 * mult;
    lbnb[i].fspos = lbnb[i].bspos * 3 * mult;
    lbnb[i].irpos = lbnb[i].brpos * pairs;
    lbnb[i].ispos = lbnb[i].bspos * pairs;
//    lbnb[i].krpos = lbnb[i].brpos * pairs2;
//    lbnb[i].kspos = lbnb[i].bspos * pairs2;
    lbnb[i].nrpos = lbnb[i].brpos * 3;
    lbnb[i].nspos = lbnb[i].bspos * 3;
    }
  if(lbsy.nd == 3)
    for(int i=4; i<6; i++) {
      lbnb[i].rpos = lbnb[i].brpos * lbsitelength;
      lbnb[i].spos = lbnb[i].bspos * lbsitelength;
      lbnb[i].frpos = lbnb[i].brpos * 3 * mult;
      lbnb[i].fspos = lbnb[i].bspos * 3 * mult;
      lbnb[i].irpos = lbnb[i].brpos * pairs;
      lbnb[i].ispos = lbnb[i].bspos * pairs;
//      lbnb[i].krpos = lbnb[i].brpos * pairs2;
//      lbnb[i].kspos = lbnb[i].bspos * pairs2;
      lbnb[i].nrpos = lbnb[i].brpos * 3;
      lbnb[i].nspos = lbnb[i].bspos * 3;
    }

  return 0;
}

int fNonBlockComm2DX()
{

  // pass two dimensional boundary value along x direction in unblocked call 
  
  MPI_Request request[4];
#ifdef Packbuf
  double *ptr_start;
  double *ptr_rcv[2];
  int indx, block, i, j, kmax, counter;
    
  MPI_Irecv(recvbuf_1_x,lbdm.bwid*lbdm.yinner*lbsitelength,MPI_DOUBLE,lbnb[1].rank, 10001, MPI_COMM_WORLD, &request[0]);
  MPI_Irecv(recvbuf_0_x,lbdm.bwid*lbdm.yinner*lbsitelength,MPI_DOUBLE,lbnb[0].rank, 10002, MPI_COMM_WORLD, &request[1]);

  ptr_rcv[0] = recvbuf_1_x;
  ptr_rcv[1] = recvbuf_0_x;

  #pragma omp parallel private(block,i,j,counter,ptr_start)
  {
    ptr_start = &lbf[lbnb[0].spos];
    for (j=0; j<lbdm.bwid; j++) {
      counter = j * lbdm.youter * lbsitelength;
      #pragma omp for
      for (block = 0; block < lbdm.yinner*lbsitelength; block++) {
        sendbuf_0_x[j*lbdm.yinner*lbsitelength + block] = ptr_start[counter + block];
      }
    }
    #pragma omp barrier
    #pragma omp master
    {
      MPI_Isend(sendbuf_0_x,lbdm.bwid*lbdm.yinner*lbsitelength,MPI_DOUBLE,lbnb[0].rank, 10001, MPI_COMM_WORLD, &request[2]);
    }
    ptr_start = &lbf[lbnb[1].spos];
    for (j=0; j<lbdm.bwid; j++) {
      counter = j * lbdm.youter * lbsitelength;
      #pragma omp for
      for (block = 0; block < lbdm.yinner*lbsitelength; block++) {
        sendbuf_1_x[j*lbdm.yinner*lbsitelength + block] = ptr_start[counter+block];
      }
    }
    #pragma omp barrier
    #pragma omp master
    {
      MPI_Isend(sendbuf_1_x,lbdm.bwid*lbdm.yinner*lbsitelength,MPI_DOUBLE,lbnb[1].rank, 10002, MPI_COMM_WORLD, &request[3]);
    }
    for (i = 0; i < 2; i++) {
      #pragma omp master
      {
        MPI_Waitany(2, &request[0], &indx, MPI_STATUS_IGNORE);
      }
      #pragma omp barrier
      ptr_start = &lbf[lbnb[1-indx].rpos];
      for (j=0; j<lbdm.bwid; j++) {
        counter = j*lbdm.youter*lbsitelength;
        #pragma omp for
        for (block = 0; block < lbdm.yinner*lbsitelength; block++){
          ptr_start[counter+block] = ptr_rcv[indx][j*lbdm.yinner*lbsitelength+block];
        }
      }
    }
  }
  MPI_Waitall(2, &request[2], MPI_STATUSES_IGNORE);

#else
  MPI_Status status[4];

  MPI_Isend(&lbf[lbnb[0].spos], 1, lbmsg2x, lbnb[0].rank, 
	    10001, MPI_COMM_WORLD, &request[0]);
  MPI_Irecv(&lbf[lbnb[1].rpos], 1, lbmsg2x, lbnb[1].rank, 
	    10001, MPI_COMM_WORLD, &request[1]);
  MPI_Isend(&lbf[lbnb[1].spos], 1, lbmsg2x, lbnb[1].rank, 
	    10002, MPI_COMM_WORLD, &request[2]);
  MPI_Irecv(&lbf[lbnb[0].rpos], 1, lbmsg2x, lbnb[0].rank, 
	    10002, MPI_COMM_WORLD, &request[3]);
  MPI_Waitall(4, request, status);
#endif
  return 0;
}


int fNonBlockComm2DY()
{

  // pass two dimensional boundary value along y direction in unblocked call

  MPI_Request request[4];
#ifdef Packbuf

  double *ptr_start;
  double *ptr_rcv[2];
  int indx, block, counter, i, j, k, kmax;
  int  ylth = lbdm.youter * lbsitelength;
    
  MPI_Irecv(recvbuf_1_y,lbdm.xouter*lbdm.bwid*lbsitelength,MPI_DOUBLE,lbnb[3].rank, 10003, MPI_COMM_WORLD, &request[0]);
  MPI_Irecv(recvbuf_0_y,lbdm.xouter*lbdm.bwid*lbsitelength,MPI_DOUBLE,lbnb[2].rank, 10004, MPI_COMM_WORLD, &request[1]);

  ptr_rcv[0] = recvbuf_1_y;
  ptr_rcv[1] = recvbuf_0_y;

  #pragma omp parallel private(block,i,j,counter,ptr_start)
  {
    ptr_start = &lbf[lbnb[2].spos];
    #pragma omp for
    for (block = 0; block < lbdm.xouter; block++) {
      for (j=0; j<lbdm.bwid*lbsitelength; j++) {
        sendbuf_0_y[block*lbdm.bwid*lbsitelength+j] =  ptr_start[block*ylth+j];
      }
    }
    #pragma omp barrier
    #pragma omp master
    {
      MPI_Isend(sendbuf_0_y,lbdm.xouter*lbdm.bwid*lbsitelength, MPI_DOUBLE, lbnb[2].rank, 10003, MPI_COMM_WORLD, &request[2]);
    }

    ptr_start = &lbf[lbnb[3].spos];
    #pragma omp for
    for (block = 0; block < lbdm.xouter; block++) {
      for (j=0; j<lbdm.bwid*lbsitelength; j++) {
        sendbuf_1_y[block*lbdm.bwid*lbsitelength+j] =  ptr_start[block*ylth+j];
      }
    }
    #pragma omp barrier
    #pragma omp master
    {
      MPI_Isend(sendbuf_1_y,lbdm.xouter*lbdm.bwid*lbsitelength, MPI_DOUBLE, lbnb[3].rank, 10004, MPI_COMM_WORLD, &request[3]);
    }

    for (i = 0; i < 2; ++i) {
      #pragma omp master
      {
        MPI_Waitany(2, &request[0], &indx, MPI_STATUS_IGNORE);
      }
      #pragma omp barrier
      ptr_start = &lbf[lbnb[2+1-indx].rpos];
      #pragma omp for
      for (block = 0; block < lbdm.xouter; block++) {
        for (j=0; j<lbdm.bwid*lbsitelength; j++) {
          ptr_start[block*ylth+j] = ptr_rcv[indx][block*lbdm.bwid*lbsitelength+j];
        }
      }
    }
  }

  MPI_Waitall(2, &request[2], MPI_STATUSES_IGNORE);

#else
  MPI_Status status[4];

  MPI_Isend(&lbf[lbnb[2].spos], 1, lbmsg2y, lbnb[2].rank, 
	    10003, MPI_COMM_WORLD, &request[0]);
  MPI_Irecv(&lbf[lbnb[3].rpos], 1, lbmsg2y, lbnb[3].rank, 
	    10003, MPI_COMM_WORLD, &request[1]);
  MPI_Isend(&lbf[lbnb[3].spos], 1, lbmsg2y, lbnb[3].rank, 
	    10004, MPI_COMM_WORLD, &request[2]);
  MPI_Irecv(&lbf[lbnb[2].rpos], 1, lbmsg2y, lbnb[2].rank, 
	    10004, MPI_COMM_WORLD, &request[3]);
  MPI_Waitall(4, request, status);
#endif
  return 0;
}


int fNonBlockComm2D()
{

  // pass boundary information for 2D system in unblocked call

  fNonBlockComm2DX();
  fNonBlockComm2DY();
  return 0; 
}

int fNonBlockComm3DX()
{

  // pass three dimensional boundary value along x direction in unblocked call

  MPI_Request request[4];

#ifdef Packbuf
  double *ptr_start;
  double *ptr_rcv[2];
  int block_distance = lbsitelength * lbdm.zouter;
  int indx, block, i, j, k, kmax, counter;

  MPI_Irecv(recvbuf_1_x,lbdm.bwid*lbdm.yinner*lbdm.zinner*lbsitelength,MPI_DOUBLE,lbnb[1].rank, 10001, MPI_COMM_WORLD, &request[0]);
  MPI_Irecv(recvbuf_0_x,lbdm.bwid*lbdm.yinner*lbdm.zinner*lbsitelength,MPI_DOUBLE,lbnb[0].rank, 10002, MPI_COMM_WORLD, &request[1]);

  kmax = lbdm.zinner * lbsitelength;
  ptr_rcv[0] = recvbuf_1_x;
  ptr_rcv[1] = recvbuf_0_x;

  #pragma omp parallel private(block,i,j,k,counter,ptr_start)
  {
    ptr_start = &lbf[lbnb[0].spos];
    for (j=0; j<lbdm.bwid; j++) {
      counter = j * lbdm.youter * block_distance;
      #pragma omp for
      for (block = 0; block < lbdm.yinner; block++){
        for (k = 0; k < kmax; k++){
          sendbuf_0_x[j*lbdm.yinner*kmax + block*kmax + k] = ptr_start[counter + block*block_distance + k];
        }
      }
    }
    #pragma omp barrier
    #pragma omp master
    {
      MPI_Isend(sendbuf_0_x,lbdm.bwid*lbdm.yinner*lbdm.zinner*lbsitelength,MPI_DOUBLE,lbnb[0].rank, 10001, MPI_COMM_WORLD, &request[2]);
    }
    ptr_start = &lbf[lbnb[1].spos];
    for (j=0; j<lbdm.bwid; j++) {
      counter = j * lbdm.youter * block_distance;
      #pragma omp for
      for (block = 0; block < lbdm.yinner; block++){
        for (k = 0; k < kmax; k++){
          sendbuf_1_x[j*lbdm.yinner*kmax + block*kmax + k] = ptr_start[counter+block*block_distance + k];
        }
      }
    }
    #pragma omp barrier
    #pragma omp master
    {
      MPI_Isend(sendbuf_1_x,lbdm.bwid*lbdm.yinner*lbdm.zinner*lbsitelength,MPI_DOUBLE,lbnb[1].rank, 10002, MPI_COMM_WORLD, &request[3]);
    }
    for (i = 0; i < 2; i++) {
      #pragma omp master
      {
        MPI_Waitany(2, &request[0], &indx, MPI_STATUS_IGNORE);
      }
      #pragma omp barrier
      ptr_start = &lbf[lbnb[1-indx].rpos];
      for (j=0; j<lbdm.bwid; j++) {
        counter = j*lbdm.youter*block_distance;
        #pragma omp for
        for (block = 0; block < lbdm.yinner; block++){
          for (k = 0; k < kmax; k++) {
            ptr_start[counter+block*block_distance + k] = ptr_rcv[indx][j*lbdm.yinner*kmax+block*kmax+k];
          }
        }
      }
    }
  }
  MPI_Waitall(2, &request[2], MPI_STATUSES_IGNORE);

#else
  MPI_Status status[4];

  MPI_Isend(&lbf[lbnb[0].spos], 1, lbmsg3x, lbnb[0].rank, 
	    10001, MPI_COMM_WORLD, &request[0]);
  MPI_Irecv(&lbf[lbnb[1].rpos], 1, lbmsg3x, lbnb[1].rank, 
	    10001, MPI_COMM_WORLD, &request[1]);
  MPI_Isend(&lbf[lbnb[1].spos], 1, lbmsg3x, lbnb[1].rank, 
	    10002, MPI_COMM_WORLD, &request[2]);
  MPI_Irecv(&lbf[lbnb[0].rpos], 1, lbmsg3x, lbnb[0].rank, 
	    10002, MPI_COMM_WORLD, &request[3]);
  MPI_Waitall(4, request, status);
#endif
    
  return 0;
}


int fNonBlockComm3DY()
{

  // pass three dimensional boundary value along y direction in unblocked call

  MPI_Request request[4];

#ifdef Packbuf

  double *ptr_start;
  double *ptr_rcv[2];
  int indx, block, counter, i, j, k, kmax;
  int  ylth = lbdm.youter * lbdm.zouter * lbsitelength;
  MPI_Irecv(recvbuf_1_y,lbdm.xouter*lbdm.bwid*lbdm.zinner*lbsitelength,MPI_DOUBLE,lbnb[3].rank, 10003, MPI_COMM_WORLD, &request[0]);
  MPI_Irecv(recvbuf_0_y,lbdm.xouter*lbdm.bwid*lbdm.zinner*lbsitelength,MPI_DOUBLE,lbnb[2].rank, 10004, MPI_COMM_WORLD, &request[1]);

  kmax = lbdm.zinner * lbsitelength;
  ptr_rcv[0] = recvbuf_1_y;
  ptr_rcv[1] = recvbuf_0_y;

  #pragma omp parallel private(block,i,j,k,counter,ptr_start)
  {
    ptr_start = &lbf[lbnb[2].spos];
    #pragma omp for
    for (block = 0; block < lbdm.xouter; block++) {
      for (j=0; j<lbdm.bwid; j++) {
        counter = j*lbdm.zouter*lbsitelength;
        for (k = 0; k < kmax; k++) {
          sendbuf_0_y[block*lbdm.bwid*kmax+j*kmax+k] =  ptr_start[block*ylth+counter+k];
        }
      }
    }
    #pragma omp barrier
    #pragma omp master
    {
      MPI_Isend(sendbuf_0_y,lbdm.xouter*lbdm.bwid*lbdm.zinner*lbsitelength, MPI_DOUBLE, lbnb[2].rank, 10003, MPI_COMM_WORLD, &request[2]);
    }

    ptr_start = &lbf[lbnb[3].spos];
    #pragma omp for
    for (block = 0; block < lbdm.xouter; block++) {
      for (j=0; j<lbdm.bwid; j++) {
        counter = j*lbdm.zouter*lbsitelength;
        for (k = 0; k < kmax; k++) {
          sendbuf_1_y[block*lbdm.bwid*kmax+j*kmax+k] =  ptr_start[block*ylth+counter+k];
        }
      }
    }
    #pragma omp barrier
    #pragma omp master
    {
      MPI_Isend(sendbuf_1_y,lbdm.xouter*lbdm.bwid*lbdm.zinner*lbsitelength, MPI_DOUBLE, lbnb[3].rank, 10004, MPI_COMM_WORLD, &request[3]);
    }

    for (i = 0; i < 2; ++i) {
      #pragma omp master
      {
        MPI_Waitany(2, &request[0], &indx, MPI_STATUS_IGNORE);
      }
      #pragma omp barrier
      ptr_start = &lbf[lbnb[2+1-indx].rpos];
      #pragma omp for
      for (block = 0; block < lbdm.xouter; block++) {
        for (j=0; j<lbdm.bwid; j++) {
          counter = j*lbdm.zouter*lbsitelength;
          for (k = 0; k < kmax; k++) {
            ptr_start[block*ylth+counter+k] = ptr_rcv[indx][block*lbdm.bwid*kmax+j*kmax+k];
          }
        }
      }
    }
  }

  MPI_Waitall(2, &request[2], MPI_STATUSES_IGNORE);

#else
  MPI_Status status[4];

  MPI_Isend(&lbf[lbnb[2].spos], 1, lbmsg3y, lbnb[2].rank, 
	    10003, MPI_COMM_WORLD, &request[0]);
  MPI_Irecv(&lbf[lbnb[3].rpos], 1, lbmsg3y, lbnb[3].rank, 
	    10003, MPI_COMM_WORLD, &request[1]);
  MPI_Isend(&lbf[lbnb[3].spos], 1, lbmsg3y, lbnb[3].rank, 
	    10004, MPI_COMM_WORLD, &request[2]);
  MPI_Irecv(&lbf[lbnb[2].rpos], 1, lbmsg3y, lbnb[2].rank, 
	    10004, MPI_COMM_WORLD, &request[3]);
  MPI_Waitall(4, request, status);
#endif
    
  return 0;
}


int fNonBlockComm3DZ()
{

  // pass three dimensional boundary value along z direction in unblocked call

  MPI_Request request[4];

#ifdef Packbuf
  int ylth = lbdm.youter * lbdm.xouter * lbsitelength;
  int i, k, indx, block, xblock, yblock, counter;
  int Xouter = lbdm.xouter;
  int Youter = lbdm.youter;
  int Zouter = lbdm.zouter;
  int message_size = ylth * lbdm.bwid;
  double *ptr_start;
  double *ptr_rcv[2];
  MPI_Irecv(recvbuf_1_z,message_size,MPI_DOUBLE,lbnb[5].rank, 10005, MPI_COMM_WORLD, &request[0]);
  MPI_Irecv(recvbuf_0_z,message_size,MPI_DOUBLE,lbnb[4].rank, 10006, MPI_COMM_WORLD, &request[1]);

  ptr_rcv[0] = recvbuf_1_z;
  ptr_rcv[1] = recvbuf_0_z;

  #pragma omp parallel private(xblock,yblock,k,i,counter,ptr_start)
  {
    ptr_start = &lbf[lbnb[4].spos];
    #pragma omp for collapse(2)
    for (xblock = 0; xblock < Xouter; xblock++) {
      for (yblock = 0; yblock < Youter; yblock++) {
        counter = (xblock * Youter + yblock) * lbsitelength;
        for (k = 0; k < lbdm.bwid*lbsitelength; k++)
          sendbuf_0_z[counter + k] = ptr_start[k +  Zouter * counter];
      }
    }
    #pragma omp barrier
    #pragma omp master
    {
      MPI_Isend(sendbuf_0_z, message_size, MPI_DOUBLE, lbnb[4].rank, 10005, MPI_COMM_WORLD, &request[2]);
    }

    ptr_start = &lbf[lbnb[5].spos];
    #pragma omp for collapse(2)
    for (xblock = 0; xblock < Xouter; xblock++) {
      for (yblock = 0; yblock < Youter; yblock++) {
        counter = (xblock * Youter + yblock) * lbsitelength;
        for (k = 0; k < lbdm.bwid*lbsitelength; k++)
	      sendbuf_1_z[counter + k] = ptr_start[k +  Zouter * counter];
      }
    }

    #pragma omp barrier
    #pragma omp master
    {
      MPI_Isend(sendbuf_1_z, message_size, MPI_DOUBLE, lbnb[5].rank, 10006, MPI_COMM_WORLD, &request[3]);
    }

    for (i = 0; i < 2; i++) {
      #pragma omp master
      {
        MPI_Waitany(2, &request[0], &indx, MPI_STATUS_IGNORE);
      }
      #pragma omp barrier

      ptr_start = &lbf[lbnb[4+1-indx].rpos];

      #pragma omp for collapse(2)
      for (xblock = 0; xblock < Xouter; xblock++) {
        for (yblock = 0; yblock < Youter; yblock++) {
 	      counter = (xblock * Youter + yblock) * lbsitelength;
          for (k = 0; k < lbdm.bwid*lbsitelength; k++)
	        ptr_start[k +  Zouter * counter] = ptr_rcv[indx][counter + k];
        }
      }
    }
  }
  MPI_Waitall(2, &request[2], MPI_STATUSES_IGNORE);

#else
  MPI_Status status[4];

  MPI_Isend(&lbf[lbnb[4].spos], 1, lbmsg3z, lbnb[4].rank, 
	    10005, MPI_COMM_WORLD, &request[0]);
  MPI_Irecv(&lbf[lbnb[5].rpos], 1, lbmsg3z, lbnb[5].rank, 
	    10005, MPI_COMM_WORLD, &request[1]);
  MPI_Isend(&lbf[lbnb[5].spos], 1, lbmsg3z, lbnb[5].rank, 
	    10006, MPI_COMM_WORLD, &request[2]);
  MPI_Irecv(&lbf[lbnb[4].rpos], 1, lbmsg3z, lbnb[4].rank, 
	    10006, MPI_COMM_WORLD, &request[3]);
  MPI_Waitall(4, request, status);
#endif
  return 0;
}

int fNonBlockComm3D()
{

  // pass boundary information for 3D system in unblocked call

  fNonBlockComm3DX();
  fNonBlockComm3DY();
  fNonBlockComm3DZ();
  return 0; 
}

int fNonBlockCommunication()
{

  // pass boundary information for either 2D or 3D system in unblocked call

  if(lbsy.nd == 2)
    fNonBlockComm2D();
  else
    fNonBlockComm3D();
  return 0;
}

int fPrintDomainInfo()
{

  // print domain information

  int dummy;
  int buf[7];
  MPI_Status status;

#ifdef _OPENMP
  int nthreads;
  #pragma omp parallel
  {
    #pragma omp single
    {
      nthreads = omp_get_num_threads();
    }
  }
  if(lbdm.rank==0)
    cout << "Running with " << nthreads << " threads/process" << endl;
#endif

  if(lbdm.rank == 0) {
    cout << "In total, " << lbdm.size << " processes are arranged as follows: ";
    cout << "  x: " << lbdm.xdim << "   y: " << lbdm.ydim;
    if(lbsy.nd == 3)
      cout << "   z: " << lbdm.zdim;
    cout << endl;
    cout << "     process  x-start   x-end   y-start   y-end  ";
    if(lbsy.nd == 3) 
      cout << " z-start   z-end  ";
    cout << endl;
    fPrintLine();
    cout << setw(9) << lbdm.rank << setw(9) << lbdm.xs << setw(9) << lbdm.xe 
         << setw(9) << lbdm.ys << setw(9) << lbdm.ye;
    if(lbsy.nd == 3)
      cout << setw(9) << lbdm.zs << setw(9) << lbdm.ze;
    cout << endl;
    for(int i=1;i<lbdm.size;i++) {
      MPI_Send(&i, 1, MPI_INT, i, 31415, MPI_COMM_WORLD);
      MPI_Recv(buf, 7, MPI_INT, i, 14159, MPI_COMM_WORLD, &status);
      cout << setw(9) << buf[0] << setw(9) << buf[1] << setw(9) << buf[2] 
           << setw(9) << buf[3] << setw(9) << buf[4];
      if(lbsy.nd == 3)
        cout << setw(9) << buf[5] << setw(9) << buf[6];
    cout << endl;
    }
  }
  else {
    buf[0]=lbdm.rank;
    buf[1]=lbdm.xs;
    buf[2]=lbdm.xe;
    buf[3]=lbdm.ys;
    buf[4]=lbdm.ye;
    buf[5]=lbdm.zs;
    buf[6]=lbdm.ze;
    MPI_Recv(&dummy, 1, MPI_INT, 0, 31415, MPI_COMM_WORLD, &status);
    MPI_Send(buf, 7, MPI_INT, 0, 14159, MPI_COMM_WORLD);
  }
  if(lbdm.rank == 0)
    fPrintLine();
  return 0;
}


int fBroadcast(int *item1)
{

  // broadcast integer value

  MPI_Bcast(item1, 1, MPI_INT, 0, MPI_COMM_WORLD);
  return 0;
}


int fOutputInfo()
{

  int i, start[3], end[3];
  int ioRootRank, numberIOGroups;
  int* starts, *ends;

  // determine domain extents for current I/O group

  fGroupPieceRangeGlobal(start,end);

  // gather domain extents for all I/O groups

  if(lbIOGroup.rank == 0) {
    MPI_Comm_rank(ioRootCommunicator, &ioRootRank);
    numberIOGroups = lbIOGroup.rootSize;
      
    starts = (int*)malloc(numberIOGroups*3*sizeof(int));
    ends   = (int*)malloc(numberIOGroups*3*sizeof(int));
      
    MPI_Gather(start, 3, MPI_INT, starts, 3, MPI_INT, 0, ioRootCommunicator);
    MPI_Gather(end,   3, MPI_INT, ends,   3, MPI_INT, 0, ioRootCommunicator);

  // output system information

    if(ioRootRank == 0) {
      ofstream file1("lbout.info");
      file1<<"numberofDimensions    "<<lbsy.nd<<endl;
      file1<<"numberofFluids        "<<lbsy.nf<<endl;
      file1<<"numberofSolutes       "<<lbsy.nc<<endl;
      file1<<"numberofTemperatures  "<<lbsy.nt<<endl;
      file1<<"sizeofSystem          "<<numberIOGroups<<endl;
      file1<<"sizeofInteger         "<<sizeof(int)<<endl;
      file1<<"sizeofFloat           "<<sizeof(float)<<endl;
      file1.close();
      
      if(!lbmpiio) {
        ofstream file2("lbout.ext");
        // print extents for all I/O groups
        for(i=0;i<numberIOGroups;i++) {
            file2<<"extent_"<<setw(6)<<setfill('0')<<i<<"   "<<starts[3*i]<<" "<<ends[3*i]
                 <<" "<<starts[3*i+1]<<" "<<ends[3*i+1]<<" "<<starts[3*i+2]<<" "<<ends[3*i+2]<<endl;
        }
        file2.close();
      }
    }
    free(starts);
    free(ends);
  }

  MPI_Barrier(MPI_COMM_WORLD);
  return 0;
}


int fMPISetoffSteer()
{

  // create notsteer file to prevent DL_MESO_LBE from creating new system and 
  // space files
  
  if(lbdm.rank == 0)
    {
      ofstream file("notsteer");
      lbsteer = 0;
      file.close();
    }
  fBroadcast(&lbsteer);
  return 0;
}


int fMPICheckSteer()
{

  // check for existence of notsteer file: if not found, read system and space 
  // files
  
  if(lbdm.rank == 0)
    {
      ifstream file("notsteer");
      if(!file)
	lbsteer = 1;
      file.close();
    }
  fBroadcast(&lbsteer);
  
  if(lbsteer == 1) {
    fInputParameters("lbin.sys");
    fReadSpaceParameter("lbin.spa");	
  }
  
  fMPISetoffSteer();
  
  return 0;
}

int fBoundNonBlockComm2DX()
{

  // pass two dimensional boundary values along x direction in unblocked call
  
  MPI_Request request[12];
  MPI_Status status[12];

  // boundary condition
    
  MPI_Isend(&lbphi[lbnb[0].bspos], 1, lbbmsg2x, lbnb[0].rank, 
	    1001, MPI_COMM_WORLD, &request[0]);
  MPI_Irecv(&lbphi[lbnb[1].brpos], 1, lbbmsg2x, lbnb[1].rank, 
	    1001, MPI_COMM_WORLD, &request[1]);
  MPI_Isend(&lbphi[lbnb[1].bspos], 1, lbbmsg2x, lbnb[1].rank, 
	    1002, MPI_COMM_WORLD, &request[2]);
  MPI_Irecv(&lbphi[lbnb[0].brpos], 1, lbbmsg2x, lbnb[0].rank, 
	    1002, MPI_COMM_WORLD, &request[3]);

  // neighbouring point information
    
  MPI_Isend(&lbneigh[lbnb[0].bspos], 1, lbbmsg2x, lbnb[0].rank,
	    2001, MPI_COMM_WORLD, &request[4]);
  MPI_Irecv(&lbneigh[lbnb[1].brpos], 1, lbbmsg2x, lbnb[1].rank,
	    2001, MPI_COMM_WORLD, &request[5]);
  MPI_Isend(&lbneigh[lbnb[1].bspos], 1, lbbmsg2x, lbnb[1].rank,
	    2002, MPI_COMM_WORLD, &request[6]);
  MPI_Irecv(&lbneigh[lbnb[0].brpos], 1, lbbmsg2x, lbnb[0].rank,
	    2002, MPI_COMM_WORLD, &request[7]);

  // surface normals
    
  MPI_Isend(&lbboundnorm[lbnb[0].nspos], 1, lbnmsg2x, lbnb[0].rank,
        3001, MPI_COMM_WORLD, &request[8]);
  MPI_Irecv(&lbboundnorm[lbnb[1].nrpos], 1, lbnmsg2x, lbnb[1].rank,
        3001, MPI_COMM_WORLD, &request[9]);
  MPI_Isend(&lbboundnorm[lbnb[1].nspos], 1, lbnmsg2x, lbnb[1].rank,
        3002, MPI_COMM_WORLD, &request[10]);
  MPI_Irecv(&lbboundnorm[lbnb[0].nrpos], 1, lbnmsg2x, lbnb[0].rank,
        3002, MPI_COMM_WORLD, &request[11]);
    
  MPI_Waitall(12, request, status);
    
  return 0;
}


int fBoundNonBlockComm2DY()
{

  // pass two dimensional boundary values along y direction in unblocked call

  MPI_Request request[12];
  MPI_Status status[12];

  // boundary condition
    
  MPI_Isend(&lbphi[lbnb[2].bspos], 1, lbbmsg2y, lbnb[2].rank, 
	    1003, MPI_COMM_WORLD, &request[0]);
  MPI_Irecv(&lbphi[lbnb[3].brpos], 1, lbbmsg2y, lbnb[3].rank, 
	    1003, MPI_COMM_WORLD, &request[1]);
  MPI_Isend(&lbphi[lbnb[3].bspos], 1, lbbmsg2y, lbnb[3].rank, 
	    1004, MPI_COMM_WORLD, &request[2]);
  MPI_Irecv(&lbphi[lbnb[2].brpos], 1, lbbmsg2y, lbnb[2].rank, 
	    1004, MPI_COMM_WORLD, &request[3]);
    
  // neighbouring point information
    
  MPI_Isend(&lbneigh[lbnb[2].bspos], 1, lbbmsg2y, lbnb[2].rank,
	    2003, MPI_COMM_WORLD, &request[4]);
  MPI_Irecv(&lbneigh[lbnb[3].brpos], 1, lbbmsg2y, lbnb[3].rank,
	    2003, MPI_COMM_WORLD, &request[5]);
  MPI_Isend(&lbneigh[lbnb[3].bspos], 1, lbbmsg2y, lbnb[3].rank,
	    2004, MPI_COMM_WORLD, &request[6]);
  MPI_Irecv(&lbneigh[lbnb[2].brpos], 1, lbbmsg2y, lbnb[2].rank,
	    2004, MPI_COMM_WORLD, &request[7]);
    
  // surface normals
    
  MPI_Isend(&lbboundnorm[lbnb[2].nspos], 1, lbnmsg2y, lbnb[2].rank,
        3003, MPI_COMM_WORLD, &request[8]);
  MPI_Irecv(&lbboundnorm[lbnb[3].nrpos], 1, lbnmsg2y, lbnb[3].rank,
        3003, MPI_COMM_WORLD, &request[9]);
  MPI_Isend(&lbboundnorm[lbnb[3].nspos], 1, lbnmsg2y, lbnb[3].rank,
        3004, MPI_COMM_WORLD, &request[10]);
  MPI_Irecv(&lbboundnorm[lbnb[2].nrpos], 1, lbnmsg2y, lbnb[2].rank,
        3004, MPI_COMM_WORLD, &request[11]);
    
  MPI_Waitall(12, request, status);
  return 0;
}


int fBoundNonBlockComm2D()
{

  // pass boundary information for 2D system in unblocked call

  fBoundNonBlockComm2DX();
  fBoundNonBlockComm2DY();
  return 0; 
}

int fBoundNonBlockComm3DX()
{

  // pass three dimensional boundary values along x direction in unblocked call

  MPI_Request request[12];
  MPI_Status status[12];

  // boundary condition
    
  MPI_Isend(&lbphi[lbnb[0].bspos], 1, lbbmsg3x, lbnb[0].rank, 
	    1001, MPI_COMM_WORLD, &request[0]);
  MPI_Irecv(&lbphi[lbnb[1].brpos], 1, lbbmsg3x, lbnb[1].rank, 
	    1001, MPI_COMM_WORLD, &request[1]);
  MPI_Isend(&lbphi[lbnb[1].bspos], 1, lbbmsg3x, lbnb[1].rank, 
	    1002, MPI_COMM_WORLD, &request[2]);
  MPI_Irecv(&lbphi[lbnb[0].brpos], 1, lbbmsg3x, lbnb[0].rank, 
	    1002, MPI_COMM_WORLD, &request[3]);
    
  // neighbouring point information
    
  MPI_Isend(&lbneigh[lbnb[0].bspos], 1, lbbmsg3x, lbnb[0].rank,
	    2001, MPI_COMM_WORLD, &request[4]);
  MPI_Irecv(&lbneigh[lbnb[1].brpos], 1, lbbmsg3x, lbnb[1].rank,
	    2001, MPI_COMM_WORLD, &request[5]);
  MPI_Isend(&lbneigh[lbnb[1].bspos], 1, lbbmsg3x, lbnb[1].rank,
	    2002, MPI_COMM_WORLD, &request[6]);
  MPI_Irecv(&lbneigh[lbnb[0].brpos], 1, lbbmsg3x, lbnb[0].rank,
	    2002, MPI_COMM_WORLD, &request[7]);
    
  // surface normals
    
  MPI_Isend(&lbboundnorm[lbnb[0].nspos], 1, lbnmsg3x, lbnb[0].rank,
        3001, MPI_COMM_WORLD, &request[8]);
  MPI_Irecv(&lbboundnorm[lbnb[1].nrpos], 1, lbnmsg3x, lbnb[1].rank,
        3001, MPI_COMM_WORLD, &request[9]);
  MPI_Isend(&lbboundnorm[lbnb[1].nspos], 1, lbnmsg3x, lbnb[1].rank,
        3002, MPI_COMM_WORLD, &request[10]);
  MPI_Irecv(&lbboundnorm[lbnb[0].nrpos], 1, lbnmsg3x, lbnb[0].rank,
        3002, MPI_COMM_WORLD, &request[11]);
    
  MPI_Waitall(12, request, status);
  return 0;
}


int fBoundNonBlockComm3DY()
{

  // pass three dimensional boundary values along y direction in unblocked call

  MPI_Request request[12];
  MPI_Status status[12];

  // boundary condition
    
  MPI_Isend(&lbphi[lbnb[2].bspos], 1, lbbmsg3y, lbnb[2].rank, 
	    1003, MPI_COMM_WORLD, &request[0]);
  MPI_Irecv(&lbphi[lbnb[3].brpos], 1, lbbmsg3y, lbnb[3].rank, 
	    1003, MPI_COMM_WORLD, &request[1]);
  MPI_Isend(&lbphi[lbnb[3].bspos], 1, lbbmsg3y, lbnb[3].rank, 
	    1004, MPI_COMM_WORLD, &request[2]);
  MPI_Irecv(&lbphi[lbnb[2].brpos], 1, lbbmsg3y, lbnb[2].rank, 
	    1004, MPI_COMM_WORLD, &request[3]);
    
   // neighbouring point information
    
  MPI_Isend(&lbneigh[lbnb[2].bspos], 1, lbbmsg3y, lbnb[2].rank,
	    2003, MPI_COMM_WORLD, &request[4]);
  MPI_Irecv(&lbneigh[lbnb[3].brpos], 1, lbbmsg3y, lbnb[3].rank,
	    2003, MPI_COMM_WORLD, &request[5]);
  MPI_Isend(&lbneigh[lbnb[3].bspos], 1, lbbmsg3y, lbnb[3].rank,
	    2004, MPI_COMM_WORLD, &request[6]);
  MPI_Irecv(&lbneigh[lbnb[2].brpos], 1, lbbmsg3y, lbnb[2].rank,
	    2004, MPI_COMM_WORLD, &request[7]);
    
  // surface normals
    
  MPI_Isend(&lbboundnorm[lbnb[2].nspos], 1, lbnmsg3y, lbnb[2].rank,
        3003, MPI_COMM_WORLD, &request[8]);
  MPI_Irecv(&lbboundnorm[lbnb[3].nrpos], 1, lbnmsg3y, lbnb[3].rank,
        3003, MPI_COMM_WORLD, &request[9]);
  MPI_Isend(&lbboundnorm[lbnb[3].nspos], 1, lbnmsg3y, lbnb[3].rank,
        3004, MPI_COMM_WORLD, &request[10]);
  MPI_Irecv(&lbboundnorm[lbnb[2].nrpos], 1, lbnmsg3y, lbnb[2].rank,
        3004, MPI_COMM_WORLD, &request[11]);
    
  MPI_Waitall(12, request, status);
  return 0;
}


int fBoundNonBlockComm3DZ()
{

  // pass three dimensional boundary values along z direction in unblocked call

  MPI_Request request[12];
  MPI_Status status[12];

  // boundary condition
    
  MPI_Isend(&lbphi[lbnb[4].bspos], 1, lbbmsg3z, lbnb[4].rank, 
	    1005, MPI_COMM_WORLD, &request[0]);
  MPI_Irecv(&lbphi[lbnb[5].brpos], 1, lbbmsg3z, lbnb[5].rank, 
	    1005, MPI_COMM_WORLD, &request[1]);
  MPI_Isend(&lbphi[lbnb[5].bspos], 1, lbbmsg3z, lbnb[5].rank, 
	    1006, MPI_COMM_WORLD, &request[2]);
  MPI_Irecv(&lbphi[lbnb[4].brpos], 1, lbbmsg3z, lbnb[4].rank, 
	    1006, MPI_COMM_WORLD, &request[3]);
    
   // neighbouring point information
    
  MPI_Isend(&lbneigh[lbnb[4].bspos], 1, lbbmsg3z, lbnb[4].rank,
	    2005, MPI_COMM_WORLD, &request[4]);
  MPI_Irecv(&lbneigh[lbnb[5].brpos], 1, lbbmsg3z, lbnb[5].rank,
	    2005, MPI_COMM_WORLD, &request[5]);
  MPI_Isend(&lbneigh[lbnb[5].bspos], 1, lbbmsg3z, lbnb[5].rank,
	    2006, MPI_COMM_WORLD, &request[6]);
  MPI_Irecv(&lbneigh[lbnb[4].brpos], 1, lbbmsg3z, lbnb[4].rank,
	    2006, MPI_COMM_WORLD, &request[7]);
    
  // surface normals
    
  MPI_Isend(&lbboundnorm[lbnb[4].nspos], 1, lbnmsg3z, lbnb[4].rank,
        3005, MPI_COMM_WORLD, &request[8]);
  MPI_Irecv(&lbboundnorm[lbnb[5].nrpos], 1, lbnmsg3z, lbnb[5].rank,
        3005, MPI_COMM_WORLD, &request[9]);
  MPI_Isend(&lbboundnorm[lbnb[5].nspos], 1, lbnmsg3z, lbnb[5].rank,
        3006, MPI_COMM_WORLD, &request[10]);
  MPI_Irecv(&lbboundnorm[lbnb[4].nrpos], 1, lbnmsg3z, lbnb[4].rank,
        3006, MPI_COMM_WORLD, &request[11]);
    
  MPI_Waitall(12, request, status);
  return 0;
}

int fBoundNonBlockComm3D()
{

  // pass boundary information for 3D system in unblocked call

  fBoundNonBlockComm3DX();
  fBoundNonBlockComm3DY();
  fBoundNonBlockComm3DZ();
  return 0; 
}

int fBoundNonBlockCommunication()
{

  // pass boundary information for either 2D or 3D system in unblocked call

  if(lbsy.nd == 2)
    fBoundNonBlockComm2D();
  else
    fBoundNonBlockComm3D();
  return 0;
}

// interaction forces

int fForceNonBlockComm2DX()
{

  // pass two dimensional interaction forces along x direction in unblocked call 
  
  MPI_Request request[4];
#ifdef Packbuf
  double *ptr_start;
  double *ptr_rcv[2];
  int indx, block, i, j, kmax, counter;
  int mult = (interact>9 && interact<20)?1:lbsy.nf;

  MPI_Irecv(recvbuf_1_x,3*lbdm.bwid*lbdm.yinner*mult,MPI_DOUBLE,lbnb[1].rank, 5001, MPI_COMM_WORLD, &request[0]);
  MPI_Irecv(recvbuf_0_x,3*lbdm.bwid*lbdm.yinner*mult,MPI_DOUBLE,lbnb[0].rank, 5002, MPI_COMM_WORLD, &request[1]);

  ptr_rcv[0] = recvbuf_1_x;
  ptr_rcv[1] = recvbuf_0_x;

  #pragma omp parallel private(block,i,j,counter,ptr_start)
  {
    ptr_start = &lbinterforce[lbnb[0].fspos];
    for (j=0; j<lbdm.bwid; j++) {
      counter = 3 * j * lbdm.youter * mult;
      #pragma omp for
      for (block = 0; block < 3*lbdm.yinner*mult; block++) {
        sendbuf_0_x[3*j*lbdm.yinner*mult + block] = ptr_start[counter + block];
      }
    }
    #pragma omp barrier
    #pragma omp master
    {
      MPI_Isend(sendbuf_0_x,3*lbdm.bwid*lbdm.yinner*mult,MPI_DOUBLE,lbnb[0].rank, 5001, MPI_COMM_WORLD, &request[2]);
    }
    ptr_start = &lbinterforce[lbnb[1].fspos];
    for (j=0; j<lbdm.bwid; j++) {
      counter = 3 * j * lbdm.youter * mult;
      #pragma omp for
      for (block = 0; block < 3*lbdm.yinner*mult; block++) {
        sendbuf_1_x[3*j*lbdm.yinner*mult + block] = ptr_start[counter+block];
      }
    }
    #pragma omp barrier
    #pragma omp master
    {
      MPI_Isend(sendbuf_1_x,3*lbdm.bwid*lbdm.yinner*mult,MPI_DOUBLE,lbnb[1].rank, 5002, MPI_COMM_WORLD, &request[3]);
    }
    for (i = 0; i < 2; i++) {
      #pragma omp master
      {
        MPI_Waitany(2, &request[0], &indx, MPI_STATUS_IGNORE);
      }
      #pragma omp barrier
      ptr_start = &lbinterforce[lbnb[1-indx].frpos];
      for (j=0; j<lbdm.bwid; j++) {
        counter = 3*j*lbdm.youter*mult;
        #pragma omp for
        for (block = 0; block < 3*lbdm.yinner*mult; block++){
          ptr_start[counter+block] = ptr_rcv[indx][3*j*lbdm.yinner*mult+block];
        }
      }
    }
  }
  MPI_Waitall(2, &request[2], MPI_STATUSES_IGNORE);

#else
  MPI_Status status[4];

  MPI_Isend(&lbinterforce[lbnb[0].fspos], 1, lbfmsg2x, lbnb[0].rank, 
	    5001, MPI_COMM_WORLD, &request[0]);
  MPI_Irecv(&lbinterforce[lbnb[1].frpos], 1, lbfmsg2x, lbnb[1].rank, 
	    5001, MPI_COMM_WORLD, &request[1]);
  MPI_Isend(&lbinterforce[lbnb[1].fspos], 1, lbfmsg2x, lbnb[1].rank, 
	    5002, MPI_COMM_WORLD, &request[2]);
  MPI_Irecv(&lbinterforce[lbnb[0].frpos], 1, lbfmsg2x, lbnb[0].rank, 
	    5002, MPI_COMM_WORLD, &request[3]);
  MPI_Waitall(4, request, status);
#endif
  return 0;
}


int fForceNonBlockComm2DY()
{

  // pass two dimensional interaction forces along y direction in unblocked call 

  MPI_Request request[4];
#ifdef Packbuf

  double *ptr_start;
  double *ptr_rcv[2];
  int indx, block, counter, i, j, k, kmax;
  int mult = (interact>9 && interact<20)?1:lbsy.nf;
  int ylth = 3 * lbdm.youter * mult;

  MPI_Irecv(recvbuf_1_y,3*lbdm.xouter*lbdm.bwid*mult,MPI_DOUBLE,lbnb[3].rank, 5003, MPI_COMM_WORLD, &request[0]);
  MPI_Irecv(recvbuf_0_y,3*lbdm.xouter*lbdm.bwid*mult,MPI_DOUBLE,lbnb[2].rank, 5004, MPI_COMM_WORLD, &request[1]);
  ptr_rcv[0] = recvbuf_1_y;
  ptr_rcv[1] = recvbuf_0_y;

  #pragma omp parallel private(block,i,j,counter,ptr_start)
  {
    ptr_start = &lbinterforce[lbnb[2].fspos];
    #pragma omp for
    for (block = 0; block < lbdm.xouter; block++) {
      for (j=0; j<3*lbdm.bwid*mult; j++) {
        sendbuf_0_y[3*block*lbdm.bwid*mult+j] =  ptr_start[block*ylth+j];
      }
    }
    #pragma omp barrier
    #pragma omp master
    {
      MPI_Isend(sendbuf_0_y, 3*lbdm.xouter*lbdm.bwid*mult, MPI_DOUBLE, lbnb[2].rank, 5003, MPI_COMM_WORLD, &request[2]);
    }

    ptr_start = &lbinterforce[lbnb[3].fspos];
    #pragma omp for
    for (block = 0; block < lbdm.xouter; block++) {
      for (j=0; j<3*lbdm.bwid*mult; j++) {
        sendbuf_1_y[3*block*lbdm.bwid*mult+j] =  ptr_start[block*ylth+j];
      }
    }
    #pragma omp barrier
    #pragma omp master
    {
      MPI_Isend(sendbuf_1_y, 3*lbdm.xouter*lbdm.bwid*mult, MPI_DOUBLE, lbnb[3].rank, 5004, MPI_COMM_WORLD, &request[3]);
    }

    for (i = 0; i < 2; ++i) {
      #pragma omp master
      {
        MPI_Waitany(2, &request[0], &indx, MPI_STATUS_IGNORE);
      }
      #pragma omp barrier
      ptr_start = &lbinterforce[lbnb[2+1-indx].frpos];
      #pragma omp for
      for (block = 0; block < lbdm.xouter; block++) {
        for (j=0; j<3*lbdm.bwid*mult; j++) {
          ptr_start[block*ylth+j] = ptr_rcv[indx][3*block*lbdm.bwid*mult+j];
        }
      }
    }
  }

  MPI_Waitall(2, &request[2], MPI_STATUSES_IGNORE);

#else
  MPI_Status status[4];

  MPI_Isend(&lbinterforce[lbnb[2].fspos], 1, lbfmsg2y, lbnb[2].rank, 
	    5003, MPI_COMM_WORLD, &request[0]);
  MPI_Irecv(&lbinterforce[lbnb[3].frpos], 1, lbfmsg2y, lbnb[3].rank, 
	    5003, MPI_COMM_WORLD, &request[1]);
  MPI_Isend(&lbinterforce[lbnb[3].fspos], 1, lbfmsg2y, lbnb[3].rank, 
	    5004, MPI_COMM_WORLD, &request[2]);
  MPI_Irecv(&lbinterforce[lbnb[2].frpos], 1, lbfmsg2y, lbnb[2].rank, 
	    5004, MPI_COMM_WORLD, &request[3]);
  MPI_Waitall(4, request, status);
#endif
  return 0;
}


int fForceNonBlockComm2D()
{

  // pass interaction force information for 2D system in unblocked call

  fForceNonBlockComm2DX();
  fForceNonBlockComm2DY();
  return 0; 
}

int fForceNonBlockComm3DX()
{

  // pass three dimensional interaction forces along x direction in unblocked call

  MPI_Request request[4];

#ifdef Packbuf

  double *ptr_start;
  double *ptr_rcv[2];
  int mult = (interact>9 && interact<20)?1:lbsy.nf;
  int block_distance = 3 * mult * lbdm.zouter;
  int indx, block, i, j, k, kmax, counter;
    
  MPI_Irecv(recvbuf_1_x,3*lbdm.bwid*lbdm.yinner*lbdm.zinner*mult,MPI_DOUBLE,lbnb[1].rank, 5001, MPI_COMM_WORLD, &request[0]);
  MPI_Irecv(recvbuf_0_x,3*lbdm.bwid*lbdm.yinner*lbdm.zinner*mult,MPI_DOUBLE,lbnb[0].rank, 5002, MPI_COMM_WORLD, &request[1]);

  kmax = 3 * lbdm.zinner * mult;
  ptr_rcv[0] = recvbuf_1_x;
  ptr_rcv[1] = recvbuf_0_x;

  #pragma omp parallel private(block,i,j,k,counter,ptr_start)
  {
    ptr_start = &lbinterforce[lbnb[0].fspos];
    for (j=0; j<lbdm.bwid; j++) {
      counter = j * lbdm.youter * block_distance;
      #pragma omp for
      for (block = 0; block < lbdm.yinner; block++){
        for (k = 0; k < kmax; k++){
          sendbuf_0_x[j*lbdm.yinner*kmax + block*kmax + k] = ptr_start[counter + block*block_distance + k];
        }
      }
    }
    #pragma omp barrier
    #pragma omp master
    {
      MPI_Isend(sendbuf_0_x,3*lbdm.bwid*lbdm.yinner*lbdm.zinner*mult,MPI_DOUBLE,lbnb[0].rank, 5001, MPI_COMM_WORLD, &request[2]);
    }
    ptr_start = &lbinterforce[lbnb[1].fspos];
    for (j=0; j<lbdm.bwid; j++) {
      counter = j * lbdm.youter * block_distance;
      #pragma omp for
      for (block = 0; block < lbdm.yinner; block++){
        for (k = 0; k < kmax; k++){
          sendbuf_1_x[j*lbdm.yinner*kmax + block*kmax + k] = ptr_start[counter+block*block_distance + k];
        }
      }
    }
    #pragma omp barrier
    #pragma omp master
    {
      MPI_Isend(sendbuf_1_x,3*lbdm.bwid*lbdm.yinner*lbdm.zinner*mult,MPI_DOUBLE,lbnb[1].rank, 5002, MPI_COMM_WORLD, &request[3]);
    }
    for (i = 0; i < 2; i++) {
      #pragma omp master
      {
        MPI_Waitany(2, &request[0], &indx, MPI_STATUS_IGNORE);
      }
      #pragma omp barrier
      ptr_start = &lbinterforce[lbnb[1-indx].frpos];
      for (j=0; j<lbdm.bwid; j++) {
        counter = j*lbdm.youter*block_distance;
        #pragma omp for
        for (block = 0; block < lbdm.yinner; block++){
          for (k = 0; k < kmax; k++) {
            ptr_start[counter+block*block_distance + k] = ptr_rcv[indx][j*lbdm.yinner*kmax+block*kmax+k];
          }
        }
      }
    }
  }
  MPI_Waitall(2, &request[2], MPI_STATUSES_IGNORE);

#else
  MPI_Status status[4];

  MPI_Isend(&lbinterforce[lbnb[0].fspos], 1, lbfmsg3x, lbnb[0].rank, 
	    5001, MPI_COMM_WORLD, &request[0]);
  MPI_Irecv(&lbinterforce[lbnb[1].frpos], 1, lbfmsg3x, lbnb[1].rank, 
	    5001, MPI_COMM_WORLD, &request[1]);
  MPI_Isend(&lbinterforce[lbnb[1].fspos], 1, lbfmsg3x, lbnb[1].rank, 
	    5002, MPI_COMM_WORLD, &request[2]);
  MPI_Irecv(&lbinterforce[lbnb[0].frpos], 1, lbfmsg3x, lbnb[0].rank, 
	    5002, MPI_COMM_WORLD, &request[3]);
  MPI_Waitall(4, request, status);
#endif
  return 0;
}


int fForceNonBlockComm3DY()
{

  // pass three dimensional interaction forces along y direction in unblocked call

  MPI_Request request[4];

#ifdef Packbuf

  double *ptr_start;
  double *ptr_rcv[2];
  int indx, block, counter, i, j, k, kmax;
  int mult = (interact>9 && interact<20)?1:lbsy.nf;
  int ylth = 3 * lbdm.youter * lbdm.zouter * mult;

  MPI_Irecv(recvbuf_1_y,3*lbdm.xouter*lbdm.bwid*lbdm.zinner*mult,MPI_DOUBLE,lbnb[3].rank, 5003, MPI_COMM_WORLD, &request[0]);
  MPI_Irecv(recvbuf_0_y,3*lbdm.xouter*lbdm.bwid*lbdm.zinner*mult,MPI_DOUBLE,lbnb[2].rank, 5004, MPI_COMM_WORLD, &request[1]);

  kmax = 3 * lbdm.zinner * mult;
  ptr_rcv[0] = recvbuf_1_y;
  ptr_rcv[1] = recvbuf_0_y;
    
  #pragma omp parallel private(block,i,j,k,counter,ptr_start)
  {
    ptr_start = &lbinterforce[lbnb[2].fspos];
    #pragma omp for
    for (block = 0; block < lbdm.xouter; block++) {
      for (j=0; j<lbdm.bwid; j++) {
        counter = 3*j*lbdm.zouter*mult;
        for (k = 0; k < kmax; k++) {
          sendbuf_0_y[block*lbdm.bwid*kmax+j*kmax+k] =  ptr_start[block*ylth+counter+k];
        }
      }
    }
    #pragma omp barrier
    #pragma omp master
    {
      MPI_Isend(sendbuf_0_y,3*lbdm.xouter*lbdm.bwid*lbdm.zinner*mult, MPI_DOUBLE, lbnb[2].rank, 5003, MPI_COMM_WORLD, &request[2]);
    }

    ptr_start = &lbinterforce[lbnb[3].fspos];
    #pragma omp for
    for (block = 0; block < lbdm.xouter; block++) {
      for (j=0; j<lbdm.bwid; j++) {
        counter = 3*j*lbdm.zouter*mult;
        for (k = 0; k < kmax; k++) {
          sendbuf_1_y[block*lbdm.bwid*kmax+j*kmax+k] =  ptr_start[block*ylth+counter+k];
        }
      }
    }
    #pragma omp barrier
    #pragma omp master
    {
      MPI_Isend(sendbuf_1_y,3*lbdm.xouter*lbdm.bwid*lbdm.zinner*mult, MPI_DOUBLE, lbnb[3].rank, 5004, MPI_COMM_WORLD, &request[3]);
    }

    for (i = 0; i < 2; ++i) {
      #pragma omp master
      {
        MPI_Waitany(2, &request[0], &indx, MPI_STATUS_IGNORE);
      }
      #pragma omp barrier
      ptr_start = &lbinterforce[lbnb[2+1-indx].frpos];
      #pragma omp for
      for (block = 0; block < lbdm.xouter; block++) {
        for (j=0; j<lbdm.bwid; j++) {
          counter = 3*j*lbdm.zouter*mult;
          for (k = 0; k < kmax; k++) {
            ptr_start[block*ylth+counter+k] = ptr_rcv[indx][block*lbdm.bwid*kmax+j*kmax+k];
          }
        }
      }
    }
  }

  MPI_Waitall(2, &request[2], MPI_STATUSES_IGNORE);

#else
  MPI_Status status[4];

  MPI_Isend(&lbinterforce[lbnb[2].fspos], 1, lbfmsg3y, lbnb[2].rank, 
	    5003, MPI_COMM_WORLD, &request[0]);
  MPI_Irecv(&lbinterforce[lbnb[3].frpos], 1, lbfmsg3y, lbnb[3].rank, 
	    5003, MPI_COMM_WORLD, &request[1]);
  MPI_Isend(&lbinterforce[lbnb[3].fspos], 1, lbfmsg3y, lbnb[3].rank, 
	    5004, MPI_COMM_WORLD, &request[2]);
  MPI_Irecv(&lbinterforce[lbnb[2].frpos], 1, lbfmsg3y, lbnb[2].rank, 
	    5004, MPI_COMM_WORLD, &request[3]);
  MPI_Waitall(4, request, status);
#endif
  return 0;
}


int fForceNonBlockComm3DZ()
{

  // pass three dimensional interaction forces along z direction in unblocked call

  MPI_Request request[4];

#ifdef Packbuf

  int i, k, indx, block, xblock, yblock, counter;
  int Xouter = lbdm.xouter;
  int Youter = lbdm.youter;
  int Zouter = lbdm.zouter;
  int mult = (interact>9 && interact<20)?1:lbsy.nf;
  int ylth = 3 * lbdm.youter * lbdm.xouter * mult;
  int message_size = ylth * lbdm.bwid;
  double *ptr_start;
  double *ptr_rcv[2];

  MPI_Irecv(recvbuf_1_z,message_size,MPI_DOUBLE,lbnb[5].rank, 5005, MPI_COMM_WORLD, &request[0]);
  MPI_Irecv(recvbuf_0_z,message_size,MPI_DOUBLE,lbnb[4].rank, 5006, MPI_COMM_WORLD, &request[1]);

  ptr_rcv[0] = recvbuf_1_z;
  ptr_rcv[1] = recvbuf_0_z;

  #pragma omp parallel private(xblock,yblock,k,i,counter,ptr_start)
  {
    ptr_start = &lbinterforce[lbnb[4].fspos];
    #pragma omp for collapse(2)
    for (xblock = 0; xblock < Xouter; xblock++) {
      for (yblock = 0; yblock < Youter; yblock++) {
        counter = 3 * (xblock * Youter + yblock) * mult;
        for (k = 0; k < 3*lbdm.bwid*mult; k++)
          sendbuf_0_z[counter + k] = ptr_start[k +  Zouter * counter];
      }
    }
    #pragma omp barrier
    #pragma omp master
    {
      MPI_Isend(sendbuf_0_z, message_size, MPI_DOUBLE, lbnb[4].rank, 5005, MPI_COMM_WORLD, &request[2]);
    }

    ptr_start = &lbinterforce[lbnb[5].fspos];
    #pragma omp for collapse(2)
    for (xblock = 0; xblock < Xouter; xblock++) {
      for (yblock = 0; yblock < Youter; yblock++) {
        counter = 3 * (xblock * Youter + yblock) * mult;
        for (k = 0; k < 3*lbdm.bwid*mult; k++)
	      sendbuf_1_z[counter + k] = ptr_start[k +  Zouter * counter];
      }
    }

    #pragma omp barrier
    #pragma omp master
    {
      MPI_Isend(sendbuf_1_z, message_size, MPI_DOUBLE, lbnb[5].rank, 5006, MPI_COMM_WORLD, &request[3]);
    }

    for (i = 0; i < 2; i++) {
      #pragma omp master
      {
        MPI_Waitany(2, &request[0], &indx, MPI_STATUS_IGNORE);
      }
      #pragma omp barrier

      ptr_start = &lbinterforce[lbnb[4+1-indx].frpos];

      #pragma omp for collapse(2)
      for (xblock = 0; xblock < Xouter; xblock++) {
        for (yblock = 0; yblock < Youter; yblock++) {
 	      counter = 3 * (xblock * Youter + yblock) * mult;
          for (k = 0; k < 3*lbdm.bwid*mult; k++)
	        ptr_start[k +  Zouter * counter] = ptr_rcv[indx][counter + k];
        }
      }
    }
  }
  MPI_Waitall(2, &request[2], MPI_STATUSES_IGNORE);

#else
  MPI_Status status[4];

  MPI_Isend(&lbinterforce[lbnb[4].fspos], 1, lbfmsg3z, lbnb[4].rank, 
	    5005, MPI_COMM_WORLD, &request[0]);
  MPI_Irecv(&lbinterforce[lbnb[5].frpos], 1, lbfmsg3z, lbnb[5].rank, 
	    5005, MPI_COMM_WORLD, &request[1]);
  MPI_Isend(&lbinterforce[lbnb[5].fspos], 1, lbfmsg3z, lbnb[5].rank, 
	    5006, MPI_COMM_WORLD, &request[2]);
  MPI_Irecv(&lbinterforce[lbnb[4].frpos], 1, lbfmsg3z, lbnb[4].rank, 
	    5006, MPI_COMM_WORLD, &request[3]);
  MPI_Waitall(4, request, status);
#endif
  return 0;
}

int fForceNonBlockComm3D()
{

  // pass interaction force information for 3D system in unblocked call

  fForceNonBlockComm3DX();
  fForceNonBlockComm3DY();
  fForceNonBlockComm3DZ();
  return 0; 
}

int fForceNonBlockCommunication()
{

  // pass interaction force information for either 2D or 3D system in unblocked call

  if(lbsy.nd == 2)
    fForceNonBlockComm2D();
  else
    fForceNonBlockComm3D();
  return 0;
}


// Lishchuk phase indices

int fIndexNonBlockComm2DX()
{

  // pass two dimensional phase indices along x direction in unblocked call 
  
  MPI_Request request[4];
#ifdef Packbuf
  int pairs = (interact==20)?(4*lbsy.nf):(3*lbsy.nf*(lbsy.nf-1)/2);
  double *ptr_start;
  double *ptr_rcv[2];
  int indx, block, i, j, kmax, counter;

  MPI_Irecv(recvbuf_1_x,lbdm.bwid*lbdm.yinner*pairs,MPI_DOUBLE,lbnb[1].rank, 5001, MPI_COMM_WORLD, &request[0]);
  MPI_Irecv(recvbuf_0_x,lbdm.bwid*lbdm.yinner*pairs,MPI_DOUBLE,lbnb[0].rank, 5002, MPI_COMM_WORLD, &request[1]);

  ptr_rcv[0] = recvbuf_1_x;
  ptr_rcv[1] = recvbuf_0_x;

  #pragma omp parallel private(block,i,j,counter,ptr_start)
  {
    ptr_start = &lbft[lbnb[0].ispos];
    for (j=0; j<lbdm.bwid; j++) {
      counter = j * lbdm.youter * pairs;
      #pragma omp for
      for (block = 0; block < lbdm.yinner*pairs; block++) {
        sendbuf_0_x[j*lbdm.yinner*pairs + block] = ptr_start[counter + block];
      }
    }
    #pragma omp barrier
    #pragma omp master
    {
      MPI_Isend(sendbuf_0_x,lbdm.bwid*lbdm.yinner*pairs,MPI_DOUBLE,lbnb[0].rank, 5001, MPI_COMM_WORLD, &request[2]);
    }
    ptr_start = &lbft[lbnb[1].ispos];
    for (j=0; j<lbdm.bwid; j++) {
      counter = j * lbdm.youter * pairs;
      #pragma omp for
      for (block = 0; block < lbdm.yinner*pairs; block++) {
        sendbuf_1_x[j*lbdm.yinner*pairs + block] = ptr_start[counter+block];
      }
    }
    #pragma omp barrier
    #pragma omp master
    {
      MPI_Isend(sendbuf_1_x,lbdm.bwid*lbdm.yinner*pairs,MPI_DOUBLE,lbnb[1].rank, 5002, MPI_COMM_WORLD, &request[3]);
    }
    for (i = 0; i < 2; i++) {
      #pragma omp master
      {
        MPI_Waitany(2, &request[0], &indx, MPI_STATUS_IGNORE);
      }
      #pragma omp barrier
      ptr_start = &lbft[lbnb[1-indx].irpos];
      for (j=0; j<lbdm.bwid; j++) {
        counter = j * lbdm.youter * pairs;
        #pragma omp for
        for (block = 0; block < lbdm.yinner*pairs; block++){
          ptr_start[counter+block] = ptr_rcv[indx][j*lbdm.yinner*pairs+block];
        }
      }
    }
  }
  MPI_Waitall(2, &request[2], MPI_STATUSES_IGNORE);

#else
  MPI_Status status[4];

  MPI_Isend(&lbft[lbnb[0].ispos], 1, lbimsg2x, lbnb[0].rank, 
	    5001, MPI_COMM_WORLD, &request[0]);
  MPI_Irecv(&lbft[lbnb[1].irpos], 1, lbimsg2x, lbnb[1].rank, 
	    5001, MPI_COMM_WORLD, &request[1]);
  MPI_Isend(&lbft[lbnb[1].ispos], 1, lbimsg2x, lbnb[1].rank, 
	    5002, MPI_COMM_WORLD, &request[2]);
  MPI_Irecv(&lbft[lbnb[0].irpos], 1, lbimsg2x, lbnb[0].rank, 
	    5002, MPI_COMM_WORLD, &request[3]);
  MPI_Waitall(4, request, status);
#endif
  return 0;
}


int fIndexNonBlockComm2DY()
{

  // pass two dimensional phase indices along y direction in unblocked call 

  MPI_Request request[4];

#ifdef Packbuf
  int pairs = (interact==20)?(4*lbsy.nf):(3*lbsy.nf*(lbsy.nf-1)/2);
  double *ptr_start;
  double *ptr_rcv[2];
  int indx, block, counter, i, j, k, kmax;
  int  ylth = lbdm.youter * pairs;
  MPI_Irecv(recvbuf_1_y,lbdm.xouter*lbdm.bwid*pairs,MPI_DOUBLE,lbnb[3].rank, 5003, MPI_COMM_WORLD, &request[0]);
  MPI_Irecv(recvbuf_0_y,lbdm.xouter*lbdm.bwid*pairs,MPI_DOUBLE,lbnb[2].rank, 5004, MPI_COMM_WORLD, &request[1]);

  ptr_rcv[0] = recvbuf_1_y;
  ptr_rcv[1] = recvbuf_0_y;

  #pragma omp parallel private(block,i,j,counter,ptr_start)
  {
    ptr_start = &lbft[lbnb[2].ispos];
    #pragma omp for
    for (block = 0; block < lbdm.xouter; block++) {
      for (j=0; j<lbdm.bwid*pairs; j++) {
        sendbuf_0_y[block*lbdm.bwid*pairs+j] =  ptr_start[block*ylth+j];
      }
    }
    #pragma omp barrier
    #pragma omp master
    {
      MPI_Isend(sendbuf_0_y,lbdm.xouter*lbdm.bwid*pairs, MPI_DOUBLE, lbnb[2].rank, 5003, MPI_COMM_WORLD, &request[2]);
    }

    ptr_start = &lbft[lbnb[3].ispos];
    #pragma omp for
    for (block = 0; block < lbdm.xouter; block++) {
      for (j=0; j<lbdm.bwid*pairs; j++) {
        sendbuf_1_y[block*lbdm.bwid*pairs+j] =  ptr_start[block*ylth+j];
      }
    }
    #pragma omp barrier
    #pragma omp master
    {
      MPI_Isend(sendbuf_1_y,lbdm.xouter*lbdm.bwid*pairs, MPI_DOUBLE, lbnb[3].rank, 5004, MPI_COMM_WORLD, &request[3]);
    }

    for (i = 0; i < 2; ++i) {
      #pragma omp master
      {
        MPI_Waitany(2, &request[0], &indx, MPI_STATUS_IGNORE);
      }
      #pragma omp barrier
      ptr_start = &lbft[lbnb[2+1-indx].irpos];
      #pragma omp for
      for (block = 0; block < lbdm.xouter; block++) {
        for (j=0; j<lbdm.bwid*pairs; j++) {
          ptr_start[block*ylth+j] = ptr_rcv[indx][block*lbdm.bwid*pairs+j];
        }
      }
    }
  }

  MPI_Waitall(2, &request[2], MPI_STATUSES_IGNORE);

#else
  MPI_Status status[4];

  MPI_Isend(&lbft[lbnb[2].ispos], 1, lbimsg2y, lbnb[2].rank, 
	    5003, MPI_COMM_WORLD, &request[0]);
  MPI_Irecv(&lbft[lbnb[3].irpos], 1, lbimsg2y, lbnb[3].rank, 
	    5003, MPI_COMM_WORLD, &request[1]);
  MPI_Isend(&lbft[lbnb[3].ispos], 1, lbimsg2y, lbnb[3].rank, 
	    5004, MPI_COMM_WORLD, &request[2]);
  MPI_Irecv(&lbft[lbnb[2].irpos], 1, lbimsg2y, lbnb[2].rank, 
	    5004, MPI_COMM_WORLD, &request[3]);
  MPI_Waitall(4, request, status);
#endif
  return 0;
}


int fIndexNonBlockComm2D()
{

  // pass interaction force information for 2D system in unblocked call

  fIndexNonBlockComm2DX();
  fIndexNonBlockComm2DY();
  return 0; 
}

int fIndexNonBlockComm3DX()
{

  // pass three dimensional phase indices along x direction in unblocked call

  MPI_Request request[4];

#ifdef Packbuf
  int pairs = (interact==20)?(4*lbsy.nf):(3*lbsy.nf*(lbsy.nf-1)/2);
  double *ptr_start;
  double *ptr_rcv[2];
  int block_distance = pairs * lbdm.zouter;
  int indx, block, i, j, k, kmax, counter;

  MPI_Irecv(recvbuf_1_x,lbdm.bwid*lbdm.yinner*lbdm.zinner*pairs,MPI_DOUBLE,lbnb[1].rank, 5001, MPI_COMM_WORLD, &request[0]);
  MPI_Irecv(recvbuf_0_x,lbdm.bwid*lbdm.yinner*lbdm.zinner*pairs,MPI_DOUBLE,lbnb[0].rank, 5002, MPI_COMM_WORLD, &request[1]);

  kmax = lbdm.zinner * pairs;
  ptr_rcv[0] = recvbuf_1_x;
  ptr_rcv[1] = recvbuf_0_x;

  #pragma omp parallel private(block,i,j,k,counter,ptr_start)
  {
    ptr_start = &lbft[lbnb[0].ispos];
    for (j=0; j<lbdm.bwid; j++) {
      counter = j * lbdm.youter * block_distance;
      #pragma omp for
      for (block = 0; block < lbdm.yinner; block++){
        for (k = 0; k < kmax; k++){
          sendbuf_0_x[j*lbdm.yinner*kmax + block*kmax + k] = ptr_start[counter + block*block_distance + k];
        }
      }
    }
    #pragma omp barrier
    #pragma omp master
    {
      MPI_Isend(sendbuf_0_x,lbdm.bwid*lbdm.yinner*lbdm.zinner*pairs,MPI_DOUBLE,lbnb[0].rank, 5001, MPI_COMM_WORLD, &request[2]);
    }
    ptr_start = &lbft[lbnb[1].ispos];
    for (j=0; j<lbdm.bwid; j++) {
      counter = j * lbdm.youter * block_distance;
      #pragma omp for
      for (block = 0; block < lbdm.yinner; block++){
        for (k = 0; k < kmax; k++){
          sendbuf_1_x[j*lbdm.yinner*kmax + block*kmax + k] = ptr_start[counter+block*block_distance + k];
        }
      }
    }
    #pragma omp barrier
    #pragma omp master
    {
      MPI_Isend(sendbuf_1_x,lbdm.bwid*lbdm.yinner*lbdm.zinner*pairs,MPI_DOUBLE,lbnb[1].rank, 5002, MPI_COMM_WORLD, &request[3]);
    }
    for (i = 0; i < 2; i++) {
      #pragma omp master
      {
        MPI_Waitany(2, &request[0], &indx, MPI_STATUS_IGNORE);
      }
      #pragma omp barrier
      ptr_start = &lbft[lbnb[1-indx].irpos];
      for (j=0; j<lbdm.bwid; j++) {
        counter = j * lbdm.youter * block_distance;
        #pragma omp for
        for (block = 0; block < lbdm.yinner; block++){
          for (k = 0; k < kmax; k++) {
            ptr_start[counter+block*block_distance + k] = ptr_rcv[indx][j*lbdm.yinner*kmax+block*kmax+k];
          }
        }
      }
    }
  }
  MPI_Waitall(2, &request[2], MPI_STATUSES_IGNORE);

#else
  MPI_Status status[4];

  MPI_Isend(&lbft[lbnb[0].ispos], 1, lbimsg3x, lbnb[0].rank, 
	    5001, MPI_COMM_WORLD, &request[0]);
  MPI_Irecv(&lbft[lbnb[1].irpos], 1, lbimsg3x, lbnb[1].rank, 
	    5001, MPI_COMM_WORLD, &request[1]);
  MPI_Isend(&lbft[lbnb[1].ispos], 1, lbimsg3x, lbnb[1].rank, 
	    5002, MPI_COMM_WORLD, &request[2]);
  MPI_Irecv(&lbft[lbnb[0].irpos], 1, lbimsg3x, lbnb[0].rank, 
	    5002, MPI_COMM_WORLD, &request[3]);
  MPI_Waitall(4, request, status);
#endif
  return 0;
}


int fIndexNonBlockComm3DY()
{

  // pass three dimensional phase indices along y direction in unblocked call

  MPI_Request request[4];

#ifdef Packbuf
  int pairs = (interact==20)?(4*lbsy.nf):(3*lbsy.nf*(lbsy.nf-1)/2);
  double *ptr_start;
  double *ptr_rcv[2];
  int indx, block, counter, i, j, k, kmax;
  int  ylth = lbdm.youter * lbdm.zouter * pairs;
    
  MPI_Irecv(recvbuf_1_y,lbdm.xouter*lbdm.bwid*lbdm.zinner*pairs,MPI_DOUBLE,lbnb[3].rank, 5003, MPI_COMM_WORLD, &request[0]);
  MPI_Irecv(recvbuf_0_y,lbdm.xouter*lbdm.bwid*lbdm.zinner*pairs,MPI_DOUBLE,lbnb[2].rank, 5004, MPI_COMM_WORLD, &request[1]);

  kmax = lbdm.zinner * pairs;
  ptr_rcv[0] = recvbuf_1_y;
  ptr_rcv[1] = recvbuf_0_y;

  #pragma omp parallel private(block,i,j,k,counter,ptr_start)
  {
    ptr_start = &lbft[lbnb[2].ispos];
    #pragma omp for
    for (block = 0; block < lbdm.xouter; block++) {
      for (j=0; j<lbdm.bwid; j++) {
        counter = j * lbdm.zouter * pairs;
        for (k = 0; k < kmax; k++) {
          sendbuf_0_y[block*lbdm.bwid*kmax+j*kmax+k] =  ptr_start[block*ylth+counter+k];
        }
      }
    }
    #pragma omp barrier
    #pragma omp master
    {
      MPI_Isend(sendbuf_0_y,lbdm.xouter*lbdm.bwid*lbdm.zinner*pairs, MPI_DOUBLE, lbnb[2].rank, 5003, MPI_COMM_WORLD, &request[2]);
    }

    ptr_start = &lbft[lbnb[3].ispos];
    #pragma omp for
    for (block = 0; block < lbdm.xouter; block++) {
      for (j=0; j<lbdm.bwid; j++) {
        counter = j * lbdm.zouter * pairs;
        for (k = 0; k < kmax; k++) {
          sendbuf_1_y[block*lbdm.bwid*kmax+j*kmax+k] =  ptr_start[block*ylth+counter+k];
        }
      }
    }
    #pragma omp barrier
    #pragma omp master
    {
      MPI_Isend(sendbuf_1_y,lbdm.xouter*lbdm.bwid*lbdm.zinner*pairs, MPI_DOUBLE, lbnb[3].rank, 5004, MPI_COMM_WORLD, &request[3]);
    }

    for (i = 0; i < 2; ++i) {
      #pragma omp master
      {
        MPI_Waitany(2, &request[0], &indx, MPI_STATUS_IGNORE);
      }
      #pragma omp barrier
      ptr_start = &lbft[lbnb[2+1-indx].irpos];
      #pragma omp for
      for (block = 0; block < lbdm.xouter; block++) {
        for (j=0; j<lbdm.bwid; j++) {
          counter = j * lbdm.zouter * pairs;
          for (k = 0; k < kmax; k++) {
            ptr_start[block*ylth+counter+k] = ptr_rcv[indx][block*lbdm.bwid*kmax+j*kmax+k];
          }
        }
      }
    }
  }

  MPI_Waitall(2, &request[2], MPI_STATUSES_IGNORE);

#else
  MPI_Status status[4];

  MPI_Isend(&lbft[lbnb[2].ispos], 1, lbimsg3y, lbnb[2].rank, 
	    5003, MPI_COMM_WORLD, &request[0]);
  MPI_Irecv(&lbft[lbnb[3].irpos], 1, lbimsg3y, lbnb[3].rank, 
	    5003, MPI_COMM_WORLD, &request[1]);
  MPI_Isend(&lbft[lbnb[3].ispos], 1, lbimsg3y, lbnb[3].rank, 
	    5004, MPI_COMM_WORLD, &request[2]);
  MPI_Irecv(&lbft[lbnb[2].irpos], 1, lbimsg3y, lbnb[2].rank, 
	    5004, MPI_COMM_WORLD, &request[3]);
  MPI_Waitall(4, request, status);
#endif
  return 0;
}


int fIndexNonBlockComm3DZ()
{

  // pass three dimensional phase indices along z direction in unblocked call

  MPI_Request request[4];
    
#ifdef Packbuf
  int pairs = (interact==20)?(4*lbsy.nf):(3*lbsy.nf*(lbsy.nf-1)/2);
  int ylth = lbdm.youter * lbdm.xouter * pairs;
  int i, k, indx, block, xblock, yblock, counter;
  int Xouter = lbdm.xouter;
  int Youter = lbdm.youter;
  int Zouter = lbdm.zouter;
  int message_size = ylth * lbdm.bwid;
  double *ptr_start;
  double *ptr_rcv[2];
    
  MPI_Irecv(recvbuf_1_z,message_size,MPI_DOUBLE,lbnb[5].rank, 5005, MPI_COMM_WORLD, &request[0]);
  MPI_Irecv(recvbuf_0_z,message_size,MPI_DOUBLE,lbnb[4].rank, 5006, MPI_COMM_WORLD, &request[1]);

  ptr_rcv[0] = recvbuf_1_z;
  ptr_rcv[1] = recvbuf_0_z;

  #pragma omp parallel private(xblock,yblock,k,i,counter,ptr_start)
  {
    ptr_start = &lbft[lbnb[4].ispos];
    #pragma omp for collapse(2)
    for (xblock = 0; xblock < Xouter; xblock++) {
      for (yblock = 0; yblock < Youter; yblock++) {
        counter = pairs * (xblock * Youter + yblock);
        for (k = 0; k < lbdm.bwid*pairs; k++)
          sendbuf_0_z[counter + k] = ptr_start[k +  Zouter * counter];
      }
    }
    #pragma omp barrier
    #pragma omp master
    {
      MPI_Isend(sendbuf_0_z, message_size, MPI_DOUBLE, lbnb[4].rank, 5005, MPI_COMM_WORLD, &request[2]);
    }

    ptr_start = &lbft[lbnb[5].ispos];
    #pragma omp for collapse(2)
    for (xblock = 0; xblock < Xouter; xblock++) {
      for (yblock = 0; yblock < Youter; yblock++) {
        counter = pairs * (xblock * Youter + yblock);
        for (k = 0; k < lbdm.bwid*pairs; k++)
	      sendbuf_1_z[counter + k] = ptr_start[k +  Zouter * counter];
      }
    }

    #pragma omp barrier
    #pragma omp master
    {
      MPI_Isend(sendbuf_1_z, message_size, MPI_DOUBLE, lbnb[5].rank, 5006, MPI_COMM_WORLD, &request[3]);
    }

    for (i = 0; i < 2; i++) {
      #pragma omp master
      {
        MPI_Waitany(2, &request[0], &indx, MPI_STATUS_IGNORE);
      }
      #pragma omp barrier

      ptr_start = &lbft[lbnb[4+1-indx].irpos];

      #pragma omp for collapse(2)
      for (xblock = 0; xblock < Xouter; xblock++) {
        for (yblock = 0; yblock < Youter; yblock++) {
 	      counter = pairs * (xblock * Youter + yblock);
          for (k = 0; k < lbdm.bwid*pairs; k++)
	        ptr_start[k +  Zouter * counter] = ptr_rcv[indx][counter + k];
        }
      }
    }
  }
  MPI_Waitall(2, &request[2], MPI_STATUSES_IGNORE);

#else
  MPI_Status status[4];

  MPI_Isend(&lbft[lbnb[4].ispos], 1, lbimsg3z, lbnb[4].rank, 
	    5005, MPI_COMM_WORLD, &request[0]);
  MPI_Irecv(&lbft[lbnb[5].irpos], 1, lbimsg3z, lbnb[5].rank, 
	    5005, MPI_COMM_WORLD, &request[1]);
  MPI_Isend(&lbft[lbnb[5].ispos], 1, lbimsg3z, lbnb[5].rank, 
	    5006, MPI_COMM_WORLD, &request[2]);
  MPI_Irecv(&lbft[lbnb[4].irpos], 1, lbimsg3z, lbnb[4].rank, 
	    5006, MPI_COMM_WORLD, &request[3]);
  MPI_Waitall(4, request, status);
#endif
  return 0;
}

int fIndexNonBlockComm3D()
{

  // pass phase index information for 3D system in unblocked call

  fIndexNonBlockComm3DX();
  fIndexNonBlockComm3DY();
  fIndexNonBlockComm3DZ();
  return 0; 
}

int fIndexNonBlockCommunication()
{

  // pass phase index information for either 2D or 3D system in unblocked call

  if(lbsy.nd == 2)
    fIndexNonBlockComm2D();
  else
    fIndexNonBlockComm3D();
  return 0;
}


int fPrintSystemMass()
{

  // display masses of individual and all fluids in system
  double totmass[lbsy.nf+1];
  if(interact==20) {
    totmass[0]=fGetOneMassDomain(0);
    for(int i=0; i<lbsy.nf; i++)
      totmass[i+1]=fGetOneMassSwiftDomain(i);
  }
  else {
    totmass[0]=fGetTotMassDomain();
    for(int i=0; i<lbsy.nf; i++)
      totmass[i+1]=fGetOneMassDomain(i);
  }
    
  fGlobalValue(totmass, lbsy.nf+1);

  if(lbdm.rank == 0) {
    cout<<"MASS: "<<"total = "<<totmass[0];
    for(int i=0; i<lbsy.nf; i++)
      cout<<", fluid "<<i<<" = "<<totmass[i+1];
    cout<<endl;
  }
  return 0;
}


int fPrintSystemMomentum()
{

  // display total fluid momentum in system

  double mome[3];
  if(interact==6)
    fGetTotMomentSwiftDomain(mome);
  else
    fGetTotMomentDomain(mome);
    
  fGlobalValue(mome, 3);
  if(lbdm.rank==0) {
    cout<<"MOMENTUM: "<<"x: "<<mome[0]<<", y: "<<mome[1];
    if(lbsy.nd == 3)
      cout<<", z: "<<mome[2];
    cout<<endl;
  }
  return 0;  
}
