import javax.swing.*;
import java.util.*;
import java.lang.*;
import java.io.*;
import java.awt.*;
import java.awt.event.*;
import java.awt.geom.*;
import java.awt.image.*;
/*
 *     DL_MESO_GUI
 *     author: R. S. Qin, M. A. Seaton
 *     copyright: UKRI STFC Daresbury Laboratory and CCP5
 *     2005, 2018
 */
class setFluidForce extends JFrame {
    
    setlbeSysEvt forinilbe=new setlbeSysEvt(this);

    JLabel fxlabel = new JLabel("body force x-axis:", JLabel.RIGHT);
    JTextField[] xforce = new JTextField[6];

    JLabel fylabel = new JLabel("body force y-axis:", JLabel.RIGHT);
    JTextField[] yforce = new JTextField[6];

    JLabel fzlabel = new JLabel("body force z-axis:", JLabel.RIGHT);
    JTextField[] zforce = new JTextField[6];

    JLabel oscfxlabel = new JLabel("oscillating force x-axis:", JLabel.RIGHT);
    JTextField[] oscxforce = new JTextField[6];

    JLabel oscfylabel = new JLabel("oscillating force y-axis:", JLabel.RIGHT);
    JTextField[] oscyforce = new JTextField[6];

    JLabel oscfzlabel = new JLabel("oscillating force z-axis:", JLabel.RIGHT);
    JTextField[] osczforce = new JTextField[6];

    JComboBox<String> oscilfrp = new JComboBox<String>();
    JTextField oscilfp = new JTextField("1.0",5);
    
    JLabel bousfxlabel = new JLabel("boussinesq force x-axis:", JLabel.RIGHT);
    JTextField[] bousxforce = new JTextField[6];

    JLabel bousfylabel = new JLabel("boussinesq force y-axis:", JLabel.RIGHT);
    JTextField[] bousyforce = new JTextField[6];

    JLabel bousfzlabel = new JLabel("boussinesq force z-axis:", JLabel.RIGHT);
    JTextField[] bouszforce = new JTextField[6];

    JButton save = new JButton("SAVE FR");
    JButton close = new JButton("CANCEL FR");
    Font font=new Font("Dialog", Font.BOLD, 13);
    
    public setFluidForce(int totf, int dim, int coll, double[] bdf, double[] oscf, double[] bousf, double oscfrpe, int fp) {

        super("LBE fluid forces");
        
        setBounds(160, 10, 220+81*totf, 692+54*totf);
//        int width = 2+totf+((coll>7 && coll<12)?3:0);
        JPanel pane=new JPanel(new GridBagLayout());

        for(int i=0; i<totf; i++) {
            addItem(pane, new JLabel("fluid "+i), i+2, 0, 1, 1, GridBagConstraints.CENTER);
        }

        fxlabel.setFont(font);
        addItem(pane, fxlabel, 0, 1, 2, 1, GridBagConstraints.WEST);
        for(int i=0; i<totf; i++) {
            xforce[i]=new JTextField(5);
            xforce[i].setText(Double.toString(bdf[i*3]));
            addItem(pane, xforce[i], i+2, 1, 1, 1, GridBagConstraints.CENTER);
        }
	
        fylabel.setFont(font);
        addItem(pane, fylabel, 0, 2, 2, 1, GridBagConstraints.WEST);
        for(int i=0; i<totf; i++) {
            yforce[i]=new JTextField(5);
            yforce[i].setText(Double.toString(bdf[i*3+1]));
            addItem(pane, yforce[i], i+2, 2, 1, 1, GridBagConstraints.CENTER);
        }
	
        fzlabel.setFont(font);
        if (dim==2)
          fzlabel.setEnabled(false);
        addItem(pane, fzlabel, 0, 3, 2, 1, GridBagConstraints.WEST);
        for(int i=0; i<totf; i++) {
            zforce[i]=new JTextField(5);
            zforce[i].setText(Double.toString(bdf[i*3+2]));
            if (dim==2) {
              zforce[i].setEditable(false);
              zforce[i].setEnabled(false);
            }
            addItem(pane, zforce[i], i+2, 3, 1, 1, GridBagConstraints.CENTER);
        }

        oscfxlabel.setFont(font);
        addItem(pane, oscfxlabel, 0, 4, 2, 1, GridBagConstraints.WEST);
        for(int i=0; i<totf; i++) {
            oscxforce[i]=new JTextField(5);
            oscxforce[i].setText(Double.toString(oscf[i*3]));
            addItem(pane, oscxforce[i], i+2, 4, 1, 1, GridBagConstraints.CENTER);
        }
	
        oscfylabel.setFont(font);
        addItem(pane, oscfylabel, 0, 5, 2, 1, GridBagConstraints.WEST);
        for(int i=0; i<totf; i++) {
            oscyforce[i]=new JTextField(5);
            oscyforce[i].setText(Double.toString(oscf[i*3+1]));
            addItem(pane, oscyforce[i], i+2, 5, 1, 1, GridBagConstraints.CENTER);
        }
	
        oscfzlabel.setFont(font);
        if (dim==2)
          oscfzlabel.setEnabled(false);
        addItem(pane, oscfzlabel, 0, 6, 2, 1, GridBagConstraints.WEST);
        for(int i=0; i<totf; i++) {
            osczforce[i]=new JTextField(5);
            osczforce[i].setText(Double.toString(oscf[i*3+2]));
            if (dim==2) {
              osczforce[i].setEditable(false);
              osczforce[i].setEnabled(false);
            }
            addItem(pane, osczforce[i], i+2, 6, 1, 1, GridBagConstraints.CENTER);
        }

        oscilfrp.addItem("oscillation frequency");
        oscilfrp.addItem("oscillation period");
        oscilfrp.setSelectedIndex(fp);
        addItem(pane, oscilfrp, 0, 7, 2, 1, GridBagConstraints.WEST);
        oscilfp.setText(Double.toString(oscfrpe));
        addItem(pane, oscilfp, 2, 7, 1, 1, GridBagConstraints.CENTER);
        
        bousfxlabel.setFont(font);
        addItem(pane, bousfxlabel, 0, 8, 2, 1, GridBagConstraints.WEST);
        for(int i=0; i<totf; i++) {
            bousxforce[i]=new JTextField(5);
            bousxforce[i].setText(Double.toString(bousf[i*3]));
            addItem(pane, bousxforce[i], i+2, 8, 1, 1, GridBagConstraints.CENTER);
        }
	
        bousfylabel.setFont(font);
        addItem(pane, bousfylabel, 0, 9, 2, 1, GridBagConstraints.WEST);
        for(int i=0; i<totf; i++) {
            bousyforce[i]=new JTextField(5);
            bousyforce[i].setText(Double.toString(bousf[i*3+1]));
            addItem(pane, bousyforce[i], i+2, 9, 1, 1, GridBagConstraints.CENTER);
        }
	
        bousfzlabel.setFont(font);
        if (dim==2)
          bousfzlabel.setEnabled(false);
        addItem(pane, bousfzlabel, 0, 10, 2, 1, GridBagConstraints.WEST);
        for(int i=0; i<totf; i++) {
            bouszforce[i]=new JTextField(5);
            bouszforce[i].setText(Double.toString(bousf[i*3+2]));
            if (dim==2) {
              bouszforce[i].setEditable(false);
              bouszforce[i].setEnabled(false);
            }
            addItem(pane, bouszforce[i], i+2, 10, 1, 1, GridBagConstraints.CENTER);
        }


        Box buttonBox = Box.createHorizontalBox();
        save.setFont(font);
        save.addActionListener(forinilbe);
        buttonBox.add(save);
        close.setFont(font);
        close.addActionListener(forinilbe);
        buttonBox.add(close);
        addItem(pane, buttonBox, 0, 11, 2+totf, 1, GridBagConstraints.WEST);

        this.add(pane);
        this.pack();
        setVisible(true);
    }

    private void addItem(JPanel p, JComponent c, int x, int y, int width, int height, int align)
    {
        GridBagConstraints gc = new GridBagConstraints();
        gc.gridx = x;
        gc.gridy = y;
        gc.gridwidth = width;
        gc.gridheight = height;
        gc.weightx = 100.0;
        gc.weighty = 100.0;
        gc.insets = new Insets(5, 5, 5, 5);
        gc.anchor = align;
        gc.fill = GridBagConstraints.NONE;
        p.add(c, gc);
    }

}
