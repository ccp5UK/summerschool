import javax.swing.*;
import java.util.*;
import java.lang.*;
import java.io.*;
import java.awt.*;
import java.awt.event.*;
import java.awt.geom.*;
import java.awt.image.*;
/*
 *     DL_MESO_GUI
 *     author: R. S. Qin, M. A. Seaton
 *     copyright: UKRI STFC Daresbury Laboratory and CCP5
 *     2005, 2018
 */
class setExternal extends JFrame {

    setdpdInteractEvt exterdpd=new setdpdInteractEvt(this);
    Font font=new Font("Dialog", Font.BOLD, 13);

    JLabel inttype = new JLabel("EXTERNAL FIELD TYPE", JLabel.RIGHT);
    JLabel aexlabel = new JLabel("external parameter a:", JLabel.RIGHT);
    JLabel bexlabel = new JLabel("external parameter b:", JLabel.RIGHT);
    JLabel cexlabel = new JLabel("external parameter c:", JLabel.RIGHT);
    JTextField aex = new JTextField("0.0", 7);
    JTextField bex = new JTextField("0.0", 7);
    JTextField cex = new JTextField("0.0", 7);

    JButton save = new JButton("SAVE E");
    JButton close = new JButton("CANCEL E");
    
    public setExternal(int et, double ex, double ey, double ez) {
	super("DPD external field properties");
	setBounds(170, 120, 320, 200);
	JPanel pane=new JPanel(new GridBagLayout());

        if (et==1) { 
           inttype.setText("GRAVITATIONAL FIELD");
           aexlabel.setText("acceleration x-component:");
           bexlabel.setText("acceleration y-component:");
           cexlabel.setText("acceleration z-component:");
           aexlabel.setFont(font);
           bexlabel.setFont(font);
           cexlabel.setFont(font);
           addItem(pane, aexlabel, 0, 1, 1, 1, GridBagConstraints.WEST);
           addItem(pane, bexlabel, 0, 2, 1, 1, GridBagConstraints.WEST);
           addItem(pane, cexlabel, 0, 3, 1, 1, GridBagConstraints.WEST);
           addItem(pane, aex, 1, 1, 1, 1, GridBagConstraints.WEST);
           addItem(pane, bex, 1, 2, 1, 1, GridBagConstraints.WEST);
           addItem(pane, cex, 1, 3, 1, 1, GridBagConstraints.WEST);
        }
        else if (et==2) { 
           inttype.setText("CONTINUOUS LINEAR SHEAR");
           aexlabel.setText("boundary velocity x-component:");
           bexlabel.setText("boundary velocity y-component:");
           cexlabel.setText("boundary velocity z-component:");
           aexlabel.setFont(font);
           bexlabel.setFont(font);
           cexlabel.setFont(font);
           addItem(pane, aexlabel, 0, 1, 1, 1, GridBagConstraints.WEST);
           addItem(pane, bexlabel, 0, 2, 1, 1, GridBagConstraints.WEST);
           addItem(pane, cexlabel, 0, 3, 1, 1, GridBagConstraints.WEST);
           addItem(pane, aex, 1, 1, 1, 1, GridBagConstraints.WEST);
           addItem(pane, bex, 1, 2, 1, 1, GridBagConstraints.WEST);
           addItem(pane, cex, 1, 3, 1, 1, GridBagConstraints.WEST);
        }
        else if (et==3) {
           inttype.setText("CONSTANT ELECTRIC FIELD");
           aexlabel.setText("electric field x-component:");
           bexlabel.setText("electric field y-component:");
           cexlabel.setText("electric field z-component:");
           aexlabel.setFont(font);
           bexlabel.setFont(font);
           cexlabel.setFont(font);
           addItem(pane, aexlabel, 0, 1, 1, 1, GridBagConstraints.WEST);
           addItem(pane, bexlabel, 0, 2, 1, 1, GridBagConstraints.WEST);
           addItem(pane, cexlabel, 0, 3, 1, 1, GridBagConstraints.WEST);
           addItem(pane, aex, 1, 1, 1, 1, GridBagConstraints.WEST);
           addItem(pane, bex, 1, 2, 1, 1, GridBagConstraints.WEST);
           addItem(pane, cex, 1, 3, 1, 1, GridBagConstraints.WEST);
        }

        inttype.setFont(font);
        addItem(pane, inttype, 0, 0, 2, 1, GridBagConstraints.WEST);

        aex.setText(Double.toString(ex));
        bex.setText(Double.toString(ey));
        cex.setText(Double.toString(ez));
        
        Box buttonBox = Box.createHorizontalBox();
        save.setFont(font);
        save.addActionListener(exterdpd);
        buttonBox.add(save);
        close.setFont(font);
        close.addActionListener(exterdpd);
        buttonBox.add(close);
        addItem(pane, buttonBox, 0, 5, 2, 1, GridBagConstraints.WEST);

        this.add(pane);
        this.pack();
        setVisible(true);
    }

    private void addItem(JPanel p, JComponent c, int x, int y, int width, int height, int align)
    {
        GridBagConstraints gc = new GridBagConstraints();
        gc.gridx = x;
        gc.gridy = y;
        gc.gridwidth = width;
        gc.gridheight = height;
        gc.weightx = 100.0;
        gc.weighty = 100.0;
        gc.insets = new Insets(5, 5, 5, 5);
        gc.anchor = align;
        gc.fill = GridBagConstraints.NONE;
        p.add(c, gc);
    }

}
