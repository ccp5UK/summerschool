import javax.swing.*;
import java.util.*;
import java.lang.*;
import java.io.*;
import java.awt.*;
import java.awt.event.*;
import java.awt.geom.*;
import java.awt.image.*;
/*
 *     DL_MESO_GUI
 *     author: W. Smith, R. S. Qin & M. A. Seaton 2006, 2018
 *     copyright: UKRI STFC Daresbury Laboratory and CCP5
 */
class setdpdSysEvt implements ItemListener, ActionListener {
    
    static setdpdSys inidpd;
    setThermostat tg;
    setBarostat bg;
    setElectrostatic eg;
    setSurface sfg;
    FileWriter fw;
    BufferedReader in;
    String filename="CONTROL", str;
    int xint;
    double xdouble;
    dpdsysdim dim = new dpdsysdim();
    static int kres, itype, btype, etype, converr, betalen, betalenrel, mxspl, permbjer;
    public static int srftype;
    public static boolean frzx, frzy, frzz;
    public static String name;
    static int srfx, srfy, srfz, kmax1, kmax2, kmax3;
    static int ii, jj, kk;
    static boolean cube=true, lisotrop=true, lgbnd, lnfold, lconf, lind, lomp, lgeq;
    static double atherm, abaro, bbaro, cbaro, aelec, belec, celec, walloff, vgapx, vgapy, vgapz;

    public setdpdSysEvt(setdpdSys ini) {
        atherm = 0.3;
        abaro = 2.0;
        bbaro = 5.0;
        cbaro = 0.0;
        aelec = 13.87;
        belec = 0.9695;
        celec = 0.929;
        kmax1 = 5;
        kmax2 = 5;
        kmax3 = 5;
        mxspl = 8;
        srfx = 0;
        srfy = 0;
        srfz = 0;
        kres=0;
        itype=0;
        btype=0;
        etype=0;
        converr=0;
        betalen=0;
        betalenrel=0;
        permbjer=0;
        srftype=0;
        walloff=0.0;
        vgapx=0.0;
        vgapy=0.0;
        vgapz=0.0;
        inidpd=ini;
        lnfold=false;
        lconf=false;
        lgeq=false;
        lomp=false;
        frzx=false;
        frzy=false;
        frzz=false;
    }

    public setdpdSysEvt(setThermostat theini) {
        tg=theini;
    }

    public setdpdSysEvt(setBarostat barini) {
        bg=barini;
    }

    public setdpdSysEvt(setElectrostatic eleini) {
        eg=eleini;
    }

    public setdpdSysEvt(setSurface surini) {
        sfg=surini;
    }

    public void actionPerformed(ActionEvent event) {
        String cmd =event.getActionCommand();

        if (cmd == "set thermostat") {
            try {
                setthermostatparameter(itype,atherm);
            } catch  (NumberFormatException e) {
                ierr(" expecting an integer number ");
            }
        }
        else if (cmd == "set barostat") {
            try {
                setbarostatparameter(btype,abaro,bbaro,cbaro,lisotrop);
            } catch  (NumberFormatException e) {
                ierr(" expecting an integer number ");
            }
        }
        else if (cmd == "set electrostatics") {
            try {
                setelectroparameter(etype,permbjer,converr,betalen,betalenrel,aelec,belec,celec,kmax1,kmax2,kmax3,mxspl,lgeq);
            } catch  (NumberFormatException e) {
                ierr(" expecting an integer number ");
            }
        }
        else if (cmd == "set surfaces") {
            try {
                setsurfaceparameter(srftype,srfx,srfy,srfz,walloff,vgapx,vgapy,vgapz);
            } catch  (NumberFormatException e) {
                ierr(" expecting an integer number ");
            }
        }
        else if (cmd == "OPEN") {
            opendpd();
        }
        else if (cmd == "SAVE") {
            savedpd();
        }
        else if (cmd == "SAVE T") {
            savethermo();
        }
        else if (cmd == "CANCEL T") {
            tg.dispose();
        }
        else if (cmd == "SAVE B") {
            savebaro();
        }
        else if (cmd == "CANCEL B") {
            bg.dispose();
        }
        else if (cmd == "SAVE E") {
            saveelectro();
        }
        else if (cmd == "CANCEL E") {
            eg.dispose();
        }
        else if (cmd == "SAVE SF") {
            savesurface();
        }
	    else if (cmd == "CANCEL SF") {
            sfg.dispose();
	    }

    }

    public void itemStateChanged(ItemEvent event) {
        Object item=event.getItem();
	    String answer=item.toString();
        if (answer == "cubic") {
          cube = true;
          lnfold = false;
          inidpd.label22x.setEnabled(false);
          inidpd.label22y.setEnabled(false);
          inidpd.label22z.setEnabled(false);
          inidpd.volume_y.setEditable(false);
          inidpd.volume_y.setEnabled(false);
          inidpd.volume_z.setEditable(false);
          inidpd.volume_z.setEnabled(false);
          inidpd.config.setEnabled(true);
        } 
        else if (answer == "orthorhombic") {
          cube = false;
          lnfold = false;
          inidpd.label22x.setEnabled(true);
          inidpd.label22y.setEnabled(true);
          inidpd.label22z.setEnabled(true);
          inidpd.volume_y.setEditable(true);
          inidpd.volume_y.setEnabled(true);
          inidpd.volume_z.setEditable(true);
          inidpd.volume_z.setEnabled(true);         
          inidpd.config.setEnabled(true);
        }
        else if (answer == "nfold") {
          cube = false;
          lnfold = true;
          inidpd.label22x.setEnabled(true);
          inidpd.label22y.setEnabled(true);
          inidpd.label22z.setEnabled(true);
          inidpd.volume_y.setEditable(true);
          inidpd.volume_y.setEnabled(true);
          inidpd.volume_z.setEditable(true);
          inidpd.volume_z.setEnabled(true);         
          inidpd.config.setEnabled(false);
        }
        else if (event.getSource() == inidpd.restart_key && answer == "none")
          kres = 0;
        else if (answer == "full restart")
          kres = 1;
        else if (answer == "new run")
          kres = 2;
        else if (answer == "rescaled")
          kres = 3;
        else if (answer == "DPD/MD-VV") {
          itype = 0;
          inidpd.setthermo.setEnabled(false);           
        }
        else if (answer == "DPD/DPD-VV") {
          itype = 1;
          inidpd.setthermo.setEnabled(false);           
        }
        else if (answer == "DPD/DPD-S1") {
          itype = 2;
          inidpd.setthermo.setEnabled(false);
        }
        else if (answer == "DPD/DPD-S2") {
          itype = 3;
          inidpd.setthermo.setEnabled(false);
        }
        else if (answer == "Lowe-Andersen") {
          itype = 4;
          inidpd.setthermo.setEnabled(false);           
        }
        else if (answer == "Peters") {
          itype = 5;
          inidpd.setthermo.setEnabled(false);           
        }
        else if (answer == "Stoyanov-Groot") {
          itype = 6;
          inidpd.setthermo.setEnabled(true);           
        }
        else if (event.getSource() == inidpd.barostat_key && answer == "none") {
          btype = 0;
          inidpd.label32.setEnabled(false);
          inidpd.sys_pressure.setEditable(false);
          inidpd.sys_pressure.setEnabled(false);
          inidpd.setbaro.setEnabled(false);
        }
        else if (answer == "Langevin NPT") {
          btype = 1;
          inidpd.label32.setEnabled(true);
          inidpd.sys_pressure.setEditable(true);
          inidpd.sys_pressure.setEnabled(true);
          inidpd.setbaro.setEnabled(true);
        }
        else if (answer == "Langevin NPAT") {
            btype = 2;
            inidpd.label32.setEnabled(true);
            inidpd.sys_pressure.setEditable(true);
            inidpd.sys_pressure.setEnabled(true);
            inidpd.setbaro.setEnabled(true);
        }
        else if (answer == "Langevin NsT") {
            btype = 3;
            inidpd.label32.setEnabled(true);
            inidpd.sys_pressure.setEditable(true);
            inidpd.sys_pressure.setEnabled(true);
            inidpd.setbaro.setEnabled(true);
        }
        else if (answer == "Berendsen NPT") {
          btype = 4;
          inidpd.label32.setEnabled(true);
          inidpd.sys_pressure.setEditable(true);
          inidpd.sys_pressure.setEnabled(true);
          inidpd.setbaro.setEnabled(true);
        }
        else if (answer == "Berendsen NPAT") {
            btype = 5;
            inidpd.label32.setEnabled(true);
            inidpd.sys_pressure.setEditable(true);
            inidpd.sys_pressure.setEnabled(true);
            inidpd.setbaro.setEnabled(true);
        }
        else if (answer == "Berendsen NsT") {
            btype = 6;
            inidpd.label32.setEnabled(true);
            inidpd.sys_pressure.setEditable(true);
            inidpd.sys_pressure.setEnabled(true);
            inidpd.setbaro.setEnabled(true);
        }
        else if (event.getSource() == inidpd.electrostatic_key && answer == "none") {
          etype = 0;
          inidpd.label51.setEnabled(false);
          inidpd.electrostatic_cutoff.setEditable(false);
          inidpd.electrostatic_cutoff.setEnabled(false);
          inidpd.setelectro.setEnabled(false);
        }
        else if (answer == "Ewald sum/no smearing") {
          etype = 1;
          inidpd.label51.setEnabled(true);
          inidpd.electrostatic_cutoff.setEditable(true);
          inidpd.electrostatic_cutoff.setEnabled(true);
          inidpd.setelectro.setEnabled(true);
        }
        else if (answer == "Ewald sum/linear smearing") {
          etype = 2;
          inidpd.label51.setEnabled(true);
          inidpd.electrostatic_cutoff.setEditable(true);
          inidpd.electrostatic_cutoff.setEnabled(true);
          inidpd.setelectro.setEnabled(true);
        }
        else if (answer == "Ewald sum/exact Slater smearing") {
          etype = 3;
          inidpd.label51.setEnabled(true);
          inidpd.electrostatic_cutoff.setEditable(true);
          inidpd.electrostatic_cutoff.setEnabled(true);
          inidpd.setelectro.setEnabled(true);
        }
        else if (answer == "Ewald sum/approx. Slater smearing") {
          etype = 4;
          inidpd.label51.setEnabled(true);
          inidpd.electrostatic_cutoff.setEditable(true);
          inidpd.electrostatic_cutoff.setEnabled(true);
          inidpd.setelectro.setEnabled(true);
        }
        else if (answer == "Ewald sum/Gauss smearing") {
          etype = 5;
          inidpd.label51.setEnabled(true);
          inidpd.electrostatic_cutoff.setEditable(true);
          inidpd.electrostatic_cutoff.setEnabled(true);
          inidpd.setelectro.setEnabled(true);
        }
        else if (answer == "Ewald sum/sinusoidal smearing") {
          etype = 6;
          inidpd.label51.setEnabled(true);
          inidpd.electrostatic_cutoff.setEditable(true);
          inidpd.electrostatic_cutoff.setEnabled(true);
          inidpd.setelectro.setEnabled(true);
        }
        else if (answer == "SPME/no smearing") {
          etype = 7;
          inidpd.label51.setEnabled(true);
          inidpd.electrostatic_cutoff.setEditable(true);
          inidpd.electrostatic_cutoff.setEnabled(true);
          inidpd.setelectro.setEnabled(true);
        }
        else if (answer == "SPME/linear smearing") {
          etype = 8;
          inidpd.label51.setEnabled(true);
          inidpd.electrostatic_cutoff.setEditable(true);
          inidpd.electrostatic_cutoff.setEnabled(true);
          inidpd.setelectro.setEnabled(true);
        }
        else if (answer == "SPME/exact Slater smearing") {
          etype = 9;
          inidpd.label51.setEnabled(true);
          inidpd.electrostatic_cutoff.setEditable(true);
          inidpd.electrostatic_cutoff.setEnabled(true);
          inidpd.setelectro.setEnabled(true);
        }
        else if (answer == "SPME/approx. Slater smearing") {
          etype = 10;
          inidpd.label51.setEnabled(true);
          inidpd.electrostatic_cutoff.setEditable(true);
          inidpd.electrostatic_cutoff.setEnabled(true);
          inidpd.setelectro.setEnabled(true);
        }
        else if (answer == "SPME/Gauss smearing") {
          etype = 11;
          inidpd.label51.setEnabled(true);
          inidpd.electrostatic_cutoff.setEditable(true);
          inidpd.electrostatic_cutoff.setEnabled(true);
          inidpd.setelectro.setEnabled(true);
        }
        else if (answer == "SPME/sinusoidal smearing") {
          etype = 12;
          inidpd.label51.setEnabled(true);
          inidpd.electrostatic_cutoff.setEditable(true);
          inidpd.electrostatic_cutoff.setEnabled(true);
          inidpd.setelectro.setEnabled(true);
        }
        else if (event.getSource() == inidpd.surface_key && answer == "none") {
          srftype = 0;
          inidpd.label52.setEnabled(false);
          inidpd.surface_cutoff.setEditable(false);
          inidpd.surface_cutoff.setEnabled(false);
          inidpd.setsurface.setEnabled(false);
        }
        else if (answer == "Lees-Edwards shear") {
          srftype = 1;
          inidpd.label52.setEnabled(false);
          inidpd.surface_cutoff.setEditable(false);
          inidpd.surface_cutoff.setEnabled(false);
          inidpd.setsurface.setEnabled(true);
        }
        else if (answer == "hard surfaces/specular") {
          srftype = 2;
          inidpd.label52.setEnabled(true);
          inidpd.surface_cutoff.setEditable(true);
          inidpd.surface_cutoff.setEnabled(true);
          inidpd.setsurface.setEnabled(true);
        }
        else if (answer == "hard surfaces/bounceback") {
          srftype = 3;
          inidpd.label52.setEnabled(true);
          inidpd.surface_cutoff.setEditable(true);
          inidpd.surface_cutoff.setEnabled(true);
          inidpd.setsurface.setEnabled(true);
        }
        else if (event.getSource() == inidpd.frzxwall) {
            frzx=inidpd.frzxwall.isSelected();
            if(frzx) {
              inidpd.setsurface.setEnabled(true);
            }
            else {
              inidpd.setsurface.setEnabled(false);
            }
        }
        else if (event.getSource() == inidpd.frzywall) {
            frzy=inidpd.frzywall.isSelected();
            if(frzy) {
              inidpd.setsurface.setEnabled(true);
            }
            else {
              inidpd.setsurface.setEnabled(false);
            }
        }
        else if (event.getSource() == inidpd.frzzwall) {
            frzz=inidpd.frzzwall.isSelected();
            if(frzz) {
              inidpd.setsurface.setEnabled(true);
            }
            else {
              inidpd.setsurface.setEnabled(false);
            }
        }
        else if (event.getSource() == inidpd.config) {
          lconf = inidpd.config.isSelected();
          if(lconf) {
            inidpd.index.setEnabled(false);
          }
          else {
            inidpd.index.setEnabled(true);
          }
        }
        else if (event.getSource() == eg.converror) {
            converr = eg.converror.getSelectedIndex();
            eg.kmaxlabel.setEnabled(converr==0);
            eg.kmax1.setEnabled(converr==0);
            eg.kmax2.setEnabled(converr==0);
            eg.kmax3.setEnabled(converr==0);
            eg.kmax1.setEditable(converr==0);
            eg.kmax2.setEditable(converr==0);
            eg.kmax3.setEditable(converr==0);
        }
        else if (event.getSource() == eg.gausseq) {
            lgeq=eg.gausseq.isSelected();
            if(lgeq) {
                celec=Double.parseDouble(eg.smearlen.getText());
                if(celec>1.0e-16 && converr==0) {
                  belec=1.0/celec;
                  eg.converr.setText(Double.toString(belec));
                }
            }
            
        }
    }

    void setthermostatparameter(int ityp,double at) {
      setThermostat st= new setThermostat(ityp,at);
    }

    void setbarostatparameter(int btyp,double ab,double bb,double cb,boolean iso) {
      setBarostat sb= new setBarostat(btyp,ab,bb,cb,iso);
    }

    void setelectroparameter(int etyp,int pb,int coe,int bl,int blrel,double ae,double be,double ce,int k1,int k2,int k3,int mxs,boolean ge) {
      setElectrostatic se= new setElectrostatic(etyp,pb,coe,bl,blrel,ae,be,ce,k1,k2,k3,mxs,ge);
    }

    void setsurfaceparameter(int sftyp,int sx,int sy,int sz,double woff, double vx, double vy, double vz) {
      setSurface ssf= new setSurface(sftyp,sx,sy,sz,woff,vx,vy,vz);
    }

    void savethermo() {
        int i, j, k;
        String str;
	try {
           xdouble=Double.parseDouble(tg.atherm.getText());
           atherm = xdouble;
           tg.dispose();
	} catch (NumberFormatException enfl) {
	    ierr(" thermostat parameter: format error or no value ");
        }
    }

    void savebaro() {
        int i, j, k;
        String str;
        try {
            lisotrop = bg.isotrop.isSelected();
            xdouble=Double.parseDouble(bg.abaro.getText());
            abaro = xdouble;
            xdouble=Double.parseDouble(bg.bbaro.getText());
            bbaro = xdouble;
            bg.dispose();
        } catch (NumberFormatException enfl) {
	    ierr(" barostat parameter: format error or no value ");
        }
    }

    void saveelectro() {
        int i, j, k;
        String str;
        try {
            xdouble=Double.parseDouble(eg.perm.getText());
            aelec = xdouble;
            xdouble=Double.parseDouble(eg.converr.getText());
            belec = xdouble;
            xdouble=Double.parseDouble(eg.smearlen.getText());
            celec = xdouble;
            xint=Integer.parseInt(eg.kmax1.getText());
            kmax1 = xint;
            xint=Integer.parseInt(eg.kmax2.getText());
            kmax2 = xint;
            xint=Integer.parseInt(eg.kmax3.getText());
            kmax3 = xint;
            xint=eg.permbjer.getSelectedIndex();
            permbjer = xint;
            xint=eg.converror.getSelectedIndex();
            converr = xint;
            lgeq=eg.gausseq.isSelected();
            xint=eg.lenbeta.getSelectedIndex();
            betalen=xint;
            xint=eg.lenbetarel.getSelectedIndex();
            betalenrel=xint;
            eg.dispose();
        } catch (NumberFormatException enfl) {
	    ierr(" electrostatic parameter: format error or no value ");
        }
    }

    void  savesurface() {
        int i, j, k;
        Boolean surface;
        String str;
        try {
            surface = sfg.xwall.isSelected();
            if (surface)
              srfx = 1;
            else
              srfx = 0;
            surface = sfg.ywall.isSelected();
            if (surface)
              srfy = 1;
            else
              srfy = 0;
            surface = sfg.zwall.isSelected();
            if (surface)
              srfz = 1;
            else
              srfz = 0;
            xdouble = Double.parseDouble(sfg.walloffset.getText());
            xdouble = Double.parseDouble(sfg.vgapx.getText());
            vgapx = xdouble;
            xdouble = Double.parseDouble(sfg.vgapy.getText());
            vgapy = xdouble;
            xdouble = Double.parseDouble(sfg.vgapz.getText());
            vgapz = xdouble;
            sfg.dispose();
        } catch (NumberFormatException enfl) {
	    ierr(" surface parameter: format error or no value ");
        }
    }


    void  savedpd() {
        try {
            fw = new FileWriter(filename, false);
            } catch (IOException e) {
                ierr(" cannot create "+filename+" file ");
            }
	
        try {
            name = inidpd.job_header.getText();
            int nfoldx=0, nfoldy=0, nfoldz=0;
            double volx=0, voly=0, volz=0;
            if(lnfold) {
              nfoldx = Integer.parseInt(inidpd.volume_x.getText());            
              nfoldy = Integer.parseInt(inidpd.volume_y.getText());            
              nfoldz = Integer.parseInt(inidpd.volume_z.getText());            
            }
            else {
              volx = Double.parseDouble(inidpd.volume_x.getText());
              voly = Double.parseDouble(inidpd.volume_y.getText());
              volz = Double.parseDouble(inidpd.volume_z.getText());
            }
            double temp = Double.parseDouble(inidpd.sys_temperature.getText());
            double pres = Double.parseDouble(inidpd.sys_pressure.getText());
            double delt = Double.parseDouble(inidpd.time_step.getText());
            double cut = Double.parseDouble(inidpd.cutoff_radius.getText());
            double halo = Double.parseDouble(inidpd.boundary_halo.getText());
            double mbcut = Double.parseDouble(inidpd.manybody_cutoff.getText());
            double eleccut = Double.parseDouble(inidpd.electrostatic_cutoff.getText());
            double surfcut = Double.parseDouble(inidpd.surface_cutoff.getText());
            double densvar = Double.parseDouble(inidpd.dens_var.getText());
            int dump = Integer.parseInt(inidpd.dump_interval.getText());
            int nstp = Integer.parseInt(inidpd.total_steps.getText());
            int neql = Integer.parseInt(inidpd.equilib_steps.getText());
            int pint = Integer.parseInt(inidpd.print_interval.getText());
            int tscal = Integer.parseInt(inidpd.temp_scaling.getText());
            int spanstart = Integer.parseInt(inidpd.save_start.getText());
            int span = Integer.parseInt(inidpd.save_interval.getText());
            int savelevel = inidpd.save_level.getSelectedIndex();
            int stak = Integer.parseInt(inidpd.stack_interval.getText());
            int plot = Integer.parseInt(inidpd.plot_interval.getText());
            int seed = Integer.parseInt(inidpd.random_seed.getText());
            double tjob = Double.parseDouble(inidpd.job_time.getText());
            double ctim = Double.parseDouble(inidpd.close_time.getText());
            fw.write(name+"\n\n");
            if (cube) {
              fw.write("volume "+volx+"\n");
            }
            else if (lnfold) {
              fw.write("nfold "+nfoldx+" "+nfoldy+" "+nfoldz+"\n");
            }
            else {
              fw.write("volume "+volx+" "+voly+" "+volz+"\n");
            }
            if (densvar>0)
              fw.write("densvar "+densvar+"\n");
            fw.write("temperature "+temp+"\n");
            if (btype>0) {
              fw.write("pressure "+pres+"\n");
            }
            fw.write("cutoff "+cut+"\n");
            if (mbcut<cut) {
              fw.write("manybody cutoff "+mbcut+"\n");
            }
            if (etype>0) {
              fw.write("electrostatic cutoff "+eleccut+"\n");
            }
            if (srftype>1) {
              fw.write("surface cutoff "+surfcut+"\n");
            }
            if (halo>cut) {
              fw.write("boundary halo "+halo+"\n");
            }
            if(kres==1) {
              fw.write("restart\n");
            }
            else if(kres==2) {
              fw.write("restart noscale\n");
            }
            else if(kres==3) {
              fw.write("restart scale\n");
            }
            lgbnd = inidpd.global.isSelected();
            if(lgbnd)
              fw.write("global bonds\n");
            lconf = inidpd.config.isSelected();
            if(lconf && !lnfold)
              fw.write("no config\n");
            lind = inidpd.index.isSelected();
            if(lind && !lconf)
              fw.write("no index\n");
            lomp = inidpd.openmp.isSelected();
            if(lomp)
              fw.write("openmp critical\n");
            fw.write("timestep "+delt+"\n");
            fw.write("steps "+nstp+"\n");
            fw.write("equilibration steps "+neql+"\n");
     	    if(tscal > 0)
              fw.write("scale temperature every "+tscal+"\n");
            if(span > 0)
              fw.write("trajectory "+spanstart+" "+span+" "+savelevel+"\n");
            if(plot > 0)
	          fw.write("stats every "+plot+"\n");
            fw.write("stack size "+stak+"\n");
            fw.write("print every "+pint+"\n");
            if(dump!=1000)
              fw.write("ndump "+dump+"\n");
            if(seed!=0)
              fw.write("seed "+seed+"\n");
            fw.write("job time "+tjob+"\n");
            fw.write("close time "+ctim+"\n");
            if (btype==0) {
              fw.write("ensemble nvt ");
              switch (itype) {
                case 0: fw.write("mdvv\n");                break;
                case 1: fw.write("dpdvv\n");               break;
                case 2: fw.write("dpds1\n");               break;
                case 3: fw.write("dpds2\n");               break;
                case 4: fw.write("lowe\n");                break;
                case 5: fw.write("peters\n");              break;
                case 6: fw.write("stoyanov "+atherm+"\n"); break;
              }
            }
            else if(btype==1) {
              fw.write("ensemble npt ");
              switch (itype) {
                case 0: fw.write("mdvv");             break;
                case 1: fw.write("dpdvv");            break;
                case 2: fw.write("dpds1");            break;
                case 3: fw.write("dpds2");            break;
                case 4: fw.write("lowe");             break;
                case 5: fw.write("peters");           break;
                case 6: fw.write("stoyanov "+atherm); break;
              }
              fw.write(" langevin "+abaro+" "+bbaro+"\n");
            }
            else if(btype==2) {
                fw.write("ensemble nst ");
                switch (itype) {
                    case 0: fw.write("mdvv");             break;
                    case 1: fw.write("dpdvv");            break;
                    case 2: fw.write("dpds1");            break;
                    case 3: fw.write("dpds2");            break;
                    case 4: fw.write("lowe");             break;
                    case 5: fw.write("peters");           break;
                    case 6: fw.write("stoyanov "+atherm); break;
                }
                fw.write(" langevin "+abaro+" "+bbaro+" area\n");
            }
            else if(btype==3) {
                fw.write("ensemble nst ");
                switch (itype) {
                    case 0: fw.write("mdvv");             break;
                    case 1: fw.write("dpdvv");            break;
                    case 2: fw.write("dpds1");            break;
                    case 3: fw.write("dpds2");            break;
                    case 4: fw.write("lowe");             break;
                    case 5: fw.write("peters");           break;
                    case 6: fw.write("stoyanov "+atherm); break;
                }
                if(!lisotrop)
                    fw.write(" langevin "+abaro+" "+bbaro+" tension "+cbaro+"\n");
                else
                    fw.write(" langevin "+abaro+" "+bbaro+" tension "+cbaro+" semi\n");
            }
            else if(btype==4) {
              fw.write("ensemble npt ");
              switch (itype) {
                case 0: fw.write("mdvv");             break;
                case 1: fw.write("dpdvv");            break;
                case 2: fw.write("dpds1");            break;
                case 3: fw.write("dpds2");            break;
                case 4: fw.write("lowe");             break;
                case 5: fw.write("peters");           break;
                case 6: fw.write("stoyanov "+atherm); break;
              }
              fw.write(" berendsen "+abaro+"\n");
            }
            else if(btype==5) {
                fw.write("ensemble nst ");
                switch (itype) {
                    case 0: fw.write("mdvv");             break;
                    case 1: fw.write("dpdvv");            break;
                    case 2: fw.write("dpds1");            break;
                    case 3: fw.write("dpds2");            break;
                    case 4: fw.write("lowe");             break;
                    case 5: fw.write("peters");           break;
                    case 6: fw.write("stoyanov "+atherm); break;
                }
                fw.write(" berendsen "+abaro+" area\n");
            }
            else if(btype==6) {
                fw.write("ensemble nst ");
                switch (itype) {
                    case 0: fw.write("mdvv");             break;
                    case 1: fw.write("dpdvv");            break;
                    case 2: fw.write("dpds1");            break;
                    case 3: fw.write("dpds2");            break;
                    case 4: fw.write("lowe");             break;
                    case 5: fw.write("peters");           break;
                    case 6: fw.write("stoyanov "+atherm); break;
                }
                if(!lisotrop)
                    fw.write(" berendsen "+abaro+" tension "+cbaro+"\n");
                else
                    fw.write(" berendsen "+abaro+" tension "+cbaro+" semi\n");
            }
            switch (etype) {
                case 0:     break;
                case 1:     if(permbjer>0)
                              fw.write("bjerrum length "+aelec+"\n");
                            else
                              fw.write("permittivity constant "+aelec+"\n");
                            if(converr>0)
                              fw.write("ewald precision "+belec+"\n");
                            else
                              fw.write("ewald sum "+belec+" "+kmax1+" "+kmax2+" "+kmax3+"\n");
                            break;
                case 2:     if(permbjer>0)
                              fw.write("bjerrum length "+aelec+"\n");
                            else
                              fw.write("permittivity constant "+aelec+"\n");
                            if(converr>0)
                              fw.write("ewald precision "+belec+"\n");
                            else
                              fw.write("ewald sum "+belec+" "+kmax1+" "+kmax2+" "+kmax3+"\n");
                            fw.write("smear linear\n");
                            fw.write("smear length "+celec+"\n");
                            break;
                case 3:     if(permbjer>0)
                              fw.write("bjerrum length "+aelec+"\n");
                            else
                              fw.write("permittivity constant "+aelec+"\n");
                            if(converr>0)
                              fw.write("ewald precision "+belec+"\n");
                            else
                              fw.write("ewald sum "+belec+" "+kmax1+" "+kmax2+" "+kmax3+"\n");
                            fw.write("smear slater exact\n");
                            switch (betalen*3+betalenrel) {
                                case 0: fw.write("smear length "+celec+" original\n");      break;
                                case 1: fw.write("smear length "+celec+" overlap\n");       break;
                                case 2: fw.write("smear length "+celec+" distribution\n");  break;
                                case 3: fw.write("smear beta "+celec+" original\n");        break;
                                case 4: fw.write("smear beta "+celec+" overlap\n");         break;
                                case 5: fw.write("smear beta "+celec+" distribution\n");    break;
                            }
                            break;
                case 4:     if(permbjer>0)
                              fw.write("bjerrum length "+aelec+"\n");
                            else
                              fw.write("permittivity constant "+aelec+"\n");
                            if(converr>0)
                              fw.write("ewald precision "+belec+"\n");
                            else
                              fw.write("ewald sum "+belec+" "+kmax1+" "+kmax2+" "+kmax3+"\n");
                            fw.write("smear slater approx\n");
                            switch (betalen*3+betalenrel) {
                                case 0: fw.write("smear length "+celec+" original\n");      break;
                                case 1: fw.write("smear length "+celec+" overlap\n");       break;
                                case 2: fw.write("smear length "+celec+" distribution\n");  break;
                                case 3: fw.write("smear beta "+celec+" original\n");        break;
                                case 4: fw.write("smear beta "+celec+" overlap\n");         break;
                                case 5: fw.write("smear beta "+celec+" distribution\n");    break;
                            }
                            break;
                case 5:     if(permbjer>0)
                              fw.write("bjerrum length "+aelec+"\n");
                            else
                              fw.write("permittivity constant "+aelec+"\n");
                            if(converr>0)
                              fw.write("ewald precision "+belec+"\n");
                            else
                              fw.write("ewald sum "+belec+" "+kmax1+" "+kmax2+" "+kmax3+"\n");
                            fw.write("smear gauss\n");
                            if(lgeq)
                                fw.write("smear length "+celec+" equal\n");
                            else
                                fw.write("smear length "+celec+"\n");
                            break;
                case 6:     if(permbjer>0)
                              fw.write("bjerrum length "+aelec+"\n");
                            else
                              fw.write("permittivity constant "+aelec+"\n");
                            if(converr>0)
                              fw.write("ewald precision "+belec+"\n");
                            else
                              fw.write("ewald sum "+belec+" "+kmax1+" "+kmax2+" "+kmax3+"\n");
                            fw.write("smear sinusoidal\n");
                            fw.write("smear length "+celec+"\n");
                            break;
                case 7:     if(permbjer>0)
                              fw.write("bjerrum length "+aelec+"\n");
                            else
                              fw.write("permittivity constant "+aelec+"\n");
                            if(converr>0)
                              fw.write("spme precision "+belec+" "+mxspl+"\n");
                            else
                              fw.write("spme "+belec+" "+kmax1+" "+kmax2+" "+kmax3+" "+mxspl+"\n");
                            break;
                case 8:     if(permbjer>0)
                              fw.write("bjerrum length "+aelec+"\n");
                            else
                              fw.write("permittivity constant "+aelec+"\n");
                            if(converr>0)
                              fw.write("spme precision "+belec+" "+mxspl+"\n");
                            else
                              fw.write("spme "+belec+" "+kmax1+" "+kmax2+" "+kmax3+" "+mxspl+"\n");
                            fw.write("smear linear\n");
                            fw.write("smear length "+celec+"\n");
                            break;
                case 9:     if(permbjer>0)
                              fw.write("bjerrum length "+aelec+"\n");
                            else
                              fw.write("permittivity constant "+aelec+"\n");
                            if(converr>0)
                              fw.write("spme precision "+belec+" "+mxspl+"\n");
                            else
                              fw.write("spme "+belec+" "+kmax1+" "+kmax2+" "+kmax3+" "+mxspl+"\n");
                            fw.write("smear slater exact\n");
                            switch (betalen*3+betalenrel) {
                                case 0: fw.write("smear length "+celec+" original\n");      break;
                                case 1: fw.write("smear length "+celec+" overlap\n");       break;
                                case 2: fw.write("smear length "+celec+" distribution\n");  break;
                                case 3: fw.write("smear beta "+celec+" original\n");        break;
                                case 4: fw.write("smear beta "+celec+" overlap\n");         break;
                                case 5: fw.write("smear beta "+celec+" distribution\n");    break;
                            }
                            break;
                case 10:    if(permbjer>0)
                              fw.write("bjerrum length "+aelec+"\n");
                            else
                              fw.write("permittivity constant "+aelec+"\n");
                            if(converr>0)
                              fw.write("spme precision "+belec+" "+mxspl+"\n");
                            else
                              fw.write("spme "+belec+" "+kmax1+" "+kmax2+" "+kmax3+" "+mxspl+"\n");
                            fw.write("smear slater approx\n");
                            switch (betalen*3+betalenrel) {
                                case 0: fw.write("smear length "+celec+" original\n");      break;
                                case 1: fw.write("smear length "+celec+" overlap\n");       break;
                                case 2: fw.write("smear length "+celec+" distribution\n");  break;
                                case 3: fw.write("smear beta "+celec+" original\n");        break;
                                case 4: fw.write("smear beta "+celec+" overlap\n");         break;
                                case 5: fw.write("smear beta "+celec+" distribution\n");    break;
                            }
                            break;
                case 11:    if(permbjer>0)
                              fw.write("bjerrum length "+aelec+"\n");
                            else
                              fw.write("permittivity constant "+aelec+"\n");
                            if(converr>0)
                              fw.write("spme precision "+belec+" "+mxspl+"\n");
                            else
                              fw.write("spme "+belec+" "+kmax1+" "+kmax2+" "+kmax3+" "+mxspl+"\n");
                            fw.write("smear gauss\n");
                            if(lgeq)
                                fw.write("smear length "+celec+" equal\n");
                            else
                                fw.write("smear length "+celec+"\n");
                            break;
                case 12:    if(permbjer>0)
                              fw.write("bjerrum length "+aelec+"\n");
                            else
                              fw.write("permittivity constant "+aelec+"\n");
                            if(converr>0)
                              fw.write("spme precision "+belec+" "+mxspl+"\n");
                            else
                              fw.write("spme "+belec+" "+kmax1+" "+kmax2+" "+kmax3+" "+mxspl+"\n");
                            fw.write("smear sinusoidal\n");
                            fw.write("smear length "+celec+"\n");
                            break;
            }
            if(frzx || frzy || frzz) {
              fw.write("frozen wall");
              if(frzx)
                fw.write(" x");
              if(frzy)
                fw.write(" y");
              if(frzz)
                fw.write(" z");
              fw.write("\n");
            }
            if (srftype==1) {
              fw.write("surface shear");
              if(srfx>0)
                fw.write(" x");
              if(srfy>0)
                fw.write(" y");
              if(srfz>0)
                fw.write(" z");
              fw.write("\n");
            }
            else if (srftype==2) {
              fw.write("surface hard");
              if(srfx>0)
                fw.write(" x");
              if(srfy>0)
                fw.write(" y");
              if(srfz>0)
                fw.write(" z");
              fw.write(" specular");
              if(walloff>0.0)
                fw.write(" "+walloff);
              fw.write("\n");
              if(vgapx!=0.0 || vgapy!=0.0 || vgapz!=0.0)
                fw.write("vacuum gap "+vgapx+" "+vgapy+" "+vgapz+"\n");
            }
            else if (srftype==3) {
              fw.write("surface hard");
              if(srfx>0)
                fw.write(" x");
              if(srfy>0)
                fw.write(" y");
              if(srfz>0)
                fw.write(" z");
              fw.write(" bounceback");
              if(walloff>0.0)
                fw.write(" "+walloff);
              fw.write("\n");
              if(vgapx!=0.0 || vgapy!=0.0 || vgapz!=0.0)
                fw.write("vacuum gap "+vgapx+" "+vgapy+" "+vgapz+"\n");
            }
            fw.write("\nfinish\n");
            dim.srftyp=srftype;
            dim.frzwalls=(frzx || frzy || frzz);
            } catch (NumberFormatException enf) {
            ierr(" system parameter: format error or no value ");
                } catch (IOException e) {
            ierr(" error when saving "+filename+" ");
            System.out.println("Exception: "+e.getMessage());
            }
            try {
                fw.close();
            } catch (IOException e) {
            ierr(" error when closing "+filename+" ");
            System.out.println("Exception: "+e.getMessage());
        }
    }

    void  opendpd() {
        int i,j,k;
        int re=0,rs=0,rm=0,st=0,ab=0,bb=0,cb=0;
        String input,barostat="none";
        String[] words;
        boolean lelec,lspme;
        File it = new File(filename);
        if(!it.exists()) {
          ierr(" cannot find "+filename+" file ");
        }
        try {
            // set defaults
            inidpd.restart_key.setSelectedItem("none");
            kres=0;
            inidpd.thermostat_key.setSelectedItem("DPD/MD-VV");
            itype=0;
            inidpd.setthermo.setEnabled(false);
            inidpd.barostat_key.setSelectedItem("none");
            btype=0;
            lisotrop=true;
            inidpd.setbaro.setEnabled(false);
            inidpd.label52.setEnabled(false);
            inidpd.surface_cutoff.setEditable(false);
            inidpd.surface_cutoff.setEnabled(false);
            inidpd.electrostatic_key.setSelectedItem("none");
            etype=0;
            lelec=false;
            lspme=false;
            inidpd.setelectro.setEnabled(false);
            inidpd.label51.setEnabled(false);
            inidpd.electrostatic_cutoff.setEditable(false);
            inidpd.electrostatic_cutoff.setEnabled(false);
            inidpd.surface_key.setSelectedItem("none");
            srftype=0;
            inidpd.setsurface.setEnabled(false);
            inidpd.label52.setEnabled(false);
            inidpd.surface_cutoff.setEditable(false);
            inidpd.surface_cutoff.setEnabled(false);
            srfx=0;
            srfy=0;
            srfz=0;
            inidpd.global.setSelected(false);
            inidpd.config.setSelected(false);
            inidpd.index.setSelected(false);
            inidpd.dump_interval.setText("1000");
            inidpd.equilib_steps.setText("0");
            inidpd.plot_interval.setText("0");
            inidpd.save_start.setText("0");
            inidpd.save_interval.setText("0");
            inidpd.dens_var.setText("0.0");
            inidpd.boundary_halo.setText("0.0");
            // read name of simulation from CONTROL file
            BufferedReader in = new BufferedReader(new FileReader(filename));
            name = in.readLine();
            inidpd.job_header.setText(name);
            // read in CONTROL file line by line
            while((input = in.readLine()) != null) {
              words = input.split("\\s+");
              k = words.length;
              if(words[0].toLowerCase().startsWith("finish"))
                break;
              else if(words[0].toLowerCase().startsWith("vol")) {
                inidpd.volume_x.setText(words[1]);
                if(k>2) {
                  inidpd.volume_y.setText(words[2]);
                  inidpd.volume_z.setText(words[3]);
                  cube = false;
                  lnfold = false;
                  inidpd.cubic.setSelectedItem("orthorhombic");
                  inidpd.label22x.setEnabled(true);
                  inidpd.label22y.setEnabled(true);
                  inidpd.label22z.setEnabled(true);
                  inidpd.volume_y.setEditable(true);
                  inidpd.volume_y.setEnabled(true);
                  inidpd.volume_z.setEditable(true);
                  inidpd.volume_z.setEnabled(true);
                }
                else {
                  inidpd.volume_y.setText("0.0");
                  inidpd.volume_z.setText("0.0");
                  cube = true;
                  lnfold = false;
                  inidpd.cubic.setSelectedItem("cubic");
                  inidpd.label22x.setEnabled(false);
                  inidpd.label22y.setEnabled(false);
                  inidpd.label22z.setEnabled(false);
                  inidpd.volume_y.setEditable(false);
                  inidpd.volume_y.setEnabled(false);
                  inidpd.volume_z.setEditable(false);
                  inidpd.volume_z.setEnabled(false);
                }
              }
              else if(words[0].toLowerCase().startsWith("nfold")) {
                inidpd.volume_x.setText(words[1]);
                inidpd.volume_y.setText(words[2]);
                inidpd.volume_z.setText(words[3]);
                cube = false;
                lnfold = true;
                inidpd.cubic.setSelectedItem("nfold");
                inidpd.label22x.setEnabled(true);
                inidpd.label22y.setEnabled(true);
                inidpd.label22z.setEnabled(true);
                inidpd.volume_y.setEditable(true);
                inidpd.volume_y.setEnabled(true);
                inidpd.volume_z.setEditable(true);
                inidpd.volume_z.setEnabled(true);
              }
              else if(words[0].toLowerCase().startsWith("temp"))
                inidpd.sys_temperature.setText(words[1]);
              else if(words[0].toLowerCase().startsWith("pres"))
                inidpd.sys_pressure.setText(words[1]);
              else if(words[0].toLowerCase().startsWith("timestep"))
                inidpd.time_step.setText(words[1]);
              else if(words[0].toLowerCase().startsWith("cut") || words[0].toLowerCase().startsWith("rcut"))
                inidpd.cutoff_radius.setText(words[1]);
              else if(words[0].toLowerCase().startsWith("many")) {
                inidpd.manybody_cutoff.setText(words[2]);
                rm=1;
              }
              else if(words[0].toLowerCase().startsWith("elec")) {
                inidpd.electrostatic_cutoff.setText(words[2]);
                re=1;
              }
              else if(words[0].toLowerCase().startsWith("froz")) {
                if(k>1) {
                  if(words[1].toLowerCase().startsWith("x"))
                    frzx = true;
                  else if(words[1].toLowerCase().startsWith("y"))
                    frzy = true;
                  else if(words[1].toLowerCase().startsWith("z"))
                    frzz = true;
                }
                if(k>2) {
                  if(words[2].toLowerCase().startsWith("x"))
                    frzx = true;
                  else if(words[2].toLowerCase().startsWith("y"))
                    frzy = true;
                  else if(words[2].toLowerCase().startsWith("z"))
                    frzz = true;
                }
                if(k>3) {
                  if(words[3].toLowerCase().startsWith("x"))
                    frzx = true;
                  else if(words[3].toLowerCase().startsWith("y"))
                    frzy = true;
                  else if(words[3].toLowerCase().startsWith("z"))
                    frzz = true;
                }
                if(frzx)
                  inidpd.frzxwall.setSelected(true);
                if(frzy)
                  inidpd.frzywall.setSelected(true);
                if(frzz)
                  inidpd.frzzwall.setSelected(true);
              }
              else if(words[0].toLowerCase().startsWith("surf")) {
                if(words[1].toLowerCase().startsWith("cut")) {
                  inidpd.surface_cutoff.setText(words[2]);
                  rs=1;
                }
                else if(words[1].toLowerCase().startsWith("hard")) {
                  srftype=2;
                  walloff=0.0;
                  inidpd.label52.setEnabled(true);
                  inidpd.surface_cutoff.setEditable(true);
                  inidpd.surface_cutoff.setEnabled(true);
                  inidpd.setsurface.setEnabled(true);
                  if(k>2) {
                    if(words[2].toLowerCase().startsWith("x"))
                      srfx = 1;
                    else if(words[2].toLowerCase().startsWith("y"))
                      srfy = 1;
                    else if(words[2].toLowerCase().startsWith("z"))
                      srfz = 1;
                  }
                  if(k>3) {
                    if(words[3].toLowerCase().startsWith("x"))
                      srfx = 1;
                    else if(words[3].toLowerCase().startsWith("y"))
                      srfy = 1;
                    else if(words[3].toLowerCase().startsWith("z"))
                      srfz = 1;
                    else if(words[3].toLowerCase().startsWith("spec")) {
                      srftype=2;
                      if(k>4)
                        walloff=Double.parseDouble(words[4]);
                    }
                    else if(words[3].toLowerCase().startsWith("boun")) {
                      srftype=3;
                      if(k>4)
                        walloff=Double.parseDouble(words[4]);
                    }
                  }
                  if(k>4) {
                    if(words[4].toLowerCase().startsWith("x"))
                      srfx = 1;
                    else if(words[4].toLowerCase().startsWith("y"))
                      srfy = 1;
                    else if(words[4].toLowerCase().startsWith("z"))
                      srfz = 1;
                    else if(words[4].toLowerCase().startsWith("spec")) {
                      srftype=2;
                      if(k>5)
                        walloff=Double.parseDouble(words[5]);
                    }
                    else if(words[4].toLowerCase().startsWith("boun")) {
                      srftype=3;
                      if(k>5)
                        walloff=Double.parseDouble(words[5]);
                    }
                  }
                  if(k>5) {
                    if(words[5].toLowerCase().startsWith("spec")) {
                      srftype=2;
                      if(k>6)
                        walloff=Double.parseDouble(words[6]);
                    }
                    else if(words[5].toLowerCase().startsWith("boun")) {
                      srftype=3;
                      if(k>6)
                        walloff=Double.parseDouble(words[6]);
                    }
                  }
                  if(srftype==2)
                    inidpd.surface_key.setSelectedItem("hard surfaces/specular");
                  else if(srftype==3)
                    inidpd.surface_key.setSelectedItem("hard surfaces/bounceback");
                }
                else if(words[1].toLowerCase().startsWith("shea")) {
                  srftype=1;
                  inidpd.surface_key.setSelectedItem("Lees-Edwards shear");
                  inidpd.label52.setEnabled(false);
                  inidpd.surface_cutoff.setEditable(false);
                  inidpd.surface_cutoff.setEnabled(false);
                  inidpd.setsurface.setEnabled(true);
                  if(k>2) {
                    if(words[2].toLowerCase().startsWith("x"))
                      srfx = 1;
                    else if(words[2].toLowerCase().startsWith("y"))
                      srfy = 1;
                    else if(words[2].toLowerCase().startsWith("z"))
                      srfz = 1;
                  }
                }
              }
              else if(words[0].toLowerCase().startsWith("densvar"))
                inidpd.dens_var.setText(words[1]);
              else if(words[0].toLowerCase().startsWith("ndump"))
                inidpd.dump_interval.setText(words[1]);
              else if(words[0].toLowerCase().startsWith("steps"))
                inidpd.total_steps.setText(words[1]);
              else if(words[0].toLowerCase().startsWith("equil")) {
                if(k>2)
                  inidpd.equilib_steps.setText(words[2]);
                else
                  inidpd.equilib_steps.setText(words[1]);
              }  
              else if(words[0].toLowerCase().startsWith("print")) {
                if(k>2)
                  inidpd.print_interval.setText(words[2]);
                else
                  inidpd.print_interval.setText(words[1]);
              }  
              else if(words[0].toLowerCase().startsWith("scale")) {
                if(k>3)
                  inidpd.temp_scaling.setText(words[3]);
                else if(k>2)
                  inidpd.temp_scaling.setText(words[2]);
                else
                  inidpd.temp_scaling.setText(words[1]);
              }
              else if(words[0].toLowerCase().startsWith("seed"))
                  inidpd.random_seed.setText(words[1]);
              else if(words[0].toLowerCase().startsWith("traj")) {
                if(k>2) {
                  inidpd.save_start.setText(words[1]);
                  inidpd.save_interval.setText(words[2]);
                  st=1;
                  if(k>3) {
                    if(words[3].startsWith("1"))
                      inidpd.save_level.setSelectedItem("1: x,v");
                    else if(words[3].startsWith("2"))
                      inidpd.save_level.setSelectedItem("2: x,v,f");
                    else
                      inidpd.save_level.setSelectedItem("0: x");
                  }
                }
                else {
                  inidpd.save_interval.setText(words[1]);
                  inidpd.save_level.setSelectedItem("0: x");
                }
              }
              else if(words[0].toLowerCase().startsWith("stack")) {
                if(k>2)
                  inidpd.stack_interval.setText(words[2]);
                else
                  inidpd.stack_interval.setText(words[1]);
              }  
              else if(words[0].toLowerCase().startsWith("stats")) {
                if(k>2)
                  inidpd.plot_interval.setText(words[2]);
                else
                  inidpd.plot_interval.setText(words[1]);
              }  
              else if(words[0].toLowerCase().startsWith("job"))
                inidpd.job_time.setText(words[2]);
              else if(words[0].toLowerCase().startsWith("close"))
                inidpd.close_time.setText(words[2]);
              else if(words[0].toLowerCase().startsWith("bound"))
                inidpd.boundary_halo.setText(words[2]);
              else if(words[0].toLowerCase().startsWith("ewald")) {
                lelec = true;
                lspme = false;
                inidpd.label51.setEnabled(true);
                inidpd.electrostatic_cutoff.setEditable(true);
                inidpd.electrostatic_cutoff.setEnabled(true);
                if(words[1].toLowerCase().startsWith("prec")) {
                  belec = Double.parseDouble(words[2]);
                  converr = 1;
                }
                else if(words[1].toLowerCase().startsWith("sum")) {
                  belec = Double.parseDouble(words[2]);
                  kmax1 = Integer.parseInt(words[3]);
                  kmax2 = Integer.parseInt(words[4]);
                  kmax3 = Integer.parseInt(words[5]);
                  converr = 0;
                }
                else {
                  belec = Double.parseDouble(words[1]);
                  kmax1 = Integer.parseInt(words[2]);
                  kmax2 = Integer.parseInt(words[3]);
                  kmax3 = Integer.parseInt(words[4]);
                  converr = 0;
                }
              }
              else if(words[0].toLowerCase().startsWith("spme")) {
                lelec = true;
                lspme = true;
                inidpd.label51.setEnabled(true);
                inidpd.electrostatic_cutoff.setEditable(true);
                inidpd.electrostatic_cutoff.setEnabled(true);
                if(words[1].toLowerCase().startsWith("prec")) {
                  belec = Double.parseDouble(words[2]);
                  mxspl = Integer.parseInt(words[3]);
                  converr = 1;
                }
                else if(words[1].toLowerCase().startsWith("sum")) {
                  belec = Double.parseDouble(words[2]);
                  kmax1 = Integer.parseInt(words[3]);
                  kmax2 = Integer.parseInt(words[4]);
                  kmax3 = Integer.parseInt(words[5]);
                  mxspl = Integer.parseInt(words[6]);
                  converr = 0;
                }
                else {
                  belec = Double.parseDouble(words[1]);
                  kmax1 = Integer.parseInt(words[2]);
                  kmax2 = Integer.parseInt(words[3]);
                  kmax3 = Integer.parseInt(words[4]);
                  mxspl = Integer.parseInt(words[5]);
                  converr = 0;
                }
              }
              else if(words[0].toLowerCase().startsWith("smear")) {
                if(words[1].toLowerCase().startsWith("none")) {
                  etype = 1;
                  inidpd.electrostatic_key.setSelectedItem("Ewald sum/no smearing");
                  inidpd.setelectro.setEnabled(true);
                }
                else if(words[1].toLowerCase().startsWith("linear")) {
                  etype = 2;
                  inidpd.electrostatic_key.setSelectedItem("Ewald sum/linear smearing");
                  inidpd.setelectro.setEnabled(true);
                }
                else if(words[1].toLowerCase().startsWith("slater")) {
                  if(words[2].toLowerCase().startsWith("approx")){
                    etype = 4;
                    inidpd.electrostatic_key.setSelectedItem("Ewald sum/approx. Slater smearing");
                    inidpd.setelectro.setEnabled(true);
                  }
                  else {
                    etype = 3;
                    inidpd.electrostatic_key.setSelectedItem("Ewald sum/exact Slater smearing");
                    inidpd.setelectro.setEnabled(true);
                  }
                }
                else if(words[1].toLowerCase().startsWith("gauss")) {
                  etype = 5;
                  inidpd.electrostatic_key.setSelectedItem("Ewald sum/Gauss smearing");
                  inidpd.setelectro.setEnabled(true);
                }
                else if(words[1].toLowerCase().startsWith("sinus")) {
                  etype = 6;
                  inidpd.electrostatic_key.setSelectedItem("Ewald sum/sinusoidal smearing");
                  inidpd.setelectro.setEnabled(true);
                }
                else if(words[1].toLowerCase().startsWith("len")) {
                    celec = Double.parseDouble(words[2]);
                    betalen = 0;
                    betalenrel = 0;
                    if(words[3].toLowerCase().startsWith("orig"))
                        betalenrel = 0;
                    else if(words[3].toLowerCase().startsWith("over"))
                        betalenrel = 1;
                    else if(words[3].toLowerCase().startsWith("dist"))
                        betalenrel = 2;
                }
                else if(words[1].toLowerCase().startsWith("bet")) {
                    celec = Double.parseDouble(words[2]);
                    betalen = 1;
                    betalenrel = 0;
                    if(words[3].toLowerCase().startsWith("orig"))
                        betalenrel = 0;
                    else if(words[3].toLowerCase().startsWith("over"))
                        betalenrel = 1;
                    else if(words[3].toLowerCase().startsWith("dist"))
                        betalenrel = 2;
                }
              }
              else if(words[0].toLowerCase().startsWith("perm")) {
                if(k>2)
                  aelec = Double.parseDouble(words[2]);
                else
                  aelec = Double.parseDouble(words[1]);
                permbjer = 0;
              }
              else if(words[0].toLowerCase().startsWith("bjer")) {
                if(k>2)
                  aelec = Double.parseDouble(words[2]);
                else
                  aelec = Double.parseDouble(words[1]);
                permbjer = 1;
              }
              else if(words[0].toLowerCase().startsWith("vacu")) {
                if(k>4) {
                  vgapx = Double.parseDouble(words[2]);
                  vgapy = Double.parseDouble(words[3]);
                  vgapz = Double.parseDouble(words[4]);
                }
                else {
                  vgapx = Double.parseDouble(words[1]);
                  vgapy = Double.parseDouble(words[2]);
                  vgapz = Double.parseDouble(words[3]);
                }
              }
              else if(words[0].toLowerCase().startsWith("global"))
                inidpd.global.setSelected(true);
              else if(words[0].toLowerCase().startsWith("no")) {
                if(words[1].toLowerCase().startsWith("conf"))
                  inidpd.config.setSelected(true);
                else if(words[1].toLowerCase().startsWith("ind"))
                  inidpd.index.setSelected(true);
                else if(words[1].toLowerCase().startsWith("elec")) {
                  inidpd.electrostatic_key.setSelectedItem("none");
                  etype=0;
                  inidpd.setelectro.setEnabled(false);
                  inidpd.label51.setEnabled(false);
                  inidpd.electrostatic_cutoff.setEditable(false);
                  inidpd.electrostatic_cutoff.setEnabled(false);
                }
              }
              else if(words[0].toLowerCase().startsWith("openmp"))
                inidpd.openmp.setSelected(true);
              else if(words[0].toLowerCase().startsWith("restart")) {
                kres = 1;
                if(k>1) {
                  if(words[1].toLowerCase().startsWith("noscale")) {
                    kres = 2;
                    inidpd.restart_key.setSelectedItem("new run");
                  }
                  else if(words[1].toLowerCase().startsWith("scale")) {
                    kres = 3;
                    inidpd.restart_key.setSelectedItem("rescaled");
                  }
                }
                if(kres==1)
                  inidpd.restart_key.setSelectedItem("full restart");
              }
              else if(words[0].toLowerCase().startsWith("ensemble")) {
                if(words[1].toLowerCase().startsWith("nvt")) {
                  btype = 0;
                  inidpd.barostat_key.setSelectedItem("none");
                  if(words[2].toLowerCase().startsWith("mdvv")) {
                    itype = 0;
                    inidpd.thermostat_key.setSelectedItem("DPD/MD-VV");
                  }
                  else if(words[2].toLowerCase().startsWith("dpdv")) {
                    itype = 1;
                    inidpd.thermostat_key.setSelectedItem("DPD/DPD-VV");
                  }
                  else if(words[2].toLowerCase().startsWith("dpds1")) {
                    itype = 2;
                    inidpd.thermostat_key.setSelectedItem("DPD/DPD-S1");
                  }
                  else if(words[2].toLowerCase().startsWith("dpds2")) {
                    itype = 3;
                    inidpd.thermostat_key.setSelectedItem("DPD/DPD-S2");
                  }
                  else if(words[2].toLowerCase().startsWith("lowe")) {
                    itype = 4;
                    inidpd.thermostat_key.setSelectedItem("Lowe-Andersen");
                  }
                  else if(words[2].toLowerCase().startsWith("pete")) {
                    itype = 5;
                    inidpd.thermostat_key.setSelectedItem("Peters");
                  }
                  else if(words[2].toLowerCase().startsWith("stoy")) {
                    itype = 6;
                    inidpd.thermostat_key.setSelectedItem("Stoyanov-Groot");
                    atherm = Double.parseDouble(words[3]);
                    inidpd.setthermo.setEnabled(true);
                  }
                }
                else if(words[1].toLowerCase().startsWith("npt")) {
                  if(words[2].toLowerCase().startsWith("mdvv")) {
                    itype = 0;
                    inidpd.thermostat_key.setSelectedItem("DPD/MD-VV");
                    barostat = words[3];
                    ab = 4; bb = 5;
                  }
                  else if(words[2].toLowerCase().startsWith("dpdv")) {
                    itype = 1;
                    inidpd.thermostat_key.setSelectedItem("DPD/DPD-VV");
                    barostat = words[3];
                    ab = 4; bb = 5;
                  }
                  else if(words[2].toLowerCase().startsWith("dpds1")) {
                    itype = 2;
                    inidpd.thermostat_key.setSelectedItem("DPD/DPD-S1");
                    barostat = words[3];
                    ab = 4; bb = 5;
                  }
                  else if(words[2].toLowerCase().startsWith("dpds2")) {
                    itype = 3;
                    inidpd.thermostat_key.setSelectedItem("DPD/DPD-S2");
                    barostat = words[3];
                    ab = 4; bb = 5;
                  }
                  else if(words[2].toLowerCase().startsWith("lowe")) {
                    itype = 4;
                    inidpd.thermostat_key.setSelectedItem("Lowe-Andersen");
                    barostat = words[3];
                    ab = 4; bb = 5;
                  }
                  else if(words[2].toLowerCase().startsWith("pete")) {
                    itype = 5;
                    inidpd.thermostat_key.setSelectedItem("Peters");
                    barostat = words[3];
                    ab = 4; bb = 5;
                  }
                  else if(words[2].toLowerCase().startsWith("stoy")) {
                    itype = 6;
                    inidpd.thermostat_key.setSelectedItem("Stoyanov-Groot");
                    atherm = Double.parseDouble(words[3]);
                    inidpd.setthermo.setEnabled(true);
                    barostat = words[4];
                    ab = 5; bb = 6;
                  }
                  if(barostat.toLowerCase().startsWith("lang")) {
                    btype = 1;
                    inidpd.barostat_key.setSelectedItem("Langevin NPT");
                    abaro = Double.parseDouble(words[ab]);
                    bbaro = Double.parseDouble(words[bb]);
                    inidpd.setbaro.setEnabled(true);
                  }
                  else if(barostat.toLowerCase().startsWith("bere")) {
                    btype = 4;
                    inidpd.barostat_key.setSelectedItem("Berendsen NPT");
                    abaro = Double.parseDouble(words[ab]);
                    inidpd.setbaro.setEnabled(true);
                  }
                }
                else if(words[1].toLowerCase().startsWith("nst")) {
                    if(words[2].toLowerCase().startsWith("mdvv")) {
                        itype = 0;
                        inidpd.thermostat_key.setSelectedItem("DPD/MD-VV");
                        barostat = words[3];
                        ab = 4; bb = 5; cb = 7;
                    }
                    else if(words[2].toLowerCase().startsWith("dpdv")) {
                        itype = 1;
                        inidpd.thermostat_key.setSelectedItem("DPD/DPD-VV");
                        barostat = words[3];
                        ab = 4; bb = 5; cb = 7;
                    }
                    else if(words[2].toLowerCase().startsWith("dpds1")) {
                        itype = 2;
                        inidpd.thermostat_key.setSelectedItem("DPD/DPD-S1");
                        barostat = words[3];
                        ab = 4; bb = 5; cb = 7;
                    }
                    else if(words[2].toLowerCase().startsWith("dpds2")) {
                        itype = 3;
                        inidpd.thermostat_key.setSelectedItem("DPD/DPD-S2");
                        barostat = words[3];
                        ab = 4; bb = 5; cb = 7;
                    }
                    else if(words[2].toLowerCase().startsWith("lowe")) {
                        itype = 4;
                        inidpd.thermostat_key.setSelectedItem("Lowe-Andersen");
                        barostat = words[3];
                        ab = 4; bb = 5; cb = 7;
                    }
                    else if(words[2].toLowerCase().startsWith("pete")) {
                        itype = 5;
                        inidpd.thermostat_key.setSelectedItem("Peters");
                        barostat = words[3];
                        ab = 4; bb = 5; cb = 7;
                    }
                    else if(words[2].toLowerCase().startsWith("stoy")) {
                        itype = 6;
                        inidpd.thermostat_key.setSelectedItem("Stoyanov-Groot");
                        atherm = Double.parseDouble(words[3]);
                        inidpd.setthermo.setEnabled(true);
                        barostat = words[4];
                        ab = 5; bb = 6; cb = 8;
                    }
                    if(barostat.toLowerCase().startsWith("lang")) {
                        btype = 3;
                        lisotrop = false;
                        if(words[cb-1].toLowerCase().startsWith("area")) {
                            btype = 2;
                            inidpd.barostat_key.setSelectedItem("Langevin NPAT");
                            abaro = Double.parseDouble(words[ab]);
                            bbaro = Double.parseDouble(words[bb]);
                        }
                        else {
                            btype = 3;
                            inidpd.barostat_key.setSelectedItem("Langevin NsT");
                            if(words[bb+1].toLowerCase().startsWith("orth")) {
                                abaro = Double.parseDouble(words[ab]);
                                bbaro = Double.parseDouble(words[bb]);
                                cbaro = 0.0;
                                if(words[cb].toLowerCase().startsWith("semi"))
                                    lisotrop = true;
                            }
                            else {
                                abaro = Double.parseDouble(words[ab]);
                                bbaro = Double.parseDouble(words[bb]);
                                cbaro = Double.parseDouble(words[cb]);
                                if(k>cb+1) {
                                    if(words[cb+1].toLowerCase().startsWith("semi"))
                                        lisotrop = true;
                                }
                            }
                        }
                        inidpd.setbaro.setEnabled(true);
                    }
                    else if(barostat.toLowerCase().startsWith("bere")) {
                        lisotrop = false;
                        if(words[bb].toLowerCase().startsWith("area")) {
                           btype = 5;
                           abaro = Double.parseDouble(words[ab]);
                           inidpd.barostat_key.setSelectedItem("Berendsen NPAT");
                        }
                        else {
                            btype = 6;
                            inidpd.barostat_key.setSelectedItem("Berendsen NsT");
                            if(words[bb].toLowerCase().startsWith("orth")) {
                                abaro = Double.parseDouble(words[ab]);
                                bbaro = 0.0;
                                if(words[cb-1].toLowerCase().startsWith("semi"))
                                   lisotrop = true;
                            }
                            else {
                                abaro = Double.parseDouble(words[ab]);
                                bbaro = Double.parseDouble(words[cb-1]);
                                if(k>cb) {
                                    if(words[cb].toLowerCase().startsWith("semi"))
                                        lisotrop = true;
                                }
                            }
                        }
                        inidpd.setbaro.setEnabled(true);
                    }
                }
                  
              }
            }
        if(st==0)
            inidpd.save_start.setText(inidpd.equilib_steps.getText());
        if(lelec && etype==0)
            etype = 1;
        if(lspme)
            etype +=6;
        dim.srftyp=srftype;
        dim.frzwalls=(frzx || frzy || frzz);
	    in.close();
        } catch (NumberFormatException enf) {
            ierr(" system parameter: format error or no value ");
        } catch (IOException e) {
            ierr(" error when reading "+filename+" ");
            System.out.println("Exception: "+e.getMessage());
        }
    }

    void ierr(String errinfo) {
      msgPanel fcer=new msgPanel(errinfo);	
    }
}
