int fOutputVTK(const char* filename);
int fsOutputVTK(const char* filename);

int fOutputVTKP(const char* filename, int prop);
int fsOutputVTKP(const char* filename, int prop);

int fOutputVTKCA(const char* filename, int iprop);
int fsOutputVTKCA(const char* filename, int iprop);

int fOutputVTKCB(const char* filename, int iprop);
int fsOutputVTKCB(const char* filename, int iprop);

int fOutputVTKT(const char* filename);
int fsOutputVTKT(const char* filename);
