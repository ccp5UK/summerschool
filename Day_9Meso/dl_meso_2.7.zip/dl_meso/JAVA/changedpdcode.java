import javax.swing.*;
import java.util.*;
import java.lang.*;
import java.io.*;
import java.awt.*;
import java.awt.event.*;
import java.awt.geom.*;
import java.awt.image.*;
/*
 *     DL_MESO_GUI
 *     author: R. S. Qin, W. Smith and M. A. Seaton 2006, 2018
 *     copyright: UKRI STFC Daresbury Laboratory and CCP5
 */
class changedpdcode extends JPanel {
    changedpdEvt cdpd = new changedpdEvt(this); 

    Font font=new Font("Dialog", Font.BOLD, 12);
    Color paneltop=new Color(170, 170, 230);

    Color bgcolorc=new Color(200, 200, 190);
    Color focolorc=new Color(30, 20, 30);

    JLabel lb1 = new JLabel("Step 1:");
    JLabel lb2 = new JLabel("Step 2:");
    JLabel lb3 = new JLabel("Step 3:");
    JComboBox<String> edit= new JComboBox<String>();
    JTextField editalt = new JTextField(10);
    JComboBox<String> open= new JComboBox<String>();
    JTextField openalt = new JTextField(10);
    JButton change = new JButton("EDIT");

    JLabel info1 = new JLabel("Save the document to its original folder with the same filename");

    public changedpdcode() {
        setSize(620, 530);
        JPanel panel1 = new JPanel();
        panel1.setLayout(new GridBagLayout());

        edit.addItem("Select a Text Editor");
        edit.addItem("dlmesoEditor");
        edit.addItem("emacs");
        edit.addItem("vi");
        edit.addItem("notepad");
        edit.addItem("other ...");
        edit.setFont(font);
        edit.addItemListener(cdpd);
        open.addItem("Choose the file you want to change");
        open.addItem("main file");
        open.addItem("constants");
        open.addItem("global variables");
        open.addItem("configuration module");
        open.addItem("start module");
        open.addItem("force calculation module");
        open.addItem("force calculation module (OpenMP)");
        open.addItem("bond interaction module");
        open.addItem("bond interaction module (OpenMP)");
        open.addItem("many-body DPD module");
        open.addItem("many-body DPD module (OpenMP)");
        open.addItem("ewald module");
        open.addItem("ewald module (OpenMP)");
        open.addItem("SPME module");
        open.addItem("SPME module (OpenMP)");
        open.addItem("surfaces module");
        open.addItem("statistics DPD module");
        open.addItem("other ...");
        open.setFont(font);
        open.addItemListener(cdpd);
        change.setFont(font);
        change.addActionListener(cdpd);

        addItem(panel1, new JLabel(" "), 0, 0, 3, 1, GridBagConstraints.CENTER);

        addItem(panel1, lb1, 0, 1, 1, 1, GridBagConstraints.EAST);
        addItem(panel1, edit, 1, 1, 1, 1, GridBagConstraints.WEST);
        addItem(panel1, editalt, 2, 1, 1, 1, GridBagConstraints.CENTER);

        addItem(panel1, lb2, 0, 2, 1, 1, GridBagConstraints.EAST);
        addItem(panel1, open, 1, 2, 1, 1, GridBagConstraints.WEST);
        addItem(panel1, openalt, 2, 2, 1, 1, GridBagConstraints.CENTER);

        addItem(panel1, lb3, 0, 3, 1, 1, GridBagConstraints.EAST);
        addItem(panel1, change, 1, 3, 1, 1, GridBagConstraints.WEST);

        addItem(panel1, info1, 0, 4, 3, 1, GridBagConstraints.CENTER);

        this.add(panel1);
    }

    private void addItem(JPanel p, JComponent c, int x, int y, int width, int height, int align)
    {
        GridBagConstraints gc = new GridBagConstraints();
        gc.gridx = x;
        gc.gridy = y;
        gc.gridwidth = width;
        gc.gridheight = height;
        gc.weightx = 100.0;
        gc.weighty = 100.0;
        gc.insets = new Insets(30, 5, 30, 5);
        gc.anchor = align;
        gc.fill = GridBagConstraints.NONE;
        p.add(c, gc);
    }
}
