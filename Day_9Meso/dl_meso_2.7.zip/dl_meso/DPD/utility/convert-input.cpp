#include <iomanip>
#include <iostream>
#include <fstream>
#include <cstdlib>
#include <cstdio>
#include <string>
#include <cstring>
#include <cmath>
#include <sstream>
#include <vector>

using namespace std;
string readstring (string, int);
bool fexists(const char *);

template <typename T>
  T StringToNumber ( const string &Text )
  {
     istringstream ss(Text);
     T result;
     return ss >> result ? result : 0;
  }

int main(int argc, char* argv[])
  //-----------------------------------------------------------------
  //
  //    daresbury laboratory ccp5 program to convert input files
  //    for dl_meso_dpd from old format (for dl_meso 2.4 and earlier)
  //    to new version (for dl_meso 2.7 onwards)
  //
  //    copyright ukri stfc daresbury laboratory
  //    author - m. a. seaton december 2019
  //
  //-----------------------------------------------------------------
{

  int result,kres,ktyp,itype,btype,etype,srftype,srfx,srfy,srfz;
  long int nspe, ispe, npot, nsbts, nseql, nrun, nstk, nsbpo, ntraj, iscorr;
  long int mxnbdmol, dummy, nmoldef, k, k1, k2, spec1, spec2, finmol, imol, ibond, iangle, idihed, kmax1, kmax2, kmax3;
  double rcut, rmbcut, relec, srfzcut, rhalo, volm, dimx, dimy, dimz, gamm, cbsize, bdfrcx, bdfrcy, bdfrcz;
  double timjob, tclose, temp, tstep, aatherm, aabaro, bbbaro, aa, bb, cc, dd, ee;
  double gammaelec, alphaew, betaew, x0, y0, z0, prszero, dummdble;
  bool ltemp,lcorr,ltraj,lbond,lgbnd,langle,ldihed,lisoprs,lbody;
  char text[80];
  char** namspe=NULL;
  char** nammol=NULL;
  long int* nspec=NULL;
  long int* nmol=NULL;
  long int* nbdmol=NULL;
  double* amass=NULL;
  double* aasrf=NULL;
  double* aaa=NULL;
  double* bbb=NULL;
  double** mbody=NULL;
  double* chge=NULL;
  double* gamma=NULL;
  double** mlxxx=NULL;
  double** mlyyy=NULL;
  double** mlzzz=NULL;
  long int** mlspe=NULL;
  double** bond=NULL;
  double** angle=NULL;
  double** dihedral=NULL;
  int* bdtype=NULL;
  int* agtype=NULL;
  int* dhtype=NULL;
  long int*** bdinp=NULL;
  long int*** aginp=NULL;
  long int*** dhinp=NULL;
  long int* nbond=NULL;
  long int* nangle=NULL;
  long int* ndihed=NULL;
  int* ktype=NULL;
  bool* lint=NULL;

  bool lmolecule=false,verbose=false;

  string word, word0, word1, word2, word3;
  string record, record1;
  string incontrol, infield, inmolecule, tempstring;
  char c1[40];
  char c2[40];

  incontrol = "CONTROL";
  infield = "FIELD";
  inmolecule = "MOLECULE";

  // check for command line arguments
    
  for(int i=1; i<argc; i++) {
    word = argv[i];
    if(word.compare(0,2,"-c")==0 || word.compare(0,2,"-C")==0) {
      incontrol = argv[i+1];
      i++;
    }
    else if(word.compare(0,2,"-f")==0 || word.compare(0,2,"-F")==0) {
      infield = argv[i+1];
      i++;
    }
    else if(word.compare(0,2,"-m")==0 || word.compare(0,2,"-M")==0) {
      inmolecule = argv[i+1];
      i++;
    }
    else if(word.compare(0,2,"-v")==0 || word.compare(0,2,"-V")==0) {
      verbose = true;
    }
    else if(word.compare(0,2,"-h")==0 || word.compare(0,2,"-H")==0) {
      cout << "DL_MESO convert input utility, reads in CONTROL, FIELD and" << endl;
      cout << "MOLECULE input files for DL_MESO 2.4 or earlier and converts" << endl;
      cout << "them to CONTROL and FIELD file for DL_MESO 2.7 or later" << endl;
      cout << "Usage: " << argv[0] << " [OPTIONS]" << endl << endl;
      cout << "Options:" << endl << endl;
      cout << "-h" << endl;
      cout << "       display this help and exit" << endl << endl;
      cout << "-c [CONTROL]" << endl;
      cout << "       old CONTROL file with simulation parameters named [CONTROL]" << endl;
      cout << "       (default: CONTROL)" << endl << endl;
      cout << "-f [FIELD]" << endl;
      cout << "       old FIELD file with interaction data named [FIELD]" << endl;
      cout << "       (default: FIELD)" << endl << endl;
      cout << "-m [MOLECULE]" << endl;
      cout << "       old MOLECULE file with molecule data named [MOLECULE]" << endl;
      cout << "       (default: MOLECULE)" << endl << endl;
      cout << "-v" << endl;
      cout << "       verbose option: display all information found in input" << endl;
      cout << "       files on screen/default output" << endl;
      exit(0);
    }
  }

  // check for existence of CONTROL, FIELD and MOLECULE files

  strcpy (c1, incontrol.c_str());
  if (!fexists (c1)) {
    cerr << "ERROR: cannot find CONTROL file (name: " << incontrol << ")\n";
    exit(1);
  }

  strcpy (c1, infield.c_str());
  strcpy (c2, inmolecule.c_str());
  if (fexists (c1) && fexists (c1)) {
    lmolecule = true;
  }
    
  //    open old CONTROL file (pass 1)
  
  strcpy (c1, incontrol.c_str());
  ifstream inpfile;
  inpfile.open(c1);
  
  if(inpfile.bad())
    {
      cerr << "ERROR: Unable to open CONTROL file\n";
      exit(8);
    }
  
  inpfile.getline(text,80);
  
  // read in all simulation control parameters (not species data - yet)

  ltraj = false;
  lcorr = false;
  ltemp = false;
  lisoprs = true;
  lbody = false;
  lbond = false;
  langle = false;
  ldihed = false;
  lgbnd = false;
  btype = 0;
  itype = 0;
  etype = 0;
  srftype = 0;

  while(inpfile.good()!=0)
    {
      inpfile >> record;
      
      if(record.compare(0,3,"VOL")==0 || record.compare(0,3,"vol")==0) {
	    inpfile >> volm;
        dimx = dimy = dimz = pow (volm, 1.0/3.0);
        if(verbose)
          cout << "Volume = " << volm << endl;
      }
      else if(record.compare(0,3,"DIM")==0 || record.compare(0,3,"dim")==0) {
        inpfile >> dimx >> dimy >> dimz;
        if(verbose)
          cout << "Dimensions = " << dimx <<", " << dimy <<", "<< dimz << endl;
      }
      else if(record.compare(0,4,"TEMP")==0 || record.compare(0,4,"temp")==0) {
        inpfile >> temp;
        if(verbose)
          cout << "Temperature = " << temp << endl;
 	  }
      else if(record.compare(0,4,"PRES")==0 || record.compare(0,4,"pres")==0) {
	    inpfile >> prszero;
        if(verbose)
          cout << "Pressure = " << prszero << endl;
	  }
      else if(record.compare(0,4,"TSTE")==0 || record.compare(0,4,"tste")==0) {
	    inpfile >> tstep;
        if(verbose)
          cout << "Timestep = " << tstep << endl;
	  }
      else if(record.compare(0,4,"RCUT")==0 || record.compare(0,4,"rcut")==0)
	  {
	    inpfile >> rcut;
        if(verbose)
          cout << "Cut-off radius = " << rcut << endl;
	  }
      else if(record.compare(0,4,"RMBC")==0 || record.compare(0,4,"rmbc")==0) {
	    inpfile >> rmbcut;
        if(verbose)
          cout << "Many-body cut-off radius = " << rmbcut << endl;
 	  }
      else if(record.compare(0,4,"RELE")==0 || record.compare(0,4,"rele")==0) {
	    inpfile >> relec;
        if(verbose)
          cout << "Electrostatic cut-off = " << relec << endl;
	  }
      else if(record.compare(0,4,"RHAL")==0 || record.compare(0,4,"rhal")==0) {
	    inpfile >> rhalo;
        if(verbose)
          cout << "Boundary halo size = " << rhalo << endl;
      }
      else if(record.compare(0,4,"SRFZ")==0 || record.compare(0,4,"srfz")==0) {
	    inpfile >> srfzcut;
        if(verbose)
          cout << "Surface cut-off = " << srfzcut << endl;
	  }
      else if(record.compare(0,4,"GAMM")==0 || record.compare(0,4,"gamm")==0) {
	    inpfile >> gamm;
        if(verbose)
          cout << "Dissipative factor = " << gamm << endl;
	  }
      else if(record.compare(0,4,"TIMJ")==0 || record.compare(0,4,"timj")==0) {
	    inpfile >> timjob;
        if(verbose)
          cout << "Job time = " << timjob << endl;
	  }
      else if(record.compare(0,4,"TCLO")==0 || record.compare(0,4,"tclo")==0) {
	    inpfile >> tclose;
        if(verbose)
          cout << "Close-down time = " << tclose << endl;
	  }
      else if(record.compare(0,4,"KRES")==0 || record.compare(0,4,"kres")==0) {
	    inpfile >> kres;
        if(verbose)
          cout << "Restart parameter = " << kres << endl;
	  }
      else if(record.compare(0,4,"NSBT")==0 || record.compare(0,4,"nsbt")==0) {
	    inpfile >> nsbts;
        if(verbose)
          cout << "Temperature rescale interval = " << nsbts << endl;
	  }
      else if(record.compare(0,4,"NSEQ")==0 || record.compare(0,4,"nseq")==0) {
	    inpfile >> nseql;
        if(verbose)
          cout << "Equilibration timesteps = " << nseql << endl;
 	  }
      else if(record.compare(0,4,"NRUN")==0 || record.compare(0,4,"nrun")==0) {
	    inpfile >> nrun;
        if(verbose)
          cout << "Total timesteps = " << nrun << endl;
	  }
      else if(record.compare(0,4,"NSTK")==0 || record.compare(0,4,"nstk")==0) {
        inpfile >> nstk;
        if(verbose)
          cout << "Statistical stack size = " << nstk << endl;
	  }
      else if(record.compare(0,4,"NSBP")==0 || record.compare(0,4,"nsbp")==0) {
	    inpfile >> nsbpo;
        if(verbose)
          cout << "OUTPUT file interval = " << nsbpo << endl;
	  }
      else if(record.compare(0,4,"NSBS")==0 || record.compare(0,4,"nsbs")==0) {
	    inpfile >> ntraj;
        if(verbose)
          cout << "Trajectory output interval = " << ntraj << endl;
	  }
      else if(record.compare(0,4,"LSBS")==0 || record.compare(0,4,"lsbs")==0) {
	    inpfile >> word;
	    if(word.compare(0,6,".TRUE.")==0 || word.compare(0,6,".true.")==0)ltraj=true;
	    if(word.compare(0,7,".FALSE.")==0 || word.compare(0,7,".false.")==0)ltraj=false;
        if(verbose)
          cout << "Trajectory output switch = " << ltraj << endl;
	  }
      else if(record.compare(0,4,"NSPE")==0 || record.compare(0,4,"nspe")==0) {
	    inpfile >> nspe;
        if(verbose)
          cout << "Number of species = " << nspe << endl;
	  }
      else if(record.compare(0,4,"NMOL")==0 || record.compare(0,4,"nmol")==0) {
	    inpfile >> nmoldef;
        if(verbose)
          cout << "Number of molecule definitions = " << nmoldef << endl;
	  }
      else if(record.compare(0,4,"KTYP")==0 || record.compare(0,4,"ktyp")==0) {
	    inpfile >> ktyp;
        if(verbose)
          cout << "Interaction type = " << ktyp << endl;
	  }
      else if(record.compare(0,4,"LCOR")==0 || record.compare(0,4,"lcor")==0) {
	    inpfile >> word;
	    if(word.compare(0,6,".TRUE.")==0 || word.compare(0,6,".true.")==0)lcorr=true;
	    if(word.compare(0,7,".FALSE.")==0 || word.compare(0,7,".false.")==0)lcorr=false;
        if(verbose)
          cout << "CORREL file switch = " << lcorr << endl;
	  }
      else if(record.compare(0,4,"ISCO")==0 || record.compare(0,4,"isco")==0) {
	    inpfile >> iscorr;
        if(verbose)
          cout << "CORREL file interval = " << iscorr << endl;
	  }
      else if(record.compare(0,4,"LTEM")==0 || record.compare(0,4,"ltem")==0) {
	    inpfile >> word;
	    if(word.compare(0,6,".TRUE.")==0 || word.compare(0,6,".true.")==0)ltemp=true;
	    if(word.compare(0,7,".FALSE.")==0 || word.compare(0,7,".false.")==0)ltemp=false;
        if(verbose)
          cout << "Temperature rescale switch = " << ltemp << endl;
	  }
      else if(record.compare(0,4,"THER")==0 || record.compare(0,4,"ther")==0) {
	    inpfile >> itype;
        if(verbose)
          cout << "Integrator/thermostat type = " << itype;
        if(itype==4) {
          inpfile >> dummdble >> aatherm;
          if(verbose)
            cout <<", thermostat parameter = " << aatherm;
        }
        cout << endl;
	  }
      else if(record.compare(0,4,"BARO")==0 || record.compare(0,4,"baro")==0) {
	    inpfile >> btype;
        if(btype==1)
          inpfile >> aabaro >> bbbaro;
        else if(btype==2) {
          inpfile >> aabaro;
          bbbaro = 0.0;
        }
        if(verbose)
          cout << "Barostat type = " << btype <<", barostat parameters = " << aabaro << ", " << bbbaro << endl;
	  }
      else if(record.compare(0,4,"ELEC")==0 || record.compare(0,4,"elec")==0) {
	  inpfile >> etype;
        if(verbose)
          cout << "Electrostatics type = " << etype;
        if(etype==1) {
          inpfile >> gammaelec >> alphaew >> betaew;
          if(verbose)
            cout << ", electrostatic parameters = " << gammaelec << ", " << alphaew << ", " << betaew;
        }
        cout << endl;
  	  }
      else if(record.compare(0,4,"LISO")==0 || record.compare(0,4,"liso")==0) {
	    inpfile >> word;
	    if(word.compare(0,6,".TRUE.")==0 || word.compare(0,6,".true.")==0)lisoprs=true;
	    if(word.compare(0,7,".FALSE.")==0 || word.compare(0,7,".false.")==0)lisoprs=false;
        if(verbose)
          cout << "Isotropic switch = " << lisoprs << endl;
	  }
      else if(record.compare(0,4,"LBON")==0 || record.compare(0,4,"lbon")==0) {
	    inpfile >> word;
	    if(word.compare(0,6,".TRUE.")==0 || word.compare(0,6,".true.")==0)lbond=true;
	    if(word.compare(0,7,".FALSE.")==0 || word.compare(0,7,".false.")==0)lbond=false;
        if(verbose)
          cout << "Bond switch = " << lbond << endl;
	  }
      else if(record.compare(0,4,"LANG")==0 || record.compare(0,4,"lang")==0) {
	    inpfile >> word;
	    if(word.compare(0,6,".TRUE.")==0 || word.compare(0,6,".true.")==0)langle=true;
	    if(word.compare(0,7,".FALSE.")==0 || word.compare(0,7,".false.")==0)langle=false;
        if(verbose)
          cout << "Angle switch = " << langle << endl;
	  }
      else if(record.compare(0,4,"LDIH")==0 || record.compare(0,4,"ldih")==0) {
	    inpfile >> word;
	    if(word.compare(0,6,".TRUE.")==0 || word.compare(0,6,".true.")==0)ldihed=true;
	    if(word.compare(0,7,".FALSE.")==0 || word.compare(0,7,".false.")==0)ldihed=false;
        if(verbose)
          cout << "Dihedral switch = " << ldihed << endl;
	  }
      else if(record.compare(0,4,"LGBN")==0 || record.compare(0,4,"lgbn")==0) {
	    inpfile >> word;
	    if(word.compare(0,6,".TRUE.")==0 || word.compare(0,6,".true.")==0)lgbnd=true;
	    if(word.compare(0,7,".FALSE.")==0 || word.compare(0,7,".false.")==0)lgbnd=false;
        if(verbose)
          cout << "Global bond switch = " << lgbnd << endl;
	  }
      else if(record.compare(0,4,"BODY")==0 || record.compare(0,4,"body")==0) {
	    inpfile >> bdfrcx >> bdfrcy >> bdfrcz;
        lbody = true;
        if(verbose)
          cout << "External body force = " << bdfrcx <<", " << bdfrcy << ", " << bdfrcz << endl;
	  }
    }
  
  inpfile.close();

  if(!lbond)
    lmolecule = false;

  // allocate arrays required for reading species and molecule data

  npot = nspe * (nspe + 1) / 2;
  namspe = new char* [nspe];
  for (int i=0; i<nspe; i++)
    namspe[i] = new char[8];

  nspec = new long int[nspe];
  if(lmolecule) {
    nmol = new long int[nmoldef];
    nammol = new char* [nmoldef];
    nbdmol = new long int[nmoldef];
    for (int i=0; i<nmoldef; i++)
      nammol[i] = new char[8];
  }
  amass = new double[nspe];
  chge = new double[nspe];
  aasrf = new double[nspe];
  aaa = new double[npot];
  bbb = new double[npot];
  gamma = new double[npot];
  ktype = new int[npot];
  lint = new bool[npot];
  mbody = new double*[npot];
  for (int i=0; i<npot; i++) {
    mbody[i] = new double[5];
    gamma[i] = gamm;
    ktype[i] = ktyp;
    lint[i] = false;
    aaa[i] = bbb[i] = 0.0;
  }

  //    open old CONTROL file (pass 2)
  
  inpfile.open(c1);
  
  if(inpfile.bad())
    {
      cerr << "ERROR: Unable to open CONTROL file\n";
      exit(8);
    }
  
  inpfile.getline(text,80);

  ispe = -1;
  imol = -1;

  // read in species and non-bonded interaction data

  while(inpfile.good()!=0)
    {
      getline(inpfile,word);
      record = readstring(word, 0);
      if(record.compare(0,4,"SPEC")==0 || record.compare(0,4,"spec")==0) {
	    ispe++;
        k = ispe * (ispe + 1) / 2 + ispe;
        word1 = readstring(word, 1);
        copy(word1.begin(), word1.end(), namspe[ispe]);
        if(word1.size()<9)
          namspe[ispe][word1.size()] = '\0';
        else
          namspe[ispe][8] = '\0';
        nspec[ispe] = StringToNumber <int> (readstring(word, 2));
        amass[ispe] = StringToNumber <double> (readstring(word, 3));
        aaa[k] = StringToNumber <double> (readstring(word, 4));
        bbb[k] = StringToNumber <double> (readstring(word, 5));
        chge[ispe] = StringToNumber <double> (readstring(word, 6));
        dd = StringToNumber <double> (readstring(word, 7));
        if(dd>1.0e-6)
          gamma[k] = dd;
        lint[k] = true;
        if(verbose) {
          cout << "Species: name = " << namspe[ispe] << endl;
          cout << "         population = " << nspec[ispe] << endl;
          cout << "         mass = " << amass[ispe] << endl;
          cout << "         energy parameter = " << aaa[k] << endl;
          cout << "         distance parameter = " << bbb[k] << endl;
          cout << "         charge = " << chge[ispe] << endl;
        }
	  }
      else if(record.compare(0,4,"MOLE")==0 || record.compare(0,4,"mole")==0) {
	    imol++;
        word1 = readstring(word, 1);
        copy(word1.begin(), word1.end(), nammol[imol]);
        if(word1.size()<9)
          nammol[imol][word1.size()] = '\0';
        else
          nammol[imol][8] = '\0';
        nmol[imol] = StringToNumber <int> (readstring(word, 2));
        if(verbose) {
          cout << "Molecule: name = " << nammol[imol] << endl;
          cout << "          population = " << nmol[imol] << endl;
        }
	  }
      else if(record.compare(0,4,"SURF")==0 || record.compare(0,4,"surf")==0) {
        srftype = StringToNumber <int> (readstring(word, 1));
        srfx = StringToNumber <int> (readstring(word, 2));
        srfy = StringToNumber <int> (readstring(word, 3));
        srfz = StringToNumber <int> (readstring(word, 4));
        for(int i=0; i<nspe; i++)
          aasrf[i] = StringToNumber <double> (readstring(word, 5+i));
        if(verbose) {
          cout << "Surfaces: x, y, z = " << srfx << ", " << srfy << ", " << srfz << endl;
          cout << "          parameters = ";
          for(int i=0; i<nspe; i++) {
            cout << aasrf[i];
            if (i<nspe-1)
              cout << ", ";
          }
          cout << endl;
        }
	  }
      else if(record.compare(0,4,"KMAX")==0 || record.compare(0,4,"kmax")==0) {
	    kmax1 = StringToNumber <int> (readstring(word, 1));
	    kmax2 = StringToNumber <int> (readstring(word, 2));
	    kmax3 = StringToNumber <int> (readstring(word, 3));
        if (kmax2==0)
          kmax2 = kmax1;
        if (kmax3==0)
          kmax3 = kmax1;
        if(verbose)
          cout << "k-vector sizes = " << kmax1 << ", " << kmax2 << ", " << kmax3 << endl;
	  }
      else if(record.compare(0,4,"MANY")==0 || record.compare(0,4,"many")==0) {
        word1 = readstring(word, 1);
        word2 = readstring(word, 2);
        spec1 = -1; spec2 = -1;
        for (int i=0; i<nspe; i++) {
          word3 = namspe[i];
          if(word1.compare(namspe[i])==0)
            spec1 = i;
          if(word2.compare(namspe[i])==0)
            spec2 = i;
        }
        if (spec1==-1)
          spec1 = StringToNumber <int> (word1) - 1;
        if (spec2==-1)
          spec2 = StringToNumber <int> (word2) - 1;
        if (spec1==-1 || spec2==-1) {
          cerr << "ERROR: unknown species in CONTROL file (many-body)\n";
          exit(1);
        }
        if (spec1>spec2) {
          k = (spec1 + 1) * spec1 / 2 + spec2;
        }
        else {
          k = (spec2 + 1) * spec2 / 2 + spec1;
        }
        mbody[k][0] = StringToNumber <double> (readstring(word, 3));
        mbody[k][1] = StringToNumber <double> (readstring(word, 4));
        mbody[k][2] = StringToNumber <double> (readstring(word, 5));
        mbody[k][3] = StringToNumber <double> (readstring(word, 6));
        mbody[k][4] = StringToNumber <double> (readstring(word, 7));
        ktype[k] = 3;
        lint[k] = true;
        if(verbose) {
          cout << "Many-body: species 1 = " << namspe[spec1] << endl;
          cout << "           species 2 = " << namspe[spec2] << endl;
          cout << "           aa = " << mbody[k][0] << endl;
          cout << "           bb = " << mbody[k][1] << endl;
          cout << "           cc = " << mbody[k][2] << endl;
          cout << "           dd = " << mbody[k][3] << endl;
          cout << "           ee = " << mbody[k][4] << endl;
        }
      }
      else if(record.compare(0,4,"UNLI")==0 || record.compare(0,4,"unli")==0) {
        word1 = readstring(word, 1);
        word2 = readstring(word, 2);
        spec1 = -1; spec2 = -1;
        for (int i=0; i<nspe; i++) {
          if(word1.compare(namspe[i])==0)
            spec1 = i;
          if(word2.compare(namspe[i])==0)
            spec2 = i;
        }
        if (spec1==-1)
          spec1 = StringToNumber <int> (word1) - 1;
        if (spec2==-1)
          spec2 = StringToNumber <int> (word2) - 1;
        if (spec1==-1 || spec2==-1) {
          cerr << "ERROR: unknown species in CONTROL file (unlike)\n";
          exit(1);
        }
        if (spec1>spec2) {
          k = (spec1 + 1) * spec1 / 2 + spec2;
        }
        else {
          k = (spec2 + 1) * spec2 / 2 + spec1;
        }
        k1 = (spec1 + 1) * spec1 / 2 + spec1;
        k2 = (spec2 + 1) * spec2 / 2 + spec2;
        aaa[k] = StringToNumber <double> (readstring(word, 3));
        bb = StringToNumber <double> (readstring(word, 4));
        cc = StringToNumber <double> (readstring(word, 5));
        if(bb<1.0e-16) {
          bb = 0.5*(bbb[k1] + bbb[k2]);
        }
        if(cc>1.0e-16)
          gamma[k] = cc;
        bbb[k] = bb;
        lint[k] = true;
        if(verbose) {
          cout << "Unlike: species 1 = " << namspe[spec1] << " " << k1 << endl;
          cout << "        species 2 = " << namspe[spec2] << " " << k2 << endl;
          cout << "        energy = " << aaa[k] << endl;
          cout << "        distance = " << bbb[k] << endl;
          cout << "        dissipation = " << gamma[k] << endl;
        }
      }
    }

  inpfile.close();

  //  deal with missing interaction data

  for(int i=0; i<nspe; i++)
    for(int j=i; j<nspe; j++) {
      k = (j + 1) * j / 2 + i;
      k1 = (i + 1) * i / 2 + i;
      k2 = (j + 1) * j / 2 + j;
      if (!lint[k]) {
        aa = sqrt(aaa[k1] * aaa[k2]);
        bb = 0.5 * (bbb[k1] + bbb[k2]);
        aaa[k] = aa;
        bbb[k] = bb;
        if(verbose) {
          cout << "Missing interaction: species 1 = " << namspe[i] << endl;
          cout << "                     species 2 = " << namspe[j] << endl;
          cout << "                     energy parameter = " << aa << endl;
          cout << "                     distance parameter = " << bb << endl;
        }
      }
    }

  //    open old MOLECULE file (pass 1)

  if(lmolecule) {  
    strcpy (c1, inmolecule.c_str());
    ifstream molefile;
    molefile.open(c1);
  
    if(molefile.bad())
      {
        cerr << "ERROR: Unable to open MOLECULE file\n";
        exit(8);
      }
  
  // determine maximum molecule size

    imol = -1;
    mxnbdmol = 0;

    while(molefile.good()!=0)
      {
        getline(molefile,word);
        record = readstring(word, 0);
        if(record.compare(0,4,"MOLE")==0 || record.compare(0,4,"mole")==0)
  	  {
            imol++;
  	    nbdmol[imol] = StringToNumber <int> (readstring(word,1));
            if(nbdmol[imol]>mxnbdmol)
              mxnbdmol = nbdmol[imol];
	  }
      }

    if(verbose)
      cout << "Maximum molecule size = " << mxnbdmol << endl;

    molefile.close();

  // allocate arrays required for reading molecule positions

    mlxxx = new double*[nmoldef];
    mlyyy = new double*[nmoldef];
    mlzzz = new double*[nmoldef];
    mlspe = new long int*[nmoldef];
    for (int i=0; i<nmoldef; i++) {
      mlxxx[i] = new double[mxnbdmol];
      mlyyy[i] = new double[mxnbdmol];
      mlzzz[i] = new double[mxnbdmol];
      mlspe[i] = new long int[mxnbdmol];
    }  

  //    open old MOLECULE file (pass 2)
  
    molefile.open(c1);
  
    if(molefile.bad())
      {
        cerr << "ERROR: Unable to open MOLECULE file\n";
        exit(8);
      }
  
  // determine molecule positions

    imol = -1;

    while(molefile.good()!=0)
      {
        getline(molefile,word);
        record = readstring(word, 0);
        if(record.compare(0,4,"MOLE")==0 || record.compare(0,4,"mole")==0) {
            imol++;
            if (imol<nmoldef) {
              finmol = nbdmol[imol];
              if(verbose)
                cout << "Molecule type "<<(imol+1)<<": number of beads = " << finmol << endl;
              x0 = y0 = z0 = 0.0;
              for (int i=0; i<finmol; i++) {
                getline(molefile,word0);
                word1 = readstring(word0, 0);
                spec1 = -1; 
                for (int j=0; j<nspe; j++) {
                  word2 = namspe[j];
                  if(word1.compare(namspe[j])==0)
                    spec1 = j;
                }
                if (spec1==-1)
                  spec1 = StringToNumber <int> (word1) - 1;
                if (spec1==-1) {
                  cerr << "ERROR: unknown species in MOLECULE file\n";
                  exit(1);
                }
                mlspe[imol][i] = spec1;
                mlxxx[imol][i] = StringToNumber <double> (readstring(word0, 1));
                mlyyy[imol][i] = StringToNumber <double> (readstring(word0, 2));
                mlzzz[imol][i] = StringToNumber <double> (readstring(word0, 3));
                x0 += mlxxx[imol][i];
                y0 += mlyyy[imol][i];
                z0 += mlzzz[imol][i];
              }
              x0 /= finmol; y0 /= finmol; z0 /= finmol; 
              for (int i=0; i<finmol; i++) {
                mlxxx[imol][i] -= x0;
                mlyyy[imol][i] -= y0;
                mlzzz[imol][i] -= z0;
                if(verbose) {
                  cout << "Bead " << (i+1) <<": species = " << namspe[spec1] << endl;
                  cout << "                     position = " << mlxxx[imol][i] << ", " << mlyyy[imol][i] << ", " << mlzzz[imol][i] << endl;
                }
              }              
            }
	    }
      }
  
    molefile.close();

  // allocate arrays for bond, angle, dihedral types and inputs

    bond = new double*[nmoldef*mxnbdmol];
    angle = new double*[nmoldef*mxnbdmol];
    dihedral = new double*[nmoldef*mxnbdmol];
    for (int i=0; i<nmoldef*mxnbdmol; i++) {
      bond[i] = new double[4];
      angle[i] = new double[4];
      dihedral[i] = new double[4];
    }
    bdtype = new int[nmoldef*mxnbdmol];
    agtype = new int[nmoldef*mxnbdmol];
    dhtype = new int[nmoldef*mxnbdmol];
    nbond = new long int[nmoldef];
    nangle = new long int[nmoldef];
    ndihed = new long int[nmoldef];

    bdinp = new long int**[nmoldef];
    aginp = new long int**[nmoldef];
    dhinp = new long int**[nmoldef];
    for (int i=0; i<nmoldef; i++) {
      bdinp[i] = new long int*[mxnbdmol];
      aginp[i] = new long int*[mxnbdmol];
      dhinp[i] = new long int*[mxnbdmol];
      for (int j=0; j<mxnbdmol; j++) {
        bdinp[i][j] = new long int[3];
        aginp[i][j] = new long int[4];
        dhinp[i][j] = new long int[5];
      }
    }

  //    open old FIELD file (pass 1)

    strcpy (c1, infield.c_str());
    ifstream fieldfile;
    fieldfile.open(c1);
  
    if(fieldfile.bad())
      {
        cerr << "ERROR: Unable to open FIELD file\n";
        exit(8);
      }

    imol = -1;
    ibond = -1;
    iangle = -1;
    idihed = -1;
  
    while(fieldfile.good()!=0)
      {
        getline(fieldfile,word);
        record = readstring(word, 0);
       
        if(record.compare(0,4,"BOND")==0 || record.compare(0,4,"bond")==0) {
          ibond++;
          bdtype[ibond] = StringToNumber <int> (readstring(word, 1));
          bond[ibond][0] = StringToNumber <double> (readstring(word, 2));
          bond[ibond][1] = StringToNumber <double> (readstring(word, 3));
          bond[ibond][2] = StringToNumber <double> (readstring(word, 4));
          bond[ibond][3] = StringToNumber <double> (readstring(word, 5));
          if(verbose) {
            cout << "Bond: type = " << bdtype[ibond] << endl;
            cout << "      aa = " << bond[ibond][0] << endl;
            cout << "      bb = " << bond[ibond][1] << endl;
            cout << "      cc = " << bond[ibond][2] << endl;
            cout << "      dd = " << bond[ibond][3] << endl;
          }
	    }
        else if(record.compare(0,4,"ANGL")==0 || record.compare(0,4,"angl")==0) {
          iangle++;
          agtype[iangle] = StringToNumber <int> (readstring(word, 1));
          angle[iangle][0] = StringToNumber <double> (readstring(word, 2));
          angle[iangle][1] = StringToNumber <double> (readstring(word, 3));
          angle[iangle][2] = StringToNumber <double> (readstring(word, 4));
          angle[iangle][3] = StringToNumber <double> (readstring(word, 5));
          if(verbose) {
            cout << "Angle: type = " << agtype[iangle] << endl;
            cout << "       aa = " << angle[iangle][0] << endl;
            cout << "       bb = " << angle[iangle][1] << endl;
            cout << "       cc = " << angle[iangle][2] << endl;
            cout << "       dd = " << angle[iangle][3] << endl;
          }
	    }
        else if(record.compare(0,4,"DIHE")==0 || record.compare(0,4,"dihe")==0) {
          idihed++;
          dhtype[idihed] = StringToNumber <int> (readstring(word, 1));
          dihedral[idihed][0] = StringToNumber <double> (readstring(word, 2));
          dihedral[idihed][1] = StringToNumber <double> (readstring(word, 3));
          dihedral[idihed][2] = StringToNumber <double> (readstring(word, 4));
          dihedral[idihed][3] = StringToNumber <double> (readstring(word, 5));
          if(verbose) {
            cout << "Dihedral: type = " << dhtype[idihed] << endl;
            cout << "          aa = " << dihedral[idihed][0] << endl;
            cout << "          bb = " << dihedral[idihed][1] << endl;
            cout << "          cc = " << dihedral[idihed][2] << endl;
            cout << "          dd = " << dihedral[idihed][3] << endl;
          }
	    }
      }
  
    fieldfile.close();

  //    open old FIELD file (pass 2)

    fieldfile.open(c1);
  
    if(fieldfile.bad())
      {
        cerr << "ERROR: Unable to open FIELD file\n";
        exit(8);
      }

    imol = -1;
    ibond = -1;
    iangle = -1;
    idihed = -1;
  
    while(fieldfile.good()!=0)
      {
        getline(fieldfile,word);
        record = readstring(word, 0);
        if(record.compare(0,4,"MOLE")==0 || record.compare(0,4,"mole")==0) {
          imol++;
          nbond[imol] = StringToNumber <int> (readstring(word, 1));
          nangle[imol] = StringToNumber <int> (readstring(word, 2));
          ndihed[imol] = StringToNumber <int> (readstring(word, 3));
          finmol = nbond[imol];
          for (int i=0; i<finmol; i++) {
            fieldfile >> bdinp[imol][i][0] >> bdinp[imol][i][1] >> bdinp[imol][i][2];
            if(verbose)
              cout << "Bond interaction: type = " << bdinp[imol][i][2] << ", beads " << bdinp[imol][i][0] << " and "<< bdinp[imol][i][1] << endl;
          }
          finmol = nangle[imol];
          for (int i=0; i<finmol; i++) {
            fieldfile >> aginp[imol][i][0] >> aginp[imol][i][1] >> aginp[imol][i][2] >> aginp[imol][i][3];
            if(verbose)
              cout << "Angle interaction: type = " << aginp[imol][i][3] << ", beads " << aginp[imol][i][0] << ", " << aginp[imol][i][1] << " and "<< aginp[imol][i][2] << endl;
          }
          finmol = ndihed[imol];
          for (int i=0; i<finmol; i++) {
            fieldfile >> dhinp[imol][i][0] >> dhinp[imol][i][1] >> dhinp[imol][i][2] >> dhinp[imol][i][3] >> dhinp[imol][i][4];
            if(verbose)
              cout << "Dihedral interaction: type = " << dhinp[imol][i][4] << ", beads " << dhinp[imol][i][0] << ", " << dhinp[imol][i][1] << ", " << dhinp[imol][i][2] << " and " << dhinp[imol][i][3] << endl;
          }
          finmol = nbond[imol];
	    }
      }

  }

  // rename old CONTROL and FIELD files if necessary

  if (incontrol=="CONTROL") {
    tempstring = "CONTROL";
    incontrol = "CONTROL.old";
    strcpy (c1, tempstring.c_str());
    strcpy (c2, incontrol.c_str());
    result = rename (c1, c2);
    if (result != 0) {
      cerr << "ERROR: cannot rename old CONTROL file\n";
      exit(1);
    }
  }

  if (infield=="FIELD" && lmolecule) {
    tempstring = "FIELD";
    infield = "FIELD.old";
    strcpy (c1, tempstring.c_str());
    strcpy (c2, infield.c_str());
    result = rename (c1, c2);
    if (result != 0) {
      cerr << "ERROR: cannot rename old FIELD file\n";
      exit(1);
    }
  }


  // open new CONTROL file and write directives etc.

  ofstream newcontrol;
  newcontrol.open("CONTROL");

  newcontrol << text << endl << endl;

  // system
  newcontrol << "volume " << showpoint << dimx << " " << dimy << " " << dimz << endl;
  newcontrol << "temperature " << temp << endl;
  if(btype>0)
    newcontrol << "pressure " << prszero << endl;
  newcontrol << "cutoff " << rcut << endl;
  if(ktyp==3)
    newcontrol << "manybody cutoff " << rmbcut << endl;
  if(etype>0)
    newcontrol << "electrostatic cutoff " << relec << endl;
  if(srftype==1)
    newcontrol << "surface cutoff " << srfzcut << endl;
  if(rhalo>rcut)
    newcontrol << "boundary halo " << rhalo << endl;
  switch (kres) {
    case 1 :
      newcontrol << "restart" << endl;
      break;
    case 2 :
      newcontrol << "restart noscale" << endl;
      break;
    case 3 :
      newcontrol << "restart scale" << endl;
      break;
  }
  if(lmolecule && lgbnd)
    newcontrol << "global bonds" << endl;
  newcontrol << endl;

  // timings
  newcontrol << "timestep " << tstep << endl;
  newcontrol << "steps " << nrun << endl;
  newcontrol << "equilibration steps " << nseql << endl;
  if(ltemp)
    newcontrol << "scale temperature every " << nsbts << endl;
  if(ltraj)
    newcontrol << "trajectory " << nseql << " " << ntraj << " 1" << endl;
  if(lcorr)
    newcontrol << "stats every " << iscorr << endl;
  newcontrol << "stack size " << nstk << endl;
  newcontrol << "print every " << nsbpo << endl;
  newcontrol << "job time " << timjob << endl;
  newcontrol << "close time " << tclose << endl;
  newcontrol << endl;

  // ensembles
  switch(btype) {
    case 0 :
      newcontrol << "ensemble nvt ";
      if(itype==0)
        newcontrol << "mdvv" << endl;
      if(itype==1)
        newcontrol << "dpdvv" << endl;
      if(itype==2)
        newcontrol << "lowe" << endl;
      if(itype==3)
        newcontrol << "peters" << endl;
      if(itype==4)
        newcontrol << "stoyanov " << aatherm << endl;
      break;
    case 1 :
      if(lisoprs) {
        newcontrol << "ensemble npt ";
      }
      else {
        newcontrol << "ensemble nst ";
      }
      if(itype==0)
        newcontrol << "mdvv";
      if(itype==1)
        newcontrol << "dpdvv";
      if(itype==2)
        newcontrol << "lowe";
      if(itype==3)
        newcontrol << "peters";
      if(itype==4)
        newcontrol << "stoyanov " << aatherm;
      newcontrol << " langevin " << aabaro << " " << bbbaro << endl;
      break;
    case 2 :
      if(lisoprs) {
        newcontrol << "ensemble npt ";
      }
      else {
        newcontrol << "ensemble nst ";
      }
      if(itype==0)
        newcontrol << "mdvv";
      if(itype==1)
        newcontrol << "dpdvv";
      if(itype==2)
        newcontrol << "lowe";
      if(itype==3)
        newcontrol << "peters";
      if(itype==4)
        newcontrol << "stoyanov " << aatherm;
      newcontrol << " berendsen " << aabaro << endl;
      break;
  }
  newcontrol << endl;

  // electrostatics
  if(etype==1) {
    newcontrol << "ewald sum " << alphaew << " " << kmax1 << " " << kmax2 << " " << kmax3 << endl;
    newcontrol << "permittivity constant " << gammaelec << endl;
    newcontrol << "smear slater approx" << endl;
    newcontrol << "smear beta " << betaew << endl << endl;
  }

  // surfaces
  if(srftype==1 && (srfx>0 || srfy>0 || srfz>0)) {
    newcontrol << "surface hard";
    if(srfx>0)
      newcontrol << " x";
    if(srfy>0)
      newcontrol << " y";
    if(srfz>0)
      newcontrol << " z";
    newcontrol << endl << endl;
  }

  newcontrol << "finish" << endl;

  newcontrol.close();
  cout << "New CONTROL file written" << endl;

  // open new FIELD file and write interaction data.

  ofstream newfield;
  newfield.open("FIELD");

  newfield << text << endl << endl;

  // species
  newfield << "SPECIES " << nspe << showpoint << endl;
  for(int i=0; i<nspe; i++) {
    newfield << namspe[i] << " " << amass[i] << " " << chge[i] << " " << nspec[i] << endl;
  }
  newfield << endl;

  // molecules
  if(lmolecule) {
    newfield << "MOLECULES " << nmoldef << endl;
    for(int i=0; i<nmoldef; i++) {
      newfield << nammol[i] << endl;
      newfield << "nummols " << nmol[i] << endl;
      newfield << "beads " << nbdmol[i] << endl;
      finmol = nbdmol[i];
      for(int j=0; j<finmol; j++) {
        newfield << namspe[mlspe[i][j]] << " " << mlxxx[i][j] << " " << mlyyy[i][j] << " " << mlzzz[i][j] << endl;
      }
      newfield << "bonds " << nbond[i] << endl;
      finmol = nbond[i];
      for(int j=0; j<finmol; j++) {
        ibond = bdinp[i][j][2]-1;
        dummy = bdtype[ibond];
        switch(dummy) {
          case 1 :
            newfield << "harm  " << bdinp[i][j][0] << " " << bdinp[i][j][1] << " " << bond[ibond][0] << " " << bond[ibond][1] << endl;
            break;
          case 2 :
            newfield << "fene  " << bdinp[i][j][0] << " " << bdinp[i][j][1] << " " << bond[ibond][0] << " " << bond[ibond][1] 
                                                                              << " " << bond[ibond][2] << endl;
            break;
          case 3 :
            newfield << "wlc   " << bdinp[i][j][0] << " " << bdinp[i][j][1] << " " << bond[ibond][0] << " " << bond[ibond][1] << endl;
            break;
          case 4 :
            newfield << "mors  " << bdinp[i][j][0] << " " << bdinp[i][j][1] << " " << bond[ibond][0] << " " << bond[ibond][1]
                                                                              << " " << bond[ibond][2] << endl;
            break;
        }
      }
      if(langle) {
        newfield << "angles " << nangle[i] << endl;
        finmol = nangle[i];
        for(int j=0; j<finmol; j++) {
          iangle = aginp[i][j][3]-1;
          dummy = agtype[iangle];
          switch(dummy) {
            case 1 :
              newfield << "harm  " << aginp[i][j][0] << " " << aginp[i][j][1] << " " << aginp[i][j][2] << " " 
                                                            << angle[iangle][0] << " " << angle[iangle][1] << endl;
              break;
            case 2 :
              newfield << "hcos  " << aginp[i][j][0] << " " << aginp[i][j][1] << " " << aginp[i][j][2] << " " 
                                                            << angle[iangle][0] << " " << angle[iangle][1] << endl;
              break;
          }
        }
      }

      if(ldihed) {
        newfield << "dihedrals " << ndihed[i] << endl;
        finmol = ndihed[i];
        for(int j=0; j<finmol; j++) {
          idihed = dhinp[i][j][4]-1;
          dummy = dhtype[idihed];
          switch(dummy) {
            case 1 :
              newfield << "cos   " << dhinp[i][j][0] << " " << dhinp[i][j][1] << " " << dhinp[i][j][2] << " " << dhinp[i][j][3] << " "
                                                            << dihedral[idihed][0] << " " << dihedral[idihed][2] << " " << dihedral[idihed][1] << endl;
              break;
            case 2 :
              newfield << "harm  " << dhinp[i][j][0] << " " << dhinp[i][j][1] << " " << dhinp[i][j][2] << " " << dhinp[i][j][3] << " " 
                                                            << dihedral[idihed][0] << " " << dihedral[idihed][1] << endl;
              break;
            case 3 :
              newfield << "hcos  " << dhinp[i][j][0] << " " << dhinp[i][j][1] << " " << dhinp[i][j][2] << " " << dhinp[i][j][3] << " " 
                                                            << dihedral[idihed][0] << " " << dihedral[idihed][1] << endl;
              break;
          }
        }
      }
      newfield << "finish" << endl;
    }
    newfield << endl;
  }

  // interactions
  newfield << "INTERACTIONS " << npot << endl;
  for(int i=0; i<nspe; i++)
    for(int j=i; j<nspe; j++) {
      k = (j + 1) * j / 2 + i;
      newfield << namspe[i] << " " << namspe[j];
      switch(ktype[k]) {
        case 0 :
          newfield << " lj   " << aaa[k] << " " << bbb[k] << " " << gamma[k] << endl;
          break;
        case 1 :
          newfield << " wca  " << aaa[k] << " " << bbb[k] << " " << gamma[k] << endl;
          break;
        case 2 :
          newfield << " dpd  " << aaa[k] << " " << bbb[k] << " " << gamma[k] << endl;
          break;
        case 3 :
          newfield << " mdpd " << mbody[k][0] << " " << mbody[k][1] << " " << mbody[k][2] << " " << mbody[k][3] << " " << mbody[k][4]
                                              << " " << bbb[k] << " " << gamma[k] << endl;
          break;
      }
    }
  newfield << endl;

  // surfaces
  if(srftype==1) {
    newfield << "SURFACES" << endl;
    for(int i=0; i<nspe; i++)
      newfield << namspe[i] << " " << aasrf[i] << endl;
    newfield << endl;
  }

  // external body forces/accelerations
  if(lbody) {
    newfield << "EXTERNAL" << endl;
    newfield << "grav " << bdfrcx << " " << bdfrcy << " " << bdfrcz << endl;
    newfield << endl;
  }

  newfield << "CLOSE" << endl;

  newfield.close();
  cout << "New FIELD file written" << endl;

  return(0);
}

string readstring(string strin, int ii)
{
    string buf;
    vector<string> tokens;
    stringstream ss(strin);

    while (ss >> buf)
        tokens.push_back(buf);

    if(ii>=tokens.size()) {
      buf = string();
    }
    else {
      buf = tokens.at(ii);
    }

    return(buf);
}

bool fexists(const char *filename)
{
  ifstream ifile(filename);
  return (bool)ifile;
}


