/***************************************************
 *   DL_MESO       Version 2.7                     *
 *   Authors   :   R. S. Qin, M. A. Seaton,        *
 *                 M. A. Johnston                  *
 *   Copyright :   UKRI STFC Daresbury Laboratory  *
 *             :   09/12/2018                      *
 ***************************************************/

float fGetTemperatureWrap(int ilen, int iprop)
{
 return float(fGetTemperatureSite(ilen));
}

float fGetOneMassSiteWrap(int ilen, int iprop)
{
  return float(fGetOneMassSite(&lbf[ilen*lbsitelength+iprop]));
}

float fGetOneMassSwiftSiteWrap(int ilen, int iprop)
{
  return float(fGetOneMassSite(&lbf[ilen*lbsitelength])*fGetFracSwiftSite(iprop, &lbf[ilen*lbsitelength]));
}

float fGetFracSiteWrap(int ilen, int iprop)
{
  return float(fGetFracSite(iprop, &lbf[ilen*lbsitelength]));
}

float fGetFracSwiftSiteWrap(int ilen, int iprop)
{
  return float(fGetFracSwiftSite(iprop, &lbf[ilen*lbsitelength]));
}

float fGetOneConcSiteWrap(int ilen, int iprop)
{
  return float(fGetOneConcSite(iprop, ilen));
}

void fPieceRangeLocal(int* start, int* end, bool* includeInnerHalos)
{
  // determine extent of piece
  start[0] = 0; end[0] = lbdm.xouter; 
  if(lbdm.xcor == 0)
    start[0] = lbdm.bwid;
  if(lbdm.xcor == lbdm.xdim-1)
    end[0] = lbdm.xouter - lbdm.bwid;

  start[1] = 0; end[1] = lbdm.youter; 
  if(lbdm.ycor == 0)
    start[1] = lbdm.bwid;
  if(lbdm.ycor == lbdm.ydim-1)
    end[1] = lbdm.youter - lbdm.bwid;

  start[2] = 0; end[2] = lbdm.zouter; 
  if(lbdm.zcor == 0 && lbsy.nd==3)
    start[2] = lbdm.bwid;
  if(lbdm.zcor == lbdm.zdim-1 && lbsy.nd==3)
    end[2] = lbdm.zouter - lbdm.bwid;

  // modify piece extent based on includeInnerHalos
  if(includeInnerHalos[0] == false) {
    // remove left halo in x
    if(lbdm.xcor != 0) start[0] += lbdm.bwid;
    // remove right halo in x
    if(lbdm.xcor != lbdm.xdim-1) end[0] -= lbdm.bwid;
  }

  if(includeInnerHalos[1] == false) {
    // remove bottom halo in y
    if(lbdm.ycor != 0) start[1] += lbdm.bwid;
    // remove top halo in y
    if(lbdm.ycor != lbdm.ydim-1) end[1] -= lbdm.bwid;
  }

  if(includeInnerHalos[2] == false && lbsy.nd==3) {
    // remove back halo in z
    if(lbdm.zcor != 0) start[2] += lbdm.bwid;
    // remove front halo in z
    if(lbdm.zcor != lbdm.zdim-1) end[2] -= lbdm.bwid;
  }

}

void fPieceRangeGlobal(int* myStart, int *myEnd)
{
  // return range of grid-points owned by calling process
  // relative to global grid (without halos)

  bool includeInnerHalos[3] = {false, false, false}; 

  //Get the piece local start-end ranges NOT including any halos
  fPieceRangeLocal(myStart,myEnd,includeInnerHalos);

  myStart[0] =  lbdm.xs;
  myStart[1] =  lbdm.ys;
  myStart[2] =  lbdm.zs;
  myEnd[0] =  lbdm.xs+myEnd[0]-lbdm.bwid;
  myEnd[1] =  lbdm.ys+myEnd[1]-lbdm.bwid;
  myEnd[2] =  lbdm.zs+myEnd[2]-((lbsy.nd==3)?lbdm.bwid:0);

}

int fPieceDataPoints(int* start, int* end, int* length)
{
  // calculate number of data points in each dimension

  length[0] = end[0] - start[0];
  length[1] = end[1] - start[1];
  length[2] = end[2] - start[2];

  return length[0]*length[1]*length[2];
}

void fFillBuffer(float* buffer, int* start, int* end, int iprop, bool swapbit, float (*GetFunction)(int, int))
{
  // fill buffer with information for set of points in grid
  // based on specified function
    
  int i,j,k;
  int kstart, jstart, istart;   
  int kend, jend, iend;   
  int ilen, index;
  float value;

  istart = start[0];
  jstart = start[1];
  kstart = start[2];

  iend = end[0];
  jend = end[1];
  kend = end[2];

  for(index=0, k=kstart; k<kend; k++) {
    for(j=jstart; j<jend; j++) {
      for(i=istart; i<iend; i++, index++) {
        ilen = (i* lbdm.youter + j) * lbdm.zouter + k;
        value = GetFunction(ilen, iprop);
        if (swapbit) fByteSwap((void*)(&value),sizeof(float),1);
        buffer[index] = value;
      }
    }
  }
}

void fPieceDensities(float* buffer, int* start, int* end, int iprop, bool swapbit)
{
  fFillBuffer(buffer, start, end, iprop, swapbit, &fGetOneMassSiteWrap);
}

void fPieceDensitiesSwift(float* buffer, int* start, int* end, int iprop, bool swapbit)
{
  fFillBuffer(buffer, start, end, iprop, swapbit, &fGetOneMassSwiftSiteWrap);
}

void fPieceMassFractions(float* buffer, int* start, int* end, int iprop, bool swapbit)
{
  fFillBuffer(buffer, start, end, iprop, swapbit, &fGetFracSiteWrap);
}

void fPieceMassFractionsSwift(float* buffer, int* start, int* end, int iprop, bool swapbit)
{
  fFillBuffer(buffer, start, end, iprop, swapbit, &fGetFracSwiftSiteWrap);
}

void fPieceSoluteConcentrations(float* buffer, int* start, int* end, int iprop, bool swapbit)
{
  fFillBuffer(buffer, start, end, iprop, swapbit, &fGetOneConcSiteWrap);
}

void fPieceTemperatures(float* buffer, int* start, int* end, int param, bool swapbit)
{
  fFillBuffer(buffer, start, end, 0, swapbit, &fGetTemperatureWrap);
}

void fPieceVelocity(float* buffer, int* start, int* end, int comp, bool swapbit)
{
  // fill buffer with single velocity component for piece
  int i,j,k;
  int kstart, jstart, istart;   
  int kend, jend, iend;   
  int ilen, index;
  float ipos;
  float (*GetFunction)(int, double*);

  istart = start[0];
  jstart = start[1];
  kstart = start[2];

  iend = end[0];
  jend = end[1];
  kend = end[2];

  if(interact==20)
    GetFunction = &fGetOneDirecSpeedSwiftSite;
  else if(!incompress)
    GetFunction = &fGetOneDirecSpeedSite;
  else
    GetFunction = &fGetOneDirecSpeedIncomSite;

  // add velocities to buffer
  for(index=0, k=kstart; k<kend; k++) {
    for(j=jstart; j<jend; j++) {
      for(i=istart; i<iend; i++, index++) {
        ilen = (i* lbdm.youter + j) * lbdm.zouter + k;
        if(lbphi[ilen] == 12 || lbphi[ilen] == 13) {
          ipos = 0.0;
        }
        else {
          ipos = GetFunction(comp, &lbf[ilen*lbsitelength]);
        }
        if (swapbit) fByteSwap(&ipos,sizeof(float),1);
        buffer[index] = ipos;
      }
    }
  }
}


void fPieceVelocities(float* buffer, int* start, int* end, int param, bool swapbit)
{
  // fill buffer with velocities for piece
  int i,j,k;
  int kstart, jstart, istart;   
  int kend, jend, iend;   
  int ilen, index;
  float ipos[3];
  float (*GetFunction)(int, double*);

  istart = start[0];
  jstart = start[1];
  kstart = start[2];

  iend = end[0];
  jend = end[1];
  kend = end[2];

  if(interact==20)
    GetFunction = &fGetOneDirecSpeedSwiftSite;
  else if(!incompress)
    GetFunction = &fGetOneDirecSpeedSite;
  else
    GetFunction = &fGetOneDirecSpeedIncomSite;

  // add velocities to buffer
  for(index=0, k=kstart; k<kend; k++) {
    for(j=jstart; j<jend; j++) {
      for(i=istart; i<iend; i++, index++) {
        ilen = (i* lbdm.youter + j) * lbdm.zouter + k;
        if(lbphi[ilen] == 12 || lbphi[ilen] == 13) {
          ipos[0] = 0.0;
          ipos[1] = 0.0;
          ipos[2] = 0.0;
        }
        else {
          ipos[0] = GetFunction(0, &lbf[ilen*lbsitelength]);
          ipos[1] = GetFunction(1, &lbf[ilen*lbsitelength]);
          ipos[2] = GetFunction(2, &lbf[ilen*lbsitelength]);
        }
        if (swapbit) fByteSwap(ipos,sizeof(float),3);
        buffer[3*index] = ipos[0];        
        buffer[3*index+1] = ipos[1];        
        buffer[3*index+2] = ipos[2];        
      }
    }
  }
}

void fPiecePhaseField(int* buffer, int* start, int* end, int param, bool swapbit)
{
  // fill buffer with phase field for piece
  int i,j,k;
  int kstart, jstart, istart;   
  int kend, jend, iend;   
  int ilen, index;
  int jpos;

  istart = start[0];
  jstart = start[1];
  kstart = start[2];

  iend = end[0];
  jend = end[1];
  kend = end[2];

  for(index=0, k=kstart; k<kend; k++) 
  {
    for(j=jstart; j<jend; j++) 
    {
      for(i=istart; i<iend; i++, index++) 
      {
        ilen = (i* lbdm.youter + j) * lbdm.zouter + k;
        jpos=lbphi[ilen];
        if (swapbit) fByteSwap(&jpos,sizeof(int),1);
        buffer[index] = jpos;
      }
    }
  }
}

void fPiecePhaseFieldFloat(float* buffer, int* start, int* end, int param, bool swapbit)
{
  // fill buffer with phase field for piece (converted to float)
  int i,j,k;
  int kstart, jstart, istart;   
  int kend, jend, iend;   
  int ilen, index;
  float jpos;

  istart = start[0];
  jstart = start[1];
  kstart = start[2];

  iend = end[0];
  jend = end[1];
  kend = end[2];

  for(index=0, k=kstart; k<kend; k++) 
  {
    for(j=jstart; j<jend; j++) 
    {
      for(i=istart; i<iend; i++, index++) 
      {
        ilen = (i* lbdm.youter + j) * lbdm.zouter + k;
        jpos=(float)lbphi[ilen];
        if (swapbit) fByteSwap(&jpos,sizeof(float),1);
        buffer[index] = jpos;
      }
    }
  }
}

void fPieceGridPoints(float* buffer, int* start, int* end, int param, bool swapbit)
{
  // fill buffer with coordinate information for piece
  int i,j,k;
  int kstart, jstart, istart;   
  int kend, jend, iend;   
  int index;
  float ipos[3];

  istart = start[0];
  jstart = start[1];
  kstart = start[2];

  iend = end[0];
  jend = end[1];
  kend = end[2];

  if(lbsy.nd==3) {
    for(index=0, k=kstart; k<kend; k++) {
      for(j=jstart; j<jend; j++) {
        for(i=istart; i<iend; i++, index++) {
          ipos[0]=(lbdm.xs + i - lbdm.bwid)*float(lbdx);
          ipos[1]=(lbdm.ys + j - lbdm.bwid)*float(lbdx);
          ipos[2]=(lbdm.zs + k - lbdm.bwid)*float(lbdx);
          if (swapbit) fByteSwap((float*)&ipos,sizeof(float),3);
          buffer[3*index] = ipos[0];
          buffer[3*index+1] = ipos[1];
          buffer[3*index+2] = ipos[2];
        }
      }
    }
  }
  else {
    for(index=0, j=jstart; j<jend; j++) {
      for(i=istart; i<iend; i++, index++) {
        ipos[0]=(lbdm.xs + i - lbdm.bwid)*float(lbdx);
        ipos[1]=(lbdm.ys + j - lbdm.bwid)*float(lbdx);
        ipos[2]=0.0;
        if (swapbit) fByteSwap((float*)&ipos,sizeof(float),3);
        buffer[3*index] = ipos[0];
        buffer[3*index+1] = ipos[1];
        buffer[3*index+2] = ipos[2];
      }
    }
  }
}

void fPieceGridPointComponent(float* buffer, int* start, int* end, int comp, bool swapbit)
{
  // fill buffer with coordinate information for piece
  int i,j,k;
  int kstart, jstart, istart;   
  int kend, jend, iend;   
  int index;
  float ipos;

  istart = start[0];
  jstart = start[1];
  kstart = start[2];

  iend = end[0];
  jend = end[1];
  kend = end[2];

  if(lbsy.nd==3) {
    for(index=0, k=kstart; k<kend; k++) {
      for(j=jstart; j<jend; j++) {
        for(i=istart; i<iend; i++, index++) {
          switch (comp) {
            case 0:   ipos=(lbdm.xs+i-lbdm.bwid)*float(lbdx);
                      break;
            case 1:   ipos=(lbdm.ys+j-lbdm.bwid)*float(lbdx);
                      break;
            case 2:   ipos=(lbdm.zs+k-lbdm.bwid)*float(lbdx);
                      break;
          }
          if (swapbit) fByteSwap(&ipos,sizeof(float),1);
          buffer[index] = ipos;
        }
      }
    }
  }
  else {
    for(index=0, j=jstart; j<jend; j++) {
      for(i=istart; i<iend; i++, index++) {
        switch (comp) {
          case 0:   ipos=(lbdm.xs+i-lbdm.bwid)*float(lbdx);
                    break;
          case 1:   ipos=(lbdm.ys+j-lbdm.bwid)*float(lbdx);
                    break;
          case 2:   ipos=0.0;
                    break;
        }
        if (swapbit) fByteSwap(&ipos,sizeof(float),1);
        buffer[index] = ipos;
      }
    }
  }
}

void fGroupRangeGlobal(sIOGroup* ioGroup)
{
  // sets range of grid points owned by I/O group
  // relative to global grid (without halos)
    
  static bool initialized=false;
  int myStart[3], myEnd[3];
  
  if(!initialized)
  {
    fPieceRangeGlobal(myStart, myEnd);
    initialized = true;
  }

}

void fGroupPieceRangeLocal(int* start, int* end)
{
  // return range of grid points in each dimension covered
  // by piece of I/O group of calling process
    
  int i;
  int dim[3];

  // set range of grid points held by I/O group relative to global grid
    
  fGroupRangeGlobal(&lbIOGroup);

  dim[0] = lbdm.xdim;
  dim[1] = lbdm.ydim;
  dim[2] = lbdm.zdim;

  // convert ranges on global grid to pseudo-local outer
  // grid: (1) add halos in each dimension, (2) convert to
  // local indexing (from 0) and (3) decide whether or not
  // halos should be included

  for(i=0;i<3;i++) {
    start[i] = lbIOGroup.gridStartGlobal[i] - lbdm.bwid;
    end[i] = lbIOGroup.gridEndGlobal[i] + lbdm.bwid;

    end[i] -= start[i];
    start[i] -= start[i];

    if(lbIOGroup.cartStart[i] == 0) start[i] = lbdm.bwid;
    if(lbIOGroup.cartEnd[i] == dim[i] -1) end[i] -= lbdm.bwid;
  }
  if(lbsy.nd<3) {
    start[2] = 0;
    end[2] = 1;
  }

}

void fGroupPieceRangeGlobal(int* start, int* end)
{
  // return range of grid points in each dimension covered
  // by piece of I/O group of calling process, returning
  // indices relative to global grid
    
  fGroupPieceRangeLocal(start, end);

  start[0] = lbdm.xs+start[0]-lbdm.bwid;
  end[0] = lbdm.xs+end[0]-lbdm.bwid-1;

  start[1] = lbdm.ys+start[1]-lbdm.bwid;
  end[1] = lbdm.ys+end[1]-lbdm.bwid-1;

  start[2] = lbdm.zs+start[2]-((lbsy.nd==3)?lbdm.bwid:0);
  end[2] = lbdm.zs+end[2]-1-((lbsy.nd==3)?lbdm.bwid:0);
}

int fGroupPieceDataPoints(int* length)
{
  // find number of grid points in piece of current I/O group
  int count;
  int start[3], end[3];

  fGroupPieceRangeLocal(start, end);
 
  length[0] = end[0] - start[0];
  length[1] = end[1] - start[1];
  length[2] = end[2] - start[2];

  count = length[0]*length[1]*length[2];

  return count;
}
 
void fGroupGatherFloatData(sIOGroup* ioGroup, float* buffer, int* start, int* end, int dataPerPoint,
      int param, bool swapbit, void (*GetLocalData)(float*, int*, int*, int, bool))
{
  // fill buffer with float information for all grid points
  // held by I/O group
    
  int i;
  int myLength[3], myStart[3], myEnd[3]; 
  bool includeInnerHalos[3];

  // includeInnerHalos[i] is false for serial calculations
  for(i=0; i<3;i++) includeInnerHalos[i] = false;

  // get piece extent relative to local piece excluding
  // inner halos in combined dimensions
  fPieceRangeLocal(myStart,myEnd,includeInnerHalos);

  // get local data: all data in serial case
  GetLocalData(buffer, myStart, myEnd, param, swapbit);
    
}

void fGroupGatherIntData(sIOGroup* ioGroup, int* buffer, int* start, int* end, int dataPerPoint,
      int param, bool swapbit, void (*GetLocalData)(int*, int*, int*, int, bool))
{
  // fill buffer with integer information for all grid points
  // held by I/O group
    
  int i;
  int myLength[3], myStart[3], myEnd[3]; 
  bool includeInnerHalos[3]; 

  // includeInnerHalos[i] is false for serial calculations
  for(i=0; i<3;i++) includeInnerHalos[i] = false;

  // get piece extent relative to local piece excluding
  // inner halos in combined dimensions
  fPieceRangeLocal(myStart,myEnd,includeInnerHalos);

  // get local data: all data in serial case
  GetLocalData(buffer, myStart, myEnd, param, swapbit);

}

void fGroupDensities(float* buffer, int* start, int* end, int iprop, bool swapbit)
{
  // gather densities for fluid iprop over entire I/O group
  if(interact==20 && lbsy.nf>1)
    fGroupGatherFloatData(&lbIOGroup, buffer, start, end, 1, iprop, swapbit, &fPieceDensitiesSwift);
  else
    fGroupGatherFloatData(&lbIOGroup, buffer, start, end, 1, iprop, swapbit, &fPieceDensities);
}

void fGroupMassFractions(float* buffer, int* start, int* end, int iprop, bool swapbit)
{
  // gather mass fractions for fluid iprop over entire I/O group
  if(interact==20 && lbsy.nf>1)
    fGroupGatherFloatData(&lbIOGroup, buffer, start, end, 1, iprop, swapbit, &fPieceMassFractionsSwift);
  else
    fGroupGatherFloatData(&lbIOGroup, buffer, start, end, 1, iprop, swapbit, &fPieceMassFractions);
}

void fGroupSoluteConcentrations(float* buffer, int* start, int* end, int iprop, bool swapbit)
{
  // gather concentrations for solute iprop over entire I/O group
  fGroupGatherFloatData(&lbIOGroup, buffer, start, end, 1, iprop, swapbit, &fPieceSoluteConcentrations);
}

void fGroupTemperatures(float* buffer, int* start, int* end, bool swapbit)
{
  // gather temperatures over entire I/O group (N.B. dummy type 0)
  fGroupGatherFloatData(&lbIOGroup, buffer, start, end, 1, 0, swapbit, &fPieceTemperatures);
}

void fGroupPhaseField(int* buffer, int* start, int* end, bool swapbit)
{
  // gather phase fields over entire I/O group (N.B. dummy type 0)
  fGroupGatherIntData(&lbIOGroup, buffer, start, end, 1, 0, swapbit, &fPiecePhaseField);
}

void fGroupPhaseFieldFloat(float* buffer, int* start, int* end, bool swapbit)
{
  // gather phase fields over entire I/O group (N.B. dummy type 0)
  fGroupGatherFloatData(&lbIOGroup, buffer, start, end, 1, 0, swapbit, &fPiecePhaseFieldFloat);
}

void fGroupVelocityComponent(float* buffer, int* start, int* end, int comp, bool swapbit)
{
  // gather single velocity component over entire I/O group
  // (N.B. type based on velocity component)
  fGroupGatherFloatData(&lbIOGroup, buffer, start, end, 1, comp, swapbit, &fPieceVelocity);
}

void fGroupVelocities(float* buffer, int* start, int* end, bool swapbit)
{
  // gather velocities over entire I/O group (N.B. dummer type 0)
  fGroupGatherFloatData(&lbIOGroup, buffer, start, end, 3, 0, swapbit, &fPieceVelocities);
}

void fGroupGridPoints(float* buffer, int* start, int* end, bool swapbit)
{
  // gather grid points over entire I/O group (N.B. dummy type 0)
  fGroupGatherFloatData(&lbIOGroup, buffer, start, end, 3, 0, swapbit, &fPieceGridPoints);
}

void fGroupGridPointComponent(float* buffer, int* start, int* end, int comp, bool swapbit)
{
  // gather grid points over entire I/O group (N.B. type based on component)
  fGroupGatherFloatData(&lbIOGroup, buffer, start, end, 1, comp, swapbit, &fPieceGridPointComponent);
}

int fOpenOutputBinaryFile(const char* filename, ofstream &file)
{
  file.open(filename, ios::binary);
  return 0;
}

int fCloseOutputANSIFile(ofstream &file)
{
  file.close();
  return 0;
}

int fOpenOutputANSIFile(const char* filename, ofstream &file)
{
  file.open(filename);
  return 0;
}

int fCloseOutputBinaryFile(ofstream &file)
{
  file.close();
  return 0;
}

// XML VTK (structured grid) format output

int fWriteVTKFloatBinaryData(float* buffer, int bufflen, unsigned long& startpos, const char* header, const char* footer, unsigned long headersize, unsigned long footersize, ofstream &file)
{
  unsigned int kpos;
    
  kpos=sizeof(float)*bufflen;
  if(!bigend) fByteSwap(&kpos,sizeof(unsigned int),1);
  if(headersize>0) file << header;
  file.write(reinterpret_cast<const char*>(&kpos), sizeof(unsigned int));
  file.write((char*)buffer, bufflen*sizeof(float));
  if(footersize>0) file << footer;
  startpos += headersize+sizeof(unsigned int)+sizeof(float)*bufflen+footersize;
  return 0;
}

int fWriteVTKIntegerBinaryData(int* buffer, int bufflen, unsigned long& startpos, const char* header, const char* footer, unsigned long headersize, unsigned long footersize, ofstream &file)
{
  unsigned int kpos;
  kpos=sizeof(int)*bufflen;
  if(!bigend) fByteSwap(&kpos,sizeof(unsigned int),1);
  if(headersize>0) file << header;
  file.write(reinterpret_cast<const char*>(&kpos), sizeof(unsigned int));
  file.write((char*)buffer, bufflen*sizeof(int));
  if(footersize>0) file << footer;
  startpos += headersize+sizeof(unsigned int)+sizeof(int)*bufflen+footersize;
  return 0;
}

int fWriteVTKFloatANSIData(float* buffer, int bufflen, unsigned long& startpos, const char* header, const char* footer, unsigned long headersize, unsigned long footersize, ofstream &file)
{
  int datalength;
  stringstream sstm;
    
  if(headersize>0) file << header;
  sstm.str(string());
  for(int i=0; i<bufflen; i++) {
    sstm<<buffer[i]<<" ";
  }
  sstm<<"\n";
  datalength = sstm.str().length();
  file << sstm.str() << endl;
  if(footersize>0) file << footer;
  startpos += headersize+datalength+footersize;
  return 0;
}

int fWriteVTKIntegerANSIData(int* buffer, int bufflen, unsigned long& startpos, const char* header, const char* footer, unsigned long headersize, unsigned long footersize, ofstream &file)
{
  int datalength;
  stringstream sstm;
    
  if(headersize>0) file << header;
  sstm.str(string());
  for(int i=0; i<bufflen; i++) {
    sstm<<buffer[i]<<" ";
  }
  sstm<<"\n";
  datalength = sstm.str().length();
  file << sstm.str() << endl;
  if(footersize>0) file << footer;
  startpos += headersize+datalength+footersize;
  return 0;
}

// Legacy VTK format output

int fWriteLegacyVTKFloatBinaryData(float* buffer, int bufflen, unsigned long& startpos, const char* header, const char* footer, unsigned long headersize, unsigned long footersize, ofstream &file)
{
  if(headersize>0) file << header;
  file.write((char*)buffer, bufflen*sizeof(float));
  if(footersize>0) file << footer;
  startpos += headersize+sizeof(float)*bufflen+footersize;
  return 0;
}

int fWriteLegacyVTKIntegerBinaryData(int* buffer, int bufflen, unsigned long& startpos, const char* header, const char* footer, unsigned long headersize, unsigned long footersize, ofstream &file)
{
  if(headersize>0) file << header;
  file.write((char*)buffer, bufflen*sizeof(int));
  if(footersize>0) file << footer;
  startpos += headersize+sizeof(int)*bufflen+footersize;
  return 0;
}

int fWriteLegacyVTKFloatANSIData(float* buffer, int bufflen, bool vec, unsigned long& startpos, const char* header, const char* footer, unsigned long headersize, unsigned long footersize, ofstream &file)
{
  int datalength;
  stringstream sstm;
    
  sstm.str(string());
  if(vec) {
    int line = bufflen/3;
    for(int i=0; i<line; i++) {
      sstm<<buffer[3*i]<<" "<<buffer[3*i+1]<<" "<<buffer[3*i+2]<<"\n";
    }
  }
  else {
    for(int i=0; i<bufflen; i++) {
      sstm<<buffer[i]<<"\n";
    }
  }
  datalength = sstm.str().length();
  if(headersize>0) file << header;
  file << sstm.str() << endl;
  if(footersize>0) file << footer;
  startpos += headersize+datalength+footersize;
  return 0;
}

int fWriteLegacyVTKIntegerANSIData(int* buffer, int bufflen, bool vec, unsigned long& startpos, const char* header, const char* footer, unsigned long headersize, unsigned long footersize, ofstream &file)
{
  int datalength;
  stringstream sstm;
    
  if(headersize>0) file << header;
  sstm.str(string());
  if(vec) {
    int line = bufflen/3;
    for(int i=0; i<line; i++) {
      sstm<<buffer[3*i]<<" "<<buffer[3*i+1]<<" "<<buffer[3*i+2]<<"\n";
    }
  }
  else {
    for(int i=0; i<bufflen; i++) {
      sstm<<buffer[i]<<"\n";
    }
  }
  datalength = sstm.str().length();
  file << sstm.str() << endl;
  if(footersize>0) file << footer;
  startpos += headersize+datalength+footersize;
  return 0;
}

// Plot3D format output

int fWritePlot3DGridFloatBinaryData(float* buffer, int bufflen, unsigned long& startpos, ofstream &file)
{
  file.write((char*)buffer, bufflen*sizeof(float));
  startpos += sizeof(float)*bufflen;
  return 0;
}

int fWritePlot3DGridIntegerBinaryData(int* buffer, int bufflen, unsigned long& startpos, ofstream &file)
{
  file.write((char*)buffer, bufflen*sizeof(int));
  startpos += sizeof(int)*bufflen;
  return 0;
}

int fWritePlot3DGridFloatANSIData(float* buffer, int bufflen, unsigned long& startpos, ofstream &file)
{
  stringstream sstm;
  int datalength;
    
  sstm.str(string());
  for(int i=0; i<bufflen; i++) {
    sstm<<buffer[i];
    if(i<bufflen-1)
      sstm<<" ";
    else
      sstm<<"\n";
  }
  datalength = sstm.str().length();
  file << sstm.str();
  startpos += datalength;
  return 0;
}

int fWritePlot3DGridIntegerANSIData(int* buffer, int bufflen, unsigned long& startpos, ofstream &file)
{
  stringstream sstm;
  int datalength;
    
  sstm.str(string());
  for(int i=0; i<bufflen; i++)
    sstm<<buffer[i]<<" ";
  sstm<<"\n";
  datalength = sstm.str().length();
  file << sstm.str();
  startpos += datalength;
  return 0;
}

int fReadRestart(const char* filename)
{
    // read distribution functions from restart file
    // to resume previous simulation (serial version)
    
    int buffer[12], posbuf[3];
    double headbuf[lbsy.nf], databuf[lbsitelength+lbsy.nf];
    ifstream file;
    long il, totpos;
    bool safe=true;
    unsigned long gridpos, readpos, gridposstart, readposstart;
    
    file.open(filename, ios::binary);
    
    // check if file exists/can be opened: if not,
    // stop with error message
    
    if(!file) {
      cout << "error opening restart file ("<<filename<<")"<<endl;
      exit(1);
    }
    
    // read header with system properties and check
    // they match those in lbin.sys file (if not,
    // indicate which values do not match and stop)
    
    file.read((char*)buffer, 12*sizeof(int));
    if(buffer[0]!=lbsy.nd) {
        cout << "error: mismatch in number of space dimensions between lbin.sys and restart file ("<<filename<<")" << endl;
        cout << "       " << lbsy.nd << " != " << buffer[0] << endl;
        safe = false;
    }
    if(buffer[1]!=lbsy.nq) {
        cout << "error: mismatch in number of discrete speeds (lattice links) between lbin.sys and restart file ("<<filename<<")" << endl;
        cout << "       " << lbsy.nq << " != " << buffer[1] << endl;
        safe = false;
    }
    if(buffer[2]!=lbsy.nx) {
        cout << "error: mismatch in number of grid points in x-direction between lbin.sys and restart file ("<<filename<<")" << endl;
        cout << "       " << lbsy.nx << " != " << buffer[2] << endl;
        safe = false;
    }
    if(buffer[3]!=lbsy.ny) {
        cout << "error: mismatch in number of grid points in y-direction between lbin.sys and restart file ("<<filename<<")" << endl;
        cout << "       " << lbsy.ny << " != " << buffer[3] << endl;
        safe = false;
    }
    if(buffer[4]!=lbsy.nz) {
        cout << "error: mismatch in number of grid points in z-direction between lbin.sys and restart file ("<<filename<<")" << endl;
        cout << "       " << lbsy.nz << " != " << buffer[4] << endl;
        safe = false;
    }
    if(buffer[5]!=lbsy.nf) {
        cout << "error: mismatch in number of fluids between lbin.sys and restart file ("<<filename<<")" << endl;
        cout << "       " << lbsy.nf << " != " << buffer[5] << endl;
        safe = false;
    }
    if(buffer[6]!=lbsy.nc) {
        cout << "error: mismatch in number of solutes between lbin.sys and restart file ("<<filename<<")" << endl;
        cout << "       " << lbsy.nc << " != " << buffer[6] << endl;
        safe = false;
    }
    if(buffer[7]!=lbsy.nt) {
        cout << "error: mismatch in use of temperature field between lbin.sys and restart file ("<<filename<<")" << endl;
        cout << "       " << lbsy.nt << " != " << buffer[7] << endl;
        safe = false;
    }
    if(buffer[8]!=lbsy.pf) {
        cout << "error: mismatch in use of phase field between lbin.sys and restart file ("<<filename<<")" << endl;
        cout << "       " << lbsy.pf << " != " << buffer[8] << endl;
        safe = false;
    }
    if(!safe)
        exit(1);
    
    // assign timestep and output file numbers (overriding defaults of 0 for new simulations)
    lbcurstep = buffer[9];
    qVersion = buffer[10];
    postequil = (lbcurstep>lbequstep);

    // warn if incompressible fluid flag does not match lbin.sys
    // (but does not necessarily prevent a restart)
    
    if(incompress!=buffer[11])
      cout << "warning: mismatch in use of (in)compressible fluids between lbin.sys and restart file ("<<filename<<")"<<endl;
    
    // read constant densities for fluids (do not have to match lbin.sys
    // to restart simulation, so not checking these)
    
    file.read((char*)headbuf, lbsy.nf*sizeof(double));
    
    // read coordinates of each lattice point, find data and
    // replace distribution functions and local relaxation times
    
    totpos = buffer[2]*buffer[3]*buffer[4];
    gridposstart = 12*sizeof(int)+lbsy.nf*sizeof(double);
    readposstart = gridposstart + 3*sizeof(int)*totpos;
    
    for(long ilread=0; ilread<totpos; ilread++) {
        gridpos = gridposstart+3*ilread*sizeof(int);
        file.seekg(gridpos, ios::beg);
        file.read((char*)posbuf, 3*sizeof(int));
        if(lbsy.nd==3)
          il = ((posbuf[0]+lbdm.bwid) * lbdm.youter + posbuf[1]+lbdm.bwid) * lbdm.zouter + posbuf[2]+lbdm.bwid;
        else
          il = (posbuf[0]+lbdm.bwid) * lbdm.youter + posbuf[1]+lbdm.bwid;
        readpos = readposstart+ilread*sizeof(double)*(lbsitelength+lbsy.nf);
        file.seekg(readpos, ios::beg);
        file.read((char*)databuf, (lbsitelength+lbsy.nf)*sizeof(double));
        for(int m=0; m<lbsitelength; m++)
            lbf[il*lbsitelength+m] = databuf[m];
        for(int m=0; m<lbsy.nf; m++)
            lbomega[il*lbsy.nf+m] = databuf[lbsitelength+m];
    }
    
    cout << "restarted simulation at timestep " << lbcurstep << " using restart file ("<<filename<<")" << endl;
    cout << "restarting outputs with frame number " << qVersion+1 << endl;
    return 0;
}

int fWriteRestart(const char* filename="lbout")
{
    // output raw distribution functions to enable
    // restart of simulation (serial version)
    
    char buf[80];
    int buffer[12], posbuf[3];
    double databuf[lbsitelength+lbsy.nf];
    ofstream file;
    long il;
    
    sprintf(buf, "%s.dump", filename);
    
    file.open(buf, ios::binary);
    
    // write required information for restarting simulation
    // (check against properties given in lbin.sys)
    
    buffer[0] =lbsy.nd;
    buffer[1] =lbsy.nq;
    buffer[2] =lbsy.nx;
    buffer[3] =lbsy.ny;
    buffer[4] =lbsy.nz;
    buffer[5] =lbsy.nf;
    buffer[6] =lbsy.nc;
    buffer[7] =lbsy.nt;
    buffer[8] =lbsy.pf;
    buffer[9] =lbcurstep;
    buffer[10]=qVersion;
    buffer[11]=incompress;
    file.write((char*)buffer, 12*sizeof(int));
    
    // write constant densities (only needed for post-processing)
    
    file.write((char*)lbincp, lbsy.nf*sizeof(double));
    
    // write (absolute) lattice point coordinates
    
    for(int i=0; i<lbsy.nx; i++) {
        posbuf[0]=i;
        for(int j=0; j<lbsy.ny; j++) {
            posbuf[1]=j;
            for(int k=0; k<lbsy.nz; k++) {
                posbuf[2]=k;
                file.write((char*)posbuf, 3*sizeof(int));
            }
        }
    }
    
    // put together data at each grid point (first: distribution functions in given order,
    // second: local relaxation frequencies), then write to file
    
    if(lbsy.nd==3) {
      for(int i=lbdm.bwid; i<lbsy.nx+lbdm.bwid; i++) {
        for(int j=lbdm.bwid; j<lbsy.ny+lbdm.bwid; j++) {
          for(int k=lbdm.bwid; k<lbsy.nz+lbdm.bwid; k++) {
            il = (i * lbdm.youter + j) * lbdm.zouter + k;
            for(int m=0; m<lbsitelength; m++)
              databuf[m]=lbf[il*lbsitelength+m];
            for(int m=0; m<lbsy.nf; m++)
              databuf[lbsitelength+m]=lbomega[il*lbsy.nf+m];
            file.write((char*)databuf, (lbsitelength+lbsy.nf)*sizeof(double));
          }
        }
      }
    }
    else {
      for(int i=lbdm.bwid; i<lbsy.nx+lbdm.bwid; i++) {
        for(int j=lbdm.bwid; j<lbsy.ny+lbdm.bwid; j++) {
          il = i * lbdm.youter + j;
          for(int m=0; m<lbsitelength; m++)
            databuf[m]=lbf[il*lbsitelength+m];
          for(int m=0; m<lbsy.nf; m++)
            databuf[lbsitelength+m]=lbomega[il*lbsy.nf+m];
          file.write((char*)databuf, (lbsitelength+lbsy.nf)*sizeof(double));
        }
      }
    }
    
    file.close();
    return 0;
}
