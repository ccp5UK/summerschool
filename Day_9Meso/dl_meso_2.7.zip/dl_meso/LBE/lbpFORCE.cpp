/***************************************************
 *   DL_MESO       Version 2.7                     *
 *   Authors   :   R. S. Qin, M. A. Seaton         *
 *   Copyright :   UKRI STFC Daresbury Laboratory  *
 *             :   09/12/2018                      *
 ***************************************************/

int fInteractionForceZero()
{
  // reset all interaction and heat forces to zero

  if(interact>9 && interact<20) {
    for(long k=0; k<3*lbdm.touter; k++)
      lbinterforce[k]=0;
    for(long k=0; k<3*lbsy.nf*lbdm.touter; k++)
      lbheatforce[k]=0;
  }
  else {
    for(long k=0; k<3*lbsy.nf*lbdm.touter; k++) {
      lbinterforce[k]=0;
      lbheatforce[k]=0;
    }
  }
  return 0;
}

int fCalcPotential_ShanChen()
{
  // calculate interaction potentials
  double *pt3 = &lbft[0];

  #pragma omp parallel
  {
    double rho[lbsy.nf];
    double R = lbgasconst;
    double Tr, m, pstar, rho0, psi0, a, b, phi;
    #pragma omp for
    for(long i=0; i<lbdm.touter; i++) {
      fGetAllMassSite(rho, &lbf[i*lbsitelength]);
      double T = (lbsy.nt>0)?fGetTemperatureSite(i):lbsyst;
      for(int j=0; j<lbsy.nf; j++) {
        int pottyp = lbscpot[j];
        switch (pottyp) {
          case 0:
          // Ideal lattice gas: psi = 0
            pt3[i*lbsy.nf+j] = 0.0;
            break;
          case 1:
          // Shan-Chen model (1993): psi = rho0 * (1 - exp(-rho/rho0))
            rho0 = lbincp[j];
            pt3[i*lbsy.nf+j] = rho0 * (1.0 - exp(-rho[j]/rho0));
            break;
          case 2:
          // Shan-Chen model (1994): psi = psi0 * exp (-rho0/rho)
            rho0 = lbincp[j];
            psi0 = lbpsi0[j];
            pt3[i*lbsy.nf+j] = psi0 * (exp(-rho0/rho[j]));
            break;
          case 3:
          // Qian model (1995): psi = rho0 * rho / (rho0 + rho)
            rho0 = lbincp[j];
            pt3[i*lbsy.nf+j] = rho0 * rho[j] * fReciprocal(rho0+rho[j]);
            break;
          case 4:
          // psi = rho
            pt3[i*lbsy.nf+j] = rho[j];
            break;
          case 5:
          // Ideal gas: P = rho*RT
            pstar = R*T*lbrcssq - 1.0;
            pt3[i*lbsy.nf+j] = fCppSign(pstar) * sqrt(2.0*rho[j]*fCppAbs(pstar));
            break;
          case 6:
          // van der Waals (1873): P = rho*RT/(1-b*rho) - a*rho*rho
            a = lbeosa[j];
            b = lbeosb[j];
            pstar = R*T*lbrcssq*fReciprocal(1.0-b*rho[j]) - a*rho[j]*lbrcssq - 1.0;
            pt3[i*lbsy.nf+j] = fCppSign(pstar) * sqrt(2.0*rho[j]*fCppAbs(pstar));
            break;
          case 7:
          // Carnahan-Starling-van der Waals (1972): P = rho*RT*(1+phi+phi^2-phi^3)/((1-phi)^3) - a*rho*rho
            a = lbeosa[j];
            phi = 0.25*rho[j]*lbeosb[j];
            pstar = R*T*lbrcssq*(1.0+phi*(1.0+phi*(1.0-phi)))*fReciprocal((1.0-phi)*(1.0-phi)*(1.0-phi)) - a*rho[j]*lbrcssq - 1.0;
            pt3[i*lbsy.nf+j] = fCppSign(pstar) * sqrt(2.0*rho[j]*fCppAbs(pstar));
            break;
          case 8:
          // Redlich-Kwong (1949): P = rho*RT/(1-b*rho) - a*rho*rho/(sqrt(T)*(1+b*rho)) (constant system temperature)
            a = lbeosa[j];
            b = lbeosb[j];
            pstar = R*T*lbrcssq*fReciprocal(1.0-b*rho[j]) - a*rho[j]*lbrcssq*fReciprocal(1.0+b*rho[j]) - 1.0;
            pt3[i*lbsy.nf+j] = fCppSign(pstar) * sqrt(2.0*rho[j]*fCppAbs(pstar));
            break;
          case 9:
          // Redlich-Kwong (1949): P = rho*RT/(1-b*rho) - a*rho*rho/(sqrt(T)*(1+b*rho)) (variable system temperature)
            a = lbeosa[j]*fReciprocal(sqrt(T));
            b = lbeosb[j];
            pstar = R*T*lbrcssq*fReciprocal(1.0-b*rho[j]) - a*rho[j]*lbrcssq*(1.0+b*rho[j]) - 1.0;
            pt3[i*lbsy.nf+j] = fCppSign(pstar) * sqrt(2.0*rho[j]*fCppAbs(pstar));
            break;
          case 10:
          // Soave-Redlich-Kwong (1972): P = rho*RT/(1-b*rho) - a*alpha*rho*rho/(1+b*rho) (constant system temperature)
            a = lbeosa[j];
            b = lbeosb[j];
            pstar = R*T*lbrcssq*fReciprocal(1.0-b*rho[j]) - a*rho[j]*lbrcssq*fReciprocal(1.0+b*rho[j]) - 1.0;
            pt3[i*lbsy.nf+j] = fCppSign(pstar) * sqrt(2.0*rho[j]*fCppAbs(pstar));
            break;
          case 11:
          // Soave-Redlich-Kwong (1972): P = rho*RT/(1-b*rho) - a*alpha*rho*rho/(1+b*rho) (variable system temperature)
            Tr = T * fReciprocal(lbcritt[j]);
            m = (1.0 + (0.480 + lbacentric[j] * (1.574  - 0.176 * lbacentric[j])) * (1.0 - sqrt(Tr)));
            a = lbeosa[j]*m*m;
            b = lbeosb[j];
            pstar = R*T*lbrcssq*fReciprocal(1.0-b*rho[j]) - a*rho[j]*lbrcssq*fReciprocal(1.0+b*rho[j]) - 1.0;
            pt3[i*lbsy.nf+j] = fCppSign(pstar) * sqrt(2.0*rho[j]*fCppAbs(pstar));
            break;
          case 12:
          // Peng-Robinson (1976): P = rho*RT/(1-b*rho) - a*alpha*rho*rho/(1+2*b*rho-b*b*rho*rho) (constant system temperature)
            a = lbeosa[j];
            b = lbeosb[j];
            pstar = R*T*lbrcssq*fReciprocal(1.0-b*rho[j]) - a*rho[j]*lbrcssq*fReciprocal(1.0+b*rho[j]*(2.0-b*rho[j])) - 1.0;
            pt3[i*lbsy.nf+j] = fCppSign(pstar) * sqrt(2.0*rho[j]*fCppAbs(pstar));
            break;
          case 13:
          // Peng-Robinson (1976): P = rho*RT/(1-b*rho) - a*alpha*rho*rho/(1+2*b*rho-b*b*rho*rho) (variable system temperature)
            Tr = T * fReciprocal(lbcritt[j]);
            m = (1.0 + (0.37464 + lbacentric[j] * (1.54226  - 0.26992 * lbacentric[j])) * (1.0 - sqrt(Tr)));
            a = lbeosa[j]*m*m;
            b = lbeosb[j];
            pstar = R*T*lbrcssq*fReciprocal(1.0-b*rho[j]) - a*rho[j]*lbrcssq*fReciprocal(1.0+b*rho[j]*(2.0-b*rho[j])) - 1.0;
            pt3[i*lbsy.nf+j] = fCppSign(pstar) * sqrt(2.0*rho[j]*fCppAbs(pstar));
            break;
          case 14:
          // Carnahan-Starling-Redlich-Kwong (1972): P = rho*RT*(1+phi+phi^2-phi^3)/((1-phi)^3) - a*rho*rho/(sqrt(T)*(1+b*rho)) (constant system temperature)
            a = lbeosa[j];
            b = lbeosb[j];
            phi = 0.25*rho[j]*b;
            pstar = R*T*lbrcssq*(1.0+phi*(1.0+phi*(1.0-phi)))*fReciprocal((1.0-phi)*(1.0-phi)*(1.0-phi)) - a*rho[j]*lbrcssq*fReciprocal(1.0+b*rho[j]) - 1.0;
            pt3[i*lbsy.nf+j] = fCppSign(pstar) * sqrt(2.0*rho[j]*fCppAbs(pstar));
            break;
          case 15:
          // Carnahan-Starling-Redlich-Kwong (1972): P = rho*RT*(1+phi+phi^2-phi^3)/((1-phi)^3) - a*rho*rho/(sqrt(T)*(1+b*rho)) (variable system temperature)
            a = lbeosa[j];
            b = lbeosb[j];
            phi = 0.25*rho[j]*b;
            pstar = R*T*lbrcssq*(1.0+phi*(1.0+phi*(1.0-phi)))*fReciprocal((1.0-phi)*(1.0-phi)*(1.0-phi)) - a*rho[j]*lbrcssq*fReciprocal(sqrt(T)*(1.0+b*rho[j])) - 1.0;
            pt3[i*lbsy.nf+j] = fCppSign(pstar) * sqrt(2.0*rho[j]*fCppAbs(pstar));
            break;
        }
      }
    }
  }

  pt3 = NULL;
  return 0;
}

int fCalcInteraction_ShanChen(int xpos, int ypos, int zpos)
{
  long spos, tpos;
  double factor0[lbsy.nf], factor1[lbsy.nf], factor2[lbsy.nf];
  double wfactor0 = 0.0;
  double wfactor1 = 0.0;
  double wfactor2 = 0.0;
  double gwall, phi;

  tpos = (xpos * lbdm.youter + ypos) * lbdm.zouter + zpos;
  for(int k=0; k<lbsy.nf; k++){
    factor0[k]=0.0; factor1[k]=0.0; factor2[k]=0.0;
  }
  if (lbneigh[tpos]==0) {
    for(int m=1; m<lbsy.nq; m++) {
      spos = ((xpos+lbvx[m])*lbdm.youter + ypos+lbvy[m])*lbdm.zouter + zpos+lbvz[m];
      for(int k=0; k<lbsy.nf; k++) {
        double psi = lbft[spos * lbsy.nf + k];
        factor0[k] += lbvwx[m] * psi;
        factor1[k] += lbvwy[m] * psi;
        factor2[k] += lbvwz[m] * psi;
      }
    }
    for(int k=0; k<lbsy.nf; k++) {
      double psik = fCppAbs(lbft[tpos*lbsy.nf+k]);
      for(int j=0; j<lbsy.nf; j++) {
        double gfluid = lbg[k*lbsy.nf+j]*psik;
        lbinterforce[tpos*3*lbsy.nf+3*k]  -=gfluid*factor0[j];
        lbinterforce[tpos*3*lbsy.nf+3*k+1]-=gfluid*factor1[j];
        lbinterforce[tpos*3*lbsy.nf+3*k+2]-=gfluid*factor2[j];
      }
    }
  }
  else {
    for(int m=1; m<lbsy.nq; m++) {
      spos = ((xpos+lbvx[m])*lbdm.youter + ypos+lbvy[m])*lbdm.zouter + zpos+lbvz[m];
      for(int k=0; k<lbsy.nf; k++) {
        double psi = lbft[spos * lbsy.nf + k];
        factor0[k] += lbvwx[m] * psi;
        factor1[k] += lbvwy[m] * psi;
        factor2[k] += lbvwz[m] * psi;
      }
      double spsi = (lbphi[spos]>10);
      wfactor0 += lbvwx[m] * spsi;
      wfactor1 += lbvwy[m] * spsi;
      wfactor2 += lbvwz[m] * spsi;
    }
    for(int k=0; k<lbsy.nf; k++) {
      int wettyp = lbwet[k];
      double psik = fCppAbs(lbft[tpos*lbsy.nf+k]);
      for(int j=0; j<lbsy.nf; j++) {
        double gfluid = lbg[k*lbsy.nf+j]*psik;
        lbinterforce[tpos*3*lbsy.nf+3*k]  -=gfluid*factor0[j];
        lbinterforce[tpos*3*lbsy.nf+3*k+1]-=gfluid*factor1[j];
        lbinterforce[tpos*3*lbsy.nf+3*k+2]-=gfluid*factor2[j];
      }
      gwall = 0.0;
      switch (wettyp) {
        case 0:
        // Martys-Chen (1996): density-based wetting
          gwall = lbgwall[k]*fGetOneMassSite(k, tpos);
          break;
        case 1:
        // Raiskinmaki et al. (2000): pseudopotential-based wetting
          gwall = lbgwall[k]*psik;
          break;
        case 2:
        // Li et al. (2014): pseudopotential-based wetting with position-dependent screening
          phi = psik;
          gwall = lbgwall[k]*psik*phi;
          break;
      }
      lbinterforce[tpos*3*lbsy.nf+3*k]  -=gwall*wfactor0;
      lbinterforce[tpos*3*lbsy.nf+3*k+1]-=gwall*wfactor1;
      lbinterforce[tpos*3*lbsy.nf+3*k+2]-=gwall*wfactor2;
    }
  }
  return 0;
}

int fCalcInteraction_ShanChen_Boundary(int xpos, int ypos, int zpos)
{
  long spos, tpos;
  double factor0[lbsy.nf], factor1[lbsy.nf], factor2[lbsy.nf];
  double wfactor0 = 0.0;
  double wfactor1 = 0.0;
  double wfactor2 = 0.0;
  double gwall, phi;

  tpos = (xpos * lbdm.youter + ypos) * lbdm.zouter + zpos;
  for(int k=0; k<lbsy.nf; k++){
    factor0[k]=0.0; factor1[k]=0.0; factor2[k]=0.0;
  }
  if(lbneigh[tpos]==0) {
    for(int m=1; m<lbsy.nq; m++) {
      spos = (fCppMod(xpos+lbvx[m], lbdm.xouter)  * lbdm.youter
            + fCppMod(ypos+lbvy[m], lbdm.youter)) * lbdm.zouter
            + fCppMod(zpos+lbvz[m], lbdm.zouter);
      for(int k=0; k<lbsy.nf; k++) {
        double psi = lbft[spos * lbsy.nf + k];
        factor0[k] += lbvwx[m] * psi;
        factor1[k] += lbvwy[m] * psi;
        factor2[k] += lbvwz[m] * psi;
      }
    }
    for(int k=0; k<lbsy.nf; k++) {
      double psik = fCppAbs(lbft[tpos*lbsy.nf+k]);
      for(int j=0; j<lbsy.nf; j++) {
        double gfluid = lbg[k*lbsy.nf+j]*psik;
        lbinterforce[tpos*3*lbsy.nf+3*k]  -=gfluid*factor0[j];
        lbinterforce[tpos*3*lbsy.nf+3*k+1]-=gfluid*factor1[j];
        lbinterforce[tpos*3*lbsy.nf+3*k+2]-=gfluid*factor2[j];
      }
    }
  }
  else {
    for(int m=1; m<lbsy.nq; m++) {
      spos = (fCppMod(xpos+lbvx[m], lbdm.xouter)  * lbdm.youter
            + fCppMod(ypos+lbvy[m], lbdm.youter)) * lbdm.zouter
            + fCppMod(zpos+lbvz[m], lbdm.zouter);
      for(int k=0; k<lbsy.nf; k++) {
        double psi = lbft[spos * lbsy.nf + k];
        factor0[k] += lbvwx[m] * psi;
        factor1[k] += lbvwy[m] * psi;
        factor2[k] += lbvwz[m] * psi;
      }
      double spsi = (lbphi[spos]>10);
      wfactor0 += lbvwx[m] * spsi;
      wfactor1 += lbvwy[m] * spsi;
      wfactor2 += lbvwz[m] * spsi;
    }
    for(int k=0; k<lbsy.nf; k++) {
      int wettyp = lbwet[k];
      double psik = fCppAbs(lbft[tpos*lbsy.nf+k]);
      for(int j=0; j<lbsy.nf; j++) {
        double gfluid = lbg[k*lbsy.nf+j]*psik;
        lbinterforce[tpos*3*lbsy.nf+3*k]  -=gfluid*factor0[j];
        lbinterforce[tpos*3*lbsy.nf+3*k+1]-=gfluid*factor1[j];
        lbinterforce[tpos*3*lbsy.nf+3*k+2]-=gfluid*factor2[j];
      }
      gwall = 0.0;
      switch (wettyp) {
        case 0:
        // Martys-Chen (1996): density-based wetting
          gwall = lbgwall[k]*fGetOneMassSite(k, tpos);
          break;
        case 1:
        // Raiskinmaki et al. (2000): pseudopotential-based wetting
          gwall = lbgwall[k]*psik;
          break;
        case 2:
        // Li et al. (2014): pseudopotential-based wetting with position-dependent screening
          phi = psik;
          gwall = lbgwall[k]*psik*phi;
          break;
      }
      lbinterforce[tpos*3*lbsy.nf+3*k]  -=gwall*wfactor0;
      lbinterforce[tpos*3*lbsy.nf+3*k+1]-=gwall*wfactor1;
      lbinterforce[tpos*3*lbsy.nf+3*k+2]-=gwall*wfactor2;
    }
  }
  return 0;
}


int fCalcInteraction_ShanChenQuadratic(int xpos, int ypos, int zpos)
{
  long spos, tpos;
  double factor0[lbsy.nf], factor1[lbsy.nf], factor2[lbsy.nf], factor3[lbsy.nf], factor4[lbsy.nf], factor5[lbsy.nf];
  double wfactor0 = 0.0;
  double wfactor1 = 0.0;
  double wfactor2 = 0.0;
  double gwall, phi;

  tpos = (xpos * lbdm.youter + ypos) * lbdm.zouter + zpos;
  for(int k=0; k<lbsy.nf; k++){
    factor0[k]=0.0; factor1[k]=0.0; factor2[k]=0.0; factor3[k]=0.0; factor4[k]=0.0; factor5[k]=0.0;
  }
  if(lbneigh[tpos]==0) {
    for(int m=1; m<lbsy.nq; m++) {
      spos = ((xpos+lbvx[m])*lbdm.youter + ypos+lbvy[m])*lbdm.zouter + zpos+lbvz[m];
      for(int k=0; k<lbsy.nf; k++) {
        double psi = lbft[spos * lbsy.nf + k];
        factor0[k] += lbvwx[m] * psi;
        factor1[k] += lbvwy[m] * psi;
        factor2[k] += lbvwz[m] * psi;
        factor3[k] += lbvwx[m] * psi * psi;
        factor4[k] += lbvwy[m] * psi * psi;
        factor5[k] += lbvwz[m] * psi * psi;
      }
    }
    for(int k=0; k<lbsy.nf; k++) {
      double psik = fCppAbs(lbft[tpos*lbsy.nf+k]);
      for(int j=0; j<lbsy.nf; j++) {
        double betakj = lbscquad[k*lbsy.nf+j];
        double gfluid1 = lbg[k*lbsy.nf+j]*psik*betakj;
        double gfluid2 = 0.5*lbg[k*lbsy.nf+j]*(1.0-betakj);
        lbinterforce[tpos*3*lbsy.nf+3*k]  -=(gfluid1*factor0[j]+gfluid2*factor3[j]);
        lbinterforce[tpos*3*lbsy.nf+3*k+1]-=(gfluid1*factor1[j]+gfluid2*factor4[j]);
        lbinterforce[tpos*3*lbsy.nf+3*k+2]-=(gfluid1*factor2[j]+gfluid2*factor5[j]);
      }
    }
  }
  else {
    for(int m=1; m<lbsy.nq; m++) {
      spos = ((xpos+lbvx[m])*lbdm.youter + ypos+lbvy[m])*lbdm.zouter + zpos+lbvz[m];
      for(int k=0; k<lbsy.nf; k++) {
        double psi = lbft[spos * lbsy.nf + k];
        factor0[k] += lbvwx[m] * psi;
        factor1[k] += lbvwy[m] * psi;
        factor2[k] += lbvwz[m] * psi;
        factor3[k] += lbvwx[m] * psi * psi;
        factor4[k] += lbvwy[m] * psi * psi;
        factor5[k] += lbvwz[m] * psi * psi;
      }
      double spsi = (lbneigh[tpos]>0 && lbphi[spos]>10);
      wfactor0 += lbvwx[m] * spsi;
      wfactor1 += lbvwy[m] * spsi;
      wfactor2 += lbvwz[m] * spsi;
    }
    for(int k=0; k<lbsy.nf; k++) {
      int wettyp = lbwet[k];
      double psik = fCppAbs(lbft[tpos*lbsy.nf+k]);
      for(int j=0; j<lbsy.nf; j++) {
        double betakj = lbscquad[k*lbsy.nf+j];
        double gfluid1 = lbg[k*lbsy.nf+j]*psik*betakj;
        double gfluid2 = 0.5*lbg[k*lbsy.nf+j]*(1.0-betakj);
        lbinterforce[tpos*3*lbsy.nf+3*k]  -=(gfluid1*factor0[j]+gfluid2*factor3[j]);
        lbinterforce[tpos*3*lbsy.nf+3*k+1]-=(gfluid1*factor1[j]+gfluid2*factor4[j]);
        lbinterforce[tpos*3*lbsy.nf+3*k+2]-=(gfluid1*factor2[j]+gfluid2*factor5[j]);
      }
      gwall = 0.0;
      switch (wettyp) {
        case 0:
        // Martys-Chen (1996): density-based wetting
          gwall = lbgwall[k]*fGetOneMassSite(k, tpos);
          break;
        case 1:
        // Raiskinmaki et al. (2000): pseudopotential-based wetting
          gwall = lbgwall[k]*psik;
          break;
        case 2:
        // Li et al. (2014): pseudopotential-based wetting with position-dependent screening
          phi = psik;
          gwall = lbgwall[k]*psik*phi;
          break;
      }
      lbinterforce[tpos*3*lbsy.nf+3*k]  -=gwall*wfactor0;
      lbinterforce[tpos*3*lbsy.nf+3*k+1]-=gwall*wfactor1;
      lbinterforce[tpos*3*lbsy.nf+3*k+2]-=gwall*wfactor2;
    }
  }
  return 0;
}

int fCalcInteraction_ShanChenQuadratic_Boundary(int xpos, int ypos, int zpos)
{
  long spos, tpos;
  double factor0[lbsy.nf], factor1[lbsy.nf], factor2[lbsy.nf], factor3[lbsy.nf], factor4[lbsy.nf], factor5[lbsy.nf];
  double wfactor0 = 0.0;
  double wfactor1 = 0.0;
  double wfactor2 = 0.0;
  double gwall, phi;

  tpos = (xpos * lbdm.youter + ypos) * lbdm.zouter + zpos;
  for(int k=0; k<lbsy.nf; k++){
    factor0[k]=0.0; factor1[k]=0.0; factor2[k]=0.0; factor3[k]=0.0; factor4[k]=0.0; factor5[k]=0.0;
  }
  if(lbneigh[tpos]>0) {
    for(int m=1; m<lbsy.nq; m++) {
      spos = (fCppMod(xpos+lbvx[m], lbdm.xouter)  * lbdm.youter
            + fCppMod(ypos+lbvy[m], lbdm.youter)) * lbdm.zouter
            + fCppMod(zpos+lbvz[m], lbdm.zouter);
      for(int k=0; k<lbsy.nf; k++) {
        double psi = lbft[spos * lbsy.nf + k];
        factor0[k] += lbvwx[m] * psi;
        factor1[k] += lbvwy[m] * psi;
        factor2[k] += lbvwz[m] * psi;
        factor3[k] += lbvwx[m] * psi * psi;
        factor4[k] += lbvwy[m] * psi * psi;
        factor5[k] += lbvwz[m] * psi * psi;
      }
    }
    for(int k=0; k<lbsy.nf; k++) {
      double psik = fCppAbs(lbft[tpos*lbsy.nf+k]);
      for(int j=0; j<lbsy.nf; j++) {
        double betakj = lbscquad[k*lbsy.nf+j];
        double gfluid1 = lbg[k*lbsy.nf+j]*psik*betakj;
        double gfluid2 = 0.5*lbg[k*lbsy.nf+j]*(1.0-betakj);
        lbinterforce[tpos*3*lbsy.nf+3*k]  -=(gfluid1*factor0[j]+gfluid2*factor3[j]);
        lbinterforce[tpos*3*lbsy.nf+3*k+1]-=(gfluid1*factor1[j]+gfluid2*factor4[j]);
        lbinterforce[tpos*3*lbsy.nf+3*k+2]-=(gfluid1*factor2[j]+gfluid2*factor5[j]);
      }
    }
  }
  else {
    for(int m=1; m<lbsy.nq; m++) {
      spos = (fCppMod(xpos+lbvx[m], lbdm.xouter)  * lbdm.youter
            + fCppMod(ypos+lbvy[m], lbdm.youter)) * lbdm.zouter
            + fCppMod(zpos+lbvz[m], lbdm.zouter);
      for(int k=0; k<lbsy.nf; k++) {
        double psi = lbft[spos * lbsy.nf + k];
        factor0[k] += lbvwx[m] * psi;
        factor1[k] += lbvwy[m] * psi;
        factor2[k] += lbvwz[m] * psi;
        factor3[k] += lbvwx[m] * psi * psi;
        factor4[k] += lbvwy[m] * psi * psi;
        factor5[k] += lbvwz[m] * psi * psi;
      }
      double spsi = (lbneigh[tpos]>0 && lbphi[spos]>10);
      wfactor0 += lbvwx[m] * spsi;
      wfactor1 += lbvwy[m] * spsi;
      wfactor2 += lbvwz[m] * spsi;
    }
    for(int k=0; k<lbsy.nf; k++) {
      int wettyp = lbwet[k];
      double psik = fCppAbs(lbft[tpos*lbsy.nf+k]);
      for(int j=0; j<lbsy.nf; j++) {
        double betakj = lbscquad[k*lbsy.nf+j];
        double gfluid1 = lbg[k*lbsy.nf+j]*psik*betakj;
        double gfluid2 = 0.5*lbg[k*lbsy.nf+j]*(1.0-betakj);
        lbinterforce[tpos*3*lbsy.nf+3*k]  -=(gfluid1*factor0[j]+gfluid2*factor3[j]);
        lbinterforce[tpos*3*lbsy.nf+3*k+1]-=(gfluid1*factor1[j]+gfluid2*factor4[j]);
        lbinterforce[tpos*3*lbsy.nf+3*k+2]-=(gfluid1*factor2[j]+gfluid2*factor5[j]);
      }
      gwall = 0.0;
      switch (wettyp) {
        case 0:
        // Martys-Chen (1996): density-based wetting
          gwall = lbgwall[k]*fGetOneMassSite(k, tpos);
          break;
        case 1:
        // Raiskinmaki et al. (2000): pseudopotential-based wetting
          gwall = lbgwall[k]*psik;
          break;
        case 2:
        // Li et al. (2014): pseudopotential-based wetting with position-dependent screening
          phi = psik;
          gwall = lbgwall[k]*psik*phi;
          break;
      }
      lbinterforce[tpos*3*lbsy.nf+3*k]  -=gwall*wfactor0;
      lbinterforce[tpos*3*lbsy.nf+3*k+1]-=gwall*wfactor1;
      lbinterforce[tpos*3*lbsy.nf+3*k+2]-=gwall*wfactor2;
    }
  }
  return 0;
}


int fInteractionForceShanChen()
{
  unsigned long il, i, j, k;
  unsigned long Xmax = (unsigned long) lbdm.xouter,
                Ymax = (unsigned long) lbdm.youter,
                Zmax = (unsigned long) lbdm.zouter;

#pragma omp parallel
  {
    #pragma omp for private(i,j,k,il) collapse(2)
    for(i=lbdm.owidx; i<(Xmax-lbdm.owidx); i++)
      for(j=lbdm.owidy; j<(Ymax-lbdm.owidy); j++)
        for(k=lbdm.owidz; k<(Zmax-lbdm.owidz); k++) {
          il = (i * Ymax + j) * Zmax + k;
          if(lbphi[il] == 0)
            fCalcInteraction_ShanChen((int) i, (int) j, (int) k);
      }

  }
  return 0;
}


int fsInteractionForceShanChen()
{
  unsigned long il, i, j, k;
  unsigned long Xmax = (unsigned long) lbdm.xouter,
                Ymax = (unsigned long) lbdm.youter,
                Zmax = (unsigned long) lbdm.zouter;

#pragma omp parallel
  {
    #pragma omp for
    for(i=0; i<lboutersize; i++) {
      if (lbphi[lbouter[4*i]] == 0)
        fCalcInteraction_ShanChen_Boundary((int) lbouter[4*i+1], (int) lbouter[4*i+2], (int) lbouter[4*i+3]);
    }
    #pragma omp for private(i,j,k,il) collapse(2)
    for(i=lbdm.owidx; i<(Xmax-lbdm.owidx); i++)
      for(j=lbdm.owidy; j<(Ymax-lbdm.owidy); j++)
        for(k=lbdm.owidz; k<(Zmax-lbdm.owidz); k++) {
          il = (i * Ymax + j) * Zmax + k;
          if(lbphi[il] == 0)
            fCalcInteraction_ShanChen((int) i, (int) j, (int) k);
      }

  }
  return 0;
}


int fInteractionForceShanChenQuadratic()
{
  unsigned long il, i, j, k;
  unsigned long Xmax = (unsigned long) lbdm.xouter,
                Ymax = (unsigned long) lbdm.youter,
                Zmax = (unsigned long) lbdm.zouter;

#pragma omp parallel
  {
    #pragma omp for private(i,j,k,il) collapse(2)
    for(i=lbdm.owidx; i<(Xmax-lbdm.owidx); i++)
      for(j=lbdm.owidy; j<(Ymax-lbdm.owidy); j++)
        for(k=lbdm.owidz; k<(Zmax-lbdm.owidz); k++) {
          il = (i * Ymax + j) * Zmax + k;
          if(lbphi[il] == 0)
            fCalcInteraction_ShanChenQuadratic((int) i, (int) j, (int) k);
      }

  }
  return 0;
}


int fsInteractionForceShanChenQuadratic()
{
  unsigned long il, i, j, k;
  unsigned long Xmax = (unsigned long) lbdm.xouter,
                Ymax = (unsigned long) lbdm.youter,
                Zmax = (unsigned long) lbdm.zouter;

#pragma omp parallel
  {
    #pragma omp for
    for(i=0; i<lboutersize; i++) {
      if (lbphi[lbouter[4*i]] == 0)
        fCalcInteraction_ShanChenQuadratic_Boundary((int) lbouter[4*i+1], (int) lbouter[4*i+2], (int) lbouter[4*i+3]);
    }
    #pragma omp for private(i,j,k,il) collapse(2)
    for(i=lbdm.owidx; i<(Xmax-lbdm.owidx); i++)
      for(j=lbdm.owidy; j<(Ymax-lbdm.owidy); j++)
        for(k=lbdm.owidz; k<(Zmax-lbdm.owidz); k++) {
          il = (i * Ymax + j) * Zmax + k;
          if(lbphi[il] == 0)
            fCalcInteraction_ShanChenQuadratic((int) i, (int) j, (int) k);
      }

  }
  return 0;
}


int fCalcPhaseIndex_Lishchuk()
{
  // calculate interfacial normals (first-order derivatives of phase indices)

  int numpair = lbsy.nf*(lbsy.nf-1)/2;
  double rhoi, rhoj;
  double *rhoN = new double[numpair*lbdm.touter];
  double rho[lbsy.nf];

  for(unsigned long il=0; il<lbdm.touter; il++) {
    fGetAllMassSite(rho, &lbf[il*lbsitelength]);
    for(int pair=0; pair<numpair; pair++) {
      int ii=lbspair[2*pair  ];
      int jj=lbspair[2*pair+1];
      rhoi = rho[ii];
      rhoj = rho[jj];
      rhoN[il*numpair+pair] = (rhoi-rhoj)*fReciprocal(rhoi+rhoj);
    }
  }
    
#pragma omp parallel
  {
    long Xmax = (long) lbdm.xouter,
         Ymax = (long) lbdm.youter,
         Zmax = (long) lbdm.zouter;
    double rrhoN, rhox, rhoy, rhoz;
    int nxyz,dx,dy,dz;
    unsigned long i,j,k,spos,spos1,spos2,tpos;
    const double c1 = 4.0/3.0;
    const double c2 = 1.0/6.0;

    #pragma omp for private(i,j,k,dx,dy,dz,nxyz,spos,spos1,spos2,tpos,rhox,rhoy,rhoz,rrhoN) collapse(3)
    for(i=lbdm.owidx; i<(Xmax-lbdm.owidx); i++) {
      for(j=lbdm.owidy; j<(Ymax-lbdm.owidy); j++) {
        for(k=lbdm.owidz; k<(Zmax-lbdm.owidz); k++) {
          tpos = (i * Ymax + j) * Zmax + k;
          if(lbneigh[tpos]>0) {
            dx = lbneigh[tpos]/100;
            dy = (lbneigh[tpos]/10)%10;
            dz = (lbneigh[tpos])%10;
            if(dx==2 || dx==4 || dy==2 || dy==4 || dz==2 || dz==4) {
              for(int pair=0; pair<numpair; pair++) {
                rhox = 0.0; rhoy = 0.0; rhoz = 0.0;
                for(int m=1; m<lbsy.nq; m++) {
                  spos = ((i+lbvx[m])*Ymax + j+lbvy[m])*Zmax + k+lbvz[m];
                  nxyz = !(lbphi[spos]>10);
                  rhox += lbrcssq * lbvwx[m] * rhoN[spos*numpair+pair] * nxyz;
                  rhoy += lbrcssq * lbvwy[m] * rhoN[spos*numpair+pair] * nxyz;
                  rhoz += lbrcssq * lbvwz[m] * rhoN[spos*numpair+pair] * nxyz;
                }
                rrhoN = fReciprocal(sqrt(rhox*rhox+rhoy*rhoy+rhoz*rhoz));
                lbft[3*tpos*numpair+3*pair  ] = rhox*rrhoN;
                lbft[3*tpos*numpair+3*pair+1] = rhoy*rrhoN;
                lbft[3*tpos*numpair+3*pair+2] = rhoz*rrhoN;
              }
            }
            else {
              for(int pair=0; pair<numpair; pair++) {
                rhox = 0.0; rhoy = 0.0; rhoz = 0.0;
                for(int m=1; m<lbsy.nq; m++) {
                  spos1 = ((i+lbvx[m])*Ymax + j+lbvy[m])*Zmax + k+lbvz[m];
                  spos2 = (fCppMod(i+2*lbvx[m], Xmax)*Ymax + fCppMod(j+2*lbvy[m], Ymax))*Zmax + fCppMod(k+2*lbvz[m], Zmax);
                  nxyz = !(lbphi[spos1]>10 || lbphi[spos2]>10);
                  rhox += lbrcssq * lbvwx[m] * (c1*rhoN[spos1*numpair+pair] - c2*rhoN[spos2*numpair+pair]) * nxyz;
                  rhoy += lbrcssq * lbvwy[m] * (c1*rhoN[spos1*numpair+pair] - c2*rhoN[spos2*numpair+pair]) * nxyz;
                  rhoz += lbrcssq * lbvwz[m] * (c1*rhoN[spos1*numpair+pair] - c2*rhoN[spos2*numpair+pair]) * nxyz;
                }
                rrhoN = fReciprocal(sqrt(rhox*rhox+rhoy*rhoy+rhoz*rhoz));
                lbft[3*tpos*numpair+3*pair  ] = rhox*rrhoN;
                lbft[3*tpos*numpair+3*pair+1] = rhoy*rrhoN;
                lbft[3*tpos*numpair+3*pair+2] = rhoz*rrhoN;
              }
            }
          }
          else {
            for(int pair=0; pair<numpair; pair++) {
              rhox = 0.0; rhoy = 0.0; rhoz = 0.0;
              for(int m=1; m<lbsy.nq; m++) {
                spos = ((i+lbvx[m])*Ymax + j+lbvy[m])*Zmax + k+lbvz[m];
                rhox += lbrcssq * lbvwx[m] * rhoN[spos*numpair+pair];
                rhoy += lbrcssq * lbvwy[m] * rhoN[spos*numpair+pair];
                rhoz += lbrcssq * lbvwz[m] * rhoN[spos*numpair+pair];
              }
              rrhoN = fReciprocal(sqrt(rhox*rhox+rhoy*rhoy+rhoz*rhoz));
              lbft[3*tpos*numpair+3*pair  ] = rhox*rrhoN;
              lbft[3*tpos*numpair+3*pair+1] = rhoy*rrhoN;
              lbft[3*tpos*numpair+3*pair+2] = rhoz*rrhoN;
            }
          }
        }
      }
    }
  }
    
  delete [] rhoN;
  return 0;
}

int fsCalcPhaseIndex_Lishchuk()
{
  // calculate interfacial normals (first-order derivatives of phase indices)

  int numpair = lbsy.nf*(lbsy.nf-1)/2;
  double rhoi, rhoj;
  double *rhoN = new double[numpair*lbdm.touter];
  double rho[lbsy.nf];

  for(unsigned long il=0; il<lbdm.touter; il++) {
    fGetAllMassSite(rho, &lbf[il*lbsitelength]);
    for(int pair=0; pair<numpair; pair++) {
      int ii=lbspair[2*pair  ];
      int jj=lbspair[2*pair+1];
      rhoi = rho[ii];
      rhoj = rho[jj];
      rhoN[il*numpair+pair] = (rhoi-rhoj)*fReciprocal(rhoi+rhoj);
    }
  }
    
#pragma omp parallel
  {
    long Xmax = (long) lbdm.xouter,
         Ymax = (long) lbdm.youter,
         Zmax = (long) lbdm.zouter;
    double rrhoN, rhox, rhoy, rhoz;
    int nxyz,dx,dy,dz;
    unsigned long i,j,k,spos,spos1,spos2,tpos;
    const double c1 = 4.0/3.0;
    const double c2 = 1.0/6.0;

    #pragma omp for private(i,j,k,dx,dy,dz,nxyz,spos,spos1,spos2,tpos,rhox,rhoy,rhoz,rrhoN)
    for(unsigned long il=0; il<lboutersize; il++) {
      tpos = lbouter[4*il];
      i = lbouter[4*il+1];
      j = lbouter[4*il+2];
      k = lbouter[4*il+3];
      if(lbneigh[tpos]>0) {
        dx = lbneigh[tpos]/100;
        dy = (lbneigh[tpos]/10)%10;
        dz = (lbneigh[tpos])%10;
        if(dx==2 || dx==4 || dy==2 || dy==4 || dz==2 || dz==4) {
          for(int pair=0; pair<numpair; pair++) {
            rhox = 0.0; rhoy = 0.0; rhoz = 0.0;
            for(int m=1; m<lbsy.nq; m++) {
              spos = (fCppMod(i+lbvx[m], Xmax)  * Ymax +
                      fCppMod(j+lbvy[m], Ymax)) * Zmax +
                      fCppMod(k+lbvz[m], Zmax);
              nxyz = !(lbphi[spos]>10);
              rhox += lbrcssq * lbvwx[m] * rhoN[spos*numpair+pair] * nxyz;
              rhoy += lbrcssq * lbvwy[m] * rhoN[spos*numpair+pair] * nxyz;
              rhoz += lbrcssq * lbvwz[m] * rhoN[spos*numpair+pair] * nxyz;
            }
            rrhoN = fReciprocal(sqrt(rhox*rhox+rhoy*rhoy+rhoz*rhoz));
            lbft[3*tpos*numpair+3*pair  ] = rhox*rrhoN;
            lbft[3*tpos*numpair+3*pair+1] = rhoy*rrhoN;
            lbft[3*tpos*numpair+3*pair+2] = rhoz*rrhoN;
          }
        }
        else {
          for(int pair=0; pair<numpair; pair++) {
            rhox = 0.0; rhoy = 0.0; rhoz = 0.0;
            for(int m=1; m<lbsy.nq; m++) {
              spos1 = (fCppMod(i+lbvx[m], Xmax)  * Ymax +
                       fCppMod(j+lbvy[m], Ymax)) * Zmax +
                       fCppMod(k+lbvz[m], Zmax);
              spos2 = (fCppMod(i+2*lbvx[m], Xmax)  * Ymax +
                       fCppMod(j+2*lbvy[m], Ymax)) * Zmax +
                       fCppMod(k+2*lbvz[m], Zmax);
              nxyz = !(lbphi[spos1]>10 || lbphi[spos2]>10);
              rhox += lbrcssq * lbvwx[m] * (c1*rhoN[spos1*numpair+pair] - c2*rhoN[spos2*numpair+pair]) * nxyz;
              rhoy += lbrcssq * lbvwy[m] * (c1*rhoN[spos1*numpair+pair] - c2*rhoN[spos2*numpair+pair]) * nxyz;
              rhoz += lbrcssq * lbvwz[m] * (c1*rhoN[spos1*numpair+pair] - c2*rhoN[spos2*numpair+pair]) * nxyz;
            }
            rrhoN = fReciprocal(sqrt(rhox*rhox+rhoy*rhoy+rhoz*rhoz));
            lbft[3*tpos*numpair+3*pair  ] = rhox*rrhoN;
            lbft[3*tpos*numpair+3*pair+1] = rhoy*rrhoN;
            lbft[3*tpos*numpair+3*pair+2] = rhoz*rrhoN;
          }
        }
      }
      else {
        for(int pair=0; pair<numpair; pair++) {
          rhox = 0.0; rhoy = 0.0; rhoz = 0.0;
          for(int m=1; m<lbsy.nq; m++) {
            spos = (fCppMod(i+lbvx[m], Xmax)  * Ymax +
                    fCppMod(j+lbvy[m], Ymax)) * Zmax +
                    fCppMod(k+lbvz[m], Zmax);
            rhox += lbrcssq * lbvwx[m] * rhoN[spos*numpair+pair];
            rhoy += lbrcssq * lbvwy[m] * rhoN[spos*numpair+pair];
            rhoz += lbrcssq * lbvwz[m] * rhoN[spos*numpair+pair];
          }
          rrhoN = fReciprocal(sqrt(rhox*rhox+rhoy*rhoy+rhoz*rhoz));
          lbft[3*tpos*numpair+3*pair  ] = rhox*rrhoN;
          lbft[3*tpos*numpair+3*pair+1] = rhoy*rrhoN;
          lbft[3*tpos*numpair+3*pair+2] = rhoz*rrhoN;
        }
      }
    }

    #pragma omp for private(i,j,k,dx,dy,dz,nxyz,spos,spos1,spos2,tpos,rhox,rhoy,rhoz,rrhoN) collapse(3)
    for(i=lbdm.owidx; i<(Xmax-lbdm.owidx); i++) {
      for(j=lbdm.owidy; j<(Ymax-lbdm.owidy); j++) {
        for(k=lbdm.owidz; k<(Zmax-lbdm.owidz); k++) {
          tpos = (i * Ymax + j) * Zmax + k;
          if(lbneigh[tpos]>0) {
            dx = lbneigh[tpos]/100;
            dy = (lbneigh[tpos]/10)%10;
            dz = (lbneigh[tpos])%10;
            if(dx==2 || dx==4 || dy==2 || dy==4 || dz==2 || dz==4) {
              for(int pair=0; pair<numpair; pair++) {
                rhox = 0.0; rhoy = 0.0; rhoz = 0.0;
                for(int m=1; m<lbsy.nq; m++) {
                  spos = ((i+lbvx[m])*Ymax + j+lbvy[m])*Zmax + k+lbvz[m];
                  nxyz = !(lbphi[spos]>10);
                  rhox += lbrcssq * lbvwx[m] * rhoN[spos*numpair+pair] * nxyz;
                  rhoy += lbrcssq * lbvwy[m] * rhoN[spos*numpair+pair] * nxyz;
                  rhoz += lbrcssq * lbvwz[m] * rhoN[spos*numpair+pair] * nxyz;
                }
                rrhoN = fReciprocal(sqrt(rhox*rhox+rhoy*rhoy+rhoz*rhoz));
                lbft[3*tpos*numpair+3*pair  ] = rhox*rrhoN;
                lbft[3*tpos*numpair+3*pair+1] = rhoy*rrhoN;
                lbft[3*tpos*numpair+3*pair+2] = rhoz*rrhoN;
              }
            }
            else {
              for(int pair=0; pair<numpair; pair++) {
                rhox = 0.0; rhoy = 0.0; rhoz = 0.0;
                for(int m=1; m<lbsy.nq; m++) {
                  spos1 = ((i+lbvx[m])*Ymax + j+lbvy[m])*Zmax + k+lbvz[m];
                  spos2 = (fCppMod(i+2*lbvx[m], Xmax)*Ymax + fCppMod(j+2*lbvy[m], Ymax))*Zmax + fCppMod(k+2*lbvz[m], Zmax);
                  nxyz = !(lbphi[spos1]>10 || lbphi[spos2]>10);
                  rhox += lbrcssq * lbvwx[m] * (c1*rhoN[spos1*numpair+pair] - c2*rhoN[spos2*numpair+pair]) * nxyz;
                  rhoy += lbrcssq * lbvwy[m] * (c1*rhoN[spos1*numpair+pair] - c2*rhoN[spos2*numpair+pair]) * nxyz;
                  rhoz += lbrcssq * lbvwz[m] * (c1*rhoN[spos1*numpair+pair] - c2*rhoN[spos2*numpair+pair]) * nxyz;
                }
                rrhoN = fReciprocal(sqrt(rhox*rhox+rhoy*rhoy+rhoz*rhoz));
                lbft[3*tpos*numpair+3*pair  ] = rhox*rrhoN;
                lbft[3*tpos*numpair+3*pair+1] = rhoy*rrhoN;
                lbft[3*tpos*numpair+3*pair+2] = rhoz*rrhoN;
              }
            }
          }
          else {
            for(int pair=0; pair<numpair; pair++) {
              rhox = 0.0; rhoy = 0.0; rhoz = 0.0;
              for(int m=1; m<lbsy.nq; m++) {
                spos = ((i+lbvx[m])*Ymax + j+lbvy[m])*Zmax + k+lbvz[m];
                rhox += lbrcssq * lbvwx[m] * rhoN[spos*numpair+pair];
                rhoy += lbrcssq * lbvwy[m] * rhoN[spos*numpair+pair];
                rhoz += lbrcssq * lbvwz[m] * rhoN[spos*numpair+pair];
              }
              rrhoN = fReciprocal(sqrt(rhox*rhox+rhoy*rhoy+rhoz*rhoz));
              lbft[3*tpos*numpair+3*pair  ] = rhox*rrhoN;
              lbft[3*tpos*numpair+3*pair+1] = rhoy*rrhoN;
              lbft[3*tpos*numpair+3*pair+2] = rhoz*rrhoN;
            }
          }
        }
      }
    }
  }
    
  delete [] rhoN;
  return 0;
}


int fCalcPhaseIndex_LishchukLocal()
{
  // calculate interfacial normals using local approximation
  
#pragma omp parallel
  {
    int numpair = lbsy.nf*(lbsy.nf-1)/2;
    int qdim=lbsy.nf+lbsy.nc+lbsy.nt;
    double rhoi, rhoj, rhoN, rrhoN, rhox, rhoy, rhoz;
    const double epsilon=0.0005;
    const double threshold=(1.0-epsilon);

    #pragma omp for private(rhox,rhoy,rhoz,rhoN,rrhoN,rhoi,rhoj)
    for(long il=0; il<lbdm.touter; il++) {
      for (int pair=0; pair<numpair; pair++) {
        int ii=lbspair[2*pair  ];
        int jj=lbspair[2*pair+1];
        rhox = 0.0; rhoy = 0.0; rhoz = 0.0;
        rhoi = fGetOneMassSite(ii, il);
        rhoj = fGetOneMassSite(jj, il);
        rrhoN = fCppAbs((rhoi-rhoj)*fReciprocal(rhoi+rhoj));
        if(lbphi[il]<11 && rrhoN<=threshold) {
          for(int m=1; m<lbsy.nq; m++) {
            rhoi = lbf[il*lbsitelength + m*qdim + ii];
            rhoj = lbf[il*lbsitelength + m*qdim + jj];
            rhoN = (rhoi-rhoj) * fReciprocal(rhoi+rhoj);
            rhox -= lbrcssq * lbvwx[m] * rhoN;
            rhoy -= lbrcssq * lbvwy[m] * rhoN;
            rhoz -= lbrcssq * lbvwz[m] * rhoN;
          }
        }
        rrhoN = fReciprocal(sqrt(rhox*rhox+rhoy*rhoy+rhoz*rhoz));
        lbft[3*il*numpair+3*pair  ] = rhox * rrhoN;
        lbft[3*il*numpair+3*pair+1] = rhoy * rrhoN;
        lbft[3*il*numpair+3*pair+2] = rhoz * rrhoN;
      }
    }
  }
  return 0;
}


int fCalcInteraction_Lishchuk(int xpos, int ypos, int zpos)
{
  long spos, spos1, spos2, tpos;
  double allmass, invallmass, kurv, delrhoN, rhoNx, rhoNy, rhoNz, nx, ny, nz, wx, wy, wz;
  double rho[lbsy.nf];
  int pair, nxyz, dx, dy, dz;
  int numpair = lbsy.nf*(lbsy.nf-1)/2;
  double dnxdx, dnxdy, dnxdz, dnydx, dnydy, dnydz, dnzdx, dnzdy, dnzdz;
  const double c1 = 4.0/3.0;
  const double c2 = 1.0/6.0;

  tpos = (xpos * lbdm.youter + ypos) * lbdm.zouter + zpos;
  fGetAllMassSite(rho, &lbf[tpos*lbsitelength]);
  allmass = fGetTotMassSite(&lbf[tpos*lbsitelength]);
  invallmass = fReciprocal(allmass);
  if(lbneigh[tpos]>0) {
    dx = lbneigh[tpos]/100;
    dy = (lbneigh[tpos]/10)%10;
    dz = (lbneigh[tpos])%10;
    for(pair=0; pair<numpair; pair++) {
      int k=lbspair[2*pair  ];
      int j=lbspair[2*pair+1];
      delrhoN = 2.0*lbg[k*lbsy.nf+j]*lbseg[lbsy.nf*k+j]*rho[j]*rho[k]*invallmass*invallmass*invallmass;
      dnxdx = 0.0; dnxdy = 0.0; dnxdz = 0.0;
      dnydx = 0.0; dnydy = 0.0; dnydz = 0.0;
      dnzdx = 0.0; dnzdy = 0.0; dnzdz = 0.0;
      if(dx==2 || dx==4 || dy==2 || dy==4 || dz==2 || dz==4) {
        for(int m=1; m<lbsy.nq; m++) {
          spos = ((xpos+lbvx[m])*lbdm.youter + ypos+lbvy[m])*lbdm.zouter + zpos+lbvz[m];
          nxyz = !(lbphi[spos]>10);
          rhoNx = lbrcssq*lbft[3*spos*numpair+3*pair  ];
          rhoNy = lbrcssq*lbft[3*spos*numpair+3*pair+1];
          rhoNz = lbrcssq*lbft[3*spos*numpair+3*pair+2];
          dnxdx += lbvwx[m] * rhoNx * nxyz;
          dnxdy += lbvwy[m] * rhoNx * nxyz;
          dnxdz += lbvwz[m] * rhoNx * nxyz;
          dnydx += lbvwx[m] * rhoNy * nxyz;
          dnydy += lbvwy[m] * rhoNy * nxyz;
          dnydz += lbvwz[m] * rhoNy * nxyz;
          dnzdx += lbvwx[m] * rhoNz * nxyz;
          dnzdy += lbvwy[m] * rhoNz * nxyz;
          dnzdz += lbvwz[m] * rhoNz * nxyz;
        }
      }
      else {
        for(int m=1; m<lbsy.nq; m++) {
          spos1 = ((xpos+lbvx[m])*lbdm.youter + ypos+lbvy[m])*lbdm.zouter + zpos+lbvz[m];
          spos2 = (fCppMod(xpos+2*lbvx[m], lbdm.xouter)*lbdm.youter + fCppMod(ypos+2*lbvy[m], lbdm.youter))*lbdm.zouter
                 + fCppMod(zpos+2*lbvz[m], lbdm.zouter);
          nxyz = !(lbphi[spos1]>10 || lbphi[spos2]>10);
          rhoNx = lbrcssq*(c1*lbft[3*spos1*numpair+3*pair  ]-c2*lbft[3*spos2*numpair+3*pair  ]);
          rhoNy = lbrcssq*(c1*lbft[3*spos1*numpair+3*pair+1]-c2*lbft[3*spos2*numpair+3*pair+1]);
          rhoNz = lbrcssq*(c1*lbft[3*spos1*numpair+3*pair+2]-c2*lbft[3*spos2*numpair+3*pair+2]);
          dnxdx += lbvwx[m] * rhoNx * nxyz;
          dnxdy += lbvwy[m] * rhoNx * nxyz;
          dnxdz += lbvwz[m] * rhoNx * nxyz;
          dnydx += lbvwx[m] * rhoNy * nxyz;
          dnydy += lbvwy[m] * rhoNy * nxyz;
          dnydz += lbvwz[m] * rhoNy * nxyz;
          dnzdx += lbvwx[m] * rhoNz * nxyz;
          dnzdy += lbvwy[m] * rhoNz * nxyz;
          dnzdz += lbvwz[m] * rhoNz * nxyz;
        }
      }
      nx = lbft[3*tpos*numpair+3*pair  ];
      ny = lbft[3*tpos*numpair+3*pair+1];
      nz = lbft[3*tpos*numpair+3*pair+2];
      kurv = nx*ny*(dnxdy+dnydx) + nx*nz*(dnxdz+dnzdx) + ny*nz*(dnydz+dnzdy)
           - (ny*ny+nz*nz)*dnxdx - (nx*nx+nz*nz)*dnydy - (nx*nx+ny*ny)*dnzdz;
      lbinterforce[3*tpos  ] += delrhoN*nx*kurv;
      lbinterforce[3*tpos+1] += delrhoN*ny*kurv;
      lbinterforce[3*tpos+2] += delrhoN*nz*kurv;
    }
  // boundary wetting forces along surface (based on species 0 as background fluid)
    for(int i=1; i<lbsy.nf; i++) {
      delrhoN = 2.0*lbgwall[i]*lbseg[i]*rho[0]*rho[i]*invallmass*invallmass*invallmass;
      nx = lbft[3*tpos*numpair+3*(i-1)  ];
      ny = lbft[3*tpos*numpair+3*(i-1)+1];
      nz = lbft[3*tpos*numpair+3*(i-1)+2];
      wx = lbboundnorm[3*tpos  ];
      wy = lbboundnorm[3*tpos+1];
      wz = lbboundnorm[3*tpos+2];
      kurv = nx*wx + ny*wy + nz*wz;
      lbinterforce[3*tpos  ] -= delrhoN*(nx-wx*kurv);
      lbinterforce[3*tpos+1] -= delrhoN*(ny-wy*kurv);
      lbinterforce[3*tpos+2] -= delrhoN*(nz-wz*kurv);
    }
  }
  else {
    for(pair=0; pair<numpair; pair++) {
      int k=lbspair[2*pair  ];
      int j=lbspair[2*pair+1];
      delrhoN = 2.0*lbg[k*lbsy.nf+j]*lbseg[lbsy.nf*k+j]*rho[j]*rho[k]*invallmass*invallmass*invallmass;
      dnxdx = 0.0; dnxdy = 0.0; dnxdz = 0.0;
      dnydx = 0.0; dnydy = 0.0; dnydz = 0.0;
      dnzdx = 0.0; dnzdy = 0.0; dnzdz = 0.0;
      for(int m=1; m<lbsy.nq; m++) {
        spos = ((xpos+lbvx[m])*lbdm.youter + ypos+lbvy[m])*lbdm.zouter + zpos+lbvz[m];
        rhoNx = lbrcssq*lbft[3*spos*numpair+3*pair  ];
        rhoNy = lbrcssq*lbft[3*spos*numpair+3*pair+1];
        rhoNz = lbrcssq*lbft[3*spos*numpair+3*pair+2];
        dnxdx += lbvwx[m] * rhoNx;
        dnxdy += lbvwy[m] * rhoNx;
        dnxdz += lbvwz[m] * rhoNx;
        dnydx += lbvwx[m] * rhoNy;
        dnydy += lbvwy[m] * rhoNy;
        dnydz += lbvwz[m] * rhoNy;
        dnzdx += lbvwx[m] * rhoNz;
        dnzdy += lbvwy[m] * rhoNz;
        dnzdz += lbvwz[m] * rhoNz;
      }
      nx = lbft[3*tpos*numpair+3*pair  ];
      ny = lbft[3*tpos*numpair+3*pair+1];
      nz = lbft[3*tpos*numpair+3*pair+2];
      kurv = nx*ny*(dnxdy+dnydx) + nx*nz*(dnxdz+dnzdx) + ny*nz*(dnydz+dnzdy)
           - (ny*ny+nz*nz)*dnxdx - (nx*nx+nz*nz)*dnydy - (nx*nx+ny*ny)*dnzdz;
      lbinterforce[3*tpos  ] += delrhoN*nx*kurv;
      lbinterforce[3*tpos+1] += delrhoN*ny*kurv;
      lbinterforce[3*tpos+2] += delrhoN*nz*kurv;
    }
  }

  return 0;
}

int fCalcInteraction_Lishchuk_Boundary(int xpos, int ypos, int zpos)
{
  long spos, spos1, spos2, tpos;
  double allmass, invallmass, kurv, delrhoN, rhoNx, rhoNy, rhoNz, nx, ny, nz, wx, wy, wz;
  double rho[lbsy.nf];
  int pair, nxyz, dx, dy, dz;
  int numpair = lbsy.nf*(lbsy.nf-1)/2;
  double dnxdx, dnxdy, dnxdz, dnydx, dnydy, dnydz, dnzdx, dnzdy, dnzdz;
  const double c1 = 4.0/3.0;
  const double c2 = 1.0/6.0;

  tpos = (xpos * lbdm.youter + ypos) * lbdm.zouter + zpos;
  fGetAllMassSite(rho, &lbf[tpos*lbsitelength]);
  allmass = fGetTotMassSite(&lbf[tpos*lbsitelength]);
  invallmass = fReciprocal(allmass);
  if(lbneigh[tpos]>0) {
    dx = lbneigh[tpos]/100;
    dy = (lbneigh[tpos]/10)%10;
    dz = (lbneigh[tpos])%10;
    for(pair=0; pair<numpair; pair++) {
      int k=lbspair[2*pair  ];
      int j=lbspair[2*pair+1];
      delrhoN = 2.0*lbg[k*lbsy.nf+j]*lbseg[lbsy.nf*k+j]*rho[j]*rho[k]*invallmass*invallmass*invallmass;
      dnxdx = 0.0; dnxdy = 0.0; dnxdz = 0.0;
      dnydx = 0.0; dnydy = 0.0; dnydz = 0.0;
      dnzdx = 0.0; dnzdy = 0.0; dnzdz = 0.0;
      if(dx==2 || dx==4 || dy==2 || dy==4 || dz==2 || dz==4) {
        for(int m=1; m<lbsy.nq; m++) {
          spos = (fCppMod(xpos+lbvx[m], lbdm.xouter)  * lbdm.youter +
                  fCppMod(ypos+lbvy[m], lbdm.youter)) * lbdm.zouter +
                  fCppMod(zpos+lbvz[m], lbdm.zouter);
          nxyz = !(lbphi[spos]>10);
          rhoNx = lbrcssq*lbft[3*spos*numpair+3*pair  ];
          rhoNy = lbrcssq*lbft[3*spos*numpair+3*pair+1];
          rhoNz = lbrcssq*lbft[3*spos*numpair+3*pair+2];
          dnxdx += lbvwx[m] * rhoNx * nxyz;
          dnxdy += lbvwy[m] * rhoNx * nxyz;
          dnxdz += lbvwz[m] * rhoNx * nxyz;
          dnydx += lbvwx[m] * rhoNy * nxyz;
          dnydy += lbvwy[m] * rhoNy * nxyz;
          dnydz += lbvwz[m] * rhoNy * nxyz;
          dnzdx += lbvwx[m] * rhoNz * nxyz;
          dnzdy += lbvwy[m] * rhoNz * nxyz;
          dnzdz += lbvwz[m] * rhoNz * nxyz;
        }
      }
      else {
        for(int m=1; m<lbsy.nq; m++) {
          spos1 = (fCppMod(xpos+lbvx[m], lbdm.xouter)  * lbdm.youter +
                   fCppMod(ypos+lbvy[m], lbdm.youter)) * lbdm.zouter +
                   fCppMod(zpos+lbvz[m], lbdm.zouter);
          spos2 = (fCppMod(xpos+2*lbvx[m], lbdm.xouter)  * lbdm.youter +
                   fCppMod(ypos+2*lbvy[m], lbdm.youter)) * lbdm.zouter +
                   fCppMod(zpos+2*lbvz[m], lbdm.zouter);
          nxyz = !(lbphi[spos1]>10 || lbphi[spos2]>10);
          rhoNx = lbrcssq*(c1*lbft[3*spos1*numpair+3*pair  ]-c2*lbft[3*spos2*numpair+3*pair  ]);
          rhoNy = lbrcssq*(c1*lbft[3*spos1*numpair+3*pair+1]-c2*lbft[3*spos2*numpair+3*pair+1]);
          rhoNz = lbrcssq*(c1*lbft[3*spos1*numpair+3*pair+2]-c2*lbft[3*spos2*numpair+3*pair+2]);
          dnxdx += lbvwx[m] * rhoNx * nxyz;
          dnxdy += lbvwy[m] * rhoNx * nxyz;
          dnxdz += lbvwz[m] * rhoNx * nxyz;
          dnydx += lbvwx[m] * rhoNy * nxyz;
          dnydy += lbvwy[m] * rhoNy * nxyz;
          dnydz += lbvwz[m] * rhoNy * nxyz;
          dnzdx += lbvwx[m] * rhoNz * nxyz;
          dnzdy += lbvwy[m] * rhoNz * nxyz;
          dnzdz += lbvwz[m] * rhoNz * nxyz;
        }
      }
      nx = lbft[3*tpos*numpair+3*pair  ];
      ny = lbft[3*tpos*numpair+3*pair+1];
      nz = lbft[3*tpos*numpair+3*pair+2];
      kurv = nx*ny*(dnxdy+dnydx) + nx*nz*(dnxdz+dnzdx) + ny*nz*(dnydz+dnzdy)
           - (ny*ny+nz*nz)*dnxdx - (nx*nx+nz*nz)*dnydy - (nx*nx+ny*ny)*dnzdz;
      lbinterforce[3*tpos  ] += delrhoN*nx*kurv;
      lbinterforce[3*tpos+1] += delrhoN*ny*kurv;
      lbinterforce[3*tpos+2] += delrhoN*nz*kurv;
    }
  // boundary wetting forces along surface (based on species 0 as background fluid)
    for(int i=1; i<lbsy.nf; i++) {
      delrhoN = 2.0*lbgwall[i]*lbseg[i]*rho[0]*rho[i]*invallmass*invallmass*invallmass;
      nx = lbft[3*tpos*numpair+3*(i-1)  ];
      ny = lbft[3*tpos*numpair+3*(i-1)+1];
      nz = lbft[3*tpos*numpair+3*(i-1)+2];
      wx = lbboundnorm[3*tpos  ];
      wy = lbboundnorm[3*tpos+1];
      wz = lbboundnorm[3*tpos+2];
      kurv = nx*wx + ny*wy + nz*wz;
      lbinterforce[3*tpos  ] -= delrhoN*(nx-wx*kurv);
      lbinterforce[3*tpos+1] -= delrhoN*(ny-wy*kurv);
      lbinterforce[3*tpos+2] -= delrhoN*(nz-wz*kurv);
    }
  }
  else {
    for(pair=0; pair<numpair; pair++) {
      int k=lbspair[2*pair  ];
      int j=lbspair[2*pair+1];
      delrhoN = 2.0*lbg[k*lbsy.nf+j]*lbseg[lbsy.nf*k+j]*rho[j]*rho[k]*invallmass*invallmass*invallmass;
      dnxdx = 0.0; dnxdy = 0.0; dnxdz = 0.0;
      dnydx = 0.0; dnydy = 0.0; dnydz = 0.0;
      dnzdx = 0.0; dnzdy = 0.0; dnzdz = 0.0;
      for(int m=1; m<lbsy.nq; m++) {
        spos = (fCppMod(xpos + lbvx[m], lbdm.xouter)  * lbdm.youter +
                fCppMod(ypos + lbvy[m], lbdm.youter)) * lbdm.zouter +
                fCppMod(zpos + lbvz[m], lbdm.zouter);
        rhoNx = lbrcssq*lbft[3*spos*numpair+3*pair  ];
        rhoNy = lbrcssq*lbft[3*spos*numpair+3*pair+1];
        rhoNz = lbrcssq*lbft[3*spos*numpair+3*pair+2];
        dnxdx += lbvwx[m] * rhoNx;
        dnxdy += lbvwy[m] * rhoNx;
        dnxdz += lbvwz[m] * rhoNx;
        dnydx += lbvwx[m] * rhoNy;
        dnydy += lbvwy[m] * rhoNy;
        dnydz += lbvwz[m] * rhoNy;
        dnzdx += lbvwx[m] * rhoNz;
        dnzdy += lbvwy[m] * rhoNz;
        dnzdz += lbvwz[m] * rhoNz;
      }
      nx = lbft[3*tpos*numpair+3*pair  ];
      ny = lbft[3*tpos*numpair+3*pair+1];
      nz = lbft[3*tpos*numpair+3*pair+2];
      kurv = nx*ny*(dnxdy+dnydx) + nx*nz*(dnxdz+dnzdx) + ny*nz*(dnydz+dnzdy)
           - (ny*ny+nz*nz)*dnxdx - (nx*nx+nz*nz)*dnydy - (nx*nx+ny*ny)*dnzdz;
      lbinterforce[3*tpos  ] += delrhoN*nx*kurv;
      lbinterforce[3*tpos+1] += delrhoN*ny*kurv;
      lbinterforce[3*tpos+2] += delrhoN*nz*kurv;
    }
  }

  return 0;
}


int fCalcInteraction_LishchukSpencer(int xpos, int ypos, int zpos, double *rho)
{
  long spos, spos1, spos2, tpos;
  double allmass, invallmass, allmass1, invallmass1, allmass2, invallmass2;
  double nx, ny, nz, nx1, nx2, ny1, ny2, nz1, nz2, weight, weight1, weight2;
  int pair, nxyz, dx, dy, dz;
  int numpair = lbsy.nf*(lbsy.nf-1)/2;
  double dkdx, dkdy, dkdz, vwdotn, vwdotn1, vwdotn2, fwallx, fwally, fwallz;
  const double c1 = 4.0/3.0;
  const double c2 = 1.0/6.0;

  tpos = (xpos * lbdm.youter + ypos) * lbdm.zouter + zpos;
  dkdx = 0.0; dkdy = 0.0; dkdz = 0.0;
  fwallx = 0.0; fwally = 0.0; fwallz = 0.0;
  if(lbneigh[tpos]>0) {
    dx = lbneigh[tpos]/100;
    dy = (lbneigh[tpos]/10)%10;
    dz = (lbneigh[tpos])%10;
    if(dx==2 || dx==4 || dy==2 || dy==4 || dz==2 || dz==4) {
      for(int m=1; m<lbsy.nq; m++) {
        spos = ((xpos+lbvx[m])*lbdm.youter + ypos+lbvy[m])*lbdm.zouter + zpos+lbvz[m];
        nxyz = !(lbphi[spos]>10);
        allmass = 0.0;
        for(int n=0; n<lbsy.nf; n++)
          allmass += rho[spos*lbsy.nf+n];
        invallmass = fReciprocal(allmass);
        for(pair=0; pair<numpair; pair++) {
          int k=lbspair[2*pair  ];
          int j=lbspair[2*pair+1];
          weight = lbg[j*lbsy.nf+k]*lbseg[j*lbsy.nf+k]*rho[spos*lbsy.nf+j]*rho[spos*lbsy.nf+k]*invallmass*invallmass*invallmass;
          nx = lbft[3*spos*numpair+3*pair  ];
          ny = lbft[3*spos*numpair+3*pair+1];
          nz = lbft[3*spos*numpair+3*pair+2];
          vwdotn = weight * (lbvwx[m] * nx + lbvwy[m] * ny + lbvwz[m] * nz);
          dkdx += nx * vwdotn * nxyz;
          dkdy += ny * vwdotn * nxyz;
          dkdz += nz * vwdotn * nxyz;
        }
      }
    }
    else {
      for(int m=1; m<lbsy.nq; m++) {
        spos1 = ((xpos+lbvx[m])*lbdm.youter + ypos+lbvy[m])*lbdm.zouter + zpos+lbvz[m];
        spos2 = (fCppMod(xpos+2*lbvx[m], lbdm.xouter)*lbdm.youter + fCppMod(ypos+2*lbvy[m], lbdm.youter))*lbdm.zouter
               + fCppMod(zpos+2*lbvz[m], lbdm.zouter);
        nxyz = !(lbphi[spos1]>10 || lbphi[spos2]>10);
        allmass1 = 0.0; allmass2 = 0.0;
        for(int n=0; n<lbsy.nf; n++) {
          allmass1 += rho[spos1*lbsy.nf+n];
          allmass2 += rho[spos2*lbsy.nf+n];
        }
        invallmass1 = fReciprocal(allmass1);
        invallmass2 = fReciprocal(allmass2);
        for(pair=0; pair<numpair; pair++) {
          int k=lbspair[2*pair  ];
          int j=lbspair[2*pair+1];
          weight1 = c1*lbg[j*lbsy.nf+k]*lbseg[j*lbsy.nf+k]*rho[spos1*lbsy.nf+j]*rho[spos1*lbsy.nf+k]*invallmass1*invallmass1*invallmass1;
          weight2 = c2*lbg[j*lbsy.nf+k]*lbseg[j*lbsy.nf+k]*rho[spos2*lbsy.nf+j]*rho[spos2*lbsy.nf+k]*invallmass2*invallmass2*invallmass2;
          nx1 = lbft[3*spos1*numpair+3*pair  ];
          ny1 = lbft[3*spos1*numpair+3*pair+1];
          nz1 = lbft[3*spos1*numpair+3*pair+2];
          nx2 = lbft[3*spos2*numpair+3*pair  ];
          ny2 = lbft[3*spos2*numpair+3*pair+1];
          nz2 = lbft[3*spos2*numpair+3*pair+2];
          vwdotn1 = weight1 * (lbvwx[m] * nx1 + lbvwy[m] * ny1 + lbvwz[m] * nz1);
          vwdotn2 = weight2 * (lbvwx[m] * nx2 + lbvwy[m] * ny2 + lbvwz[m] * nz2);
          dkdx += (nx1 * vwdotn1 - nx2 * vwdotn2) * nxyz;
          dkdy += (ny1 * vwdotn1 - ny2 * vwdotn2) * nxyz;
          dkdy += (nz1 * vwdotn1 - nz2 * vwdotn2) * nxyz;
        }
      }
    }
  // boundary wetting forces along surface (based on species 0 as background fluid)
    allmass = 0.0;
    for(int n=0; n<lbsy.nf; n++)
      allmass += rho[tpos*lbsy.nf+n];
    invallmass = fReciprocal(allmass);
    for(int i=1; i<lbsy.nf; i++) {
      weight = 2.0*lbgwall[i]*lbseg[i]*rho[tpos*lbsy.nf]*rho[tpos*lbsy.nf+i]*invallmass*invallmass*invallmass;
      nx = lbft[3*tpos*numpair+3*(i-1)  ];
      ny = lbft[3*tpos*numpair+3*(i-1)+1];
      nz = lbft[3*tpos*numpair+3*(i-1)+2];
      nx1 = lbboundnorm[3*tpos  ];
      ny1 = lbboundnorm[3*tpos+1];
      nz1 = lbboundnorm[3*tpos+2];
      weight1 = nx*nx1 + ny*ny1 + nz*nz1;
      fwallx += weight*(nx-nx1*weight1);
      fwally += weight*(ny-ny1*weight1);
      fwallz += weight*(nz-nz1*weight1);
    }
  }
  else {
    for(int m=1; m<lbsy.nq; m++) {
      spos = ((xpos+lbvx[m])*lbdm.youter + ypos+lbvy[m])*lbdm.zouter + zpos+lbvz[m];
      allmass = 0.0;
      for(int n=0; n<lbsy.nf; n++)
        allmass += rho[spos*lbsy.nf+n];
      invallmass = fReciprocal(allmass);
      for(pair=0; pair<numpair; pair++) {
        int k=lbspair[2*pair  ];
        int j=lbspair[2*pair+1];
        weight = lbg[j*lbsy.nf+k]*lbseg[j*lbsy.nf+k]*rho[spos*lbsy.nf+j]*rho[spos*lbsy.nf+k]*invallmass*invallmass*invallmass;
        nx = lbft[3*spos*numpair+3*pair  ];
        ny = lbft[3*spos*numpair+3*pair+1];
        nz = lbft[3*spos*numpair+3*pair+2];
        vwdotn = weight * (lbvwx[m] * nx + lbvwy[m] * ny + lbvwz[m] * nz);
        dkdx += nx * vwdotn;
        dkdy += ny * vwdotn;
        dkdz += nz * vwdotn;
      }
    }
  }
  lbinterforce[3*tpos  ] -= (fwallx+2.0*lbrcssq*dkdx);
  lbinterforce[3*tpos+1] -= (fwally+2.0*lbrcssq*dkdy);
  lbinterforce[3*tpos+2] -= (fwallz+2.0*lbrcssq*dkdz);

  return 0;
}

int fCalcInteraction_LishchukSpencer_Boundary(int xpos, int ypos, int zpos, double *rho)
{
  long spos, spos1, spos2, tpos;
  double allmass, invallmass, allmass1, invallmass1, allmass2, invallmass2;
  double nx, ny, nz, nx1, nx2, ny1, ny2, nz1, nz2, weight, weight1, weight2;
  int pair, nxyz, dx, dy, dz;
  int numpair = lbsy.nf*(lbsy.nf-1)/2;
  double dkdx, dkdy, dkdz, vwdotn, vwdotn1, vwdotn2, fwallx, fwally, fwallz;
  const double c1 = 4.0/3.0;
  const double c2 = 1.0/6.0;

  tpos = (xpos * lbdm.youter + ypos) * lbdm.zouter + zpos;
  dkdx = 0.0; dkdy = 0.0; dkdz = 0.0;
  fwallx = 0.0; fwally = 0.0; fwallz = 0.0;
  if(lbneigh[tpos]>0) {
    dx = lbneigh[tpos]/100;
    dy = (lbneigh[tpos]/10)%10;
    dz = (lbneigh[tpos])%10;
    if(dx==2 || dx==4 || dy==2 || dy==4 || dz==2 || dz==4) {
      for(int m=1; m<lbsy.nq; m++) {
        spos = (fCppMod(xpos+lbvx[m], lbdm.xouter)  * lbdm.youter +
                fCppMod(ypos+lbvy[m], lbdm.youter)) * lbdm.zouter +
                fCppMod(zpos+lbvz[m], lbdm.zouter);
        nxyz = !(lbphi[spos]>10);
        allmass = 0.0;
        for(int n=0; n<lbsy.nf; n++)
          allmass += rho[spos*lbsy.nf+n];
        invallmass = fReciprocal(allmass);
        for(pair=0; pair<numpair; pair++) {
          int k=lbspair[2*pair  ];
          int j=lbspair[2*pair+1];
          weight = lbg[j*lbsy.nf+k]*lbseg[j*lbsy.nf+k]*rho[spos*lbsy.nf+j]*rho[spos*lbsy.nf+k]*invallmass*invallmass*invallmass;
          nx = lbft[3*spos*numpair+3*pair  ];
          ny = lbft[3*spos*numpair+3*pair+1];
          nz = lbft[3*spos*numpair+3*pair+2];
          vwdotn = weight * (lbvwx[m] * nx + lbvwy[m] * ny + lbvwz[m] * nz);
          dkdx += nx * vwdotn * nxyz;
          dkdy += ny * vwdotn * nxyz;
          dkdz += nz * vwdotn * nxyz;
        }
      }
    }
    else {
      for(int m=1; m<lbsy.nq; m++) {
        spos1 = (fCppMod(xpos+lbvx[m], lbdm.xouter)  * lbdm.youter +
                 fCppMod(ypos+lbvy[m], lbdm.youter)) * lbdm.zouter +
                 fCppMod(zpos+lbvz[m], lbdm.zouter);
        spos2 = (fCppMod(xpos+2*lbvx[m], lbdm.xouter)  * lbdm.youter +
                 fCppMod(ypos+2*lbvy[m], lbdm.youter)) * lbdm.zouter
               + fCppMod(zpos+2*lbvz[m], lbdm.zouter);
        nxyz = !(lbphi[spos1]>10 || lbphi[spos2]>10);
        allmass1 = 0.0; allmass2 = 0.0;
        for(int n=0; n<lbsy.nf; n++) {
          allmass1 += rho[spos1*lbsy.nf+n];
          allmass2 += rho[spos2*lbsy.nf+n];
        }
        invallmass1 = fReciprocal(allmass1);
        invallmass2 = fReciprocal(allmass2);
        for(pair=0; pair<numpair; pair++) {
          int k=lbspair[2*pair  ];
          int j=lbspair[2*pair+1];
          weight1 = c1*lbg[j*lbsy.nf+k]*lbseg[j*lbsy.nf+k]*rho[spos1*lbsy.nf+j]*rho[spos1*lbsy.nf+k]*invallmass1*invallmass1*invallmass1;
          weight2 = c2*lbg[j*lbsy.nf+k]*lbseg[j*lbsy.nf+k]*rho[spos2*lbsy.nf+j]*rho[spos2*lbsy.nf+k]*invallmass2*invallmass2*invallmass2;
          nx1 = lbft[3*spos1*numpair+3*pair  ];
          ny1 = lbft[3*spos1*numpair+3*pair+1];
          nz1 = lbft[3*spos1*numpair+3*pair+2];
          nx2 = lbft[3*spos2*numpair+3*pair  ];
          ny2 = lbft[3*spos2*numpair+3*pair+1];
          nz2 = lbft[3*spos2*numpair+3*pair+2];
          vwdotn1 = weight1 * (lbvwx[m] * nx1 + lbvwy[m] * ny1 + lbvwz[m] * nz1);
          vwdotn2 = weight2 * (lbvwx[m] * nx2 + lbvwy[m] * ny2 + lbvwz[m] * nz2);
          dkdx += (nx1 * vwdotn1 - nx2 * vwdotn2) * nxyz;
          dkdy += (ny1 * vwdotn1 - ny2 * vwdotn2) * nxyz;
          dkdy += (nz1 * vwdotn1 - nz2 * vwdotn2) * nxyz;
        }
      }
    }
  // boundary wetting forces along surface (based on species 0 as background fluid)
    allmass = 0.0;
    for(int n=0; n<lbsy.nf; n++)
      allmass += rho[tpos*lbsy.nf+n];
    invallmass = fReciprocal(allmass);
    for(int i=1; i<lbsy.nf; i++) {
      weight = 2.0*lbgwall[i]*lbseg[i]*rho[tpos*lbsy.nf]*rho[tpos*lbsy.nf+i]*invallmass*invallmass*invallmass;
      nx = lbft[3*tpos*numpair+3*(i-1)  ];
      ny = lbft[3*tpos*numpair+3*(i-1)+1];
      nz = lbft[3*tpos*numpair+3*(i-1)+2];
      nx1 = lbboundnorm[3*tpos  ];
      ny1 = lbboundnorm[3*tpos+1];
      nz1 = lbboundnorm[3*tpos+2];
      weight1 = nx*nx1 + ny*ny1 + nz*nz1;
      fwallx += weight*(nx-nx1*weight1);
      fwally += weight*(ny-ny1*weight1);
      fwallz += weight*(nz-nz1*weight1);
    }
  }
  else {
    for(int m=1; m<lbsy.nq; m++) {
      spos = (fCppMod(xpos+lbvx[m], lbdm.xouter)  * lbdm.youter +
              fCppMod(ypos+lbvy[m], lbdm.youter)) * lbdm.zouter +
              fCppMod(zpos+lbvz[m], lbdm.zouter);
      allmass = 0.0;
      for(int n=0; n<lbsy.nf; n++)
        allmass += rho[spos*lbsy.nf+n];
      invallmass = fReciprocal(allmass);
      for(pair=0; pair<numpair; pair++) {
        int k=lbspair[2*pair  ];
        int j=lbspair[2*pair+1];
        weight = lbg[j*lbsy.nf+k]*lbseg[j*lbsy.nf+k]*rho[spos*lbsy.nf+j]*rho[spos*lbsy.nf+k]*invallmass*invallmass*invallmass;
        nx = lbft[3*spos*numpair+3*pair  ];
        ny = lbft[3*spos*numpair+3*pair+1];
        nz = lbft[3*spos*numpair+3*pair+2];
        vwdotn = weight * (lbvwx[m] * nx + lbvwy[m] * ny + lbvwz[m] * nz);
        dkdx += nx * vwdotn;
        dkdy += ny * vwdotn;
        dkdz += nz * vwdotn;
      }
    }
  }
  lbinterforce[3*tpos  ] -= (fwallx+2.0*lbrcssq*dkdx);
  lbinterforce[3*tpos+1] -= (fwally+2.0*lbrcssq*dkdy);
  lbinterforce[3*tpos+2] -= (fwallz+2.0*lbrcssq*dkdz);

  return 0;
}

int fWallInteractionForceLishchukLocal()
{
  // calculate boundary wetting forces for Lishchuk interactions
  // when using Spencer-tensor or local forms: does not need
  // communication of forces before collisions
    
#pragma omp parallel
  {
    int numpair = lbsy.nf*(lbsy.nf-1)/2;
    double rho[lbsy.nf];
    double allmass,invallmass,delrhoN,nx,ny,nz,wx,wy,wz,kurv;

    #pragma omp for private(allmass,invallmass,delrhoN,nx,ny,nz,wx,wy,wz,kurv,rho)
    for(long il=0; il<lbdm.touter; il++) {
      if(lbneigh[il]>0) {
        fGetAllMassSite(rho, &lbf[il*lbsitelength]);
        allmass = fGetTotMassSite(&lbf[il*lbsitelength]);
        invallmass = fReciprocal(allmass);
        for (int jj=1; jj<lbsy.nf; jj++) {
          delrhoN = 2.0*lbgwall[jj]*lbseg[jj]*rho[0]*rho[jj]*invallmass*invallmass*invallmass;
          nx = lbft[3*il*numpair+3*(jj-1)  ];
          ny = lbft[3*il*numpair+3*(jj-1)+1];
          nz = lbft[3*il*numpair+3*(jj-1)+2];
          wx = lbboundnorm[3*il  ];
          wy = lbboundnorm[3*il+1];
          wz = lbboundnorm[3*il+2];
          kurv = nx*wx + ny*wy + nz*wz;
          lbinterforce[3*il  ] -= delrhoN*(nx-wx*kurv);
          lbinterforce[3*il+1] -= delrhoN*(ny-wy*kurv);
          lbinterforce[3*il+2] -= delrhoN*(nz-wz*kurv);
        }
      }
    }
  }
  return 0;
}

int fInteractionForceLishchuk()
{
  unsigned long il, i, j, k;
  unsigned long Xmax = (unsigned long) lbdm.xouter,
                Ymax = (unsigned long) lbdm.youter,
                Zmax = (unsigned long) lbdm.zouter;

#pragma omp parallel
  {
    #pragma omp for private(i,j,k,il) collapse(2)
    for(i=lbdm.owidx; i<(Xmax-lbdm.owidx); i++)
      for(j=lbdm.owidy; j<(Ymax-lbdm.owidy); j++)
        for(k=lbdm.owidz; k<(Zmax-lbdm.owidz); k++) {
          il = (i * Ymax + j) * Zmax + k;
          if(lbphi[il] == 0 || lbphi[il]>100)
            fCalcInteraction_Lishchuk((int) i, (int) j, (int) k);
        }

  }
  return 0;
}


int fsInteractionForceLishchuk()
{
  unsigned long il, i, j, k;
  unsigned long Xmax = (unsigned long) lbdm.xouter,
                Ymax = (unsigned long) lbdm.youter,
                Zmax = (unsigned long) lbdm.zouter;

#pragma omp parallel
  {
    #pragma omp for private(i)
    for(i=0; i<lboutersize; i++) {
      if (lbphi[lbouter[4*i]] == 0 || lbphi[lbouter[4*i]]>100)
        fCalcInteraction_Lishchuk_Boundary((int) lbouter[4*i+1], (int) lbouter[4*i+2], (int) lbouter[4*i+3]);
    }
    #pragma omp for private(i,j,k,il) collapse(2)
    for(i=lbdm.owidx; i<(Xmax-lbdm.owidx); i++)
      for(j=lbdm.owidy; j<(Ymax-lbdm.owidy); j++)
        for(k=lbdm.owidz; k<(Zmax-lbdm.owidz); k++) {
          il = (i * Ymax + j) * Zmax + k;
          if(lbphi[il] == 0 || lbphi[il]>100)
            fCalcInteraction_Lishchuk((int) i, (int) j, (int) k);
        }

  }
  return 0;
}


int fInteractionForceLishchukSpencer()
{
  unsigned long il, i, j, k;
  unsigned long Xmax = (unsigned long) lbdm.xouter,
                Ymax = (unsigned long) lbdm.youter,
                Zmax = (unsigned long) lbdm.zouter;
  double *rho = new double[lbsy.nf*lbdm.touter];

  for(il=0; il<lbdm.touter; il++)
    fGetAllMassSite(&rho[il*lbsy.nf], &lbf[il*lbsitelength]);

#pragma omp parallel
  {
    #pragma omp for private(i,j,k,il) collapse(2)
    for(i=lbdm.owidx; i<(Xmax-lbdm.owidx); i++)
      for(j=lbdm.owidy; j<(Ymax-lbdm.owidy); j++)
        for(k=lbdm.owidz; k<(Zmax-lbdm.owidz); k++) {
          il = (i * Ymax + j) * Zmax + k;
          if(lbphi[il] == 0 || lbphi[il]>100)
            fCalcInteraction_LishchukSpencer((int) i, (int) j, (int) k, rho);
        }

  }
  delete [] rho;
  return 0;
}


int fsInteractionForceLishchukSpencer()
{
  unsigned long il, i, j, k;
  unsigned long Xmax = (unsigned long) lbdm.xouter,
                Ymax = (unsigned long) lbdm.youter,
                Zmax = (unsigned long) lbdm.zouter;
  double *rho = new double[lbsy.nf*lbdm.touter];

  for(il=0; il<lbdm.touter; il++)
    fGetAllMassSite(&rho[il*lbsy.nf], &lbf[il*lbsitelength]);

#pragma omp parallel
  {
    #pragma omp for private(i)
    for(i=0; i<lboutersize; i++) {
      if (lbphi[lbouter[4*i]] == 0 || lbphi[lbouter[4*i]]>100)
        fCalcInteraction_LishchukSpencer_Boundary((int) lbouter[4*i+1], (int) lbouter[4*i+2], (int) lbouter[4*i+3], rho);
    }
    #pragma omp for private(i,j,k,il) collapse(2)
    for(i=lbdm.owidx; i<(Xmax-lbdm.owidx); i++)
      for(j=lbdm.owidy; j<(Ymax-lbdm.owidy); j++)
        for(k=lbdm.owidz; k<(Zmax-lbdm.owidz); k++) {
          il = (i * Ymax + j) * Zmax + k;
          if(lbphi[il] == 0 || lbphi[il]>100)
            fCalcInteraction_LishchukSpencer((int) i, (int) j, (int) k, rho);
        }

  }
  delete [] rho;
  return 0;
}


int fCalcDensityGradient_Swift()
{
  // calculate first-order and second-order derivatives of fluid densities
  
#pragma omp parallel
  {
    double *rho = new double[lbdm.touter];
    double rhox, rhoy, rhoz, rho2, d1, d2, drdb;
    int nx,ny,nz;
    unsigned long i,j,k,il,spos,spos1,spos2,tpos;
    long Xmax = (long) lbdm.xouter,
         Ymax = (long) lbdm.youter,
         Zmax = (long) lbdm.zouter;
    const double third = 1.0/3.0;
    const double sixth = 1.0/6.0;
    const double twelfth = 1.0/12.0;
    double dx [] = {-twelfth, -twelfth, -sixth, -twelfth, -twelfth, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, twelfth, twelfth, sixth, twelfth, twelfth};
    double dy [] = {0.0, -twelfth, 0.0, twelfth, 0.0, -twelfth, 0.0, twelfth, -sixth, 0.0, sixth, -twelfth, 0.0, twelfth, 0.0, -twelfth, 0.0, twelfth, 0.0};
    double dz [] = {-twelfth, 0.0, 0.0, 0.0, twelfth, -twelfth, -sixth, -twelfth, 0.0, 0.0, 0.0, twelfth, sixth, twelfth, -twelfth, 0.0, 0.0, 0.0, twelfth};
    double nabla [] = {sixth, sixth, third, sixth, sixth, sixth, third, sixth, third, -4.0, third, sixth, third, sixth, sixth, sixth, third, sixth, sixth};
    int wettyp = lbwet[0];
      
    for(il=0; il<lbdm.touter; il++) {
      rho[il]=fGetOneMassSite(0, il);
    }
    #pragma omp for private(i,j,k,spos,spos1,spos2,tpos,nx,ny,nz,d1,d2,drdb,rhox,rhoy,rhoz,rho2) collapse(3)
    for(i=lbdm.owidx; i<(Xmax-lbdm.owidx); i++) {
      for(j=lbdm.owidy; j<(Ymax-lbdm.owidy); j++) {
        for(k=lbdm.owidz; k<(Zmax-lbdm.owidz); k++) {
          rhox = 0.0; rhoy = 0.0; rhoz = 0.0; rho2 = 0.0;
          tpos = (i * Ymax + j) * Zmax + k;
          if(lbneigh[tpos]>0) {
            drdb = lbfewet[0] + lbfewet[1]*rho[tpos];
            nx = lbneigh[tpos]/100;
            ny = (lbneigh[tpos]/10)%10;
            nz = (lbneigh[tpos])%10;
            switch (nx) {
              case 1:
                spos1 = ((i-1)*Ymax + j)*Zmax + k;
                spos2 = ((i+1)*Ymax + j)*Zmax + k;
                rhox = 0.5*(rho[spos2] - rho[spos1]);
                rho2 += (rho[spos1]-2.0*rho[tpos]+rho[spos2]);
                break;
              case 2:
                switch (wettyp) {
                  case 0:
                    spos1 = ((i+1)*Ymax + j)*Zmax + k;
                    rhox = rho[spos1] - rho[tpos];
                    break;
                  case 1:
                    rhox = drdb;
                    break;
                }
                break;
              case 3:
                spos1 = ((i+1)*Ymax + j)*Zmax + k;
                spos2 = (fCppMod(i+2, Xmax)*Ymax + j)*Zmax + k;
                switch (wettyp) {
                  case 0:
                    rhox = -1.5*rho[tpos] + 2.0*rho[spos1] - 0.5*rho[spos2];
                    rho2 += rho[tpos] - 2.0*rho[spos1] + rho[spos2];
                    break;
                  case 1:
                    rhox = drdb;
                    d1 = 0.5*(rho[spos2] - rho[tpos]);
                    d2 = 1.5*rho[spos2] - 2.0*rho[spos1] + 0.5*rho[tpos];
                    rho2 += (-1.5*rhox + 2.0*d1 - 0.5*d2);
                    break;
                }
                break;
              case 4:
                switch (wettyp) {
                  case 0:
                    spos1 = ((i-1)*Ymax + j)*Zmax + k;
                    rhox = rho[tpos] - rho[spos1];
                    break;
                  case 1:
                    rhox = -drdb;
                    break;
                }
                break;
              case 5:
                spos1 = ((i-1)*Ymax + j)*Zmax + k;
                spos2 = (fCppMod(i-2, Xmax)*Ymax + j)*Zmax + k;
                switch (wettyp) {
                  case 0:
                    rhox = 1.5*rho[tpos] - 2.0*rho[spos1] + 0.5*rho[spos2];
                    rho2 += rho[tpos] - 2.0*rho[spos1] + rho[spos2];
                    break;
                  case 1:
                    rhox = -drdb;
                    d1 = 0.5*(rho[tpos] - rho[spos2]);
                    d2 = -1.5*rho[spos2] + 2.0*rho[spos1] - 0.5*rho[tpos];
                    rho2 += (1.5*rhox - 2.0*d1 + 0.5*d2);
                    break;
                }
                break;
            }
            switch (ny) {
              case 1:
                spos1 = (i*Ymax + j-1)*Zmax + k;
                spos2 = (i*Ymax + j+1)*Zmax + k;
                rhoy = 0.5*(rho[spos2] - rho[spos1]);
                rho2 += (rho[spos1]-2.0*rho[tpos]+rho[spos2]);
                break;
              case 2:
                switch (wettyp) {
                  case 0:
                    spos1 = (i*Ymax + j+1)*Zmax + k;
                    rhoy = rho[spos1] - rho[tpos];
                    break;
                  case 1:
                    rhoy = drdb;
                    break;
                }
                break;
              case 3:
                spos1 = (i*Ymax + j+1)*Zmax + k;
                spos2 = (i*Ymax + fCppMod(j+2, Ymax))*Zmax + k;
                switch (wettyp) {
                  case 0:
                    rhoy = -1.5*rho[tpos] + 2.0*rho[spos1] - 0.5*rho[spos2];
                    rho2 += rho[tpos] - 2.0*rho[spos1] + rho[spos2];
                    break;
                  case 1:
                    rhoy = drdb;
                    d1 = 0.5*(rho[spos2] - rho[tpos]);
                    d2 = 1.5*rho[spos2] - 2.0*rho[spos1] + 0.5*rho[tpos];
                    rho2 += (-1.5*rhoy + 2.0*d1 - 0.5*d2);
                    break;
                }
                break;
              case 4:
                switch (wettyp) {
                  case 0:
                    spos1 = (i*Ymax + j-1)*Zmax + k;
                    rhoy = rho[tpos] - rho[spos1];
                    break;
                  case 1:
                    rhoy = -drdb;
                    break;
                }
                break;
              case 5:
                spos1 = (i*Ymax + j-1)*Zmax + k;
                spos2 = (i*Ymax + fCppMod(j-2, Ymax))*Zmax + k;
                switch (wettyp) {
                  case 0:
                    rhoy = 1.5*rho[tpos] - 2.0*rho[spos1] + 0.5*rho[spos2];
                    rho2 += rho[tpos] - 2.0*rho[spos1] + rho[spos2];
                    break;
                  case 1:
                    rhoy = -drdb;
                    d1 = 0.5*(rho[tpos] - rho[spos2]);
                    d2 = -1.5*rho[spos2] + 2.0*rho[spos1] - 0.5*rho[tpos];
                    rho2 += (1.5*rhoy - 2.0*d1 + 0.5*d2);
                    break;
                }
                break;
            }
            switch (nz) {
              case 1:
                spos1 = (i*Ymax + j)*Zmax + ((lbsy.nd>2)?k-1:0);
                spos2 = (i*Ymax + j)*Zmax + ((lbsy.nd>2)?k+1:0);
                rhoz = 0.5*(rho[spos2] - rho[spos1]);
                rho2 += (rho[spos1]-2.0*rho[tpos]+rho[spos2]);
                break;
              case 2:
                switch (wettyp) {
                  case 0:
                    spos1 = (i*Ymax + j)*Zmax + ((lbsy.nd>2)?k+1:0);
                    rhoz = rho[spos1] - rho[tpos];
                    break;
                  case 1:
                    rhoz = drdb;
                    break;
                }
                break;
              case 3:
                spos1 = (i*Ymax + j)*Zmax + ((lbsy.nd>2)?k+1:0);
                spos2 = (i*Ymax + j)*Zmax + ((lbsy.nd>2)?fCppMod(k+2, Zmax):0);
                switch (wettyp) {
                  case 0:
                    rhoz = -1.5*rho[tpos] + 2.0*rho[spos1] - 0.5*rho[spos2];
                    rho2 += rho[tpos] - 2.0*rho[spos1] + rho[spos2];
                    break;
                  case 1:
                    rhoz = drdb;
                    d1 = 0.5*(rho[spos2] - rho[tpos]);
                    d2 = 1.5*rho[spos2] - 2.0*rho[spos1] + 0.5*rho[tpos];
                    rho2 += (-1.5*rhoz + 2.0*d1 - 0.5*d2);
                    break;
                }
                break;
              case 4:
                switch (wettyp) {
                  case 0:
                    spos1 = (i*Ymax + j)*Zmax + ((lbsy.nd>2)?k-1:0);
                    rhoz = rho[tpos] - rho[spos1];
                    break;
                  case 1:
                    rhoz = -drdb;
                    break;
                }
                break;
              case 5:
                spos1 = (i*Ymax + j)*Zmax + ((lbsy.nd>2)?k-1:0);
                spos2 = (i*Ymax + j)*Zmax + ((lbsy.nd>2)?fCppMod(k-2, Zmax):0);
                switch (wettyp) {
                  case 0:
                    rhoz = 1.5*rho[tpos] - 2.0*rho[spos1] + 0.5*rho[spos2];
                    rho2 += rho[tpos] - 2.0*rho[spos1] + rho[spos2];
                    break;
                  case 1:
                    rhoz = -drdb;
                    d1 = 0.5*(rho[tpos] - rho[spos2]);
                    d2 = -1.5*rho[spos2] + 2.0*rho[spos1] - 0.5*rho[tpos];
                    rho2 += (1.5*rhoz - 2.0*d1 + 0.5*d2);
                    break;
                }
                break;
            }
          }
          else {
            for(int m=0; m<19; m++) {
              spos = ((i+lbfevx[m]) * Ymax + j+lbfevy[m]) * Zmax + k+lbfevz[m];
              rhox += dx[m] * rho[spos];
              rhoy += dy[m] * rho[spos];
              rhoz += dz[m] * rho[spos];
              rho2 += nabla[m] * rho[spos];
            }
          }
          lbft[4*tpos  ] = rhox;
          lbft[4*tpos+1] = rhoy;
          lbft[4*tpos+2] = rhoz;
          lbft[4*tpos+3] = rho2;
        }
      }
    }
    delete [] rho;
  }
  return 0;
}

int fsCalcDensityGradient_Swift()
{
  // calculate first-order and second-order derivatives of fluid densities
  
#pragma omp parallel
  {
    double* rho = new double[lbdm.touter];
    double rhox, rhoy, rhoz, rho2, d1, d2, drdb;
    int nx,ny,nz;
    unsigned long i,j,k,il,spos,spos1,spos2,tpos;
    long Xmax = (long) lbdm.xouter,
         Ymax = (long) lbdm.youter,
         Zmax = (long) lbdm.zouter;
    const double third = 1.0/3.0;
    const double sixth = 1.0/6.0;
    const double twelfth = 1.0/12.0;
    double dx [] = {-twelfth, -twelfth, -sixth, -twelfth, -twelfth, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, twelfth, twelfth, sixth, twelfth, twelfth};
    double dy [] = {0.0, -twelfth, 0.0, twelfth, 0.0, -twelfth, 0.0, twelfth, -sixth, 0.0, sixth, -twelfth, 0.0, twelfth, 0.0, -twelfth, 0.0, twelfth, 0.0};
    double dz [] = {-twelfth, 0.0, 0.0, 0.0, twelfth, -twelfth, -sixth, -twelfth, 0.0, 0.0, 0.0, twelfth, sixth, twelfth, -twelfth, 0.0, 0.0, 0.0, twelfth};
    double nabla [] = {sixth, sixth, third, sixth, sixth, sixth, third, sixth, third, -4.0, third, sixth, third, sixth, sixth, sixth, third, sixth, sixth};
    int wettyp = lbwet[0];

    for(il=0; il<lbdm.touter; il++) {
      rho[il]=fGetOneMassSite(0, il);
    }
    #pragma omp for private(il,i,j,k,spos,spos1,spos2,tpos,nx,ny,nz,d1,d2,drdb,rhox,rhoy,rhoz,rho2)
    for(il=0; il<lboutersize; il++) {
      i = lbouter[4*il+1];
      j = lbouter[4*il+2];
      k = lbouter[4*il+3];
      rhox = 0.0; rhoy = 0.0; rhoz = 0.0; rho2 = 0.0;
      tpos = (i * Ymax + j) * Zmax + k;
      if(lbneigh[tpos]>0) {
        drdb = lbfewet[0] + lbfewet[1]*rho[tpos];
        nx = lbneigh[tpos]/100;
        ny = (lbneigh[tpos]/10)%10;
        nz = (lbneigh[tpos])%10;
        switch (nx) {
          case 1:
            spos1 = (fCppMod(i-1, Xmax)*Ymax + j)*Zmax + k;
            spos2 = (fCppMod(i+1, Xmax)*Ymax + j)*Zmax + k;
            rhox = 0.5*(rho[spos2] - rho[spos1]);
            rho2 += (rho[spos1]-2.0*rho[tpos]+rho[spos2]);
            break;
          case 2:
            switch (wettyp) {
              case 0:
                spos1 = (fCppMod(i+1, Xmax)*Ymax + j)*Zmax + k;
                rhox = rho[spos1] - rho[tpos];
                break;
              case 1:
                rhox = drdb;
                break;
            }
            break;
          case 3:
            spos1 = (fCppMod(i+1, Xmax)*Ymax + j)*Zmax + k;
            spos2 = (fCppMod(i+2, Xmax)*Ymax + j)*Zmax + k;
            switch (wettyp) {
              case 0:
                rhox = -1.5*rho[tpos] + 2.0*rho[spos1] - 0.5*rho[spos2];
                rho2 += rho[tpos] - 2.0*rho[spos1] + rho[spos2];
                break;
              case 1:
                rhox = drdb;
                d1 = 0.5*(rho[spos2] - rho[tpos]);
                d2 = 1.5*rho[spos2] - 2.0*rho[spos1] + 0.5*rho[tpos];
                rho2 += (-1.5*rhox + 2.0*d1 - 0.5*d2);
                break;
            }
            break;
          case 4:
            switch (wettyp) {
              case 0:
                spos1 = (fCppMod(i-1, Xmax)*Ymax + j)*Zmax + k;
                rhox = rho[tpos] - rho[spos1];
                break;
              case 1:
                rhox = -drdb;
                break;
            }
            break;
          case 5:
            spos1 = (fCppMod(i-1, Xmax)*Ymax + j)*Zmax + k;
            spos2 = (fCppMod(i-2, Xmax)*Ymax + j)*Zmax + k;
            switch (wettyp) {
              case 0:
                rhox = 1.5*rho[tpos] - 2.0*rho[spos1] + 0.5*rho[spos2];
                rho2 += rho[tpos] - 2.0*rho[spos1] + rho[spos2];
                break;
              case 1:
                rhox = -drdb;
                d1 = 0.5*(rho[tpos] - rho[spos2]);
                d2 = -1.5*rho[spos2] + 2.0*rho[spos1] - 0.5*rho[tpos];
                rho2 += (1.5*rhox - 2.0*d1 + 0.5*d2);
                break;
            }
            break;
        }
        switch (ny) {
          case 1:
            spos1 = (i*Ymax + fCppMod(j-1, Ymax))*Zmax + k;
            spos2 = (i*Ymax + fCppMod(j+1, Ymax))*Zmax + k;
            rhoy = 0.5*(rho[spos2] - rho[spos1]);
            rho2 += (rho[spos1]-2.0*rho[tpos]+rho[spos2]);
            break;
          case 2:
            switch (wettyp) {
              case 0:
                spos1 = (i*Ymax + fCppMod(j+1, Ymax))*Zmax + k;
                rhox = rho[spos1] - rho[tpos];
                break;
              case 1:
                rhoy = drdb;
                break;
            }
            break;
          case 3:
            spos1 = (i*Ymax + fCppMod(j+1, Ymax))*Zmax + k;
            spos2 = (i*Ymax + fCppMod(j+2, Ymax))*Zmax + k;
            switch (wettyp) {
              case 0:
                rhoy = -1.5*rho[tpos] + 2.0*rho[spos1] - 0.5*rho[spos2];
                rho2 += rho[tpos] - 2.0*rho[spos1] + rho[spos2];
                break;
              case 1:
                rhoy = drdb;
                d1 = 0.5*(rho[spos2] - rho[tpos]);
                d2 = 1.5*rho[spos2] - 2.0*rho[spos1] + 0.5*rho[tpos];
                rho2 += (-1.5*rhoy + 2.0*d1 - 0.5*d2);
                break;
            }
            break;
          case 4:
            switch (wettyp) {
              case 0:
                spos1 = (i*Ymax + fCppMod(j-1, Ymax))*Zmax + k;
                rhoy = rho[tpos] - rho[spos1];
                break;
              case 1:
                rhoy = -drdb;
                break;
            }
            break;
          case 5:
            spos1 = (i*Ymax + fCppMod(j-1, Ymax))*Zmax + k;
            spos2 = (i*Ymax + fCppMod(j-2, Ymax))*Zmax + k;
            switch (wettyp) {
              case 0:
                rhoy = 1.5*rho[tpos] - 2.0*rho[spos1] + 0.5*rho[spos2];
                rho2 += rho[tpos] - 2.0*rho[spos1] + rho[spos2];
                break;
              case 1:
                rhoy = -drdb;
                d1 = 0.5*(rho[tpos] - rho[spos2]);
                d2 = -1.5*rho[spos2] + 2.0*rho[spos1] - 0.5*rho[tpos];
                rho2 += (1.5*rhoy - 2.0*d1 + 0.5*d2);
                break;
            }
            break;
        }
        switch (nz) {
          case 1:
            spos1 = (i*Ymax + j)*Zmax + fCppMod(k-1, Zmax);
            spos2 = (i*Ymax + j)*Zmax + fCppMod(k+1, Zmax);
            rhoz = 0.5*(rho[spos2] - rho[spos1]);
            rho2 += (rho[spos1]-2.0*rho[tpos]+rho[spos2]);
            break;
          case 2:
            switch (wettyp) {
              case 0:
                spos1 = (i*Ymax + j)*Zmax + fCppMod(k+1, Zmax);
                rhoz = rho[spos1] - rho[tpos];
                break;
              case 1:
                rhoz = drdb;
                break;
            }
            break;
          case 3:
            spos1 = (i*Ymax + j)*Zmax + fCppMod(k+1, Zmax);
            spos2 = (i*Ymax + j)*Zmax + fCppMod(k+2, Zmax);
            switch (wettyp) {
              case 0:
                rhoz = -1.5*rho[tpos] + 2.0*rho[spos1] - 0.5*rho[spos2];
                rho2 += rho[tpos] - 2.0*rho[spos1] + rho[spos2];
                break;
              case 1:
                rhoz = drdb;
                d1 = 0.5*(rho[spos2] - rho[tpos]);
                d2 = 1.5*rho[spos2] - 2.0*rho[spos1] + 0.5*rho[tpos];
                rho2 += (-1.5*rhoz + 2.0*d1 - 0.5*d2);
                break;
            }
            break;
          case 4:
            switch (wettyp) {
              case 0:
                spos1 = (i*Ymax + j)*Zmax + fCppMod(k-1, Zmax);
                rhoz = rho[tpos] - rho[spos1];
                break;
              case 1:
                rhoz = -drdb;
                break;
            }
            break;
          case 5:
            spos1 = (i*Ymax + j)*Zmax + fCppMod(k-1, Zmax);
            spos2 = (i*Ymax + j)*Zmax + fCppMod(k-2, Zmax);
            switch (wettyp) {
              case 0:
                rhoz = 1.5*rho[tpos] - 2.0*rho[spos1] + 0.5*rho[spos2];
                rho2 += rho[tpos] - 2.0*rho[spos1] + rho[spos2];
                break;
              case 1:
                rhoz = -drdb;
                d1 = 0.5*(rho[tpos] - rho[spos2]);
                d2 = -1.5*rho[spos2] + 2.0*rho[spos1] - 0.5*rho[tpos];
                rho2 += (1.5*rhoz - 2.0*d1 + 0.5*d2);
                break;
            }
            break;
        }
      }
      else {
        for(int m=0; m<19; m++) {
          spos = (fCppMod(i+lbfevx[m], Xmax) * Ymax + fCppMod(j+lbfevy[m], Ymax)) * Zmax + fCppMod(k+lbfevz[m], Zmax);
          rhox += dx[m] * rho[spos];
          rhoy += dy[m] * rho[spos];
          rhoz += dz[m] * rho[spos];
          rho2 += nabla[m] * rho[spos];
        }
      }
      lbft[4*tpos  ] = rhox;
      lbft[4*tpos+1] = rhoy;
      lbft[4*tpos+2] = rhoz;
      lbft[4*tpos+3] = rho2;
    }
    #pragma omp for private(i,j,k,spos,spos1,spos2,tpos,nx,ny,nz,d1,d2,drdb,rhox,rhoy,rhoz,rho2) collapse(3)
    for(i=lbdm.owidx; i<(Xmax-lbdm.owidx); i++) {
      for(j=lbdm.owidy; j<(Ymax-lbdm.owidy); j++) {
        for(k=lbdm.owidz; k<(Zmax-lbdm.owidz); k++) {
          rhox = 0.0; rhoy = 0.0; rhoz = 0.0; rho2 = 0.0;
          tpos = (i * Ymax + j) * Zmax + k;
          if(lbneigh[tpos]>0) {
            drdb = lbfewet[0] + lbfewet[1]*rho[tpos];
            nx = lbneigh[tpos]/100;
            ny = (lbneigh[tpos]/10)%10;
            nz = (lbneigh[tpos])%10;
            switch (nx) {
              case 1:
                spos1 = ((i-1)*Ymax + j)*Zmax + k;
                spos2 = ((i+1)*Ymax + j)*Zmax + k;
                rhox = 0.5*(rho[spos2] - rho[spos1]);
                rho2 += (rho[spos1]-2.0*rho[tpos]+rho[spos2]);
                break;
              case 2:
                switch (wettyp) {
                  case 0:
                    spos1 = ((i+1)*Ymax + j)*Zmax + k;
                    rhox = rho[spos1] - rho[tpos];
                    break;
                  case 1:
                    rhox = drdb;
                    break;
                }
                break;
              case 3:
                spos1 = ((i+1)*Ymax + j)*Zmax + k;
                spos2 = (fCppMod(i+2, Xmax)*Ymax + j)*Zmax + k;
                switch (wettyp) {
                  case 0:
                    rhox = -1.5*rho[tpos] + 2.0*rho[spos1] - 0.5*rho[spos2];
                    rho2 += rho[tpos] - 2.0*rho[spos1] + rho[spos2];
                    break;
                  case 1:
                    rhox = drdb;
                    d1 = 0.5*(rho[spos2] - rho[tpos]);
                    d2 = 1.5*rho[spos2] - 2.0*rho[spos1] + 0.5*rho[tpos];
                    rho2 += (-1.5*rhox + 2.0*d1 - 0.5*d2);
                    break;
                }
                break;
              case 4:
                switch (wettyp) {
                  case 0:
                    spos1 = ((i-1)*Ymax + j)*Zmax + k;
                    rhox = rho[tpos] - rho[spos1];
                    break;
                  case 1:
                    rhox = -drdb;
                    break;
                }
                break;
              case 5:
                spos1 = ((i-1)*Ymax + j)*Zmax + k;
                spos2 = (fCppMod(i-2, Xmax)*Ymax + j)*Zmax + k;
                switch (wettyp) {
                  case 0:
                    rhox = 1.5*rho[tpos] - 2.0*rho[spos1] + 0.5*rho[spos2];
                    rho2 += rho[tpos] - 2.0*rho[spos1] + rho[spos2];
                    break;
                  case 1:
                    rhox = -drdb;
                    d1 = 0.5*(rho[tpos] - rho[spos2]);
                    d2 = -1.5*rho[spos2] + 2.0*rho[spos1] - 0.5*rho[tpos];
                    rho2 += (1.5*rhox - 2.0*d1 + 0.5*d2);
                    break;
                }
                break;
            }
            switch (ny) {
              case 1:
                spos1 = (i*Ymax + j-1)*Zmax + k;
                spos2 = (i*Ymax + j+1)*Zmax + k;
                rhoy = 0.5*(rho[spos2] - rho[spos1]);
                rho2 += (rho[spos1]-2.0*rho[tpos]+rho[spos2]);
                break;
              case 2:
                switch (wettyp) {
                  case 0:
                    spos1 = (i*Ymax + j+1)*Zmax + k;
                    rhoy = rho[spos1] - rho[tpos];
                    break;
                  case 1:
                    rhoy = drdb;
                    break;
                }
                break;
              case 3:
                spos1 = (i*Ymax + j+1)*Zmax + k;
                spos2 = (i*Ymax + fCppMod(j+2, Ymax))*Zmax + k;
                switch (wettyp) {
                  case 0:
                    rhoy = -1.5*rho[tpos] + 2.0*rho[spos1] - 0.5*rho[spos2];
                    rho2 += rho[tpos] - 2.0*rho[spos1] + rho[spos2];
                    break;
                  case 1:
                    rhoy = drdb;
                    d1 = 0.5*(rho[spos2] - rho[tpos]);
                    d2 = 1.5*rho[spos2] - 2.0*rho[spos1] + 0.5*rho[tpos];
                    rho2 += (-1.5*rhoy + 2.0*d1 - 0.5*d2);
                    break;
                }
                break;
              case 4:
                switch (wettyp) {
                  case 0:
                    spos1 = (i*Ymax + j-1)*Zmax + k;
                    rhoy = rho[tpos] - rho[spos1];
                    break;
                  case 1:
                    rhoy = -drdb;
                    break;
                }
                break;
              case 5:
                spos1 = (i*Ymax + j-1)*Zmax + k;
                spos2 = (i*Ymax + fCppMod(j-2, Ymax))*Zmax + k;
                switch (wettyp) {
                  case 0:
                    rhoy = 1.5*rho[tpos] - 2.0*rho[spos1] + 0.5*rho[spos2];
                    rho2 += rho[tpos] - 2.0*rho[spos1] + rho[spos2];
                    break;
                  case 1:
                    rhoy = -drdb;
                    d1 = 0.5*(rho[tpos] - rho[spos2]);
                    d2 = -1.5*rho[spos2] + 2.0*rho[spos1] - 0.5*rho[tpos];
                    rho2 += (1.5*rhoy - 2.0*d1 + 0.5*d2);
                    break;
                }
                break;
            }
            switch (nz) {
              case 1:
                spos1 = (i*Ymax + j)*Zmax + ((lbsy.nd>2)?k-1:0);
                spos2 = (i*Ymax + j)*Zmax + ((lbsy.nd>2)?k+1:0);
                rhoz = 0.5*(rho[spos2] - rho[spos1]);
                rho2 += (rho[spos1]-2.0*rho[tpos]+rho[spos2]);
                break;
              case 2:
                switch (wettyp) {
                  case 0:
                    spos1 = (i*Ymax + j)*Zmax + ((lbsy.nd>2)?k+1:0);
                    rhoz = rho[spos1] - rho[tpos];
                    break;
                  case 1:
                    rhoz = drdb;
                    break;
                }
                break;
              case 3:
                spos1 = (i*Ymax + j)*Zmax + ((lbsy.nd>2)?k+1:0);
                spos2 = (i*Ymax + j)*Zmax + fCppMod(k+2, Zmax);
                switch (wettyp) {
                  case 0:
                    rhoz = -1.5*rho[tpos] + 2.0*rho[spos1] - 0.5*rho[spos2];
                    rho2 += rho[tpos] - 2.0*rho[spos1] + rho[spos2];
                    break;
                  case 1:
                    rhoz = drdb;
                    d1 = 0.5*(rho[spos2] - rho[tpos]);
                    d2 = 1.5*rho[spos2] - 2.0*rho[spos1] + 0.5*rho[tpos];
                    rho2 += (-1.5*rhoz + 2.0*d1 - 0.5*d2);
                    break;
                }
                break;
              case 4:
                switch (wettyp) {
                  case 0:
                    spos1 = (i*Ymax + j)*Zmax + ((lbsy.nd>2)?k-1:0);
                    rhoz = rho[tpos] - rho[spos1];
                    break;
                  case 1:
                    rhoz = -drdb;
                    break;
                }
                break;
              case 5:
                spos1 = (i*Ymax + j)*Zmax + ((lbsy.nd>2)?k-1:0);
                spos2 = (i*Ymax + j)*Zmax + fCppMod(k-2, Zmax);
                switch (wettyp) {
                  case 0:
                    rhoz = 1.5*rho[tpos] - 2.0*rho[spos1] + 0.5*rho[spos2];
                    rho2 += rho[tpos] - 2.0*rho[spos1] + rho[spos2];
                    break;
                  case 1:
                    rhoz = -drdb;
                    d1 = 0.5*(rho[tpos] - rho[spos2]);
                    d2 = -1.5*rho[spos2] + 2.0*rho[spos1] - 0.5*rho[tpos];
                    rho2 += (1.5*rhoz - 2.0*d1 + 0.5*d2);
                    break;
                }
                break;
            }
          }
          else {
            for(int m=0; m<19; m++) {
              spos = ((i+lbfevx[m]) * Ymax + j+lbfevy[m]) * Zmax + k+lbfevz[m];
              rhox += dx[m] * rho[spos];
              rhoy += dy[m] * rho[spos];
              rhoz += dz[m] * rho[spos];
              rho2 += nabla[m] * rho[spos];
            }
          }
          lbft[4*tpos  ] = rhox;
          lbft[4*tpos+1] = rhoy;
          lbft[4*tpos+2] = rhoz;
          lbft[4*tpos+3] = rho2;
        }
      }
    }
    delete [] rho;
  }
  return 0;
}

int fCalcDensityConcentrationGradient_Swift()
{
  // calculate first-order and second-order derivatives of fluid densities and concentrations
  
#pragma omp parallel
  {
    double* rho = new double[lbdm.touter];
    double* phi = new double[lbdm.touter];
    double rhox, rhoy, rhoz, rho2, d1, d2, drdb, phix, phiy, phiz, phi2, p1, p2, dpdb;
    int nx,ny,nz;
    unsigned long i,j,k,il,spos,spos1,spos2,tpos;
    long Xmax = (long) lbdm.xouter,
         Ymax = (long) lbdm.youter,
         Zmax = (long) lbdm.zouter;
    const double third = 1.0/3.0;
    const double sixth = 1.0/6.0;
    const double twelfth = 1.0/12.0;
    double dx [] = {-twelfth, -twelfth, -sixth, -twelfth, -twelfth, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, twelfth, twelfth, sixth, twelfth, twelfth};
    double dy [] = {0.0, -twelfth, 0.0, twelfth, 0.0, -twelfth, 0.0, twelfth, -sixth, 0.0, sixth, -twelfth, 0.0, twelfth, 0.0, -twelfth, 0.0, twelfth, 0.0};
    double dz [] = {-twelfth, 0.0, 0.0, 0.0, twelfth, -twelfth, -sixth, -twelfth, 0.0, 0.0, 0.0, twelfth, sixth, twelfth, -twelfth, 0.0, 0.0, 0.0, twelfth};
    double nabla [] = {sixth, sixth, third, sixth, sixth, sixth, third, sixth, third, -4.0, third, sixth, third, sixth, sixth, sixth, third, sixth, sixth};
    int wettyp = lbwet[0];
      
    for(il=0; il<lbdm.touter; il++) {
      rho[il]=fGetOneMassSite(0, il);
      phi[il]=fGetOneMassSite(1, il);
    }
    #pragma omp for private(i,j,k,spos,spos1,spos2,tpos,nx,ny,nz,d1,d2,drdb,rhox,rhoy,rhoz,rho2,p1,p2,dpdb,phix,phiy,phiz,phi2) collapse(3)
    for(i=lbdm.owidx; i<(Xmax-lbdm.owidx); i++) {
      for(j=lbdm.owidy; j<(Ymax-lbdm.owidy); j++) {
        for(k=lbdm.owidz; k<(Zmax-lbdm.owidz); k++) {
          rhox = 0.0; rhoy = 0.0; rhoz = 0.0; rho2 = 0.0;
          phix = 0.0; phiy = 0.0; phiz = 0.0; phi2 = 0.0;
          tpos = (i * Ymax + j) * Zmax + k;
          if(lbneigh[tpos]>0) {
            drdb = lbfewet[0] + lbfewet[1]*rho[tpos];
            dpdb = lbfewet[2] + lbfewet[3]*phi[tpos];
            nx = lbneigh[tpos]/100;
            ny = (lbneigh[tpos]/10)%10;
            nz = (lbneigh[tpos])%10;
            switch (nx) {
              case 1:
                spos1 = ((i-1)*Ymax + j)*Zmax + k;
                spos2 = ((i+1)*Ymax + j)*Zmax + k;
                rhox = 0.5*(rho[spos2] - rho[spos1]);
                rho2 += (rho[spos1]-2.0*rho[tpos]+rho[spos2]);
                phix = 0.5*(phi[spos2] - phi[spos1]);
                phi2 += (phi[spos1]-2.0*phi[tpos]+phi[spos2]);
                break;
              case 2:
                switch (wettyp) {
                  case 0:
                    spos1 = ((i+1)*Ymax + j)*Zmax + k;
                    rhox = rho[spos1] - rho[tpos];
                    phix = phi[spos1] - phi[tpos];
                    break;
                  case 1:
                    rhox = drdb;
                    phix = dpdb;
                    break;
                }
                break;
              case 3:
                spos1 = ((i+1)*Ymax + j)*Zmax + k;
                spos2 = (fCppMod(i+2, Xmax)*Ymax + j)*Zmax + k;
                switch (wettyp) {
                  case 0:
                    rhox = -1.5*rho[tpos] + 2.0*rho[spos1] - 0.5*rho[spos2];
                    rho2 += rho[tpos] - 2.0*rho[spos1] + rho[spos2];
                    phix = -1.5*phi[tpos] + 2.0*phi[spos1] - 0.5*phi[spos2];
                    phi2 += phi[tpos] - 2.0*phi[spos1] + phi[spos2];
                    break;
                  case 1:
                    rhox = drdb;
                    d1 = 0.5*(rho[spos2] - rho[tpos]);
                    d2 = 1.5*rho[spos2] - 2.0*rho[spos1] + 0.5*rho[tpos];
                    rho2 += (-1.5*rhox + 2.0*d1 - 0.5*d2);
                    phix = dpdb;
                    p1 = 0.5*(phi[spos2] - phi[tpos]);
                    p2 = 1.5*phi[spos2] - 2.0*phi[spos1] + 0.5*phi[tpos];
                    phi2 += (-1.5*phix + 2.0*p1 - 0.5*p2);
                    break;
                }
                break;
              case 4:
                switch (wettyp) {
                  case 0:
                    spos1 = ((i-1)*Ymax + j)*Zmax + k;
                    rhox = rho[tpos] - rho[spos1];
                    phix = phi[tpos] - phi[spos1];
                    break;
                  case 1:
                    rhox = -drdb;
                    phix = -dpdb;
                    break;
                }
                break;
              case 5:
                spos1 = ((i-1)*Ymax + j)*Zmax + k;
                spos2 = (fCppMod(i-2, Xmax)*Ymax + j)*Zmax + k;
                switch (wettyp) {
                  case 0:
                    rhox = 1.5*rho[tpos] - 2.0*rho[spos1] + 0.5*rho[spos2];
                    rho2 += rho[tpos] - 2.0*rho[spos1] + rho[spos2];
                    phix = 1.5*phi[tpos] - 2.0*phi[spos1] + 0.5*phi[spos2];
                    phi2 += phi[tpos] - 2.0*phi[spos1] + phi[spos2];
                    break;
                  case 1:
                    rhox = -drdb;
                    d1 = 0.5*(rho[tpos] - rho[spos2]);
                    d2 = -1.5*rho[spos2] + 2.0*rho[spos1] - 0.5*rho[tpos];
                    rho2 += (1.5*rhox - 2.0*d1 + 0.5*d2);
                    phix = -dpdb;
                    p1 = 0.5*(phi[tpos] - phi[spos2]);
                    p2 = -1.5*phi[spos2] + 2.0*phi[spos1] - 0.5*phi[tpos];
                    phi2 += (1.5*phix - 2.0*p1 + 0.5*p2);
                    break;
                }
                break;
            }
            switch (ny) {
              case 1:
                spos1 = (i*Ymax + j-1)*Zmax + k;
                spos2 = (i*Ymax + j+1)*Zmax + k;
                rhoy = 0.5*(rho[spos2] - rho[spos1]);
                rho2 += (rho[spos1]-2.0*rho[tpos]+rho[spos2]);
                phiy = 0.5*(phi[spos2] - phi[spos1]);
                phi2 += (phi[spos1]-2.0*phi[tpos]+phi[spos2]);
                break;
              case 2:
                switch (wettyp) {
                  case 0:
                    spos1 = (i*Ymax + j+1)*Zmax + k;
                    rhoy = rho[spos1] - rho[tpos];
                    phiy = phi[spos1] - phi[tpos];
                    break;
                  case 1:
                    rhoy = drdb;
                    phiy = dpdb;
                    break;
                }
                break;
              case 3:
                spos1 = (i*Ymax + j+1)*Zmax + k;
                spos2 = (i*Ymax + fCppMod(j+2, Ymax))*Zmax + k;
                switch (wettyp) {
                  case 0:
                    rhoy = -1.5*rho[tpos] + 2.0*rho[spos1] - 0.5*rho[spos2];
                    rho2 += rho[tpos] - 2.0*rho[spos1] + rho[spos2];
                    phiy = -1.5*phi[tpos] + 2.0*phi[spos1] - 0.5*phi[spos2];
                    phi2 += phi[tpos] - 2.0*phi[spos1] + phi[spos2];
                    break;
                  case 1:
                    rhoy = drdb;
                    d1 = 0.5*(rho[spos2] - rho[tpos]);
                    d2 = 1.5*rho[spos2] - 2.0*rho[spos1] + 0.5*rho[tpos];
                    rho2 += (-1.5*rhoy + 2.0*d1 - 0.5*d2);
                    phiy = dpdb;
                    p1 = 0.5*(phi[spos2] - phi[tpos]);
                    p2 = 1.5*phi[spos2] - 2.0*phi[spos1] + 0.5*phi[tpos];
                    phi2 += (-1.5*phiy + 2.0*p1 - 0.5*p2);
                    break;
                }
                break;
              case 4:
                switch (wettyp) {
                  case 0:
                    spos1 = (i*Ymax + j-1)*Zmax + k;
                    rhoy = rho[tpos] - rho[spos1];
                    phiy = phi[tpos] - phi[spos1];
                    break;
                  case 1:
                    rhoy = -drdb;
                    phiy = -dpdb;
                    break;
                }
                break;
              case 5:
                spos1 = (i*Ymax + j-1)*Zmax + k;
                spos2 = (i*Ymax + fCppMod(j-2, Ymax))*Zmax + k;
                switch (wettyp) {
                  case 0:
                    rhoy = 1.5*rho[tpos] - 2.0*rho[spos1] + 0.5*rho[spos2];
                    rho2 += rho[tpos] - 2.0*rho[spos1] + rho[spos2];
                    phiy = 1.5*phi[tpos] - 2.0*phi[spos1] + 0.5*phi[spos2];
                    phi2 += phi[tpos] - 2.0*phi[spos1] + phi[spos2];
                    break;
                  case 1:
                    rhoy = -drdb;
                    d1 = 0.5*(rho[tpos] - rho[spos2]);
                    d2 = -1.5*rho[spos2] + 2.0*rho[spos1] - 0.5*rho[tpos];
                    rho2 += (1.5*rhoy - 2.0*d1 + 0.5*d2);
                    phiy = -dpdb;
                    p1 = 0.5*(phi[tpos] - phi[spos2]);
                    p2 = -1.5*phi[spos2] + 2.0*phi[spos1] - 0.5*phi[tpos];
                    phi2 += (1.5*phiy - 2.0*p1 + 0.5*p2);
                    break;
                }
            }
            switch (nz) {
              case 1:
                spos1 = (i*Ymax + j)*Zmax + ((lbsy.nd>2)?k-1:0);
                spos2 = (i*Ymax + j)*Zmax + ((lbsy.nd>2)?k+1:0);
                rhoz = 0.5*(rho[spos2] - rho[spos1]);
                phiz = 0.5*(phi[spos2] - phi[spos1]);
                rho2 += (rho[spos1]-2.0*rho[tpos]+rho[spos2]);
                phi2 += (phi[spos1]-2.0*phi[tpos]+phi[spos2]);
                break;
              case 2:
                switch (wettyp) {
                  case 0:
                    spos1 = (i*Ymax + j)*Zmax + ((lbsy.nd>2)?k+1:0);
                    rhoz = rho[spos1] - rho[tpos];
                    phiz = phi[spos1] - phi[tpos];
                    break;
                  case 1:
                    rhoz = drdb;
                    phiz = dpdb;
                    break;
                }
                break;
              case 3:
                spos1 = (i*Ymax + j)*Zmax + ((lbsy.nd>2)?k+1:0);
                spos2 = (i*Ymax + j)*Zmax + ((lbsy.nd>2)?fCppMod(k+2, Zmax):0);
                switch (wettyp) {
                  case 0:
                    rhoz = -1.5*rho[tpos] + 2.0*rho[spos1] - 0.5*rho[spos2];
                    rho2 += rho[tpos] - 2.0*rho[spos1] + rho[spos2];
                    phiz = -1.5*phi[tpos] + 2.0*phi[spos1] - 0.5*phi[spos2];
                    phi2 += phi[tpos] - 2.0*phi[spos1] + phi[spos2];
                    break;
                  case 1:
                    rhoz = drdb;
                    d1 = 0.5*(rho[spos2] - rho[tpos]);
                    d2 = 1.5*rho[spos2] - 2.0*rho[spos1] + 0.5*rho[tpos];
                    rho2 += (-1.5*rhoz + 2.0*d1 - 0.5*d2);
                    phiz = dpdb;
                    p1 = 0.5*(phi[spos2] - phi[tpos]);
                    p2 = 1.5*phi[spos2] - 2.0*phi[spos1] + 0.5*phi[tpos];
                    phi2 += (-1.5*phiz + 2.0*p1 - 0.5*p2);
                    break;
                }
                break;
              case 4:
                switch (wettyp) {
                  case 0:
                    spos1 = (i*Ymax + j)*Zmax + ((lbsy.nd>2)?k-1:0);
                    rhoz = rho[tpos] - rho[spos1];
                    phiz = phi[tpos] - phi[spos1];
                    break;
                  case 1:
                    rhoz = -drdb;
                    phiz = -dpdb;
                    break;
                }
                break;
              case 5:
                spos1 = (i*Ymax + j)*Zmax + ((lbsy.nd>2)?k-1:0);
                spos2 = (i*Ymax + j)*Zmax + ((lbsy.nd>2)?fCppMod(k-2, Zmax):0);
                switch (wettyp) {
                  case 0:
                    rhoz = 1.5*rho[tpos] - 2.0*rho[spos1] + 0.5*rho[spos2];
                    rho2 += rho[tpos] - 2.0*rho[spos1] + rho[spos2];
                    phiz = 1.5*phi[tpos] - 2.0*phi[spos1] + 0.5*phi[spos2];
                    phi2 += phi[tpos] - 2.0*phi[spos1] + phi[spos2];
                    break;
                  case 1:
                    rhoz = -drdb;
                    d1 = 0.5*(rho[tpos] - rho[spos2]);
                    d2 = -1.5*rho[spos2] + 2.0*rho[spos1] - 0.5*rho[tpos];
                    rho2 += (1.5*rhoz - 2.0*d1 + 0.5*d2);
                    phiz = -dpdb;
                    p1 = 0.5*(phi[tpos] - phi[spos2]);
                    p2 = -1.5*phi[spos2] + 2.0*phi[spos1] - 0.5*phi[tpos];
                    phi2 += (1.5*phiz - 2.0*p1 + 0.5*p2);
                    break;
                }
                break;
            }
          }
          else {
            for(int m=0; m<19; m++) {
              spos = ((i+lbfevx[m]) * Ymax + j+lbfevy[m]) * Zmax + k+lbfevz[m];
              rhox += dx[m] * rho[spos];
              phix += dx[m] * phi[spos];
              rhoy += dy[m] * rho[spos];
              phiy += dy[m] * phi[spos];
              rhoz += dz[m] * rho[spos];
              phiz += dz[m] * phi[spos];
              rho2 += nabla[m] * rho[spos];
              phi2 += nabla[m] * phi[spos];
            }
          }
          lbft[8*tpos  ] = rhox;
          lbft[8*tpos+1] = rhoy;
          lbft[8*tpos+2] = rhoz;
          lbft[8*tpos+3] = rho2;
          lbft[8*tpos+4] = phix;
          lbft[8*tpos+5] = phiy;
          lbft[8*tpos+6] = phiz;
          lbft[8*tpos+7] = phi2;
        }
      }
    }
    delete [] rho;
    delete [] phi;
  }
  return 0;
}

int fsCalcDensityConcentrationGradient_Swift()
{
  // calculate first-order and second-order derivatives of fluid densities and concentrations
  
#pragma omp parallel
  {
    double* rho = new double[lbdm.touter];
    double* phi = new double[lbdm.touter];
    double rhox, rhoy, rhoz, rho2, d1, d2, drdb, phix, phiy, phiz, phi2, p1, p2, dpdb;
    int nx,ny,nz;
    unsigned long i,j,k,il,spos,spos1,spos2,tpos;
    long Xmax = (long) lbdm.xouter,
         Ymax = (long) lbdm.youter,
         Zmax = (long) lbdm.zouter;
    const double third = 1.0/3.0;
    const double sixth = 1.0/6.0;
    const double twelfth = 1.0/12.0;
    double dx [] = {-twelfth, -twelfth, -sixth, -twelfth, -twelfth, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, twelfth, twelfth, sixth, twelfth, twelfth};
    double dy [] = {0.0, -twelfth, 0.0, twelfth, 0.0, -twelfth, 0.0, twelfth, -sixth, 0.0, sixth, -twelfth, 0.0, twelfth, 0.0, -twelfth, 0.0, twelfth, 0.0};
    double dz [] = {-twelfth, 0.0, 0.0, 0.0, twelfth, -twelfth, -sixth, -twelfth, 0.0, 0.0, 0.0, twelfth, sixth, twelfth, -twelfth, 0.0, 0.0, 0.0, twelfth};
    double nabla [] = {sixth, sixth, third, sixth, sixth, sixth, third, sixth, third, -4.0, third, sixth, third, sixth, sixth, sixth, third, sixth, sixth};
    int wettyp = lbwet[0];

    for(il=0; il<lbdm.touter; il++) {
      rho[il]=fGetOneMassSite(0, il);
      phi[il]=fGetOneMassSite(1, il);
    }
    #pragma omp for private(il,i,j,k,spos,spos1,spos2,tpos,nx,ny,nz,d1,d2,drdb,rhox,rhoy,rhoz,rho2,p1,p2,dpdb,phix,phiy,phiz,phi2)
    for(il=0; il<lboutersize; il++) {
      i = lbouter[4*il+1];
      j = lbouter[4*il+2];
      k = lbouter[4*il+3];
      rhox = 0.0; rhoy = 0.0; rhoz = 0.0; rho2 = 0.0;
      phix = 0.0; phiy = 0.0; phiz = 0.0; phi2 = 0.0;
      tpos = (i * Ymax + j) * Zmax + k;
      if(lbneigh[tpos]>0) {
        drdb = lbfewet[0] + lbfewet[1]*rho[tpos];
        dpdb = lbfewet[2] + lbfewet[3]*phi[tpos];
        nx = lbneigh[tpos]/100;
        ny = (lbneigh[tpos]/10)%10;
        nz = (lbneigh[tpos])%10;
        switch (nx) {
          case 1:
            spos1 = (fCppMod(i-1, Xmax)*Ymax + j)*Zmax + k;
            spos2 = (fCppMod(i+1, Xmax)*Ymax + j)*Zmax + k;
            rhox = 0.5*(rho[spos2] - rho[spos1]);
            rho2 += (rho[spos1]-2.0*rho[tpos]+rho[spos2]);
            phix = 0.5*(phi[spos2] - phi[spos1]);
            phi2 += (phi[spos1]-2.0*phi[tpos]+phi[spos2]);
            break;
          case 2:
            switch (wettyp) {
              case 0:
                spos1 = (fCppMod(i+1, Xmax)*Ymax + j)*Zmax + k;
                rhox = rho[spos1] - rho[tpos];
                phix = phi[spos1] - phi[tpos];
                break;
              case 1:
                rhox = drdb;
                phix = dpdb;
                break;
            }
            break;
          case 3:
            spos1 = (fCppMod(i+1, Xmax)*Ymax + j)*Zmax + k;
            spos2 = (fCppMod(i+2, Xmax)*Ymax + j)*Zmax + k;
            switch (wettyp) {
              case 0:
                rhox = -1.5*rho[tpos] + 2.0*rho[spos1] - 0.5*rho[spos2];
                rho2 += rho[tpos] - 2.0*rho[spos1] + rho[spos2];
                phix = -1.5*phi[tpos] + 2.0*phi[spos1] - 0.5*phi[spos2];
                phi2 += phi[tpos] - 2.0*phi[spos1] + phi[spos2];
                break;
              case 1:
                rhox = drdb;
                d1 = 0.5*(rho[spos2] - rho[tpos]);
                d2 = 1.5*rho[spos2] - 2.0*rho[spos1] + 0.5*rho[tpos];
                rho2 += (-1.5*rhox + 2.0*d1 - 0.5*d2);
                phix = dpdb;
                p1 = 0.5*(phi[spos2] - phi[tpos]);
                p2 = 1.5*phi[spos2] - 2.0*phi[spos1] + 0.5*phi[tpos];
                phi2 += (-1.5*phix + 2.0*p1 - 0.5*p2);
                break;
            }
            break;
          case 4:
            switch (wettyp) {
              case 0:
                spos1 = (fCppMod(i-1, Xmax)*Ymax + j)*Zmax + k;
                rhox = rho[tpos] - rho[spos1];
                phix = phi[tpos] - phi[spos1];
                break;
              case 1:
                rhox = -drdb;
                phix = -dpdb;
                break;
            }
            break;
          case 5:
            spos1 = (fCppMod(i-1, Xmax)*Ymax + j)*Zmax + k;
            spos2 = (fCppMod(i-2, Xmax)*Ymax + j)*Zmax + k;
            switch (wettyp) {
              case 0:
                rhox = 1.5*rho[tpos] - 2.0*rho[spos1] + 0.5*rho[spos2];
                rho2 += rho[tpos] - 2.0*rho[spos1] + rho[spos2];
                phix = 1.5*phi[tpos] - 2.0*phi[spos1] + 0.5*phi[spos2];
                phi2 += phi[tpos] - 2.0*phi[spos1] + phi[spos2];
                break;
              case 1:
                rhox = -drdb;
                d1 = 0.5*(rho[tpos] - rho[spos2]);
                d2 = -1.5*rho[spos2] + 2.0*rho[spos1] - 0.5*rho[tpos];
                rho2 += (1.5*rhox - 2.0*d1 + 0.5*d2);
                phix = -dpdb;
                p1 = 0.5*(phi[tpos] - phi[spos2]);
                p2 = -1.5*phi[spos2] + 2.0*phi[spos1] - 0.5*phi[tpos];
                phi2 += (1.5*phix - 2.0*p1 + 0.5*p2);
                break;
            }
            break;
        }
        switch (ny) {
          case 1:
            spos1 = (i*Ymax + fCppMod(j-1, Ymax))*Zmax + k;
            spos2 = (i*Ymax + fCppMod(j+1, Ymax))*Zmax + k;
            rhoy = 0.5*(rho[spos2] - rho[spos1]);
            rho2 += (rho[spos1]-2.0*rho[tpos]+rho[spos2]);
            phiy = 0.5*(phi[spos2] - phi[spos1]);
            phi2 += (phi[spos1]-2.0*phi[tpos]+phi[spos2]);
            break;
          case 2:
            switch (wettyp) {
              case 0:
                spos1 = (i*Ymax + fCppMod(j+1, Ymax))*Zmax + k;
                rhoy = rho[spos1] - rho[tpos];
                phiy = phi[spos1] - phi[tpos];
                break;
              case 1:
                rhoy = drdb;
                phiy = dpdb;
                break;
            }
            break;
          case 3:
            spos1 = (i*Ymax + fCppMod(j+1, Ymax))*Zmax + k;
            spos2 = (i*Ymax + fCppMod(j+2, Ymax))*Zmax + k;
            switch (wettyp) {
              case 0:
                rhoy = -1.5*rho[tpos] + 2.0*rho[spos1] - 0.5*rho[spos2];
                rho2 += rho[tpos] - 2.0*rho[spos1] + rho[spos2];
                phiy = -1.5*phi[tpos] + 2.0*phi[spos1] - 0.5*phi[spos2];
                phi2 += phi[tpos] - 2.0*phi[spos1] + phi[spos2];
                break;
              case 1:
                rhoy = drdb;
                d1 = 0.5*(rho[spos2] - rho[tpos]);
                d2 = 1.5*rho[spos2] - 2.0*rho[spos1] + 0.5*rho[tpos];
                rho2 += (-1.5*rhoy + 2.0*d1 - 0.5*d2);
                phiy = dpdb;
                p1 = 0.5*(phi[spos2] - phi[tpos]);
                p2 = 1.5*phi[spos2] - 2.0*phi[spos1] + 0.5*phi[tpos];
                phi2 += (-1.5*phiy + 2.0*p1 - 0.5*p2);
                break;
            }
            break;
          case 4:
            switch (wettyp) {
              case 0:
                spos1 = (i*Ymax + fCppMod(j-1, Ymax))*Zmax + k;
                rhoy = rho[tpos] - rho[spos1];
                phiy = phi[tpos] - phi[spos1];
                break;
              case 1:
                rhoy = -drdb;
                phiy = -dpdb;
                break;
            }
            break;
          case 5:
            spos1 = (i*Ymax + fCppMod(j-1, Ymax))*Zmax + k;
            spos2 = (i*Ymax + fCppMod(j-2, Ymax))*Zmax + k;
            switch (wettyp) {
              case 0:
                rhoy = 1.5*rho[tpos] - 2.0*rho[spos1] + 0.5*rho[spos2];
                rho2 += rho[tpos] - 2.0*rho[spos1] + rho[spos2];
                phiy = 1.5*phi[tpos] - 2.0*phi[spos1] + 0.5*phi[spos2];
                phi2 += phi[tpos] - 2.0*phi[spos1] + phi[spos2];
                break;
              case 1:
                rhoy = -drdb;
                d1 = 0.5*(rho[tpos] - rho[spos2]);
                d2 = -1.5*rho[spos2] + 2.0*rho[spos1] - 0.5*rho[tpos];
                rho2 += (1.5*rhoy - 2.0*d1 + 0.5*d2);
                phiy = -dpdb;
                p1 = 0.5*(phi[tpos] - phi[spos2]);
                p2 = -1.5*phi[spos2] + 2.0*phi[spos1] - 0.5*phi[tpos];
                phi2 += (1.5*phiy - 2.0*p1 + 0.5*p2);
                break;
            }
            break;
        }
        switch (nz) {
          case 1:
            spos1 = (i*Ymax + j)*Zmax + fCppMod(k-1, Zmax);
            spos2 = (i*Ymax + j)*Zmax + fCppMod(k+1, Zmax);
            rhoz = 0.5*(rho[spos2] - rho[spos1]);
            rho2 += (rho[spos1]-2.0*rho[tpos]+rho[spos2]);
            phiz = 0.5*(phi[spos2] - phi[spos1]);
            phi2 += (phi[spos1]-2.0*phi[tpos]+phi[spos2]);
            break;
          case 2:
            switch (wettyp) {
              case 0:
                spos1 = (i*Ymax + j)*Zmax + fCppMod(k+1, Zmax);
                rhoz = rho[spos1] - rho[tpos];
                phiz = phi[spos1] - phi[tpos];
                break;
              case 1:
                rhoz = drdb;
                phiz = dpdb;
                break;
            }
            break;
          case 3:
            spos1 = (i*Ymax + j)*Zmax + fCppMod(k+1, Zmax);
            spos2 = (i*Ymax + j)*Zmax + fCppMod(k+2, Zmax);
            switch (wettyp) {
              case 0:
                rhoz = -1.5*rho[tpos] + 2.0*rho[spos1] - 0.5*rho[spos2];
                rho2 += rho[tpos] - 2.0*rho[spos1] + rho[spos2];
                phiz = -1.5*phi[tpos] + 2.0*phi[spos1] - 0.5*phi[spos2];
                phi2 += phi[tpos] - 2.0*phi[spos1] + phi[spos2];
                break;
              case 1:
                rhoz = drdb;
                d1 = 0.5*(rho[spos2] - rho[tpos]);
                d2 = 1.5*rho[spos2] - 2.0*rho[spos1] + 0.5*rho[tpos];
                rho2 += (-1.5*rhoz + 2.0*d1 - 0.5*d2);
                phiz = dpdb;
                p1 = 0.5*(phi[spos2] - phi[tpos]);
                p2 = 1.5*phi[spos2] - 2.0*phi[spos1] + 0.5*phi[tpos];
                phi2 += (-1.5*phiz + 2.0*p1 - 0.5*p2);
                break;
            }
            break;
          case 4:
            switch (wettyp) {
              case 0:
                spos1 = (i*Ymax + j)*Zmax + fCppMod(k-1, Zmax);
                rhoz = rho[tpos] - rho[spos1];
                phiz = phi[tpos] - phi[spos1];
                break;
              case 1:
                rhoz = -drdb;
                phiz = -dpdb;
                break;
            }
            break;
          case 5:
            spos1 = (i*Ymax + j)*Zmax + fCppMod(k-1, Zmax);
            spos2 = (i*Ymax + j)*Zmax + fCppMod(k-2, Zmax);
            switch (wettyp) {
              case 0:
                rhoz = 1.5*rho[tpos] - 2.0*rho[spos1] + 0.5*rho[spos2];
                rho2 += rho[tpos] - 2.0*rho[spos1] + rho[spos2];
                phiz = 1.5*phi[tpos] - 2.0*phi[spos1] + 0.5*phi[spos2];
                phi2 += phi[tpos] - 2.0*phi[spos1] + phi[spos2];
                break;
              case 1:
                rhoz = -drdb;
                d1 = 0.5*(rho[tpos] - rho[spos2]);
                d2 = -1.5*rho[spos2] + 2.0*rho[spos1] - 0.5*rho[tpos];
                rho2 += (1.5*rhoz - 2.0*d1 + 0.5*d2);
                phiz = -dpdb;
                p1 = 0.5*(phi[tpos] - phi[spos2]);
                p2 = -1.5*phi[spos2] + 2.0*phi[spos1] - 0.5*phi[tpos];
                phi2 += (1.5*phiz - 2.0*p1 + 0.5*p2);
                break;
            }
            break;
        }
      }
      else {
        for(int m=0; m<19; m++) {
          spos = (fCppMod(i+lbfevx[m], Xmax) * Ymax + fCppMod(j+lbfevy[m], Ymax)) * Zmax + fCppMod(k+lbfevz[m], Zmax);
          rhox += dx[m] * rho[spos];
          phix += dx[m] * phi[spos];
          rhoy += dy[m] * rho[spos];
          phiy += dy[m] * phi[spos];
          rhoz += dz[m] * rho[spos];
          phiz += dz[m] * phi[spos];
          rho2 += nabla[m] * rho[spos];
          phi2 += nabla[m] * phi[spos];
        }
      }
      lbft[8*tpos  ] = rhox;
      lbft[8*tpos+1] = rhoy;
      lbft[8*tpos+2] = rhoz;
      lbft[8*tpos+3] = rho2;
      lbft[8*tpos+4] = phix;
      lbft[8*tpos+5] = phiy;
      lbft[8*tpos+6] = phiz;
      lbft[8*tpos+7] = phi2;
    }
    #pragma omp for private(i,j,k,spos,spos1,spos2,tpos,nx,ny,nz,d1,d2,drdb,rhox,rhoy,rhoz,rho2,p1,p2,dpdb,phix,phiy,phiz,phi2) collapse(3)
    for(i=lbdm.owidx; i<(Xmax-lbdm.owidx); i++) {
      for(j=lbdm.owidy; j<(Ymax-lbdm.owidy); j++) {
        for(k=lbdm.owidz; k<(Zmax-lbdm.owidz); k++) {
          rhox = 0.0; rhoy = 0.0; rhoz = 0.0; rho2 = 0.0;
          phix = 0.0; phiy = 0.0; phiz = 0.0; phi2 = 0.0;
          tpos = (i * Ymax + j) * Zmax + k;
          if(lbneigh[tpos]>0) {
            drdb = lbfewet[0] + lbfewet[1]*rho[tpos];
            dpdb = lbfewet[2] + lbfewet[3]*phi[tpos];
            nx = lbneigh[tpos]/100;
            ny = (lbneigh[tpos]/10)%10;
            nz = (lbneigh[tpos])%10;
            switch (nx) {
              case 1:
                spos1 = ((i-1)*Ymax + j)*Zmax + k;
                spos2 = ((i+1)*Ymax + j)*Zmax + k;
                rhox = 0.5*(rho[spos2] - rho[spos1]);
                rho2 += (rho[spos1]-2.0*rho[tpos]+rho[spos2]);
                phix = 0.5*(phi[spos2] - phi[spos1]);
                phi2 += (phi[spos1]-2.0*phi[tpos]+phi[spos2]);
                break;
              case 2:
                switch (wettyp) {
                  case 0:
                    spos1 = ((i+1)*Ymax + j)*Zmax + k;
                    rhox = rho[spos1] - rho[tpos];
                    phix = phi[spos1] - phi[tpos];
                    break;
                  case 1:
                    rhox = drdb;
                    phix = dpdb;
                    break;
                }
                break;
              case 3:
                spos1 = ((i+1)*Ymax + j)*Zmax + k;
                spos2 = (fCppMod(i+2, Xmax)*Ymax + j)*Zmax + k;
                switch (wettyp) {
                  case 0:
                    rhox = -1.5*rho[tpos] + 2.0*rho[spos1] - 0.5*rho[spos2];
                    rho2 += rho[tpos] - 2.0*rho[spos1] + rho[spos2];
                    phix = -1.5*phi[tpos] + 2.0*phi[spos1] - 0.5*phi[spos2];
                    phi2 += phi[tpos] - 2.0*phi[spos1] + phi[spos2];
                    break;
                  case 1:
                    rhox = drdb;
                    d1 = 0.5*(rho[spos2] - rho[tpos]);
                    d2 = 1.5*rho[spos2] - 2.0*rho[spos1] + 0.5*rho[tpos];
                    rho2 += (-1.5*rhox + 2.0*d1 - 0.5*d2);
                    phix = dpdb;
                    p1 = 0.5*(phi[spos2] - phi[tpos]);
                    p2 = 1.5*phi[spos2] - 2.0*phi[spos1] + 0.5*phi[tpos];
                    phi2 += (-1.5*phix + 2.0*p1 - 0.5*p2);
                    break;
                }
                break;
              case 4:
                switch (wettyp) {
                  case 0:
                    spos1 = ((i-1)*Ymax + j)*Zmax + k;
                    rhox = rho[tpos] - rho[spos1];
                    phix = phi[tpos] - phi[spos1];
                    break;
                  case 1:
                    rhox = -drdb;
                    phix = -dpdb;
                    break;
                }
                break;
              case 5:
                spos1 = ((i-1)*Ymax + j)*Zmax + k;
                spos2 = (fCppMod(i-2, Xmax)*Ymax + j)*Zmax + k;
                switch (wettyp) {
                  case 0:
                    rhox = 1.5*rho[tpos] - 2.0*rho[spos1] + 0.5*rho[spos2];
                    rho2 += rho[tpos] - 2.0*rho[spos1] + rho[spos2];
                    phix = 1.5*phi[tpos] - 2.0*phi[spos1] + 0.5*phi[spos2];
                    phi2 += phi[tpos] - 2.0*phi[spos1] + phi[spos2];
                    break;
                  case 1:
                    rhox = -drdb;
                    d1 = 0.5*(rho[tpos] - rho[spos2]);
                    d2 = -1.5*rho[spos2] + 2.0*rho[spos1] - 0.5*rho[tpos];
                    rho2 += (1.5*rhox - 2.0*d1 + 0.5*d2);
                    phix = -dpdb;
                    p1 = 0.5*(phi[tpos] - phi[spos2]);
                    p2 = -1.5*phi[spos2] + 2.0*phi[spos1] - 0.5*phi[tpos];
                    phi2 += (1.5*phix - 2.0*p1 + 0.5*p2);
                    break;
                }
                break;
            }
            switch (ny) {
              case 1:
                spos1 = (i*Ymax + j-1)*Zmax + k;
                spos2 = (i*Ymax + j+1)*Zmax + k;
                rhoy = 0.5*(rho[spos2] - rho[spos1]);
                rho2 += (rho[spos1]-2.0*rho[tpos]+rho[spos2]);
                phiy = 0.5*(phi[spos2] - phi[spos1]);
                phi2 += (phi[spos1]-2.0*phi[tpos]+phi[spos2]);
                break;
              case 2:
                switch (wettyp) {
                  case 0:
                    spos1 = (i*Ymax + j+1)*Zmax + k;
                    rhoy = rho[spos1] - rho[tpos];
                    phiy = phi[spos1] - phi[tpos];
                    break;
                  case 1:
                    rhoy = drdb;
                    phiy = dpdb;
                    break;
                }
                break;
              case 3:
                spos1 = (i*Ymax + j+1)*Zmax + k;
                spos2 = (i*Ymax + fCppMod(j+2, Ymax))*Zmax + k;
                switch (wettyp) {
                  case 0:
                    rhoy = -1.5*rho[tpos] + 2.0*rho[spos1] - 0.5*rho[spos2];
                    rho2 += rho[tpos] - 2.0*rho[spos1] + rho[spos2];
                    phiy = -1.5*phi[tpos] + 2.0*phi[spos1] - 0.5*phi[spos2];
                    phi2 += phi[tpos] - 2.0*phi[spos1] + phi[spos2];
                    break;
                  case 1:
                    rhoy = drdb;
                    d1 = 0.5*(rho[spos2] - rho[tpos]);
                    d2 = 1.5*rho[spos2] - 2.0*rho[spos1] + 0.5*rho[tpos];
                    rho2 += (-1.5*rhoy + 2.0*d1 - 0.5*d2);
                    phiy = dpdb;
                    p1 = 0.5*(phi[spos2] - phi[tpos]);
                    p2 = 1.5*phi[spos2] - 2.0*phi[spos1] + 0.5*phi[tpos];
                    phi2 += (-1.5*phiy + 2.0*p1 - 0.5*p2);
                    break;
                }
                break;
              case 4:
                switch (wettyp) {
                  case 0:
                    spos1 = (i*Ymax + j-1)*Zmax + k;
                    rhoy = rho[tpos] - rho[spos1];
                    phiy = phi[tpos] - phi[spos1];
                    break;
                  case 1:
                    rhoy = -drdb;
                    phiy = -dpdb;
                    break;
                }
                break;
              case 5:
                spos1 = (i*Ymax + j-1)*Zmax + k;
                spos2 = (i*Ymax + fCppMod(j-2, Ymax))*Zmax + k;
                switch (wettyp) {
                  case 0:
                    rhoy = 1.5*rho[tpos] - 2.0*rho[spos1] + 0.5*rho[spos2];
                    rho2 += rho[tpos] - 2.0*rho[spos1] + rho[spos2];
                    phiy = 1.5*phi[tpos] - 2.0*phi[spos1] + 0.5*phi[spos2];
                    phi2 += phi[tpos] - 2.0*phi[spos1] + phi[spos2];
                    break;
                  case 1:
                    rhoy = -drdb;
                    d1 = 0.5*(rho[tpos] - rho[spos2]);
                    d2 = -1.5*rho[spos2] + 2.0*rho[spos1] - 0.5*rho[tpos];
                    rho2 += (1.5*rhoy - 2.0*d1 + 0.5*d2);
                    phiy = -dpdb;
                    p1 = 0.5*(phi[tpos] - phi[spos2]);
                    p2 = -1.5*phi[spos2] + 2.0*phi[spos1] - 0.5*phi[tpos];
                    phi2 += (1.5*phiy - 2.0*p1 + 0.5*p2);
                    break;
                }
            }
            switch (nz) {
              case 1:
                spos1 = (i*Ymax + j)*Zmax + ((lbsy.nd>2)?k-1:0);
                spos2 = (i*Ymax + j)*Zmax + ((lbsy.nd>2)?k+1:0);
                rhoz = 0.5*(rho[spos2] - rho[spos1]);
                phiz = 0.5*(phi[spos2] - phi[spos1]);
                rho2 += (rho[spos1]-2.0*rho[tpos]+rho[spos2]);
                phi2 += (phi[spos1]-2.0*phi[tpos]+phi[spos2]);
                break;
              case 2:
                switch (wettyp) {
                  case 0:
                    spos1 = (i*Ymax + j)*Zmax + ((lbsy.nd>2)?k+1:0);
                    rhoz = rho[spos1] - rho[tpos];
                    phiz = phi[spos1] - phi[tpos];
                    break;
                  case 1:
                    rhoz = drdb;
                    phiz = dpdb;
                    break;
                }
                break;
              case 3:
                spos1 = (i*Ymax + j)*Zmax + ((lbsy.nd>2)?k+1:0);
                spos2 = (i*Ymax + j)*Zmax + ((lbsy.nd>2)?fCppMod(k+2, Zmax):0);
                switch (wettyp) {
                  case 0:
                    rhoz = -1.5*rho[tpos] + 2.0*rho[spos1] - 0.5*rho[spos2];
                    rho2 += rho[tpos] - 2.0*rho[spos1] + rho[spos2];
                    phiz = -1.5*phi[tpos] + 2.0*phi[spos1] - 0.5*phi[spos2];
                    phi2 += phi[tpos] - 2.0*phi[spos1] + phi[spos2];
                    break;
                  case 1:
                    rhoz = drdb;
                    d1 = 0.5*(rho[spos2] - rho[tpos]);
                    d2 = 1.5*rho[spos2] - 2.0*rho[spos1] + 0.5*rho[tpos];
                    rho2 += (-1.5*rhoz + 2.0*d1 - 0.5*d2);
                    phiz = dpdb;
                    p1 = 0.5*(phi[spos2] - phi[tpos]);
                    p2 = 1.5*phi[spos2] - 2.0*phi[spos1] + 0.5*phi[tpos];
                    phi2 += (-1.5*phiz + 2.0*p1 - 0.5*p2);
                    break;
                }
                break;
              case 4:
                switch (wettyp) {
                  case 0:
                    spos1 = (i*Ymax + j)*Zmax + ((lbsy.nd>2)?k-1:0);
                    rhoz = rho[tpos] - rho[spos1];
                    phiz = phi[tpos] - phi[spos1];
                    break;
                  case 1:
                    rhoz = -drdb;
                    phiz = -dpdb;
                    break;
                }
                break;
              case 5:
                spos1 = (i*Ymax + j)*Zmax + ((lbsy.nd>2)?k-1:0);
                spos2 = (i*Ymax + j)*Zmax + ((lbsy.nd>2)?fCppMod(k-2, Zmax):0);
                switch (wettyp) {
                  case 0:
                    rhoz = 1.5*rho[tpos] - 2.0*rho[spos1] + 0.5*rho[spos2];
                    rho2 += rho[tpos] - 2.0*rho[spos1] + rho[spos2];
                    phiz = 1.5*phi[tpos] - 2.0*phi[spos1] + 0.5*phi[spos2];
                    phi2 += phi[tpos] - 2.0*phi[spos1] + phi[spos2];
                    break;
                  case 1:
                    rhoz = -drdb;
                    d1 = 0.5*(rho[tpos] - rho[spos2]);
                    d2 = -1.5*rho[spos2] + 2.0*rho[spos1] - 0.5*rho[tpos];
                    rho2 += (1.5*rhoz - 2.0*d1 + 0.5*d2);
                    phiz = -dpdb;
                    p1 = 0.5*(phi[tpos] - phi[spos2]);
                    p2 = -1.5*phi[spos2] + 2.0*phi[spos1] - 0.5*phi[tpos];
                    phi2 += (1.5*phiz - 2.0*p1 + 0.5*p2);
                    break;
                }
                break;
            }
          }
          else {
            for(int m=0; m<19; m++) {
              spos = ((i+lbfevx[m]) * Ymax + j+lbfevy[m]) * Zmax + k+lbfevz[m];
              rhox += dx[m] * rho[spos];
              phix += dx[m] * phi[spos];
              rhoy += dy[m] * rho[spos];
              phiy += dy[m] * phi[spos];
              rhoz += dz[m] * rho[spos];
              phiz += dz[m] * phi[spos];
              rho2 += nabla[m] * rho[spos];
              phi2 += nabla[m] * phi[spos];
            }
          }
          lbft[8*tpos  ] = rhox;
          lbft[8*tpos+1] = rhoy;
          lbft[8*tpos+2] = rhoz;
          lbft[8*tpos+3] = rho2;
          lbft[8*tpos+4] = phix;
          lbft[8*tpos+5] = phiy;
          lbft[8*tpos+6] = phiz;
          lbft[8*tpos+7] = phi2;
        }
      }
    }
    delete [] rho;
    delete [] phi;
  }
  return 0;
}

int fCalcGradient_Swift()
{
  if(lbsy.nf>1)
    fCalcDensityConcentrationGradient_Swift();
  else
    fCalcDensityGradient_Swift();
  return 0;
}

int fsCalcGradient_Swift()
{
  if(lbsy.nf>1)
    fsCalcDensityConcentrationGradient_Swift();
  else
    fsCalcDensityGradient_Swift();
  return 0;
}


int fCalcForce_Boussinesq(long tpos, double temph, double templ)
{
  double temp, rhotemp, dens, frac;
  double temp0 = 0.5 * (temph + templ);
  double rho[lbsy.nf];
  double *pt2 = &lbf[tpos*lbsitelength];
  temp = fGetTemperatureSite(tpos);
  fGetAllMassSite(rho, pt2);
  if(interact==20 && lbsy.nf>1) {
    dens = rho[0];
    frac = 0.5*(1.0+rho[1]);
    rhotemp = dens*frac * (temp-temp0) * fReciprocal(temph-templ);
    lbheatforce[tpos*3*lbsy.nf]   -= rhotemp * lbbousforce[0];
    lbheatforce[tpos*3*lbsy.nf+1] -= rhotemp * lbbousforce[1];
    lbheatforce[tpos*3*lbsy.nf+2] -= rhotemp * lbbousforce[2];
    rhotemp = dens*(1.0-frac) * (temp-temp0) * fReciprocal(temph-templ);
    lbheatforce[tpos*3*lbsy.nf+3] -= rhotemp * lbbousforce[3];
    lbheatforce[tpos*3*lbsy.nf+4] -= rhotemp * lbbousforce[4];
    lbheatforce[tpos*3*lbsy.nf+5] -= rhotemp * lbbousforce[5];
  }
  else if(!incompress) {
    for(int j=0; j<lbsy.nf; j++) {
      rhotemp = rho[j] * (temp-temp0) * fReciprocal(temph-templ);
      lbheatforce[tpos*3*lbsy.nf+3*j]   -= rhotemp * lbbousforce[j*3];
      lbheatforce[tpos*3*lbsy.nf+3*j+1] -= rhotemp * lbbousforce[j*3+1];
      lbheatforce[tpos*3*lbsy.nf+3*j+2] -= rhotemp * lbbousforce[j*3+2];
    }
  }
  else {
    for(int j=0; j<lbsy.nf; j++) {
      rhotemp = lbincp[j] * (temp-temp0) * fReciprocal(temph-templ);
      lbheatforce[tpos*3*lbsy.nf+3*j]   -= rhotemp * lbbousforce[j*3];
      lbheatforce[tpos*3*lbsy.nf+3*j+1] -= rhotemp * lbbousforce[j*3+1];
      lbheatforce[tpos*3*lbsy.nf+3*j+2] -= rhotemp * lbbousforce[j*3+2];
    }
  }
  pt2 = NULL;
  return 0;
}


int fConvectionForceBoussinesq(double temph, double templ)
{
  long Touter = (long) lbdm.touter;

  if(lbsy.nt==1) {
    #pragma omp parallel
    {
      #pragma omp for
      for(long il=0; il<Touter; il++) {
        if(lbphi[il]<11)
          fCalcForce_Boussinesq(il, temph, templ);
      }
    }
  }
  return 0;
}



