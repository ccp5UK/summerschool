import javax.swing.*;
import java.util.*;
import java.lang.*;
import java.io.*;
import java.awt.*;
import java.awt.event.*;
import java.awt.geom.*;
import java.awt.image.*;
/*
 *     DL_MESO_GUI
 *     author: R. S. Qin, M. A. Seaton
 *     copyright: UKRI STFC Daresbury Laboratory and CCP5
 *     2005, 2018
 */
class setThermal extends JFrame {

    setlbeSysEvt theinilbe=new setlbeSysEvt(this);
    Font font=new Font("Dialog", Font.BOLD, 13);

    JLabel difulabel = new JLabel("heat relaxation time",JLabel.RIGHT);
    JTextField difut = new JTextField(5);

    JLabel inilabel = new JLabel("initial T(K):", JLabel.RIGHT);
    JTextField init = new JTextField(5);
    JLabel inidtlabel = new JLabel("initial dT/dt (K/s):", JLabel.RIGHT);
    JTextField inidt = new JTextField(5);

    JLabel boushlabel = new JLabel("boussinesq high T(K):", JLabel.RIGHT);
    JTextField boushigh = new JTextField(5);
    JLabel bousllabel = new JLabel("boussinesq low T(K):", JLabel.RIGHT);
    JTextField bouslow = new JTextField(5);
 
    JButton save = new JButton("SAVE T");
    JButton close = new JButton("CANCEL T");

    public setThermal(int dim, double heatrelax, double boustemph, double boustempl, 
                      double tempsi, double heatratesi) {
	super("LBE thermal properties");
	setBounds(160, 10, 312, 530);
	JPanel pane=new JPanel(new GridBagLayout());

        inilabel.setFont(font);
        addItem(pane, inilabel, 0, 0, 2, 1, GridBagConstraints.WEST);
        init.setText(Double.toString(tempsi));
        addItem(pane, init, 2, 0, 1, 1, GridBagConstraints.CENTER);

        inidtlabel.setFont(font);
        addItem(pane, inidtlabel, 0, 1, 2, 1, GridBagConstraints.WEST);
        inidt.setText(Double.toString(heatratesi));
        addItem(pane, inidt, 2, 1, 1, 1, GridBagConstraints.CENTER);

        boushlabel.setFont(font);
        addItem(pane, boushlabel, 0, 2, 2, 1, GridBagConstraints.WEST);
        boushigh.setText(Double.toString(boustemph));
        addItem(pane, boushigh, 2, 2, 1, 1, GridBagConstraints.CENTER);

        bousllabel.setFont(font);
        addItem(pane, bousllabel, 0, 3, 2, 1, GridBagConstraints.WEST);
        bouslow.setText(Double.toString(boustempl));
        addItem(pane, bouslow, 2, 3, 1, 1, GridBagConstraints.CENTER);

        difulabel.setFont(font);
        addItem(pane, difulabel, 0, 4, 2, 1, GridBagConstraints.WEST);
        difut.setText(Double.toString(heatrelax));
        addItem(pane, difut, 2, 4, 1, 1, GridBagConstraints.CENTER);

        save.setFont(font);
        save.addActionListener(theinilbe);
        addItem(pane, save, 0, 5, 1, 1, GridBagConstraints.CENTER);

        close.setFont(font);
        close.addActionListener(theinilbe);
        addItem(pane, close, 1, 5, 1, 1, GridBagConstraints.CENTER);

        this.add(pane);
        this.pack();
        setVisible(true);
    }

    private void addItem(JPanel p, JComponent c, int x, int y, int width, int height, int align)
    {
        GridBagConstraints gc = new GridBagConstraints();
        gc.gridx = x;
        gc.gridy = y;
        gc.gridwidth = width;
        gc.gridheight = height;
        gc.weightx = 100.0;
        gc.weighty = 100.0;
        gc.insets = new Insets(5, 5, 5, 5);
        gc.anchor = align;
        gc.fill = GridBagConstraints.NONE;
        p.add(c, gc);
    }

}
