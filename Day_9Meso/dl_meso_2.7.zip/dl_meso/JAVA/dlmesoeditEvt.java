import javax.swing.*;
import java.util.*;
import java.lang.*;
import java.io.*;
import java.awt.*;
import java.awt.event.*;
import java.awt.geom.*;
import java.awt.image.*;
/*
 *     DL_MESO_GUI
 *     author: R. S. Qin, M. A. Seaton
 *     copyright: UKRI STFC Daresbury Laboratory and CCP5
 *     2005, 2018
 */
class dlmesoeditEvt implements ActionListener {
    
    dlmesoeditor gui;
    FileWriter ot;
    String ostr="input-file";
    public dlmesoeditEvt(dlmesoeditor in) {
	gui =in;
    }

    public void actionPerformed(ActionEvent event) {
	String cmd =event.getActionCommand();
	if (cmd == "save"){
	    try {
		ot = new FileWriter(gui.filename, false);
		ostr = gui.text.getText();
		ot.write(ostr +"\n");
		try {
		    ot.close();
		} catch (IOException es) {
		    System.out.println("Exception: "+es.getMessage());
		}
	    } catch (IOException e) {
		System.out.println("Exception: "+e.getMessage());
	    }
	}
	else if(cmd == "exit")
	    gui.dispose();
    }
}
