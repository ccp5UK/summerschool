#include <iostream>
#include <fstream>
#include <string>
#include <cstring>
#include <cstdlib>
#include <stdio.h>
#include <sys/stat.h>
using namespace std;


/**************************************************
 *   DL_MESO       Version 2.7                    *
 *   Authors   :   R. S. Qin, M. A. Seaton        *
 *   Copyright :   UKRI STFC Daresbury Laboratory *
 *             :   09/12/2018                     *
 **************************************************/

class cGatherData
{

  // put all datafiles saved by individual processes into a single datafile: 
  // one grid file (lbtout.xyz or lbtout.xy) and a series of solution files
  // (lbtout%.6d.q, where %.6d is the saved time step)

  // the data structure follows the Fluid3D standard, in multi-grid format
  
public:

  cGatherData()
    {

      getsize();
      gatherallG();
      gatherallQ();

    }

  ~cGatherData()
    {

      delete [] sizeofbufg;
      delete [] sizeofbufq;      

    }

  int getsize();

  int gatherallG();

  int gatherallQ();
  
protected:

  bool alldata;

  int numofdim;

  int sizeofint;

  int sizeofsys;

  int sizeofver;

  int numfluid;

  int numsolute;

  int numtemp;

  unsigned long *sizeofbufg;

  unsigned long *sizeofbufq;

};


int cGatherData::getsize()
{

  // this procedure is required to avoid mismatches caused by different 
  // machines

  char buf[80];
  char issue[22];
  double value;

  ifstream myfile("lbout.info");

  if(!myfile)
    {
      cout<<"error opening "<<"lbout.info"<<" file\n"; 
      exit(1);
    }

  while (!myfile.eof())
    {

      myfile >> issue >> value;

      if(!strcmp(issue, "numberofDimensions"))
        numofdim = int(value);

      else if(!strcmp(issue, "sizeofSystem")) 
        sizeofsys = int(value);

      else if(!strcmp(issue, "sizeofInteger")) 
        sizeofint = int(value);

      else if(!strcmp(issue, "numberofFluids")) 
        numfluid = int(value);

      else if(!strcmp(issue, "numberofSolutes")) 
        numsolute = int(value);

      else if(!strcmp(issue, "numberofTemperatures")) 
        numtemp = int(value);

    }

  myfile.close();

  //  this procedure can work out whether or not all simulation data is
  //  available

  ifstream myfile1("lbout00dens000000at000000.q");
  alldata = (bool)myfile1;
  myfile1.close();

  //  this procedure can deal with unequal numbers of grid points among
  //  processes

  sizeofbufg=new unsigned long[sizeofsys];
  sizeofbufq=new unsigned long[sizeofsys];

  struct stat results;

  for(int i=0; i<sizeofsys; i++)
    {
      if(alldata)
        sprintf(buf, "lbout00dens%.6dat000000.q", i);
      else
        sprintf(buf, "lbout%.6dat000000.q", i);

      if(stat(buf, &results) == 0) 
        sizeofbufq[i] = results.st_size;

      else
        cout<<"error opening "<<buf<<" file\n";

      if(numofdim==2)
        sprintf(buf, "lbout%.6d.xy", i);
      else
        sprintf(buf, "lbout%.6d.xyz", i);

      if(stat(buf, &results) == 0) 
        sizeofbufg[i] = results.st_size;

      else
        cout<<"error opening "<<buf<<" file\n";      
    }

  //  work out the number of Q-files available

  int i=0;
  
  while(1)
    {

      if(alldata)
        sprintf(buf, "lbout00dens000000at%.4d.q", i);
      else
        sprintf(buf, "lbout000000at%.6d.q", i);

      ifstream myfile1(buf);

      if(!myfile1)
        {
          sizeofver = i;
          break;
        }
      
      i++;
      
    }
  
  return 0;
  
}


int cGatherData::gatherallG()
{

  // sort out all grid positions

  unsigned long maxbufsize=0;
  
  unsigned long pos=0;
  
  unsigned long pos1=0;

  string filename="lbtout.xyz";

  for(int i=0; i<sizeofsys; i++) 
    {
      if(maxbufsize < sizeofbufg[i])
        maxbufsize = sizeofbufg[i];
    }
  
  char *buf = new char[maxbufsize]; 

  char namebuf[80];

  if (numofdim==2)
    filename="lbtout.xy";

  ofstream ofile(filename.c_str());

  ofile.write((char*)&sizeofsys, sizeofint);

  pos1=(sizeofsys*numofdim+1)*sizeofint;

  for(int i=0; i<sizeofsys; i++) {

    sprintf(namebuf, "lbout%.6d.xyz", i);
    if (numofdim==2)
      sprintf(namebuf, "lbout%.6d.xy", i);

    ifstream ifile(namebuf);
    ifile.seekg(0);
    ifile.read(buf, numofdim*sizeofint);
    pos = (i*numofdim+1)*sizeofint;

    ofile.seekp(pos);
    ofile.write(buf, sizeofint*numofdim);

    ifile.seekg(numofdim*sizeofint);
    ifile.read(buf, sizeofbufg[i]-numofdim*sizeofint);

    ofile.seekp(pos1);
    ofile.write(buf, sizeofbufg[i]-numofdim*sizeofint);    

    pos1 += sizeofbufg[i]-numofdim*sizeofint;

    ifile.close();

  }

  ofile.close();

  delete [] buf;

  return 0;
}

int cGatherData::gatherallQ()
{

  // sort out all Q-files

  unsigned long maxbufsize=0;

  unsigned long pos=0;

  unsigned long pos1=0;

  for(int i=0; i<sizeofsys; i++) 
    {
      if(maxbufsize < sizeofbufq[i])
        maxbufsize = sizeofbufq[i];
    }
  
  char *buf = new char[maxbufsize]; 
  
  char namebuf[80];

  if(alldata) {

    for(int iprop=0; iprop<numfluid; iprop++) {

      for(int k=0; k<sizeofver; k++) {

        sprintf(namebuf, "lbtout%.2ddens%.6d.q", iprop, k);

        ofstream ofile(namebuf);
        ofile.write((char*)&sizeofsys, sizeofint);

        pos1=(sizeofsys*numofdim+1)*sizeofint;

        for(int i=0; i<sizeofsys; i++) {
          sprintf(namebuf, "lbout%.2ddens%.6dat%.6d.q", iprop, i, k);

          ifstream ifile(namebuf);
          ifile.seekg(0);
          ifile.read(buf, numofdim*sizeofint);

          pos = (i*numofdim+1)*sizeofint;
          ofile.seekp(pos);
          ofile.write(buf, sizeofint*numofdim);

          ifile.seekg(numofdim*sizeofint);
          ifile.read(buf, sizeofbufq[i]-numofdim*sizeofint);

          ofile.seekp(pos1);
          ofile.write(buf, sizeofbufq[i]-numofdim*sizeofint);    

          pos1 += sizeofbufq[i]-numofdim*sizeofint;

          ifile.close();

        }

        ofile.close();

      }

      for(int k=0; k<sizeofver; k++) {

        sprintf(namebuf, "lbtout%.2dfrac%.6d.q", iprop, k);

        ofstream ofile(namebuf);
        ofile.write((char*)&sizeofsys, sizeofint);

        pos1=(sizeofsys*numofdim+1)*sizeofint;

        for(int i=0; i<sizeofsys; i++) {
          sprintf(namebuf, "lbout%.2dfrac%.6dat%.6d.q", iprop, i, k);

          ifstream ifile(namebuf);
          ifile.seekg(0);
          ifile.read(buf, numofdim*sizeofint);

          pos = (i*numofdim+1)*sizeofint;
          ofile.seekp(pos);
          ofile.write(buf, sizeofint*numofdim);

          ifile.seekg(numofdim*sizeofint);
          ifile.read(buf, sizeofbufq[i]-numofdim*sizeofint);

          ofile.seekp(pos1);
          ofile.write(buf, sizeofbufq[i]-numofdim*sizeofint);    

          pos1 += sizeofbufq[i]-numofdim*sizeofint;

          ifile.close();

        }

        ofile.close();

      }

    }

    for(int iprop=0; iprop<numsolute; iprop++) {

      for(int k=0; k<sizeofver; k++) {

        sprintf(namebuf, "lbtout%.2dconc%.6d.q", iprop, k);

        ofstream ofile(namebuf);
        ofile.write((char*)&sizeofsys, sizeofint);

        pos1=(sizeofsys*numofdim+1)*sizeofint;

        for(int i=0; i<sizeofsys; i++) {
          sprintf(namebuf, "lbout%.2dconc%.6dat%.6d.q", iprop, i, k);

          ifstream ifile(namebuf);
          ifile.seekg(0);
          ifile.read(buf, numofdim*sizeofint);

          pos = (i*numofdim+1)*sizeofint;
          ofile.seekp(pos);
          ofile.write(buf, sizeofint*numofdim);

          ifile.seekg(numofdim*sizeofint);
          ifile.read(buf, sizeofbufq[i]-numofdim*sizeofint);

          ofile.seekp(pos1);
          ofile.write(buf, sizeofbufq[i]-numofdim*sizeofint);    

          pos1 += sizeofbufq[i]-numofdim*sizeofint;

          ifile.close();

        }

        ofile.close();

      }

    }

    if(numtemp==1) {

      for(int k=0; k<sizeofver; k++) {

        sprintf(namebuf, "lbtouttemp%.6d.q", k);

        ofstream ofile(namebuf);
        ofile.write((char*)&sizeofsys, sizeofint);

        pos1=(sizeofsys*numofdim+1)*sizeofint;

        for(int i=0; i<sizeofsys; i++) {
          sprintf(namebuf, "lbouttemp%.6dat%.6d.q", i, k);

          ifstream ifile(namebuf);
          ifile.seekg(0);
          ifile.read(buf, numofdim*sizeofint);

          pos = (i*numofdim+1)*sizeofint;
          ofile.seekp(pos);
          ofile.write(buf, sizeofint*numofdim);

          ifile.seekg(numofdim*sizeofint);
          ifile.read(buf, sizeofbufq[i]-numofdim*sizeofint);

          ofile.seekp(pos1);
          ofile.write(buf, sizeofbufq[i]-numofdim*sizeofint);    

          pos1 += sizeofbufq[i]-numofdim*sizeofint;

          ifile.close();

        }

        ofile.close();

      }

    }

  }
  else {

    for(int k=0; k<sizeofver; k++) {

      sprintf(namebuf, "lbtout%.6d.q", k);

      ofstream ofile(namebuf);
      ofile.write((char*)&sizeofsys, sizeofint);

      pos1=(sizeofsys*numofdim+1)*sizeofint;

      for(int i=0; i<sizeofsys; i++) {
        sprintf(namebuf, "lbout%.6dat%.6d.q", i, k);

        ifstream ifile(namebuf);
        ifile.seekg(0);
        ifile.read(buf, numofdim*sizeofint);

        pos = (i*numofdim+1)*sizeofint;
        ofile.seekp(pos);
        ofile.write(buf, sizeofint*numofdim);

        ifile.seekg(numofdim*sizeofint);
        ifile.read(buf, sizeofbufq[i]-numofdim*sizeofint);

        ofile.seekp(pos1);
        ofile.write(buf, sizeofbufq[i]-numofdim*sizeofint);    

        pos1 += sizeofbufq[i]-numofdim*sizeofint;

        ifile.close();

      }

      ofile.close();

    }

  }

  delete [] buf;

  return 0;
}


int main(int argc, char* argv[])
{
  string word;
  for(int i=1; i<argc; i++) {
    if(word.compare(0,2,"-h")==0 || word.compare(0,2,"-H")==0) {
      cout << "DL_MESO Plot3D gather utility, creates combined output" << endl;
      cout << "files from *.q files generated when running DL_MESO in" << endl;
      cout << "parallel (requires lbout.info file)" << endl;
      cout << "Usage: " << argv[0] << " [OPTIONS]" << endl << endl;
      cout << "Options:" << endl << endl;
      cout << "-h" << endl;
      cout << "       display this help and exit" << endl << endl;
      exit(0);
    }
  }

  cGatherData aa;

  return 0;
}
