import javax.swing.*;
import java.util.*;
import java.lang.*;
import java.io.*;
import java.awt.*;
import java.awt.event.*;
import java.awt.geom.*;
import java.awt.image.*;
/*
 *     DL_MESO_GUI
 *     author: R. S. Qin, M. A. Seaton
 *     copyright: UKRI STFC Daresbury Laboratory and CCP5
 *     2005, 2018
 */
class plotlbeEvt implements ItemListener, ActionListener{
    plotlbe gui;
    static String pcmd="",rcmd="plotting-tool ",tcmd="";
    static Boolean altutil=false;
    private static String OS = System.getProperty("os.name").toLowerCase();
    public plotlbeEvt(plotlbe in){
        gui = in;
    }
    public void actionPerformed(ActionEvent event) {
	String cmd = event.getActionCommand();
        Boolean term = gui.konsole.isSelected();
        if (altutil) {
          pcmd = gui.plotalt.getText();
        }
        try {
            if (term) {
                if (isWindows ()) {
                    String rcmdargs[] = { "cmd.exe", "/c", pcmd };
                    Process p2 = Runtime.getRuntime().exec(rcmdargs);
                    BufferedReader ou2 = new BufferedReader
                    (new InputStreamReader(p2.getInputStream()));
                    String line2;
                    while ((line2 = ou2.readLine()) != null)
                        System.out.println(line2);
                    ou2.close();
                } else if (isMac ()) {
                    String executionPath = System.getProperty("user.dir");
                    tcmd = "tell application \"Terminal\" to do script \"cd "+executionPath+";"+pcmd+";exit\"";
                    String rcmdargs[] = { "osascript", "-e", tcmd };
                    Process p2 = Runtime.getRuntime().exec(rcmdargs);
                    BufferedReader ou2 = new BufferedReader
                    (new InputStreamReader(p2.getInputStream()));
                    String line2;
                    while ((line2 = ou2.readLine()) != null)
                        System.out.println(line2);
                    ou2.close();
                } else if (isUnix ()) {
                    String rcmdargs[] = { "xterm", "-e", pcmd };
                    Process p2 = Runtime.getRuntime().exec(rcmdargs);
                    BufferedReader ou2 = new BufferedReader
                    (new InputStreamReader(p2.getInputStream()));
                    String line2;
                    while ((line2 = ou2.readLine()) != null)
                        System.out.println(line2);
                    ou2.close();
                }
            } else {
                if (isMac()) {
                    if (pcmd=="vmd") {
                        String executionPath = System.getProperty("user.dir");
                        rcmd="/Applications/VMD*.app/Contents/MacOS/startup.command";
                        tcmd = "tell application \"Terminal\" to do script \"cd "+executionPath+";"+rcmd+";exit\"";
                        String rcmdargs[] = { "osascript", "-e", tcmd };
                        Process p2 = Runtime.getRuntime().exec(rcmdargs);
                        BufferedReader ou2 = new BufferedReader
                        (new InputStreamReader(p2.getInputStream()));
                        String line2;
                        while ((line2 = ou2.readLine()) != null)
                            System.out.println(line2);
                        ou2.close();
                    }
                    else {
                        rcmd="/Applications/"+pcmd+".app/Contents/MacOS/"+pcmd;
                        Process p2 = Runtime.getRuntime().exec(rcmd);
                        BufferedReader ou2 = new BufferedReader
                        (new InputStreamReader(p2.getInputStream()));
                        String line2;
                        while ((line2 = ou2.readLine()) != null)
                            System.out.println(line2);
                        ou2.close();
                    }
                } else if (isWindows() || isUnix ()) {
                    Process p2 = Runtime.getRuntime().exec(pcmd);
                    BufferedReader ou2 = new BufferedReader
                    (new InputStreamReader(p2.getInputStream()));
                    String line2;
                    while ((line2 = ou2.readLine()) != null)
                        System.out.println(line2);
                    ou2.close();
                }
            }
        } catch (IOException e1) {
            System.out.println(e1);
        }
    }
    public void itemStateChanged(ItemEvent event) {
        Object item=event.getItem();
        String answer=item.toString();
        if(answer == "field view") {
            pcmd="fv";
            altutil = false;
            gui.konsole.setSelected(false);
            gui.konsole.setEnabled(false);
        }
        else if(answer == "paraview") {
            pcmd="paraview";
            altutil = false;
            gui.konsole.setSelected(false);
            gui.konsole.setEnabled(false);
        }
        else if(answer == "other ...") {
            altutil = true;
            gui.konsole.setEnabled(true);
        }
    }
    
    public static boolean isWindows() {
        return (OS.indexOf("win") >= 0);
    }
    
    public static boolean isMac() {
        return (OS.indexOf("mac") >= 0);
    }
    
    public static boolean isUnix() {
        return (OS.indexOf("nix") >= 0 || OS.indexOf("nux") >= 0 || OS.indexOf("aix") >= 0 || OS.indexOf("sunos") >= 0 );
    }
}
